import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0.0,0.0,0.0,0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpatan(0.0);
  }
}
