import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.0,0.0,0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpasin(0.0);
  }
}
