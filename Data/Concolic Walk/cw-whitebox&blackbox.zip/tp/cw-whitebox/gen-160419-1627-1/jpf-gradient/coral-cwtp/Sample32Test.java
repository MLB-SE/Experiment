import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpsqrt(0.0);
  }
}
