import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0.0,0.0,0.0,0.0,0.0,0,0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helppow(0.0,2.0);
  }
}
