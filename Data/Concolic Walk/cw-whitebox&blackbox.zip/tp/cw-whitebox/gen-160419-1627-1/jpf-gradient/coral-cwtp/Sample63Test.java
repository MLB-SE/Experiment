import org.junit.Test;

public class Sample63Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark63(0.0,0.0,0.0,-8.0,0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark63(-0.08852391394723337,0.0,0.0,-8.0,0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.helpsqrt(0);
  }
}
