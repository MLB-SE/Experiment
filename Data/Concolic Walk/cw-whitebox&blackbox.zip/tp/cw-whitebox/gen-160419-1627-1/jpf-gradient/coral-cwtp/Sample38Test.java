import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpatan2(0.0,0.0);
  }
}
