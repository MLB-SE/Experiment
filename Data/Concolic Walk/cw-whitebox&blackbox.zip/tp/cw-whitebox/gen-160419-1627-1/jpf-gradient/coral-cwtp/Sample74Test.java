import org.junit.Test;

public class Sample74Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark74(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpsin(0.0);
  }
}
