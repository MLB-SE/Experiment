import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.0,0.0,0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helptan(0.0);
  }
}
