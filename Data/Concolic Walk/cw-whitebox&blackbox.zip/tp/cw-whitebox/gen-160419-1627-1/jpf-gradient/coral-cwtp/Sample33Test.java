import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpsin(0.0);
  }
}
