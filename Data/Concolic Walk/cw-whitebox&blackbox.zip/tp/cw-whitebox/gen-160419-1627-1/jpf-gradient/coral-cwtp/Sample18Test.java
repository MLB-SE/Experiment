import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.helpacos(0.0);
  }
}
