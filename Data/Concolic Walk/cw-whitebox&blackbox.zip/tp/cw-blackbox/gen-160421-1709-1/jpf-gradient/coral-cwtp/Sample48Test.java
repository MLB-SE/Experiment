import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-5.3333335761781955,-2.6666662880890963,-8.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-5.333333909511566,-2.6666669547557853,-8.0);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-8.0,-8.0,-8.0);
  }
}
