import org.junit.Test;

public class Sample76Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark76(-7.999992000000013,-7.9999930000000115,-7.99999400000001,-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0);
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark76(-7.9999930000000115,-7.99999400000001,-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002);
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark76(-7.9999930000000115,-7.99999400000001,-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-8.0);
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark76(-7.99999400000001,-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002,0);
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark76(-7.99999400000001,-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-8.0,0);
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark76(-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002,0,0);
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark76(-7.999995000000008,-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-8.0,0,0);
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark76(-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002,0,0,0);
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark76(-7.9999960000000065,-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-8.0,0,0,0);
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark76(-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002,0,0,0,0);
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark76(-7.999997000000005,-7.999998000000003,-7.999999000000002,-8.0,-8.0,0,0,0,0);
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark76(-7.999998000000003,-7.999999000000002,-8.0,-7.999999000000002,0,0,0,0,0);
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark76(-7.999998000000003,-7.999999000000002,-8.0,-8.0,0,0,0,0,0);
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark76(-7.999999000000002,-8.0,-7.999999000000002,0,0,0,0,0,0);
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark76(-7.999999000000002,-8.0,-8.0,0,0,0,0,0,0);
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark76(-8.0,-7.999999000000002,0,0,0,0,0,0,0);
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark76(-8.0,-8.0,0,0,0,0,0,0,0);
  }
}
