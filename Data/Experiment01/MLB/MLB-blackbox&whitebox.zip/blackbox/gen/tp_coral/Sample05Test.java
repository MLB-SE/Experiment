import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(3.4855991085880333,41.323140745524114,9.76951619770854 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-62.96447234895098,32.97571767127381,85.91552412700975 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-96.77430517938517,15.464262446746346,29.864976530753808 ) ;
  }
}
