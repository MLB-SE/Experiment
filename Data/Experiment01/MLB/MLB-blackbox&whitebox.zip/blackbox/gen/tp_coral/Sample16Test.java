import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-2.1342248329004008 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,7.946645578670484 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(-4.084591462052842,77.24144370938205,58.97598045731246,-78.70207587600653,-76.73597075233485 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(73.57376840049804,15.327523519884469,-88.10222793299853,9.608304685134868,91.59435594664086 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(98.35840442308194,14.486042994797941,58.51083263399619,11.629506861368426,94.13407593074348 ) ;
  }
}
