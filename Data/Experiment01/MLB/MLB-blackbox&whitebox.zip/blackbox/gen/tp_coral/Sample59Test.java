import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,4.030992209186152,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,-41.658834504586096,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(10.643389862645979,59.286786251930316,5.277319059453258,20.210841869351043,58.91569255188054 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(15.810467127829071,-23.466583104384583,56.139203071940244,36.0986494043247,-27.8061203440797 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(21.56954732951681,10.712328869674836,75.72309186638418,67.40722892361958,79.93454005657577 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(-30.92757710750527,2.7450181591544864,27.309614954487486,85.1657310461978,-14.470241627260265 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(-32.49823682182824,1.970488102057132,-23.385949064903627,-67.2900101182027,-56.75951054729709 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(3.2547426664946144,0.36648244918171713,-8.880418278180159,63.17789419996518,35.2975522639133 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(-41.009202312727155,-26.418412884211882,67.50021984186469,-86.75385662147677,14.628956010057408 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(49.53568588504817,60.27749540393984,-7.7678043585301,71.34463879299622,-9.452596964858401 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(-55.04289104411342,-81.51890043855694,-96.41198915759257,24.582208821543432,-10.222016605382535 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(65.0159922675602,56.24280698419412,100.0,-5.702583808322672,-11.258603599980205 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(71.36829596411911,5.455650010667213,87.85908693793448,48.75218457304959,-32.44725134659889 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(88.28306857801671,36.8168862958059,-40.36471602788105,24.19746989916993,58.60083492306235 ) ;
  }
}
