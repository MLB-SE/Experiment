import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,2.0637319711378694,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,47.10823242934342,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-50.80241715635201,-1.8326837535729084,64.86070818540477,-1.6875199230903917,37.04061946475275 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(-51.04148610357622,-69.92287381963922,-37.99124742675306,73.0398815281024,68.1126037641661 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(98.27887780450416,-81.73536560442909,87.53942049019292,-38.79471846336264,-66.78875304436673 ) ;
  }
}
