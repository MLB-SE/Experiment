import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(1.1023152909307392,12.982454174970798 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.20129294975575,46.05931591552694 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(-14.289557365759848,-92.64507406489379 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(19.334469197994224,30.66553080200577 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(20.464026660627454,41.08501076373321 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(-21.633594644535222,29.692718937887065 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(24.443014054768668,-4.9439876673358185 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(3.8474850017681064,24.041872413494264 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(62.712274278775226,-12.712274278775226 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(64.16095005165897,72.7194748320938 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(73.71550585806915,85.59935138791207 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(74.22697895740151,-7.812787784810865 ) ;
  }
}
