import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,7.692298904877106 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-85.3813090367004 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.9821540259377431,-94.09121187366048,-93.24785765259688,0.1387998049365932 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(1.0904719646273258,-1.3363823550460978E-51,67.94350127597028,-47.840102101443954 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(1.1143510065072064,18.307528622807624,-59.47398661804193,91.95750681045533 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(-23.940691124091913,-70.55907450677843,61.99171323539167,-32.70666805995188 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(24.57568603043572,31.14937727676829,84.47838487229603,27.316201677891286 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(25.070399727576874,-0.3637650347590912,6.6993667213448305,-62.963071512479665 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(25.95098690981048,81.2507314943663,152.18968193358762,-1.200738920619557 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(30.51975346964454,-100.0,100.0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(-32.347179988709215,38.2158988612681,-86.82681854589418,56.84273217546922 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(35.61082216621372,0.0,-64.24216098614421,68.07184649208733 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(37.030060169967015,-16.91742486652619,20.659652242673317,41.861841359881026 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(43.30249264202919,0.3617496306745931,-1.9912116218129938,61.10222180492039 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(44.74112671559564,-35.24963274304083,21.4258666420186,-1.2692650457309709 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(54.69547536046386,19.997534937954043,55.0792243104282,19.6137859879897 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(55.63400068514156,-40.11759793186489,-34.35998896009869,-88.27022359023992 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(61.45963340001438,25.968634825044703,42.191632507123785,15.023942991740327 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(7.317598766453642,9.917785460016091,82.48127891125878,-21.212702856591335 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(74.39355768565389,-2.2249065787853795,-19.19019749636002,17.13333788934632 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(-83.66587033747885,90.04332348885342,88.76134174687266,-3.730973718328002 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(-93.09892244897537,92.9356527158119,11.8820508414956,-72.77558804851263 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(99.30580808224974,-85.67443192482855,-97.59322308334282,-81.89490819272405 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(99.3771359569762,-100.0,100.0,-100.0 ) ;
  }
}
