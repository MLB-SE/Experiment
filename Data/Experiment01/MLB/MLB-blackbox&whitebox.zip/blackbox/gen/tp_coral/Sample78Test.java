import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0.0,-58.49273941599705,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-54.100940633384795,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-96.15434245377628,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-14.082323458447958,-90.0,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-14.137689924381732,55.806364896420604,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-18.56772847909349,-40.584918717750206,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-45.37840492533475,-4.0E-322,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,60.41789159814027,-33.83549055889408,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(-0.2054453292968744,80.00018469535581,-100.0,0.20544531834887425,-100.0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(100.0,0,0,100.0,3.75E-322,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,2.6355494858076308E-82,89.71832390953048,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,0,0,76.98455746806437,-1.9662785120217545E-261,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(-100.0,100.0,100.0,-100.0,-0.8739503379826239,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(16.0,160.0,880.0,16.0,687.0,17,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(1.812137117970657E-21,0,0,40.104418205186974,90.0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(-2.0,867.0,507.0,-2.0,-399.0,0,0,893 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(30.042834191294872,0,0,-31.66574521280394,86.73929669243185,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(-34.3004907630509,0,0,-81.68453154703725,84.38939711686373,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(-36.09739005905619,30.287893287642703,61.75237207285991,-17.81619002762831,-8.62344148920269,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(435.0,-610.0,830.0,435.0,968.0,0,0,-4 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(50.11389481656087,0,0,-81.38679773317648,57.914293898065466,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(52.87831289352337,0,0,-64.98900081384406,-51.25727673932761,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(-54.65943319843145,0,0,55.41369682775559,-95.99020811182251,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(55.80943836141578,0,0,95.40074584907357,-90.0,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(6.169067113340929E-20,0,0,36.81190115163516,90.0,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(-71.0,1127.0,-133.0,71.0,795.0,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(84.111204271254,0,0,-72.98669576970957,-63.35070721994358,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(-88.50117853941582,0,0,91.13416282386274,-61.83769283741294,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(99.99541835887764,0,0,55.86550688623185,90.0,0,0,0 ) ;
  }
}
