import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.4874089906145507,-71.02501946947677,54.481787876331595,-91.48663030781458 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-21.211846179228203,86.86155711004807,-42.949038486070855,-36.78602597901921 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(47.321124491109344,14.145619925043235,31.122851696893036,51.20683034345518 ) ;
  }
}
