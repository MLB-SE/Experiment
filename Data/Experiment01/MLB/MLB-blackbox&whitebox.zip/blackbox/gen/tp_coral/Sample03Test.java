import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-33.12042255437966,64.27272575516173 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-40.20411234878076,85.715207403325 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(72.03956008084957,-55.194942389537054 ) ;
  }
}
