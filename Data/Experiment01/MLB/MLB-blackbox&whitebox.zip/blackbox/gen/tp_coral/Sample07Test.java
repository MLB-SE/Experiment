import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-27.70909755537876,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-28.808792821627208,0,74.88005499359453 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,-42.823304454057265,0,51.019276348472914 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-45.0294947035131,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-61.92303348735572,-66.65255669818963,-85.5753837089586,64.00024722160401 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(68.96434475835557,-67.8912908889132,-36.59363047388968,-50.0918730558608 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(87.45251183662509,-16.666011353315383,-69.56579872262753,-31.651418455952737 ) ;
  }
}
