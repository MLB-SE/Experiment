import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-32.76718372640737,86.94860817863136 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-41.41651465790197,15.752541472044882 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(-56.17297983039621,-65.49065063774631 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-72.91568906839166,-71.84299638939511 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(-85.24739886989283,83.88061437879139 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(91.8966535755404,-13.42470589902915 ) ;
  }
}
