import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(-0.3547795209767628,-54.242185643728206,67.54949315053932,72.58899418085784 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.503136127052727,80.8307653921211,-67.23243329998043,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.5571582328439462,-159.1753722041187,-115.98212454759992,1.5441879502486557 ) ;
  }
}
