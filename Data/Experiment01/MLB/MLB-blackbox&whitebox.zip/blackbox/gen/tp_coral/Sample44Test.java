import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(-0.6657489237894509,-95.7970207237846 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(31.754203741258152,0.04247539495226249 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(62.06232968977915,8.690194496151364 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(73.3523454744558,86.48704392719108 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(-80.78681818536218,-80.78681818536218 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(93.60750822713584,97.2798616952351 ) ;
  }
}
