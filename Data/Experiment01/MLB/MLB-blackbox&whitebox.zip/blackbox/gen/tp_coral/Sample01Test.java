import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(17.998166719324303,-94.35073359929243 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(25.98996021169924,-83.0057429084513 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(45.366188890754586,38.56159090324337 ) ;
  }
}
