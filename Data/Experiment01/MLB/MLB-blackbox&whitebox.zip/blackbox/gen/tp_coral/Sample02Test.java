import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-34.20028585056864,58.476697430437 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-68.94306899512316,72.55524469337325 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-88.6584028055183,-24.197699561720512 ) ;
  }
}
