import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(0.5851900707028125,1.5176345462672156,-4.570835838764978 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(100.0,44.35109287564598,100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(11.530455626254312,-31.341202429418374,10.383728090369118 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(1.2536484564451311,-26.620971710171478,0.2981748146483482 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(16.10680732941509,-24.739167839333057,17.114015048594567 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(2.22146535937992,2.310080656687295,3.2530318121629285 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(26.61959180792745,-56.75628980526369,27.87598141458924 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(-34.81109860487082,-50.49707913052303,-16.19793223829906 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(43.548379477217054,-32.94887819948069,44.817442928969314 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(59.03609832460425,99.4273628658625,61.745249617686284 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(65.96258784031522,10.068854706490526,-76.8807578153334 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(-75.32110295830898,-77.11401560052693,-27.55080442847617 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(82.67269753071253,97.71549261366019,21.53789324077711 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(91.70493945257613,76.45553999155709,88.56943835613495 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(91.88610967964058,-41.25605832041538,92.83858088528632 ) ;
  }
}
