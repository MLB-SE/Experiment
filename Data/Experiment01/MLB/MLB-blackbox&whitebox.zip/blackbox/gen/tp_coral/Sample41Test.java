import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.532193187191794,0.8154227756851539 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.7815270365714022,1.39231154546348 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000013 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-2.9318719358223433,11.527744983884999 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(5.77004097207228,96.74723386922756 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(-6.440485778919073,47.920342847377896 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(91.45250641835489,-24.644770426783964 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(9.674147937183387,83.91499037332618 ) ;
  }
}
