import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(19.325536628593014,-4.396081963361581 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(20.175687662920254,29.824312337079732 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(-33.4500755060395,-53.151162603462446 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(46.406945746065304,91.46056842285478 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(55.29720084060378,62.796710147906936 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(7.6416673234293455,42.358332676570654 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(78.80328059755516,81.35230047984624 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(79.6799055470253,-7.013179529354318 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(85.54999159001503,71.24043039794188 ) ;
  }
}
