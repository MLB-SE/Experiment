import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(12.041849948896584,63.36793806100377,1.0981704715216694 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(-25.17679711016959,-34.65704312702644,-24.18125141191068 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(33.91124740264575,-51.71917269418464,-52.6233256562487 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(45.34097953204051,-27.064946397508805,84.314165431312 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(58.93387102019193,24.18791669679625,85.99761508307395 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(8.378381198929858,2.509255119536718,-79.34107727888752 ) ;
  }
}
