import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-11.149701235630943,27.47000208419665,-65.3916182127887 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(43.96609997372008,-21.87856418334941,-86.02649728939129 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-91.58421506604775,29.51675553524336,16.59188796110325 ) ;
  }
}
