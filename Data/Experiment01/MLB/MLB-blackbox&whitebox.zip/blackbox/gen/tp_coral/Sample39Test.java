import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(29.96868832239207,-41.97676036282587 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(54.00955232663992,74.49782853127672 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(5.700317045173285,-1.3623491506824194E-17 ) ;
  }
}
