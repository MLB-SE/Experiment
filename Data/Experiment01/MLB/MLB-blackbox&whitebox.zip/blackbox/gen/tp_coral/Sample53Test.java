import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(2.5424999421597647,73.74267585571266,-79.98014584541046 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(-43.13014285117676,45.72223084930218,-43.979994820929534 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(48.98110401209351,-27.653940284855082,37.366843750542955 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(61.79541006398574,50.514129695473514,66.06081738925076 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(75.1198794008188,-29.3411464262241,78.31226803360553 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(-85.11356103110012,-2.785130179890582,97.01680267226858 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(-9.221323725878957,-30.13800013200334,-13.783743130802023 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(92.29565205766295,44.56959395576118,90.24345000579612 ) ;
  }
}
