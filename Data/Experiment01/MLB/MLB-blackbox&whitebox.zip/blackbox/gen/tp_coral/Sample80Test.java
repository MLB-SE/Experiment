import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(-0.6042826019970549,3.4822822881922235 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-63.32566417949366,93.39335140044929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(76.4700224292072,85.87248450909695 ) ;
  }
}
