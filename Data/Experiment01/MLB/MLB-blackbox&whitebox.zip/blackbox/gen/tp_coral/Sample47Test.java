import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(-23.947462194198806,6.98939605772901,87.77753811527705 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(53.776160071263774,-92.38791762792191,-92.21014598899822 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-5.472038029127679,-94.52796197087233,-100.0 ) ;
  }
}
