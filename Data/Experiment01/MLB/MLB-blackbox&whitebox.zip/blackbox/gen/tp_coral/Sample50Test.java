import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(13.137723871233398,36.862276128766595 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(13.404254354772895,-3.6611820980078136 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(18.301934183013003,20.95615727348465 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(18.4977286511416,31.4977286511416 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(-25.175238473658197,77.06508658041435 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(35.79474682140821,-2.1150149148928534 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(44.1914876438793,85.65186005081262 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(51.6883352888066,88.56641996440732 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(55.809859605035996,72.66644690619097 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(5.841895889662011,7.221944959927366 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(7.405653730533459,20.405653730533416 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(98.17024305023108,-48.17024305023108 ) ;
  }
}
