import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(1.835925874919288,7.222023157033888,-84.66693815721781 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-26.28486699750742,81.51603597207023,61.0995004987449 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(33.28113350040314,-90.47652162112682,75.75302292121205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(42.75762199837261,81.1812319943336,-83.81040180067183 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(67.97733133480207,31.69990626964986,57.83540596719524 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-90.48797201159225,89.77398534889062,-46.500956348738654 ) ;
  }
}
