import org.junit.Test;

public class Sample17Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark17(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark17(-0.008271948448992816 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark17(-0.012859075357013694 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark17(-0.016954227772430386 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark17(-0.019751744837861906 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark17(-0.025992498453984325 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark17(-0.04617877344485541 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark17(-0.046666476776934473 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark17(-0.061848652728031084 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark17(-0.10764303006209275 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark17(-0.1434899267876517 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark17(-0.2666073505568354 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark17(-0.34097429273398916 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark17(-0.350667658269316 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark17(0.36208927206005476 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark17(-0.4786189839315824 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark17(-0.5995372418175009 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark17(-0.7071067811865476 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark17(-0.7432546641041426 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark17(-0.8274791547704439 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark17(-0.8471485565534635 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark17(-0.8583349342212045 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark17(-0.8633564603004658 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark17(-0.9122383428449297 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark17(-0.9276049219716356 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark17(-0.9380567988784776 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark17(-0.9649981978628217 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark17(-0.999598138451714 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark17(-0.9998080413048245 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999984 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999996 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999996 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999998 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark17(0.9999999999999998 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark17(-0.9999999999999999 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark17(-1.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000004 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000000000000009 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark17(-1.000000484714176 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000160806702978 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark17(-1.0000553538403534 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark17(-1.0001570460740017 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark17(-1.0002941147969044 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark17(-1.0007594265072264 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark17(10.086969825836789 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark17(1.0587911840678754E-22 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark17(-1.1113793747425387E-162 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark17(13.875751077453941 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark17(1.3877787807814457E-17 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark17(-1742.235645870819 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark17(-17.759161778628282 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark17(-1.9735234708256257 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark17(2.1684043449710089E-19 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark17(2.220446049250313E-16 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark17(-2245.314936018812 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark17(-24.94290022652092 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark17(-26.611433642225578 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark17(-29.09113702693324 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark17(-33.661091620489955 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark17(-39.38580901989452 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark17(-40.09666982673992 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark17(-40.81415587334574 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark17(-43.2092125019089 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark17(4.440892098500626E-16 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark17(-46.50366044219459 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark17(-48.23584825701046 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark17(4.846419272973222 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark17(-50.78159930957962 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark17(-54.42811379853383 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark17(56.747774069573325 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark17(-5.748960183068121 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark17(5.81703134660944 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark17(-62.000163372623994 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark17(-68.13867337127166 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark17(68.94021992023738 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark17(-69.64124052628739 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark17(-74.97100028115563 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark17(-78.21784288380667 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark17(79.31999881439188 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark17(-80.84918621752442 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark17(-81.48149730018939 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark17(-8.200532357869981E-143 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark17(-8.74898723232991 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark17(-88.79999893830734 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark17(-89.42955029743187 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark17(-93.6582699833203 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark17(-93.76740742562752 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark17(-98.15714613333708 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark17(-98.59429588350142 ) ;
  }
}
