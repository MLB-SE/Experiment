import org.junit.Test;

public class Sample78Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,0.0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-13.480889515743272,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-18.437627539744668,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-1.93E-322,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-21.947195426825886,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2.220446049250313E-15,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-23.176488279688456,0,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-23.441784126642347,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,23.784127461009817,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-25.977398963398997,0,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2708.966082529921,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-2709.0727333055083,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-27.851302599906006,0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-29.003589600257172,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.458065414261291E-223,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.508354649267438E-15,0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-35.947236555590734,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-36.580664167851154,0,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-3.9415304279808914,0,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-5.532993816466458,0,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-56.99061218023698,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-58.37905803653036,0,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-66.93133294048037,0,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,70.09036595413374,0,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-72.11622490987915,0,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.08918630619155,0,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-74.83523717354149,0,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-84.30659638442688,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-86.66263635015005,0,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-8.881784197001252E-16,0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.9149177848745,0,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99351692622768,0,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999996,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-89.99999999999999,0,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.0,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,0,-90.00000000000009,0,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-32.70217776525496,0,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,100.0,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-7.032303845712412E-13,0,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-7.807590168721198E-13,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-100.0,-8.171241461241152E-14,0,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.0237970658722156E-4,0,0,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-10.70367640191732,-32.69616233066557,0,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-10.977941057081921,0,0,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,117.83957991856607,-32.69976929665027,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.6468071706506512E-35,0,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.7366668755162067,-29.50072185916548,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-17.737198923163223,-3.5083546492674388E-15,0,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-18.080049816753572,-3.077838901347178,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-19.609165572477366,-23.967828585652967,0,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,1.9670673588077108,5.941380774104445,0,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,19.801216034325904,7.105427357601002E-15,0,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-2.5467548523852056E-35,0,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,26.37739954670695,-1.887062348554888E-14,0,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-2.827868524450989,-3.429554403164642,0,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-28.33614255417875,-8.940353095189948,0,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-2.8626016613479013E-38,0,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-30.684346303972404,-0.7653395005323631,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,32.48720946377449,-26.66649910148496,0,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,3.567311611664948,-6.410472664114636,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-42.83110669876058,-18.575596081317002,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-43.156193497999766,-32.49115709160368,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-43.31550632629684,-26.515111511519308,0,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,43.61795150678418,23.395694681720514,0,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,44.03549105647667,-28.508718286209955,0,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,44.646885623297834,-12.026025387996555,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,48.11035538504865,0,0,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,49.14091232145233,-6.181383028630336,0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-51.31171871973128,-17.313136345454325,0,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-53.45765119040331,0,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-54.197675665918865,-32.70392796336153,0,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-56.19613477842095,-32.70040613182481,0,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-57.404773505941705,-28.872907525673313,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,63.3150431185404,-10.115038934119582,0,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-66.44709763492013,-32.64471649486625,0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,67.94102419528285,-5.248536706125692E-15,0,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-76.78669848954047,-29.222912899204772,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,77.64020607840237,-11.015727366716945,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-81.19079828928518,-32.703915146807475,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark78(-0.008571847810330269,-45.29079698619095,-45.29079698619083,38.00806905899307,-2.4498387712635434,0,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.03290973048626E-9,0,0,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,92.53980423844388,-29.874951247091758,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,94.52485592286902,-1.5631940186722204E-13,0,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-9.455589044427957E-9,0,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark78(0,0,0,-98.4164996689724,-3.508354649267442E-15,0,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark78(-12.412541136135744,66.17116980667782,70.24495546421855,-93.0618598629509,-11.389739901148843,0,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark78(13.04571184973599,-17.656592521564033,-17.656592521564036,55.93706570543054,-27.629299652027292,0,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark78(-1.501993210667196,34.81172539140428,34.81172539140428,100.0,-23.169945400520024,0,0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark78(15.555952918561816,0,0,76.13731605434566,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark78(1.56268557511851E-17,-99.55075001337518,-99.55075001337516,10.175802907014138,-1.8632038906830397,0,0,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark78(16.043644762639467,-86.91845711796634,2.188573786624283,-23.25683832885636,-2.193515787861066,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark78(-16.791659892625198,36.835257101738314,64.22315713164735,-29.575230389313695,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark78(21.930104990327752,-71.0503599475001,18.949640052499895,-23.849598012472022,-2.852950259523979,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark78(27.406841894104446,95.72703625233035,134.14589106032858,-87.95466477544937,-2.7469823627351104,0,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark78(275.8828503959569,-858.3856670756861,1975.903801560543,-167.85356879414172,-16.527790445071133,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark78(-27.626781303080293,-29.950899894031167,-20.426007730897027,73.32962154361539,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark78(-30.631935975247075,0,0,-32.752113967482785,-0.32571885241179643,0,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark78(-39.34856265908608,-100.0,-1.4929997928919931,-84.39671991349755,-4.967502916163696,0,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark78(4.210651240000019E-9,0,0,100.0,-0.6667467032655594,0,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark78(4.2262786406347307E-32,0,0,55.29473882687172,-12.010236374212639,0,0,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark78(-45.70107490345583,-46.3387695771883,87.31307757928766,18.93856126117082,-11.8309619887591,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark78(5.077478534367173E-28,0,0,-80.55379187909459,-9.977015995622935,0,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark78(5.084891464276409E-9,0,0,-27.378825856490955,-2.2026824808563106E-13,0,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark78(-52.84010610454657,-38.92996267854962,-3.135649551411319,1.2064840491248674,-11.880879278494348,0,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark78(54.811620508437834,60.56843633378774,15.305457334773891,-83.30016665252143,-31.574037271177133,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark78(5.687431813468024,0,0,-24.91987688273889,-11.51073457655663,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark78(-5.8008180916284715,-10.580632751261959,70.37959569189283,-38.45425725485809,-27.256330654186826,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark78(-65.0416823927419,60.86218633668656,60.86218633668657,93.58857074286036,-2.029160016093982,0,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark78(-69.3017175161028,-1588.6670733424169,1020.3872393670952,100.95900189605511,-0.15059051746487362,0,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark78(7.157055488627665E-5,0,0,0.4071908050320481,-4.647130593672728,0,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark78(-80.92234510632454,56.25468586875593,-18.623153497603766,39.831668753435935,-10.380768930871724,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark78(8.463743516581509E-26,0,0,95.78488812575452,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark78(-8.491324015195787,0,0,73.26252678326036,-3.434081340251019,0,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark78(94.60665734919112,83.99669822578068,-34.0040166572859,26.090732642270638,-69.56235780298432,0,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark78(-97.09160320774467,-29.0318762708158,35.08572217060684,21.650379101302676,-12.022471533969608,0,0,0 ) ;
  }
}
