import org.junit.Test;

public class Sample03Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark03(-0.00806553470242477,17.847250717582 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark03(-0.0085106649060488,0.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark03(0.01850182388625827,-1.5522945029086384 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark03(0.02097341700463925,1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark03(-0.026051240977988062,-6.459665863725875 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark03(0.027390479138942714,5.862703725071071 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark03(0.03745030246819777,-1.146051564931426 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark03(-0.042018090354428494,135.41421486106668 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark03(0.04394004811140639,0.11078814269893839 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark03(-0.048371115043800206,1.5707963267948966 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark03(0.06371791246686616,0.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark03(-0.06546027925549981,-44.12188877012859 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark03(0.09513276131246173,-32.83103035922237 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark03(-0.09966862730263415,37.600262223044666 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark03(0.11433572581534561,-20.83652164854119 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark03(0.11885173332967185,92.79583501422857 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark03(0.12641882798621704,-6.819403676013858E-10 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark03(-0.13105353617101853,4.581335444213671 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark03(0.13648255252324049,88.92436106096346 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark03(-0.14725690793782983,2536.416980405098 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark03(-0.15310741428468022,50.94733001665844 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark03(0.16757930724123282,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark03(-0.17725053341625596,19.236514812477367 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark03(0.18047666932025028,0.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark03(0.19114504758859008,-92.8394163765509 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark03(-0.20292563712539224,-10.454962766946554 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark03(0.21436173345213425,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark03(-0.23567554612928276,1.5707963267949339 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark03(0.25343530674044246,-75.57711449482467 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark03(-0.26340408461559967,83.51560940474512 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark03(-0.26396773035457954,34.09242423160504 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark03(0.26713063388123715,69.08009998682064 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark03(0.28531914117079915,12.06588994343798 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark03(-0.29732555718069875,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark03(0.30075752465551986,85.34714739095563 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark03(0.3019895457976052,-1.5707963267948963 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark03(-0.3023403400538331,45.409884682973995 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark03(0.3039290618227223,89.74112823159157 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark03(-0.30681452930885356,96.96134799418098 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark03(0.31802349312622197,-1.5707963267948961 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark03(-0.318519067979949,35.458472692694535 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark03(-0.34358123943054053,0.1618310880672565 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark03(-0.3436192198528971,73.4563195292339 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark03(-0.3600947373038561,-2639.8626452612257 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark03(-0.3655456574722957,1.5707963267948966 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark03(-0.40149076181883314,1.570796326794881 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark03(-0.4042637708264316,33.37554513034713 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark03(0.43471144191414646,-1.4850708651064117 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark03(-0.436693528106357,-48.25799260253544 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark03(-0.47003483997781387,1.570796326794897 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark03(-0.5067512191112638,-1.5707963267948966 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark03(0.5315904852412245,71.88175909690719 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark03(-0.5347803092891611,1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark03(0.5417292315676576,-41.47069970577277 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark03(-0.5491059204891809,-32.49323604796194 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark03(0.5552440111071314,45.18413231409755 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark03(-0.5591952441546603,-67.03547105626784 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark03(-0.5639803661965739,-13.569336538026306 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark03(-0.5723280550859451,-1.5707963267948968 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark03(0.5767159732673406,-100.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark03(-0.5930707938149595,-35.93661990199885 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark03(-0.6035154282928374,-44.3061112227972 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark03(0.61004734112155,76.2772170959383 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark03(0.619211006155082,0.4560745633737625 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark03(0.6357553152038092,-22.04108494565584 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark03(0.6453037263881204,-1.9154016696508568E-7 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark03(-0.6508825207079929,-72.59078617477918 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark03(-0.6517415981065182,-47.40805441310319 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark03(-0.6622358106481112,8.881784197001252E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark03(-0.6734376611853321,0.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark03(-0.6755219568852269,40.5077605858173 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark03(-0.6846428279273713,-1.570796326794897 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark03(-0.6892028213586414,-69.4102699556302 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark03(0.7041750580497945,1.5707963267948948 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark03(0.707884277841897,-72.69744447340275 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark03(-0.7157013283213229,-11.700544308515731 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark03(-0.7273159284664104,-82.01779063288637 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark03(0.7354225590112298,0.11569375323606965 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark03(-0.742685894593393,91.83262321609743 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark03(-0.7495407380774258,55.20651771465734 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark03(-0.7706553321629195,-1.5707963267948963 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark03(-0.7805521564427913,67.8393772566811 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark03(-0.785642970562477,83.86608907670941 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark03(0.7865856771460649,-0.5707944573421454 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark03(0.7942327378642225,0.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark03(-0.7947855148219776,-12.300544805271741 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark03(0.7969973806230536,4.331753403940581 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark03(0.7999510746615925,2543.2371000408957 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark03(-0.8007713626772347,-77.88440287400297 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark03(-0.8011746533451223,-47.53270751700612 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark03(-0.8081700084375534,44.16131177449257 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark03(0.8320722278962175,-6.198806773290224 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark03(0.8514500466161319,0.5524543215400004 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark03(-0.856811363474311,54.12106007434707 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark03(-0.862574032838225,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark03(-0.8649849540053722,10.835239202178172 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark03(-0.8761432658969959,69.11503837897546 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark03(-0.8776073731402789,-158.10944140110715 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark03(0.885277813247157,0.0808731836068112 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark03(0.8910072325424409,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark03(0.9035404529268364,62.164597197927804 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark03(0.9044345226743332,55.046875576606 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark03(0.9068679728580608,-93.58385125375696 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark03(-0.9194771373622075,37.89779331695297 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark03(-0.933947938300463,-61.54580837225906 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark03(-0.9488347752911803,-21.585976104441045 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark03(0.9529748602562051,17.280065078704396 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark03(-0.968582134407088,69.14453559435232 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark03(0.9847688173052671,-1.5707963267948966 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark03(-0.9975802365600543,-43.61665869542926 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark03(-0.9985415646136175,83.28208098231465 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark03(100.0,0.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.04513796483522931 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-0.13533228937318065 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,0.5610702739625305 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-0.5707422819390514 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-100.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,100.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,11.650991911128918 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.230134974892268 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-136.28142191249142 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark03(100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,1.5707963267948972 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-1.5707963267948983 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark03(100.0,18.6563907792563 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,2.005357562763122E-6 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,21.40705707665258 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,2606.26369609115 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,3.552713678800501E-15 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-45.35873319784389 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,46.68825433102813 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-5.243353895258074 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-6.443625892048023 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,-69.41919235989545 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,70.97945495462696 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark03(100.0,-72.43949206761151 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark03(-100.0,91.32255525750608 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark03(10.048997281865411,-1.5707963267948966 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark03(100.53119707647235,-1.5707963267949032 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark03(-100.56580020708803,-56.16985328007165 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark03(-1.005927156769277,-45.95508507490065 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark03(100.99949223553632,-7.012222598325072 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark03(-101.14606469426487,30.760096079384724 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark03(-1.0129527950087205,0.7505376585002637 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark03(101.4828958129228,-58.38792912023689 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark03(-10.234141841715243,0.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark03(10.26490726311728,-92.48261570701086 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark03(10.283143110464291,0.5706914484181654 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark03(-10.30751772808569,99.8429083553948 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark03(-10.30985769699972,-111.73275845429532 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark03(103.39315720330627,1.641143268216382 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark03(-10.341013065172373,61.685175359414586 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark03(-1.0352829892237514,98.96016858892955 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark03(-103.67255563273866,-1.5707963267948963 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark03(10.42477796075741,-2.5707963267968075 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark03(-1.0438813739730992,-78.01290138692303 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark03(-104.76012750710981,30.073361944991234 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark03(104.93239667991446,-2508.248593703746 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark03(10.520834559809593,-0.43409532345896623 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark03(-10.527998740242802,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark03(1.052871242315943,1.5707963267948966 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark03(1.0604751054961756,-78.14043834894859 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark03(-1.060966173907735,0.0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark03(-10.615750625589149,75.01840002417991 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark03(10.655895389984039,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark03(106.57321357582778,-37.29007765852981 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark03(10.673305049483034,4.215957769348758 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark03(-10.680406555133231,25.718597844061037 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark03(106.81413821165782,1.5707857148683737 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark03(106.814151494555,-142.94246546478897 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark03(1.068831568582476,-6.785150065392007 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark03(-107.00690499371937,77.97386574776412 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark03(107.06414842671599,4.9623871850477075 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark03(-1.0744902917208572,21.494842540054513 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark03(-10.749695287682641,96.98530229340852 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark03(10.770677302197555,42.17121666485829 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark03(-107.82332857915381,-60.354143389000384 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark03(107.86829465597219,44.044064880856105 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark03(-1.0828821740518597,50.505916591591635 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark03(-10.847611423471633,9.531730052630564 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark03(10.863348954032602,68.52849565158672 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark03(10.903012609823065,-6.431148797529571 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark03(10.92030493224297,-60.64213731200234 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark03(-10.921310792757467,77.82417713174232 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark03(-10.958907795831351,-77.3667349057686 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark03(10.964826448489973,1.5707963267948912 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark03(-10.972712530350663,-30.81145594486108 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark03(-10.99245867179988,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark03(10.99557428756427,-86.39428625607215 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark03(-109.95574348493017,1.5707963267948977 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark03(11.070493391180458,-0.013101334807099765 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark03(-111.05372271912196,-1.5707963267948983 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark03(-11.13631394043854,76.97368511116738 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark03(111.41446712683441,73.30428451414951 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark03(111.46687872318628,-89.43972623234916 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark03(-111.56967082419212,-50.30905882989534 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark03(-111.62924075445105,-0.43093772232505856 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark03(-111.65624187142326,9.793622609175884 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark03(1.1168838835693746,-16.55550809390542 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark03(11.174548476619876,-23.244444858798403 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark03(111.8021460642635,0.5658764959713795 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark03(-11.190383612669478,65.42664204854981 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark03(11.225494490633944,-47.189946917134264 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark03(-1.1227886913863525,1.5707963267948966 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark03(-112.6408926471712,-10.649385565790382 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark03(112.70908683254419,72.45662565580355 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark03(112.91244961833243,1.5707963267948983 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark03(-113.0956218665452,42.41150082344835 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark03(113.09729071549025,-95.81852822482382 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark03(-113.09733131719682,-1.5707963267948977 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark03(113.09733523705667,-20.420349505160747 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark03(-113.09733552433156,-1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark03(-113.09818806792381,-45.55309347699945 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark03(113.0983120963347,-1.5707963267948983 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark03(-11.32839181920096,1.57079632679487 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark03(-11.411055778504362,0.7270482008836154 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark03(1.1553871210413824,54.9778751260588 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark03(-116.23602135708109,-1.5707963267948961 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark03(-116.2627244322508,37.682596120483396 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark03(116.60764346490458,-83.37925049899049 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark03(-117.56583290615131,6.983932867307672 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark03(1.1790590718308196,-0.3917372549640771 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark03(-118.0548011567724,-16.946760336269207 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark03(1.1812030555980328,-26.881502735203867 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark03(118.19128151681426,1.5707963267948966 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark03(-11.851781651428889,73.90069948462397 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark03(1.1851901877419517,-2585.2243014816722 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark03(1.1869350698787964,-4.619133433562638 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark03(-118.85053842467076,-2.374088994203488 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark03(-118.85635619332132,-97.36943548266339 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark03(-118.94800269217541,1.5707963267948966 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark03(118.99510576299676,2579.3168811616383 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark03(119.05259041644833,1.8987267467587146 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark03(1.1907203860802564,-3.780406972112729 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark03(-119.07552777035858,-129.01000581818627 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark03(-119.25992041904503,-1.5707963267949054 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark03(119.29569738486546,86.7975543273842 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark03(-119.38039927950166,-83.25222092011535 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark03(1.1939497343274128,-82.59625788873677 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark03(119.396146184702,-89.53545177717197 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark03(119.59837652561316,-0.03376474255342881 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark03(1.2031212738351973,0.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark03(-120.5669230282389,56.841110463200806 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark03(1.2062029651242634,1.5707963267948966 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark03(1.2073199776031198,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark03(12.089583825375543,10.435445554065197 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark03(1.217033100274985,88.74681028167109 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark03(12.246923328876406,174.3584012705224 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark03(1.2273433030629026,-50.53664842403181 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark03(-12.323239323152976,4.769194625626158E-6 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark03(-1.232595164407831E-32,-55.02201269706583 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark03(-12.328889373856185,-0.231749691086864 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark03(-123.2907197935931,-2.8584994289401635 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark03(1.2368096972371205,63.49722325648975 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark03(123.7322531864302,91.46684358447064 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark03(1.2395711599567234,1.5707963267948966 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark03(-12.402528672368035,-1.5707963267948966 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark03(-124.37514900281855,61.37617423663039 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark03(12.463372420844749,-1.5707963267948974 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark03(12.520660327783247,85.61979785077301 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark03(-12.532675478848,-16.490017515169548 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark03(12.54108961746456,-6.049014748177263E-16 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark03(-12.554709137533564,-2608.2309648567457 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark03(12.559048131796102,-1.5786088267949556 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark03(-12.566342088923841,199.49112314838698 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark03(-12.566355841521615,-51.83629404327097 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark03(-12.566369252188094,-86.39379797371271 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark03(-12.56637061435917,-1.5707963267948966 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark03(-12.566370614592016,1.5707963267948966 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark03(-12.566379617116542,-1.5707963166438084 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark03(12.566614755978984,-83.25212805106858 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark03(12.568155026426417,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark03(-12.570333664010569,83.25616705479887 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark03(-125.80577991672999,-83.39427909326778 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark03(12.618605462317156,-51.794457375201304 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark03(12.64471411390619,72.28004141833338 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark03(-126.62533191802243,79.14898689210904 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark03(126.82563441714743,-15.908625250308877 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark03(12.709129491536018,72.31134010304915 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark03(12.71409297387196,-1.0395598435403883 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark03(127.18746416178692,95.9428021479162 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark03(-12.723971246507155,-1.9924485426028429 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark03(127.33680805094849,45.0667703368467 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark03(12.768831262376949,-1.5707963267948974 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark03(12.777139221023461,-4.923157587049068 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark03(-12.77757472901476,15.984836271374965 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark03(1.278800945802416E-4,30.59650030223648 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark03(127.99095812905946,57.70534770249711 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark03(1.2835086708478234,0.32957714575676905 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark03(12.880317070537103,95.50462947840585 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark03(12.901179469531172,53.11864202675899 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark03(12.90332910896683,-1.5707963267948968 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark03(-129.20699451834926,-49.668882473156025 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark03(-12.964683428464298,-81.7984298373025 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark03(1.2967263410489076,73.85007911626177 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark03(12.984347847585624,-90.5080795530194 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark03(-13.022654713039941,-191.86912041137813 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark03(13.024368556402562,11.10736371134179 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark03(130.28781514047307,-2576.351507348102 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark03(130.35795928873617,94.34735459339336 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark03(-13.04111121256959,0.027869574339124466 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark03(13.050357224486845,-1.290295365316077 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark03(13.059842828132103,1.5707963267948968 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark03(-13.075041453337684,10.486903448585766 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark03(13.080699327311885,5.226717693337402 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark03(13.121343807443633,1.5707963267948972 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark03(-13.129188066184327,1.5707963267948966 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark03(131.94107967518016,-10.995575114206666 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark03(-131.94671675989053,42.41150082299127 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark03(13.195005890006954,-5.76679199113176E-4 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark03(13.23038935885468,28.361626337072437 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark03(13.233268695895383,-26.00437966070524 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark03(-13.235531761730561,90.2045517746805 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark03(132.51054178293333,-5.276039312546704 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark03(13.258279769228782,-47.728549877646316 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark03(1.3283700410240158,14.703076742094368 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark03(133.03918020412615,40.73182818397196 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark03(13.35974888817941,17.036142462527522 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark03(-1.3390103243579423,16.351534370534853 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark03(-133.94078983147634,20.717281026597554 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark03(-13.408963799578572,1.5707963267948966 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark03(1.3421437562221992,3.552713678800501E-15 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark03(1.3431186121612466,-1.5707963267948966 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark03(-13.463593134339064,61.593211254828645 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark03(1.346802269471611,-157.3756780686815 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark03(-134.8639842459914,-2.070804874527162 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark03(-135.17938666980055,14.450802704556722 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark03(-13.51856308473512,44.39952113656915 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark03(1.353692343530187,31.63303051916264 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark03(13.537197019057047,-50.754436583454265 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark03(1.3563218158178687,73.32495742795933 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark03(-13.584002534566805,-44.49633647342773 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark03(13.624208508044132,18.336597488428822 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark03(-1.3713091299916456,-1.5707963267948966 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark03(-13.76591177053345,-1.736641010891944 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark03(-13.772551944711779,-74.69298469736587 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark03(-1.3796155814393791,0.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark03(-1.3817578333906142,0.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark03(138.2339831028211,-136.65927206667644 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark03(-1.3840156322369044,-78.31275161680374 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark03(13.852694935945834,152.12690512548374 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark03(13.857519144746579,0.0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark03(1.3858082427831313,54.04700758586392 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark03(138.73277013675846,1.570796326794898 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark03(-1.3877787807814457E-17,-1.570796325212476 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark03(-1.3877787807814457E-17,-89.53539062730908 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark03(13.939461961003232,164.3940494473904 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark03(13.949749551545196,7.748032802633702 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark03(1.4044650006326937,44.7330911171549 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark03(-14.068974432135278,-2614.7742661501784 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark03(-14.08191414426345,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark03(1.4110558227847365,81.8380516822053 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark03(-1.4130985594215524,0.3307861548757334 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark03(14.13716694115367,0.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark03(-14.137166941154069,2.235280606117928 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark03(-141.3749552417632,-67.54424205217786 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark03(14.17833486287276,2609.385000124466 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark03(141.83037449841117,35.17710737554951 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark03(14.198831333571302,0.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark03(142.02286715662729,-7.626109206640834 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark03(1.4206048735982921,-67.5442782281617 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark03(1.4220229907957416,-0.022194084859146063 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark03(142.3084404036187,-3.3548962887552596E-15 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark03(14.240780834744871,0.40598042377016663 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark03(-1.4307270711017577,0.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark03(-14.323562942806504,-127.17599467850538 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark03(-1.4336822197157328,-58.30380172905577 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark03(14.349705793289054,43.54369136145425 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark03(14.360867825851173,-44.113200629720644 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark03(-14.417161430035634,-73.1946714450536 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark03(14.427821626312914,1.5707963267948966 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark03(-144.51326206512294,124.09290892055111 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark03(-144.51521519022694,158.65042900623652 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark03(-144.7384667831135,67.47795609748286 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark03(-1.4504908766604807,-1.5707963267948966 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark03(145.21784637547137,-93.83067714052366 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark03(-1.4525300249476658E-22,4.712388995375597 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark03(145.40571727764376,6.918861048326098 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark03(-145.418559883822,85.32257747281508 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark03(-1.4565651523042504,0.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark03(-14.62424601003363,0.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark03(14.625185507907826,44.47031571701086 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark03(-146.42115679301173,88.61133248968136 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark03(-14.703872566691302,-82.33178640231726 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark03(147.18616947095953,190.2231085851036 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark03(-14.722866079861063,27.13382915726918 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark03(-14.736223898475487,1.5707963267948983 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark03(-147.39996544116934,32.73721810906958 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark03(147.6548217839914,-98.96016284597128 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark03(-148.16448932034461,0.9005356443888815 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark03(148.33846791385247,-89.59134962226463 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark03(14.84142093358534,-48.66422661307814 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark03(1.4851253929532646,-1.5707963267948966 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark03(14.860300862372554,-8.787443231195851 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark03(149.20668504716213,-3.1226266552367443 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark03(-14.964690986435443,-77.71935024749652 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark03(-1.498355760191598,-72.32907159916854 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark03(1.501938357077531,0.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark03(-15.033091835813012,0.0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark03(1.5037312481672966,0.06706507862759853 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark03(1.504632769052528E-36,-1.5707963267948977 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark03(-15.056484057351184,-90.3345229165617 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark03(150.79644617715172,-0.568122259484254 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark03(-150.96407703139405,-64.8372005311277 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark03(1.510199039322006,-37.63851455560463 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark03(-15.108518895807912,-1.5707963267948966 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark03(-151.12658852106028,-1.5707963267948966 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark03(-151.2102721817537,80.85658479615081 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark03(151.733796446951,57.18211501677025 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark03(1.5217612850919526,-31.464961577600874 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark03(15.23180534143117,67.4075147408885 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark03(-15.262791690972094,16.198548818407914 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark03(-1.526437608949427E-16,237.19024577849973 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark03(15.271514007639658,95.63290178193799 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark03(1.5281877120220488,-1.2437504751163267E-6 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark03(-152.9908917838854,-1.5707963267948966 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark03(15.316653097610057,-95.6587229251357 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark03(1.5346200057552797,0.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark03(153.93804002588885,98.96016741634962 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark03(15.400916606199559,-67.43572265350295 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark03(-1.5407439555097887E-33,1.5707963267948963 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark03(-1.5407439555097887E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark03(-1.5429753197998115,-0.5747284214609265 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark03(-154.58792000852117,-84.1305253185662 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark03(-15.473027924418616,49.15708324144657 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark03(-154.9778714378214,100.00000000000001 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark03(155.1493048082294,0.028381696553801607 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark03(15.5161248687006,91.28004183172352 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark03(-1.552382518513084E-8,-14.144216164887396 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark03(-1.5534567350554638,-50.753177918788836 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark03(15.565457388445934,-0.37639008361826015 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark03(-1.559125975684743,48.664758274207685 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark03(-156.05764499763873,-1.5707963267948966 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark03(-1.5626699631163914,29.5583689030249 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark03(1.5655950535102632,32.161128363790425 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark03(-1.567572833099058,-1.5707963267948966 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark03(1.5682217417583637,81.68398357837114 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark03(1.570163673721496,6.326530736982733E-4 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark03(-1.5702308076870628,-3.266490312047992 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark03(1.570794682823211,-11.022177882106009 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark03(1.5707949493945184,-6.429922224868432 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267881981,-94.2477796077048 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267901706,2.3821858744499948E-12 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark03(15.707963267924763,1.5707963267706897 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267925324,28.274333882310167 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267926526,-9.42477796077166 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267927947,144.5132620651291 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267935188,-34.557519189481916 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267935938,50.265482457440456 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267938645,-2610.076520263217 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326793931,-2.8976820965185E-14 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267940153,0.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267940475,31.41592653590289 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267941067,-75.39822368615128 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794146,-97.38937226128468 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267941594,3.851112662078951E-18 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267945397,1.1362626306449363E-59 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267945608,86.99254468694289 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267945708,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267946758,72.25663103256261 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267947322,65.973445725386 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948308,1.5707963267948968 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794853,73.46931592368065 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948595,1.5707963267948966 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948735,64.76665851063618 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948841,-1.5707963267948968 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794886,0.0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-1.570796326794914 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-26.97349628162074 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948912,-53.9695075435922 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-56.42650985600328 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,6.476262391923016 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,66.34124844245224 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948912,-80.64794930072776 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-0.2086006679179775 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,0.3080709924960468 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,11.107685589113814 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,15.599990969674668 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-18.79185578863403 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,22.41366254179799 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-2.3620466715314657E-9 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-2606.2491638321712 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,40.374013855862216 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,44.037124772065965 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-55.39838890692849 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,-66.96418104488009 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,6.766829379176512 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,71.54153973223451 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,77.98844631763544 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,81.53549075447776 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948948,-84.1054868471426 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948948,86.74746422500698 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948952,0.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-0.008605430199016767 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-1.5707963267948948 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,-1.5707963267949054 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,2616.537865618097 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,26.433047112729597 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,30.224151517258232 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948957,80.13894737873021 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948957,-90.50196472115323 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-1.5707963267946583 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948961,-1.5707963267948966 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794896,125.66370614266664 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948961,-44.278682985548 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,0.45033502269322334 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-1.5707963267948963 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,1.5707963267948968 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948963,24.68143513428788 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948963,-38.054622934899506 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark03(15.707963267948964,-1.5707963267948977 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794896,-45.77639984117699 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.0012871803803108871 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.015116070942308218 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.02610923782710494 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.09527083399207392 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.14607419106933417 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.18563330497967767 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.2106574452541642 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.2932055489432766 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.2982481372471626 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.36450189484392026 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.4084093803403288 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.4356653517627649 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.455162636539317 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.5570735618115911 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.5707860707469493 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.5707954563054441 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-0.5946376660691622 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-0.5952325119138503 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,0.679620750489633 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.6968131353787754 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,0.9389186887145211 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-100.53096491462269 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,10.262153554197837 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,10.42285947333295 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.0575864306372387 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,106.81435090619199 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-10.943437832659392 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-10.995574287563906 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-10.99557428756557 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,10.995574500581837 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-12.013749492399171 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,127.58563020828477 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-12.943462748625329 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,13.363892385097415 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-135.0884841043559 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,135.13025848568176 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-136.13185396990082 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,136.65926680479762 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,136.65928033333037 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-136.6592804300033 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.380219320831336 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,138.2292908954215 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.137166941154076 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.155672187501224 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.4261054010516199 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.429220955215115 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,14.4292232356159 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.529543562223793 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267937108 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267947633 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948903 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948937 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.570796326794895 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267948988 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267949225 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707963267950102 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.5707963267950105 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,1.5707963267950105 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,1.5707969715870826 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-15.725204480365761 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,16.099601569888165 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-164.51977939444922 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,17.278759594743867 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-17.670753986395724 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-179.6163246217397 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-1.8638083424973042 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,18.755154743650877 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-1.9695674492928816 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-20.095537614546046 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-20.272128103855565 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-20.371514670742737 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-20.42035224833365 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,21.952885926220024 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,21.991148575128552 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-23.54806989289517 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-23.561944901923443 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-23.70953767730968 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2.4116791654512966 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-25.13274122871764 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2569.337570055113 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,2603.6341243011184 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-2613.3041368953386 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,2625.7158381127583 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-26.895381016276115 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-29.59386664106536 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,29.703965467807453 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,29.84513020910305 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,30.104426022115966 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-3.077720725410529 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,31.253386272227257 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-31.33431870276477 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,31.415926535893494 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-31.41592653590371 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-31.97945284826123 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,33.135628741023716 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,33.44772352920094 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,3.346317300582214 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-33.776618918002846 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,33.96851846193156 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-34.16924648226218 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-34.598906072253236 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,3.7143538604319855E-16 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-37.75936276058861 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-38.592076041061105 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-39.09393125275164 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,39.141875063379246 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,39.14947961772525 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-39.26990816987241 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,39.26990816987241 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-40.8407044966674 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,42.411500823462205 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,42.411744964090445 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-43.56315447342497 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-43.57584747995499 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,4.3920459706258373E-4 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,43.98229715025825 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-44.00779281525508 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,44.34475897560832 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-44.50097045973885 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.36448162787997 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,45.41475976532965 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.50148941401606 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,45.55309347705199 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,45.553093477052 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-45.55309359638596 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-4.590058369094399 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-47.12388980384432 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-4.712389319112247 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,48.69468613064144 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-49.10090182207476 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,49.34596775690715 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-4.941623601328871 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,4.974708446244811 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,50.159666808355496 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,50.265482457436136 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-52.09649607859388 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,53.293758472835606 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,53.52990897709716 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-53.84654235532169 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,54.977871437821385 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-54.977871438287046 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-54.977871445271965 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-56.525561959315695 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-56.5486677646097 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,58.02196186405158 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-58.11946409141116 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,58.11946409141116 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-58.51092699911021 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-59.34893394057791 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-59.57044272969234 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-60.068612846897665 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-60.289666601106575 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,6.123233995736766E-17 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,61.26105674500096 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,61.26815885475793 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.283185307179586 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,63.02169272086846 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.331913291675881E-15 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-63.37456016461776 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,64.33840454960813 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.5961703284694835 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,65.97344572538567 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-66.1213255718992 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,6.6732424533799275 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,67.65735475128655 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-67.70431391635903 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,68.46586015299076 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-70.469924536872 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,70.79565278697426 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,71.20960064661921 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-7.131614771619588E-8 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,71.45345129423575 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-72.25663103256319 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,72.55695689698132 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,73.28451689827631 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,73.43613296306741 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,73.82742735936014 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,74.82299319659745 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,7.486620502305382E-5 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-75.35793333136863 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-75.39822368615636 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-7.77262458111854 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,78.53981633974483 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-78.57770672953384 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-7.86894877388562 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,79.40168285780703 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-80.11061441747572 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-80.11085680716474 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,80.50559363754957 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-82.77794036405955 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,83.2522053201295 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,83.25611157012953 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-83.29406777684873 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,84.23010229383868 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,84.25220532012952 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,84.58551609032929 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,86.16520558576046 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-86.3937979737193 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,86.7861769410585 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,88.39307030628795 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,89.53539062730911 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,89.67473100816449 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-91.0596543728302 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,91.1061869540989 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,91.10618695410136 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,91.17816742913206 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,92.32175194857976 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,92.67698328090059 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.311276754999902 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.424777960771323 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-94.3727796076938 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,94.7279546969026 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,95.15053573201442 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,95.31424446179128 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,9.680802845802617 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,-96.94077218277593 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-9.752530973684543 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948966,-97.98932200751307 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948966,98.48663571228421 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948968,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark03(-1.570796326794897,-100.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948974,0.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948974,-2570.356970080159 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948974,99.16573560323653 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-0.5707763090277612 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-14.432543783958444 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,15.70796326794897 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-1.5707963267948983 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,16.853904371282553 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,19.40145341846683 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-25.603000973253515 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,25.66375693276389 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-2600.9090901396494 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-2646.275168991565 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,28.560830003991327 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-3.0400071441169554 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-32.0641395040804 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-50.68285821412493 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,5.347860711797026 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,55.8293603904454 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,61.63544483799467 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-6.429300763211175 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267948983,-67.45883261271362 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,77.51248311686032 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267948983,-88.40920226450947 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark03(1.570796326794901,2598.965591364392 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949019,0.0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949019,-100.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949019,78.14252724960666 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949054,-2621.4601662521313 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,-44.11854404745041 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949054,7.771693810518669E-16 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949054,94.2477796076938 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark03(-1.5707963267949125,-1.5707963267948972 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949197,1.5707963267948966 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963267949623,6.123233995907447E-17 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963268011913,-7.1746481373430634E-43 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark03(1.5707963268402614,224.6258278471267 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark03(1.5708133152235377,-1.6988430966074053E-5 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark03(-1.5708213954407333,-2.6415149691584765 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark03(-15.723588267948967,-1.5707963267948986 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark03(-15.738401107591868,0.9407728333301151 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark03(1.5777218104420236E-30,-67.54424205218051 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark03(-15.808822486975016,0.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark03(-15.821329192068713,-39.15654224575267 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark03(-158.29579527880702,-2487.84299347515 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark03(158.71991437434326,-36.12831551628272 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark03(-15.89059301323914,-1.5707963267948966 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark03(15.973992913435456,-1.5707963267948948 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark03(16.01084460273165,-93.7044103534632 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark03(160.15323892365322,96.5426069040688 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark03(-16.03950731508153,32.37921079225608 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark03(16.061914720939882,36.27810958625169 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark03(-1.6084376126388236,35.63023947523132 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark03(-1.6095551561743076E-9,39.51080201818546 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark03(16.097208116361486,67.4030765793573 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark03(-16.142159086416072,7.419785815507377 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark03(-16.145073556734193,-89.88272312166626 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark03(161.48847014034357,74.59459575090168 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark03(16.17645225314328,2666.8831258597015 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark03(162.34735052628034,60.55843592574283 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark03(-16.34469526997226,-1.5707963267948966 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark03(-1.6359309894407232,-53.921746090861106 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark03(-16.377302540667937,32.31738358997386 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark03(-16.384961558044996,-1.5707963267948968 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark03(16.39763331230606,0.11163366460103266 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark03(163.99607674558735,13.503908182235973 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark03(1.645435215559928,-1.5707963267948966 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark03(164.60814578694448,184.62018980087856 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark03(1.646849043236133,-1.5707963267948966 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark03(164.69340935265797,-0.28318815389304774 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark03(16.553300714091186,-1.5707963267948966 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark03(-16.582969197228863,-66.06626861186729 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark03(1.660723976169166,41.27926904384975 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark03(-16.684630371211526,1.5707963267949288 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark03(-1.668786751376956,2676.186284837957 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark03(16.715808054223533,3.8254791028802515 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark03(16.742781526296156,-56.012934492234265 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark03(-167.77556515328493,-0.2996418137663249 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark03(-16.789956030080447,-44.6926095666744 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark03(-16.814969753743014,0.0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark03(168.23833122911398,-45.417201349995885 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark03(-168.5472939231716,-0.34574855817652234 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark03(169.1879354476331,0.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark03(-169.19588127922896,57.41184515616777 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark03(169.204121547458,74.18338759215587 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark03(-169.37138329852368,-1.5707963267948974 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark03(-16.960039129321686,-1.5707963267948966 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark03(-169.6458864603584,1.5707963267970737 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark03(-16.97448594142685,0.0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark03(16.98548947823664,-97.09610214477637 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark03(-170.5797952939827,16.34496759461 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark03(170.659948421953,-43.42544595156639 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark03(17.150037712241787,66.10216760788774 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark03(-1.7151244994428829E-15,-1.5707963267948983 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark03(-17.22920171327896,162.37457882980118 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark03(-17.23854715200857,0.009361925429551892 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark03(-17.278759625842728,3.1098388833616385E-8 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark03(-172.89022121394305,78.1240079868756 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark03(-1.7291140405096428,-85.84547099385973 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark03(-17.388083411697465,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark03(17.430146771635442,-59.53887324131449 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark03(174.30249348716552,-53.35117632395848 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark03(174.3877594502921,15.826168183718615 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark03(-17.446816990616583,0.09952842874295617 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark03(-17.515181290722253,-38.08970014026919 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark03(-17.544813569730564,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark03(175.9057751554297,0.5598479367264789 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark03(-175.92833777598528,-158.71292900628757 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark03(-175.92917445684967,10.995574175935825 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark03(1.763309912814016,-1.5707963267948968 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark03(17.646862415304312,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark03(-1.7668929105647493,86.27367825767459 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark03(-177.22505257185327,78.13614303662345 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark03(-177.39145253246465,-43.395152180066944 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark03(-1.7754001364006888,-97.59397607088938 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,0.5707537116049785 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,23.345734493305255 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,31.935080423835103 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,36.76841329495241 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,-37.008706010905186 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark03(-1.7763568394002505E-15,-4.712389138297449 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark03(1.7763568394002505E-15,-63.36361308816777 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark03(-1.7791069007685897E-5,28.415325882218355 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark03(-1.7879772420726443,1.570796326794897 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark03(-179.06198789165538,-1.5707963267948295 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark03(179.6997636925032,-59.31614272975592 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark03(-17.97871694674697,-98.54007929052015 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark03(1.8000934125004306,0.1780854728728159 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark03(180.97983338740016,71.93517937639241 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark03(-18.12528477348917,0.18078682239188545 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark03(18.143604079519605,-91.09792624096585 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark03(-181.86377602880611,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark03(-182.21225882064127,-67.54424205217335 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark03(-18.241297622989208,0.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark03(18.328152929801874,6.4348696152411815 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark03(-18.33841406612126,-168.64608716941038 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark03(-18.377472929416736,-34.37162945334842 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark03(-1.8465676641310296,34.02929000052336 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark03(-18.50951805252407,-10.733776992169027 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark03(18.53216965588038,-42.80070596957056 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark03(-18.533965522568835,-34.69318567435373 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark03(18.564262770298726,96.5234303149862 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark03(186.8903672653858,-3.1759882767966823 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark03(18.69905563277159,68.48470368995466 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark03(18.76369690812649,-38.54674944382468 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark03(-1.88079096131566E-37,-1.5707963267948966 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark03(-1.8827660172681533,1.5707963267948972 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark03(188.49444656635887,73.82742961107958 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark03(188.4948369143709,45.55309346840668 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark03(-18.849554785040226,14.137177757381782 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark03(18.849555900000624,-10.996064811212113 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark03(-18.849555916759677,-10.995570670610512 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark03(-18.849555920934623,-171.2170450375405 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark03(-18.84955592153863,1.5707963267948966 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark03(18.849555921538652,1.570796326795004 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark03(18.849555921539277,1.5707963267943783 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark03(18.849555981143407,-1.5707963267948966 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark03(-18.8498000648867,61.2630169462923 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark03(-188.49962210643992,26.703537555513233 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark03(18.862796196678715,4.7825445184096935 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark03(-18.87551481799703,-21.991148575128552 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark03(-18.88399590821432,-1.6052363134704528 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark03(-18.899556518970538,-17.228758997312084 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark03(-18.92312794787304,6.246429047625455 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark03(-18.924365481904744,-100.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark03(18.97084400192511,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark03(-19.03509795977174,-66.99294912224943 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark03(-19.112203591233918,52.45015762594281 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark03(1.9117483667327089,0.3409520399378124 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark03(-19.148739907552358,8.153165619988082 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark03(-191.63229188471274,1.5707963267948966 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark03(19.234590171985033,-0.5330790013356156 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark03(-19.244570458786693,21.06925608894865 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark03(-19.258592234389422,53.70225457646457 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark03(1.9259299443872359E-34,32.986723816367146 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark03(19.29031153541555,1.5707963267948966 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark03(-19.337445806468423,33.43433176590348 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark03(-19.400600970596837,0.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark03(19.420842741805348,-23.951126720984746 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark03(-19.429384993949757,1.5707963267948966 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark03(19.44424200716442,0.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark03(19.464300543375085,-5.327133602221015 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark03(194.77835810984166,-39.26990816987225 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark03(-194.77874452254534,-1.5707963267948966 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark03(-19.5160925022001,45.26760900432333 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark03(-19.583687403194233,2.858397264079598 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark03(19.59056372148198,-82.62374778121088 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark03(-19.590916532078168,0.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark03(-19.591842656544443,0.5380108699700656 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark03(-19.613068647593934,-0.47238118951413127 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark03(-19.6681142901897,96.63713430313963 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark03(-19.698414240563267,-18.919776970716455 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark03(1.9721522630525295E-31,-1.5707963267948977 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark03(19.7593931564122,105.25721399540073 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark03(19.761361806550966,-57.49012034452057 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark03(-19.76903968802522,9.160900588542688 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark03(-197.7367324259497,32.93804456355399 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark03(19.852134047965265,-38.788046816507816 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark03(19.8818507822142,43.51445122994224 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark03(-19.936153695373434,1.57079632679548 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark03(-199.48507361745675,76.41756081732532 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark03(199.66796329314212,-33.58866941839483 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark03(-19.99058805362876,-2.711828458884896 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark03(20.057369995634858,2661.398476802604 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark03(-2.009245104041284,1.5155386728758196 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark03(-201.06192983077565,1.5707963042900557 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark03(-20.14466152423745,-4.7915928900289366E-4 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark03(20.23068420514403,-98.98568213169179 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark03(20.27450822402427,1.4403066368341162 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark03(-203.19232430521456,2.5137136970273413 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark03(20.368517647214574,81.9934911862212 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark03(203.97459913260258,36.139861325166294 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark03(-20.403669783577087,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark03(20.411989521938985,14.429753595649643 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark03(20.42234823431231,1.5707963267948968 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark03(20.436729475044444,-2534.0243341111122 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark03(20.480630721265374,-6.343463780111305 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark03(20.48724127073652,39.63032882955113 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark03(-20.53799433055397,90.55478930123101 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark03(-20.544995305535387,-29.021337455777562 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark03(20.549176734777983,-48.77509959632299 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark03(-20.5548963790404,0.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark03(-20.578883532437388,-3.3001239376935256 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark03(-20.585632662440236,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark03(20.602152078603837,43.82572393301069 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark03(20.62697345461298,-1.5707963267948963 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark03(-20.63726715991992,-1.5707963267948966 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark03(-20.64718425286361,-0.22669135506841864 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark03(20.664728290778537,-1.5707963267948912 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark03(20.665756709549033,14.42920904899372 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark03(20.675072030019198,61.65483420508812 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark03(20.68594013737775,-53.34806413439275 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark03(-20.713067683739,-157.14573262272012 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark03(20.76625519893362,-0.09598457846738141 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark03(20.78247376863081,-213.3570004554745 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark03(20.806762831043716,-45.455658907305235 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark03(-20.82994201574593,-36.128315516283806 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark03(-20.830566297275325,-1.5707963267948974 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark03(-20.85103678277478,-1.5707963267948968 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark03(-20.896146974516952,1.5707963267948963 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark03(-20.93447115128066,21.66041690226139 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark03(20.94160602999108,-1.5707963267948966 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark03(-20.943343349777564,0.0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark03(20.953970717916256,-61.35070631185378 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark03(20.96273758306,-81.13902365860828 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark03(21.025413008338575,-1.570796326794897 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark03(-210.4866734992029,1.5707963267948968 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark03(210.48670780057608,0.0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark03(-2.109450434890421,-0.5707822421896861 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark03(21.16440069837362,1.5707963267948966 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark03(2.1263595840854324,0.0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark03(21.265005800632437,-80.64328344770175 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark03(-21.376478976922265,-1.5707963267948966 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark03(-21.42148609751468,0.0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark03(-21.44319091635539,54.74624764197321 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark03(-21.53634206034205,-28.421074687055217 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark03(-21.556729057849736,89.26961612421223 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark03(-21.590465630520352,-1.5707963267948966 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark03(-21.678437809655904,-44.91704417630741 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark03(-21.718071884687838,6.270248641919821 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark03(-21.776158873851756,0.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark03(21.789787310303765,1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark03(-21.85777017731887,-9.677971990499774 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark03(-21.86190723960297,-32.898860398701274 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark03(21.876450966594692,1.5707963267948966 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark03(2.1895288505075267E-47,1.5707963267948977 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark03(21.904295723114146,-100.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark03(-21.910433109113825,90.54152817663089 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark03(21.960598624061674,-96.01960674522418 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark03(21.976508827117367,-10.910788652262298 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark03(-21.991147635858656,-1.5707955307667951 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148495562534,-1.570796325422157 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148575007887,-39.26990816104253 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857510524,17.278759588972026 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark03(21.991148575118352,1.570796326794908 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512823,1.570796326794893 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512849,0.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857512855,1.5707963267948966 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark03(21.99114857512855,61.26105674499817 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark03(-21.99114857682338,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark03(-21.991148590030825,-1.5707963267948983 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark03(21.99132413141492,-0.5696734448298512 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark03(21.991393101859405,1.570796010110563 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark03(22.078720222848887,82.98538437077389 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark03(-22.089790696099172,12.577385556706133 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark03(-22.106459972888928,31.715155489277933 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,1.5707963267949054 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,2541.9289022901653 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-36.26586243332015 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-39.25657633651599 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,-45.577074489228345 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark03(2.220446049250313E-16,67.12554742157059 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark03(-2.221567368385209,-124.01245031564314 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark03(-22.233112276380098,-23.267008777565664 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark03(-22.245042972117844,21.882534378703188 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark03(-22.275822543486612,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark03(2.228805608138435,1.5707963267949108 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark03(-22.331825229185096,-23.84593420622471 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark03(22.334135437258936,96.13089856713599 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark03(-22.349100142491736,74.22922043262312 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark03(-22.35353483973506,158.3659066914674 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark03(22.374012933885297,1.5707963267948966 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark03(-22.38954711285534,2.8407195424504863 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark03(-22.412286261938423,-2603.8564804120347 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark03(-22.418046388494542,53.62483145678411 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark03(22.418530413974764,-30.165916085214654 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark03(22.433916700906945,1.5707963267948966 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark03(-22.47572560857465,2553.496385789744 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark03(-22.50857503970252,1.5707963267948966 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark03(22.53156709137408,50.13557511450516 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark03(-22.534829366038736,-1.5707963267948966 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark03(-22.652712514042506,-2632.484807433837 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark03(-22.765568915283133,-56.369867735490864 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark03(-23.00542868116544,-174.83515949135182 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark03(-23.08925310191726,-0.0037114281991311227 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark03(23.1194404190271,-47.42287268121778 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark03(23.2042858922202,33.05765575555551 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark03(-23.22928199937138,45.92507891951257 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark03(23.274489195676935,75.77127299786747 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark03(-23.279725105899857,-14.429210473374624 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark03(23.330136986174725,97.10515761013744 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark03(-23.354016352634602,14.430118752127896 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark03(-23.474176540422903,0.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark03(-23.478932711193096,99.52127489098315 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark03(-23.552256480374318,87.95490587896508 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark03(23.57696113241659,97.16652503467193 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark03(-23.783205526500495,-100.75222553945044 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark03(23.784392550596465,-1.5707963267948966 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark03(-23.950759271790275,28.504516763399824 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark03(24.065828074391433,-11.221148702544312 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark03(2.4074124304840448E-35,1.5707963267950105 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark03(24.110419323505,1.5707963267949872 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark03(-24.314685295717474,-62.3644857407669 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark03(-24.331168725184153,1.5707963267948966 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark03(-24.43141875977473,54.24560469611355 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark03(24.468954343579313,1.5707963267948983 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark03(24.627779789236442,8.970652581281485 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark03(-2.463413969838342,-61.767630720300915 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark03(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark03(24.824690290808633,-28.565823715052233 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark03(24.9145415363921,-40.0635166118728 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark03(24.963523643349465,1.5707963267948968 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark03(24.977747203007183,1.1348182620061378 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark03(25.005551221267154,2.8692837222271663 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark03(-25.129878682982124,-4.715251526126074 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark03(25.13274007476233,20.420352248333646 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark03(25.132741228718338,-1.5707963267948963 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark03(25.132741228733764,-1.5707963267794562 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark03(-25.132741364996168,0.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark03(25.132741753377836,-4.712387731260543 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark03(25.13274316000446,39.26990816996833 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark03(25.16630950509643,-33.83026300906744 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark03(25.168285257519294,-77.48003589700853 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark03(-25.19524122871841,0.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark03(25.283947775685157,17.437670923444834 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark03(-2.531001688378109,0.5244172404980644 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark03(-25.31346857127697,-37.07992136534681 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark03(-2.5356708505710657,1.5707963267948966 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark03(-25.363316565334173,-136.4574792850562 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark03(-25.39313146514253,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark03(-25.462770052779774,74.08600493892152 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark03(25.48600559000775,0.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark03(25.50966838851247,179.58897444943116 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark03(25.517567992077712,36.51314227964199 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark03(-25.561258228728718,-1.3865378398552792 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark03(25.568387597200612,47.788921872207396 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark03(-25.57364044729224,78.9211791627655 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark03(25.620152049251306,56.571059568691425 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark03(-25.651877463710022,0.0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark03(-25.67557042755307,44.26314703927983 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark03(-25.73455558095897,1.5707963267948966 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark03(25.75514124324873,27.825342117311266 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark03(25.8056577925544,-95.94879242653151 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark03(2.582656011228069E-7,45.224733795436684 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark03(-25.855818006017486,1.5707963267950023 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark03(25.900779864055252,33.76968124259872 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark03(-25.907630397683945,-1.5707963267948966 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark03(25.96585443580635,0.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark03(26.00851083532302,-4.712394596229842 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark03(-26.07110342575355,-44.48838693240611 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark03(26.088705746352563,-31.85959078470775 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark03(-26.10659163762843,1.5707963267948966 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark03(-26.10743557729272,0.0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark03(26.17257264063986,-100.0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark03(-26.190460690991543,171.9108899615248 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark03(26.204113125002667,0.4994244305105752 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark03(-26.20625226209483,1.5707963267948966 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark03(26.282527363532594,0.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark03(26.296330055187607,-62.472576643279666 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark03(26.298828883258082,89.88938389550137 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark03(26.300625083652406,63.63532539738233 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark03(-2631.273022538185,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark03(-2.6342668544412153,44.39783106071066 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark03(-2.64828503808525,39.979883113269466 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark03(-26.487159538653863,-1.5707963267948948 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark03(26.502866904268018,-27.085942495000353 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark03(26.63689753132397,-62.71926108091299 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark03(26.703537555514004,0.0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark03(26.722884953656603,75.89096356476611 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark03(-26.729147394352385,33.49367516015329 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark03(-26.757482773904748,1.5707963267948968 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark03(-26.79340510649591,-23.012486585740923 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark03(26.79548244738028,-74.02979403898809 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark03(-26.798140222523756,0.5711082289950775 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark03(26.812387571617286,0.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark03(-26.822988222152798,0.08300304326841845 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark03(26.839957382681142,2.018214289331692E-6 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark03(26.854937682159097,33.36331050828923 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark03(26.888932433458216,7.371025475090537 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark03(-26.913812760213858,43.930480514805964 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark03(-26.93510196398212,-15.664299177204725 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark03(26.9847975862685,32.3200898627139 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark03(270.12297946442425,-1.6247885653012661 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark03(27.022433394624684,77.96729017837177 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark03(-27.025196475102998,-33.920207048610365 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark03(27.030274759158672,-76.77014195321411 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark03(27.03962485561669,1.570796326794897 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark03(27.06270635487253,0.0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark03(-27.069639004656466,60.056361867349295 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark03(-27.091336358527997,88.77983442975116 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark03(-2.710505431213761E-20,-80.11085680716474 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark03(-27.110605298153857,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark03(27.1322381762701,-0.5181892608192958 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark03(27.13882832450487,53.69910504238043 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark03(-27.13919580559549,87.15966379885009 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark03(-27.151404847724887,-1.5707963267948966 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark03(27.157314482672117,29.179106026496072 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark03(2719.4353847855496,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark03(-2731.130519993752,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark03(27.31819064544419,12.566370614359172 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark03(27.367294439357618,1.5707963267948966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark03(2737.8315395862614,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark03(27.404552942560684,53.41676668049175 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark03(-27.40770890110217,-96.68520091569467 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark03(-27.44680249893463,-0.9420076699316482 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark03(27.54218845430539,-69.9744852498912 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark03(27.683564828354534,-1.493863576470282 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark03(-27.687077594557433,2.5707963267949077 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark03(-27.708943253179818,80.11061404156801 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark03(27.727182188891724,63.464465935757616 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark03(27.75377338055698,0.018352202446146278 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark03(-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark03(-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark03(-2.7755575615628914E-17,-1.5707963267948968 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark03(27.786151482714484,1.5707963267948966 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark03(-27.796040148788045,0.010318066762323113 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark03(27.798315905597377,-86.39379955073116 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark03(-27.799778711943958,-0.4517482630446139 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark03(27.80420160749475,72.93881252353802 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark03(27.849932335139798,43.664553845111314 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark03(-27.85823825366262,1.5707963267948968 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark03(-27.87018507984527,-29.823250237496765 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark03(27.876443570622527,36.935661144958885 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark03(27.949106777985325,-136.51169180786178 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark03(-27.949999439987295,-1.5707963267948966 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark03(-27.964158718629733,-1.5707963267948966 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark03(-27.965394185480193,-17.00429889525725 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark03(-27.980358615190227,141.5588294096135 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark03(-27.99546661830862,101.86946578716817 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark03(27.995648677268818,-35.29113654960821 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark03(-28.0335058591815,-10.68867985266007 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark03(-28.034921253280764,4.146093312271279 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark03(28.04179324504122,-44.73555128317423 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark03(-28.048034879856242,13.90292913760774 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark03(-28.048861114623275,12.0894361275261 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark03(-28.05968048805579,-78.90776371547038 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark03(-28.08489026132071,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark03(-28.09208172806577,-13.667843220180302 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark03(28.098276154081027,-1.5707963267948966 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark03(28.135429603042038,20.281447969067553 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark03(28.141352317834418,-11.448111862001937 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark03(28.147396895634877,-1.5707963267948963 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark03(-28.16366720671945,-1.6814811816779343 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark03(-28.169944190764888,-84.47135392369056 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark03(28.17169569466004,29.407401513794582 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark03(28.2352187964708,1.5707963267949832 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark03(28.242530646257286,-1.5707963267949054 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark03(-28.272506287867994,8.1048903175445 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark03(-28.27408525158941,1.570796326781363 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433278108739,-23.569757402526335 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark03(28.274333879237698,4.7123889698904105 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333881886104,158.6504290060148 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882078704,48.6946861306419 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark03(28.27433388230813,-1.5707963267948868 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark03(-28.274333882308134,0.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark03(-28.27433388230837,1.5707963267948966 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark03(28.274333882540972,-1.5707963267948966 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark03(28.27433388715713,-1.5707963267948966 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark03(28.2743338920515,-1.5707960981804685 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark03(28.27433389720931,-1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark03(28.286255851008036,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark03(-28.288400291083462,-1.5707963267948968 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark03(28.355113390386663,-5.111568213025553 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark03(28.480981201261244,69.2764587031831 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark03(-28.490213257272814,-55.71423498238431 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark03(-28.494592516494137,-85.78744493930705 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark03(28.513294380409825,0.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark03(-28.51467302839929,49.37046334825938 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark03(-28.546776333127525,-45.94049959809118 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark03(28.549836242844464,-2700.481397743977 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark03(28.642853008786915,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark03(28.70424844729044,-17.051442292008247 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark03(28.704360261009214,81.72205468281618 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark03(-28.711465705308314,14.899789616814289 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark03(-28.73821940517595,1.5707963267948963 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark03(2.8762380691620137,68.16469472402225 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark03(-28.78730270416733,-0.27265679801311027 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark03(28.827981971632852,-9.954772825861195 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark03(28.948570737554434,-48.43583291855411 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark03(28.957321105234826,-1.5707963267948966 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark03(28.97381140004603,79.34405432563108 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark03(-28.99220673053435,-52.129733783018416 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark03(29.007353077894972,88.2392880036393 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark03(29.017162767112495,0.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark03(2.9131309670887617,18.664161530978234 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark03(29.180987842188607,0.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark03(29.206922608352585,0.0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark03(-29.213497119524035,59.69026041820607 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark03(29.234636984737847,0.0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark03(-29.254134220823616,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark03(29.34612588709804,40.37295865458316 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark03(29.363750249406586,0.16021537033146954 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark03(29.394167453467645,33.615166698588354 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark03(-29.467110479602574,0.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark03(29.546478524717855,-1.5707963267949054 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark03(29.636102754968412,-36.15506038179033 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark03(2.9721414274330016,-55.23724724280005 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark03(2.9794977966940905,-73.55697964555537 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark03(29.80210569841636,35.77670126827965 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark03(-2.9808808632258064,1.5707963267948966 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark03(-29.813213225674982,90.70390036905803 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark03(-29.845130209099263,1.5646525260377987E-12 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark03(-29.848595346528842,14.429204371111886 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark03(29.954995109769698,8.48374785581828 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark03(-29.998590863295703,-1.5707963267948966 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark03(30.009071279061384,-136.5412341383905 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark03(-30.00970142733871,-6.4477565254152625 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark03(3.009265538105056E-36,-17.2787595184378 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark03(-3.009265538105056E-36,-32.986722862599116 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark03(30.177285833165598,-2632.0015258917015 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark03(30.31761839554875,-116.40364754064063 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark03(30.33896629043707,-43.15641209874764 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark03(30.358876024220052,30.315909147227757 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark03(-30.399312259739133,96.38418039520582 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark03(-30.406832701561864,-1.5707963267948966 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark03(-30.53991745642663,6.447735804682229 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark03(-3.0586377879667843,2.070796326794897 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark03(-30.600308764677337,-47.49841294284634 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark03(-30.72031034197833,56.018014470070256 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark03(-30.738261269885683,44.327961073546305 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark03(30.754154949978428,0.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark03(-3.0814879110195774E-33,-45.553093477051995 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark03(3.0814879110195774E-33,67.54424205218054 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark03(-30.831620458163528,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark03(-30.9883488254506,1.5707963267948966 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark03(31.014300126669614,67.14261564295224 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark03(31.088234969542953,58.007060676259464 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark03(-31.166046589276064,27.83611106801223 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark03(31.303015495516107,-64.73552697979707 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark03(-31.387288095671664,97.46358160837909 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark03(-3.1414659365979603E-20,98.96407483807904 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark03(3.141592653584589,-10.995574287528253 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark03(31.41592653587464,-14.137166941149443 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark03(31.415926535897928,-1.5707963267948966 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark03(3.141592653589809,-1.5707963267949123 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark03(31.41592655346078,67.54424158273724 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark03(3.14166467641536,120.95131728444397 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark03(-3.1416883273239224,32.990629227080504 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark03(3.141917920204574,1.5707963267949054 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark03(3.1420809348397944,-64.40230552296924 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark03(-3.1436439538946437,-1.5707963267948966 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark03(-31.447176535897935,1.5707963267948957 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark03(-31.44717653589794,-1.5707963267948966 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark03(3.146325974556674,-0.28970665200876644 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark03(-31.485732481332974,15.730068363287884 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark03(31.49536626950552,50.642762579213496 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark03(-31.572073942710908,-75.72492995667352 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark03(-3.1596979427685588,42.429606110911344 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark03(-31.652171780843986,-14.424538657477967 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark03(-31.67244126029689,8.110496358373439 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark03(-3.1682272616748066,-76.94238543683129 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark03(-31.713376081568338,-4.2117739246991745E-15 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark03(-3.1745464455782204,55.00752834705185 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark03(-3.177453079661892,45.51723305098013 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark03(31.803168415783176,80.45593032210678 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark03(3.1848386159068784,-86.35055201140223 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark03(3.18620067739775,24.631535564123404 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark03(31.87280310612988,0.07651892106251665 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark03(31.94892482443249,-31.86085545511115 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark03(-32.06729049814426,0.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark03(-32.14768599734117,1.5707963267948966 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark03(32.156551015859435,-64.62791089629698 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark03(-3.218136267413634E-13,-117.81063944299437 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark03(32.19174176590562,-73.64166313067017 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark03(32.3212216285323,49.66070405004655 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark03(-3.233670127575884E-19,-58.11946409141116 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark03(32.344163767184455,-38.68067659176837 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark03(-3.236232830694769,1.5707963267948966 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark03(-32.3683532693408,48.40468454458591 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark03(32.410233345948114,11.047505569146821 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark03(-32.483404121184044,-14.435222796426764 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark03(32.505820467911406,-39.963863516660595 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark03(32.532033595198584,-1.5707963267948966 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark03(32.56637945462286,0.0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark03(-3.2572809962922253,-61.56019577258562 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark03(32.58425910529928,1.5707963267949339 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark03(32.5938228160147,-72.56042317816485 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark03(3.2628951765046246,99.199910062609 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark03(3.2665926535901018,124.05575868276073 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark03(3.2665926536532472,-4.711918329600693 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark03(32.667133470710986,1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark03(-3.2670020640794566,32.98672280553806 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark03(-32.6973702326752,27.797577233047832 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark03(32.73982881245392,-0.2468940502389068 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark03(-32.77558777203276,0.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark03(32.84365632091459,-1.5707963267948983 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark03(-32.84802093824652,-0.19810561141247807 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark03(-32.881925706276945,1.5707963267948966 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark03(32.88623955573725,0.01638765876739778 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark03(32.896899867904516,-1.5707963267948966 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark03(-32.89836469515583,-94.44396384904493 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark03(-32.931265600212825,-4.782762580626777 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark03(-32.97124595871952,1.5707963267948966 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark03(32.986722862692275,7.771561174958844E-16 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark03(3.3001785723004833,0.0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark03(-33.111878002638456,-54.197002625777046 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark03(-33.11916284673811,89.87257276503934 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark03(-3.314360501257937,-16.69595841330016 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark03(-3.3263652556309964,17.463456712767304 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark03(-33.41264360681021,1.5707963267948966 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark03(-33.4806257890596,-66.46734865175243 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark03(-33.531040774267524,-74.83374529115567 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark03(33.72163969495176,53.70355914091507 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark03(-33.865949259946746,1.5707963267948948 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark03(-33.88481500486735,0.041101080416861266 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark03(-33.942574814618,-39.50505421577163 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark03(-3.4015939494675544,-13.877165645276309 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark03(34.332668657191164,-84.7019001841123 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark03(-34.35756959277849,0.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark03(-3.4372012244717354,-7.501017429552846 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark03(-3.440909744791796,-2603.63466504452 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark03(34.42086948449921,30.41442324118117 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark03(-34.44439288242636,-2693.3850199115645 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark03(34.541264602213374,42.79151588640423 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark03(-34.55751918750799,1.5707963267948966 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark03(34.55751918825254,-45.553337617677 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark03(-34.55751919693831,-1.5707963267948968 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark03(34.55752160275397,0.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark03(34.55754632053243,39.269464237466615 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark03(-34.55849575198778,-1.5707963267948966 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark03(-34.55849595102826,67.5442161392236 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark03(-34.58156352795761,-4.736433318854577 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark03(-34.58935810381493,-1.0409161459692164 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark03(-34.65813783034557,0.08896301026021886 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark03(-34.66845244041525,67.1122910768134 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark03(34.67432235125575,-44.46170173887394 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark03(34.679681742287926,0.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark03(-34.68251918965447,133.517689484404 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark03(3.469446951953614E-18,1.5707965293574837 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark03(-34.703038609699675,36.90368619603315 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark03(34.72387513314894,-83.99184313437954 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark03(34.782671432304056,-100.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark03(34.78342076844847,0.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark03(34.79466304601104,1.5707963267949054 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark03(-34.80412112957612,1.5707963267948974 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark03(34.80498126862432,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark03(34.842967680936766,8.853981636139872 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark03(-34.87143945467328,-56.51456266063837 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark03(-34.9751493021746,-35.61904709802528 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark03(35.018277775030484,-2.0707963267949303 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark03(-35.0418970471281,88.1976440716376 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark03(-35.0456266171598,60.37014606895703 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark03(3.504726760006627,-65.02575005291301 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark03(-35.076598934369656,35.634485121303726 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark03(-35.10663152779749,0.0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark03(-3.5145483165433973,-39.21185244543989 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark03(-35.16089868217389,-10.4875139916998 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark03(35.17473354817329,20.22766168938847 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark03(3.5193506804355246,0.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark03(-35.194465756228354,-20.202375101679834 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark03(-35.203327046053914,11.23763720784072 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark03(-35.22167707049758,1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark03(-35.2253102749454,-44.0462064147048 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark03(35.23504982827063,1.5707963267948966 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark03(35.25335890174449,1.570796326799794 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark03(35.2649281158767,100.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark03(35.26788628245839,-5.53080329980493 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark03(-35.34203817977975,1.5707963267948974 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark03(35.39150494844773,-65.05912141549122 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark03(3.540245093576978,-52.61497103368249 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark03(35.44407371536485,-40.996616376896576 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark03(35.46388642107782,-0.8145442303718896 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark03(3.552713678800501E-15,-23.89483984749199 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark03(-3.5563522790044897,20.005592622918968 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark03(35.59126409460868,65.59025702962111 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark03(35.622908243732866,-0.07944488414636386 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark03(35.65294666880402,28.505201858090032 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark03(-35.65435607860307,-2.18871851019788 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark03(3.5681010326789773,-71.11234308485953 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark03(35.919182946606846,1.467185662564179 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark03(-3.5938205657967774,43.53477587489824 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark03(35.963321202670045,-10.480022413799633 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark03(-35.96707532682308,34.68668059404527 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark03(35.97809161110261,-0.14886270587332703 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark03(-35.99515429404123,1.5707963267948963 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark03(36.01628090291265,-76.73127319536921 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark03(-36.044353381662674,1.5707963267948966 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark03(-36.08511984941316,44.02549281712657 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark03(-36.08952279445996,-0.4624668705819677 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark03(-36.120120555183235,44.39973956047582 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark03(36.1326347730096,-97.39369151801054 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark03(-36.16967314265386,0.0413576263712393 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark03(36.230321962983766,34.38166586905379 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark03(-36.502755405992964,0.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark03(3.6504995373879154,-42.5936740686105 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark03(3.659827350358782,8.308390541127915 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark03(36.65112388022578,-32.732697365251795 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark03(-36.68009044756437,73.83135851106559 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark03(36.69789480408852,-2659.1251634110895 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark03(3.670940360917669,-32.53705077344847 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark03(-36.71367640752479,91.23982691659478 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark03(-36.81432516688976,-56.39501748514648 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark03(36.867307474522505,-65.64306872550176 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark03(-36.904311939211425,9.777340495707023 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark03(-3.6958963619558887,0.0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark03(-37.102674618450614,-37.82443841961384 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark03(-37.212251197528396,-21.34728483677972 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark03(37.25160620763106,-2.018301962241352 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark03(-37.353716577008065,0.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark03(-3.738960918128942,-23.725296659213882 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark03(37.394417214496656,93.53415136325484 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark03(37.555536373787035,1.5707963267948966 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark03(37.61072633487345,36.4318803942451 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark03(-37.63562290621876,-46.26700505201615 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark03(37.64973024464038,-1.5707963267948966 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark03(37.651868850174374,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark03(-37.66786248164244,-4.743638980384691 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark03(3.7698583025321266,-9.038583200749299 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark03(-37.69911184307751,-1.5707963267948977 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark03(-37.699111843077524,1.5707963267948966 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark03(-37.6991118471911,-32.98672285282993 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark03(-37.699172878233774,-1.5707963267948957 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark03(-37.699172878233774,1.5707963267948966 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark03(37.70152386598785,4.7436389803846915 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark03(-3.770803023579859,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark03(-37.714736843077524,1.5707963267948961 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark03(37.7164748109376,0.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark03(-37.74944035002174,3.280878611280528 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark03(-3.77928778037311,1.570796326794904 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark03(37.79633763036063,1.5707963267948966 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark03(37.81615505971318,39.033697760999274 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark03(-37.92188064429498,-36.33400368580737 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark03(37.960814199518026,-42.673203179902714 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark03(-38.03206751037655,-107.05707735237971 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark03(-38.11245760545523,-1.7449038042531486 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark03(38.12203100771794,-100.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark03(-38.27900859906578,-100.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark03(38.3360330613196,81.51255929121393 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark03(38.3660491477077,-80.11061269098019 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark03(-38.37323411907,-2.7633015732720904E-15 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark03(-38.379256339424394,-0.18102758627942622 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark03(-38.38872928259538,4.740820964054781 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark03(-38.40647179990192,-32.87444381509073 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark03(38.46037340254723,0.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark03(-38.48259882991767,0.0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark03(38.501564625125354,-15.941766559658689 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark03(-3.8518598887744717E-34,-1.5707963267948963 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark03(38.59018496917235,-1.5707963267948983 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark03(-38.638613508625625,0.47925918143473273 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark03(-3.864528457077455,63.98807778998855 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark03(38.66746566192731,-18.286723940758776 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark03(-38.69752166951696,-1.5707963267948966 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark03(-38.7456768837598,5.080308181549912 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark03(38.75687033675831,13.880517004429018 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark03(3.8786688261150033,-61.015975286805535 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark03(-38.80135602656492,0.7718463885068578 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark03(3.8827878678586916E-27,-1.5707963267948966 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark03(3.8828481855396054E-8,-7.541644443740256 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark03(-38.865091790829275,-1.5707963267948966 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark03(-38.909283632441465,0.4638333091619305 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark03(38.926575567394394,-172.42053496002666 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark03(-38.972711308980855,-100.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark03(-38.99707726195034,83.64036052263262 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark03(39.03516355393755,50.030737841501825 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark03(39.03518014113068,0.37969519938295365 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark03(-39.06912645792542,0.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark03(39.188200111125354,-2608.090272598576 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark03(-3.9196031676385275,-14.430690022157016 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark03(-39.20048967081444,-1.57079632679487 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark03(39.2520646025462,-50.28332602476291 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark03(39.25535327429924,1.5707963267948966 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark03(39.25941188493084,1.5707963267948983 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark03(-3.944304526105059E-31,-80.11451923886989 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark03(39.48560873131226,-75.12340874928555 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark03(-39.526477668785745,54.97787434218231 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark03(39.80286320253941,0.0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark03(3.9953732088005296,1.5707963267948972 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark03(-40.02599653821088,62.61578624595455 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark03(40.0300634740003,96.1561282830067 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark03(40.0772141419979,1.0991665871943666 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark03(40.09447439990721,6.429204871176492 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark03(40.159178263547346,78.39143776019165 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark03(40.305724199013945,24.096925199576816 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark03(40.31025811227383,38.12760520533277 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark03(-40.31763487981082,1.52801527327472 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark03(-40.33140290350443,-45.65225566406011 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark03(-40.406619600579994,39.703993065959736 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark03(40.442223288587144,1.387207405606452 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark03(40.50810743157501,5.083571886697486 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark03(-40.51116673449269,0.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark03(-40.537906892465855,-3.2633992528017486 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark03(4.057191415931377,4.712417073779698 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark03(40.72343616606345,-1.5707963267948966 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark03(-40.75505148708088,-16.0814356859868 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark03(40.756557203491525,1.4866490336191094 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark03(-40.812652481251924,-39.98583059079812 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark03(40.8201347388639,64.25222880449988 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark03(-40.83975172187529,45.553093477051334 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark03(-40.840635106715496,67.5452186504134 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070435757616,95.81857182691543 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark03(-40.84070448155958,-193.20796418652372 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark03(40.840704495501924,4.712384303003283 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark03(40.84070449666687,-1.570796326794458 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark03(40.84070449666731,1.5707963267948966 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark03(40.8407045294787,-36.12831576672852 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark03(40.84091803461591,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark03(40.841851758148294,-10.98650741993805 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark03(40.84584464560837,1.5707962871148842 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark03(-4.085531971414284,16.23399814014489 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark03(-40.859128093378594,2627.017613401408 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark03(40.871954496667314,1.5707963267948966 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark03(-40.885679593072936,-1.5258212303892724 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark03(-40.95775091410297,58.52376155401146 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark03(-40.958255970471654,0.0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark03(-40.9807361384295,45.68884289333007 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark03(41.0006303676721,0.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark03(41.02949861124566,-1.5707963267948966 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark03(-41.05296308537939,-0.03518705527300148 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark03(41.06287290905367,45.37198200513663 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark03(-41.280250720980334,45.52737500863222 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark03(41.28441589314477,-1.5707963267948966 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark03(-41.32332954656498,-100.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark03(41.33720881030805,1.5707963267948966 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark03(-4.141592653584829,-93.6769832810192 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark03(-4.141592653589798,-38.94486019129059 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark03(4.141592653606805,115.19440671596473 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark03(-4.1415926536360805,63.42233233722827 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark03(4.141592654810924,-196.70113955943597 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark03(-4.141592667607018,-126.50317397596186 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark03(4.1416175433671505,248.9339896704001 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark03(4.145456470158865,10.929253857570218 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark03(-41.468717065849404,66.44324561955196 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark03(-41.573462873552415,-23.56800026561627 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark03(41.60489437105183,-1.5707963267949054 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark03(41.661876340381866,57.21806440675232 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark03(41.66816825396688,54.45506185988228 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark03(41.684101304607694,-0.17516683426757834 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark03(41.6844878308392,-68.09422628931492 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark03(41.68552395063648,1.5707963267949128 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark03(41.71152232184457,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark03(41.73391169021099,-2592.123742633284 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark03(41.851939912171446,0.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark03(41.89317071900527,6.021025748893692 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark03(-41.899236143576786,-1.5707963267948966 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark03(41.91318640050136,-80.11061266653972 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark03(41.92331121332357,-90.61799734396537 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark03(-41.96032941951891,35.750271445799086 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark03(42.123047111157774,-95.6026387913573 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark03(-42.14052018671256,0.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark03(42.19061271594714,-22.96461655032296 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark03(42.282628278565795,64.02853985283753 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark03(42.29610530590028,48.693886485042995 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark03(4.232700041978161,-67.54404915866165 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark03(42.402316903400184,-3.15077657365182 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark03(-42.41150082342657,1.9342306451535882E-56 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark03(-42.411500823461516,1.7922010705925161E-12 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark03(-42.41295266746346,-95.61491186488993 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark03(-42.49500594244449,1.5707963267948966 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark03(42.50197527801282,65.11738063809474 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark03(42.54174681116697,-24.77473593547191 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark03(-42.54223118921756,-80.11061266653991 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark03(-42.56501376924412,1.5707963267948968 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark03(42.56893491943492,-78.0224428685549 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark03(-42.581119473944554,1.5707963267948983 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark03(-42.58195074310741,1.5707963267948966 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark03(42.582566882382054,-9.62113282920025 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark03(-42.584860799092674,-1.5707963267948966 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark03(42.586068212623346,2.9670252644286563 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark03(4.258728320152112,22.44480923536113 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark03(-42.59237196470933,-35.15280874086369 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark03(-42.60786168985653,-38.314623672853344 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark03(-4.260846579001364,-153.76554800772857 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark03(-42.626712678620365,-1.5707963267948966 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark03(-42.62741240154884,0.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark03(42.63909868530925,27.098672253655252 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark03(42.64047963645251,10.077483848184968 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark03(42.6478790737937,51.88935189557023 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark03(-42.6498528178238,88.2029462948758 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark03(-42.65021908164024,0.563240917980219 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark03(-42.661327445871414,-145.01580565731663 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark03(-42.67146734450444,0.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark03(-42.67169877284073,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark03(42.673865661460724,22.253513413127067 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark03(42.68181996819939,46.933633903382216 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark03(-42.69462143112861,14.87870093996034 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark03(-42.69730127256979,130.0712494974657 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark03(-42.69927422706743,-0.8607939826254454 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark03(42.71372535067296,1.5707963267948966 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark03(42.735014155998755,-86.90458651493284 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark03(-42.74348995671235,0.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark03(-42.74456460137346,1.5707963267948966 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark03(-42.777884306894606,0.0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark03(-42.78393070577243,-2563.2864566271223 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark03(-42.79028684076846,44.88971904164046 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark03(42.79724087265453,2532.489534115608 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark03(-42.84036228360673,7.515416110597461E-5 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark03(42.878629680987075,-0.5697829579403694 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark03(-42.885307765265324,-0.008814361689324928 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark03(-42.89487489118039,-0.00810943424148019 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark03(-42.90481651077874,47.55120539911546 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark03(-42.91306665506394,-1.5707963267948966 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark03(-42.916311111923825,-157.47000049276681 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark03(42.91737384126039,0.569385770244217 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark03(-42.92026261379596,8.459288759511818 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark03(42.92998191476413,100.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark03(-42.93744114346822,1.5707963267948966 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark03(-42.94328068742537,1.5707963267948963 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark03(-42.95575511878368,-37.25603995166553 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark03(-42.97960294971576,1.5707963267948972 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark03(4.309376831263546,27.661619340008173 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark03(-4.309646498413883,-123.26781600124897 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark03(-43.13304862032642,-95.44059350775356 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark03(-43.23094435054712,-80.86196546624971 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark03(-43.37054884770038,-0.25420600938108306 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark03(43.542276050480844,-1.779304362117715E-9 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark03(43.68157363241831,1.5707963267948966 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark03(-43.76481003843664,0.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark03(43.84533735722704,21.794323510050134 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark03(43.849430757920885,91.10004775125086 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark03(43.85413693874841,0.0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark03(43.87983531621904,1.6732581608329653 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark03(43.95982129186682,1.6332963267953857 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark03(-43.982264519904355,-42.4115008234622 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark03(43.98229715025274,0.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark03(43.9822971502571,1.5707963267948966 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark03(-43.98229715027166,-1.5707963267948966 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark03(-43.982304941494306,-1.570796300774974 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark03(43.98230494622921,67.54424205218037 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark03(-43.982304964400385,1.570796326434868 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark03(43.98278543155055,199.4904523176547 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark03(43.98302056739317,70.68584309235324 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark03(-43.98935778629966,-80.11062798692672 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark03(44.000756163414515,-1.5707963267948966 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark03(-44.04479715025711,0.0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark03(44.19915606223535,39.053049257894166 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark03(-44.207168018068344,-47.256767802094714 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark03(4.424317276728946,-31.732270790433503 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark03(44.25398282684871,0.7503984407661571 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark03(44.29821472824494,74.59176823778529 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark03(44.359823918848406,-16.539528876788083 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark03(-44.37754278229227,-31.513316279342206 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark03(-44.382753917120986,-60.91669142761668 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark03(-4.440892098500626E-16,-48.21160759774161 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark03(-44.41525150712124,-67.54475666076434 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark03(-44.58497912471951,0.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark03(-4.459088773631719,-226.45624960427114 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark03(-44.68511108327773,77.31682092693256 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark03(44.690300659542785,0.05116551807049758 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark03(-44.700307326084165,1.5707963267948966 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark03(44.72586590231958,-2624.262870783958 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark03(44.72774826373637,-64.40877696039607 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark03(-44.729409041588696,45.03705786861765 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark03(44.74007949074797,0.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark03(-44.922798421166945,0.0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark03(44.97651518721376,-1.5707963267948966 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark03(45.00648549440075,1.5707963267948966 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark03(45.030222281230294,0.5228711958217077 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark03(-45.03104662488724,64.30189651086914 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark03(45.03353280673908,-44.501857820570024 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark03(-45.105154238205536,-8.078541922900161 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark03(45.157479762914065,-1.5707963267948966 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark03(45.18198446777963,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark03(-45.196847319564085,0.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark03(45.23119787334856,49.06949933551619 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark03(45.350166172242155,-83.60993384702952 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark03(-45.367582255641665,61.2584462047763 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark03(45.3677359303524,1.5707963267948966 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark03(45.499499061634644,-84.71448226978356 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark03(-45.51544306221941,-61.49537023643419 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark03(-45.5426558336906,2573.656799327451 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark03(45.56690555680248,-36.19899481435858 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark03(45.639425210247964,-31.59514710298971 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark03(45.64312178118135,-0.2340731466701721 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark03(45.73544299714857,19.109757482666986 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark03(45.84606838070843,85.88107387963052 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark03(45.85927405530468,-7.291880808216915 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark03(-45.98662239632074,0.3794781634231473 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark03(46.2848166842152,-15.961389447224073 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark03(-46.351349856076965,0.0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark03(46.41682295339845,1.5707963267948966 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark03(46.50287512374277,53.16122746076462 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark03(-46.52791591878081,1.5707963267948966 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark03(46.58620032281417,-0.07128079857348053 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark03(4.660571263068007,95.73684032613278 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark03(-46.6568621070425,-2.058097345864185 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark03(-4.679912486614207,-41.78351409534169 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark03(-4.68192564377623,-68.86869537168076 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark03(46.83392110151888,-48.49458803827924 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark03(-46.83550985970422,32.83518907727062 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark03(46.88272105647323,66.43434140552048 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark03(-46.91654801448447,-92.71388540853592 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark03(-46.94440298707716,-18.155759238948534 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark03(-46.97414877425348,60.59250816718517 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark03(46.975338213414645,0.0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark03(47.02324819073098,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark03(-4.7110994529192975,99.45140455510636 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark03(-47.12388911861642,-32.986722862692815 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark03(47.123889576831196,67.54424083171656 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark03(-47.12388980129196,111.53052316385273 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark03(47.123889803845856,-10.99557428326022 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark03(47.12388980384693,1.5707963267948966 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark03(-47.12389075752122,1.5707963267948992 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark03(47.12395083977971,-1.2912355394513677E-30 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark03(47.124866366346964,0.0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark03(47.135675992156116,1.5825825151041144 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark03(-47.17690738063889,158.51717253178242 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark03(47.18720462177747,-48.69859884405623 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark03(-47.22406501982578,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark03(-47.25906708525909,13.269508339875813 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark03(-47.31540987551872,7.21883055466555 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark03(-47.33647154898004,1.5707963267948966 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark03(-47.363794834151406,0.024970581077072486 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark03(-47.37408889392513,-70.72476582489455 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark03(47.529667915177185,-33.595439347546446 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark03(-47.584228683861895,0.0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark03(-47.70207832254627,79.49309596457371 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark03(-47.73598908067979,-9.868873184657105 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark03(-4.7749513646214155,-11.982364844632897 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark03(4.775710697954556E-9,-130.37057568862582 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark03(-47.799257186961,3.4495701651384088 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark03(47.851466512345695,2589.5435970662757 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark03(47.87676051431151,-1.5717178806561167 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark03(48.069013108339476,0.0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark03(-48.09606110082065,-1.4917950760649417 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark03(-48.12994810171762,69.51040728412563 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark03(-48.14512283370719,-17.355449478661612 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark03(4.8148248609680896E-35,67.54424204973276 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark03(-48.17072608138174,0.0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark03(48.240163069526155,-1.2893230488532907 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark03(48.244054222027884,72.70726294117915 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark03(48.32975517485559,-64.99851569635761 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark03(-48.38651457138454,-32.70399890951087 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark03(-48.446061133798764,0.0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark03(48.48757884848595,-100.0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark03(-48.5039631035806,32.74890807084742 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark03(48.5342712470409,-95.43504685991711 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark03(48.55137494259895,-1.5707963267948966 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark03(48.593580408444126,166.27002962471045 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark03(48.6402186971008,0.021226682467003606 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark03(-48.675460795740705,0.523226830830745 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark03(-48.69468613064345,0.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark03(-48.69468613071093,6.888145012778556E-11 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark03(48.70305969622431,0.0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark03(-48.727934504419565,1.5707963267948974 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark03(48.728275965980075,88.34122203949238 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark03(48.72911959061006,38.671518871072806 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark03(48.732716220225825,0.0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark03(48.73809274081787,-83.20169297139506 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark03(-48.74985136858068,-13.38293877487844 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark03(48.79113292646076,161.79205151279072 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark03(48.794070979809845,-53.50645996019453 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark03(48.795338318952986,93.47496466463843 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark03(-48.80939211368553,142.9625350894818 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark03(48.810033094977314,-1.5707963267948966 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark03(48.813193117009455,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark03(-48.8176514458405,0.14918298513489106 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark03(48.907799944663395,-10.617432961775362 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark03(-48.92165410164176,94.3086858895058 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark03(48.997074380071155,1.5707963267948966 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark03(48.99754825141309,-78.36567009546691 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark03(49.03882584077106,1.5707963267948983 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark03(4.911633332264159,25.87122961065033 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark03(-49.22565104551518,100.0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark03(-49.328963772030576,2724.1617355348026 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark03(49.42161741718826,21.224249886722575 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark03(49.59756419157918,-24.307099913970802 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark03(49.632812023445894,-0.01964150370783987 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark03(-49.68525802577987,-39.251431842393814 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark03(49.697854554222744,10.594450864488689 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark03(-49.72272611110498,-0.5707527211327946 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark03(49.74131210133041,44.27855421140032 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark03(-49.74647892904998,-28.236573536020188 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark03(49.75013583139816,-9.43039580850477 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark03(-49.75523115015802,0.0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark03(-49.75840959326341,94.74097485753524 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark03(49.77015131608596,-97.90925317098552 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark03(49.772894214529906,0.0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark03(49.7823850559511,5.754876660663182 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark03(-49.80268900676242,-0.15424007687607313 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark03(-49.82033913803027,0.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark03(-49.82690232389801,2053.4853215620665 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark03(49.83539020904081,45.988016493170704 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark03(-49.841344840812596,-48.03352327502904 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark03(-49.85730311316707,-57.53785784915404 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark03(49.89756655183579,-130.00817921837552 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark03(49.90134347194264,-23.930211118590627 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark03(-49.902645800169196,-227.40263072799252 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark03(49.91566288474425,-3.541046567694721 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark03(49.95979527657192,-72.55736960078394 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark03(49.972206470307725,-56.67890665900415 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark03(49.97429780811798,0.0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark03(-49.98197635413162,-95.45529707859055 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark03(49.993504291763216,1.5707963267948966 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark03(49.996763409412374,-74.9243544278954 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark03(49.998467968544276,-86.35425558603005 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark03(-50.02282425240007,-1.3281381217582753 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark03(-50.02741043150045,6.283185307179585 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark03(50.032693549668295,-15.202167068923032 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark03(50.035369955321634,-0.8174973273004298 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark03(50.04717464597644,29.845130209103036 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark03(50.049820006052514,-92.74792388616318 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark03(-50.05061973103326,-82.44890784277233 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark03(-50.06416835293504,1.5686913041495287 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark03(-50.0711287506267,1.4921346213766613 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark03(50.07780950779431,-1.5707963267948966 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark03(50.078712691223515,1.5707963267948974 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark03(-50.08635129087769,5.519599704784881 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark03(50.086913030759526,-15.202219858637392 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark03(50.10414625415884,1.5707963267948912 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark03(-50.1106102062298,-0.44607045829792674 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark03(50.15377029730735,32.93997183798679 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark03(50.158339138758066,0.08218357098212681 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark03(-50.16203388969728,0.0029760703804234184 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark03(50.16566008707039,-6.097500056580358 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark03(-50.19896180624304,47.96444983154457 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark03(-50.21660422488949,31.424196306410145 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark03(50.219080402288725,1.6332963267948968 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark03(-50.2203235639233,118.62123614971318 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark03(50.22331458815098,10.953406418278561 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark03(50.22948587372262,-1.684644767171165 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark03(50.23526754533344,3.0179669433150615E-15 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark03(-50.23801620987193,-26.09291799397863 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark03(50.24915455510469,-53.923428222011644 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark03(-50.25926050996361,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark03(50.2646505560711,-1.5707282738443082 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark03(50.26503870685721,1.5707963256444795 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark03(-50.26545083235007,-161.791998367559 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark03(50.265458347971745,-1.5710404674300857 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark03(50.26547952157195,1.570546774211835 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark03(50.26547994205911,-1.570796261967708 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark03(-50.26548212889433,10.99557428480027 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark03(50.26548245534863,0.0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark03(50.26548245743668,-32.986720113311755 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark03(-50.27329618801763,-0.5663622521769446 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark03(50.2967324574367,-1.5707963267948966 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark03(-50.30409898968857,1.5707963267948966 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark03(50.30570399339288,68.75731620235894 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark03(-50.364800113018404,7.371306687031364 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark03(50.413382181942325,-3.9653547333835917 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark03(50.41802545260191,-65.3164710283923 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark03(-50.48031211334767,64.03290554028803 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark03(-50.51616365518894,-75.65045571207628 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark03(-5.062744745968288,68.61627583037148 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark03(-50.66055261551961,88.33861074150434 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark03(-50.67088764068474,-0.008032321843546186 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark03(50.67289123940384,91.52797903684512 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark03(50.71758538744994,-0.2053237951997823 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark03(50.8559550797475,-2614.35273394107 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark03(50.895255255549785,-25.956195773565497 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark03(-50.9022914975066,25.798764411871822 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark03(50.973484183581526,-24.577989897316613 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark03(51.0110376129652,1.5707963267948966 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark03(-51.020271390447625,0.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark03(-51.09246404210077,56.88932663879575 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark03(51.32089768755709,0.5261769300658551 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark03(-51.32567159319811,123.03272068103541 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark03(51.35108725714119,6.595029490496401 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark03(51.41799134032598,0.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark03(51.44182501098214,11.21797308807659 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark03(-51.461928557786905,-93.06723102389051 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark03(51.48676380217431,7.976840969790309E-17 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark03(51.49588224083095,1.5707963267948957 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark03(-51.519824470212576,-65.65699141136665 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark03(51.56949168705785,42.04110016052934 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark03(-51.59246346446245,198.2988610295066 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark03(-51.62031447365281,1.5707963267948983 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark03(-51.67410243467486,-44.879747452355865 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark03(51.70371440629688,23.842917457130387 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark03(-51.80955139370995,-1.5707963267948966 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark03(-51.82373453372917,-1.5707963267948966 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark03(-51.90441756565577,1.5707963267948966 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark03(-52.094093766837716,3.986102193693668 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark03(-52.41067913356603,34.39475033310066 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark03(-52.4694550113773,72.48311302231514 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark03(-52.57150584752082,76.71562551816888 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark03(-52.58337747213617,64.96412813061619 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark03(-52.670474270209475,-1.5707963267948968 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark03(52.838179985810825,78.24559288485108 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark03(52.94201861778433,0.0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark03(-5.304279475881122,1.5707963267948966 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark03(-53.04538434505474,0.0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark03(-53.05564918729435,0.0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark03(-53.09409368582734,22.306590703069972 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark03(-53.100131039313084,17.83133237927524 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark03(53.10134025899572,41.290917492703585 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark03(53.219930301544416,0.7259782822840183 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark03(53.29877673603812,-80.4829500498411 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark03(5.330189781828935,10.495609088849207 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark03(-53.36509803783367,-7.664710650343693 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark03(53.4070751033926,83.25220914814442 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark03(53.40707511102538,-1.5707963267948966 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark03(53.407075587863645,1.5707963267948912 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark03(-53.40708200420566,271.74782333325106 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark03(53.40719718136104,-45.55309056201658 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark03(53.43833331824139,-0.7412290755297917 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark03(53.44193957657105,-15.805437203361599 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark03(-53.512881529441906,0.04845536802511436 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark03(53.515435718672364,78.70594439797844 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark03(-53.535195450972076,-36.65287832376538 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark03(-53.659361848793274,33.15069908410197 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark03(-53.696905206315506,-16.63876100816728 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark03(-53.72750085059625,17.599187089588355 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark03(-53.86092818587562,-95.53580355663448 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark03(-53.895580238515926,22.012499410934524 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark03(-53.94334864589662,-15.57237242916446 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark03(-53.944966995697875,0.10323854562028549 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark03(-53.967653768487914,6.123233995736947E-17 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark03(-5.421010862427522E-20,0.0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark03(-54.23136589546053,48.70000186519809 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark03(-54.33061152250538,2.138040528447476 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark03(-54.3374578540863,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark03(54.379158861754135,0.0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark03(54.583451333868,-1.5707963267948966 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark03(-54.587732468548595,1.5707963267948966 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark03(54.58898620702582,12.479639981284677 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark03(-5.471834760380048,52.63417145759425 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark03(-54.779175742972555,-58.38421065824133 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark03(54.82199580293174,16.049436560472884 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark03(-54.92242305836106,42.85673243917532 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark03(-54.97787143782302,1.6143753815159178E-12 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark03(54.98039046535837,-1.5707963267948966 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark03(-55.02603750339263,-12.037233986041215 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark03(-55.061799674560085,0.0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark03(-55.06943056175749,0.0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark03(55.0813965705265,-38.878208119083695 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark03(55.08233681542579,-65.8520385034009 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark03(55.10523071062658,-98.7398179325244 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark03(-55.10722939074938,100.94321762230899 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark03(-55.109909414606804,70.09644342734899 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark03(-55.12157180902899,-20.22435013563569 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark03(55.12251726578105,-92.57342183563804 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark03(55.13224533235312,72.50021872474099 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark03(-55.13311945985942,-17.817687071934593 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark03(-55.169374269246845,68.92353554754999 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark03(-55.172463805106325,163.37837726548338 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark03(-55.174711526454814,-62.63501298316243 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark03(-5.518683559663174,31.47741240065206 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark03(-55.194211847926326,-1.0967191060242527 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark03(55.20220203660318,-15.275799415839586 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark03(-55.20636858715497,-24.022265559397056 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark03(-55.220411202193105,21.861423791404366 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark03(55.22050514425102,100.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark03(55.226284262806885,-0.10260889209824893 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark03(55.23624842977716,-1.5707963267948968 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark03(55.23657919933132,1.5707963267948966 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark03(55.24739051072618,90.78547438027175 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark03(-55.24863757756402,-87.96459430051421 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark03(-55.25280697956529,63.64832369993513 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark03(-55.26781820336753,2083.786953156037 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark03(-55.26975292369066,-5.991303821310308 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark03(-55.271567878260306,-1951.6389353588727 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark03(-55.27256804560429,131.95088057504924 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark03(-55.27577056724907,20.992467739704864 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark03(55.2868197137722,53.66774677125665 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark03(55.2868230628962,31.362707189164674 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark03(55.28797645828183,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark03(55.291672493659036,0.0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark03(-55.29970610294469,1.5707963267949054 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark03(-55.30322653475039,-91.02887441866214 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark03(55.310641687120025,85.69597369220615 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark03(55.34453279305913,1.5707963267948968 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark03(-55.35330063651517,16.058829580651384 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark03(55.35478764582683,-80.38085695108204 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark03(-55.38572379954648,-81.27355663160952 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark03(55.388864497416364,-87.96459430051421 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark03(-55.39501118888508,100.0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark03(-55.41259077430466,-66.48261419961406 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark03(55.423059311982115,0.0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark03(55.431318247594874,-29.718367575769662 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark03(-55.43330407357718,55.71381729463063 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark03(-55.44087836529121,101.9379939700554 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark03(55.44383709512377,0.0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark03(55.45784019342791,-20.642765314816764 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark03(55.47074056953623,-84.38098433488369 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark03(-55.475876619552444,45.137307682838866 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark03(55.484379842136235,-2529.661415775396 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark03(55.495914711989975,-19.961038285565124 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark03(-55.50231708350588,-84.55455392581383 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark03(5.551115123125783E-17,0.0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark03(5.551115123125783E-17,-1.3617675258113238 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark03(-5.551115281492759E-17,14.137166941154067 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark03(55.529493764742725,49.15068625026855 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark03(55.57232948811125,-1.5707963267948966 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark03(55.64134084512705,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark03(55.65219163761018,-95.08236838705379 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark03(-55.702912749783074,96.0035323432808 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark03(5.5722800185642285,1.5707963267948966 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark03(55.7825821891291,41.68205832797253 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark03(-55.84835284752177,54.23054145591934 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark03(55.98274206363584,-65.81441735781097 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark03(56.00026934693618,167.21235556726594 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark03(-56.01402419372402,30.45348602091667 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark03(56.03197821246219,-105.25304133650447 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark03(56.037268612314136,-5.036425179724837 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark03(56.0395097998241,-253.40736657877054 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark03(-56.05988151786846,-112.37713603478844 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark03(56.060411595254656,39.49396869759636 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark03(56.06497651188618,36.042434074498175 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark03(56.081794806906885,-12.43792768908034 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark03(-56.10775409846239,-12.487829037098024 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark03(-56.113125119926565,1.5707963267948966 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark03(56.11724420438895,45.452818813702706 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark03(-56.13753304480154,85.37439117197448 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark03(56.15288749393033,-94.27740588889952 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark03(56.2039323651967,0.029615184000993784 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark03(56.21281154599027,-16.40922858650864 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark03(56.235943818865074,-1.0299831270275351E-10 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark03(-56.23924774223402,-44.35389540465081 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark03(-56.242819077516046,-5.212389413791676 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark03(56.28900001264887,-1.8304640787623052 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark03(-56.293231333524794,-5.062378408951503 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark03(56.30234638727213,-1.5707963267948912 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark03(56.322119870031116,1.2518685577110737 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark03(-56.32246128887269,0.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark03(56.32590287553027,-2615.748109663262 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark03(-56.330711432851245,-74.95354249899542 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark03(56.38354899711782,100.40399535818506 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark03(-56.402677514862525,-1.5707963267948966 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark03(-56.423024635741555,92.83414609311257 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark03(56.444164397416756,-26.808040922712763 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark03(56.45075565457951,-1.5707963267948966 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark03(56.46448354875204,8.103981633984075 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark03(-56.46555539201286,-1.5707963267948968 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark03(-56.469836247297394,0.5645274940311765 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark03(-56.47114006690535,0.0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark03(-56.472563024628606,5.315516447644228 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark03(-56.479848734407256,-65.54427587251902 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark03(56.50297225756239,-1.5707963267948966 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark03(56.50314770335835,6.901159638142389 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark03(-56.50920256619329,89.79365887935808 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark03(56.528366697416274,0.0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark03(56.547293906407816,67.54424586696346 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark03(-56.54802983790096,42.41062491770831 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark03(56.54866661812709,-58.11946408901048 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866728579049,14.137166941161368 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark03(56.54866775260549,1.5707963267948966 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866775530404,-98.96009176377537 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776060336,39.269908169781885 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776461323,-1.5707963267986584 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark03(-56.548667764615004,1.5707963267948966 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461541,-1.570796326793978 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461556,-1.5707963267948977 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776461626,0.0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark03(-56.54866776461626,-4.745562357093237 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776461627,1.5707963267948963 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark03(56.54866776461627,-1.5707963267948966 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark03(-56.548668334549255,-0.5707312156126189 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark03(56.54866850706176,-98.96016858807378 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark03(-56.548683435687614,-4.7123889803945875 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark03(-56.54878983492878,-95.81857592274672 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark03(56.588017778629805,1.5707963267948983 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark03(56.66100140279096,-5.453511625922013 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark03(56.70396934890953,17.61784148455976 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark03(56.97578587019174,98.34059804054218 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark03(57.04043089681017,1.5707963267948974 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark03(57.05434933030135,27.748170718548522 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark03(57.05678553687753,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark03(57.06537529976367,-53.94425010403321 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark03(-57.13180071368357,68.05138794606489 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark03(-57.1778201497312,1.5707963267948974 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark03(57.282074862948946,25.331132925119373 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark03(57.28316574275374,0.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark03(57.327202880765924,87.50947297566142 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark03(57.3407085909335,95.75899576651946 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark03(57.39422975929966,21.048507911251235 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark03(-5.746854826648146,13.734812915859848 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark03(-57.58857230887949,-35.512919597486686 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark03(-57.60493828833748,81.26494256715543 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark03(57.656056659319624,-28.364070066305686 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark03(-57.69661434282194,-72.67948078115448 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark03(-57.73856763300708,2560.6501053456745 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark03(5.774281441908016,-75.49919305476212 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark03(57.74831063117682,37.63598519628931 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark03(-57.75188847538322,-2.066744608763017 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark03(5.779736132399165,-89.31464670011789 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark03(-57.799383979894436,58.20440487018715 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark03(-5.780767972574829,51.57780571542983 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark03(-57.84471991693831,-33.93979382544504 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark03(-57.90024776230834,31.6301159009095 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark03(57.91731065549091,5.0011491621672866 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark03(57.946828090020624,-24.847246828242305 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark03(-57.9507755340116,-2561.657164630661 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark03(-5.795121659394316E-5,102.10174143235068 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark03(-5.7990391886384804,5.212388980384691 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark03(58.011294479825835,-80.02047093970131 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark03(-58.11459987629104,22.52422212218835 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark03(58.11946409141103,0.0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark03(-58.14411492684247,-1.5707963267948966 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark03(58.203398264831826,-0.08393417342065289 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark03(-58.21388907685609,-100.0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark03(-58.28462358992999,17.066179395390883 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark03(-58.327234879839715,2.9338218651612533 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark03(58.36919150240942,1.5707963267948968 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark03(-58.51334185949578,9.83793046850812 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark03(5.8546885753603135,0.0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark03(58.576218178987716,-96.08386568383868 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark03(58.58146441823058,-71.04575394283242 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark03(58.592781202692834,20.420352248333653 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark03(-58.62768523234305,-48.37530957413676 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark03(5.8757601007865645,164.82656124330373 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark03(-58.83039401102519,-44.53059693431792 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark03(58.97144469846187,0.003654914489539757 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark03(59.05371890441785,96.84847786802914 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark03(59.0942866759313,2493.285369811156 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark03(-59.27825415014536,0.0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark03(-5.956460433777707,52.095951559839676 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark03(59.59496561408965,96.60739587378785 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark03(-59.69026041819011,-1.570796326794896 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark03(-59.690260418202655,-1.5707963267948966 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark03(59.690260418204474,61.261049498183105 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark03(59.69026041820606,1.5707963267948977 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark03(-59.6902604256633,-98.96015928903329 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark03(59.690260549525945,-64.40264928158928 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark03(59.69026423769849,1.570785768572114 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark03(59.69030310244715,92.67893967815395 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark03(59.72525334615207,0.0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark03(-59.73128159532914,0.0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark03(-59.75218387746927,108.10488034279844 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark03(59.853459104499024,0.0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark03(-59.9718350498009,-34.47715002919449 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark03(-60.07961913240627,-52.41110968903373 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark03(-6.011375721558991,91.76238841493947 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark03(60.15242826390096,18.646798465215355 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark03(60.23606372990818,-1.5707963267948966 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark03(60.248860472414286,0.0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark03(-60.250097514754366,1.5707963267948966 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark03(60.446645808325314,2582.7068006977606 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark03(60.470743188229605,-84.58810874897837 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark03(60.4886441564554,-98.24436111655136 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark03(-60.493842475720385,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark03(-60.497876049780515,-75.6061568134021 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark03(-60.50875066200532,-0.3216833425416309 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark03(-60.57100711312043,1.5707963267948966 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark03(-60.58842367031048,94.51527049290192 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark03(60.62817846957625,-48.98522802891225 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark03(60.67656985399977,10.819387456222538 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark03(60.693960670487286,-98.54854804414678 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark03(60.722962099744336,25.0208507325691 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark03(-60.750965241036866,-44.97629482231292 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark03(60.773698775852296,9.580677192445066 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark03(60.782292367449394,85.301766024476 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark03(-60.801279076218776,-1.5581562972811578 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark03(60.85020428000411,52.99622264602962 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark03(-60.86352910054218,-0.12476639177958404 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark03(-60.89316756525096,-50.12686151092236 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark03(60.979414191440185,0.0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark03(-60.98350387408627,-0.2780871190857105 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark03(-60.993492841440336,0.0079902324891655 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark03(61.001009299990386,-8.951179896559799 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark03(61.12423440169613,-1.3086274927923256 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark03(61.15336530525559,0.41263243097224783 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark03(6.123233995736766E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark03(61.24983192994688,0.32407398937871046 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark03(6.129350990689673,64.5201292859774 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark03(-61.33416797451686,-139.03907770384666 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark03(-6.133896956377711,-22.24449431827267 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark03(-61.34249004591346,-0.547117546681546 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark03(-61.39884427930097,31.8272217874337 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark03(-61.44279486532661,-1.5707963268234906 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark03(6.154118017692895,2713.1218208841206 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark03(-61.56554000549819,0.971067902425247 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark03(-61.59572146239887,58.96529652756553 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark03(-6.162975822039155E-33,7.853981633974481 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark03(61.6868778537713,-0.3948179119583474 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark03(61.762689393126635,16.68076389526966 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark03(62.011478863841205,0.0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark03(62.118697413137994,67.17395136589596 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark03(-62.141040913902195,-44.240097930661356 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark03(-62.254922282006774,-1.062370691524271 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark03(-62.30971472599013,0.0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark03(-62.446260863538036,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark03(62.46395544466896,54.067492246983875 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark03(-62.49989115768959,63.20388274866326 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark03(62.58429777284428,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark03(6.260068260804786,0.0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark03(-62.75715302315356,-72.64156296020911 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark03(62.785222854894386,-86.69464782276113 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark03(62.8004576671558,76.42404964075644 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark03(6.283142796234215,-1.5707963019396316 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark03(62.83178494836282,1.5707963188528509 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307179543,1.5707963267950105 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark03(-6.2831853071795525,1.5707963267948966 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark03(-6.283185307179579,-1.5707963267950122 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark03(-62.831856886516604,0.0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark03(6.283185784026753,1.5707963267948966 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark03(-6.284168414902157,1.5707960092397608 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark03(-62.842390326804185,-2.0776612921079263 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark03(62.855943279185894,-0.4655840359840336 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark03(6.287433289553635,51.83203081155255 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark03(62.877204943677995,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark03(-62.89435307179587,-1.5707963267948966 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark03(62.89435307179919,1.5707963267948966 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark03(62.93005703864356,-0.19085045324336086 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark03(-62.9415545964251,-3.149794771206544 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark03(62.957483432469424,39.26566223098009 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark03(62.97296519361038,0.0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark03(6.298810307186463,-73.8313578825375 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark03(-6.304595516380291,-1.5707963267948715 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark03(-6.3049133274342815,-48.69150812811471 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark03(63.06741353451079,-46.46243374416863 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark03(63.08672146461087,-22.797003126826183 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark03(-63.12036996841948,-49.72940464615173 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark03(-63.134211024616505,1.5707963267948968 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark03(-63.13556474489748,78.85974879578012 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark03(63.16405111686548,101.54154438559948 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark03(63.170515678627126,1.8234314424434212E-4 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark03(63.194975479018126,-86.87466310304785 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark03(6.325254130613312,95.78179311858646 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark03(-6.326829756618321,42.367856374023475 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark03(-63.321373067772576,-73.33790736338342 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark03(-63.41583160621592,74.54038793917297 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark03(-63.45519375829068,63.33522126409602 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark03(63.50000110963378,1.5707963267948972 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark03(-63.50464624927306,-58.6467090773607 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark03(63.543600629646015,0.0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark03(-63.563255968249415,0.0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark03(-63.571094127282876,34.2046062441716 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark03(-63.58984567360484,-45.31571915676638 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark03(63.628210367404705,-92.8153389499266 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark03(63.64693402872567,-0.5468405001548138 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark03(-63.65646470574142,68.44618922940276 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark03(6.375982627531501,-1.5707963267948966 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark03(6.376805549055976,-86.22772394384856 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark03(-63.881258110307485,-66.84081481006172 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark03(-63.89020631920492,73.71456807792097 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark03(63.92170186928386,1.5707963267948966 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark03(63.94609795418144,-79.18125826488614 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark03(-6.397555583951137,58.2335218899529 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark03(64.00771429072473,-0.006184353052291906 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark03(-64.09297907090605,-1.5707963267948966 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark03(-6.4102347560305795,-2.051502361580824E-5 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark03(-64.10421567069942,-98.96016858807849 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark03(-64.10806984037576,90.10871238436141 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark03(6.412131856167893,0.0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark03(-64.19630429200897,78.33029458368571 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark03(-64.20820380648262,-1.5707963267948948 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark03(-64.22881103301373,44.95945984047887 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark03(64.29301049396184,-23.443059272609702 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark03(64.34258364024204,0.5705984020193214 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark03(6.438564943927696,98.96029738362738 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark03(-64.39487539062343,2633.0367703421884 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark03(-6.4455848515408825,-14.575384845753874 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark03(-6.455738809096001,16.37474570295871 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark03(64.6299463444517,0.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark03(64.65705395295682,72.38325515612922 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark03(64.81267812331808,-67.65786892996412 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark03(64.9153391427786,0.5055094295487947 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark03(64.92426905977322,45.101734767852136 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark03(-64.93138478952646,8.958550039549994 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark03(64.93252875404426,0.0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark03(-64.93611860780112,17.23163166452558 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark03(-64.97966371981897,0.0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark03(64.98996299927848,-1.1437990698419842 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark03(-65.05607576818308,2411.8077913719017 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark03(65.08620064422908,-54.44424211575654 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark03(-65.1942702216408,-21.60951451796646 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179587,-48.780590205851745 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark03(6.533185307179589,-95.7505431696478 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307181293,4.4682230870443505 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark03(-6.533185307229178,45.68315494610178 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark03(65.37951151167914,31.792885670673655 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark03(65.40160272190991,-64.80690060981513 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark03(-65.46976996896359,-21.119415506173993 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark03(-65.569114959039,-40.89060233580423 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark03(-65.64395634212912,63.31200944384872 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark03(-65.65214157637438,0.0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark03(65.74203997205237,67.54424205218056 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark03(-65.74348114758067,-82.24528319968584 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark03(6.574614046199635,-9.527977085591687 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark03(-6.574669750816241,36.59362312231454 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark03(-65.75180393543178,-39.01212062116839 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark03(65.75710899576221,-44.09326452878077 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark03(65.89472851369622,0.0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark03(65.96847241323684,-31.676255365566803 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344426972143,-45.553093477051306 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344522111143,1.5707959269128324 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344572538563,1.5707963267948963 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark03(-65.97344580485807,-1.5707963267948966 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark03(65.97345111506277,-23.56243324351124 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark03(65.97345648127298,0.5415286561083855 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark03(65.99556807521614,-38.38435807228016 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark03(66.03263503022713,67.54424205218065 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark03(-66.10963859116292,1.4346034610176348 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark03(-66.14047299114718,39.2606502660513 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark03(-66.17457289800222,0.04452044441711351 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark03(-66.18802128162068,0.0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark03(-66.19545036718162,45.33108883525604 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark03(66.22024432089833,167.1007137209197 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark03(66.245991708026,70.95838068841068 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark03(-66.2598285869452,-40.11495305164958 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark03(66.35561540838202,2534.254135258548 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark03(66.40607830733725,-37.677550792165974 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark03(66.41510932541178,87.48802871082097 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark03(66.4521303281683,0.0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark03(-66.5064327395086,86.94725833623923 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark03(66.51326509745812,-23.561945184724102 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark03(66.55477527175651,-16.853426719103524 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark03(-6.65804505416326,1.25441428131019 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark03(-66.5830818673851,-1.5707963267948966 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark03(66.59701020872447,-100.0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark03(-6.665191735452254,0.2351209067833096 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark03(-66.67816095332513,-1.5707963267948966 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark03(-66.68033983406531,-59.72125545094515 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark03(-66.70935332784155,0.1938086798978512 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark03(-66.71735548731738,-1.5707963267948966 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark03(-66.75225399178498,54.13768421997051 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark03(-66.7602835925928,-27.63519200760345 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark03(-66.77341197303565,-1.5707963267948968 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark03(66.83978910350585,69.56232359423166 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark03(6.690436704042796,-1.44537395794066 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark03(6.692039491114506,-7.445127450039564 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark03(66.94104242654029,2.1440299212755605 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark03(66.99921287710421,-73.45525760005128 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark03(-67.0244114075785,72.5511659089009 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark03(-67.05331417736966,80.26592071067529 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark03(-67.18772481944916,36.87668393533784 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark03(-67.19810873003806,-1.570796326794897 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark03(67.28562332038712,-1.5707963267948966 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark03(-67.37649361612182,0.0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark03(-67.40088366309749,-60.52845868782888 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark03(6.749394890052926,36.0910483551411 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark03(-67.50848467211371,-0.037114208789551406 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark03(-67.59605894434532,0.5420466275475918 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark03(-67.7515481444727,-1.2279560045497497 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark03(-6.776263578034403E-21,61.26300987002071 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark03(-6.779224104962836,1.5347684923475655 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark03(-67.82336749410766,74.2359459822006 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark03(6.791049106984881,30.35299400890833 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark03(-67.9244520293793,-62.22826110416866 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark03(68.09792444046806,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark03(68.17583447789227,-34.62721721920252 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark03(68.21146565137056,-48.14578901078206 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark03(-68.27661004122704,25.448050926320064 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark03(-68.36148224096053,70.5179305692522 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark03(-6.844878960329856,-10.956110398899039 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark03(68.45173753618096,-60.272779903807304 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark03(-68.52683503994996,31.134809781750164 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark03(-68.52790074448367,0.0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark03(68.54048187734216,102.0811587414963 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark03(68.58404433922641,-58.28934601234301 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark03(-68.66805789197439,32.83364272122975 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark03(-68.77129751670023,-79.87264108412637 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark03(68.79659069170066,-10.995675623648639 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark03(68.90616718067537,-95.61407893604458 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark03(-68.94440322849616,89.36475547682981 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark03(68.99687676720882,-1.5707963267948966 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark03(-69.02531761947158,0.0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark03(69.11503221522501,-0.5685718868247372 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark03(69.11503837887538,-1.5707963267948966 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503837897548,-1.5707963267949339 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503837990678,-1.5707963267948963 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503837990684,1.5707963267948966 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503839387662,-1.5707963267948963 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark03(-69.11503916206527,32.98672286269282 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark03(-69.11504273438818,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark03(69.11504441590344,-73.82742735927654 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark03(-69.1155659485554,17.278761090655358 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark03(-69.12879848571185,-25.33301272540824 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark03(69.1605399734396,36.17381711074677 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark03(69.16982889317872,8.881784197001252E-16 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark03(-69.18659023211761,-2.0707963267958127 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark03(-69.18740367873622,-1.5707963267948966 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark03(6.91948364373158,-24.19824323847543 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark03(69.2289865774029,70.83391467454808 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark03(-69.23369219802134,14.432800227060639 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark03(-6.927525970622497,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark03(-69.30558779004176,44.62545079427326 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark03(6.937650342737415,93.33144831645673 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark03(6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark03(-69.42619971900996,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark03(69.45621395785605,-69.22415943824359 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark03(69.46021896362305,-0.04935636214934436 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark03(69.55391671543035,0.0819394303843205 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark03(-69.56622719297724,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark03(69.57283796005397,-18.47003205134301 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark03(-69.57802008974309,4.7252304710940365 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark03(69.58326178127469,-1.5707963267948966 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark03(-69.64304781921037,0.0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark03(69.68778543632054,0.48588078303474497 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark03(-6.97314007000974,-85.70384321088916 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark03(69.74122622459863,32.46036256811027 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark03(69.78787127961985,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark03(-69.81903025058462,26.965420058098626 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark03(-69.82579894461776,-67.64905404108892 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark03(-70.01382869127498,17.387999851898655 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark03(70.01725670668557,129.84137021631787 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark03(70.02243541068563,26.763574083550097 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark03(-70.1767775776289,-71.19729185913313 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark03(70.20121913038051,-44.392656452023054 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark03(70.20732904114507,19.993144593942418 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark03(-70.22955432086577,-74.38080806060714 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark03(70.43265829520189,56.325178283586695 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark03(-70.43467161246741,139.19647697313297 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark03(70.46774288691856,-1.5707963267948966 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark03(70.50149861055336,-2558.924696609593 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark03(70.59942997244576,0.0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark03(-70.6008954688458,-3.0939763111091025 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark03(70.60867730928817,14.429259765506771 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark03(-70.66951831253827,16.53069767685912 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark03(70.67593921609009,17.280917012547036 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark03(70.68583470575075,0.0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark03(-70.70591307686729,72.27670940366218 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark03(-70.71702353674327,18.30424294740334 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark03(70.8350536665991,-18.793839478914226 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark03(70.94042222041648,181.9577863935619 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark03(7.12694147682505,-36.972071685928086 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark03(-71.39250886727429,59.87218184486122 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark03(71.43522219585572,0.03674071951893895 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark03(-71.51329893228417,-262.3246149907213 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark03(-71.52066803941543,-44.51468312266734 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark03(71.54450948422809,-88.82326907897195 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark03(-71.55119865719688,0.0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark03(-71.55569992245874,-39.85209445792937 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark03(71.59881332159276,85.22678632436828 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark03(71.60802422590314,58.94507060459497 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark03(-71.67146954085963,-17.346186985748886 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark03(-71.74317883054273,-43.081560619522975 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark03(-71.75927316547859,-0.2774675605370785 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark03(71.7669221483015,5.212388980885267 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark03(-71.77027703700246,6.123233995736766E-17 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark03(-71.8326042722077,21.219820171440148 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark03(71.84094703482616,-1.5707963268907954 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark03(71.95866024700271,-67.66596281655865 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark03(-72.07160583671042,130.14866978530904 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark03(72.08696526626758,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark03(-72.12353325591681,-1.3504143335810503 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark03(-72.1613146687754,94.9491759024132 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark03(-72.20141235057683,73.15503684710026 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark03(7.220762580146527,-1.5707963267948966 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark03(-7.224012998293937,-33.92755055380718 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark03(72.25663103048734,1.570796326826346 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark03(72.2566310326265,29.84513784106922 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark03(-72.25663112617963,-105.24334755777852 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark03(72.25663150940241,48.69919548507733 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark03(72.25663150941223,20.420351135283735 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark03(-72.27552006926925,-19.124141986992413 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark03(-72.29919438530244,-1.5707963267948966 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark03(-72.34524321115319,52.395431299121526 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark03(-72.35266812828237,82.82594062059367 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark03(-72.44303853455318,2674.0590082311114 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark03(-72.47273622725822,-0.4697348401771758 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark03(72.56068050688671,-71.32423501888559 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark03(-7.26980197945684,-25.99215337194802 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark03(-72.71340735313494,53.87569310565073 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark03(-72.73665362205244,-64.00330173276456 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark03(-72.8118164694077,33.17906843985884 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark03(72.91380851076846,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark03(7.295247583030505,3.2330551827001583 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark03(-72.96372320552152,51.56678634659373 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark03(72.96496770362097,-44.93625298822701 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark03(73.00095554761711,1.5707963267948968 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark03(-73.01245110298933,1.5707963267948966 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark03(73.01977958173416,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark03(73.03211131043363,8.0961403002634 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark03(-73.03367077545171,93.62194841669395 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark03(73.1037421044843,-0.14244709661356086 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark03(-73.1048649257832,67.52527358740252 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark03(73.20637107465538,0.0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark03(-73.24431477796203,-70.42202410763065 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark03(7.327397610682112,-31.837031673191603 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark03(-73.3602503640347,-1.5707963267948966 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark03(-73.49278350673747,1.5707963267948966 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark03(73.53216882482499,69.17014256350981 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark03(-73.53328857754369,-0.023438718588592367 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark03(73.58470802551568,14.802824703200486 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark03(-73.64337123165954,0.0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark03(73.66989372055258,-1.3167679636207694 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark03(73.80464858862811,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark03(73.88877094222411,-57.466091472640024 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark03(74.1274917438289,0.13805289653715108 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark03(-74.12832752510934,1.5707963267948966 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark03(-74.15403283260282,-1.5707963267948983 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark03(-74.16661938615067,-57.323990408060205 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark03(74.38998226157476,59.13244386723389 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark03(74.51289100235942,-1.5707963267948966 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark03(-74.55628284695227,-92.91870832696648 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark03(-7.4604829461944,-62.798930670988916 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark03(-74.63803004472535,-71.3747973118187 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark03(74.80233844496405,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark03(74.94039574738144,2632.231250849831 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark03(-75.13785193995439,32.16083310214012 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark03(75.1679203828159,-44.41793010643351 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark03(-7.52160130471826,2651.8395356180695 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark03(75.39822368615502,-1.5707963267948963 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark03(-75.39822463564707,61.26307667190416 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark03(-75.46440494650376,-1.6370420919689699 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark03(75.52283923546956,4.837388980460541 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark03(-75.5236064967849,34.590798681504396 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark03(-75.52549708514738,0.0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark03(75.57119784361292,-32.86480879454937 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark03(75.62587541948542,-89.14863637829806 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark03(-75.72625518766698,-7.9308521882825005 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark03(-75.73122675594954,-9.575476363174111 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark03(75.79586957436959,-39.11408728059818 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark03(75.85913617963786,34.904446891406366 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark03(-7.588545972784232,-1.5707963267948966 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark03(75.92969435314166,32.45525219570621 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark03(-76.02873414369024,1.5707963267948972 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark03(7.603052187902934E-12,-1.5707963269538006 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark03(76.03406829819107,-79.58782409001975 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark03(76.16496610494532,2.968854098939266E-17 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark03(76.19912632713229,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark03(-76.20367315703338,84.93072667767623 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark03(76.2796078249813,-65.8025277357865 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark03(76.30249680056752,-16.382670322968565 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark03(-76.35022819614784,-104.29134938526528 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark03(76.452984484257,-100.0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark03(76.4562476931592,-1.5707963267948966 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark03(76.5302782529385,1.5707963267935163 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark03(76.64892978286167,-99.19018570756499 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark03(76.6561002707561,-7.619948062511199 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark03(-76.68916461164305,-66.40665154943082 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark03(7.6756786784972775,-22.00127278914185 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark03(76.77398800024395,0.0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark03(7.679370069625644,6.1951789304791225 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark03(-76.80185098193668,0.0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark03(-76.95121341051141,-26.21898690341709 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark03(-7.696898061763861,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark03(-76.98125517399085,32.69683203156434 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark03(76.99873044377043,-155.62179950780626 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark03(77.00282984885794,0.03380983590800309 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark03(77.00685813231385,-43.98201646544246 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark03(77.03945707954182,-22.29009586555628 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark03(77.0763609108587,61.26105674500097 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark03(-77.0786279191978,-9.627669438930688 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark03(77.08492180882669,1.5707963267948966 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark03(77.13568045501772,-2574.266464615691 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark03(-7.714096159212536E-16,1.5707963267948974 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark03(-77.16131987197537,-72.06433117353981 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark03(-77.16914880577394,86.66781680770394 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark03(-7.718121956527398,91.25994255625491 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark03(77.1946893309912,-7.253687404846971 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark03(77.19644792674329,0.29762516780354936 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark03(77.19795356049384,2612.5886428459503 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark03(77.22142357303662,-61.21846092354244 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark03(-77.23149358088139,1.5707963267948963 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark03(77.27695977761928,0.0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark03(-77.2987411680453,-52.596086039936964 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark03(77.31110260050565,15.223038006645044 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark03(-77.31794577392299,-46.97012871617626 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark03(-77.32154621539229,20.136021003003577 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark03(77.34936853733595,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark03(7.7349508903058535,-49.44263364491617 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark03(77.38800362416725,-10.86615350766877 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark03(77.39804027164382,0.0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark03(-77.40841308389932,0.0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark03(77.42631807411033,-44.45245026790836 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark03(-77.51745440895881,33.427167522541794 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark03(77.52033911865342,17.278759594743864 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark03(77.53804208112132,5.604641914492873 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark03(-77.5582228015514,56.38726751473507 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark03(77.5848375037065,-2599.865214962521 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark03(77.6675747089802,0.0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark03(77.67462126524617,-62.2383076606996 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark03(77.69020931181592,-29.2537217685326 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark03(77.70346425063737,-3.1415926535897936 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark03(-77.7157641106264,-78.26922197249868 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark03(77.71657602484302,44.079555285546576 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark03(-77.82327412558412,86.95226025028703 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark03(-77.88971776018133,85.94633872243861 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark03(-77.97358483133227,0.0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark03(77.97924481847659,-100.0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark03(77.9821327223479,1.5707963267948966 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark03(78.02060130023966,74.58799283054717 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark03(78.08364297776329,28.22931508498661 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark03(78.09130844819063,-90.673003610958 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark03(78.1134727213909,-40.974028879060675 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark03(-78.13034144699593,-2587.8332022115133 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark03(-78.1393935732448,0.0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark03(-78.14776827056264,-96.69967427995041 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark03(-78.18839416276731,10.644152110586756 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark03(78.20936460878697,-1.5707963267948966 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark03(-78.3206786066681,0.0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark03(78.34422695208873,-1.5707963267948912 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark03(78.34587123567971,-1.5707963267948966 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark03(78.38965208586984,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark03(-78.41337738301569,-36.085200723232 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark03(78.41973791160147,0.0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark03(78.43010385185943,36.23510262101155 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark03(78.43837089209894,135.54235050755284 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark03(78.45998321123855,4.792222160922442 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark03(-78.4711497823207,14.205833498578206 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark03(-78.48217724444895,90.15965442367207 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark03(-78.48455955051351,0.0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark03(-78.51899146173221,-14.436653809427945 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark03(-78.53160323901263,1.5707963267948968 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark03(7.853943492669015,0.012118773044158423 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark03(-78.53949755765628,26.698563346137767 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark03(78.53980692862407,-4.712388980381062 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981578159548,0.5707931868812867 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark03(78.53981630046711,14.137178957101314 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633800836,95.81851682419457 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark03(78.5398163391811,1.5707963267949197 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark03(78.5398163397445,130.3760951239519 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974477,1.5707963267948402 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981633974482,-1.5707963267948963 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,-1.5707963267948977 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark03(78.53981633974482,-92.67698305035265 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark03(-7.853981633974483,0.20563617101773932 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974483,-0.38598990837020924 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark03(-7.853981633974483,1.5707963267948966 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark03(7.853981633974484,100.0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark03(-7.853981633974489,-1.284686741777994 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark03(-7.853981633974496,-31.718334505944213 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark03(7.853981636181631,0.0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark03(-78.53981645643982,130.37609512048954 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark03(78.5398201544421,1.5707963267948963 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark03(7.853986250584363,-30.888731872945293 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark03(-7.853986928406746,-1.5717309113002529 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark03(78.53987737490108,-1.5707963267948966 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark03(78.5994175100618,-1.5707963267948966 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark03(78.6874331964532,0.0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark03(-78.7211127004802,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark03(-78.7292131815176,-15.918758123880508 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark03(-78.74523275880878,-45.03339047316541 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark03(-78.77027322751522,42.57375181176516 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark03(-78.78312880127271,-27.724495379966285 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark03(78.79958302516332,-9.645630354267489 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark03(-78.88979454452563,-31.920580319319107 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark03(-79.01966839869581,0.0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark03(-79.03106614674395,-24.999383916100612 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark03(-79.12049304451187,72.51199305538317 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark03(79.12845186320274,83.27735807739609 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark03(79.26471055104325,-0.16207786199974375 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark03(-79.26639037653808,-64.12957594734215 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark03(-79.337173555317,-14.166143715826117 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark03(-79.49227740251423,-5.664850043154092 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark03(79.50990241419078,-2.8528962023095916 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark03(79.5234802853158,-27.108094398769197 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark03(79.52395525728369,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark03(-79.5292305573799,42.41156798651635 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark03(79.58349262679636,-157.6161046050178 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark03(-7.964787610577332,-1.5707963267948308 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark03(-79.70548224124089,-75.80335411145388 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark03(79.73816631653864,-42.128008675451106 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark03(-79.7632840271816,25.760938687382136 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark03(-79.79720947993489,0.0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark03(79.84542960852198,-95.6148693981517 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark03(79.87774970648196,-8.783818174010306E-7 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark03(-7.99244101982093,-1.5707963267948966 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark03(-79.95897707925594,-0.033775135783264854 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark03(-79.97320009733676,-44.149865312727414 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark03(80.08301092353298,41.92090511682173 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark03(80.09220952757198,0.04055316839006982 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark03(-80.11061266654615,0.0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark03(8.012344724570127,25.291051025457232 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark03(80.14282583604545,-0.35140364942456764 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark03(-80.26206166786254,-6.712072603324067E-9 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark03(-80.33244566693108,-40.033380067980715 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark03(80.34971870547659,0.0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark03(80.60494346018837,38.47340922931132 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark03(80.68532391486895,1.5707963267948966 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark03(80.8213034619655,-87.01840364937317 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark03(8.108904323782715,80.43256962657759 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark03(-81.15057072429332,101.57092297262697 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark03(-81.30808789923205,-94.64585606244276 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark03(81.31902515170114,68.31508317041542 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark03(8.145652788678497,1.7626276034325717E-15 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark03(-81.5126410268545,-2511.5408820398525 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark03(8.162324937221314,31.976251054001402 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark03(-81.68140899333387,4.712388943414621 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark03(-81.6865347552635,-0.570794730538959 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark03(-81.68922149333584,-0.56815273917776 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark03(-81.7095128021832,48.917672029873444 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark03(-81.73412084857581,50.77157931139877 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark03(-81.73725486815698,1.5707963267948968 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark03(-81.75115831726515,14.429461275080634 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark03(81.84957548588974,-66.47408052313403 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark03(81.87222607590829,-0.5643024175507524 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark03(81.88144133728042,1.3707639828490998 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark03(81.8890658997981,-19.37438163439822 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark03(81.88985123986399,-139.10598062137888 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark03(-8.192269651849623,0.5934283782249932 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark03(81.92590361078683,-1.8290214997203265 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark03(-81.95646947100167,-64.50288161381522 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark03(-81.95685686838652,-53.009189282666426 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark03(8.19643776960946,-37.91705733145439 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark03(8.198120794525348,0.34413916055086496 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark03(-8.203561210177185,-67.72656861656789 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark03(-8.203802312652511,15.358142589270939 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark03(82.05773416577863,1.5707963267948912 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark03(82.07562920176417,1.5707963267948966 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark03(82.08330796814994,4.71238898038469 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark03(-82.09041406844293,-0.017838245671491105 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark03(8.209534974899569,12.210817273434088 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark03(-82.10440246827628,-1.570796328541235 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark03(82.12492473877685,2672.385512988484 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark03(-8.214516674055844,-0.44333650832223365 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark03(-8.216628957405547,-7.3503982072587775 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark03(82.17404942114165,-1.5707963267948961 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark03(-82.18567473399652,-78.8367285745472 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark03(82.25887432586967,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark03(-8.229445703417099,-2.9515133605680495 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark03(-82.29982653879114,0.47601706767284546 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark03(-82.32875358914809,-45.26671609797898 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark03(8.237873605842928,0.0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark03(-82.3791268324608,0.0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark03(-8.239010713125538,-1.2551100634272103 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark03(8.240961908042578,-0.38698027406809515 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark03(-8.242850204086874,131.39444277132205 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark03(8.251451648661934,14.095607424544838 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark03(-82.55530491895227,3.9989809223315826 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark03(82.60969428491484,-1.570796326796419 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark03(-8.26127177780127,-162.20017982932956 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark03(82.61297993200708,12.007864669313633 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark03(-82.77559230680993,0.0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark03(-82.81268020794165,-1.5707963267948966 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark03(82.87540747174302,1.5707963267948966 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark03(82.95303798270132,-1.5707963267948968 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark03(-82.95725892563489,-29.845130863710708 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark03(82.96959141572191,0.0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark03(82.9921655631467,0.0934524276264369 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark03(83.02531483309411,42.62099820038503 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark03(83.0298916592817,54.14263521171074 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark03(83.03186199566946,-84.56380813084809 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark03(-83.07729729214468,-2621.2674479168672 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark03(-83.10269777228955,0.0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark03(8.319863988257499,-1.5707963267948968 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark03(83.2523374303962,0.0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark03(83.26439707153207,-1.5707963267948966 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark03(83.28082169244351,-4.106837776964959E-10 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark03(83.28955734547574,6.429385446982054 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark03(-83.29203620710885,-61.031551116263614 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark03(83.29284864672138,0.49750449062870683 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark03(8.331732506921224,-44.32252184848036 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark03(-83.34841274115674,67.08319967302688 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark03(-8.335527283152942,94.03023922393913 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark03(83.3647655539935,-1.5707963267948972 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark03(8.337084859704014,0.533490213865189 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark03(83.38575073623795,-0.062007071734681514 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark03(83.40379312451807,-102.92384787590572 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark03(-8.345021241095779,1.5707963267948966 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark03(-8.345608781056649,1.5707963267948966 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark03(-83.47872889217689,-34.33099561744036 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark03(83.5229522834901,25.040370989965737 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark03(83.53502656234934,1.5707963267949197 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark03(83.57908625801292,82.69108590798336 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark03(83.76928251144,-5.766108115869111 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark03(8.37729685440546,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark03(83.77517603186573,-154.6504167125279 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark03(-8.387168349985393,-36.5265216897772 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark03(83.88448531088292,-82.01209940235219 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark03(8.399818545147397,1.5707963267948912 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark03(-84.01033493971686,98.65158961071731 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark03(84.03188356650509,0.0020311080140921665 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark03(-84.03771297863739,-88.75997399120513 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark03(-84.1388070366738,14.429489499146882 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark03(84.14150402305569,26.596064809406556 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark03(8.417954388716087,-1.9760315929828778 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark03(-8.42267859383929,-2.5728956937249863 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark03(-84.22876268272972,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark03(-8.427851170373867,-27.700464345908756 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark03(84.28229017426989,-0.1360747906347822 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark03(-84.28685620427771,-98.12433883107113 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark03(-84.33197216541501,0.5036330327055812 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark03(84.3386979157091,-51.10701687622502 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark03(-84.44111931939185,1.5707963267948966 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark03(-8.44569280739191,59.09854924478864 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark03(-8.447807075691179E-19,1.5707963267911407 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark03(84.53502022969818,0.0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark03(-84.63797897970588,0.0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark03(-84.6400698937086,-6.429421076364819 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark03(84.6679093440133,1.5707963267948968 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark03(84.67049289698272,4.868634005158067 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark03(-84.698995179609,0.4999955903019127 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark03(8.470329472543003E-22,-64.40313767985343 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark03(8.470329472543003E-22,92.6769808378763 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark03(84.74962113542576,2332.958449560082 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark03(-84.7660318927476,-164.8332333075879 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark03(-84.80563019470077,91.67878904980077 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark03(-84.81038801127843,-1.5864213267949414 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark03(84.82122709410349,-37.012259404152616 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300028265321,-45.55309347704752 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300156651071,14.137166884437141 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark03(84.82300164692396,1.5707963267948966 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164692438,-54.9778753116509 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark03(-84.82300164705018,1.5707963267948966 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark03(84.82300167232876,-32.98672286250353 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark03(84.82300927774126,-1.5707963267948961 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark03(-84.90852540828305,-101.66785607575339 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark03(-84.93971092736241,1.5707963267948968 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark03(85.00723436298387,44.4045362213715 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark03(85.05715507023496,-98.05555098582482 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark03(85.09757071063032,-1.5707963267948968 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark03(85.1288120735046,58.42527451799136 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark03(-85.13172877443952,19.640815276685732 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark03(85.13597380365118,92.56767033852005 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark03(-85.18115151834532,38.0453892416173 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark03(-85.20026571832604,74.13073762364212 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark03(85.20889195151943,73.55174810777484 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark03(-85.23682215770492,-60.33735517234051 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark03(85.2837123183102,-73.25797192551047 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark03(85.29108554038746,71.52464107753542 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark03(-85.33974053312616,-15.098609882726805 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark03(-85.3465459319701,-85.44991961412452 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark03(85.48605335746433,-0.016300466122147243 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark03(85.51409165019348,-0.29433465214281684 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark03(8.55280457373714,6.982008246942243 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark03(85.53150886823059,-17.174631757642132 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark03(85.593625290353,28.14548835368372 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark03(8.56480370247525,-0.6898047956804603 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark03(85.6565588086722,1.5707963267948966 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark03(-85.80558750240623,0.0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark03(-85.83471201348722,-68.95159923740523 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark03(85.86547366376911,-80.21620360669601 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark03(85.86677770791559,-14.429480621758096 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark03(85.88340603284334,-68.02941767232068 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark03(85.97055666199648,-1.5707963267948983 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark03(86.01320312636136,1.5707963267948983 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark03(86.03394258987706,44.03171133296921 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark03(-86.0914009416524,-11.694192287778066 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark03(-86.10240909933835,44.15170664963344 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark03(86.1281936937558,59.31048550546598 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark03(86.33519779112618,1.5707963267948912 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark03(-86.39379797371537,0.0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark03(86.54047119815121,-71.65479312122957 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark03(86.55501420929653,73.91979667139196 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark03(86.60267818414766,1.5707963267948948 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark03(8.660365980535868,37.0833469499648 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark03(-86.67893310702632,136.56396450421568 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark03(8.673617379884035E-19,-29.845130209103 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark03(-8.673617379884035E-19,39.26990816986585 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark03(-86.93130790144701,-38.41621521147624 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark03(87.03874943263253,-77.39202077208725 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark03(87.05819156101947,8.881784197001252E-16 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark03(87.09497744364285,0.0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark03(-87.1935958095372,-33.14310762430401 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark03(87.19479342801529,73.61931263450981 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark03(-87.20680352289197,-74.58521813698238 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark03(-87.2471256686582,-1.5707963267948966 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark03(87.37349653884755,22.970847140256787 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark03(-87.59543862965387,30.214285879963377 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark03(87.61581931053064,80.57115328492594 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark03(87.65098279903373,-58.43307559289166 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark03(87.65388973147589,-76.40979262142616 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark03(87.80924123464524,122.76955629338903 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark03(8.781076729069186,-1.5707963267948966 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark03(87.96459429926551,-39.269908021163495 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark03(87.96459430057159,1.5707963267948966 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark03(87.96459434430488,42.411500823291505 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark03(87.9646181727356,10.995526307862589 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark03(-87.9782334812328,127.25668629587068 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark03(-88.04094140276234,-6.525686402810777 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark03(-88.07215654078422,41.39178805054701 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark03(-88.11003831535297,-1.5707963267948972 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark03(88.28509703421138,1.5707963267948957 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark03(-88.29548963178961,9.438315095967027 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark03(-88.33829373947837,10.652518071133418 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark03(-88.42810240237932,-136.14836331672666 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark03(-88.48433631970403,-57.93282955074215 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark03(-8.862092350107574,94.49570546079397 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark03(-88.63538244307173,-26.992829761458413 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark03(-8.863776670713769,-71.46012469493218 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark03(88.67392090920113,4.316162132450486 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark03(88.70642964210387,-42.749426838682886 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark03(88.70751697001634,2552.7196356652403 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark03(-88.74611946593589,-91.65724891469583 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark03(88.75335682535088,0.0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark03(-88.7767258007108,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark03(88.80964195015227,2628.2990550888867 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-1.0964305991670074 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,11.620511771200947 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-2498.9226527706983 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,-53.68792189318798 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark03(8.881784197001252E-16,-74.46285946337166 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-76.38071476594453 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark03(-8.881784197001252E-16,-85.22826153084245 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark03(88.82353497901724,79.5849623497052 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark03(-88.83964117173713,-40.697173380462814 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark03(-88.92757213516398,-48.615745275180885 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark03(-88.97120498676145,-41.01565174034118 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark03(-88.9776715346107,-1.099446564760196 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark03(-89.03989691654408,18.760409337042958 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark03(89.06727346474733,43.426233965077586 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark03(89.08512078833951,118.82397996554258 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark03(89.17163116002251,100.0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark03(-89.17815111063243,9.669827720452439 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark03(-89.18043285196661,-15.353005492606473 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark03(-89.19218279933531,0.0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark03(89.2549232226227,-8.134449038660897 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark03(89.41861262911493,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark03(-89.42597057723194,-4.630688623048581 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark03(89.49517955827032,-6.4300669014578995 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark03(89.53536042647703,-3.020083174312559E-5 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark03(89.56770174293702,42.411500823462205 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark03(-89.62305089351244,102.69961981464934 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark03(89.64180964031254,41.54044247083766 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark03(-89.6561832488548,73.80424835940985 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark03(89.69642696786403,-50.10444611688177 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark03(89.69658627607723,0.0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark03(-89.71373021260504,51.96296621694782 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark03(-89.76424338908927,44.063903500852234 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark03(89.78598067163581,53.13883801901932 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark03(89.89278991870422,0.0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark03(89.92623487783561,0.33876279901560136 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark03(89.92713223173777,0.1267761685113979 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark03(89.93640392685397,107.01930518590771 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark03(89.93853633150206,-88.1434282177471 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark03(89.99304352441976,100.98861781198404 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark03(-90.00285742674274,2532.827382636038 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark03(-90.00454834245062,1.5707963267948966 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark03(-90.00909842203883,-90.83399762016442 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark03(-90.03136754595708,1.5707963267948912 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark03(90.05077389499371,-2.96601474458609 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark03(90.07519993319178,-25.53234792558594 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark03(-90.09973685372015,-1.5707963267948983 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark03(90.32174773340552,-1.5707963267948966 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark03(9.044969853558854,0.0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark03(-90.46284321633307,-65.22911413274855 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark03(-90.53801801955477,96.3678295207502 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark03(90.54008943320278,14.429348248450616 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark03(90.54356376558087,-12.830391973289005 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark03(90.54583072895477,68.44908017984142 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark03(90.57577425561837,80.64102536502536 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark03(-90.59708887166559,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark03(90.60886769114772,86.84841473598101 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark03(90.61268572393945,3.229065647235771 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark03(-90.64220224495882,0.0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark03(90.64930146156419,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark03(-90.66263706271273,-2646.3901536547505 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark03(-90.6701524755281,-93.79484878454694 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark03(90.67124489492839,-38.834966110696804 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark03(-90.67306476734888,-47.39994618294262 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark03(90.68868220057547,-39.01228200228002 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark03(90.7068268259334,-0.12116759889962662 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark03(-90.71823039177622,-11.395287850253425 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark03(90.72042753210195,-4.328344052809371 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark03(90.78253350359796,-37.05022931741653 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark03(-90.81585705283636,1.8068100223899792 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark03(-90.82824234485088,-73.54948275010702 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark03(90.83062587176524,44.47811083897514 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark03(-90.84074684950936,-86.36082774043663 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark03(90.84453316009638,0.3691907075927735 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark03(-90.84604125592752,2449.645180662775 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark03(-90.98382315973866,1.69316012116033 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark03(-91.01371117890544,80.09832533208098 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark03(91.01960429097645,-61.855166826153194 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark03(-91.02779200858402,-0.5707918930767139 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark03(91.05759057089193,85.73404423451788 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark03(-91.09436683867852,0.21257674294209755 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark03(91.10618564532572,-10.995574287538076 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618689181494,98.96016858840876 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618695367636,-7.853981621273276 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618695410152,-1.5707963267973843 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618695410392,-1.5707963267948966 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark03(91.10618695410399,-1.5707963267948966 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark03(91.10618695414462,-1.5707963267948897 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark03(-91.1061872543504,1.5707963267948966 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark03(-91.10618726184764,61.26105673242857 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark03(-91.10625587873012,-4.712388951452505 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark03(91.10667524008812,39.26989671132798 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark03(91.10667525358507,-130.3804311521447 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark03(-91.10822600212785,-1.5707963267948963 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark03(91.110093204104,1.5707963267948966 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark03(-91.11388833831317,-7.818923789079783 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark03(91.15448931025546,0.0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark03(-9.139060411134441,45.84136319664475 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark03(-91.45300480818803,9.854354193948708 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark03(91.54624057081776,77.92410985908508 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark03(91.61893163296963,-1.9236609372501887 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark03(-91.67840036016273,-0.9985829207361744 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark03(9.172817699531521,-71.37726111870691 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark03(91.74022021783821,-54.9778714441526 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark03(91.87825420195631,-13.63072515884096 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark03(91.88300256122443,1.5707963267948968 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark03(-91.97091355659073,76.85011464091696 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark03(91.98276203862622,67.80746435075082 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark03(-92.02465170856789,-2550.734046780295 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark03(92.03714856806847,-242.5424690392445 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark03(92.13625551226389,-25.6250145973074 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark03(92.1382160715404,1.5707963267948966 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark03(-92.19423558592348,-53.75004729176857 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark03(9.224516103290314,0.0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark03(9.225532632618323,4.9885538159082845 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark03(-92.26083509985479,-37.999127373006836 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark03(-92.29698192083484,-0.5280706372018764 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark03(-92.40648227439775,-85.98600749818313 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark03(-92.51584039030038,-31.57706942649645 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark03(-92.578475050793,-42.41171133372935 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark03(92.58041125010317,2.453061426224261 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark03(92.59815492622138,-47.710708011831215 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark03(92.60200202179124,-44.00882190031007 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark03(-92.61353248544798,-43.91884635480618 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark03(-92.6869743472064,-0.009991066307511941 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark03(-92.71563465213933,-93.90742472315203 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark03(9.274826277523587,-87.34460798178331 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark03(-9.300925885675763,-1.8116487877320117E-4 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark03(93.01700292983864,-93.81648779910547 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark03(93.09217118281926,-47.473786035928825 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark03(-93.09571824016733,5.551115123125783E-17 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark03(93.10828251190014,0.0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark03(93.10948565885198,-72.68913341051832 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark03(-93.17144749137096,1.1097528739491354 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark03(-93.1973559410534,-98.21966615177196 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark03(-93.28818568192885,9.462598389750582 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark03(9.335770553757488,-32.89771545568094 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark03(9.339875403290137,-59.9614370869415 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark03(-93.47133420437514,-1.5707963267948966 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark03(93.67180634071758,-29.971108268148758 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark03(-93.93193195369831,62.448495022779554 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark03(94.16797573634908,44.07910024336353 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark03(-94.22615270846505,-53.884928546198815 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark03(94.23653436752537,1.5864972396059223 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark03(94.23966344941051,89.54350678559238 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark03(9.424018918398566E-9,17.27875946715776 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark03(94.24763561901078,32.986722862692815 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark03(-9.424763584160177,20.42035224833365 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark03(-9.424776640432125,39.269908169870966 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark03(94.24777849624682,7.853981633392774 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777929923305,64.40264939485016 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark03(9.424777958568054,-92.67698328067165 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark03(9.424777959535689,-130.37609359636082 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777959781553,14.137166500719145 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark03(-94.24777960739412,-67.54424205218054 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960766873,-1.5707963267974034 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960768598,0.0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960769376,48.6946863765946 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark03(94.24777960769377,0.0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark03(9.424777960769378,1.5707963267948966 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark03(9.424777960769378,-48.69468613049364 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark03(-9.424777960769385,-1.5707963267948966 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark03(94.24778151504519,29.84512789106783 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark03(-94.24790811264924,76.9690200129383 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark03(9.424900031275355,-1.5707944933852553 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark03(9.425065434390984,42.411500822892556 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark03(94.28919858916814,0.0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark03(-94.29403574850241,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark03(-94.37444604107988,0.0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark03(-94.4964202956699,-40.88095529389659 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark03(-94.55186187469108,78.72497538263781 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark03(-94.59599606071983,44.194608528001964 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark03(-94.60357306814106,-46.17237881683809 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark03(-94.62867705312381,83.71909060475951 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark03(94.64166391775262,9.802487692432986E-5 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark03(-94.68180325110235,2.5707963267950613 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark03(94.6934300600035,1.950851962210684 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark03(94.71012002231576,8.584530645983001 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark03(-9.472526925374368,0.6141024657984023 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark03(-94.78828407715267,-61.58142427810091 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark03(94.8060642616604,46.12448936654539 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark03(-94.82523313754906,1.5707963267948966 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark03(94.85144147702435,-1.5707963267949054 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark03(-9.487277960769381,1.5707963267948966 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark03(-94.90241328080435,1.570796326794906 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark03(94.912106277492,0.47591523285828413 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark03(9.492977005534726,2.070796326795892 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark03(-94.93887008785215,-34.4064080517347 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark03(95.06942774572141,-14.943086860846606 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark03(95.12352943133894,90.79699613602642 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark03(95.13787728207947,0.0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark03(-95.1656151297384,-10.229029089309151 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark03(-9.529490360318498,-4.185198681133226 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark03(-95.31924361236867,-10.732889291752429 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark03(95.37837956918698,-100.0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark03(95.42184936727313,88.83790991071965 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark03(-95.42544531446198,0.0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark03(95.45781895732915,-1.5393406586602534 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark03(95.48877588164837,0.0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark03(-95.52759838904585,2.850615108146948 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark03(-9.5581039993718,0.0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark03(95.60671584131958,1.5707963267948963 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark03(9.566519383094722,72.03462058752736 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark03(-9.568226039433767,-82.15874199207687 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark03(95.69893148494867,-51.49411562341126 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark03(95.70227537319732,16.19845939740611 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark03(-95.71290592645705,0.0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark03(-95.73353431184194,5.5872113353118635 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark03(95.7339924289387,44.495339244049745 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark03(95.74856505357465,93.02241991058051 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark03(9.57759285058433,0.0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark03(9.578443530264668,67.2032344492792 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark03(95.8156679924862,-147.12757927828255 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark03(95.81738384404075,-0.0011920904479590844 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark03(-95.84502002791216,-1.5707963267949125 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark03(9.586509331668113,44.03643491474396 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark03(9.598302500274798,-72.75274441138777 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark03(96.02463061204924,-24.926686551157804 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark03(96.09763901905032,95.33213450613343 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark03(-96.13733893063865,130.46596948782008 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark03(96.22173670280122,-1.5707963267948963 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark03(-96.22518991905682,38.03328648397678 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark03(96.45234224207024,0.002139945529336114 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark03(96.46860322036724,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark03(-96.46945594628843,-37.090721048193956 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark03(96.49408463216696,89.57253334659396 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark03(-96.63302822666624,-23.06404743338581 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark03(96.6554020356072,-7.8539816339744695 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark03(9.672045832686834,-39.31899218266649 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark03(9.674777960769381,67.3905454504324 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark03(9.680400000578594,-23.16984251528271 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark03(9.68192221043188,2.070796326794897 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark03(96.89736156982707,32.93413508741503 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark03(9.693601505597599,-7.418922296250376 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark03(9.69549346233136,4.3997550157890695 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark03(96.99173828307065,-29.434102921111332 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark03(97.04803184856021,26.73918347789801 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark03(97.06532204704098,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark03(97.25286438694971,0.0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark03(97.25297559204938,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark03(-97.3893715164036,0.0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark03(-97.3893997715865,-54.977865000911784 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark03(97.40228512436812,-46.58402955638078 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark03(-97.44049228773429,-24.26858394674828 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark03(97.47343413969861,73.76055393411184 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark03(-97.4831185338078,0.0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark03(9.750328169253121,1.896454880048437 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark03(-97.50809825223908,-45.372339746329686 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark03(-97.62764603180949,-1.2984195664483673 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark03(-97.67266954738015,5.212388980384691 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark03(9.767726227719834,1.5707963267948966 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark03(-97.68597853654448,1.4777075816956007 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark03(97.68837798799476,-38.84517232575646 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark03(97.70466133151749,46.45064584193912 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark03(97.77219536225232,0.8720710734123429 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark03(97.806285082246,-20.531061605853107 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark03(-97.87502595109703,-83.08871915851263 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark03(97.92023908704547,-79.57974584077785 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark03(-97.97922110697915,-56.000709680474785 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark03(98.03992165618406,-1.815022571321066 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark03(98.07700736514195,1.5707963267948966 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark03(98.0886820421843,1.5707963267948966 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark03(-98.11096312243752,0.0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark03(-98.12681597267884,61.428762172413485 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark03(98.13312965810556,-0.17128770169594984 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark03(-9.814645648010526,2566.163832367738 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark03(98.252102341486,83.05233542891892 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark03(-98.48863384329833,-17.764485900294275 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark03(98.59508094279747,11.102802553114415 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark03(9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark03(98.62960073888672,0.9161468504838798 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark03(-98.66619425476063,95.35430461907583 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark03(98.66891813948044,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark03(-98.69068318532743,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark03(9.870127281425958,53.71568110247374 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark03(9.877596366187191,-1.815726834822187 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark03(-98.91289762369951,0.04727096437898047 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark03(98.94333720467895,0.0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark03(-98.96016858808241,2.9343596853049343E-12 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark03(-9.930907733870669,36.61441847106178 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark03(99.34764967337941,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark03(-9.937412430221187,-15.643094597174368 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark03(-99.46852071573574,-89.43699280255437 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark03(99.4696759158899,22.289335946439692 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark03(-99.49715538025683,-91.8126890008173 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark03(-99.51108536398773,-58.96992835934272 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark03(-99.52220644014254,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark03(99.52431551989255,0.0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark03(-99.70318043874443,-58.833072668047606 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark03(99.73233497520738,0.0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark03(-99.73505701736374,1.5707963267948974 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark03(99.73511346842349,37.34658892232601 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark03(9.981661458962886,-60.53342872320132 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark03(99.82629191872479,-26.929254504595264 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark03(99.8334446600647,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark03(-9.995330842247483,1.000243445316793 ) ;
  }
}
