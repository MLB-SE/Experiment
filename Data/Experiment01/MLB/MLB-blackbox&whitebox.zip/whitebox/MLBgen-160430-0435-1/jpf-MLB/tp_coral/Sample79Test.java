import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(0.005716025298918382,-85.88095553380519,94.11911401214607,100.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(0.005831654405728068,-166.80987639986114,14.98061279352916,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(0,-0.25686067185191064,187.46592688942923,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark79(0,-10.002474109770105,79.9975258902299,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark79(0,-10.351421100082774,64.50498798910894,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark79(0,-10.404745174943898,29.62188878639651,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark79(0,-112.20949746265458,67.79055978204194,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark79(0,-120.27089384458624,117.02488565478028,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark79(0,-125.92057721333316,73.5283568325518,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark79(0,13.224077593029236,13.224077593029238,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark79(0,-135.39097396817635,75.4108648113835,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark79(0,-135.76158833841976,44.238412838512566,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark79(0,-136.17005696829375,91.17581706789969,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark79(0,-148.6899230723095,80.87999631976626,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark79(0,-15.127716567000007,74.87228343299999,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark79(0,-151.39781033598288,85.89796917454663,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark79(0,-156.58275224800238,23.42965188557884,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark79(0,-162.6451644317249,17.354849336284317,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark79(0,-16.48538996958715,73.51461003041285,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark79(0,-165.6943904930581,18.604657104792977,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark79(0,-182.2314975743636,14.796193572332328,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark79(0,19.99859430014375,48.50499631531795,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark79(0,-20.07787256232573,-20.077872562325737,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark79(0,-20.897973325112854,159.10204033837812,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark79(0,-21.346684499332994,-49.521673153264125,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark79(0,22.708038273203385,7.791438484087678,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark79(0,22.899511867689725,-42.32721437911104,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark79(0,-23.432938667725153,14.808203145054094,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark79(0,-25.063160328106253,64.93683967189374,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark79(0,-2603.2524679525936,100.0,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark79(0,26.685598884196743,46.53863324550977,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark79(0,-2.7803640104378644,86.43201248859847,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark79(0,-30.34981101169467,59.65018898830533,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark79(0,-3.1514040508498837,86.84859594915011,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark79(0,-32.264823601573845,57.73517639842615,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark79(0,32.48346210844295,55.55826074807226,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark79(0,-34.98145555212646,-28.626478371722115,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark79(0,-359.7077581163411,2382.1208612633704,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark79(0,36.77410618530942,-34.27085583950419,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark79(0,-37.07229608664885,52.927703913351166,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark79(0,40.56103709905267,40.56103709905267,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark79(0,42.650417020167964,7.609440441351921,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark79(0,-43.0158130676469,-18.919965000917955,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark79(0,-43.526002442651986,169.11821088343555,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark79(0,-44.94562303650862,52.925832240037806,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark79(0,-46.62076804589221,-13.917993557206108,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark79(0,-48.81473542711071,-48.81473542711072,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark79(0,-49.351807092089,-15.33914906124187,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark79(0,-53.16303656774038,155.6480981714356,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark79(0,5.353314781401636,76.76774720099692,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark79(0,-55.28646471269861,-55.2864647126986,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark79(0,-56.10169444079345,33.898305559206534,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark79(0,-56.94949949571806,33.050500504281935,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark79(0,-62.12808698929118,28.52515756076344,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark79(0,-65.01040101310922,-18.123056704503,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark79(0,-68.03138616778595,111.9690509643228,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark79(0,-68.06597003255933,21.934029967440672,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark79(0,-69.8540228523801,-32.994449796954356,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark79(0,-69.8655905129833,20.134409487016697,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.12664399096113,95.59405298541662,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark79(0,-7.113529647489695,14.569291113806443,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark79(0,-71.13811286587506,18.861887134124927,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark79(0,-74.58402934594571,-47.704012682829934,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark79(0,-74.84501322122503,-79.55642975608046,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark79(0,-78.57045108646135,23.076213031307617,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark79(0,-80.91286973474809,100.0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark79(0,80.97764233741856,-76.14932228776992,0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark79(0,81.288448097155,89.42997328364879,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark79(0,-82.96181780417788,7.038182195822116,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark79(0,-83.26665763463103,97.99496981849697,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark79(0,-85.38697445019254,4.613025549807471,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark79(0,-85.74916821907945,94.2508454412989,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark79(0,-86.94374108611356,100.0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark79(0,-86.96091641425204,3.0390835857479654,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark79(0,-87.16785976312347,100.0,0,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark79(0,-88.09984795357637,93.02451151008282,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark79(0,88.33671367231162,88.33671367231163,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark79(0,-88.81491244728865,-2.068854562090962,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.22632745093505,116.07948822242759,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark79(0,-90.87349656814479,-90.8734965681448,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.0720641946894,-1.0720641946894087,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.15881568552891,89.05536488595736,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark79(0,-91.41834168794131,-1.4183416879413073,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.32228902964593,99.65501931345443,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark79(0,-96.50638508106789,-6.506385081067888,0,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark79(0,-9.724517227500982,53.11284969984865,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark79(0,-99.59810270039539,-9.598102700395401,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark79(-100.0,61.2181103889358,61.218110388935855,100.0,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark79(100.0,-81.66065046156471,100.0,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark79(-1.0236797577647187E-8,12.222393063781958,28.574424035638113,46.12307319608181,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark79(1.0350394804880495E-8,-59.04903780687022,-34.27456885362697,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark79(1.0508772924538538E-8,81.97564211425059,100.0,99.34237829267761,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark79(-11.80836309413489,-36.77648397874139,53.22351602125861,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark79(1.2109225906942892E-26,31.587511715286297,42.61367793453545,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark79(-1.223746411855292E-7,-44.65341825438948,136.63753479916102,3.353145141427518,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark79(-1.2385426790546591E-11,-137.29544146503363,100.0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark79(1.2733355512173628E-9,-70.21677837543884,19.783221624561165,-34.84433438001287,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark79(-1.3030657008028396E-9,-100.0,81.04674139718855,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark79(1.4717177542355237E-23,-82.94448952534448,-82.94448952534447,100.0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark79(1.6568181792761727E-7,-69.72837028539412,110.27583745304781,-4.21395041198592,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark79(-1.6803396279264842,10.333058762317776,10.333058762317782,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark79(17.777447023296062,-99.22364096957385,81.07751249506833,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark79(-17.80095620232554,-81.51411562858242,8.485884371417587,57.347234075344545,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark79(1.8915995545279515E-7,-161.65693181922114,75.55818478575392,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark79(2.0270306127004288E-34,-100.0,81.67439416363214,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark79(2.0296912059416514E-9,-100.0,100.0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark79(20.3616702481303,-81.97870935721879,8.021290642781201,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark79(-2.0642487277903029E-35,-59.80801470162951,30.19198529837048,0,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark79(-22.063387629807373,-16.334974915521308,73.66502508447869,0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark79(22.304721491740025,-89.30339780544982,0.6966021945501817,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark79(2.2818597693739144E-6,-84.94251855140881,95.3031218939817,100.0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark79(-22.92059734630834,60.666308300634455,89.18534956151709,93.8346549369789,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark79(-2.391679549075115E-16,-30.564881391196593,14.443072535451577,-100.0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark79(25.863334913940633,-47.56135748819106,42.438642511808865,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark79(-26.015964551463497,-34.34863093945776,55.65136906054223,51.43876793233261,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark79(2.6643227090644877E-15,-81.54707784590785,98.45292301078887,25.50330479545596,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark79(-2.684202397853431E-22,-190.9274954942569,41.33529272044893,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark79(2.9207394620461377E-28,-64.8347643467884,-64.83476434678839,44.37317101674886,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark79(-3.044164699881639E-32,-78.75672179336752,11.243278206632471,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark79(-31.453469928082995,-15.287675342944667,182.37705001132514,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark79(3.155925410741802E-23,-12.8717461082581,77.12825389174189,-63.321691175359106,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark79(3.2930156303878904E-23,-23.47897948257175,66.52102051742824,47.063364747825595,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark79(-3.336665617638152E-8,-99.02335142528895,82.73906774265332,52.874173061007596,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark79(33.721915204139265,-100.0,89.4305611550615,-46.348920552697884,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark79(34.71536158276217,-112.60840202270509,68.79848493056141,-96.97275556382216,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark79(-40.7549107299906,-32.56857678657181,170.62472195807408,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark79(41.56472779554027,-5.721725430313194,84.2782745696868,-4.44868331484296,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark79(42.52600137833713,-81.69112737339461,100.0,0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark79(-4.384482191229276E-13,-40.00455474503351,140.20087531176475,-52.69104579631162,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark79(-4.715252986043495E-9,-54.96189346389578,35.03810653610422,100.0,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark79(4.759654092468534E-5,-51.94614025409467,38.05385974590533,-41.3420690244713,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark79(4.782835042214462E-9,-65.57316236421357,131.23534067604254,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark79(48.89372150096992,18.531723332055037,95.35613480064649,0,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark79(-4.916235322659901E-22,-80.40960571781054,100.0,0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark79(5.084567309107505E-32,-73.84879638559366,16.151203614406324,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark79(-51.976977923457255,-51.52507732423277,34.58877485694768,0,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark79(5.289130801881857E-5,-136.72860299641727,99.53658927880745,0,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark79(56.305576630508185,-119.33662449642338,95.95406954876458,69.14695009325968,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark79(5.659449969542383E-23,-63.162403670896296,26.837596329103704,41.51054774070459,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark79(-5.704909758857265E-9,2.3102226995953075,28.857090534765746,0,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark79(57.29817998163571,-33.34721195163242,-16.208820338218686,0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark79(-57.64964669010482,-88.93777026362469,92.13471138299266,-23.086108303786006,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark79(57.941165434590516,-13.484838673247793,55.74778183869546,-1.838241428451127,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark79(5.837865703816392E-31,38.969478604324166,38.96947860432422,0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark79(58.666778889703494,-27.332659825040565,-27.332659825040558,48.832516965895536,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark79(6.103117593774746E-5,-263.38711461523127,-81.7189680978847,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark79(65.0513101945467,-88.25910001712974,1.7408999828702587,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark79(6.540460121718388E-35,-96.01516465480435,-6.015164654804353,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark79(-66.88465867964328,-50.25638030575379,-37.09985409030667,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark79(-6.893381898597354E-4,-136.15573647135992,51.35194004182052,26.895441693475476,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark79(7.0386687169677405E-22,-16.826212961939945,-16.82621296193994,0,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark79(-79.65587168514466,-37.10052577478544,52.89947422521456,0,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark79(-8.05220532904302E-5,27.297672724664196,27.297672724664203,0,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark79(8.335918507145294E-31,-44.68242900678641,45.3175709932136,0,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark79(-8.439950285614103,-34.223288253437886,55.77671174656194,0,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark79(8.46405690160737E-9,-81.46526068558875,100.0,0,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark79(8.66015275967805E-24,-48.83040528417892,-44.91460370674039,-94.48519881467776,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark79(8.73561290070242,-47.601941175942805,42.39805882405719,0,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark79(87.62217356174185,-58.034044477120794,1.5134657454863856,23.722536536633626,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark79(-89.1350818251988,-76.37922031853525,13.620779681464754,-25.529791343281133,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark79(-9.102402335730257,-53.71911483829657,-50.371580325925066,65.5250831725599,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark79(-9.274153130093891E-9,-86.3962261281639,3.6037738718360863,88.27093436632308,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark79(-9.445327338623839E-34,-88.3501203033804,1.649879696619582,0,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark79(9.747049675225724E-19,-57.61621264641632,-57.61621264641621,84.79817248387056,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark79(98.53362433973152,-1.044448906220751,4.620647453834152,-3.2290319914894496,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark79(-9.88353690278456E-30,-93.07785726721934,-3.0778572672193523,-62.069248873944936,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark79(-9.891892636034445,-92.12074088946666,-92.12074088946665,-13.59545861120839,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark79(-99.28276777484852,55.17614621886642,61.83394898425081,0,0 ) ;
  }
}
