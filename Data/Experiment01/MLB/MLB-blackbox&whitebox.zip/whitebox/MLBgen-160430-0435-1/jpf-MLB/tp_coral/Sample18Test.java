import org.junit.Test;

public class Sample18Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark18(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark18(0.04359087475644685 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark18(0.09189239564484808 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark18(0.13571685292652091 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark18(0.13742894500975922 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark18(0.26919761862551184 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark18(0.3151798340189629 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark18(0.3183204828707886 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark18(0.31906864284326275 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark18(0.36458360717051796 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark18(0.42187614999417633 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark18(0.46208103674625534 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark18(0.4840218393046314 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark18(0.7071067811865476 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark18(0.739521466269693 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark18(0.7507039495179697 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark18(0.7774860127020418 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark18(0.815868732384601 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark18(0.8307597929873936 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark18(-0.9226658249801307 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark18(0.9530023769017304 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark18(0.9554350560412388 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark18(0.9726035632637462 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark18(0.9773300420349358 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark18(0.9789556435715169 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark18(0.982731462084412 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark18(0.9854914702948364 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark18(0.9887779697636461 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark18(0.9910760677771009 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark18(0.9923477989906496 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark18(0.995736449897521 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark18(0.9961698882591123 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark18(0.9984230606630529 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark18(0.9992739117074179 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark18(0.999848299940252 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999964 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999991 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999996 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark18(-0.9999999999999998 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark18(0.9999999999999998 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark18(-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000002 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000004 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark18(-1.0000000000000009 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark18(1.0000000000000009 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark18(-1.000000000000004 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark18(-1.000151048178291 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark18(-11.118549651466964 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark18(-11.82691938960329 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark18(14.713932882396847 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark18(1.7259397098143476E-16 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark18(1.734723475976807E-18 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark18(18.665739548824803 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark18(-18.714311524499493 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark18(-18.76259405515819 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark18(2.2081423235744793E-7 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark18(2.220446049250313E-16 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark18(2.7016136048916335E-225 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark18(-29.67137957770109 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark18(3.469446951953614E-18 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark18(-40.06807543803041 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark18(4.1870973627283595E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark18(-4.374800490796744 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark18(-4.639745980663946 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark18(-4.913861584033711 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark18(-53.664076796577675 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark18(55.716427623060014 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark18(5.8751301457205045 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark18(-62.90743978594166 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark18(-6.346205812802381 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark18(-6.938893903907228E-18 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark18(78.50854972239682 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark18(-8.149590863168811E-16 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark18(-9.458210319132745E-16 ) ;
  }
}
