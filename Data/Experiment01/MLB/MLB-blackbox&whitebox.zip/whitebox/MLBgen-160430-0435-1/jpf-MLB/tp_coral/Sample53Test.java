import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(0.006101068444845245,-1.5,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(0.00819933301861025,-1.5,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(0.008822160098099949,-1.5,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.4999999999999982,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5000000000000004,0.9274128381671443 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.010255725995943436 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.010569642387973444 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.03429402574629989 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.048696137044180784 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.06255593888605013 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.07145127156795927 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.10198546627631444 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.17167913784848032 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.1904798878568883 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.19808896847519034 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.261241326928086 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.32216418648093526 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.3227844258754901 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.36208928221980585 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.37081135286905587 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.561927150306021 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.5858165477909146 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.6089021945802717 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.6116113832800375 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.6762314763813011 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.7362746523254147 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.8378893225231248 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.8402389612669904 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.8820281081493885 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.9029471878644006 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.9252152311601801 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.9518983125726788 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.9774250454099094 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.9996696283561768 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-0.9999999999999964 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,0.9999999999999982 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,1.0000000000000002 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.0000000000000018 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.0000000000025 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,1.0000000118130257 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.000000263657871 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.0635199653217038 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.210184973390412E-122 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1.4332962682114259 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-1759.1364855034535 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,20.483082422703646 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,2083.2083283704615 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,21.649349826812717 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-2194.241567561443 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,2377.003614739556 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-24.903948219978005 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,25.282759157555674 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,28.69273529916565 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-36.084453085136474 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,3.7050026486390206 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,38.12373779499178 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,4.004166190366202E-146 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,4.125099570101003E-18 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-41.60533092291159 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-4.636594412547467 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-48.32289212246157 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,51.22668063763952 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-51.83295367566124 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,5.551115123125783E-17 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,58.94115241562872 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-58.999742424366204 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,61.99305855459897 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,64.95432561891195 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,65.24328189559367 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,65.76740931466416 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-6.581843869095123E-5 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-6.850382623874694 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-70.03739514767878 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-70.38997853795111 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5708209254436936,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,71.25072981620555 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-71.63611277928139 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-77.32014365004801 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,78.92979027130525 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,79.21405055255684 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-80.7815510368373 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,80.87343458944795 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-83.62675424434589 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-89.41541784223628 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-1.5,-95.557579697897 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark53(0.017877733209549284,-1.5,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark53(0.023366756809437818,-1.5,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark53(0.02445060127714902,-1.5,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark53(0,0.3618812962101714,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark53(0.041170997945229715,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark53(0.04511825717510476,-1.5,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark53(0.048540430012128155,-1.5,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark53(0.053780511235995476,-1.5,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark53(0.06345561379210665,-1.5,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark53(0.06446498481866737,-1.5,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark53(-0.06473152768450105,-1.5,-33.14905821710052 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark53(0.0,-6.621265056287584E-24,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark53(-0.0959225179606894,-1.5,1.232595164407831E-32 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark53(0.1053720962923137,-1.5,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark53(0.128620724636491,-1.5,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark53(0,13.405712672055387,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark53(0,-14.2894946754176,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark53(0.144957360792378,-1.5,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark53(0.14631746501507337,-1.5,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.540958103719554,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark53(0,-15.524465369143854,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark53(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark53(0.18178244270421828,-1.5,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark53(0.20417870713293043,-1.5,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark53(0.20466021406170032,-1.5,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark53(0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark53(0,2.3223401500591813E-17,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark53(0.24093097341282155,-1.5,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark53(0.24469609282651583,-1.5,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark53(0.24700861553226616,-1.5,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark53(0.26063678762425013,-1.5,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark53(0,-2631.4591977450727,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark53(-0.26884993770738974,-1.5,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark53(0,-2738.3157941111494,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark53(0.27837464768177256,-1.5,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark53(0,-27.982838201924537,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark53(0.28268178998455085,-1.5,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark53(0.3116899100791102,-1.5,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark53(0.3250216181767658,-1.5,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark53(0.32636036509156807,-1.5,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark53(0.3523739980758194,-1.5,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark53(0.3586662083181462,-1.5,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark53(0.3715988967043587,-1.5,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark53(0.40368370971346224,-1.5,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark53(0.41093193576948117,-1.5,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark53(0.4170943476367674,-1.5,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark53(0.42052582222831525,-1.5,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark53(-0.4284945680900424,-1.5,58.16265725755425 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark53(0,-43.223820432141395,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark53(0.44082558928081805,-1.5,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark53(0,-44.513286543448416,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark53(0.45059529572590407,-1.5,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark53(0.4539408747098366,-1.5,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark53(0.4689574915108836,-1.5,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark53(0.4773878233201003,-1.5,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark53(-0.4807648603373227,-1.5,1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark53(0,-49.364993639875806,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark53(0.49644227722054207,-1.5,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark53(0.5072719304053583,-1.5,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark53(0.5116139755684301,-1.5,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark53(0,-5.255700625686572,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark53(0.5267994198498656,-1.5,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark53(0,-5.413720018864069,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark53(0.5605152071786315,-1.5,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark53(0.5638195152351191,-1.5,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark53(0.5735687549327638,-1.5,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark53(0,61.61368192955209,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark53(0,-64.68257468208047,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark53(0.6582404958129984,-1.5,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark53(0.6590545066173661,-1.5,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark53(0,-66.66542211920519,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark53(0.6780794036832134,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark53(0.7083721624408934,-1.5,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark53(0.7147759636322932,-1.5,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark53(0.741773712502222,-1.5,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark53(0,-74.63592257004893,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark53(0.8194487964933361,-1.5,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark53(0.8415669893519606,-1.5,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark53(0.8436313526503012,-1.5,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark53(0,-85.06501319013837,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark53(0.8541976689599006,-1.5,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark53(0.8794556232055442,-1.5,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark53(0.886769434402392,-1.5,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark53(0.8923274117706512,-1.5,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark53(0.8965743018412411,-1.5,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark53(0.9041213576516753,-1.5,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark53(0.9068111670879238,-1.5,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark53(0.9255976740031286,-1.5,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark53(0.926886392461725,-1.5,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark53(0.9389788560781369,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark53(0.946386509750881,-1.5,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark53(0.9703716750006619,-1.5,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark53(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark53(0.9902991211431829,-1.5,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.4999999999999996,1.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000007,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000016,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark53(100.0,-1.5000000000000036,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5000000000000036,100.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,0.0625528895499694 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,0.2698720572349006 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,0.3620904937651959 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,0.5136429366268551 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-0.5505690591093328 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-0.6706255197065584 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,0.8118592927636074 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-0.999999999999997 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-0.9999999999999989 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-1.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,1.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-100.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-1.0000000000000002 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,1.0000000760130572 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-29.820057288283223 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-4.2030456845295373E-286 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-6.746113636599542E-9 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,-68.9623493373737 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,7.498484069478155E-242 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark53(-100.0,-1.5,9.860761315262648E-32 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark53(10.010291304746417,-1.5,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark53(10.034951171321765,-1.5,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark53(10.060558183271183,-1.5,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark53(10.063080621800701,-1.5,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark53(10.075650979090227,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark53(10.140502216496245,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark53(10.150890465549628,-1.5,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark53(10.163459919169583,-1.5,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark53(10.174808221173425,-1.5,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark53(10.177925992241683,-1.5,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark53(10.193959192581062,-1.5,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark53(10.197023845636899,-1.5,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark53(10.224351279899608,-1.5,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark53(10.226256411068961,-1.5,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark53(10.232199699221376,-1.5,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark53(10.251796976525938,-1.5,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark53(10.283717704159628,-1.5,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark53(10.288665075637374,-1.5,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark53(-1.0362840948163239,-1.5,96.58254742188043 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark53(10.36954665947748,-1.5,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark53(10.391671275326246,-1.5,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark53(10.4007493595551,-1.5,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark53(10.403922860158778,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark53(10.408528488329544,-1.5,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark53(1.040921737957243,-1.5,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark53(10.497100474815898,-1.5,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark53(10.57674320919179,-1.5,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark53(10.604194409494829,-1.5,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark53(1.0689637146049527,-1.5000000000000007,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark53(1.069936128327802,-1.5,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark53(10.79451810339366,-1.5,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark53(1.0798358102679675,-1.5,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark53(10.802592651124318,-1.5,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark53(10.839864967013114,-1.5,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark53(10.897554677104011,-1.5,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark53(10.90038374704443,-1.5,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark53(1.0946643578799211,-1.5,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark53(10.947826440539242,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark53(10.959415006371536,-1.5,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark53(11.003800777694355,-1.5,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark53(11.009877412493381,-1.5,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark53(11.019380111822702,-1.5,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark53(11.028917113476806,-1.5,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark53(11.032759178812732,-1.5,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark53(-1.1102230246251565E-16,-1.5,0.6397765635361049 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark53(11.114552973853623,-1.5,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark53(11.1279852908108,-1.5,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark53(11.132315643126443,-1.5,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark53(1.113247760707381,-1.5,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark53(-11.176603430558838,-1.5000000000000002,2333.893543744839 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark53(11.200660381262018,-1.5,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark53(11.219240011581256,-1.5,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark53(11.26161467065305,-1.5,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark53(11.298857965431608,-1.5,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark53(11.309824744389502,-1.5,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark53(11.317249305141956,-1.5,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark53(1.1323529846008853,-1.5,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark53(1.1323662192866797,-1.5,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark53(-11.374356553535872,-1.5,0.9999999909370371 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark53(1.1410091371274418,-1.5,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark53(11.434752759580476,-1.5,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark53(11.46388600005243,-1.5,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark53(11.521473348007476,-1.5,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark53(11.549848796294935,-1.5,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark53(11.590501941822467,-1.5,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark53(11.616879302976216,-1.5,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark53(11.647198366733775,-1.5,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark53(-11.64899886279061,-1.5,-1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark53(11.661328335400782,-1.5,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark53(11.680451280587874,-1.5,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark53(-11.704174008355494,-1.5,-1.0000000082039273 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark53(11.760624732016183,-1.5,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark53(11.805305607453604,-1.5,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark53(11.827704364896974,-1.5,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark53(11.83716919887687,-1.5,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark53(11.854463293574682,-1.5,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark53(11.873419955747242,-1.5,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark53(11.886280767563221,-1.5,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark53(11.88989726906859,-1.5,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark53(11.949225542390394,5.3217026539963825,-32.25643698008098 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark53(11.963074468917775,-1.5,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark53(11.979047631959716,-1.5000000000000013,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark53(-11.995657408763073,-1.5,-11.840583096591207 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark53(1.199769409887267,-1.5,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark53(12.010997180373831,-1.5,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark53(12.053602316891855,-1.5,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark53(12.059234515465846,-1.5,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark53(12.059689222019358,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark53(12.060492476671865,-1.5,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark53(12.06430384285327,-1.5,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark53(12.081891511897378,-1.5,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark53(1.210184973390412E-122,-1.5,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark53(12.105209829117655,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark53(12.116550675261323,-1.5,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark53(1.2123462517114048,-1.5,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark53(1.218772639570092,-1.5,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark53(12.198719327394635,-1.5,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark53(12.322749497579125,-1.5,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark53(12.340319023028073,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark53(-12.34085439998379,-1.5,57.242735744526826 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark53(12.380365269526507,-1.5,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark53(12.40716130674808,-1.5,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark53(12.429668906700755,-1.5,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark53(12.458995947793142,-1.5,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark53(-12.472348557914813,-63.49028026924677,55.10658685237922 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark53(12.474960793325543,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark53(12.531476133026054,-1.5,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark53(12.54402593052543,-1.5,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark53(12.54447620729773,-1.5,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark53(12.544987354222044,-1.5,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark53(1.2575193408187744,-1.5,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark53(12.580901692693848,-1.5,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark53(12.600326120629514,-1.5,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark53(12.605633303526972,-1.5,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark53(12.636138544992406,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark53(12.660089412384636,-1.5,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark53(12.666871213648953,-1.5,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark53(12.675853018817108,-1.5,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark53(12.756956191044182,-78.04158460872783,-75.19636697042068 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark53(12.787732408241226,-1.500000000000003,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark53(-12.807610389147783,-1.5,1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark53(12.82621862101067,-1.5,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark53(12.85800763468805,-1.5,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark53(12.879518082762573,-1.5,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark53(12.91393149497734,-1.5,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark53(12.93595099911661,-1.5,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark53(12.940446114925095,-1.5,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark53(12.97966923395279,-1.5,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark53(13.030738138085638,-1.5,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark53(13.062307704009868,-1.5,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark53(13.065847254190864,-1.5,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark53(13.070140059525464,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark53(13.089341759612694,-1.5,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark53(13.109992723939238,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark53(13.111073960899576,-1.5,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark53(1.313764511585716,-1.5,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark53(13.138736567632103,-1.5,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark53(13.14733084861515,-1.5,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark53(13.197353567498055,-1.5,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark53(13.197903722795473,-1.5,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark53(13.21081844279949,-1.5,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark53(13.285350612250607,-1.5,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark53(13.294272493478275,-1.5,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark53(13.29989386970216,-1.5,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark53(13.325921311882096,-1.5,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark53(13.358564985601937,-1.5,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark53(13.428559819688203,-1.5,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark53(13.44377525350769,-1.5,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark53(13.463721342859017,-1.5,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark53(13.47210947391641,-1.5,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark53(13.472512545300942,-1.5,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark53(13.551705469085391,-1.5,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark53(13.562200234518313,-1.5,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark53(13.594518334353808,-1.5,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark53(13.608619224305178,-1.5,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark53(13.664858480911493,-1.5,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark53(-13.73812029774183,-1.5,-66.3125510063042 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark53(1.3779463293257432,-1.5,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark53(13.792529125922858,-1.5,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark53(13.796699405149855,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark53(-13.803813079320548,-1.499999999999999,-2400.835232170027 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark53(13.818229489758963,-1.5,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark53(-13.83914500395557,-1.5,25.11834720847127 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark53(13.85979734513999,-1.5,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark53(13.86158871633194,-1.5,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark53(1.386445227616349,-1.5,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark53(13.87680181567386,-1.5,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark53(13.913202815331701,-1.5,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark53(13.91828472713491,-1.5,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark53(1.3932714914619737,-1.5,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark53(13.967317546197663,-1.5,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark53(13.975265228607,-1.5,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark53(1.3989585138237395,-1.5,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark53(13.991449831375874,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark53(-1.4008018431608988,-1.5,0.8175773495138933 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark53(14.044414960872516,-1.5,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark53(14.057509608120629,-1.5,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark53(14.079188370528739,-1.5,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark53(1.4080273042311306,-1.5,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark53(14.083657261436862,-1.5,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark53(14.100922686869096,-1.5,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark53(14.10723377974782,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark53(14.124900336216122,-1.5,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark53(14.134951432548544,-1.5,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark53(14.154877289407565,-1.5,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark53(14.155950450815212,-1.5,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark53(14.196314611174017,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark53(14.19843125895133,-1.5,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark53(14.235200810289793,-1.5,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark53(14.2423588781919,-1.5,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark53(14.25796227183642,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark53(1.430222333808547E-247,-1.5,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark53(14.311618967731388,-1.5,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark53(14.3335442684287,-1.5,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark53(14.338931773409188,-1.5,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark53(14.356790128008747,-1.5,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark53(14.391195518619355,-1.5,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark53(14.51159734091491,-1.5,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark53(14.550372256617948,-1.5,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark53(1.4561882661311643,-1.5,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark53(14.566820321550395,-1.5,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark53(14.609356704914914,-1.5,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark53(14.628260779798087,-1.5,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark53(14.643353657767863,-1.5,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark53(14.652151874021044,-1.5,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark53(14.679003488442206,-1.5,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark53(14.704026071678875,-1.5,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark53(14.785988835514402,-1.5,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark53(1.4805454629894317,-1.5,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark53(1.4855744412711118,-1.5,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark53(14.861782647577108,-1.5,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark53(14.97012604751771,-1.5,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark53(15.03068129599805,-1.5,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark53(15.06533894610497,-1.5,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark53(1.509412257517095E-17,-1.5,2.060223529971233E-16 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark53(15.176366811858102,-1.5,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark53(15.205587760909808,-1.5,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark53(15.224932365886126,-1.5,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark53(15.326647982894244,-1.5,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark53(-15.341606081109308,-1.5,-23.086458524656237 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark53(15.442377193361011,-1.5,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark53(15.470826644370018,-1.5,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark53(15.49342414453875,-1.5,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark53(15.560933530708507,-1.5,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark53(-15.568100699540707,-1.5,1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark53(15.574032354606373,-1.5,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark53(15.589430066499938,-1.5,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark53(15.611293140307467,-1.5,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark53(15.628359021794493,-1.5,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark53(-15.631058719115611,-1.5,-37.917101486532395 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark53(15.644623305577035,-1.5,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark53(15.701142793114203,-1.5,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark53(15.703267994449476,-1.5,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark53(15.715059958853434,-1.5,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark53(15.722098691203442,-1.5,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark53(1.5807068739104153,-1.5,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark53(15.874845990469993,-1.5,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark53(15.898166380266048,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark53(15.904731919256037,-1.5,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark53(15.937635099926425,-1.5,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark53(15.959706555612058,-1.5,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark53(15.964443778042513,-1.5,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark53(15.96670522959619,-1.5,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark53(1.5971212803227068,-1.5,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark53(16.029010911481052,-1.5,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark53(16.06830921559508,-1.5,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark53(16.07489330755137,-1.5,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark53(16.085702323043247,-1.5,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark53(16.088759940925584,-1.5,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark53(16.121498272783768,-1.5,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark53(16.133590581422823,-1.5,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark53(1.6155060987643708,-1.5,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark53(16.186320729711838,-1.5,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark53(16.186951997871148,-1.5,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark53(16.221450082103814,-1.5,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark53(16.23682909401276,-1.5,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark53(16.25304080236698,-1.5,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark53(16.261889817129465,-1.5,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark53(16.26339760723721,-1.5,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark53(16.31989042593372,-1.5,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark53(-16.34094377097074,-1.5,0.905153271146844 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark53(16.401499884100343,-1.5,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark53(16.41883981620968,-1.5,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark53(16.419774496426783,-1.5,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark53(16.422987864017855,-1.5,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark53(16.435316182104074,-1.5,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark53(16.482950277007255,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark53(16.49182671586172,-1.5,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark53(16.506152858231964,-1.5,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark53(16.518427631855573,-1.5,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark53(16.542607544214547,-1.5,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark53(16.57894471563897,-1.5,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark53(16.615455550645137,-1.5,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark53(16.636504628939903,-1.5,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark53(16.71201235486628,-1.5,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark53(16.715556197250187,-1.5,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark53(16.717969439750835,-1.5,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark53(16.77619840391504,-1.5,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark53(16.824007758485607,-1.5,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark53(16.88620886454089,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark53(16.90458284474945,-1.5,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark53(1.6911218176258513,-1.5,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark53(16.925570116162987,-1.5,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark53(16.948698316958684,-1.5,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark53(16.989841345726923,-1.5,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark53(17.061906413424325,-1.5,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark53(17.083998407050814,-1.5,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark53(17.106335867241416,-1.5,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark53(17.150128635954005,-1.5,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark53(17.179179854568332,-1.5,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark53(1.720872969003411,-1.5,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark53(17.227426413675914,-44.161570005215324,87.52781544922271 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark53(17.23078972378834,-1.5,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark53(17.240816431142207,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark53(17.273993917343688,-1.5,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark53(17.28741241268798,-1.5,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark53(17.32561936094514,-1.5,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark53(1.734723475976807E-18,-1.5,-1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark53(17.359853287557872,-1.5,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark53(17.384562321914387,-1.5,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark53(17.399505850863324,-1.5,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark53(17.440124619757142,-1.5,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark53(17.46358619398316,-1.5,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark53(17.470318039957302,-1.5,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark53(17.543326894543455,-1.5,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark53(17.565029444582745,-1.5,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark53(17.596406818352733,-1.5,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark53(17.670352406619358,-1.5,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark53(17.67774581041543,-1.5,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark53(17.715787085299112,-1.5,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark53(17.72006712917505,-1.5,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark53(17.731334484486453,-1.5,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark53(17.74747496991449,-1.5,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark53(17.795097243957645,-1.5,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark53(17.80671971893402,-1.5,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark53(17.837282137605158,-1.5,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark53(17.848733110344185,-1.5,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark53(1.7858803704470692,-1.5,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark53(17.863046910882005,-1.5,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark53(17.874163931964727,-1.5,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark53(-17.888245042733068,-1.5,-19.98869809337221 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark53(17.940908339412577,-1.5,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark53(17.94585845727346,-1.5,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark53(1.7969200138026338,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark53(17.990179358180473,-1.5,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark53(18.006867891780146,-1.5,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark53(18.071672186282807,-1.5,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark53(18.108296152785957,-1.5,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark53(18.195090482861442,-1.5,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark53(1.8198292810008212,-1.5,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark53(18.212259099521688,-1.5,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark53(1.8214491140842703,-1.5,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark53(1.8272364287833085,-1.5,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark53(-18.305889765212406,-1.5,1.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark53(18.425302550315347,-1.5,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark53(18.434570989587925,-1.5,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark53(18.498411679722455,-1.5,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark53(-18.50101408256135,-1.5,0.9743103791233837 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark53(1.8515058771620456,-1.5,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark53(1.8588759314385372,-1.5,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark53(18.639024736529436,-1.5,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark53(18.72656596746809,-1.5,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark53(18.73868473422766,-1.5,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark53(18.758138883890524,-1.5,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark53(18.763127440275795,-1.5,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark53(18.784855085509818,-1.5,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark53(18.78528797413651,-1.5,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark53(1.881013217483635,-1.5,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark53(18.82961831731258,-1.5,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark53(18.858672331186973,-1.5,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark53(18.912505061212528,-1.5,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark53(19.00074711641537,-1.5,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark53(19.02375578042627,-1.5,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark53(-19.057680345013214,-1.5,0.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark53(19.082165905251678,-1.5,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark53(19.16440047898377,-1.5,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark53(19.216038180774806,-1.5,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark53(1.9310338718678821,-1.5,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark53(19.31583228274461,-1.5,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark53(19.321654123893623,-1.5,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark53(19.32983897495872,-1.5,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark53(1.9371399465980943,-1.5,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark53(19.391098998900873,-1.5,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark53(19.426905899067208,-1.5,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark53(19.430155478367077,-1.5,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark53(1.9440021140924384,-1.5,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark53(1.9470149777989325,-1.5,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark53(19.47904336097296,-1.5,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark53(19.49914220565064,-1.5,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark53(19.57729279787085,-1.5,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark53(19.60783526916545,-1.5,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark53(19.625820071535657,-1.5,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark53(19.687134456225575,-1.5,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark53(19.714124466278026,-1.5,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark53(1.9723708449867026,-1.5,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark53(19.731797249217507,-1.5,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark53(19.742047025711827,-1.5,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark53(19.79502144856242,-1.5,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark53(19.797940375993534,-1.5,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark53(19.888941348402923,-1.5,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark53(19.892827451044084,-1.5,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark53(-19.93729689764083,-1.5,10.286391072983292 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark53(-19.941317106210207,-1.5,33.19700109546625 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark53(19.957668850151737,-1.5,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark53(19.962538637460682,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark53(19.96704036536094,-1.5,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark53(19.977443113420577,-1.5,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark53(19.988499046085323,-1.5,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark53(2.00453780843882,-1.5,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark53(20.100052594165987,-1.5,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark53(20.124719235516224,-1.5,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark53(20.156957078789194,-1.5,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark53(20.184954983620543,-1.5,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark53(20.23660816109939,-1.5,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark53(20.277069433438328,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark53(20.299704144951924,-1.5,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark53(2.031547527341004,-1.5,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark53(20.339631859197716,-1.5,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark53(20.345907963036282,-1.5,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark53(20.39868809922163,-1.5,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark53(20.451439695004918,-1.5,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark53(-20.467471575362623,-1.5,61.068711529456806 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark53(20.507010988020028,-1.5,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark53(20.558583352990635,-1.5,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark53(20.56343942601337,-1.5,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark53(20.64284117792485,-1.5,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark53(20.723638730919678,-1.5,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark53(2.075543322597568,-1.5000000000000027,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark53(20.821461469235906,-1.5,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark53(2.0850830072506894,-1.5,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark53(20.869672880339053,-1.5,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark53(20.869779346476722,-1.5,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark53(20.87388125917746,-1.5,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark53(20.902575222761566,-1.5,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark53(20.95174525309541,-1.5,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark53(20.982031458667265,-1.5,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark53(20.987531083696894,-1.5,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark53(21.006429964337467,-1.5,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark53(21.042714928526024,-1.5,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark53(21.053093683508443,-1.5,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark53(21.054862534014386,-1.5,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark53(21.066368713976274,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark53(21.09127522792997,-1.5,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark53(21.124178819112103,-1.5,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark53(21.136250849300126,-1.5,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark53(2.1138527434174677,-1.5,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark53(21.14035364817917,-1.5,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark53(-21.25636373267005,-1.5,-1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark53(21.260426854163057,-1.5,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark53(21.298675691348045,-1.5,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark53(21.3165117972125,-1.5,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark53(21.359404057770377,-1.5,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark53(21.36593643417266,-1.5,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark53(21.369027064333224,-1.5,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark53(21.374374921994516,-1.5,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark53(21.399063438427383,-1.5,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark53(21.421228072149717,-1.5,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark53(21.4355510937267,-1.5,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark53(21.455566632469736,-1.5,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark53(21.531719482583693,-1.5,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark53(21.536340970491338,-1.5,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark53(21.539968367300464,-1.5,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark53(21.56217954706628,-1.5,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark53(21.60097626480362,-1.5,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark53(21.613219034934943,-1.5,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark53(21.614488065678387,-1.5,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark53(21.672449430672486,-1.5,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark53(21.69758820020426,-1.5,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark53(-21.698103963228107,-1.5,1.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark53(21.71165768398601,-1.5,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark53(21.731123240217357,-1.5,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark53(2.173249137522742,-1.5,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark53(21.764218772107967,-1.5,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark53(21.803826366885435,-1.5,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark53(21.853737972656432,-1.5,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark53(21.854772896897153,-1.5,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark53(21.879732170666195,-1.5,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark53(21.89483296954387,-1.5,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark53(21.89729932969871,-1.5,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark53(21.904285499426443,-1.5,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark53(21.913880173429263,-1.5,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark53(21.92936952552337,-1.5,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark53(21.94362906871071,-1.5,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark53(2.1973785885943613,-1.5,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark53(2.1985830490048928,-1.5,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark53(2.2005591586252507E-15,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark53(22.01993302687704,-1.5,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark53(22.026757327441445,-1.5,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark53(-22.032994517494267,-1.5,3.8264538937310704 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark53(22.03598237379304,-1.5,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark53(22.060258010102316,-1.5,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark53(2.2095687861457094,-1.5,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark53(2.213921675207206,-1.5,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark53(22.160726722019994,-1.5,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark53(22.181312309462548,-1.5,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark53(-2.22015793030094,-1.5,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark53(22.236275622878022,-1.5,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark53(22.29119466180807,-1.5,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark53(2.229501791860155,-1.5,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark53(22.34045285335646,-1.5,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark53(22.386247836679615,-1.5,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark53(2.2390920968342103,-1.5,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark53(2.240572103567146,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark53(22.409910983157516,-1.5,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark53(22.427522363880726,-1.5,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark53(22.44388368677488,-1.5,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark53(22.502783293276195,-1.5,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark53(2.2514021533572723,-1.5,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark53(22.553427672967253,-1.5,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark53(22.55759555878494,-1.5,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark53(22.584202724376667,-1.5,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark53(-2.2655595283449114E-13,-1.5,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark53(22.658275268194217,-1.5,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark53(22.666390090226066,-1.5,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark53(22.67926445875838,-1.5,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark53(22.697558279243843,-1.5,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark53(22.711425726118186,-1.5,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark53(22.722567273246895,-1.5,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark53(22.739158585169484,-1.5,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark53(22.746715380839937,-1.5,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark53(22.76014457453475,-1.5,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark53(22.766074203891165,-1.5,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark53(22.81378567427164,-1.5,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark53(22.838744983005753,-1.5,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark53(22.848807735896,-1.5,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark53(22.85290230485775,-1.5,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark53(22.855034922895385,-1.5,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark53(22.863840371083146,-1.5,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark53(-22.86523452928579,-1.5,1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark53(22.91548336501826,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark53(22.94179292455199,-1.5,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark53(22.945143920882348,-1.5,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark53(22.976196128218547,73.14003666243869,27.223271070571272 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark53(23.039239284398363,-1.5,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark53(23.04093937074825,-1.5,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark53(23.06366543565885,-1.5,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark53(2.3092820214926286,-1.5,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark53(2.3146987429442163,-1.5,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark53(23.167876491134166,-1.5,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark53(23.183066976800802,-1.5,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark53(2.3184519966010537,-1.5,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark53(23.22320315576088,-1.5,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark53(23.235838386897225,-1.5,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark53(23.26909493314335,-1.5,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark53(23.355332819850695,-1.5,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark53(23.372240786983934,-1.5,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark53(23.444898802184397,-1.5,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark53(23.44587507171286,-1.5,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark53(23.45713914063253,-1.5,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark53(23.464022951474163,-1.5,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark53(23.467435892461694,-1.5,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark53(2.3470701924444626,-1.5,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark53(23.50213768730725,-1.5,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark53(23.52097353343912,-1.5,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark53(23.55258096076465,-1.5,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark53(23.570337303043697,-1.5,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark53(23.58373102165004,-1.5,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark53(23.59652574327174,-1.5,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark53(23.610770640384217,-1.5,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark53(23.632796193778375,-1.5,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark53(23.636078875661326,-1.5,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark53(23.662134236098147,-1.5,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark53(23.662837403540365,-1.5000000000000013,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark53(23.69783005956087,-1.5,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark53(23.729767498975978,-1.5,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark53(2.373263268956535,-1.5,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark53(23.74199796229628,-1.5,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark53(23.744558337046612,-1.5,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark53(23.761002192015166,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark53(23.794611862721464,-1.5,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark53(-23.814208914335364,-1.5,-0.5565166220677789 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark53(23.853104098664023,-1.5,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark53(23.885204568317807,-1.5,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark53(23.891932771438945,-1.5,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark53(23.905619562773936,-1.5,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark53(23.92353836098738,-1.5,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark53(23.93075718047374,-1.5,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark53(23.96758559754264,-1.5,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark53(23.991855568362244,-1.5,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark53(24.0212854411255,-1.5,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark53(24.030332874123616,-1.5,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark53(24.04537705530747,-1.5,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark53(24.049801737418676,-1.5,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark53(24.050378364439872,-1.5,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark53(24.089477449365333,-1.5,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark53(24.126904865012477,-1.5,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark53(24.158866691266507,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark53(24.184348630471806,-1.5,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark53(2.4257679836855317,-1.5,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark53(24.275416595942986,-1.5,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark53(24.32674759220781,-1.5,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark53(24.328406348766336,-1.5,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark53(2.4331285708918866,-1.5,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark53(24.391992657822435,-1.5,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark53(24.398266474245236,-1.5,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark53(24.406159631107045,-1.5,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark53(24.44452799523183,-1.5,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark53(24.48396757897113,-1.5,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark53(24.532631919501696,-1.5,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark53(24.614173451263817,-1.5,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark53(24.652828934853922,-1.5,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark53(2.4664573023092227,-1.5,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark53(24.72142375068057,-1.5,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark53(24.72460081201769,-1.5,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark53(24.73896758752533,-1.5,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark53(24.793173462433373,-1.5,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark53(24.867840754484718,-1.5,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark53(2.4926687722243765E-15,-1.5,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark53(2.4932351842823763,-1.5,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark53(24.934925466151142,-1.5,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark53(2.499784054138118,-1.5,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark53(25.00413540739936,-1.5,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark53(25.032283368608024,-1.5,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark53(25.04811795426411,-1.5,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark53(25.059622270676645,-1.5,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark53(25.066185072278287,-1.5,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark53(25.1420958217347,-1.5,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark53(25.157416330105463,-1.5,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark53(25.19109390187913,-1.5,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark53(25.22994925468649,-1.5,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark53(25.239461753666045,-1.5,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark53(25.279738434781784,-1.5,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark53(25.294687325407544,-1.5,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark53(-25.326146231338797,-1.5,0.9667945605179729 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark53(25.37595644168224,-1.5,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark53(25.391799451181264,-1.5,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark53(25.468220516468335,-1.5,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark53(25.474789706512166,-1.5,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark53(25.487574570256143,-1.5,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark53(25.488533764612697,-1.5,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark53(25.511610052171505,-1.5,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark53(25.525880784978014,-1.5,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark53(25.54708395733229,-1.5,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark53(25.547545465247385,-1.5,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark53(25.55406398771774,-1.5,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark53(25.60301226798304,-1.5,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark53(25.623556433540216,-1.5,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark53(25.633795926325796,-1.5,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark53(25.646357329386646,-1.5,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark53(25.72931358196506,-1.5,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark53(25.79210168416853,-1.5,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark53(25.807529009897447,-1.5,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark53(25.818270419175732,-1.5,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark53(25.820236291130854,-1.5,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark53(-25.861264380464085,-1.5,-0.2857301139554487 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark53(25.885799541081028,-1.5,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark53(25.88726483124941,-1.5,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark53(25.92454147830547,-1.5,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark53(25.944524663193487,-1.5,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark53(25.95301984230834,-1.5,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark53(25.954214334321566,-1.5,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark53(25.957272513556845,-1.5,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark53(-26.010653790478095,-1.5,1.000000000000011 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark53(26.016422741308247,-1.5,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark53(-2.6017563335155955,-1.5,-0.0577194189941788 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark53(26.051992002242258,-1.5,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark53(26.05363628749086,-1.5,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark53(26.078964433248046,-1.5,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark53(26.0837798651005,-1.5,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark53(26.106365515664834,-1.5,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark53(-26.121448786246873,-1.5,3.7805226712523847 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark53(26.12860448622755,-1.5,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark53(26.13915305499204,-1.5,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark53(26.155017573120315,-1.5,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark53(26.19416863728128,-1.5,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark53(26.21957553816086,-1.5,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark53(26.234359792472034,-1.5,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark53(26.279776121190444,-1.5,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark53(26.34066814261993,-1.5,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark53(26.36642464432168,-1.5,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark53(26.381588580736523,-1.5,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark53(26.42018110686554,-1.5,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark53(2.6441302736864998,-1.5,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark53(-26.44190893139431,-1.5,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark53(26.46820503456934,-1.5,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark53(2.6509496813806592,-1.5,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark53(26.557205418873565,-1.5,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark53(26.618503007602722,-1.5,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark53(-26.63619074959678,-27.742696221665568,90.25442981627225 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark53(2.6637491398959696,-1.5,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark53(26.661248750767335,-1.5,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark53(26.680631859846184,-1.5,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark53(26.70363393299111,-1.5,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark53(26.7163972824263,-1.5,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark53(26.743124198312813,-1.5,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark53(-26.821111623408644,-1.5,0.23833194408427263 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark53(26.857323244421945,-1.5,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark53(26.859742532918318,-1.5,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark53(26.879727557050828,-1.5,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark53(26.89100783376213,-1.5,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark53(26.931839120143366,-1.5,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark53(26.940979717607732,-1.5,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark53(26.951818667027954,-1.5,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark53(2.696841036099629,-1.5,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark53(27.062544842580678,-1.5,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark53(27.080288403850346,-1.5,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark53(27.09961459993381,-1.5,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark53(-2.710505431213761E-20,-1.5,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark53(27.164593836502533,-1.5,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark53(27.217503845387952,-50.79059266510932,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark53(27.226548360283758,-1.5,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark53(27.234488115702742,-1.5,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark53(27.255160870225993,-1.5,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark53(-27.25806469629626,-1.5,-0.7577002337912262 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark53(27.28394235297418,-1.5,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark53(27.28932331022831,-1.5,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark53(27.304586068802067,-1.5,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark53(27.323998134332328,-1.5,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark53(-27.36040691092774,-1.5,-1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark53(27.463603849529235,-1.5,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark53(27.470907968025003,-1.5,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark53(27.475889635404247,-1.5,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark53(-2.748381761336053,-1.5,-6.922948204395988 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark53(27.487916472394772,-1.5,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark53(2.751309880197666,-1.5,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark53(27.531480732739077,-1.5,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark53(27.54882299254383,-1.5,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark53(27.566568941135145,-1.5,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark53(2.7590763311292026,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark53(27.609378424363257,-1.5,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark53(27.6473273686086,-1.5,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark53(27.66749114880117,-1.5,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark53(27.670702945093353,-1.5,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark53(27.720099574635107,-1.5,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark53(-2.7744348873340763,-1.5,0.8493842431693834 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark53(27.75174892017076,-1.5,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark53(27.77087877046704,-1.5,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark53(27.77605699409188,-1.5,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark53(2.782367263470853,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark53(27.828419154056245,-1.5,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark53(27.83322052543724,-1.5,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark53(27.921821456163137,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark53(27.982228680617823,-1.5,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark53(27.983501804089943,-1.5,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark53(2.8000664557762334,-1.5,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark53(28.01461944336185,-1.5,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark53(28.025730862396507,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark53(28.059739949647877,-1.5,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark53(28.06056481284837,-1.5,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark53(28.07712034305908,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark53(28.0817697481001,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark53(2.8085282483465726,-1.5,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark53(28.149370321396873,-1.5,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark53(-28.180238486477478,-1.5,-6.762794588191198 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark53(28.18879761030678,-1.5,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark53(28.256746955467662,-1.5,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark53(28.26070189910456,-1.5,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark53(-28.273647596749775,-1.5,-0.06056266903724866 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark53(28.34139093719307,-1.5,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark53(28.37394589529082,-1.5,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark53(28.403297614587842,-1.5,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark53(2.8416683563213603,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark53(28.491294301159684,-1.5,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark53(28.491490712876143,-1.5,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark53(28.504320525260226,-1.5,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark53(28.578831126527433,-1.5,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark53(28.586419837141165,-1.5,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark53(28.605186269567213,-1.5,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark53(28.60568567950083,-1.5,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark53(28.6140572026504,-1.5,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark53(28.662698047174274,-1.5,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark53(28.666364797107633,-1.5,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark53(28.677419829691118,-1.5,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark53(28.72142933539056,-1.5,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark53(28.758099013580797,-1.5,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark53(28.77111215871514,-1.5,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark53(2.878024745925419,-1.5,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark53(28.78124431782078,-1.5,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark53(28.787521346069013,-1.5,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark53(28.820424909130082,-1.5,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark53(28.86765575638438,-1.5,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark53(28.877904822231784,-1.5,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark53(28.88319659860949,-1.5,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark53(-2.890022363137976,-1.5,1.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark53(28.913163159674838,-1.5,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark53(28.969801078027846,-1.5,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark53(28.96991897404402,-1.5,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark53(28.9799749026701,-1.5,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark53(29.007004992360997,-1.5,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark53(29.015009233373576,-1.5,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark53(29.05140632859039,-1.5,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark53(-29.07789912193579,-1.5,-69.21595714052786 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark53(29.092777285837343,-1.5,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark53(29.09536009038279,-1.5,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark53(29.102886522014927,-1.5,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark53(29.134702353980657,-1.5,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark53(2.922751939869224,-1.5,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark53(29.23754911007366,-1.5,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark53(29.239579279430693,-1.5,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark53(29.28988251924069,-1.5,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark53(2.932244331297724,-1.5,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark53(-29.33157891183439,-1.5,1.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark53(2.9343290654489635,-1.5,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark53(29.349484060712797,-1.5,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark53(29.394402476426393,-1.5,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark53(29.405496586632935,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark53(29.425307701775267,-1.5,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark53(29.454009106802054,-1.5,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark53(29.498560567004006,-1.5,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark53(29.546574658853558,-1.5,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark53(29.553182714977424,-1.5,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark53(-29.614916951311493,-1.5,-1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark53(29.62221672397348,-1.5,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark53(29.636189315006146,-1.5,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark53(29.652825797238833,-1.5,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark53(29.671196780588478,-1.5,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark53(29.68332805791701,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark53(29.72053677980614,-1.5,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark53(29.744172472739365,-1.5,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark53(29.765154895272442,-1.5,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark53(29.849503607398077,-1.5,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark53(29.979620662783226,-1.5,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark53(-29.98003279864116,51.751900862650245,76.74397921547273 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark53(30.02865274414833,-1.5,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark53(30.049085691227862,-1.5,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark53(30.0908375272453,-1.5,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark53(30.15513914923078,-1.5,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark53(3.0190351725505167,-1.5,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark53(30.207469078274165,-1.5,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark53(30.21854949846074,-1.5,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark53(30.229635868071625,-1.5,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark53(3.0233110977040836,-1.5,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark53(30.241843192787485,-1.5,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark53(30.274877352488886,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark53(30.30328564063108,-1.5,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark53(3.0346174553907335,-1.5,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark53(30.359320355611423,-1.5,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark53(30.393263537105838,-1.5,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark53(30.396342822961095,-1.5,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark53(30.43160217406669,-1.5,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark53(30.473309164169073,-1.5,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark53(30.494146623901976,-1.5,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark53(30.545160149333782,-1.5,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark53(30.56116486535775,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark53(30.563208256672183,-1.5,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark53(30.62075897389707,-1.5,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark53(-30.638214887128434,-1.5,-1.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark53(30.65408021432051,-1.5,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark53(30.659349556913753,-1.5,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark53(30.678498439707184,-1.5,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark53(30.68941767031614,-1.5,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark53(30.708734072830058,-1.5,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark53(30.758642302363626,-1.5,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark53(3.0769226532319767,-1.5,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark53(30.796639439092555,-1.5,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark53(30.83767616510433,-1.5,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark53(30.845458528961522,-1.5,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark53(30.89137935381308,-1.5,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark53(30.930051655263412,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark53(30.946935207752233,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark53(31.02807113147254,-1.5,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark53(31.154147764235958,-1.5,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark53(31.172861149306325,-1.5,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark53(31.27988741110856,-1.5,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark53(31.28757750016814,-1.5,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark53(31.365241867240854,-1.5,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark53(31.36798338789268,-1.5,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark53(-3.139816720566561,-1.4999999999999982,0.8354297152512719 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark53(31.425847156199836,-1.5,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark53(31.55897920799606,-1.5,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark53(31.576219716792608,-1.5,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark53(31.57967881743656,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark53(31.615939402750758,-1.5,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark53(31.61725286458902,-1.5,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark53(31.622368965051546,-1.5,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark53(31.64709775105089,-1.5,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark53(31.65515076613009,-1.5,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark53(31.675462450839273,-1.5,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark53(31.760967384131803,-1.5,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark53(3.1764157857729742,-1.5,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark53(31.777814734308315,-1.5,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark53(31.806721987823884,-1.5,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark53(31.840315616044535,-1.5,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark53(32.05134312847861,-1.5,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark53(32.094008540673215,-1.5,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark53(32.156290241412876,-1.5,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark53(32.1604901946279,-1.5,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark53(32.19601814941527,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark53(32.26481896919578,-1.5,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark53(32.28115101867937,-1.5,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark53(32.28347644814963,-1.5,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark53(32.34806027745714,-1.5,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark53(-3.2393106732899497,-1.5,46.09959915497183 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark53(32.399697244783056,-1.5,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark53(3.24130318597787,-1.5,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark53(32.42960712746708,-1.5,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark53(32.48737062111471,-1.5,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark53(32.5609043330014,-1.5,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark53(32.57916857715287,-1.5,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark53(32.609908924037114,-1.5,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark53(32.64511754982561,-1.5,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark53(3.265083753489847,-1.5,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark53(32.66162129458911,-1.5,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark53(3.2667500617110178E-18,-1.5,30.871901482452166 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark53(3.2682302666971155,-1.5,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark53(32.71069548332036,-1.5,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark53(32.71580161562815,-1.5,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark53(32.72529419451962,-1.5,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark53(32.73971670907682,-1.5,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark53(3.2773089391043086,-1.5,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark53(32.784270845244265,-1.5,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark53(32.787009012798,-1.5,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark53(32.797492777456114,-1.5,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark53(32.82747292497149,-1.5,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark53(32.83693577870241,-1.5,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark53(3.2888575125239754,21.17993221734413,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark53(32.936077807273215,-1.5,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark53(32.95462983146149,-1.5,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark53(32.95971452774006,-1.5,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark53(32.98134340973066,-1.5,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark53(33.041619343434675,-1.5,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark53(3.310190119961675,-1.5,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark53(33.10430189686511,-1.5,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark53(33.114779668981065,-1.5,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark53(33.155015010794905,-1.5,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark53(33.175827828610934,-1.5,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark53(33.19929273923475,-1.5,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark53(33.20348563986401,-1.5,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark53(3.320520296758267,-1.5,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark53(-33.21048330755818,-1.5,-0.017729177283100965 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark53(33.30108226903165,-1.5,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark53(33.31767215572693,-1.5,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark53(33.41889252084658,-1.5,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark53(33.437139419904696,-1.5,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark53(33.46775082921491,-1.5,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark53(33.47220169923186,-1.5,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark53(3.3525878180830517,-1.5,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark53(33.52723131520065,-1.5,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark53(3.354467152696188,-1.5,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark53(3.355792593733753,-1.5,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark53(33.56279115702411,-1.5,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark53(33.61529245628058,-1.5,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark53(3.365166106196286,-1.5,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark53(33.71557344091923,-1.5,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark53(33.72696230696107,-1.5,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark53(33.7963767009129,-1.5,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark53(33.822555623132715,-1.5,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark53(33.84711370975526,-1.5,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark53(33.85776937201218,-1.5,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark53(33.91442817912134,-1.5,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark53(33.91980356278849,-1.5,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark53(33.939792388452574,-1.5,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark53(33.943555696378425,-1.5,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark53(33.97718745387138,-1.5,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark53(-33.980258288369654,-1.5,-76.28180727734384 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark53(33.990487992206226,-1.5,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark53(34.115452701658576,-1.5,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark53(-34.159779033587085,-1.5,98.75227950132043 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark53(34.16099497211353,-1.5,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark53(3.4208131061075733,-1.5,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark53(34.23098861648065,-1.5,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark53(34.263750601034054,-1.5,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark53(34.343605102483025,-1.5,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark53(34.35579218743348,-1.5,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark53(34.363318773583934,-1.5,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark53(34.398131265783356,-1.5,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark53(34.433366831829346,-1.5,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark53(34.471659329389155,-1.5,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark53(34.550486802735264,-1.5,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark53(34.5748502336933,-1.5,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark53(34.59803827020244,-1.5,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark53(34.599197271763984,-1.5,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark53(34.604120464273976,-1.5,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark53(34.60913805705684,-1.5,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark53(34.63096958054686,-1.5,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark53(34.65388406530748,-1.5,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark53(3.469446951953614E-18,-1.5,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark53(34.70228521431997,-1.5,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark53(34.78715639993489,-1.5,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark53(34.80830095283179,-1.5,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark53(34.82828885309078,-1.5,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark53(3.4911217396682304,-1.5,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark53(3.49523772246199,-1.5,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark53(34.982897787155906,-1.5,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark53(3.50045226882456,-1.5,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark53(35.01712025813629,-1.5,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark53(35.054108195310704,-1.5,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark53(35.05614354432541,-1.5,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark53(35.08196643228462,-1.5,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark53(35.08529068055168,-1.5,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark53(-35.14237419968103,-1.5,-1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark53(35.17500514608025,-1.5,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark53(35.18495862728892,-1.5,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark53(35.19165470876945,-1.5,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark53(35.22663267665811,-1.5,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark53(35.24966753804916,-1.5,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark53(35.252367747373654,-1.5,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark53(35.25909477601755,-1.5,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark53(35.27129339261518,-1.5,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark53(35.284522262774615,-1.5,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark53(35.33250041355717,-1.5,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark53(35.33748258593856,-1.5,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark53(35.37631566434703,-1.5,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark53(35.38905183089142,-1.5,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark53(35.40660065563123,-1.5,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark53(35.40779843640009,-1.5,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark53(35.467794151605005,-1.5,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark53(35.47598983327342,-1.5,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark53(35.49612506686404,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark53(3.552713678800501E-15,-1.5,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark53(35.538695540634365,-1.5,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark53(35.61053493758219,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark53(35.70648953937922,-1.5,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark53(35.71545325238546,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark53(35.72436308938681,-1.5,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark53(35.74003040245077,-1.5,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark53(35.813686584932924,-1.5,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark53(35.822196290960235,-1.5,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark53(35.842746243173906,-1.5,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark53(-35.94529091207113,-1.5,-1.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark53(35.97236071257379,-1.5,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark53(36.02219279538974,-1.5,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark53(36.03583691844395,-1.5,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark53(36.04009785875141,-1.5,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark53(36.043674327413214,-1.5,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark53(36.05112360441625,-1.5,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark53(3.6074153746131543,-1.5,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark53(3.6077638554218368,-1.5,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark53(3.608561134950173,-1.5,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark53(36.09899680859613,-1.5,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark53(3.6113970059138616,-1.5,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark53(36.13536029958281,-1.5,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark53(36.19388238583071,-1.5,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark53(36.197192837925684,-1.5,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark53(36.21892403063575,-1.5,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark53(36.24893096983814,-1.5,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark53(36.249243868762676,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark53(3.6286095453387617,-1.5,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark53(36.33268034940309,-1.5,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark53(3.6353575590099405,-1.5,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark53(36.384748968554504,-1.5,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark53(36.43116805222019,-1.5,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark53(36.43766851773634,-1.5,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark53(36.510681869384314,-1.5,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark53(-36.54682213998483,-1.5,-1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark53(36.561266967070935,-1.5,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark53(36.58454338626595,-1.5,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark53(36.64399472987435,-1.5,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark53(36.66768101392957,-1.5,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark53(36.71322962801756,-1.5,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark53(36.77943167244841,-1.5,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark53(36.80127309199784,-1.5,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark53(36.83557356830443,-1.5,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark53(36.84800379746215,-1.5,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark53(36.852910886883954,-1.5,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark53(36.9907790455677,-1.5,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark53(37.00498107998369,-1.5,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark53(37.01114198118373,-1.5,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark53(37.029106603463994,-1.5,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark53(37.13518639533828,-1.5,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark53(37.19013997412614,-1.5,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark53(37.217810411283835,-1.5,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark53(-3.723067559929645,-1.4999999999999996,0.36105024475308056 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark53(37.29571086510288,-1.5,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark53(37.34223557648747,-1.5,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark53(37.42195568587056,-1.5,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark53(37.42724553574471,-1.5,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark53(37.43147495283603,-1.5,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark53(37.466762057745626,-1.5,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark53(37.477898808875935,-1.5,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark53(37.50224784969924,-1.5,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark53(37.54755590226284,-1.5,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark53(37.562672063836125,-1.5,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark53(37.56970989656352,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark53(37.58155684128139,-1.5,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark53(37.59940488682698,-1.5,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark53(37.622526705237924,-1.5,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark53(3.7632869184580215,-1.5,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark53(37.682043115656434,-1.5,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark53(37.71232931576942,-1.5,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark53(37.735283970794974,-1.5,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark53(37.750395355180395,-1.5,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark53(37.75701463235163,-1.5,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark53(37.77435585047601,-1.5,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark53(37.81095201991232,-1.5,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark53(37.81298924881159,-1.5,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark53(37.815809497649084,-1.5,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark53(37.84175382904207,-1.5,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark53(37.85748795378029,-1.5,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark53(-3.785766995733679E-270,-1.5,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark53(37.873664250553446,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark53(3.7895026427969416,-1.5,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark53(37.91370248005247,-1.5,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark53(37.933362649213976,-1.5,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark53(37.982613771285656,-1.5,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark53(38.00782291235529,-1.5,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark53(3.8011286510319446,-1.5,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark53(38.059823293479695,-1.5,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark53(38.076375948439,-1.5,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark53(38.12620561981031,-1.5,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark53(3.812621118657809,-1.5,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark53(38.19828284331978,-1.5,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark53(3.8224470422402845,-1.5,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark53(38.24416255021903,-1.5,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark53(38.29568612891345,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark53(38.29925292641513,-1.5,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark53(38.30117702627404,-1.5,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark53(38.30711993447351,-1.5,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark53(38.333997167704354,-1.5,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark53(38.37856199520143,-1.5,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark53(38.43007171891065,-1.5,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark53(38.44710675919412,-1.5,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark53(38.483931294041696,-1.5,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark53(38.48870023950974,-1.5,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark53(38.49317073344153,-1.5,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark53(38.49570178629715,-1.5,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark53(38.52134409753114,-1.5,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark53(3.8538778575916437,-1.5,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark53(38.55695094144821,-1.5,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark53(38.59837850775406,-1.5,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark53(38.60393991700276,-1.5,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark53(38.648910495420864,-1.5,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark53(38.73692889227333,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark53(38.753341967874725,-1.5,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark53(38.759515584880205,-1.5,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark53(38.76920690541036,-1.5,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark53(38.803476777610555,-1.5,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark53(38.846295766813626,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark53(38.89129558958129,-1.5,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark53(38.957078630101165,-1.5,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark53(38.977394272620884,-1.5,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark53(38.997387916523536,-1.5,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark53(39.00728834927028,-1.5,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark53(39.010058521261215,-1.5,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark53(39.106299212269334,-1.5,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark53(39.11667814973963,-1.5,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark53(3.914582070417026,-1.5,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark53(39.180456509299745,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark53(39.182866391262706,-1.5,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark53(39.20008842774285,-1.5,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark53(39.21606969265951,-1.5,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark53(39.22720948425911,-1.5,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark53(39.230816339460674,-1.5,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark53(39.25052894725576,-1.5,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark53(39.25521058730757,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark53(39.3018672950648,-1.5,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark53(39.37760478813856,-1.5,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark53(39.39747249208139,-1.5,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark53(39.411296113070335,-1.5,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark53(39.41276865136436,-1.5,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark53(39.419693160268125,-1.5,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark53(39.43721965964643,-1.5,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark53(39.45957511391051,-1.5,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark53(39.488472618918934,-1.5,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark53(39.5254629234946,-1.5,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark53(39.52688127316115,-1.5,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark53(39.52737169285757,-1.5,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark53(39.545826738285115,-1.5,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark53(39.551592737179185,-1.5,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark53(39.5693462773616,-1.5,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark53(39.594143419132195,-1.5,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark53(39.68113280162078,-1.5,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark53(39.690467192441155,-1.5,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark53(39.70608295764352,-1.5,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark53(39.71879738517822,-1.5,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark53(39.734503173894126,-1.5,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark53(39.73505608146942,-1.5,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark53(39.78419881991152,-1.5,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark53(39.826489514883406,-1.5,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark53(39.84478485794952,-1.5,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark53(39.85191391588995,-1.5,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark53(39.85281351596746,-1.5,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark53(39.85719291324202,-1.5,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark53(39.86635676767937,-1.5,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark53(-39.87008996765521,-1.5,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark53(39.873886980335385,-1.5,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark53(39.908336274689134,-1.5,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark53(39.930643682201584,-1.5,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark53(39.96422404765457,-1.5,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark53(39.9805819005422,-1.5,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark53(39.98294628919592,-1.5,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark53(40.00302647248086,-1.5,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark53(40.00772745100389,-1.5,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark53(40.08076522934557,-1.5,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark53(40.092025524322885,-1.5,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark53(40.16082242327433,-1.5,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark53(40.21251684468764,-1.5,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark53(40.22852280214801,-1.5,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark53(40.23845415290542,-1.5,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark53(40.25089004154239,-1.5,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark53(4.0264115083816305,-1.5,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark53(40.302429775254915,-1.5,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark53(40.30783269408329,-1.5,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark53(40.37450645703407,-1.5,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark53(-40.385918441846826,-1.5,-1.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark53(40.39306502584415,-1.5,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark53(40.44800536834299,-1.5,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark53(40.46375627868493,-1.5,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark53(40.48069944596817,-1.5,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark53(40.48722032839706,-1.5,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark53(40.50993368637778,-1.5,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark53(40.52155557234181,-1.5,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark53(40.541866155378806,-1.5,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark53(40.592827693523816,-1.5,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark53(4.061483128855997,-1.5,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark53(40.68316019552852,-1.5,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark53(40.70495996378722,-1.5,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark53(40.70698170247425,-1.5,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark53(40.71834817751432,-1.5,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark53(40.72086121865917,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark53(40.72262163588688,-1.5,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark53(40.75193301588507,-1.5,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark53(40.77534322164158,-1.5,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark53(40.80564367461716,-1.5,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark53(-40.806058816008466,-1.5,-0.08107206748554319 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark53(40.82110363959246,-1.5,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark53(40.88531413429057,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark53(40.887185671774404,-1.5,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark53(40.92641153844777,-1.5,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark53(4.09442261260417,-1.5,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark53(40.947588730072596,-1.5,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark53(40.99753827257746,-1.5,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark53(41.05066139310711,-1.5,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark53(41.06135820170662,-1.5,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark53(41.075600958106776,-1.5,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark53(41.10846122324821,-1.5,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark53(41.14969968731154,-1.5,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark53(41.17006250657325,-1.5,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark53(41.23874583957951,-1.5,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark53(41.28854741219989,-1.5,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark53(41.447204015788884,-1.5,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark53(-4.1488528340898852E-22,-1.5,1.0000000004670588 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark53(41.52076930560514,-1.5,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark53(41.61295818680159,-1.5,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark53(41.65367940355002,-1.5,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark53(41.66623395823678,-1.5,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark53(41.667269976111044,-1.5,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark53(41.71604577429254,-1.5,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark53(41.73010472393911,-1.5,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark53(41.76597532725004,-1.5,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark53(41.794569182137565,-1.5,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark53(41.79680608000331,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark53(41.79993138835958,-1.5,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark53(41.80510133377902,-1.5,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark53(41.83553303859101,-1.5,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark53(41.85288693606084,-1.5,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark53(41.883971151894855,-1.5,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark53(41.893857352207135,-1.5,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark53(41.90044977682934,-1.5,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark53(41.93019849260666,-1.5,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark53(-4.196965898598705,-1.5,-0.9999999999999997 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark53(41.99650681631757,-1.5,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark53(42.023427999565016,-1.5,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark53(42.18151865335909,-1.5,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark53(42.18363567086538,-1.5,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark53(42.21883118277097,-1.5,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark53(42.22222361799117,-1.5,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark53(42.2255451184507,-1.5,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark53(42.24262094748782,-1.5,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark53(42.27223467615628,-1.5,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark53(42.34891127139961,-1.5,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark53(42.35796334926125,-1.5,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark53(42.43793329585135,-1.5,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark53(42.445835023231524,-1.5,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark53(42.46450123432617,-1.5,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark53(42.51816222944471,-1.5,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark53(42.56041661433539,-1.5,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark53(42.561901694734445,-1.5,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark53(42.6105619525268,-1.5,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark53(42.626031010328916,-1.5,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark53(42.64455717404837,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark53(42.67230422497718,-1.5,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark53(42.735136908148824,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark53(42.73788453478295,-1.5,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark53(42.76227448011946,-1.5,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark53(42.81931945594623,-1.5,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark53(42.83490693049433,-1.5,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark53(42.868383284601464,-1.5,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark53(42.88169679556066,-1.5,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark53(42.902241797476194,-1.5000000000000022,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark53(4.295128093896956,-1.5,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark53(42.96195323454558,-1.5,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark53(42.987786825454315,-1.5,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark53(42.99687324139839,-1.5,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark53(4.307881203528623,-1.5,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark53(43.087031328825105,-1.5,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark53(43.105641612403154,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark53(43.12515051667721,-1.5,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark53(-43.13067990750574,-1.5,-0.22670733660079634 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark53(43.140635521806495,-1.5,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark53(43.17304005920302,-1.5,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark53(43.18629676577771,-1.5,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark53(43.23442532671868,-1.5,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark53(43.252088012603906,-1.5,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark53(-43.26550307761631,-1.5,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark53(43.27705922087722,-18.929063517906826,-21.537265745070286 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark53(43.32744736976761,-1.5,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark53(43.3503893058803,-1.5,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark53(43.360563051833594,-1.5,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark53(-4.3368086899420177E-19,-1.5,-40.97720936547527 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark53(43.47299486871639,-1.5,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark53(43.50961058744738,-1.5,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark53(43.59509842359813,-1.5,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark53(43.600814042972246,-1.5,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark53(43.60970388307778,-1.5,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark53(43.64875065167877,-1.5,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark53(43.686292106051255,-1.5,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark53(43.69049730992171,-1.5,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark53(43.70987370988301,-1.5,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark53(43.71090379471532,-1.5,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark53(43.7545359659122,-1.5,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark53(43.77128019683695,-1.5,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark53(43.77378662541975,-1.5,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark53(43.82708492594036,-1.5,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark53(43.83576638357387,-1.5,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark53(43.836743312234475,-1.5,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark53(43.85507241825118,-1.5,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark53(43.88410827147584,-1.5,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark53(4.391912256148984,-1.5,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark53(43.961301534536545,-1.5,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark53(43.97237767826327,-1.5,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark53(43.982032855438995,-1.5,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark53(43.983598349314406,-1.5,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark53(44.014818263226175,-1.5,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark53(44.02814025363572,-1.5,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark53(44.1387189740575,-1.5,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark53(44.139421897348285,-1.5,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark53(4.4144162232289545,-1.5,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark53(4.415859242160721,-1.5,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark53(44.17767579998113,-1.5,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark53(44.18362799532122,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark53(44.200439141970435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark53(-44.201728015042654,-1.5,0.9999999999999982 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark53(44.238626657259,-1.5,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark53(44.26519855850435,-1.5,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark53(4.429518731306352,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark53(4.429583774482168,-1.5,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark53(44.35628600722529,-1.5,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark53(44.38108702893511,-1.5,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark53(44.39597249326052,-1.5,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark53(4.440892098500626E-16,-1.5,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark53(44.43735604578257,-1.5,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark53(44.46797946725797,-1.5,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark53(4.4476135857750805,-1.5,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark53(44.4929138970878,-1.5,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark53(44.51519546192996,-1.5,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark53(44.519948069963036,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark53(44.564884045699806,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark53(44.58583394645272,-1.5,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark53(44.60036241684198,-1.5,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark53(44.63890710206357,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark53(4.4695819449796375,-1.5,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark53(-44.74203877754563,87.549364704492,0.19625272980101727 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark53(44.74472531926952,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark53(44.78017117409254,-1.5,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark53(44.877838003145825,-1.5,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark53(44.91055708998856,-1.5,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark53(44.96388554658702,-1.5,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark53(45.01792449255959,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark53(45.03295800990643,-1.5,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark53(45.086504404903636,-1.5,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark53(45.097903079288656,-1.5,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark53(45.11704708515857,-1.5,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark53(45.16856573316261,-1.5,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark53(45.21878156770063,-1.5,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark53(45.23981644202786,-1.5,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark53(45.25375776305212,-1.5,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark53(4.525682904117903,-1.5,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark53(45.30281811687556,-1.5,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark53(45.30809826302254,-1.5,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark53(45.30917319978186,-1.5,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark53(45.32391292873369,-1.5,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark53(45.344677728848914,-1.5,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark53(45.35886788598641,-1.5,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark53(45.37254537189251,-1.5,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark53(4.538143438354453,-1.5,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark53(45.42904437486562,-1.5,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark53(45.454554157060755,-1.5,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark53(45.55924388945108,-1.5,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark53(45.572484969498504,-1.5,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark53(45.57314111458325,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark53(45.58353561997251,-1.5,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark53(4.55878609108806,-1.5,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark53(45.62486822757745,-1.5,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark53(4.56269098924556,-1.5,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark53(45.672320851316954,-1.5,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark53(45.69329010950008,-1.5,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark53(-45.7060039151455,-77.42227608458307,-53.3353646856112 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark53(45.74152381985094,-1.5,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark53(45.7683896390121,-1.5,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark53(45.78270463283455,-1.5,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark53(45.82676009281511,-1.5,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark53(45.85846357377852,-1.5,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark53(45.89550129492824,-1.5,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark53(45.89715028600096,-1.5,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark53(45.90858573413346,-1.5,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark53(45.92193675775228,-1.5,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark53(45.994402141302565,-1.5,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark53(46.006358600534114,-1.5,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark53(46.03511420092494,-1.5,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark53(46.04035606495883,-1.5,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark53(46.08138491413957,-1.5,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark53(46.19150096090373,-1.5,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark53(46.27864076257555,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark53(46.291910604903215,-1.5,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark53(46.37860630230459,-1.5,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark53(46.38744637922135,-1.5,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark53(46.3907396167247,-1.5,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark53(46.39647194675757,-1.5,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark53(46.4151637379774,-1.5,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark53(46.439662544864014,-1.5,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark53(46.45614779046704,-1.5,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark53(46.473595007926114,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark53(46.52183921634984,-1.5,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark53(46.54045947760279,-1.5,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark53(46.555312713962536,-1.5,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark53(46.572312972109515,-1.5,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark53(-46.59852207655526,-1.5,-48.74109964752134 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark53(46.60609275088525,-1.5,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark53(46.608994466560716,-1.5,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark53(46.63671737235592,-1.5,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark53(46.63812883043249,-1.5,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark53(46.688352609157214,-1.5,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark53(46.714446227110564,-1.5,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark53(46.729072775615094,-1.5,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark53(46.7478871939171,-1.5,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark53(4.676560227463586,-1.5,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark53(46.87673207492311,-1.5,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark53(4.689376008558076,-1.5,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark53(46.925219708654396,-1.5,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark53(46.94935624659881,-1.5,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark53(46.966401228682116,-1.5,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark53(46.98514971708565,-1.5,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark53(47.01390468889905,-1.5,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark53(47.056553854247674,-1.5,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark53(47.06565412658493,-1.5,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark53(47.07525914213069,-1.5,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark53(47.07872533748298,-1.5,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark53(47.08033106080502,-1.5,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark53(47.096168494068365,-1.5,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark53(47.15406546023523,-1.5,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark53(47.16924576047885,-1.5,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark53(47.18119973798787,-1.5,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark53(47.22324966823471,-1.5,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark53(47.24559188554681,-1.5,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark53(4.726106168566943,-1.5,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark53(47.267880453418286,-1.5,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark53(47.267985337051044,-1.5,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark53(47.27156036948532,-1.5,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark53(47.36086533285134,-1.5,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark53(47.37768406246504,-1.5,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark53(4.740279957115703,-1.5,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark53(47.445833714814796,-1.5,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark53(47.50004219164671,-1.5,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark53(47.511930855439,-1.5,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark53(47.57221869960949,-1.5,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark53(4.76437049637628,-1.5,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark53(47.64504312003643,-1.5,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark53(47.68426036056794,-1.5,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark53(4.7708276022943865,-1.5,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark53(47.75235234991038,-1.5,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark53(47.815742246484746,-1.5,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark53(47.97364707954457,-1.5,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark53(48.00198666892385,-1.5,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark53(48.017182028915364,-1.5,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark53(48.01986208430229,-1.5,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark53(48.038769138269494,-1.5,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark53(48.05512955466605,-1.5,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark53(48.06636351615276,-1.5,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark53(48.108694881010685,-1.5,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark53(48.12165399686887,-1.5,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark53(48.126656459528036,-1.5,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark53(48.128685481380415,-1.5,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark53(48.13134938587551,-1.5,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark53(48.242382198615815,-1.5,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark53(48.2612470080691,-1.5,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark53(-4.826223613246257,-1.5,47.23359097672596 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark53(4.8262633683533345,-1.5,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark53(48.26577003451638,-1.5,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark53(48.28179657858361,-1.5,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark53(48.29902843990562,-1.5,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark53(48.301800240499816,-1.5,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark53(48.304022746063225,-1.5,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark53(48.34158457551259,-1.5,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark53(4.848136233730571,-1.5,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark53(48.50193118261497,-1.5,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark53(48.529040916155424,-1.5,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark53(48.54655093436233,-1.5,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark53(-4.86471093824888,-1.5,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark53(48.666878202906965,-1.5,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark53(48.67306566997118,-1.5,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark53(48.6831741056663,-1.5,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark53(48.704205628540684,-1.5,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark53(48.713831115233745,-1.5,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark53(48.75158452588704,-1.5,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark53(48.75969043139483,-1.5,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark53(48.78479756194588,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark53(4.879383418480131,-1.5,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark53(48.84407160668408,-1.5,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark53(48.912952334283155,-1.5,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark53(48.93542154247973,-1.5,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark53(48.96035820635491,-1.5,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark53(48.981821508104055,-1.5,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark53(48.986190130089405,-1.5,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark53(49.051407292022226,-1.5,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark53(49.08590349468766,-1.5,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark53(49.091283318678194,-1.5,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark53(49.10364562582322,-1.5,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark53(49.1342285143281,-1.5,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark53(49.13619885377301,-1.5,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark53(49.17108966669731,-1.5,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark53(49.22452806401083,-1.5,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark53(49.30685424634359,-1.5,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark53(49.38169547033134,-1.5,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark53(49.40601287195989,-1.5,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark53(49.41068414968123,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark53(49.42230973185667,-1.5,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark53(4.944607402325161,-1.5,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark53(49.458876158011094,-1.5,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark53(49.47595973228584,-1.5,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark53(49.506274164432796,-1.5,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark53(49.520823332718976,-1.5,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark53(49.53866489576093,-1.5,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark53(49.617708695345776,-1.5,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark53(49.632351952708255,-1.5,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark53(49.6894872064611,-1.5,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark53(49.7099245063377,-1.5,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark53(4.974419098753387,-1.5,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark53(49.78298721801616,-1.5,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark53(49.813654927682556,-1.5,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark53(49.843353582685694,-1.5,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark53(49.85543485725659,-1.5,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark53(4.988146043708282,-1.5,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark53(49.885850124523614,-1.5,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark53(49.88996167096132,-1.5,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark53(49.922127698983175,-1.5,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark53(50.01241116114239,-1.5,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark53(50.08748279582679,-1.5,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark53(50.09229845665837,-1.5,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark53(50.12539124833546,-1.5,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark53(50.16100724076361,-1.5,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark53(50.2093021221351,-1.5,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark53(50.28030788732215,-1.5,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark53(-50.3565558873803,-1.5,1.0503536123410486 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark53(50.37157868043051,-1.5,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark53(50.400475367734735,-1.5,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark53(50.401991145178364,-1.5,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark53(50.475249165753425,-1.5,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark53(50.48642936765418,-1.5,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark53(50.48786789406043,-1.5,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark53(50.48904416544414,-1.5,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark53(50.50214679208215,-1.5,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark53(50.523471670698314,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark53(50.60343637404328,-1.5,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark53(5.060554749723266,-1.5,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark53(50.638917652112106,-1.5,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark53(-50.73716826473994,-1.5,-64.12524252233003 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark53(50.738196745286245,-1.5,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark53(50.76853301588838,-1.5,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark53(50.77287129279526,-1.5,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark53(50.77795080697632,-1.5,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark53(50.79272977472033,-1.5,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark53(50.79319554125342,-1.5,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark53(50.81074238013501,-1.5,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark53(5.083908587279495,-1.5,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark53(5.08766283682813,-1.5,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark53(-5.090612424242934,98.1109751747114,75.05370859417658 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark53(50.958096798343966,-1.5,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark53(50.96749330103586,-1.5,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark53(5.096937929501596,-1.5,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark53(50.969696410586934,-1.5,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark53(5.098274465653303E-28,-1.5,-4.824018922179174E-11 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark53(50.99671827118257,-1.5,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark53(51.00128468433522,-1.5,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark53(51.022128925237155,-1.5,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark53(51.06483809320019,-1.5,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark53(51.08272959748959,-1.5,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark53(51.08746744664806,-1.5,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark53(51.10623698925956,-1.5,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark53(51.135250965737875,-1.5,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark53(51.153465440387976,-1.5,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark53(51.181595996650735,-1.5,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark53(51.18900258583561,-1.5,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark53(51.19302638113891,-1.5,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark53(51.197349397514806,-1.5,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark53(51.21680467116923,-1.5,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark53(51.23396778306514,-1.5,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark53(51.23415258126786,-1.5,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark53(51.28522722019485,-1.5,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark53(51.28756339194689,-1.5,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark53(51.32923629419196,-1.5,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark53(51.33190784992281,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark53(51.33449881736573,-1.5,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark53(5.1349379488078455,-1.5,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark53(51.37477871496492,-1.5,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark53(51.42262322426535,-1.5,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark53(51.44833791854681,-1.5,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark53(51.46982921889655,-1.5,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark53(51.47164356050753,-1.5,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark53(51.48153499353637,-59.92716406945679,-57.07709562659995 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark53(51.529590284326005,-1.5,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark53(51.54395182762297,-1.5,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark53(51.55034052087149,-1.5,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark53(51.59355210830435,-1.5,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark53(51.598681930250606,-1.5,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark53(-51.60337982812324,-1.5,0.031450105032671954 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark53(51.608163838032,-1.5,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark53(51.61348621718005,-1.5,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark53(51.63307964663948,-1.5,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark53(51.671741120443336,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark53(51.69259716558406,-1.5,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark53(51.736070286324974,-1.5,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark53(-5.179423797562805,-1.5,0.7560714396160501 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark53(51.79918286781029,-1.5,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark53(51.81960560428304,-1.5,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark53(-51.84150336001517,-1.5,-50.449201362389005 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark53(51.84557269113424,-1.5,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark53(5.185060109888752,-1.5,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark53(51.85976338186867,-1.5,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark53(5.188853322877739,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark53(51.89616267396411,-1.5,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark53(51.904054643022924,-1.5,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark53(51.982904013111494,-1.5,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark53(51.98375197899426,-1.5,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark53(52.00362265550007,-1.5,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark53(52.02845058020836,-1.5,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark53(52.058243190472226,-1.5,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark53(52.06691145408152,-1.5,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark53(52.07385841249413,-1.5,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark53(52.19898261081741,-1.5,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark53(-52.20321608892668,-1.5,-0.06255252641844489 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark53(52.20678641827781,-1.5,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark53(52.24897393407156,-1.5,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark53(52.25977276124161,-1.5,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark53(52.266725507285166,-1.5,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark53(52.275016615442304,-1.5,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark53(52.283117634242416,-1.5,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark53(52.34270688557419,-1.5,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark53(52.360092513217495,-1.5,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark53(52.3803983084534,-1.5,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark53(52.39995931408731,-1.5,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark53(52.5016886043555,-1.5,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark53(52.532402782554755,-1.5,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark53(52.55599777702071,-1.5,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark53(5.256937372865792,-1.5,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark53(52.69641167029836,-1.5,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark53(52.740001634347884,-1.5,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark53(52.74821671917245,-1.5,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark53(52.81840966734015,-1.5,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark53(52.82134675631917,-1.5,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark53(52.879420099534855,-1.5,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark53(52.89584078271272,-1.5,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark53(52.973693096135094,-1.5,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark53(52.974551082859676,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark53(52.99340554927298,-1.5,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark53(53.000303503047775,-1.5,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark53(53.083147895060456,-1.5,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark53(53.10940837443003,-1.5,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark53(53.14819526760974,-1.5,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark53(53.16481498788244,-1.5,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark53(53.20605243719493,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark53(53.2462650178904,-1.5,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark53(53.25489602481093,-1.5,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark53(5.327088052329391,-1.5,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark53(53.30262765156937,-1.5,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark53(53.334555015092995,-1.5,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark53(5.336609709128865,-1.5,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark53(53.38279001107415,-1.5,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark53(53.3834176753857,-1.5,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark53(-53.425582050537855,-1.5,-0.9999998630134619 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark53(53.43103814986117,-1.5,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark53(53.46176725708989,-1.5,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark53(53.51255313361179,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark53(53.51368318085255,-1.5,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark53(5.352452854383088,-1.5,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark53(53.543845640742084,-1.5,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark53(53.59694612370839,-1.5,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark53(53.60108960325031,-1.5,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark53(53.6182063121259,-1.5,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark53(53.621665505071974,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark53(53.62429680187684,-1.5,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark53(53.63017604328883,-1.5,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark53(53.63538104306346,-1.5,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark53(53.63747425346185,-1.5,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark53(5.364505038331327,-1.5,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark53(5.368704040269044,-1.5,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark53(53.770418184702905,-1.5,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark53(-53.7908660039089,-1.5,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark53(53.80523376136594,-1.5,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark53(53.809644857607395,-1.5,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark53(53.84130360444854,-1.5,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark53(53.88003021898348,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark53(53.889702097329376,-1.5,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark53(53.91873831153825,-1.5,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark53(5.392396162586195,-1.5,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark53(53.96049162780306,-1.5,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark53(53.97206740423661,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark53(53.995978925447844,-1.5,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark53(5.399749610979864,-1.5,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark53(54.012285351389714,-1.5,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark53(54.019078590471224,-1.5,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark53(-54.028752318057016,-1.5,-6.127689596966391 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark53(54.041632569976386,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark53(54.07248034500414,-1.5,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark53(54.09157144703647,-1.5,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark53(54.190369509578055,-1.5,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark53(-54.1950239846007,-1.5,-0.9999999999999964 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark53(54.236776456946785,-1.5,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark53(54.296210299089466,-1.5,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark53(54.3001227387937,-1.5,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark53(5.43230922487E-312,-1.5,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark53(54.329862947038144,-1.5,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark53(54.465497620038875,-1.5,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark53(5.449036823045915,-1.5,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark53(54.52484215854574,-1.5,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark53(-54.61783089104601,-1.5,-0.035063758575861304 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark53(54.64138724888215,-1.5,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark53(54.655436356528156,-1.5,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark53(5.465959210696816,-1.5,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark53(54.67069121340739,-1.5,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark53(54.689901747614016,-1.5,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark53(54.698757337233445,-1.5,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark53(54.71289843181257,-1.5,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark53(54.78026811643021,-1.5,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark53(54.85431804359259,-1.5,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark53(5.486488392947703,-1.5,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark53(54.94944077572654,-1.5,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark53(54.982156946819146,-1.5,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark53(54.999473686539034,-1.5,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark53(55.05588241438673,-1.5,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark53(55.087184377723815,-1.5,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark53(55.19221452175697,-1.5,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark53(55.19726710414722,-1.5,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark53(55.28846568007414,-1.5,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark53(55.29625939378636,-1.5,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark53(55.301309412361974,-1.5,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark53(55.31414447469099,-1.5,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark53(55.39665562128168,-1.5,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark53(55.4028219164164,-1.5,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark53(55.40896779943152,-1.5,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark53(55.44758925090794,-1.5,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark53(55.483712438135285,-1.5,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark53(55.50363317371978,-1.5,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark53(5.551167850575599,-1.5,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark53(55.52190747728837,-1.5,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark53(55.53717312111172,-1.5,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark53(55.65109793953089,-1.5,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark53(55.68319164273425,-1.5,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark53(55.70398604860371,-1.5,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark53(55.70841962024346,-1.5,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark53(55.75495640610364,-1.5,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark53(55.76556884133104,-1.5,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark53(55.771067492517716,-1.5,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark53(5.581201306800594,-1.5,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark53(55.83553378689044,-1.5,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark53(55.8424891322677,-1.5,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark53(-55.85741735572283,-1.5,-0.9580862833503847 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark53(55.876418221542195,-1.5,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark53(55.924187782992945,-1.5,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark53(55.92604934684721,-1.5,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark53(55.93548580928704,-1.5,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark53(55.97884909630665,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark53(55.992885546902535,-1.5,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark53(56.05194065732961,-1.5,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark53(5.606030251049063,-1.5,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark53(56.06064109604758,-1.5,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark53(56.18427910373549,-1.5,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark53(56.20685780088385,-1.5,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark53(56.21484900925939,-1.5,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark53(56.21788933990402,-1.5,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark53(56.24632950013741,-1.5,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark53(56.254107651505656,-1.5,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark53(56.34101726721103,-1.5,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark53(56.36707479472855,-1.5,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark53(56.37838725640731,-1.5,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark53(56.40331073765565,-1.5,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark53(56.42700899735465,-1.5,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark53(56.430398017904096,-1.5,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark53(56.431892079683195,-1.5,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark53(56.440224183377055,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark53(-56.49861995325488,-1.5,-68.22658070619245 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark53(-56.4996773439329,-1.5,-0.9999999999999982 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark53(56.5558868230429,-1.5,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark53(56.56869093090337,-1.5,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark53(56.64262982226176,-1.5,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark53(-56.68999178860182,-1.5,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark53(5.673680602045849,-1.5,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark53(56.77052637545114,-1.5,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark53(56.81139430067631,-1.5,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark53(56.82349171403021,-1.5,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark53(56.83035902074357,-1.5,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark53(56.84127996052165,-1.5,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark53(56.867365305211635,-1.5,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark53(56.890598044047906,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark53(56.971949294980966,-1.5,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark53(56.99250508111505,-1.5,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark53(57.000688734611,-1.5,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark53(57.0308615527441,-1.5,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark53(57.04774425886207,-1.5,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark53(57.12397334229132,-1.5,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark53(57.180535749086204,-1.5,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark53(-57.234722306853335,-1.5,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark53(57.27445911066869,-1.5,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark53(57.287534552257654,-1.5,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark53(57.30246612548352,-1.5,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark53(5.733456618765436,-1.5,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark53(57.33844136647341,-1.5,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark53(5.738479637283271,-1.5,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark53(57.397468393358295,-1.5,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark53(57.40065961049258,-1.5,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark53(57.40141377215341,-1.5,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark53(57.40722565254694,-1.5,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark53(5.741042188335574,-1.5,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark53(5.7440475037237775,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark53(57.47701631742319,-1.5,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark53(57.544879800895814,-1.5,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark53(57.61541204713715,-1.5,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark53(57.63147637182339,-1.5,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark53(57.66265949852766,-1.5,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark53(57.68428750063319,-1.5,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark53(57.75190041643163,-1.5,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark53(57.803732380716696,-1.5,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark53(57.83960267759463,-1.5,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark53(57.89027819275179,-1.5,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark53(57.9070783842014,-1.5,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark53(57.91969011765795,-1.5,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark53(57.93666562163505,-1.5,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark53(5.79410411114354,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark53(58.03904538799546,-1.5,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark53(5.807679468620211,-1.5,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark53(58.09379533999585,-1.5,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark53(58.171792307379825,-1.5,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark53(58.178106709128464,-1.5,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark53(58.18034971382059,-1.5,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark53(58.18222349688487,-1.5,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark53(5.819127291949648,-1.5,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark53(58.20247770096904,-1.5,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark53(5.821368539457751,-1.5,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark53(58.38703009993345,-1.5,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark53(58.41196882962015,-1.5,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark53(58.42194314288369,-1.5,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark53(58.45555183365576,-1.5,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark53(5.848925940368034,-1.5,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark53(58.491626586987515,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark53(58.495339221348395,-1.5,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark53(58.567428902370295,-1.5,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark53(58.60127137051218,-1.5,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark53(58.65258110251192,-1.5,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark53(58.66382004895493,-1.5,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark53(58.67656148891636,-1.5,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark53(58.69189376441845,-1.5,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark53(5.871211153969688,-1.5,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark53(58.751760132904934,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark53(58.771472017491845,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark53(58.824529608206944,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark53(58.832251266332136,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark53(58.838949747736365,-1.5,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark53(5.885785316254083,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark53(58.88564655486976,-1.5,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark53(58.89264538812186,-1.5,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark53(58.89948462699191,-1.5,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark53(58.904086519649184,-1.5,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark53(58.920409319370094,-1.5,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark53(58.96634966917986,-1.5,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark53(58.976958496304036,-1.5,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark53(58.994193901283836,-1.5,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark53(59.01497094223229,-1.5,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark53(59.01795783747522,-1.5,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark53(59.03980361916361,-1.5,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark53(59.05697146767494,-1.5,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark53(59.059015920690264,-1.5,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark53(5.909224614593832,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark53(59.10386518619701,-1.5,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark53(5.912503487970831,-1.5,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark53(5.91553253733241,-1.5,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark53(59.196856823993116,-1.5,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark53(59.21799684015284,-1.5,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark53(59.29531253301983,-1.5,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark53(59.30081341629689,-1.5,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark53(59.31668360998552,-1.5,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark53(5.932371982287821,-1.5,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark53(59.33499064048888,-1.5,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark53(59.35616950735499,-1.5,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark53(59.43221388332975,-1.5,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark53(59.464391543387364,-1.5,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark53(59.472946190825475,-1.5,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark53(59.47906109149372,-1.5,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark53(5.948735650228697,-1.5,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark53(59.53611789656418,-1.5,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark53(59.54472248144785,-33.798043861628344,32.43822458679486 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark53(59.56006874166681,-1.5,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark53(59.57759361086186,-1.5,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark53(5.957882749160312,-1.5,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark53(59.59779079454246,-1.5,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark53(5.9758230248125646,-1.5,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark53(59.83025308037035,-1.5,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark53(59.845280753332474,-1.5,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark53(59.92838044175846,-1.5,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark53(59.92932130152582,-1.5,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark53(59.93453173902746,-1.5,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark53(5.993966173164495,-1.5,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark53(59.970626654501366,-1.5,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark53(59.97327282402692,-1.5,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark53(59.99439962166283,-1.5,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark53(60.02331506977263,-1.5,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark53(60.09467831520812,-1.5,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark53(60.153650515804344,-1.5,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark53(6.019519848424008,-1.5,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark53(6.019802895926523,-1.5,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark53(60.218836079865,-1.5,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark53(60.2331655927251,-1.5,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark53(60.244978555852185,-1.5,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark53(60.27149284903368,-1.5,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark53(60.28304668746447,-1.5,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark53(60.29689456155168,-1.5,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark53(60.298545956811495,-1.5,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark53(60.31600886431988,-1.5,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark53(60.36667785839697,-1.5,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark53(60.37179838395019,-1.5,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark53(60.41527915554332,-1.5,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark53(60.417670064415624,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark53(60.46199759621288,-1.5,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark53(60.483445807729055,-1.5,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark53(60.5289327231594,-1.5,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark53(60.531230640301516,-1.5,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark53(60.532154240367305,-1.5,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark53(6.060222363927679,-1.5,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark53(60.612256798530694,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark53(60.63047594866668,-1.5,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark53(60.68670613559873,-1.5,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark53(6.069279039243966,-1.5,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark53(60.69331756951917,-1.5,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark53(6.070459565940439,-1.5,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark53(60.783597419205165,-1.5,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark53(60.80112162391376,-1.5,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark53(60.82324500092358,-1.5,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark53(60.83179125103341,-1.5,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark53(60.836852925806575,-1.5,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark53(60.853156931983946,-1.5,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark53(60.901904201445284,-1.5,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark53(6.090979143858465,-1.5,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark53(-61.060733641530554,-1.5,-1.0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark53(61.17717575955936,-1.5,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark53(61.244531879452694,-1.5,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark53(61.24648815742208,-1.5,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark53(61.29286756748678,-1.5,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark53(61.32396474113183,-1.5,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark53(6.1346141576603985,-1.5,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark53(61.350308443511295,-1.5,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark53(61.37046422210405,-1.5,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark53(6.1410717506914185,-1.5,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark53(61.416238693232756,-1.5,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark53(61.42863096579458,-1.5,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark53(61.44114595604782,-1.5,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark53(61.46158910622262,-1.5,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark53(61.47886279884008,-1.5,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark53(61.491822451890116,-1.5,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark53(61.53127204617513,-1.5,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark53(61.58290781789121,-1.5,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark53(61.62660026461246,-1.5,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark53(61.63306880687402,-1.5,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark53(61.63576572418396,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark53(61.671105974021685,-1.5,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark53(61.76368558896243,-1.5,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark53(6.1793114709602595,-1.5,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark53(61.80139040527688,-1.5,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark53(61.803123584444606,-1.5,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark53(61.83159075862311,-1.5,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark53(61.85350224073778,-1.5,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark53(61.85375609996403,-1.5,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark53(6.186242689012227,-1.5,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark53(61.88625154843256,-1.5,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark53(61.89266207458603,-1.5,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark53(61.89701556928628,-1.5,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark53(61.903442373559415,-1.5,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark53(61.918775804431405,-1.5,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark53(61.94333498723674,-1.5,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark53(61.94427567590233,-1.5,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark53(61.96244880546444,-1.5,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark53(61.992005215827646,-1.5,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark53(62.00943493595684,-1.5,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark53(62.06452435107971,-1.5,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark53(62.09106441598708,-1.5,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark53(62.09217219203129,-1.5,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark53(62.094676717470385,-1.5,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark53(62.09926604595552,-1.5,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark53(62.10679918577076,-1.5,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark53(62.12441455255397,-1.5,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark53(62.133704677014066,-1.5,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark53(62.15240652507802,-1.5,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark53(62.18647729147685,-1.5,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark53(62.194294034722844,-1.5,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark53(62.208081310265726,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark53(6.221728034663968,-1.5,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark53(62.273667594886746,-1.5,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark53(62.27518822843422,-1.5,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark53(62.29698547104534,-1.5,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark53(62.326334802315074,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark53(62.330032665067705,-1.5,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark53(62.33206646541086,-1.5,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark53(-6.236439881074148,-1.5,21.727701747171782 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark53(62.40768072101725,-1.5,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark53(62.43679401668843,-1.5,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark53(62.44140518921631,-1.5,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark53(62.502178099008006,-1.5,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark53(62.52686236190149,-1.5,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark53(62.586203631722356,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark53(62.613415000799336,-1.5,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark53(62.63475767726959,-1.5,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark53(62.65091252374054,-1.5,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark53(62.70619577267155,-1.5,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark53(62.73414914619316,-1.5,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark53(62.753417402354486,-1.5,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark53(62.766112814159584,-1.5,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark53(62.78966941567823,-1.5,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark53(62.834633944446026,-1.5,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark53(62.850553476782466,-1.5,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark53(62.88952375976483,-1.5,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark53(62.894171109107816,-1.5,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark53(62.8995463109502,-1.5,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark53(-62.90732962588515,-1.5,1.0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark53(62.91964072459017,-1.5,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark53(6.3007290795549284,-1.5,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark53(63.022148799446626,-1.5,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark53(63.12768020382877,-1.5,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark53(63.15418203786575,-1.5,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark53(63.15864165927372,-1.5,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark53(63.174405807967204,-1.5,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark53(63.21308834447851,-1.5,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark53(63.26641584238283,-1.5,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark53(63.36091282348444,-1.5,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark53(63.36854771901618,-1.5,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark53(63.38139453758977,-1.5,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark53(63.41726175135195,-1.5,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark53(63.44630575680414,-1.5,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark53(63.45900883358535,-1.5,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark53(63.48647462464942,-1.5,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark53(63.49783983393715,-1.5000000000000049,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark53(63.53447058507099,-1.5,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark53(63.54491964113835,-1.5,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark53(63.594490850238294,-1.5,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark53(63.63147341861327,-1.5,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark53(63.71768522141002,-1.5,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark53(63.74764234784853,-1.5,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark53(6.378116368191371,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark53(6.38558405904641,-1.5,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark53(63.86184479151501,-1.5,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark53(63.86566240849372,-1.5,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark53(63.888637879252364,-1.5,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark53(63.92129027889331,-1.5,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark53(63.93034465352791,-1.5,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark53(63.932594836609056,-1.5,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark53(-63.96430459818272,67.5894057120677,44.33559985332684 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark53(64.04994296018614,-1.5,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark53(64.09437713594336,-1.5,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark53(6.409617768820979,-1.5,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark53(-64.11546897762352,-1.5,7.3055401523277705 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark53(6.413683294399258,-1.5,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark53(64.15836952475132,-1.5,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark53(64.20090390622512,-1.5,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark53(64.20631227639123,-1.5,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark53(64.21836986892292,-1.5,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark53(64.21879146297587,-1.5,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark53(64.29850032856234,-1.5,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark53(64.37741958767782,-1.5,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark53(64.37812398302786,-1.5,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark53(64.38241445029848,-1.5,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark53(64.41047004863555,-1.5,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark53(64.41511099899077,-1.5,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark53(64.46965546474605,-1.5,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark53(64.49929818475276,-1.5,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark53(6.451776968476508,-1.5,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark53(64.53705404590069,-1.5,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark53(64.5382405107838,-1.5,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark53(64.64156964342845,-1.5,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark53(64.64919579049105,-1.5,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark53(64.75150658573776,-1.5,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark53(64.79460908060602,-1.5,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark53(64.796826842125,-1.5,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark53(6.481531971074937,-1.5,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark53(64.85064558361125,-1.5,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark53(64.85739706541584,-1.5,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark53(64.87036675117426,-1.5,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark53(64.91210239298516,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark53(64.98259246100994,-1.5,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark53(65.01205186276505,-1.5,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark53(65.01419289288256,-1.5,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark53(65.05342806395961,-1.5,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark53(65.07975026804607,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark53(65.11473863869115,-1.5,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark53(6.5119681763787405,-1.5,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark53(65.16876455177822,-1.5,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark53(65.19217985236688,-1.5,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark53(65.2194354907335,-1.5,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark53(65.22418882048123,-1.5,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark53(65.23711126856563,-1.5,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark53(65.24071415933085,-1.5,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark53(65.2619669378972,-1.5,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark53(65.27676339574589,-1.5,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark53(6.532284159984442,-1.5,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark53(65.34482871386626,-1.5,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark53(65.3562565204926,-1.5,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark53(65.37024887298949,-1.5,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark53(65.37414175763986,-1.5,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark53(65.37602580300546,-1.5,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark53(65.39072515999787,-1.5,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark53(65.41513886629302,-1.5,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark53(65.43853859694983,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark53(65.45752593724802,-1.5,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark53(65.47558504867777,-1.5,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark53(65.49026900450295,-1.5,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark53(65.50314255912147,-1.5000000000000058,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark53(65.54737573742734,-1.5,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark53(65.57727565869928,-1.5,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark53(65.63935004113054,-1.5,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark53(65.73234094724594,-1.5,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark53(65.82098436483354,-1.5,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark53(6.587829576086364,-1.5,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark53(65.8797875226164,-1.5,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark53(65.90788383704627,-1.5,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark53(65.95225611978898,-1.5,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark53(65.97826057726179,-1.5,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark53(66.00325739995608,-1.5,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark53(66.0253524307528,-1.5,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark53(66.06896913324101,-1.5,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark53(66.06899481834418,-1.5,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark53(6.610430434223915,-1.5,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark53(66.11444990422001,-1.5,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark53(66.17649540140792,-1.5,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark53(66.19428585356168,-1.5,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark53(66.20904927013198,-1.5,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark53(6.623410786329956,-1.5,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark53(66.23577775653675,-64.74470622165198,-44.10403257843076 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark53(66.33492211440912,-1.5,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark53(66.35164258449427,-1.5,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark53(66.36922581086947,-1.5,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark53(66.37951779026633,-1.5,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark53(66.4344932237999,-1.5,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark53(66.46123746718985,-1.5,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark53(-6.64970510790512,-1.4999999999999964,-0.20118274918843304 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark53(66.50904891576818,-1.5,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark53(66.59502207933565,-1.5,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark53(66.6059987458762,-1.5,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark53(66.61205428838178,-1.5,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark53(66.61321267696285,-1.5,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark53(66.66260544307704,-1.5,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark53(66.70965591213826,-1.5,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark53(66.72798117020686,-1.5,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark53(66.73039486523197,-1.5,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark53(66.74887473364055,-1.5,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark53(66.8070992408202,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark53(66.80817549688598,-1.5,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark53(66.85864275201047,-1.5,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark53(66.87664338476986,-1.5,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark53(66.89348822269938,-1.5,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark53(66.93249126557005,-1.5,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark53(66.94678112444929,-1.5,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark53(66.96973956001042,-1.5,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark53(66.98010413001484,-1.5,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark53(66.98740154698964,-1.5,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark53(6.702101070228343,-1.5,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark53(67.04106397067301,-1.5,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark53(67.07572068756383,-1.5,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark53(67.10295835228933,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark53(67.12044636858731,-1.5,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark53(67.17449847328197,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark53(67.19397424318983,-1.5,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark53(67.21366535073275,-1.5,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark53(67.21440055957865,-1.5,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark53(67.23397554851609,-1.5,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark53(67.25574337168749,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark53(67.30982622920442,-1.5,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark53(67.42229816232356,-1.5,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark53(6.7487122753010835,-1.5,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark53(67.48902831156379,-1.5,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark53(67.51704777655132,-1.5,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark53(67.53244809535802,-1.5,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark53(67.54716875325829,-1.5,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark53(67.5973020492828,-1.5,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark53(67.60470435765004,-1.5,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark53(67.64862151645582,-1.5,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark53(67.67086472510694,-1.5,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark53(6.7672846081856335,-1.5,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark53(67.71092170344173,-1.5,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark53(67.72731265492588,-1.5,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark53(67.75469545689728,-1.5,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark53(67.76269710649171,-1.5,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark53(67.7755668851512,-1.5,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark53(67.82162600443961,-1.5,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark53(67.90161543508444,-1.5,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark53(67.9169309386459,-1.5,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark53(67.92138291316857,-1.5,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark53(6.792817819008187,-1.5,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark53(67.93323675211712,-1.5,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark53(67.98673507654888,-1.5,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark53(67.9900663933694,-1.5,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark53(68.00253458803388,-1.5,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark53(6.802863123402574,-1.5,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark53(68.059475950501,-1.5,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark53(6.808318258179028,-1.5,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark53(68.09518069587864,-1.5,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark53(68.10590674465679,-1.5,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark53(68.12871549341685,-1.5,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark53(68.18194746143239,-1.5,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark53(68.21493942670526,-1.5,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark53(68.25370347242173,-1.5,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark53(68.30972063753464,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark53(68.31369844616938,-1.5,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark53(68.33325208076104,-1.5,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark53(68.3426326570308,-1.5,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark53(68.3578289320807,-1.5,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark53(6.841556687538706,-1.5,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark53(68.43351648767529,-1.5,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark53(6.8477079697193,-1.5,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark53(68.49943224776433,-1.5,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark53(68.61134870018454,-1.5,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark53(68.61315427724361,-1.5,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark53(68.63794515507573,-1.5,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark53(68.63795043318606,-1.5,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark53(68.75719773269903,-1.5,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark53(68.78661667718119,-1.5,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark53(68.79562531697478,-1.5,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark53(6.883392171044875,-1.5,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark53(68.86265891742052,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark53(68.87117358727623,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark53(68.88213995939797,-1.5,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark53(68.91001934359014,-1.5,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark53(6.901823684752941,-1.5,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark53(69.04437822403636,-1.5,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark53(69.08725024202514,-1.5,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark53(69.13515243598667,-1.5,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark53(6.918011825035466,-1.5,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark53(69.234022853882,-1.5,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark53(69.24030815033474,-1.5,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark53(69.24218639007066,-1.5,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark53(69.36866804680523,-1.5,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark53(69.38128630943794,-1.5,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark53(69.4308559230929,-1.5,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark53(69.49980283071716,-1.5,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark53(6.951074070342832,-1.5,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark53(69.51829655736992,-1.5,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark53(69.54541921060999,-1.5,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark53(69.60329220708529,-1.5,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark53(69.60501889295756,-1.5,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark53(69.65171293902014,-1.5,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark53(69.6839205561941,-1.5,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark53(69.69977565575905,-1.5,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark53(69.79117821991849,-1.5,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark53(6.98793327319806,-1.5,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark53(69.88079293757583,-1.5,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark53(69.92597932682355,-1.5,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark53(69.9435797275361,-1.5,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark53(6.9955160202820075,-1.5,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark53(69.96498025516648,-1.5,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark53(6.9976089111516355,-1.5,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark53(69.99090790166834,-1.5,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark53(7.000084092419556,-1.5,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark53(70.11782966562464,-1.5,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark53(70.12253985274278,-1.5,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark53(70.12844103200487,-1.5,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark53(7.013215136815518,-1.5,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark53(70.13422622794621,-1.5,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark53(70.22598745597507,-1.5,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark53(70.2620800641827,-1.5,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark53(-70.27935700314265,-1.5,81.74185624403218 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark53(70.29121530791343,-1.5,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark53(70.29692763286944,-1.5,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark53(70.30914377551753,-1.5,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark53(70.31112577513753,-1.5,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark53(70.31497032985254,-1.5,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark53(70.35011064521204,-1.5,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark53(70.37144061603294,-1.5,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark53(70.50112937370385,-1.5,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark53(70.51526241159311,-1.5,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark53(70.53219879651266,-1.5,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark53(70.5426744369202,-1.5,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark53(70.5970831267561,-1.5,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark53(70.61907276908941,-1.5,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark53(70.70584360272557,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark53(70.72093545805441,-1.5,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark53(70.77735032957162,-1.5,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark53(70.82289876449605,-1.5,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark53(70.82404210195786,-1.5,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark53(70.8433292220542,-1.5,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark53(70.85529394408343,-1.5,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark53(70.90014806232841,-1.5,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark53(70.90322080662041,-1.5,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark53(70.9117704445045,-1.5,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark53(70.91746128250483,-1.5,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark53(70.93385827838138,-1.5,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark53(70.93821002790696,-1.5,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark53(70.95022579716402,-1.5,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark53(71.03116290113708,-1.5,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark53(7.105427357601002E-15,-1.5,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark53(-7.105427357601002E-15,-1.5,-0.05897025220185577 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark53(71.07873484236472,-47.509766877822955,56.427623762478134 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark53(71.09936353517072,-1.5,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark53(71.17968191836667,-1.5,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark53(71.20293199000106,-1.5,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark53(7.123761672308305,-1.5,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark53(71.2478109657376,-1.5,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark53(71.26025567433501,-1.5,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark53(-71.28233161347254,-1.5,0.964955271616342 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark53(71.2852333196428,-1.5,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark53(71.33308755600929,-1.5,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark53(71.38218887780431,-1.5,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark53(71.43954513493281,-1.5,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark53(71.4586897402125,-1.5,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark53(71.51255020781227,-1.5,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark53(71.53431104127984,-1.5,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark53(71.53922285242803,-1.5,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark53(71.59657460629396,-1.5,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark53(71.6101543916778,-1.5,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark53(71.61278983582264,-1.5,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark53(71.65386340760264,-1.5,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark53(71.69282732198471,-1.5,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark53(71.73094814784034,-1.5,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark53(71.77906259308304,-1.5,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark53(71.83456606568166,-1.5,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark53(72.00221072278426,-1.5,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark53(72.08469157600314,-1.5,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark53(72.11467776322695,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark53(72.15173797794758,-1.5,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark53(72.17024361137479,-1.5,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark53(72.21834966106059,-1.5,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark53(72.25945791536154,-1.5,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark53(72.42521353506093,-1.5,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark53(72.44772387377819,-1.5,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark53(7.2452136627703965,-1.5,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark53(72.49417257609625,-1.5,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark53(72.5080786761697,-1.5,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark53(72.54004104179592,-1.5,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark53(72.59454351591964,-1.5,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark53(72.62880882840429,-1.5,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark53(72.6728995086846,-1.5,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark53(72.67665626949152,-1.5,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark53(72.70380486471518,-1.5,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark53(72.73880245080286,-1.5,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark53(7.2741352366182355,-1.5,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark53(72.77137690180102,-1.5,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark53(72.7738562955376,-1.5,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark53(72.78863014319971,-1.5,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark53(-72.78930169790478,-1.5,-1.0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark53(72.80815890405367,-1.5,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark53(72.83826413972915,-1.5,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark53(72.84570310206784,-1.5,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark53(72.86878304932829,-1.5,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark53(72.87495774241589,-1.5,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark53(-72.89121120152579,-1.5,-59.46485925755078 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark53(72.89695645172932,-1.5,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark53(72.90176574785579,-1.5,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark53(72.90306576300662,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark53(72.90448700216707,-1.5,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark53(72.91174963215786,-1.5,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark53(72.9414741700257,-1.5,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark53(72.98832596350874,-1.5,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark53(-7.2998797768881865,-1.5,60.22181408948968 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark53(73.00440847271773,-1.5,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark53(-73.02288985626815,-1.5,-33.99651361301849 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark53(73.02862447953214,-1.5,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark53(73.0507406657919,-1.5,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark53(73.0580697601151,-1.5,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark53(73.06660503722767,-1.5,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark53(73.10103105842921,-1.5,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark53(73.14975943352252,-1.5,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark53(73.22887789539423,-1.5,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark53(73.27167222498906,-1.5,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark53(73.28629604417452,-1.5,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark53(73.29715584627178,-1.5,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark53(73.33286002203366,-1.5,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark53(73.40550658649867,-1.5,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark53(7.340766307639304,-1.5,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark53(73.45155498688968,-1.5,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark53(73.47342059837007,-1.5,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark53(7.3511982390644395,-1.5,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark53(73.54572784150787,-1.5,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark53(73.56682622779135,-1.5,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark53(73.59749823811183,-1.5,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark53(73.60258350258339,-1.5,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark53(73.68193272168267,-1.5,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark53(73.81499935592616,-1.5,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark53(73.83924056774251,-1.5,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark53(73.87183136658854,-1.5,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark53(73.96095012896006,-1.5,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark53(73.96613312255116,-1.5,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark53(7.3994058199677255,-1.5,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark53(74.03846579389958,-1.5,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark53(74.05276813005267,-1.5,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark53(74.07695873706284,-1.5,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark53(-74.08098903726972,-1.5,-0.9380574554891533 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark53(74.09237181020535,-1.5,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark53(74.14857032306718,-1.5,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark53(7.419508009640688,-1.5,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark53(-74.20498370644836,-37.61770857223763,73.2077178725877 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark53(74.22129884084494,-1.5,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark53(74.28739971918262,-1.5,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark53(74.32179676743834,-1.5,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark53(74.35303284525813,-1.5,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark53(74.39586335978181,-1.5,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark53(74.53025436572416,-1.5,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark53(7.454486880389452,-1.5,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark53(7.456235828138276,-1.5,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark53(74.60187697970622,-1.5,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark53(74.65429912453044,-1.5,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark53(74.69539197894304,-1.5,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark53(74.70570150317107,-1.5,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark53(7.479290852051586,-1.5,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark53(74.82453580885824,-1.5,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark53(74.84386371840685,-1.5,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark53(74.85409902189497,-1.5,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark53(74.87401779123923,-1.5,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark53(74.92404229901882,-1.5,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark53(74.98477979046999,-1.5,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark53(75.02059611942956,-1.5,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark53(7.5033442573383935,-1.5,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark53(75.03460928997478,-1.5,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark53(75.14687918511015,-1.5,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark53(-75.14765851056715,-1.5,1.439606167397983 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark53(75.16144900588719,-1.5,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark53(75.17884889837097,-1.5,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark53(75.17924464854805,-1.5,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark53(75.21284908286162,-1.5,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark53(75.2230498102266,-1.5,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark53(75.32266070009393,-1.5,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark53(75.33810042700065,-1.5,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark53(75.34059948928702,-1.5,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark53(7.534122551826027,-1.5,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark53(7.540859775992715,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark53(75.42506941687171,-1.5,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark53(75.45349916970778,-1.5,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark53(-75.48098142570376,-1.5,3.453787264584401E-16 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark53(75.48511429168738,-1.5,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark53(7.549471490372014,-1.5,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark53(7.553520873245716,-1.5,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark53(75.53794174828522,-1.5,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark53(75.56247511099369,-1.5,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark53(75.58541376225833,-1.5,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark53(75.6013879876393,-1.5,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark53(75.6044299693672,-1.5,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark53(75.63451062586651,-1.5,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark53(75.65058161025465,-1.5,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark53(7.566571121762271,-1.5,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark53(75.66739129782623,-1.5,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark53(75.78930781719129,-1.5,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark53(75.79548782848883,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark53(75.81005973521005,-1.5,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark53(75.92862072746206,-1.5,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark53(75.95951409855994,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark53(75.99446314393731,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark53(-7.603295344778594E-22,-1.5,-0.06255305044075199 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark53(76.10601158996066,-1.5,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark53(76.11060946492339,-1.5,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark53(76.11806455440029,-1.5,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark53(76.18518144900756,-1.5,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark53(76.22419412279953,-1.5,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark53(76.23655819595096,-1.5,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark53(76.23999959984867,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark53(76.24223543768883,-1.5,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark53(76.40338765868756,-1.5,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark53(7.64571264204011,-1.5,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark53(76.48467758351086,-1.5,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark53(76.50244765185084,-1.5,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark53(76.54963335006818,-1.5,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark53(76.56223595257121,-1.5,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark53(76.56650691669472,-1.5,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark53(76.5809606315004,-1.5,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark53(7.668734741316598,-1.5,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark53(76.72750691428463,-1.5,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark53(7.67682660708779,-1.5,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark53(7.676871983308166,-1.5,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark53(76.77743679875911,-1.5,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark53(7.681491651295662,-1.5,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark53(76.8171896544896,-1.5,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark53(76.82391637785688,-1.5,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark53(76.83564101653778,-1.5,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark53(76.83647091679552,-1.5,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark53(-7.685902052073471,-1.5,1.0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark53(76.91525734804077,-1.5,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark53(76.95349565089103,-1.5,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark53(76.96531762798395,-1.5,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark53(77.01699543055085,-1.5,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark53(77.11192314910502,-1.5,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark53(77.11255001757688,-1.5,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark53(77.12017312195852,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark53(7.712939305408118,-1.5,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark53(77.13568567298208,-1.5,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark53(77.17218726108808,-1.5,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark53(77.21855169460196,-1.5,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark53(77.22285218931472,-1.5,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark53(77.23215290793411,-1.5,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark53(77.26445560564711,-1.5,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark53(77.29687517977335,-1.5,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark53(77.3208297889092,-1.5,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark53(77.37615675732445,-1.5,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark53(77.37722577405245,-1.5,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark53(7.738717686031638,-1.5,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark53(77.40509522757614,-1.5,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark53(77.41208889279264,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark53(77.43560734727279,-1.5,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark53(77.45012012755262,-1.5,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark53(7.74685818031668,-1.5,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark53(77.48208508020056,-1.5,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark53(77.49384871773881,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark53(77.550982352858,-1.5,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark53(77.61127369096124,-1.5,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark53(77.61412949415337,-1.5,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark53(77.62894333637692,-1.5,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark53(77.6356754201332,-1.5,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark53(77.63576891420111,-1.5,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark53(77.66282585344155,-1.5,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark53(77.66796594368458,-1.5,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark53(77.70262761898866,-1.5,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark53(7.775499094719961,-1.5,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark53(77.8058476161845,-1.5,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark53(7.781798618102826,-1.5,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark53(7.783169682436469,-1.5,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark53(77.8323069354252,-1.5,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark53(77.83550125812484,-1.5,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark53(77.83976562835372,-1.5,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark53(77.84919549436842,-1.5,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark53(77.86382430330617,-1.5,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark53(77.96181463274826,-1.5,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark53(77.98050778516347,-1.5,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark53(77.98290984049689,-1.5,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark53(77.98393670457901,-1.5,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark53(78.05646328659185,-1.5,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark53(78.09304271516325,-1.5,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark53(7.810635916812748,-1.5,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark53(78.14564706317009,-1.5,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark53(78.15168916930628,-1.5,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark53(78.24585839309132,-1.5,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark53(78.2588985797262,-1.5,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark53(78.26714407802133,-1.5,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark53(78.30955085095806,-1.5,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark53(7.832314909840605,-1.5,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark53(78.33656909361602,-1.5,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark53(78.33672012889308,-1.5,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark53(78.36617691603848,-1.5,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark53(78.43598723900544,-1.5,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark53(78.45046110228434,-1.5,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark53(78.47664076275059,-1.5,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark53(78.5289697939992,-1.5,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark53(78.62942767494914,-1.5,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark53(78.64887192592144,-1.5,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark53(78.65748612329978,-1.5,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark53(7.867112426183809,-1.5,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark53(78.68345062227728,-1.5,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark53(78.72352498643204,-1.5,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark53(78.72616282323881,-1.5,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark53(78.72895711672471,-1.5,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark53(7.886764023742627,-1.5,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark53(78.90940379410898,-1.5,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark53(78.96984387158948,-1.5,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark53(79.05537259356795,-1.5,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark53(79.0780007874697,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark53(79.08468314602857,-1.5,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark53(79.14952761644238,-1.5,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark53(79.16720807700042,-1.5,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark53(79.20246482488605,-1.5,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark53(79.21958864497535,-22.134131100064252,-74.67710860973098 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark53(79.2255245119374,-1.5,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark53(79.23334922571094,-1.5,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark53(79.29389976908698,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark53(79.35196451632979,-1.5,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark53(79.38958560591426,-1.5,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark53(79.40679911824489,-1.5,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark53(79.41260195640864,-1.5,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark53(79.43901930569916,-1.5,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark53(79.45367525789183,-1.5,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark53(79.47668664263158,-1.5,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark53(79.53796831432922,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark53(79.54389320442203,-1.5,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark53(79.58787967411993,-1.5,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark53(79.59304406800125,-1.5,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark53(79.61923310932545,-1.5,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark53(79.6544183677295,-1.5,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark53(79.66866469466194,-1.5,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark53(79.67396533586042,-1.5,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark53(79.72228391129926,-1.5,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark53(7.97755495064355,-1.5,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark53(79.83384911301768,-1.5,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark53(7.984410934106819,-1.5,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark53(79.92139996405646,-1.5,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark53(79.9450741615668,-1.5,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark53(79.95391908248087,-1.5,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark53(79.98259741672682,-1.5,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark53(7.9983619776314505,-1.5,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark53(79.98867142742093,-1.5,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark53(80.08962797093756,-1.5,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark53(80.14843960419614,-1.5,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark53(80.25834363416195,-1.5,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark53(80.26289227997586,-1.5,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark53(80.28146854659053,-1.5,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark53(80.29779893246901,-1.5,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark53(80.33695032508487,-1.5,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark53(80.3497087720254,-1.5,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark53(80.3532467095396,-1.5,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark53(80.38250929730569,-1.5,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark53(80.38760982253547,-1.5,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark53(80.47808887788156,-1.5,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark53(80.49153368932205,-1.5,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark53(80.50883229994673,-1.5,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark53(80.54548367071797,-1.5,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark53(80.55186303839935,-1.5,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark53(80.57613454997312,-1.5,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark53(80.60457335212355,-1.5,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark53(80.61541977338274,-1.5,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark53(80.64997282943295,-1.5,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark53(80.68088726616537,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark53(80.78524473792953,-1.5,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark53(8.079938953134395,-1.5,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark53(80.81452173296796,-1.5,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark53(80.85559447555829,-1.5,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark53(80.88197523557622,-1.5,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark53(80.91752914718182,-1.5,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark53(80.91891286708,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark53(80.94015295654339,-1.5,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark53(80.97480329499211,-1.5,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark53(81.0114852473538,-1.5,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark53(81.07325042842027,-1.5,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark53(81.16170208698466,-1.5,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark53(81.18462177228947,-1.5,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark53(81.19651074656547,-1.5,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark53(81.36932684598176,-1.5,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark53(81.38488820017247,-1.5,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark53(81.45904748034056,-1.5,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark53(81.5651092843346,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark53(81.65216865503045,-1.5,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark53(81.679057533307,-1.5,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark53(-81.69727147047459,-1.5,54.902045897457725 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark53(81.7559279375794,-1.5,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark53(81.78651080140088,-1.5,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark53(81.80668279218844,-1.5,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark53(81.88486034862562,-1.5,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark53(81.91688123998968,-1.5,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark53(8.19451977878569,-1.5,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark53(81.95393041978532,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark53(82.01270188592196,-1.5,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark53(82.14142828735552,-1.5,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark53(82.14624631085661,-1.5,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark53(82.14924417210074,-1.5,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark53(82.19129247045495,-1.5,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark53(8.225543903152893,-1.5,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark53(8.23280822797505,-1.5,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark53(82.34190721638456,-1.5,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark53(8.235426702892692,-1.5,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark53(82.39006883139551,-1.5,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark53(82.47027376599627,-1.5,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark53(82.4774769894859,-1.5,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark53(82.493342630066,-1.5,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark53(82.50669811331542,-1.5,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark53(8.25193076348298,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark53(82.5597402750854,-1.5,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark53(82.5662559153694,-1.5,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark53(82.58786869175087,-1.5,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark53(8.266067455556453,-1.5,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark53(82.66803719518867,-1.5,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark53(82.7194372315309,-1.5,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark53(82.72102579569548,-1.5,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark53(8.286463681682251,-1.5,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark53(82.93125792892741,-1.5,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark53(83.00936148991426,-1.5,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark53(83.0389806443392,-1.5,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark53(83.12571409753761,-1.5,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark53(83.13832375264266,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark53(8.31445306058012,-1.5,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark53(83.18879806283869,-1.5,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark53(83.21989340221951,-1.5,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark53(83.24249047246546,-1.5,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark53(83.24750120977258,-1.5,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark53(83.25819517618741,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark53(8.331829117566912,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark53(83.33252539921813,-1.5,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark53(83.33630091956948,-1.5,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark53(83.35704631537648,-1.5,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark53(83.37521615208678,-1.5,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark53(8.341393152322311,-1.5,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark53(83.44558411999343,-1.5,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark53(83.47255522002737,-1.5,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark53(83.56409576135444,-1.5,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark53(8.358591300321265,-1.5,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark53(83.62495651863046,-1.5,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark53(83.62879215830692,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark53(83.66003761278927,-1.5,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark53(83.67670191891258,-1.5,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark53(83.72413747877,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark53(-83.8009971692648,-1.5,-1.0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark53(83.84040432865142,-1.5,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark53(83.87007492682818,-1.5,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark53(83.92663923874919,-1.5,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark53(83.9640029624232,-1.5,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark53(83.9871371789136,-1.5,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark53(84.00548417037847,-1.5,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark53(84.00647940163478,-1.5,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark53(84.02013293921783,-1.5,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark53(8.406525112509417,-1.5,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark53(84.07307301056494,-1.5,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark53(84.11086848530455,-1.5,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark53(84.21350535446015,-1.5,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark53(84.23383759283938,-1.5,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark53(84.29489043577544,-1.5,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark53(-84.31367539454544,-1.5,0.0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark53(84.34468104655745,-1.5,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark53(84.35055854533584,-1.5,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark53(84.35590910644468,-1.5,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark53(84.3590078320821,-1.5,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark53(84.39751528430841,-1.5,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark53(84.41089569328257,-1.5,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark53(84.4238034203133,-1.5,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark53(84.42884578171973,-1.5,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark53(84.43746357086533,-1.5,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark53(84.47396030605586,-1.5,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark53(84.50843350982142,-1.5,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark53(84.53187998482676,-1.5,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark53(8.453759077403816,-1.5,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark53(84.5503144851804,-1.5,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark53(84.59253142306068,-1.5,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark53(84.61846054505546,-1.5,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark53(84.66709030320285,-1.5,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark53(84.71455082495848,-1.5,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark53(84.71679337066978,-1.5,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark53(8.47201945755759,-1.5,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark53(84.74857560550575,-1.5,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark53(84.84275435589629,-1.5,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark53(84.84787536482916,-1.5,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark53(84.96324755738038,-1.5,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark53(85.03399357767455,-1.5,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark53(85.04684073026398,-1.5,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark53(8.506060303311898,-1.5,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark53(85.16764177936473,-1.5,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark53(85.20689664571368,-1.5,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark53(85.21831527534991,-1.5,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark53(85.2512239178471,-1.5,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark53(85.26981992364247,-1.5,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark53(85.28513846518567,-1.5,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark53(85.39338872121117,-1.5,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark53(8.539574404500115,-1.5,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark53(85.3976684257585,-1.5,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark53(85.47683837025068,-1.5,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark53(85.53755635485535,-1.5,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark53(85.55697889934746,-1.5,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark53(85.633951466916,-1.5,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark53(8.569673180005866,-1.5,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark53(85.70636304539079,-1.5,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark53(8.571517941596113,-1.5,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark53(85.71744283908268,-1.5,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark53(85.92675772435236,-1.5,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark53(86.00921033233918,-1.5,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark53(86.0543686940776,-1.5,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark53(86.07268905711322,-1.5,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark53(86.18888978799149,-1.5,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark53(86.21166467114364,-1.5,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark53(86.21490249969246,-1.5,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark53(86.25263005568853,-1.5,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark53(86.28719737334286,-1.5,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark53(8.639728390278423,-1.5,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark53(86.46664266098568,-1.5,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark53(86.4716460973795,-1.5,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark53(86.48310734607765,-1.5,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark53(86.51604216483798,-1.5,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark53(86.52945066400332,-1.5,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark53(86.55164554372502,-1.5,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark53(86.5569319185327,-1.5,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark53(86.5755706815261,-1.5,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark53(86.62113257614907,-1.5,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark53(-86.7078754785089,-1.5,1.0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark53(86.75049182081517,-1.5,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark53(86.77010750414453,-1.5,0 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark53(86.79732858817167,-1.5,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark53(86.92941040512028,-1.5,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark53(86.96432726234796,-1.5,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark53(86.97026170639646,-1.5,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark53(86.97584963362549,-1.5,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark53(87.0039237005797,-1.5,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark53(87.0156172127638,-1.5,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark53(87.03439524333903,-1.5,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark53(8.70932593610732,-1.5,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark53(87.1529513073202,-1.5,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark53(8.717983771946543,-1.5,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark53(87.19485146328437,-1.5,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark53(87.19850329077737,-1.5,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark53(87.23057300960392,-1.5,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark53(87.25689578442925,-1.5,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark53(87.31435004155134,-1.5,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark53(-87.31694917550895,-1.5,-1.0000000000000064 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark53(87.38437783788711,-1.5,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark53(87.42430440812416,-1.5,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark53(87.49717651537979,-1.5,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark53(87.50179937271471,-1.5,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark53(87.50538632737596,-1.5,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark53(87.56083434920762,-1.5,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark53(87.56690225038042,-1.5,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark53(87.57347691495448,-1.5,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark53(87.59663053250515,-1.5,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark53(-87.70445916952136,-1.5,2497.409885248199 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark53(87.70857074454146,-1.5,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark53(87.71318829264797,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark53(87.86558845887248,-1.5,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark53(87.92873999575482,-1.5,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark53(87.93733668993923,-1.5,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark53(87.94663106580788,-1.5,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark53(87.99368364073379,-1.5,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark53(87.99389523816643,-1.5,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark53(88.19336602430052,-1.5,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark53(-8.820023435927967E-17,-1.5,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark53(8.821194144100982,-1.5,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark53(88.23265411335137,-1.5,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark53(88.30122605463221,-1.5,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark53(88.31670608147252,-1.5,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark53(8.84227578784019,-1.5,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark53(88.46736883354833,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark53(88.5504812688489,-1.5,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark53(88.561805090733,-1.5,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark53(88.56215466897486,-1.5,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark53(88.57245284776889,-1.5,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark53(88.5899891131455,-1.5,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark53(-88.6483890242968,-1.5,-2365.865882905017 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark53(8.866207654306606,-1.5,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark53(88.76912488990072,-1.5,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark53(88.78901228940924,-1.5,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark53(8.881784197001252E-16,-1.5,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark53(88.90940041355921,-1.5,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark53(88.9890092111547,-1.5,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark53(89.00751383050067,-1.5,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark53(8.903453764438751,-1.5,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark53(8.909565739825373,-1.5,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark53(8.923595500103062,-1.5,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark53(89.25677735019798,-1.5,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark53(89.26964941954935,-1.5,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark53(89.29428425475635,-1.5,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark53(89.31204921493384,-1.5,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark53(89.31215201950704,-1.5,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark53(89.34287110974233,-1.5,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark53(89.36479168186759,-1.5,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark53(89.3690645709953,-1.5,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark53(89.38443437735899,-1.5,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark53(8.952134392219294,-1.5,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark53(8.952250414751884,-1.5,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark53(89.53021074643388,-1.5,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark53(89.60532601742516,-1.5,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark53(89.66773776864753,-1.5,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark53(89.67547136927155,-1.5,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark53(8.969481136410627,-1.5,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark53(89.73542274538298,-1.5,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark53(-89.75349074889228,-1.5,0.721447988576138 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark53(89.75617849760326,-1.5,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark53(89.83231520363303,-1.5,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark53(89.92546187018368,-1.5,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark53(89.92631817356832,-1.5,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark53(89.95989897955356,-1.5,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark53(89.9920873133353,-1.5,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark53(90.03609047325547,-1.5,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark53(90.08355854125377,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark53(90.10322739019361,-1.5,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark53(90.14228551170397,-1.5,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark53(90.16553963906462,-1.5,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark53(90.17577554446444,-1.5,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark53(90.17586076321822,-1.5,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark53(90.21233567595215,-1.5,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark53(90.25595647124942,-1.5,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark53(90.2673033823763,-1.5,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark53(90.30593631327021,-1.5,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark53(90.39103234236069,-1.5,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark53(90.48161049252634,-1.5,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark53(90.49235425131789,-1.5,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark53(90.5170505316347,-1.5,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark53(90.55223070536374,-1.5,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark53(9.056998985907853,-1.5,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark53(90.58797488969839,-1.5,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark53(90.59340845232305,-1.5,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark53(9.059365254749324,-1.5,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark53(90.60820926363868,-1.5,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark53(9.060939763642295,-1.5,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark53(9.06539332082339,-1.5,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark53(90.68269059283482,-1.5,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark53(90.77980149563498,-1.5,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark53(90.8054242983919,-1.5,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark53(90.82370100383854,-1.5,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark53(90.98148354432851,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark53(-90.98542691343036,-1.5,0.025676412024109835 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark53(-91.04288845049237,-1.5,5.645148735734978E-9 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark53(91.04541084721927,-1.5,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark53(91.07240109917538,-1.5,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark53(91.12601142711978,-1.5,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark53(91.19140963941435,-1.5,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark53(91.2266365644854,-1.5,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark53(9.12439269307032,-1.5,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark53(91.25006892080614,-1.5,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark53(91.27739518278167,-1.5,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark53(9.128622891124976,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark53(91.31142989981005,-1.5,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark53(9.132610716124262,-1.5,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark53(91.32915021517532,-1.5,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark53(91.33420483368664,-1.5,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark53(9.13697489130659,-1.5,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark53(9.148720925900605,-1.5,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark53(91.50187615604364,-1.5,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark53(9.15120242769782,-1.5,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark53(91.69582752538912,-1.5,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark53(91.73114385606104,-1.5,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark53(91.73778623687231,-1.5,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark53(91.74756609309452,-1.5,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark53(91.79235289300465,-1.5,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark53(91.87185287301689,-1.5,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark53(91.93818300270911,-1.5000000000000013,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark53(92.00949876399862,-1.5,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark53(92.09837810252793,-1.5,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark53(92.1245598329805,-1.5,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark53(92.12721955662981,-1.5,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark53(9.213577634828733,-1.5,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark53(9.226287268742869,-1.5,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark53(9.234485627359584,-1.5,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark53(92.36191479989884,-1.5,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark53(92.36490571785237,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark53(92.36686684431375,-1.5,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark53(92.44032858302077,-1.5,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark53(92.46527677440692,-1.5,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark53(92.4875255724134,-1.5,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark53(92.62841451529522,-1.5,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark53(92.64960652842919,-1.5,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark53(-92.69981746162716,-1.5,-0.6292050712165818 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark53(92.72606224533828,-1.5,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark53(92.78033606665744,-1.5,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark53(92.83518981079874,-1.5,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark53(92.86349020378171,-1.5,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark53(92.90247871452334,-1.5,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark53(92.92978128893509,-1.5,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark53(92.99411893695807,-1.5,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark53(9.299642721870878,-1.5,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark53(93.0473565601592,-1.5,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark53(93.20129156513019,-1.5,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark53(93.28837649512833,-1.5,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark53(93.30447482816935,-1.5,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark53(93.33122259428706,-1.5,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark53(93.33657202228461,-1.5000000000000009,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark53(93.39241488834628,-1.5,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark53(93.62185380303424,-1.5,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark53(93.64015355699645,-1.5,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark53(93.64825625578236,-1.5,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark53(93.652966191419,-1.5,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark53(93.69278619220367,-1.5,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark53(93.71618184612564,-1.5,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark53(93.72295136507073,-1.5,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark53(93.81170674922888,-1.5,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark53(93.8222905819502,-1.5,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark53(9.38264244173301,-1.5,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark53(93.85438061930033,-1.5,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark53(93.86271386735501,-1.5,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark53(93.91025847939872,-1.5,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark53(93.91201338384298,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark53(94.01035031321587,-1.5,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark53(94.02454515016846,-1.5,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark53(94.06769894107535,-1.5,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark53(94.0755459293405,-1.5,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark53(94.10093065821565,-1.5,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark53(94.15811714650377,-1.5,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark53(94.1939095729748,-1.5,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark53(94.21751458623274,-1.5,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark53(94.22151217824674,-1.5,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark53(94.30482400113351,-1.5,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark53(-94.31349314149102,-1.5,38.88490699895323 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark53(94.33819265616758,-1.5,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark53(94.50871345080387,-1.5,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark53(9.452181096125111,-1.5,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark53(94.59857770533876,-1.5,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark53(94.69474068037468,-1.5,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark53(94.6964398892249,-1.5,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark53(94.70311269320024,-1.5,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark53(94.75943554918248,-1.5,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark53(94.79023678043778,-1.5,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark53(94.80085002709424,-1.5,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark53(94.85609357898669,-1.5,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark53(94.88472381015177,-1.5,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark53(95.06774477629912,-1.5,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark53(95.11040681716665,-1.5,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark53(95.11556447786637,-1.5,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark53(9.51345331380817,-1.5000000000000036,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark53(95.1610580189855,-1.5,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark53(95.27135261147322,-1.5,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark53(95.27803583075399,-1.5,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark53(95.2907818368403,-1.5,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark53(95.29920833431308,-1.5,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark53(95.35090912704004,-1.5,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark53(95.35428960547537,-1.5,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark53(95.3683886532992,-1.5,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark53(95.42391690395121,-1.5,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark53(95.46443725960611,-1.5,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark53(95.48107575791502,-1.5,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark53(95.50841795410068,-1.5,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark53(95.5151195819108,-1.5,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark53(-95.52304609090274,-1.5,-0.006599047611505787 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark53(95.53707973861916,-1.5,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark53(95.55645990958547,-1.5,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark53(95.58043946671397,-1.5,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark53(9.56072128149633,-1.5,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark53(95.613668730211,-1.5,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark53(95.61988928359074,-1.5,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark53(95.64599606672365,-1.5,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark53(95.69167902267256,-1.5,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark53(95.77125124507575,-1.5,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark53(95.81860272785947,-1.5,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark53(95.8377990213329,-1.5,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark53(9.585407631071902,-1.5,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark53(95.9599766460992,-1.5,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark53(95.97811901506591,-1.5,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark53(-96.02540355546985,-1.5,0.0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark53(96.03889375922493,-1.5,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark53(96.06055865588058,-1.5,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark53(96.06831717249844,-1.5,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark53(96.11282635228679,-1.5,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark53(96.18402966406057,-1.5,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark53(96.27421163139351,-1.5,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark53(96.29968901997982,-1.5,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark53(96.30459392307787,-1.5,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark53(96.33564094259083,-1.5,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark53(96.36019237295966,-1.5,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark53(96.37571746471926,-1.5,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark53(96.4611443965718,-1.5,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark53(96.46562338247946,-1.5,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark53(96.48431647500644,-1.5,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark53(96.60947878466547,-1.5,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark53(9.663598536629301,-1.5,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark53(96.71688282941787,-1.5,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark53(96.73741253366525,-1.5,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark53(96.87417757469737,-1.5,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark53(-96.93328226885154,-1.5,-1.0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark53(97.00458719235233,-1.5,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark53(97.12175514126415,-1.5,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark53(97.14619829286283,-1.5,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark53(97.1543000105429,-1.5,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark53(9.717993342272711,-1.5,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark53(97.36345908932896,-1.5000000000000018,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark53(97.36369361846835,-1.5,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark53(9.736757152997576,-1.5,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark53(-97.42680700886943,-1.5,0.005996097132378077 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark53(97.5388125475456,-1.5,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark53(97.58524630346831,-1.5,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark53(9.760091279962978,-1.5,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark53(97.6047210453828,-1.5,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark53(97.64436717853448,-1.5,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark53(97.67917826913347,-1.5,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark53(97.77309613961037,-1.5,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark53(9.790923448627002,-1.5,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark53(9.791389996867185,-1.5000000000000004,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark53(97.93029531972662,-1.5,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark53(97.9318485406875,-1.5,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark53(97.9399745884831,-1.5,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark53(97.96739526888781,-1.5,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark53(9.798861004296683,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark53(9.799279773485932,-1.5,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark53(98.02830994613055,-1.5,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark53(98.05561611831726,-1.5,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark53(98.06151142938864,-1.5,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark53(98.07531769941994,-1.5,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark53(98.07552111263786,-1.5,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark53(-98.09675394503387,-1.5,1.0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark53(-98.15821902645754,-1.5,1.0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark53(98.17358119933505,-1.5,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark53(9.817992277216973,-1.5,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark53(98.21979113265249,-1.5,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark53(98.34948195583848,-1.5,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark53(98.37937029010945,-1.5,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark53(98.41274450526362,-1.5,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark53(9.84277567877156,-1.5,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark53(98.44807389694522,-1.5,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark53(98.49250818586867,-1.5,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark53(98.51075487909728,-1.5,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark53(98.51590547544788,-1.5,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark53(98.5544102500115,-1.5,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark53(9.856839981009601,-1.5,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark53(98.57161070200152,-1.5,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark53(9.860761315262648E-32,-1.5,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark53(9.863766063487152,-1.5,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark53(9.866149430379814,-1.5,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark53(98.68912948734133,-1.5,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark53(9.871345424374933,-1.5,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark53(-98.78961906444819,-1.5,-0.0473602266668286 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark53(98.89740176249663,-1.5,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark53(98.97059427948673,-1.5,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark53(98.9988033644077,-1.5,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark53(99.04977892245651,-1.5,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark53(99.05785373214496,-1.5,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark53(99.07302739973082,-1.5,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark53(99.09609033909524,-1.5,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark53(99.13140934359339,-1.5,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark53(99.1320413548296,-1.5,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark53(99.142901648731,-1.5,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark53(99.26907534019787,-1.5,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark53(99.28481692880118,-1.5,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark53(99.3276243327818,-1.5,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark53(99.38580695011669,-1.5,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark53(99.4046962484679,-1.5,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark53(99.47079864062843,-1.5,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark53(99.47471614720865,-1.5,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark53(99.54131784156147,-1.5,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark53(99.62362988084732,-1.5,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark53(99.65299028738062,-1.5,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark53(99.6738256854849,-1.5,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark53(9.97093068786371,-1.5,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark53(9.973203352950215,-1.5,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark53(99.73298139053276,-1.5000000000000002,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark53(99.83365541781424,-1.5,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark53(99.85584369453764,-1.5,0 ) ;
  }
}
