import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-0.001003700248684157,-1.5707963267948966,40.89397175101914 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-0.001015598740900498,0.7679776986881099,-22.612728118122764 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-0.0010856130856509495,-31.65384156576788,-1.5707963267948966 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark06(-0.0011403833361459583,2.220446049250313E-16,45.12541847534471 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark06(-0.0012676867484453303,-32.88860181582761,3.622271631530685E-71 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark06(-0.0013212924223382798,-1.348975177112008,-92.6514006304707 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark06(-0.001430792872102841,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark06(-0.0014535033642929336,1.5707963267949054,28.274333882308138 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark06(-0.0014757267875009133,-38.97998664588101,-40.8811002829511 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark06(-0.00166504084628194,-6.818063922993858E-16,-4.75808964650345 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark06(0.0017691593444967464,77.01461848625556,0.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark06(-0.0018588351220739513,78.99452958409341,-45.6858837736533 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark06(-0.001862713230457484,28.324808616688788,1.343774214952877 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark06(-0.0021493591518755295,-44.11161699181414,-59.69026041820607 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark06(-0.002155230218538036,-1.5703738709178587,47.12386858036723 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark06(-0.0022625550395021753,6.4429260979548255,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark06(-0.002299861766257502,-158.65007015164377,-21.310542032555944 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark06(-0.0023228040081928834,-1.5707963267948966,29.325120384101012 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark06(-0.002440236624131065,-1.5707963267948966,-97.47245638205672 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark06(0.0025569311584642527,2.1151245993953003,9.19515168165551 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark06(-0.0026707823301130172,-0.9791891452658344,-50.35553369780823 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark06(-0.002692738332230792,-45.19279942758156,-3.1415926535898038 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark06(-0.002739263477455227,-1.5707963267948966,-0.7656275759681106 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark06(-0.002803969707782989,-1.5707963267948966,21.991148575128552 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark06(-0.0029251444934557964,0.7318761851540695,45.553093477052 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark06(-0.0029349406039186343,1.5707963267948966,10.406149114624185 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark06(-0.0029442739665179103,-0.0047447741290500564,53.778567384847385 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark06(-0.0029783908839152427,1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark06(-0.003312698029914472,-102.10107789568151,-78.53982736537006 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark06(-0.003426742718332743,-1.5704441131971922,-15.70591844012089 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark06(0.003478246451376207,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark06(-0.003551549946715463,0.34746056090348965,39.269908169872416 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark06(-0.0035572526180656094,-3.552713678800501E-15,73.17702390511181 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark06(-0.003568807113363201,-1.5707963267948966,3.141592652498861 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark06(-0.0035928912202755946,5.551115123125783E-17,47.36994064341945 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark06(-0.0036302965426935896,-1.5707963267948963,-3.266592653593468 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark06(-0.003669311177457465,-45.26701992053852,-1.5707963267948948 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark06(0.0037592370764180545,0.9505944756203124,-62.83185307179598 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark06(-0.0038121562042663947,-84.50149847547478,1.5864225516035668 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark06(-0.0040099691321876345,1.5707963267948966,14.902847832837553 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark06(-0.004021183732039618,-31.779393785823544,-12.048293325754774 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark06(-0.004098370305493759,-95.32707139982105,0.7707065633590515 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark06(-0.004226511371822724,-0.5881275764945132,118.70279537318926 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark06(-0.0042876403513981,-38.82953873921646,-32.637890096822645 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark06(-0.0044418422468073294,-32.71070320184151,-3.141592653589793 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark06(-0.004448496661123902,50.16051873409976,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark06(-0.004509166444097392,-45.531232915465296,4.712505415046973 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark06(-0.004685186968928279,100.0,0.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark06(-0.004842163500083386,-0.5593297320529468,-1.5707963267948966 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark06(-0.004925445661233659,-1.1955494855425182,99.45776041207321 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark06(-0.004947292967674171,-1.5707963267948966,9.313722982243066 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark06(-0.005017866196514897,-1.5707963267948966,-52.13717989418225 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark06(-0.005084622233261265,-1.5707963267948966,37.218650111807065 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark06(-0.00522709791531873,-44.503746611624706,-1.5383318517716187 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark06(-0.005332107802243351,78.53755296224625,-2.9937519215818997 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark06(-0.005483930724163034,-1.5707963267948966,-37.172218685214055 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark06(-0.005516584049693109,-0.2383083993990356,-44.46130796562747 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark06(-0.0055490000360466285,1.5707963267948966,0.8449088658293514 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark06(-0.00584326686220172,-31.576080930373877,-58.52686383093506 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark06(-0.005861639536439899,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark06(-0.0060045132020078995,-32.95126789579409,-64.61416332421906 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark06(-0.006066123229196044,-1.5707963267948966,-65.33899708190975 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark06(-0.0062389422981326305,-1.570796326794882,-49.64186008665832 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark06(-0.006343399995262011,-0.15606041701436402,9.584522297319296 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark06(-0.006364611633312826,-0.6859757143503787,1.5707963267948966 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark06(0.006443096893822867,1.5707963267948966,45.03857868236685 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark06(-0.006451724859962612,-95.42649367605625,-58.55466910502537 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark06(-0.006454739377839885,90.38965918768176,16.095222277289473 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark06(0.006455264399108865,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark06(-0.006883587253156655,-31.70640891019565,0.006625290402408285 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark06(-0.006918305376476752,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark06(-0.0069305037941102135,-44.49574099262918,-2.0400628674923382 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark06(-0.0070020423311519045,-1.5707963267948966,-80.1938509540729 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark06(-0.007125812671282095,-0.7624973016311921,-79.56778258830427 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark06(-0.0075890547164870524,6.336621270843099E-16,-100.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark06(-0.007642714741145912,-1.570796297781508,136.66381034217585 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark06(-0.007650702488381192,-0.43530660551423833,27.0832489839808 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark06(-0.007684986223853607,-100.0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark06(-0.007754998547038323,-94.28099305379928,-64.45671459353521 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark06(-0.007775519574987733,-1.5707963267948966,-128.72198301191563 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark06(-0.007882164638185722,-2.220446049250313E-16,39.15505651039531 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark06(-0.007974517999534414,-2.674201717765614E-4,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark06(-0.00809961475925303,-4.440892098500626E-16,6.933987456807323 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark06(-0.008217372384866592,-0.7265520594323853,4.712396609983995 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark06(-0.008296891921347714,-44.14694792117204,-3.2666361256267575 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark06(-0.008359424698245521,-1.5707963267948983,-138.44598623435496 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark06(-0.008429154982003768,1.5707963267948966,1.2653229726447208 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark06(-0.008454077422337346,-102.06041799448063,-3.2665988011102454 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark06(-0.008799877227867537,10.79573197886801,1.5707963267948966 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark06(-0.008838848356809495,-95.45562252068355,-48.008908721033094 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark06(-0.00887760047144984,-1.5692065113931188,108.38093598024571 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark06(-0.00894656319551887,1.5707963267948966,5.915306821573642E-15 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark06(-0.008969739604364405,-88.31788313554456,-0.13705544180403073 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark06(-0.009175996680282156,-32.6632982893392,529.4064455048143 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark06(-0.0091761447398013,-1.5707963267948966,95.08926869827397 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark06(-0.009198608137357747,-1.1129105093658076,0.0068423786785068675 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark06(-0.009328350038855071,-31.95401774007422,-50.273295067037836 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark06(-0.009404560156000233,-1.5707963267948966,0.7782183092927856 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark06(-0.009412796823555496,-158.6330753865483,-34.66065250686335 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark06(-0.009820708686687845,-2.220446049250313E-16,9.440224228699797 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark06(-0.00987383819462298,-31.47687332551693,-1.5707963267948966 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark06(0.0101813721269989,1.5707963267948963,-5.693590068198895 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark06(-0.010238563569216213,-1.5707963267948966,-0.21187830381470688 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark06(-0.010251418526772917,-0.1443882513709349,-85.71935691626003 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark06(-0.01028061105091338,72.46825643422653,-9.647577736089135 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark06(0.010299295794215527,0.043407045362450616,-70.42908772482816 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark06(0.010299467171669312,97.51676165331847,1.5707963267948948 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark06(-0.01044547243371414,-15.950864792217832,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark06(-0.010498744653766323,-1.5707963267948966,21.111216263657127 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark06(-0.010647425997808768,1.3097144867925585,-100.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark06(-0.010647857771134271,85.98475178517701,1.5707963267948948 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark06(-0.01093844058097515,-1.5707963267948961,56.41667350723744 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark06(-0.011034930132720777,-1.1948843999979428,-1.616640220261978 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark06(-0.011142232537995803,1.5707963267948966,50.325358881083034 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark06(-0.011199913584723152,-1.5707963267948966,65.79524044811124 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark06(0.011243563650262502,1.5707963267948966,-1.5707963267948002 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark06(-0.011564975880006254,-0.9186444042126327,4.141592661656493 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark06(-0.011653687183836896,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark06(-0.011936526188483463,20.867672454857335,5.068495575563414 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark06(-0.01199297799608237,-9.016580681431383E-131,-10.260126031327394 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark06(-0.012141309482809254,-0.11692223807892642,-66.11282908647891 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark06(-0.0121701034066429,-1.534864033725944,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark06(-0.0125933551785265,-164.93301203840602,-116.11837218724305 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark06(-0.012787780995157821,-1.5707963267948966,58.35787678884245 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark06(-0.01321699321005173,0.19103609823124965,-57.18806383890231 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark06(-0.013218927209672389,54.48199221582096,0.3161197230762127 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark06(-0.013529591885851986,-45.43764564779939,-1.5707963267948966 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark06(-0.013529959753564401,0.7206691553588974,6.009323169161977 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark06(-0.013835248915698206,0.22537900971683505,33.48288071898946 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark06(-0.01385826456528605,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark06(-0.013913106932733399,-95.2679515648159,-53.289628620333936 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark06(-0.014303749269603476,-101.97194583483765,-33.56792934724931 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark06(0.014397002893993156,1.5707963267948966,95.86964953782686 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark06(-0.014398922283034722,-0.5429678470853988,-7.819062502208439 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark06(-0.01453547655419568,-1.5707963267948966,-3.2665926562982506 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark06(-0.014629977378161456,-1.5707963267948966,77.07939764919207 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark06(-0.015196219500627488,-39.2114477880535,-115.98808201008015 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark06(-0.015343914546496678,-1.5707963267948966,45.23177101765569 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark06(-0.015434867606143961,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark06(-0.01584271843082491,-44.30509377149717,15.434818944545375 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark06(-0.01603722251783557,-1.5707963267948966,90.76519671257844 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark06(-0.01604563184663932,-8.293781083292453,-1.5707963267948983 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark06(-0.016080442320142312,-5.770611636116085E-129,45.50547531590595 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark06(-0.01624519203167454,-1.5351884079921454,1.5707963267948966 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark06(-0.01628896554003778,-1.5707963267948966,-22.482991052228215 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark06(0.016323451995921334,0.9361293047463451,-126.63863748272718 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark06(-0.016558709467369592,-0.08145452297544367,-1.291141897766116 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark06(-0.0167271631545591,-88.20808841824662,-66.35695084130414 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark06(-0.016727995304359464,1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark06(-0.016819077366282853,-95.27012400929245,59.313790177577545 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark06(-0.016887305957232892,-1.5707963267948966,37.35234586593758 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark06(-0.016913989960858574,-1.5707963267948966,77.6744294643395 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark06(-0.0170211167732406,-32.971340915662495,-99.47606621433206 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark06(0.017244517677180844,1.642327258077832,100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark06(-0.01728078356885625,-0.8027072464260527,45.73254770408835 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark06(-0.01757520445804428,-4.2351647362715017E-22,79.58013753387642 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark06(-0.01765492089132137,-1.1286057810774623,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark06(-0.017702443024952746,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark06(0.01785467823660261,1.5707963267948966,21.962340364141074 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark06(-0.01795812579713269,73.34355677655265,69.57737358315364 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark06(-0.018148021812524336,-1.5707963267948966,28.04729908475082 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark06(-0.018200996817407944,-1.3536526083136773,3.266592653628518 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark06(-0.018203395138257344,-0.38048359686743133,34.78315404637375 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark06(-0.018264141510680787,-95.3018517126143,-2.0679515313825692E-25 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark06(-0.01828368929038915,37.0378915336172,0.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark06(-0.01865995544278931,6.712388980428624,164.768262132065 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark06(-0.018781578292120127,-45.42390976872031,-80.10947439105078 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark06(-0.018814428648219916,-164.64227521592585,-7.967714568238932 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark06(-0.018838360895693223,-39.18364761681582,-46.18384644986839 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark06(-0.018913357742548483,-19.372823182692102,-4.6738793886702 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark06(-0.019189497979877235,-0.46329728739703957,-42.238060553987836 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark06(-0.019415328632558987,22.0836503704163,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark06(-0.01954233213030021,1.2867824427885486,-26.593799579268072 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark06(-0.019724301798848078,4.324260514124935,2010.3343791043822 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark06(-0.01974306218188955,72.69004269143123,1.5707963267949054 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark06(-0.019882837483103762,-163.53636446362822,-9.799236792292712 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark06(-0.02002524881396861,10.861684943417302,-47.19747669048895 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark06(0.02010036418779628,35.25900483201887,7.105427357601002E-15 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark06(-0.020272900224682644,-0.02178693302670842,-1.5707963267948966 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark06(-0.020377978191244112,-44.181245994817914,64.49595317537629 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark06(-0.020752408461780742,-1.1102230246251565E-16,-2.6390638098931163 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark06(-0.021133851850746455,-101.0866895864317,-91.10419306333289 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark06(-0.02140865511362857,-1.569777678030925,-9.667224256862767 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark06(0.021447648103341335,62.43162875653395,-100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark06(-0.021651169861945263,-37.7802148580693,95.86159579153875 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark06(-0.02166765907446068,6.7123889804452155,-1.5707963267948983 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark06(-0.021785380865167833,-1.5707963267948966,-0.003443175940501081 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark06(-0.02190331523274444,1.5707963267948966,-48.30851915797761 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark06(-0.021996930225211694,-1.5707963267948966,49.90116634742857 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark06(-0.02211453511037757,-88.45331371131952,-59.04061904287476 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark06(-0.02219579040042855,-1.5707963267948966,-29.493997347254293 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark06(-0.02239085537185126,-1.5707963267948966,11.120574289107726 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark06(-0.02270481928678504,-0.3244421570141272,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark06(-0.02273878557207548,-1.5707963267948966,23.90517836228865 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark06(-0.02341778767724371,-1.5707963267948912,-9.716112701909882 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark06(-0.023782228607724276,-1.5707963267948966,-72.13296141821449 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark06(-0.02404994468851239,1.7763568394002505E-15,48.10575048337452 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark06(-0.02416153770101171,-1.5707963267948966,48.15528024198488 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark06(-0.024946437076920458,35.61731677921071,1.5707963267948966 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark06(-0.025046129464964633,-1.3912419157290454,6.638338840714291 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark06(-0.025288078681839597,14.429273433821308,-1.1928058211687928E-16 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark06(-0.025533437865912972,1.564218509836758,-80.61546985346023 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark06(0.02555063952736958,77.7955544468829,1.5707963267948966 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark06(-0.025587301206981425,-0.11173269747011477,21.07516876246069 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark06(-0.025597625129001527,-1.5707963267945573,53.49238401136344 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark06(-0.025771217802727845,6.439980606190912,1.9005614138574082E-17 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark06(-0.025979749897546756,-1.5707963267948966,15.707963267948966 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark06(-0.026253715891007667,-0.5464304250419616,-39.061537462726626 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark06(-0.026400256814044218,-1.5707963267948966,54.7566521614695 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark06(-0.02642782489917278,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark06(-0.02645800524910913,0.571299617963677,-29.497048084815148 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark06(-0.027199534450823855,90.68389353475881,0.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark06(0.027296782790428367,27.25010708476971,1.5707963267948966 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark06(-0.027336395774573474,-0.29474855378900444,89.12887034855089 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark06(-0.027693652234202643,-1.5707963267948912,59.48639688749293 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark06(-0.027796171193576136,-45.28135490065452,-91.08107490616662 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark06(-0.02795241193005122,-0.4250611271714592,0.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark06(-0.02853795876786428,-0.6830500653343756,-94.3054313303162 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark06(-0.02857588789883414,1.5707963267948966,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark06(-0.02865515455197362,0,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark06(-0.028790582410743906,0.10611127542741441,72.70321187410337 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark06(0.02886373830756354,1.4256146165459063,71.68811733020046 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark06(-0.029389190549905228,-1.3086177436048831,-0.9432953093480297 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark06(-0.02960679308966163,-0.3450191015137992,-0.421485017329915 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark06(-0.029661770721462196,-1.338709796038835,-88.22732805973465 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark06(-0.030137788922710587,-0.4592022454025396,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark06(-0.03032632392419783,1.5707963267948966,-78.92666712167325 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark06(-0.03049439710855051,6.430006927878304,-29.31043433494557 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark06(-0.03053939227580792,-38.84222507681797,-1.5707963267948948 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark06(-0.03075672908018265,-38.945252127495294,3.2665926535974323 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark06(-0.030908122348345272,0.26139714176847006,-41.84969008957812 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark06(-0.031006281779713096,1.5707963267949054,4.07706900847059 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark06(-0.031181516559173998,-83.29880378015335,-2.570796239088614 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark06(-0.03127768566302643,1.5905434616648075,1.5707963267948966 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark06(-0.031614930692078894,-1.5707963267948948,1.0970760841298102 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark06(-0.03168189475828253,-0.01948208970836465,1.0593210051073054 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark06(-0.03181277107854525,3.606632272572553E-130,-32.492580828374436 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark06(-0.03193838120968784,-1.5707963267948966,-56.308455878855106 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark06(-0.03200527643371493,39.538562595331484,-69.89120675865395 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark06(-0.03208946207708465,-1.0501458854676928,100.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark06(-0.03217411907417127,-1.5707963267948966,37.195328649516895 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark06(-0.03241391673791942,-1.5707963267948966,90.41539718395762 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark06(-0.032827598632999715,-32.55777131710186,0.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark06(-0.03300925107655203,-31.723363788035613,1.5707963267948957 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark06(-0.03305861501342523,-1.51625991458463,87.95836799773329 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark06(-0.03324368823653892,-0.7619369359878788,-0.7666239669907657 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark06(-0.03345589081973295,65.65855964402147,1.5707963267948966 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark06(-0.03364359514932502,-1.1087000733331431,1.5707963267948966 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark06(-0.03390482343191658,-1.5707963267948963,32.923297546474345 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark06(-0.03403955409548247,-1.5707963267948961,-100.0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark06(-0.03410791613151005,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark06(-0.03473879613400632,159.50735487088883,1.5707963267948966 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark06(-0.034954279102442844,-45.04584987297216,-88.05654359242232 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark06(-0.03520120278119941,-44.19458145464128,-13.759375334253262 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark06(-0.03545524068219072,73.5115996035695,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark06(-0.03619700836078055,-1.5707963267948983,-88.23771248420358 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark06(-0.03621798718216951,-1.5707963267948966,-44.54238118236955 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark06(0.03632045112284758,1.5707963267948966,2.143197908592553 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark06(-0.03638163572109576,-1.5707963263317715,39.21317543247203 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark06(-0.03647916122551764,1.6543612251060553E-24,9.2040816622257 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark06(-0.036944208867986106,-19.35876014394016,44.511355040460415 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark06(-0.03730018679125216,-31.53903120667957,2.5849394142282115E-26 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark06(-0.03733633851490836,-0.45363371812527087,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark06(-0.03752259974366185,-44.22444454123866,-1.6506021203037733 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark06(-0.037627391287155865,-1.5707963267948948,2.764982442275368 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark06(-0.038064577068436134,0.7425426189560156,32.14181706077353 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark06(-0.03868580149640677,1.5170406219828463,82.77391964534942 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark06(-0.03879517149902467,-88.4377659316164,-41.68197416282817 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark06(-0.03893714917722961,-1.5707963267948966,-55.16561262034626 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark06(-0.03922088147296454,-0.3602477846850124,76.29568823858324 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark06(-0.039398276842746216,-1.5707963267948983,-3.1415926535897953 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark06(-0.03951694063281919,-1.5707963267948966,51.84389425923527 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark06(-0.03993143586495136,-1.5707963267948966,44.0986222820577 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark06(-0.04010039376555974,-4.5082903407156913E-131,73.38558865592864 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark06(-0.04020371544782696,-0.306446229841591,-0.38423278480213696 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark06(-0.040517573681805384,23.399694414775265,1.5707963267948966 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark06(-0.0405842447287518,-45.51642422029358,-3.266592795202713 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark06(-0.04064787988662033,-1.0462127523026492,54.01004605155803 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark06(-0.04097353101224588,-0.1579421295080566,-20.51538533148097 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark06(-0.04098745819448435,-94.37086009017082,-2195.4944162070406 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark06(-0.041043487875947415,-1.2681639586697389,45.49206724146907 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark06(-0.0418833998387997,-38.74219227036672,-10.365218252014818 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark06(-0.0431374709964628,2.6650142706532822,5.724477309922373 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark06(-0.04344963515287223,-0.010923202230349038,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark06(-0.04462780880556583,-1.5707963267948966,-83.25657158530373 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark06(-0.044762061570510804,-1.5707963267948957,52.32011270167695 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark06(-0.04487739070480331,1.1120960297977525,52.563582201681925 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark06(-0.04512257696629793,2.710505431213761E-20,1.1438778938612444 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark06(-0.04515052348289966,-1.5707963267948966,-97.03012956202687 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark06(-0.045374033443402795,-0.1879442966398135,66.13960025172047 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark06(-0.045678102635175924,-1.5707963267948963,-0.038011324162010834 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark06(-0.045943469474335245,-1.5707963267948966,45.36075264175912 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark06(-0.04609752031088021,-1.1102230246251565E-16,1.734723475976807E-18 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark06(-0.046116028881645635,14.423017407271498,44.04102147453531 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark06(-0.046541338488105266,-45.496721869392914,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark06(-0.0470563552868333,-0.5234244280452709,-32.91994702751884 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark06(-0.04707649133569522,1.3929480280235738,-7.004952486631382 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark06(-0.04726935089517234,1.5707963267948983,65.11981200998869 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark06(-0.047312655053641184,-1.0444992137932338,-565.2846279680309 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark06(-0.04733193825498461,-1.570796326794337,-26.771876989586957 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark06(-0.0473846803843255,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark06(-0.04767999341439686,0.6015432890023034,40.46601279093371 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark06(-0.047684208458988,-26.021598205381235,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark06(-0.04899243539003374,-157.4164778867301,-1.2592907779947877 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark06(0.049004512669077176,-1.53438429269496,-0.1262618993566948 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark06(-0.04932181388268578,-100.92580482003943,-90.78479112995471 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark06(-0.04954940472673194,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark06(-0.04962453855503693,-0.46449599165255473,23.6842285494248 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark06(-0.05002300412708138,1.5707963267948983,29.84513026440508 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark06(-0.05014641872891101,1.5707963267948966,21.899132250705435 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark06(-0.050422323896868626,-1.5707963267948966,16.506887482267857 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark06(-0.05088048296555339,-1.5707963267948966,-10.973902716632193 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark06(-0.050943335531593026,83.6020278884989,26.418125134656776 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark06(-0.0515394092868352,48.453932720958846,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark06(-0.05165192761812129,-1.5707963267948966,-21.24583413468642 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark06(-0.051685635488429096,-1.5707963267948966,-81.6212245018327 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark06(-0.05175564266801769,-1.5707963267948966,43.53311685068883 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark06(-0.05192541417826227,-1.5707963267948966,-66.90317933667956 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark06(-0.05218868145212077,-32.756157201100166,0.11859482177778213 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark06(-0.052703426936532294,0.3023544835072619,-4.723955086204576 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark06(-0.0527100986956692,-1.570796325431358,-44.1460234699057 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark06(-0.05321872619587688,-4.440892098500626E-16,89.96415490055162 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark06(-0.05373883058138573,-1.5707963267948966,-22.923928392601358 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark06(-0.054068913072146334,-1.3526054286138998,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark06(-0.05414651637143123,-1.1667961517176266,1.5707963267948966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark06(-0.05476345920933193,-1.293920167692736,91.93663925655548 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark06(-0.05482333503995751,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark06(-0.054922796003676666,-32.97605505307077,-0.24626602386443364 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark06(-0.055078424576405605,-1.5707963267948966,-31.915678584981862 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark06(-0.0555835438772318,-1.5707963267948957,66.45992124048321 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark06(-0.05598172328559918,-1.5707963267948966,-4.141592653590403 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark06(-0.05606244567080232,-95.56705433436082,-83.41947576341788 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark06(-0.056172167847256024,-0.3687121720671721,8.983019317544922 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark06(-0.0563774874074313,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark06(-0.0565293609204892,1.5707963267948974,1.5707963267948983 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark06(-0.056628115809079116,-0.6218002333467595,0.3277142691611831 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark06(-0.05663591955635879,-88.45623132501055,-1.5707963267948966 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark06(-0.056859241412072443,-84.7255677264094,-1.1054869490365584 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark06(-0.057080762245584796,-0.07765289523555804,35.04499506476611 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark06(-0.05776856562458251,-38.76021760231738,27.588918856987423 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark06(0.05782507250833484,-0.38541815992790296,100.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark06(-0.05786022466307863,-1.5707963267948966,35.56627354541543 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark06(-0.05821548668473131,6.938893903907228E-18,-45.509830078048104 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark06(-0.058417768841996676,-1.5707963267948966,-79.17004712284259 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark06(-0.05844701662329932,-163.56243397159352,-2.98527728702903 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark06(-0.05881401929706165,-1.5707963267948948,31.09214768680539 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark06(-0.05882179547515082,-0.864530242744314,-83.68001802395669 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark06(-0.05888718129513957,79.5084898824374,0.9323345712343181 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark06(-0.059054277326833396,-1.5707963267948966,-1.5707963267948954 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark06(-0.05932934215007157,-1.2703623994983135,73.24529827958665 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark06(-0.05955219877334224,-1.3309487996128295,-15.506291533342447 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark06(-0.05983539634769553,-44.37580801448615,-22.376375077235984 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark06(-0.06090863987041795,-1.5707963267948966,-9.424777960777119 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark06(-0.061190651525701356,-1.5707963267948966,-0.32309634575709706 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark06(-0.061369459195021084,-1.570395080950365,-85.24160937562849 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark06(-0.06140952864388194,-5.169878828456423E-26,78.79597888348441 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark06(-0.06217722642383561,1.734723475976807E-18,-37.93098343691332 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark06(0.06250413015022263,-1.5707963267948966,-0.07052012397995505 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark06(-0.06270882372616701,-1.5619935801736946,1.5707963267948961 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark06(-0.0632733035906381,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark06(-0.06351211925207245,-1.5707963267948966,44.45308656539376 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark06(-0.06360481408796659,-1.5707963267948966,92.31769619741931 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark06(-0.06376115233367524,-0.03106080069078815,21.111344418624462 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark06(-0.06387437759745777,-0.19077757636048281,55.618892386843925 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark06(-0.06404876901045559,-32.95422914310536,8.770629886802318 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark06(-0.06423479241666702,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark06(-0.06508669626595268,-45.05236498950773,0.02804690378050667 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark06(-0.06508783127666196,1.5707963267948948,-7.8117159184692415 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark06(-0.0652020889961411,-31.815068720102403,-12.4920049041164 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark06(-0.0655654206844105,-1.5707963267948966,-66.32193311095072 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark06(-0.06576198073409639,-164.9326450606686,-35.99893790852549 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark06(-0.06699409105982863,65.6724591918416,-23.224857185914107 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark06(-0.06769382267839424,-32.591888517310295,-99.85994101738436 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark06(-0.06832576910543639,-1.5707963267948966,-97.62422007269606 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark06(-0.06857080222080754,-44.22216486896047,-152.44338448275218 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark06(-0.06874199700674355,-158.10637124539548,-67.19004613193772 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark06(-0.06878662593068363,1.5707963267948966,35.718923355518605 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark06(-0.06942889643061512,-1.5707963267948912,48.708025354300965 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark06(-0.06963628541431532,-1.5707963267948948,50.57585090422961 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark06(-0.07011875502248514,-1.5707963267948966,52.44314898379707 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark06(-0.0702634329585353,47.39446532979351,0.4091925360550306 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark06(-0.07051981328219425,-1.5707963267948961,10.574244084375776 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark06(-0.07072447885100411,-1.5707963267948966,-16.658954874207517 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark06(-0.0707484888755937,-44.315300877173684,3.777218501182406E-15 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark06(-0.07091193449790259,-95.78753827255584,-87.96459430051421 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark06(-0.07162118496409606,0.6684287322689946,65.50370704868483 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark06(-0.07162782723141803,1.5707963267948966,1.5252817659323552E-16 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark06(-0.07164822898900891,47.20291661468518,-14.461509190864525 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark06(-0.07172722214567674,-44.27212732178508,-9.753157935358093 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark06(-0.07197443357611495,-1.5707963267948966,-0.6696126151501289 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark06(0.0720661670932462,1.2137489368213634,-28.56745693898105 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark06(-0.0722428309646933,1.230923103485255,45.553093477052 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark06(-0.07237007840128484,-1.5707963267948912,27.297935205540327 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark06(-0.0726772448902344,-1.5707963267948948,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark06(-0.07315845168983086,-1.0797850578190288E-15,2.465190328815662E-32 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark06(-0.0733483837584995,1.5707963267948966,78.75195235508227 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark06(-0.07347089393439399,-44.09748197318096,1.5707963267948968 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark06(-0.07365246180956636,-1.5707963267948963,1.5708001427300289 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark06(-0.07447269066600004,-157.45133662477352,39.88762107807986 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark06(-0.07469252055954234,-0.1476895119370053,-100.0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark06(-0.07517910082953183,49.298588686365235,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark06(-0.07532693595860918,-38.7186394665211,-1.5707963267948968 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark06(-0.0756369479594458,-1.3489542703565591,-71.537474896207 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark06(-0.07570429647462995,-0.7897547730042862,89.63480039205896 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark06(-0.07573151494651861,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark06(-0.07621439909369962,-44.407782815987616,-29.071605780612032 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark06(-0.076730934969795,99.40548101356053,-72.50521682016992 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark06(-0.07684625688139173,-39.13103103441229,-0.525253280303962 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark06(-0.07722206737372289,6.712388980767845,1.5707963267948974 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark06(-0.07731759326518645,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark06(-0.07737284962557446,-1.5707963267948966,-78.59892989529023 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark06(-0.07744078830419446,-1.5479993365055962,53.82503399650082 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark06(-0.07744796329663525,1.5707963267948966,12.572901545250097 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark06(-0.07747277757732551,90.9523429759479,-87.24700585451455 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark06(-0.07767113709616219,-43.98230822801577,-1.5707963267948966 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark06(-0.07773041723963016,-32.73512961322392,-100.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark06(-0.07773165356843204,-89.77761076895989,1.179081953632339 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark06(-0.0782766183582157,-1.5707963267948966,-33.45750635410043 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark06(0.07840191482253824,0.3033794965022791,69.3646476752598 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark06(-0.07859124517200211,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark06(-0.07864365215988356,5.983030142564389,0.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark06(-0.07875917160599373,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark06(-0.07879115362536471,-0.623715845048082,-75.85581303020206 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark06(-0.07901371018408554,-1.405408556981726,-72.2628623030497 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark06(-0.07906972968326176,-0.0039029246143079213,1.5707963267948912 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark06(-0.07918782269407755,-1.5707963267948966,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark06(-0.07938912719973552,-7.343173036644085E-4,-86.24292644711454 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark06(-0.08141412889756972,0.5874674485166684,-67.13597953960783 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark06(-0.08158689867506677,-1.5707963267948966,-85.30367053530652 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark06(-0.08168195764408634,-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark06(-0.08250273835247292,-1.5707963267948957,60.41438921005866 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark06(-0.08325688472708702,-4.152734851840173E-16,-1.529156105673908 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark06(-0.08351596030155362,-0.8131553096930456,3.141592653589793 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark06(-0.0838363774252289,-45.44113492780454,-28.356857735226264 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark06(-0.08475988425499308,-0.9648150728199091,1.5707963267948948 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark06(-0.08499382609844422,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark06(-0.08513818687459251,0.4424990152071716,-32.79812379484157 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark06(-0.0853421223656392,-1.5707963267948961,86.48014276994853 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark06(-0.08559993886281464,-1.5169568821127657,99.84583040127194 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark06(-0.08653784764966704,-1.5707963267948966,0.7137077320255392 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark06(-0.08664115246733996,-32.68928520637973,-89.24496104497454 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark06(-0.0867483019402361,-1.5707963267948966,72.756631047182 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark06(-0.08676229802561863,-1.5707963267948966,11.84900911079994 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark06(-0.08689209734743353,59.22897523058103,1.5707963267948966 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark06(-0.08689844960762139,-1.5707963267948966,-39.31996971076761 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark06(-0.08704573098823443,1.5601462523883638,-1.5707963267948983 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark06(-0.08710763181378661,-37.91810467481241,-65.6400115553824 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark06(-0.08711673277650728,-45.15124875229593,-45.86796265546346 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark06(-0.08719780546779933,-19.36422969369658,2.486181085744059 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark06(-0.08771619395854258,1.3877787807814457E-17,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark06(-0.08812186269227627,165.84810419835387,-88.44312388980148 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark06(-0.08861974168784005,-19.41027621478267,-4.714342109471078 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark06(-0.08881949326336258,-1.467783066800512,1.5707963267948966 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark06(-0.08906031780689583,-0.1768861164813074,2286.6739765170196 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark06(-0.08918422141719495,-3.469446951953614E-18,-80.13277480126114 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark06(-0.08933093966214137,-45.22170114051702,-1.5707963267948966 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark06(-0.0896121669012527,-0.8887173498128615,0.0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark06(-0.08979626170128407,-1.5707963267948948,-2346.887177874624 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark06(-0.08996331975958025,1.5707963267949054,1.5707963267948966 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark06(-0.09019281740459989,-1.5707963267948966,43.16855175449069 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark06(-0.09021984915883814,-38.89211409343265,-103.34594358698082 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark06(-0.0906458523220119,6.712388980472829,-4.553974932775967 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark06(-0.09080581162249768,-1.5707963267948966,-49.222568629205135 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark06(-0.09103573035464146,-1.5707963267948966,60.838050765104214 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark06(-0.09109408960110649,-45.379336902479814,-0.014873072300924578 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark06(-0.09189997309717594,-1.4722563191374924,-1.5707963191610914 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark06(-0.09315879552498463,-31.41592653589793,-1.5707963267948966 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark06(0.09316620658762591,1.5707963267948966,5.270358707972621E-16 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark06(-0.09320051598464103,-1.5707963267948966,-5.076656425626851 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark06(-0.09368498398949392,-1.5707963267948966,-0.1862858804948786 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark06(-0.09420994953137518,-1.5707963267948966,-0.08230255718686097 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark06(-0.09461185375921859,-1.5707963267948966,-66.38243309365424 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark06(-0.09489494376960295,-101.74070780422049,-65.31657037380788 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark06(-0.09533862560236936,-1.5707963267571978,-19.972218372114305 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark06(0.09630021740436982,1.4500631030518945,-57.49666784783722 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark06(-0.09646966599941986,-1.5707963267948966,72.4486296237276 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark06(-0.09663151236882161,4.599490362920006,-0.5571348748097892 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark06(-0.09681838389835917,-1.5707963267948966,28.8116222865307 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark06(-0.0979907972446069,1.5707963267948963,-7.099578747812282 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark06(-0.09811871606020134,-45.54558009944392,-76.45032351224697 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark06(-0.09837245719900377,1.5707963267948983,2334.3158720917068 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark06(0.09866118720630046,14.429466961853471,-22.280484083893825 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark06(-0.09873745464497136,-88.2338859101239,-85.19417625292854 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark06(-0.09882707310341948,-1.5707963267948963,-1.5592295877300266 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark06(-0.09935811137762818,1.5707963267948966,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark06(-0.0994319194511396,-1.5707963267948966,37.58171210422971 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark06(-0.09950504746761447,-1.5707963267850866,10.636434586026027 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark06(-0.09975480373277859,-1.5707963267948966,-65.44187527700669 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark06(-0.10021373226886965,-1.5707963267948966,-18.954533635432952 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark06(-0.1003054043959366,-158.616509432641,-34.85270041003268 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark06(-0.10036651062581088,-5.551115123125783E-17,-42.738464685340396 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark06(-0.10037673550473303,0.08084287668667278,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark06(-0.1009324837504606,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark06(-0.1011200891648274,-32.722623780770626,-74.37479401291635 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark06(-0.10119981545437763,8.673617379884035E-19,-26.11321516187177 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark06(-0.10147292429542176,-31.843478125288442,-53.193437011909005 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark06(-0.10154061575540331,-45.44031018602053,0.9776158822163908 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark06(-0.10166490668171276,-1.552367222389558,-59.185705076280406 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark06(-0.10189351831104376,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark06(-0.10197034859951294,-1.2497918904963485,21.157968905721173 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark06(-0.10219570979293062,-0.770949821678438,73.22547076186254 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark06(-0.1022191450443708,-1.5707963267948966,-56.02078734470628 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark06(-0.10283418207914329,1.5707963267948966,-2211.172225280596 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark06(-0.10367194018207092,-0.3437456621981026,95.54047332864539 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark06(-0.10379306144949003,1.5476464653891386,58.26537124887919 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark06(-0.103964197849447,-1.570796275383529,67.3132201979732 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark06(-0.10409357158106548,6.7123889806230395,-44.2522366404096 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark06(-0.10413773594891962,-0.5949908303276575,-96.40891431212779 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark06(-0.10431199018951717,90.95372120508077,49.63610927452603 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark06(-0.10477427505084258,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark06(-0.10501824900905131,33.71097037705641,-13.728789786558082 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark06(-0.10527164497012953,55.78232026691729,-17.75557997448319 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark06(-0.10547433977305332,-19.406977655767456,64.45064589839427 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark06(-0.10550802202694776,-1.2893182397128795,-485.425650351503 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark06(-0.10584599559575791,1.5707963267948966,64.12581347565735 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark06(-0.1063660989415966,-1.362085278193231,-17.22450740096764 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark06(-0.10737899726970304,-1.5707963267948966,-4.2041384809400375 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark06(-0.1074107652073546,-1.1111288443090768,-11.571538210025683 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark06(-0.1076490509736944,-1.5707963267948966,-11.12057430917496 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark06(-0.1076611317649615,35.43752723322048,1868.1351459387447 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark06(-0.10809487946425633,-1.6812012465301333E-15,-20.59265506193543 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark06(-0.10817815814942966,-31.98616572845367,71.32263163839202 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark06(0.10870563381280708,1.6132536558712627,51.22550082961098 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark06(-0.10914797402498885,-1.3348180677190176,-3.1064041598118497E-6 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark06(-0.10920635163469838,-1.5707963267948966,-75.85241017520144 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark06(-0.10929867324599696,-31.737012888753924,31.82440506679192 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark06(-0.10971502025853268,-32.79137434090585,-190.2651840722381 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark06(-0.10980316245161603,0.0,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark06(-0.11126487735009566,-0.0766002383682671,-85.75281034172883 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark06(-0.11172553166284033,-0.18736877507583566,-11.45413675439017 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark06(-0.11267553377006267,-1.1102230246251565E-16,-18.451053608310954 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark06(-0.11274783521892542,-1.5707963267948966,-22.563254163967258 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark06(-0.1134691898450455,-88.29974176606657,4.7436389808722375 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark06(-0.11434344875880242,-0.5150672044169227,9.016580681431383E-131 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark06(-0.11483141847689549,-32.7259510542678,-56.161781404820225 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark06(-0.1150025023018356,16.77200454779115,1.5707963267948966 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark06(-0.11572918821088987,6.712388991846094,-65.8856797252303 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark06(-0.11593704079156897,-1.1992508080015605,1.5707963267948966 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark06(-0.11683216831227922,-0.09783671795833869,29.093483032512523 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark06(-0.1168670589870473,-157.21172320027208,-121.2844167979126 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark06(-0.11801446257798887,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark06(-0.11860586531061748,1.3552527156068805E-20,36.249556661574985 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark06(-0.11909776979794647,-1.5707963267948966,109.98377678992568 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark06(-0.11923744306262929,-1.2125370499173689,-1.5707963267948966 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark06(-0.11924119575813842,-1.5707963267948966,38.8223554756183 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark06(0.11970469474825662,1.188660747004809,-69.55196421738334 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark06(-0.11973201586341098,-32.68129370290886,-42.758743808714485 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark06(-0.1198678434305922,1.6940658945086007E-21,-3.2219964651549704 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark06(-0.12044318275430144,1.5707963267948966,-0.4157254146286669 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark06(-0.12045614539363278,-1.5707963267948966,-73.65556050692906 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark06(-0.12053901777967159,-1.5707963267948966,-18.04293613753258 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark06(-0.12099046068845858,-88.52754408666163,-77.87412104282105 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark06(-0.1209916509797834,-20.807160024407093,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark06(-0.12348203525562372,1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark06(-0.12368984820817364,-88.371497160931,-4.138417220962909 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark06(-0.1238175210315772,-0.9800869896839534,4.76577814460139 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark06(-0.1239913450742537,-1.5106880392762183,53.67661997572219 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark06(-0.12420478539885227,-0.9382588757739008,-50.015737011845864 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark06(-0.12477643638855351,-45.53088459506271,-86.15929099849228 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark06(-0.12497335784909647,-0.02072378784612816,1089.2891786163032 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark06(-0.124980896081993,1.5707963267948966,53.95847032727373 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark06(-0.12512070611577997,-0.08465240745656999,24.709126360345408 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark06(-0.12532217054605527,-0.810988762668114,89.91354131339429 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark06(-0.1254105550891574,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark06(-0.12578589432966836,-45.553093471309644,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark06(-0.12593349374838658,-1.5707963267948966,19.900879344072536 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark06(-0.12646085767532722,-38.7408334161545,-0.022209556191779493 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark06(-0.12685947960700064,-1.5707963267948966,-3.1415926535897936 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark06(-0.1270057128840246,1.3323886253461037,-85.15986986285179 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark06(-0.12746178665437244,3.141592653601803,79.94432206574515 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark06(-0.12752252047660265,-1.5707963267948966,1.58642132679677 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark06(-0.12932416182494216,-100.63708110233873,-1.7272763120584784 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark06(-0.1297769303337171,-1.5707963267948963,-4.74363898921513 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark06(-0.12978015100363446,-94.29664593462367,0.26162010989212564 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark06(-0.12982064048329367,0.1844241164437554,-1.3200667706920939 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark06(-0.1303991241139304,-32.53198018439683,-119.00790343490382 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark06(-0.13095289287491596,-157.2033683461106,-3.141592817602006 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark06(-0.13095488357875962,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark06(-0.1310864648662854,1.5707963267948966,22.15532087462168 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark06(-0.13164090433086648,1.5707963267948966,91.7203854179323 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark06(-0.1316781160752509,-1.4852965564257286,62.02055810357987 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark06(-0.13207015479100623,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark06(-0.13214435359251198,-1.5707963267948664,59.06562380848979 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark06(-0.13262028869128228,0.08348541493418268,39.94861271394494 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark06(-0.13276334441073162,-1.570796325384289,24.878512498769553 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark06(-0.13304302487890607,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark06(-0.13306848553573541,-1.7763568394002505E-15,0.4674359162171347 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark06(-0.13307207436708168,-31.66546150858248,-62.43166838653471 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark06(-0.13339782760467003,-100.74385093070924,-9.645124459699652 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark06(-0.1337584969489427,-1.5707963267948912,25.602653583748648 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark06(-0.1339855569622185,-1.5707963267948966,50.41388758612756 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark06(-0.1342217273090076,-38.93060609854822,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark06(-0.13447165801451763,0.14362617359707197,16.42019620730575 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark06(-0.1347578615087486,-1.5707963267948928,-83.75918316519885 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark06(-0.13491925263916055,-38.8094277037392,-42.13262717781805 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark06(-0.1353848671877413,-31.41592653637699,-68.29518798067173 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark06(-0.1355696969594058,-1.5707963267948966,39.03075105991734 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark06(0.1357279462207378,4.459571115425622,-175.2178913940747 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark06(-0.13612000175194958,1.3249342324625568,-100.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark06(-0.13623069374998778,-43.9827611219141,0.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark06(-0.13631934430786175,41.268050388652064,1.5707963267948966 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark06(-0.1364702278052814,-1.5707963267948966,64.12100769203047 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark06(-0.1369309199071427,-0.9290574472059572,-1.5707963266314056 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark06(-0.136933170134935,6.712388984000696,-1.5707963267948966 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark06(-0.13699171315886796,-1.352347034441933,-1.5707963267948966 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark06(-0.13702001471953737,4.3250927625807964,56.506013017431044 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark06(-0.1373623571799314,-95.73727990852333,-29.880581229712178 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark06(-0.1379484852287933,-1.5707963267948966,62.953211657703854 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark06(-0.13847218433208971,-0.017073385604937777,69.19766043000021 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark06(-0.1385348371949322,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark06(-0.13883687624312235,-0.6503251262230085,0.20445020477602077 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark06(-0.1390952694287016,-1.5707963267948948,-4.298599498273742 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark06(-0.1392988581244157,-1.5707963267948966,-98.71137626704125 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark06(-0.13944984598322854,-1.5707963267948966,-1.3130673187605542 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark06(-0.13976754171151773,-88.48630947090396,-3.141592953556183 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark06(-0.1418999042001926,-52.0657414616547,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark06(-0.14197646057693833,0.0,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark06(-0.1429547567738832,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark06(-0.14341955165027895,-31.973217901240808,-3.317098600085045 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark06(-0.14343198431903592,-32.54882684456866,-25.567230510075785 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark06(-0.14345873842798645,-32.70614906313632,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark06(-0.1436810972405027,-0.43978211110136556,-25.44631169581223 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark06(-0.14419176123739758,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark06(-0.14464559483551453,-1.5707963267948966,41.944234395568905 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark06(-0.14467410421559396,-31.936634769363692,-0.9068024968475797 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark06(-0.14573040643285395,-0.1303797519065979,72.75415164518319 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark06(-0.14666339388244415,-88.374786495764,0.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark06(-0.14710109830214124,-0.421606090065638,-69.75520991557367 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark06(-0.14718405392857176,-32.81266032145484,-50.71503988397299 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark06(-0.14732004467297372,-88.50164435034532,-63.09818271841865 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark06(-0.14790389411274404,48.68087792573638,1.5707963267948948 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark06(0.14847542369722733,-1.5707963267948966,-1.4315925605534703 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark06(-0.14883279762765197,-95.35526677001553,-28.50888312431654 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark06(-0.1490655643041574,-1.5707963267948948,-2.4034504928563147 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark06(-0.14908759387208623,130.16770555630217,0.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark06(-0.14977726436038097,-1.5707963267948966,-85.85084710138725 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark06(-0.14979289341044139,-32.63246107112639,0.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark06(-0.15000530159805903,-1.2266242876295106,0.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark06(-0.15014286203379257,-1.5707963267948966,55.6472249830795 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark06(-0.15026118583029285,-1.1591269220898192E-69,31.955011118516246 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark06(-0.1508051512198776,-1.570796326794895,-20.83735376720645 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark06(-0.1511089104709278,-0.6406684455917876,-61.65740560763382 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark06(-0.15155722202174382,-1.5707963267948966,14.13907764659478 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark06(-0.15264721936098802,-31.47286295190988,0.6348842490867643 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark06(-0.15302281477151616,-0.6172415907387877,-0.5200138372476599 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark06(-0.1531809351158238,0.9283894142463381,7.579800844806841 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark06(-0.1535927857778991,-1.5707963267948966,-84.14420953357218 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark06(-0.15479271187523988,-1.443502570168284,40.00490993993867 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark06(-0.15592061597133317,-3.1415926535897936,80.08907015336143 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark06(-0.156207499645323,-0.5097830603613751,-169.316293701187 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark06(-0.15626813245586052,-1.5707963267948966,21.190835045334143 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark06(-0.15643377435382244,-0.7977877120412273,-34.229805873023395 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark06(-0.15731577171945332,-44.29025877493836,1.57078747267392 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark06(-0.1573818668073078,-1.5707963267948966,54.16032972073015 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark06(-0.15842362456525602,0.001592887881698981,106.8408191974378 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark06(-0.15896046356848453,-1.366306524308132,-84.68479106335845 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark06(-0.158984018124655,-1.5707963267948966,-80.12973385395402 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark06(-0.1594640670327033,0.6850129412174786,-186.13441370304065 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark06(-0.16008925918336941,-1.5707963267948966,-183.78322330235443 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark06(-0.16009754163761045,-1.5707963267948966,61.362009509637105 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark06(-0.16105469674915063,-1.5707963267948957,14.278205033991746 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark06(-0.1612064119624037,-95.56081484903086,64.66114649707762 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark06(-0.1616120970990581,-1.5707963267948966,-1.5707963267948841 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark06(-0.16165987383384472,-1.5707963267948966,-0.5721984069409877 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark06(-0.16209466613999368,1.5707963267948966,72.58203923409432 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark06(-0.16211889475164315,-1.5383867016504087,-44.512837696939734 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark06(-0.1622569286535689,-0.3800742204217511,-33.99016168426128 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark06(-0.16235597555076908,-45.341617826802306,-88.2849076358026 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark06(-0.1625475874993189,-4.79338450145981E-16,19.3828523506298 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark06(-0.1631258059172107,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark06(0.16365386390177228,-1.5707963267948966,-0.04883895418282255 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark06(0.1637830234147998,-1.3137866005840884,0.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark06(-0.1646734756328712,-1.3328917558213715,1.5707963255686217 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark06(-0.16496179848802228,-1.2272078409430898,68.70278957065442 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark06(-0.16500131827243805,-0.16733890425549716,-0.5656372427410604 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark06(-0.1652352414461754,-0.004424706451096161,68.4952365626029 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark06(-0.16526391082781733,6.712388980384692,-64.4680385762251 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark06(-0.16560838152638713,-0.46257111042904053,83.60596035653421 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark06(-0.16565312413378008,0.4240115559893991,17.12634057858835 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark06(-0.16580163806489742,-3.1415926535897936,-38.795851838421335 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark06(-0.16588309133700352,-1.5524905334335162,-2.5707915319011585 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark06(-0.16620909786619786,-0.03331475862233545,18.036457020414723 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark06(-0.16625649615317978,-1.5707963267947782,-96.80337155216215 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark06(-0.16635068610916912,1.3476682519849703,-26.549709993411728 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark06(-0.16676419750328098,-95.44429919539118,14.67952132408412 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark06(-0.1668056256750301,4.3368086899420177E-19,39.07076505920791 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark06(-0.16728473501466684,-1.570796325463937,-0.5994233805267547 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark06(-0.16731665321879896,-45.08320555659569,9.424779149410728 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark06(-0.16754923552892853,-45.252601568639164,-1.5707963267948983 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark06(-0.16757713089633075,6.712411927634232,0.25283389938772405 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark06(-0.16759176127284156,-1.5707963267948966,-0.4423151570400034 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark06(-0.1685334056624389,10.526725957268582,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark06(-0.16856648219304138,-18.898990976624713,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark06(-0.16856806243463612,-1.5707963267948966,-30.837957281495406 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark06(-0.1690664665857449,-1.5707963267948963,20.198427191314885 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark06(-0.16908556713853767,-1.5707963267948966,-3.1415927649523265 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark06(-0.16913456923863263,-31.819104805720208,-1.5707963267948966 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark06(-0.1696699736395776,-19.34955592284762,-34.085709990629184 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark06(-0.16969044604481587,-1.5707959676481886,181.99328578200308 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark06(-0.17107380137740072,-88.14698883683194,-90.95251235572995 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark06(-0.17151847331984016,-1.5707963267948966,-80.30202728484878 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark06(-0.17201030476448198,124.15924828906597,54.244682182263986 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark06(-0.17233354518559374,1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark06(-0.1727543854117358,92.4653798436546,-31.449383887473118 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark06(-0.1727613345468324,-32.87895043375855,-5.751929308965401 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark06(-0.17329622107622306,-45.43031666219692,-29.17587860606723 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark06(-0.1733510768912935,-39.12392338028462,71.96358883479465 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark06(-0.17344535305011238,-1.1102230246251565E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark06(-0.17373168531347005,-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark06(-0.17412410530103473,-88.35985035771184,-86.83880425630248 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark06(-0.17450369006553745,-1.5707963267948966,-0.12460238853924449 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark06(-0.17460230576080438,-158.3395801735974,-25.82144579679094 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark06(0.17559258266324865,-1.5707963267948966,2.435758372177792 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark06(-0.17574794601656069,8.673617379884035E-19,-49.69693394871594 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark06(-0.1763215391426498,-32.95565399062422,-1.5707963267948948 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark06(-0.1765661734451474,-1.1102230246251565E-16,86.78128308657001 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark06(-0.1773334131034519,-163.6628594762061,-73.77542813242574 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark06(-0.17928633993339604,1.5707963267948966,0.48432964900456 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark06(-0.17964608513748448,-1.5707963267948966,-76.96902770111633 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark06(-0.1797105064138517,-1.5707963267948966,-49.70851991531387 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark06(-0.18017336549584215,-1.5707963267948912,-45.488762598909595 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark06(-0.1802193272616542,80.6288390609163,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark06(0.18051265176534695,1.5707963267948966,98.89880054446445 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark06(-0.18104934179538645,-0.12726602042390348,1.5707963267948972 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark06(-0.1811438943763075,-1.5707963267948966,66.18862042845676 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark06(-0.1811490839484753,-1.5707963267948966,23.941343851925723 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark06(-0.18155272368862285,2.220446049250313E-16,-32.98672286269282 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark06(-0.1819218914103915,-1.5707963267948966,-5.107137037831423 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark06(0.18196361548231735,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark06(-0.18220966083645662,1.0251271244211466,-66.69210147132863 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark06(-0.182210424263739,-0.07342625724759899,0.07270471599249712 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark06(-0.182508431869239,-1.5707963267948966,3.364034713612861 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark06(-0.18255929509543334,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark06(-0.1827223234146297,-1.5707963267925273,1.5707963267949019 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark06(-0.18297568508027248,1.5707963267948966,0.0023773728713090527 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark06(-0.18307310719161216,99.77896651723154,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark06(-0.18365367784073794,100.0,0.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark06(-0.18487569935713952,0.08450917668565139,-76.24109641373396 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark06(-0.1851738867691335,-0.018340193694529355,32.8714282329166 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark06(0.18582254759178754,1.5707963267948966,23.561251497057736 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark06(-0.18590751456998345,1.5707963267948966,35.635942016092855 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark06(-0.18605601489023238,-1.0912172109624434,-99.68132223729214 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark06(-0.18638763920840296,-1.5707963267948966,72.17894632756406 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark06(-0.18703821976763688,1.5642266897005948,-25.83643586632745 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark06(-0.1874730466232677,-0.6451276068920454,-28.760430915463544 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark06(-0.18786000351865936,72.61222857083487,14.891387007300224 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark06(-0.18850002744964164,-1.5707963267948966,-0.8942449141701602 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark06(-0.19004280597989817,-1.5707963267948948,-24.98163501681951 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark06(-0.19039747637734136,66.66419760784811,47.89376342979719 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark06(0.19052048776912014,0.25966283905793214,25.132741228718345 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark06(-0.19073612499196285,-0.8919941094095489,-33.60983295561032 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark06(-0.1909764037787375,-3.3881317890172014E-21,89.1322722657327 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark06(-0.1920765349022494,1.5707963267948966,-0.3811643693751363 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark06(-0.19267262755293543,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark06(-0.19293777408391438,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark06(-0.19356073509672003,-0.1430804730625126,-110.22837836034674 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark06(-0.19361487390481014,0.044711272796792885,-84.82296753886106 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark06(-0.19374486042258143,-0.11697942612329984,-623.8195790972782 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark06(-0.19420685304033578,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark06(-0.19427587718240888,-1.0663849850690534,3.1415932811042637 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark06(-0.1943158793360782,-1.2425645184478071,114.80616242688153 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark06(-0.19432813722012102,-44.01318450837086,-1.5707976705565845 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark06(-0.19541849942768114,-1.5707963267948912,12.681627764666331 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark06(0.19543092579154953,83.90994052074058,-100.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark06(-0.1957669686169313,1.275228559394519,-17.879333153471805 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark06(-0.19591043998310598,-1.5707963267948966,-21.230003393618873 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark06(-0.19598638947767144,-1.5707963267948966,160.2767211860144 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark06(-0.19645996915085473,67.24742556754516,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark06(-0.1966050473220573,-1.1353117802459685,5.690918512329169 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark06(-0.19698475248132663,-1.5707963267949003,-49.79029905670281 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark06(-0.19718789511228038,35.38795711865736,67.79480871936796 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark06(-0.19737405680504583,-95.57891790229496,-64.76706805834223 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark06(-0.1977838508854229,9.887789992374282,0.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark06(-0.19783931537012223,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark06(-0.19846902783861964,-1.5707963267948966,8.316327812515919E-112 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark06(-0.1991988936105198,-84.82300164692441,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark06(-0.19924587611750155,-164.52646991610453,-2.067301857593465E-6 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark06(-0.19929991515455017,-31.444777489780364,-90.93831001290589 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark06(-0.19955834584288085,3.3881317890172014E-21,75.69561420886231 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark06(-0.20011941554193396,-94.26040913203386,91.10319256306528 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark06(-0.2005047596283562,-0.17740588884148561,1.5707963267949014 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark06(-0.2005451758891941,-1.5707963267948966,1.6338258846746003 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark06(-0.20065923896770776,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark06(-0.2008601829246278,9.912390801377295,5.372088124624433 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark06(-0.2013143780719765,1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark06(-0.20175709370063588,-44.32884040927662,-1.5707963267948966 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark06(-0.20189441552352605,-32.42872495167792,89.9499767053357 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark06(-0.20234112991354336,1.3552527156068805E-20,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark06(-0.2023421529347665,-1.5707963267948966,-0.37572993840123525 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark06(-0.20250769574157848,-19.362818143904562,-1.5707963267948966 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark06(-0.20357522216801965,-94.2477796076938,-9.584150363817415 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark06(-0.20383965013596805,-95.67185374569176,77.01851601231904 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark06(-0.20437511898543312,-1.5707963267948966,-1.3476460719304908 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark06(-0.20448955598806595,-1.5707963267948948,46.50491728221297 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark06(-0.2046581893920778,-1.5707963267948966,-99.42626372225573 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark06(-0.20497558321027778,-94.32075866831964,-43.39350515124492 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark06(-0.20498188898207076,-1.5707963267948966,8.581007632383566 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark06(-0.20508041258031803,-1.5707963267948966,-84.20160554232619 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark06(-0.20524159333604264,1.5707963267948966,0.9210232959234632 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark06(-0.20562980676415124,-0.1098718894623808,1.5707963267948966 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark06(-0.20575597390138797,1.5707963267948966,34.74423724378153 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark06(-0.2057700823220927,4.3368086899420177E-19,-21.40810366147751 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark06(-0.20641421312272046,-1.1102230246251565E-16,39.07507390281025 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark06(-0.20642130961369373,-1.5707963267948966,-1.571060457586979 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark06(-0.20655263302610294,-0.667407030688552,-123.8707878717958 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark06(-0.20680513978970183,0.46001792753567644,16.222044000673037 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark06(-0.20695870137031672,-0.9091954727969505,4.645184382881565 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark06(-0.20707255505115418,0.3187149041605375,37.74154454650564 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark06(-0.20822040525617333,-1.5707963267948966,-3.2665929086119116 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark06(-0.20831867832840795,-0.7459586982602449,1.5707963267948963 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark06(-0.20853867855734354,-0.2928494857527255,35.19015108318541 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark06(-0.20868700554424194,7.8539816339744775,-72.5238946195613 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark06(-0.20971233505577147,-1.5707963267948966,-64.31502230340047 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark06(-0.21099779145604183,-1.2901881857513473,-55.63747474483793 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark06(-0.21191298549082882,-0.5650619494832784,1.5707963267948983 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark06(-0.21299205823512812,-4.72842568330907E-15,-12.065741483921073 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark06(-0.21341954928258888,1.5707963267948968,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark06(-0.21343754381948232,22.958978629836018,0.03689656531405434 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark06(-0.21372251294326078,-0.5560563954544329,-1.5707963267948968 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark06(-0.21373092372635635,4.897153477934681E-4,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark06(-0.21416925704590273,-0.08901168323707105,1.5707963267948983 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark06(-0.21525499458937247,-1.5707963267948966,-823.0287999495774 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark06(-0.21577812564468196,-1.5707963267948966,2.2750820639469165 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark06(-0.21622384016956375,-0.39332899455596815,-30.61033793715533 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark06(-0.2162474590632674,-1.5707963267948717,-44.00718575733315 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark06(-0.21741707125832138,-1.5707963267948966,-3.266593115585167 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark06(-0.2176586834699803,-0.024342663401256213,67.47320543294663 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark06(-0.2192706758529345,-95.35259605728234,-95.81857599471037 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark06(-0.21996699214578563,-1.5707963267948966,-193.20535943435195 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark06(-0.21998051502374447,9.900938841557105,-1.5707963267948966 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark06(-0.22031754203612494,-31.793845451823117,96.27121679326767 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark06(-0.22049224369635997,-1.5707963267948966,-0.1018427425963203 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark06(-0.2208108516305194,-1.5707963267948966,-37.893321169982144 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark06(-0.2211211739230705,-1.5707963267948966,3.141592653589733 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark06(-0.22193295510513844,0.9952103422235397,-19.18784732239012 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark06(-0.22242633122059519,-44.303540189120326,-10.567669981616522 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark06(-0.22278832996293627,-1.7763568394002505E-15,-870.3250728548089 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark06(-0.22320145396448476,2.972142486784051,-1.5707963267948966 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark06(-0.2238314111773967,-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark06(-0.22385167976209175,-0.3602013563150691,67.4118297642909 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark06(-0.2239591951479134,-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark06(-0.2241238774867942,-0.3735487725746367,-50.900528983609036 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark06(-0.22422547821137595,-32.92469610212187,3.1415926531757195 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark06(-0.2242321004656948,-37.854700497399165,-0.1626074584587212 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark06(-0.22466281944005712,-37.69911184307752,-1.4305726348231476 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark06(-0.2256225969342689,6.712388980443629,-72.44936075726253 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark06(-0.22571379188009477,15.14611269297005,1.5707963267948966 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark06(-0.22582612592367468,-95.42274880820274,-29.92516598200271 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark06(-0.2259420111753931,-38.97726458338155,-40.840704496667314 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark06(-0.22615869511484277,-157.28433745777764,53.21454687029552 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark06(-0.22668523672633378,-45.548240755872,0.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark06(-0.22679470652792943,-45.31764565958561,-75.97432298971651 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark06(0.22685117444404881,1.5707963267948948,-75.85812871513383 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark06(-0.2270072295387544,-2.220446049250313E-16,10.606571686798407 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark06(-0.2270305314652924,-1.3877787807814457E-17,-82.76255590915555 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark06(-0.22736441278639452,-1.2636972899349335,69.11514668230726 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark06(-0.22755630608676114,-0.2861716208227951,6.517169140832129 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark06(-0.2284150793920886,-1.5707963267948966,2349.40580002349 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark06(-0.22922638309106855,-1.462761474666619,9.093651458576272 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark06(-0.22948053414201278,-4.383618698016806E-193,-20.777061306086463 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark06(-0.22959424563215003,-1.5707963267948966,-6.7148869369126984 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark06(-0.23041001021359184,179.5520698513576,-58.76240458472739 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark06(-0.23100909938940914,-8.881784197001252E-16,-110.52032588387233 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark06(-0.23110725145191868,-1.5707963267948966,26.723706007215057 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark06(-0.23170661387630426,-3.141592653591233,5.413014783965264 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark06(-0.23176294475416243,-1.5707963267948966,-72.25663103256524 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark06(-0.2324817517311395,-39.00620043159665,1.5717728892949108 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark06(0.23416124301663058,85.56072866930737,1.5064342510965 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark06(-0.2342415167752953,-39.05816811041784,53.37107275362447 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark06(-0.23425466415501026,-1.5707963267948961,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark06(-0.23440327028029284,9.571047004117652,0.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark06(-0.23461879139207853,-1.5707963267948966,2.305133844050865 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark06(-0.23528318548764568,1.5707963267948966,63.65822743187405 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark06(-0.2358378162147119,-84.67248386834571,-1.5707963267948966 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark06(-0.23642318760301873,-95.74701841416729,0.6559402697170125 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark06(-0.237258882825373,-94.29466991551149,-13.073677095610535 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark06(-0.23730915466380617,-3.141592653590689,-53.53142107936263 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark06(-0.2377660303373964,1.5707963267948968,73.41968983352032 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark06(-0.2378843161566457,-1.5707963267948966,-46.85093432415679 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark06(-0.23883605125225238,0.2636822557604193,44.259079268478644 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark06(-0.2391629142226564,-31.859841656897387,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark06(-0.23938906180937614,-1.5707963267948966,22.907134175887602 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark06(-0.23968612791861288,-95.27099467674508,-316.67945738863875 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark06(-0.24098247654384158,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark06(-0.2416141812840895,-95.55747168197371,-53.75537943669331 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark06(-0.24233014462314006,-0.9231735110398839,-78.681587580968 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark06(-0.24320320396214523,-45.46748022260865,-16.4551129334625 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark06(-0.24357061408093442,-5.8774717541114375E-39,-100.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark06(-0.24404491996940844,45.809533529726984,3.2417917322880495E-16 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark06(-0.2443037647598193,-0.4054334065036731,-157.62601630368528 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark06(-0.2443202198514749,-163.78416533499657,59.33767725903993 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark06(-0.24507682552199128,-0.7872102822833718,-0.2237695148458111 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark06(-0.24529372196952778,1.4718162296158352,-16.517207950830567 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark06(-0.2469339185648658,-1.5707963267948968,-86.27679447206003 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark06(-0.24708486835650642,1.5707963267948966,85.40647848783175 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark06(-0.24749116502872326,-32.625548278420155,14.037554793752747 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark06(-0.24792090579194767,0.0534894831613256,57.7460882410045 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark06(-0.2483855306904048,-1.5707963267948966,-85.7700406513113 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark06(-0.2492966948880948,-0.03404851414725912,-26.854671426415916 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark06(-0.2494646320295984,-1.5707963267948966,0.48562412750925826 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark06(-0.2496112486641564,-95.49168544183327,-3.141592653589793 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark06(-0.24999678229768374,-1.5707963267948983,10.93131290626713 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark06(-0.2500394065941289,-1.5707963267948983,-411.547417020378 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark06(-0.2501352611687382,6.712388980387827,-2.5130554501903895 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark06(-0.25051185030655587,1.5707963267948966,75.83082084440039 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark06(-0.25065104106175895,66.08562635705348,-1.5707963267948966 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark06(-0.2513550779496075,-1.5707963267948966,0.7775542595833344 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark06(-0.25223844349666674,-1.5707963267948966,-345.0041030917129 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark06(-0.2524840179141232,-1.5707963267948966,37.96868858747287 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark06(-0.2525649257339051,-0.05716411094471805,1.5707963267948966 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark06(-0.25259312349214724,-1.5707963267948966,-27.157250048904103 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark06(-0.2530203738978055,-1.5707963267948966,1.5711031379585125 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark06(-0.2534773906317782,-95.71160283500843,-165.9163864509379 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark06(-0.2535045514031257,-1.5707963267948966,4.402204073719867E-5 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark06(-0.25366758106293946,-1.5707963267948877,-83.10821762436652 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark06(-0.25431805261328577,-0.002424291501077029,-89.1874498507778 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark06(-0.2543744287748947,1.5707963267948966,80.06907754961807 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark06(-0.2545972524368646,-0.34484311044031357,69.86874684435548 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark06(-0.2546241242867027,-1.5707963267948966,15.617049358393434 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark06(-0.25515365883031255,-38.710816531723154,-0.6468584103212482 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark06(-0.2552652666950262,-1.5707963267948966,-64.85153847347848 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark06(-0.2555403955344926,-220.96997217966072,-4.146091672065528 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark06(-0.25673979505642897,-1.5707963267948983,-72.35368623379945 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark06(-0.2569509969207112,-1.5707963267948966,3.581408616120887 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark06(-0.25758676929390456,1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark06(-0.2580141705336405,-1.5707963267948966,52.527700830577515 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark06(-0.25926888507519585,-157.63015676404987,-71.23539207286541 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark06(-0.2593071417692414,-38.99722622467361,-1.5707963267948974 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark06(-0.2614761477344128,4.3368086899420177E-19,18.63693536108658 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark06(-0.2616588857913098,-37.909459332619214,-50.09047457410389 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark06(-0.2616932929119517,-1.5707963267948966,-55.084034747804154 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark06(-0.2617060285101463,-0.4934805639556933,-19.23456133825949 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark06(-0.2617430629333351,-1.5707963267948966,-3.141592653590021 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark06(-0.26230098508217914,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark06(-0.2624607786177588,6.712388986055432,-1.5707963267948966 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark06(-0.26298522541965275,-31.415930845243814,-218.5187224964504 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark06(-0.2633972000620969,-88.10337846233618,4.712390395354352 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark06(-0.2640209155167562,1.5707963267948966,0.19311273302695042 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark06(-0.2644838086147414,-45.33983835296624,-66.51340935988051 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark06(-0.2645135280240831,-145.02597792932653,-66.22479413815468 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark06(-0.2650534450317821,-1.5707963267948966,78.57534422452908 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark06(-0.266428386538448,-1.592522357792836E-4,-66.04547036286645 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark06(-0.26753674360579377,-0.3548023995878449,10.134924996311934 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark06(-0.26848164412549064,-45.35228036321338,-66.52483730117171 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark06(-0.26872332162446555,-0.19881283269851344,-1.5707963267948966 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark06(-0.2688976093286206,-0.004994580137365777,52.264808014341064 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark06(-0.2691587481452661,-1.5707963267948966,61.2115912859513 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark06(-0.26979070651627357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark06(-0.2698543957196118,-88.41366158323316,1.5707963267949054 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark06(-0.27021381486888285,-32.8916233870745,0.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark06(-0.2704383066064042,-0.9333785274956989,-80.71701259887618 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark06(-0.2718431026913999,-1.3705201009117136,0.8704031439186212 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark06(-0.27232030275026387,-95.49701312903251,4.714384427410837 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark06(-0.2743081880245149,-1.5707963267948966,-556.0594059559752 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark06(-0.274994419952558,-1.5707963267948966,32.15843584109882 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark06(-0.2750250902036848,-45.43659683524629,-60.19275421888265 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark06(-0.27505374646404424,1.5707963267948966,17.678365423504033 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark06(-0.27507864367548696,1.5707963267948966,72.94586855815996 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark06(-0.2752392642614675,1.5707963267948966,-32.85697762076866 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark06(0.27634493291707407,-1.5707963267948966,14.433335008787708 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark06(-0.2764714127437782,-95.795241746805,-1.5707963267948966 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark06(-0.2767003249811252,29.57658147346883,1.5707963267948966 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark06(-0.2767296322835584,-1.4010310140153017,58.98045322906071 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark06(-0.27947044884866346,-44.23367447135778,0.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark06(-0.2810426120349435,4.189211797169225,80.556481483625 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark06(0.28106834503067313,1.5707963267949019,6.606680124640285 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark06(-0.2811122616805495,-145.06767945466257,-75.61299410142655 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark06(-0.28150801169387196,-1.5707963267948966,-46.203058208415776 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark06(-0.2821367869947482,-158.35163943455603,-82.47603159866236 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark06(-0.28299328580187183,-0.5706584806508518,-127.4487942967677 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark06(-0.28302107032098434,-2647.0076495203434,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark06(-0.2831500830042408,-1.5439833237786913,1.5707963267948963 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark06(-0.2835761823878912,53.938657259625856,0.0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark06(-0.28433635384193945,-1.5707963267948966,72.79101879021587 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark06(-0.2844162094596868,-0.5673461045893108,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark06(-0.2849450917035625,-44.491726867669755,-65.46649610730793 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark06(-0.28505349777935884,-0.039981514941742964,38.441912971049554 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark06(-0.28575097149342843,-38.76725405042698,-1.5707963267948912 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark06(-0.28600590741533033,-0.08015317460583259,-69.73952482884212 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark06(-0.2868582989775099,-100.54147882862814,-6.212983758325092 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark06(-0.2868958172478043,-1.1410569639962227,1.571042237586454 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark06(-0.2872939483226973,-89.56160452871565,-75.16184100107976 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark06(-0.28756538043202046,3.066746314650344E-17,-85.20280675026781 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark06(-0.2877479388932273,-0.5134892568361334,0.002655573044827761 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark06(-0.2883264159018952,-37.93653779371816,95.28209618737786 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark06(-0.28848051945692665,-88.35274602354683,-53.76072164734896 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark06(-0.28891163472502895,-0.16672072648840985,-90.788659877834 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark06(-0.2889609263700897,-1.5707963267948966,50.8036594602111 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark06(-0.2895311096136966,9.860761315262648E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark06(-0.28983524998740773,-1.5707963267948966,-3.2665930767651625 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark06(-0.2898913451150663,1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark06(-0.2900102950723445,-1.8033161362862765E-130,87.35207205296342 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark06(-0.29013463512351717,-77.41584842870918,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark06(-0.2904471340424952,-44.164325460022816,1.5707963267948968 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark06(-0.29057359556838347,-0.9820039986328553,-62.7036461051039 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark06(-0.29066302185260273,-1.5707963267948966,-56.48112394812645 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark06(-0.29190346143753976,-95.57403505690749,-30.03109576409952 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark06(-0.2919320842065929,-227.7654673285506,-65.81386080351038 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark06(-0.2924236488211975,-39.25800523635008,-0.03712375391056 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark06(-0.292504131607739,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark06(-0.2925942860745252,-0.31307007162291917,-11.38435721788289 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark06(-0.2930303721284891,-0.10870261317995622,-1.5707963267948963 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark06(-0.2940426695106415,-1.5707963267948966,-42.50289656789401 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark06(-0.2942093206216635,0.016406188955221526,83.67773285240253 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark06(-0.29462646264436465,-44.50018615447023,-494.97487427036293 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark06(-0.29510997421350865,-0.1602705123128526,31.50199256267586 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark06(-0.2955405523683292,-95.27273728506442,-35.4767478679224 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark06(-0.2957830991783936,-1.5677755742224697,42.16568424872838 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark06(-0.29638642129045983,6.712388980384713,-1.5707963267948966 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark06(-0.2977136304113669,-158.4334966775168,-4.712389934135149 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark06(-0.2983537563997779,-88.42316732285269,0.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark06(-0.29954441948744587,-44.289418046623254,-79.06493564184689 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark06(-0.2998099518766537,-95.81290907507555,-91.358461650623 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark06(-0.29996681686953197,-1.5436423597453752,0.0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark06(-0.3000467313342609,-5.635362925894614E-132,73.61619021975044 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark06(-0.3000972873724195,-0.0917535996588068,81.32156104536847 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark06(-0.30062651216154496,-32.55462148697012,21.332444935443853 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark06(-0.3007636641322434,-1.5707963267948966,-0.3470005466563748 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark06(-0.30087344660310567,-1.5707963267948966,1.4338744611177248 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark06(-0.30138043391447017,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark06(-0.30243076422028037,-31.5904252871063,-3.1415927823626695 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark06(-0.3028152286260926,-0.2267842262205437,-4.141898838298329 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark06(-0.3038595994081492,-1.3722029280657944,35.23870200163169 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark06(-0.3042610146867921,-1.5707963267948966,61.89692469051815 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark06(0.3043294658312038,0.6180466191296511,10.838567390382602 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark06(-0.3053893017769269,-0.41892312195358994,-94.45496871300689 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark06(-0.3056857649255932,1.0203565379165711E-15,0.07725606317007076 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark06(-0.30628985569619094,1.2359372020090902,-76.96763285902183 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark06(-0.3065565587762348,6.725983645642625E-17,-1.1867106246504044 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark06(-0.3069911755541549,-1.5707963267948966,-0.48191063577688636 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark06(-0.3071995072765972,-1.5707963267842322,-62.90460058532469 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark06(-0.3072270023964433,9.639774942366785,-100.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark06(-0.30724475942512636,-227.76437252245572,40.4986320594507 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark06(-0.3075543651326392,-164.4949336653548,-56.38421790023579 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark06(-0.30790969163764903,1.8311098514185427,32.95257268482219 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark06(-0.3082306469920485,1.5707963267948983,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark06(-0.3084295429863053,-1.5707963267948966,73.02227102999208 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark06(-0.30863051189034296,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark06(-0.3092542628062539,0.04762067540451135,-20.27578015730731 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark06(-0.3093743246032814,4.2351647362715017E-22,-1.5707963267948983 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark06(-0.3095072991507279,-1.5707963267944702,-185.39963676374987 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark06(-0.30960888902981765,-1.5707963267948966,-9.298026588139301 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark06(-0.31014637093665876,-1.5707963267948966,-41.919651671496396 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark06(-0.3109495935107971,-1.5707963267948966,-4.541959125096071 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark06(-0.31132519128749625,9.714128385501352,-50.684559127864674 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark06(-0.3113321434683656,-88.42142646176167,-19.28344440801192 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark06(-0.3113486359517932,-45.43671189744933,-10.91821058655066 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark06(-0.3115101430946111,49.42262828819385,-86.24443969345988 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark06(-0.3118499692984112,-1.5707963267948966,-11.011200655132086 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark06(-0.31201570031066217,0.31778567466182217,70.79110811484239 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark06(-0.31271869810904773,-1.5707963267948966,3.266787246414305 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark06(-0.3130225101117935,1.4245449055345265,14.041268137992077 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark06(-0.31317660881585774,53.74191654976608,-1.5707963267948966 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark06(-0.3131787472671509,-1.5707963267948966,10.060698316774063 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark06(-0.3134470734319771,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark06(-0.31439969073890384,90.62850814340806,5.041206692253945 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark06(-0.3152458809821049,-1.8033161362862765E-130,-0.5967080340813261 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark06(-0.31534705628056703,2034.7540503538917,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark06(-0.3153967777115533,-2.465190328815662E-32,0.1990779688850448 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark06(-0.31544179359779845,-1.5707963267948948,36.37774853669041 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark06(-0.3158361359159304,-37.73806275326952,0.17729405501451906 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark06(-0.31601189784725153,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark06(-0.31633994122645603,-1.5707963267948966,-0.061217211558592055 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark06(-0.3165912137974705,-32.74564365813946,-14.181182216593267 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark06(-0.3175692645912799,72.57817866136506,-85.80977801499832 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark06(-0.3182111829686528,-1.4914638977384405,136.6069390071201 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark06(-0.3183532665624025,-1.0691058840368783E-50,55.7585270383151 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark06(-0.3183573234000983,-1.5707963267948966,-89.79177002581696 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark06(-0.31885820374319074,-94.31854879528541,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark06(-0.31918778331171827,-1.5707963267948966,-95.39348558034553 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark06(-0.3193420785516363,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark06(-0.32137357359591157,-163.76138226165543,107.06756796979545 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark06(-0.32138508124983123,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark06(-0.3214676095529576,-0.008941807525616241,4.361254566805471 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark06(-0.3217176068161912,0.30297572912137183,-100.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark06(-0.32197667978194233,6.712389417559247,90.10688205837715 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark06(-0.32228174859299275,-31.811818107749254,0.0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark06(-0.3233276847936809,73.7711832296273,-93.4356090065423 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark06(-0.32341392934787677,-95.76716513742251,88.45131022573813 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark06(-0.323623408192248,-95.45965788354793,-0.14971682612467113 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark06(-0.3243190322324899,-32.49616888582256,-166.77694564245604 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark06(-0.324459505588248,-31.58197828160806,1.570796326794896 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark06(-0.3245314542598995,1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark06(-0.32460528795726085,72.56461783896154,0.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark06(-0.32481827382722495,-45.291870940402106,-3.14159265368086 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark06(-0.32524422925300567,54.733137081655116,1.3204581402137752 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark06(-0.3256826663529668,-8.673617379884035E-19,-66.23888306189303 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark06(-0.3264975294457862,-32.67854348042749,-0.07153271220876789 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark06(-0.32677244038741593,-1.5707963267948966,7.773922837657082 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark06(-0.326934683800966,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark06(-0.3272696695170563,-0.3356234028017539,79.01757817172864 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark06(-0.32799905827103526,-37.7694362347536,0.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark06(-0.32866863140858826,-0.0034164105882800166,-56.05384275282137 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark06(-0.3293171875806922,-0.5109840758431072,-1.827684214344643 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark06(-0.3307572650563012,49.044765359818285,46.625567646710664 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark06(-0.3308430423708182,-1.2377466329949955,2304.7208192561575 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark06(-0.3309919124111543,6.7123889803846915,-87.8684656598137 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark06(-0.3311829019754855,-1.3444359005050712,141.14675109439736 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark06(-0.3313900673339134,-32.86791728630775,-3.141592653589793 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark06(-0.33206346609868587,-88.49517487632531,1.5707963267948912 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark06(-0.33310900595218396,-1.5017525922911157,2.710505431213761E-20 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark06(-0.33333926523064994,-1.5707963267948966,-65.25823997044705 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark06(-0.3333995678793755,-157.23891263559835,84.07498034902389 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark06(-0.333424065559079,-31.415926594950918,-32.040533892869554 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark06(-0.3335550079888971,-1.5707963267948966,-6.712388980384691 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark06(-0.33384943784296256,-32.70464602162426,-6.524058814236171 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark06(-0.33425165954567326,-0.6342708525733658,-733.9165262932426 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark06(-0.33435013597687374,-1.5707963267948946,-95.95343191909309 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark06(-0.33540351207211705,-43.982297150257104,-1.5707963267948983 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark06(-0.3355190403768754,66.05039629283809,100.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark06(-0.33555037790508724,-1.1188591847304616,53.753799012225436 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark06(-0.33575673297497516,-0.03249792646565386,-45.27876169718397 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark06(-0.33658599880623935,-43.983814127925925,-78.86478618298302 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark06(-0.33727085671879437,-31.713475328706522,14.61373558016409 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark06(-0.33752619239023635,-44.443296458173286,-1.570796326794898 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark06(0.33855555027583184,1.5707963267948966,24.039191975430207 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark06(-0.3391069944403617,-1.4424719140886229,-4.682675766582822 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark06(-0.33969799364074366,-32.41975275572304,28.255610438162215 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark06(-0.3398983102581661,-95.81486166349481,1.5707963267948983 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark06(-0.3403692925017623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark06(-0.3405339734446471,-1.3854572809604462,-58.66174072163085 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark06(-0.3406406144613524,-19.37859097183675,-310.9532552595523 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark06(-0.3408206382413812,-1.5707963267948966,-30.063605821890313 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark06(-0.3412640881380028,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark06(-0.3415628314073814,-0.695359159365097,95.55998221102004 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark06(-0.3420815246242682,-157.13547936083407,1.5707962941740283 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark06(-0.3422123062533238,-0.28459344088770994,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark06(-0.342933834485629,2.6469779601696886E-23,-73.89875576197856 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark06(-0.3429611668799684,-31.953684924299203,-1.5716588207956386 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark06(-0.3430908764817325,-1.5707963267948966,-49.37876671784826 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark06(-0.3436287597723297,-31.95253847627005,-48.76475801972414 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark06(-0.34385400840624225,-0.6969601050414695,-74.8695603071673 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark06(-0.34401007098349323,-45.37411291863298,9.304068301006495 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark06(-0.34425995244722607,-31.937302933059396,-75.28811139939533 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark06(-0.344900913622326,-0.05124233426018682,602.1695942899178 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark06(-0.3449383723165345,-1.5707963267948966,53.372129191235956 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark06(-0.3459744005243223,-1.5707963267948966,1.8130292253707698E-17 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark06(-0.3461184256592949,-88.40579697871239,-4.7143462824181475 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark06(-0.34626797269623577,1.009034756378683,76.3517464244753 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark06(-0.3470391570390385,-32.538524393993505,84.08462630181619 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark06(-0.34855186392407767,-1.5707963267948948,84.94583793131818 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark06(-0.34928412139797166,-0.29352921416808336,-84.29748794060703 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark06(-0.34937032515404237,1.3552527156068805E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark06(-0.3503956894039662,-1.5707963267948966,-65.08176218362385 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark06(-0.350849589786452,1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark06(-0.35204044879144264,-0.3385692773542104,-667.3806149373976 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark06(-0.35367562853813606,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark06(0.3544048675961683,1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark06(-0.3550611405434071,-0.25452722240799786,0.08812644867908548 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark06(-0.35630359819664625,-0.33939518367408134,39.19350431773768 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark06(-0.3563129160743449,-1.5249124598516224,0.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark06(-0.35638282531552024,-1.5707963267948966,-30.585186580907582 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark06(-0.35676350446410127,-102.09638173117584,-31.505872660701694 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark06(-0.35701961849865427,-0.6494953415464255,-752.5934519682559 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark06(-0.357293520366166,-1.5707963267948957,37.877504549424025 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark06(-0.3576766474878923,-39.02117943120268,-78.95429021760216 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark06(-0.3580154057950369,-1.0842021724855044E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark06(-0.3585835389073484,-1.5707963267948966,-67.11720422203116 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark06(-0.3588194987598393,1.5707963267948966,10.109803556279438 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark06(-0.3589171422308169,-1.3536254987134733,-1.5707963267948963 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark06(-0.35923165638208854,-100.59927718273555,-165.8910077598101 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark06(0.3592351817424836,1.5707963267948912,-16.56933082836444 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark06(-0.3598079974600209,73.35388388892976,0.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark06(-0.3602911855543418,-164.89256610673885,-106.30900171538882 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark06(-0.3604049683564622,65.7111447675291,-7.467055530855148 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark06(-0.3606584593572396,-1.5686256242938927,5.141592656875794 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark06(-0.36079341100536855,-0.002447220187562306,-3.1415926535897967 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark06(-0.3611740140753001,-88.31802413899375,-1.5707963267948983 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark06(-0.36172025768126415,-1.5707963267948966,-62.15081121492749 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark06(-0.3617369054251714,-1.0248068642063795,3.141592653589793 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark06(-0.36182277416025954,-94.25330886243928,-48.28079767521984 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark06(-0.3629213121348336,6.712436817083287,196.77878303881124 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark06(-0.36319539903171894,-0.5547523545532365,63.40993959180735 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark06(-0.36375382022620717,-100.91672415640986,-45.560913906998806 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark06(0.3638535544668592,1.5707963267948966,4.220176603195753 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark06(-0.3644122160560881,-1.5707963267948966,-2.8223641192336473 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark06(-0.3646506126785856,-88.36943245044831,-9.424777961978164 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark06(-0.3648298286805224,99.31673083838804,0.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark06(-0.36504870217376545,-5.770611636116085E-129,64.20916656482053 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark06(-0.36534290289661253,0.3216073077997129,-1.5707963267948966 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark06(-0.3658069311392973,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark06(-0.36597330457704746,-0.3663710220315055,59.099551972944084 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark06(-0.36647792973262233,-1.5707963267948963,-37.11890468331951 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark06(-0.36775347396113145,-31.41685527480291,-122.95862143609901 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark06(-0.36786681995936316,-1.4628150638894388,-35.302614515261254 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark06(-0.3693381099938884,-1.5707963267948966,101.09030819359596 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark06(-0.36974744092326856,-1.5707963262795455,-26.96323507021366 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark06(-0.36983090790150813,2.710505431213761E-20,51.909468693610876 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark06(-0.3700519335979635,-1.5707963267948966,454.12169788887195 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark06(-0.37025421969944006,-101.76590246516236,-20.616772402094497 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark06(-0.37038408194094935,-3.141592656026492,1.5707963267948961 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark06(-0.3709627170874221,-39.21135071258861,14.431119185350305 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark06(-0.37146406262665643,-1.375305339184883,1.5707963267948968 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark06(-0.37255837858041224,-3.141592654011144,149.61099236258775 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark06(-0.3732160072103845,-44.03158908741132,-17.397115616790018 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark06(-0.3741168285864969,-163.72823647837262,-77.06635283199581 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark06(-0.37418625775598946,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark06(-0.37422586021623655,-19.366526587007247,-47.606372301264265 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark06(-0.3751892217430708,-5.652816879532805E-16,1.2145977590237846 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark06(-0.37537982168718975,-1.5707963267948966,-22.969439575252846 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark06(-0.3754746523331374,-0.6165535022988463,-1.633296391972089 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark06(-0.3765020777147018,59.092154692077855,0.1804225207851785 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark06(-0.37693327354930084,1.5707963267948966,24.017314651962636 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark06(-0.3770396211994822,-32.857889098711425,-6.271385036100398 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark06(-0.3774247823384762,-1.529757327836875,57.96254193091877 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark06(-0.3775650401541848,-1.5707963267948966,13.72313617640266 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark06(-0.37818628308502417,-1.3145426291005977,1.4818750975825463 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark06(-0.37912488484568274,-1.40289770155618,1.5707963267949179 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark06(-0.379240464171775,-1.5707963267948966,-67.33975552199144 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark06(-0.3800415840953718,-44.3024376547676,1.5707963267949054 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark06(-0.38048264634229956,0.0605077911093775,100.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark06(-0.3811490862388559,89.9545980445738,44.4062248529221 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark06(-0.38201744400801374,-0.6262188395081836,-1.3438341587403153 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark06(-0.382460915029579,-2.220446049250313E-16,-1.190433514630992 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark06(-0.38278415569752267,-102.08673376801623,-2.543867153171919 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark06(-0.3838646113589459,-1.5707963267948966,-73.09972919534711 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark06(-0.38415572535207554,-1.4606687246051422,-95.04577890163334 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark06(-0.3842752961763036,-1.5707963267948912,-58.88157551189905 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark06(-0.38446467058339856,1.3552527156068805E-20,-5.581953396216917 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark06(-0.3846355038033238,-1.133021528294359,1.0205355697890743 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark06(-0.38555306308571424,-31.498391120029105,2.1240543247513806 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark06(-0.385751598392042,-8.881784197001252E-16,-38.99739180241202 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark06(-0.38599743733671676,-1.5707963267948966,7.47291472831391 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark06(-0.38804718808273153,10.602783482774079,-1646.3134633480795 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark06(-0.38818611792867996,-1.5707963267948966,-0.576600454459291 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark06(-0.3882640463357685,-1.5707963267948912,-72.69399005491641 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark06(-0.38882835959213824,-3.1415926535924656,31.652865252803103 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark06(-0.3889281019151674,-1.1642693923381509,-67.05954546294541 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark06(-0.3896782457789556,-1.5707963267948966,-17.27927889967443 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark06(-0.39005631558292553,-3.141592653619153,44.983242096760655 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark06(-0.39057578005460325,-44.42623850175298,-30.04676623680334 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark06(0.390594160030063,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark06(-0.39082084255944327,-1.570796326794845,44.218619809472756 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark06(-0.39109290844228894,-95.39794919054549,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark06(-0.3911259769657285,-1.4927799134920905,-1.5707963267948966 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark06(-0.3919867443503702,-45.05332304497506,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark06(-0.3927950833105225,-37.75551706762654,-51.40239695190006 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark06(-0.39285676850250495,0.6041953841666846,-63.19746020266716 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark06(-0.3929552769253615,-1.5707963267948966,-89.69044263742673 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark06(-0.3930079267400569,-45.19313817260121,-110.49826664544126 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark06(-0.39301724516972997,-1.5707963264065177,-68.46775757520005 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark06(-0.3947259308536595,-45.36983694928941,-135.45164002933743 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark06(-0.39482955290033805,-1.5707963267948966,-53.709900160390475 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark06(-0.39503076871286047,-66.11737346189219,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark06(-0.3950377583751249,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark06(-0.3957379642715225,-95.34132571877676,-9.591992023169801 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark06(-0.39703964461667685,-1.5707963267948966,-129.02279517303367 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark06(-0.3975165163887784,-88.13002684335413,-85.03453414689051 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark06(-0.39753546830208963,22.44906568929865,1.5707963267948966 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark06(-0.39774959646065966,-88.47751352943658,-83.821713519215 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark06(-0.3982415249986401,-1.1282940456498962,-53.85598629168389 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark06(-0.39827820394163294,2.634698116602844,1.5707963267948966 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark06(-0.39839014237175263,-95.70498771040063,-77.32600255117214 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark06(-0.3984130256799858,-0.7075169139779884,-97.20875615094103 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark06(-0.39849671803950315,-1.5707963267948966,76.98160165662637 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark06(-0.3992221276103214,-163.7102105349784,-107.63249894744462 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark06(-0.4004970841189428,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark06(-0.401640330600621,-19.391326018749556,-74.7963411728249 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark06(-0.4021795511527042,-8.881784197001252E-16,0.7750526773828674 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark06(-0.40320274475413953,-0.34383828991619225,-97.60096016695378 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark06(-0.404010189131178,-1.5707963267948966,22.7331694882913 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark06(-0.40442758993197003,-38.85189234499054,-58.28001459939937 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark06(-0.40462150463494345,-3.469446951953614E-18,-1.393274722630138 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark06(-0.4052127903809293,-88.37790281617441,-100.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark06(-0.40539514825515255,-44.1830640262298,-1.5707963267948966 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark06(-0.4059631893016354,-1.5707963267948966,48.11013071490526 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark06(-0.40597969539859824,18.43578600309049,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark06(-0.4060598941203981,-1.5458251660219864,-62.83185307179586 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark06(-0.406127197406283,-45.53123279306362,-15.993994058065073 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark06(-0.40640759471561305,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark06(-0.4066341978971444,-1.5707963267948966,71.72419188113146 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark06(-0.40700475550520654,-0.08853617120451673,-71.13283690990495 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark06(-0.40752005430340055,-1.5707963267948966,-32.64790633851049 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark06(-0.408002194042284,1.734723475976807E-18,18.406795980607434 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark06(-0.4087371614943167,-88.4047662809774,-20.812495277751935 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark06(-0.4090376114458969,-1.5707963267948966,61.40264769583799 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark06(-0.4094460999062848,-1.5707963267948966,40.93496176017953 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark06(-0.40977702683584283,-1.544947286803703,63.28052364975744 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark06(-0.40996799340392487,-43.991724271096565,-71.98713137570417 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark06(-0.410028932566568,-32.985784387322695,81.68140899333463 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark06(-0.41008597333272023,-31.878838839109264,-1.5707963267948968 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark06(-0.4104917830793321,1.5707963267948966,79.99490356607703 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark06(-0.410759138083774,-1.2058630528423038,15.40271606945798 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark06(-0.4107706744855921,6.712388980953872,-0.3021365990368281 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark06(-0.41080977236459315,-0.30292100220647455,62.110572267899926 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark06(-0.41110752546124274,-31.91291252297896,-19.210878646752416 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark06(-0.41203563743188454,-0.34849737274485465,-25.57455618009361 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark06(-0.4123735126038863,-1.562970559528972,-0.41637393578371806 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark06(-0.41279168650957765,0.7628861585358715,-54.625099872050484 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark06(-0.41329192324965053,-1.5707963267948966,153.39527617017524 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark06(-0.4133573037296273,4.733727819362868,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark06(-0.41344344872762007,91.58024550279885,1.5707963267948983 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark06(-0.41346304989142446,-0.26261971059172606,1.5707963267948957 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark06(-0.41394605798797823,0.31324799219354604,-31.435263429878724 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark06(-0.41404271033096196,34.890870560357726,0.10497208028790724 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark06(-0.4150584034746015,-1.5707963267948966,-52.50209207718956 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark06(-0.41531174097229406,-1.5707963267948983,36.495123561197715 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark06(-0.41611118795737556,6.777032211474742,2.2125970949567892 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark06(-0.41676002969020215,-1.5707963267948966,-96.25330308620927 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark06(-0.4181720989222802,2.1684043449710089E-19,98.68407771643913 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark06(-0.4189528867095702,-1.5707963267948966,40.070906097426594 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark06(-0.4189825862837263,1.3456080794030894,15.498175068277817 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark06(-0.41916249244439663,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark06(-0.42048855994449147,-0.023869714690405358,521.389308917152 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark06(-0.4213031074961854,0.0,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark06(-0.4223771099474785,-1.5304203414752509,0.5688513644039653 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark06(-0.4234306459788084,-0.7823242454956407,52.89034002045403 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark06(-0.42343356134149446,1.5707963267948966,98.34526011760238 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark06(-0.42351116620934187,-1.5707963267948966,1.570796325913294 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark06(-0.4247528660526192,-0.7288290970659261,0.46468122925410293 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark06(-0.4251805449558632,-1.5707963267948983,-88.18515299846285 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark06(-0.42608109762320284,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark06(-0.42673605083079735,-45.16884667827035,-42.088079913934216 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark06(-0.42719148576720745,-1.5707963267948966,-95.61563244073639 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark06(-0.42776888980766437,-1.0650993422486799,3.141592653589793 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark06(-0.4279689806742246,-0.1961875787343778,15.694793623728597 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark06(-0.42805866813826854,-1.5707963267948966,17.251411770481553 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark06(0.4286547128872983,9.600365011573846,-41.11046208629525 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark06(-0.4291536256956775,1.5707963267948966,66.22292444006727 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark06(0.4315770209559358,0.001982727673212059,91.09302071915272 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark06(-0.4316439946752234,96.07405046603361,2417.628529276939 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark06(-0.43199182542669234,-1.5707963267948966,-35.14593432801827 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark06(-0.4324608366840583,-0.44856251933518054,31.78437770394891 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark06(-0.43252734132266824,-32.954195817013755,0.33293912072904375 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark06(-0.43370197982213465,-0.1304242312213506,-1.483060780523583 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark06(0.434482762922311,1.5707963220411714,-1.5707963267948966 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark06(-0.43497641062376735,-1.5707963267948983,2059.36897139722 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark06(-0.4359235939193812,27.980256929751462,-7.354852504743024 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark06(0.43593437236861055,1.5707963267949019,10.958641846590282 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark06(-0.43698212561964067,-88.10002809462279,-110.04626730218885 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark06(-0.4369983704699506,-1.5707963267948966,43.13820395709349 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark06(-0.43791501023535206,1.5707963267948983,4.998154595592226 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark06(-0.43818505085038373,-1.5707963267948966,91.04146496809506 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark06(-0.44030136768726447,-1.5707963267948961,58.89461235630878 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark06(-0.4404590697459427,-1.5707963267948966,-20.664494835433587 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark06(-0.44050645782841735,-0.3458731281009392,-69.74509895312134 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark06(-0.4418381512957532,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark06(-0.44186655560096677,-0.07903808123516853,87.58803081177032 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark06(-0.4426844752540604,-0.2620264326957141,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark06(-0.4431194886836633,-8.881784197001252E-16,51.83139183161512 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark06(0.44428007533703384,1.5707963267948983,76.62116366558476 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark06(-0.44448637759543885,-1.5707963267948957,32.296659893883074 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark06(-0.4448151272873637,-1.8367099231598242E-40,-11.041217606229097 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark06(-0.4452798102037623,-31.516326609082085,-121.10989479671005 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark06(0.4454212544964034,1.5707963267948966,1.5271747105503977 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark06(-0.4456100050519316,-88.16349640809372,-95.3878295185416 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark06(-0.4458242460289223,-1.5707963267948966,22.332991183475826 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark06(-0.44633608660359964,-44.329054465948644,-1.5707963267948983 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark06(-0.44671284055438265,-44.10126309375876,-20.815760374035733 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark06(-0.44802248162995933,-0.9158317710411144,-98.2675506754205 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark06(-0.4490358485486584,90.8816550037457,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark06(-0.4490500469581731,-37.780674330392,-1.2561169474217158 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark06(-0.4493894282429798,-37.845903338678646,-8.967740762343594 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark06(-0.4497332645868468,-32.5966360423042,-101.43631399040979 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark06(-0.45004666685838884,-0.32521807210288595,-84.10237322664662 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark06(-0.45037074890822626,-44.266276673208836,0.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark06(-0.4507293521047333,-32.90026785964466,65.32185920762899 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark06(-0.45102673720064856,-0.02640335871079391,-17.957218483612365 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark06(-0.451051054601908,-1.3788496989791017,1.5707963267948966 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark06(-0.45119610241956043,0.3489015707174101,53.690563544749594 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark06(-0.4515669509561988,-0.607970505623932,18.921227612267845 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark06(-0.4519304143524991,-38.73786412917861,-3.141592653589793 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark06(-0.4524054881781902,-3.141592653589794,-9.899033080769271 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark06(-0.45339602859162453,-31.687898568371608,-72.29543566491293 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark06(-0.45358108210308457,-19.352393072219034,-1.5707963267948966 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark06(-0.45411027587141817,-1.5707963267948966,-12.481002546267 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark06(-0.45417115787392615,29.16872710614238,40.0392252527938 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark06(-0.45462659617881496,-39.093475044804904,77.01183758691113 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark06(-0.45510222725331145,-6.003417091244875E-16,60.845806890004965 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark06(-0.4553736503310617,-1.5707963267948966,-3.14159265359013 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark06(-0.4558094560374619,-2.6101217871994098E-54,-88.68841620642881 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark06(-0.45600435998095445,-6.393379192879681E-18,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark06(-0.4561598356558534,-1.2273378602859841,-1.5707963267948966 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark06(-0.456192085955533,2.710505431213761E-20,-58.91118140091441 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark06(0.4573101719551945,72.66166249023155,-2.9170370796158074 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark06(-0.45761586907919827,-0.18144585092721072,-44.138540930214646 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark06(-0.45772786736591786,-1.5707963267948966,-39.752518972245255 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark06(-0.45800541689296986,-39.19677001958164,-4.0102252461021735 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark06(-0.45826249100882466,-1.5707963267948966,-46.784454324874005 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark06(-0.4588360744380108,0.8986120395642158,32.5939253963081 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark06(-0.4594257339073051,-45.38321847271857,-1.5707963267948983 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark06(-0.4597411230147076,5.932816468762397,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark06(-0.46002926383319187,1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark06(-0.4608534836126317,-1.5707963267948912,44.39202836645879 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark06(-0.46190242672061343,53.71171135766562,-1.5707963267948966 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark06(-0.4628622412319163,-32.61983716189736,-14.467998924694182 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark06(-0.4639675441009891,-37.74608561899625,-3.141592653589793 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark06(-0.4643213544032285,-1.5707963267948966,-92.7351306098899 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark06(-0.46439095569844074,-164.37377358063236,-48.63485286790878 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark06(-0.4658548311156515,-94.32805976237273,-3.141592653589811 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark06(-0.466039324317693,-45.42849793966175,-123.91140061457587 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark06(-0.4665196389232813,-44.524920728106856,-0.7922299642908475 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark06(-0.4669320034486889,-1.7763568394002505E-15,100.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark06(-0.46718215484550263,-1.4788876343096233,1.5707963267948966 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark06(-0.4678706583751735,-45.13945936980224,-73.3187375455222 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark06(-0.4681203101478678,62.263869406152864,32.69445820540892 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark06(-0.46819839314569567,-31.871843956467046,-536.4917414024651 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark06(-0.4683927311944226,0.5338879626690687,2137.357479580815 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark06(-0.46898313420919824,1.5707963267948983,-28.156328143125606 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark06(-0.46917381627891297,-1.4583354731207976,1.5707963267948968 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark06(-0.46924823639721946,-44.39350863821688,1.5707963267948983 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark06(-0.4692493671808266,-2.7755575615628914E-17,4.797834924686569 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark06(-0.46946773699867084,-1.2151371922405616,-86.17421751878209 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark06(-0.4695617059799684,-1.5707963267948966,-30.133584624348444 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark06(-0.4698056778531846,6.712506561196676,-104.90193394263184 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark06(-0.47022510039834003,-31.803162966522663,1.571040491065412 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark06(-0.470320327357541,-1.5707963267948966,21.000779252648314 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark06(-0.471096710019578,-1.5707963267948912,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark06(-0.4717018386808741,1.5707963267948966,53.53182890400664 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark06(-0.4724585755767871,-44.380643708973835,-65.61135101270628 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark06(-0.47339997330230993,-1.2773426028098758,56.17099365450747 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark06(-0.47382942950259166,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark06(-0.4745348993709901,25.132741229071897,-67.4852478211586 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark06(-0.47485802951503076,-1.570796326794894,-49.711920574326605 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark06(-0.47534375978361787,-0.44458786122507143,-636.7900454373439 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark06(-0.47573672243066367,0.5056608252650644,-14.57158823701732 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark06(-0.4762069683933284,-95.29029148988654,-55.244945905566134 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark06(-0.47661708891623844,-1.5707963267948948,-45.901808649778495 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark06(-0.47672742623553316,6.712388980754161,-1.5707963267948983 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark06(-0.4774454579848052,1.5707963267948966,16.94233679248107 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark06(-0.4777571779886469,-95.25501455096268,-40.80539402486524 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark06(-0.4780894633772448,-31.579128278689605,-47.57669953092008 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark06(-0.47829177229291187,-164.49347625999758,-5.888203101496487 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark06(-0.4788362419478318,-38.80691102483044,-84.40597422009273 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark06(-0.4792934781045219,-8.881784197001252E-16,-74.28132562270265 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark06(-0.4794286537321119,-0.23426900511920934,49.9696472673084 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark06(-0.4799996356350384,-1.2951406667008172,-84.23996005640896 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark06(-0.4801314606752465,-88.25945829523192,-53.40707511102648 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark06(-0.48107907148158113,-1.5707963267948966,67.14379939867563 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark06(-0.48165429018851347,-1.5707963267948966,-41.1578872915614 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark06(-0.4823100547485515,-31.608593292065894,-50.71540414850973 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark06(-0.48245005362462534,1.5707963267948966,96.08585813322735 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark06(-0.4827120113872711,-1.5707963267948966,3.266595793959972 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark06(-0.4833715953733647,-0.0276727400027282,-9.40515286475064 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark06(-0.48341082508546424,-1.5707963267948966,0.13374723126383703 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark06(0.4837608473081157,-1.5707963267948966,4.256130633458069E-15 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark06(-0.4839156499786281,-31.78497345988343,-0.09759487789111465 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark06(-0.48456887186141195,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark06(-0.4849974323498768,97.03126331811028,21.820541077721757 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark06(-0.4850190526927102,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark06(-0.4853984411035925,-1.5707963267948966,61.606028321981015 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark06(-0.4872619912203776,1.0602868887180548,52.437527586721046 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark06(-0.4875174918206528,-38.758247698066626,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark06(-0.48778302456320743,-0.6073028938717292,0.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark06(-0.48856646271447346,-1.5707963267948983,-9.280100604389887 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark06(-0.48886450778969187,-145.0555808080133,-1.5707963267948966 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark06(-0.4890634949252558,0.1605340285622691,-20.02384333112959 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark06(-0.48909077177670934,0.4475820919966752,94.94692740491931 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark06(-0.48936886310720235,-0.4827167430426391,-31.43150874888434 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark06(-0.49017480380429423,-0.08673730124848571,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark06(-0.49048755485218276,-37.89590144820407,-14.34560628233961 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark06(-0.4912720252545887,1.5707963267948966,86.09153410634559 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark06(-0.49154725838410984,-38.91008714732888,-50.30370923257263 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark06(-0.4919853471845595,-45.19322140793799,0.31754375071054564 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark06(-0.49362773309529556,-1.5707963267948966,-17.278759594743864 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark06(-0.4953283438535119,-38.7345771973761,-36.3185517509794 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark06(-0.4959275182994973,-0.001983214267109519,100.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark06(-0.49615292982159076,-0.4939497818958918,92.16965107215407 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark06(-0.4963959364349703,-1.5707963267948966,-29.84513790579801 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark06(-0.49640833645450755,-0.24411346578338122,-23.382856403729342 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark06(-0.49695539199788974,5.141592653607014,-10.691239364293192 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark06(-0.49698482398070365,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark06(-0.4972533142060911,-102.10152692250882,15.618725751495816 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark06(-0.4972655379055181,23.32901209355778,1.5707963267948966 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark06(-0.49758774557540764,-0.6334417682811844,0.1208183179778663 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark06(-0.4982241540246183,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark06(-0.4983721602605564,-163.8455640674754,-55.99929066213453 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark06(-0.4984457933659587,-31.846435659850883,-33.07490553158023 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark06(-0.49870301659842686,-1.345782892216017,1.476868354145353E-6 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark06(-0.4991068708505253,-270.7295951832477,-95.36998499194105 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark06(-0.4991801520554181,-1.5707963267948968,-1089.5009485804146 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark06(-0.4993080740159367,-1.5707963267948966,-1.5620953313046364 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark06(-0.49952144837076184,-0.1312266594616105,-58.30127594999604 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark06(-0.499625167993599,-1.5707963267948966,-58.283218253035685 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark06(-0.4998922034543914,-1.5707963267948966,-3.1415926535897936 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark06(-0.49997489689188523,-1.5707963267948966,2.835624787839003E-15 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark06(-0.4999988000802306,-45.386344882335706,-3.2666202781926486 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark06(-0.5001402973767659,-1.5707963267948966,841.1316663042196 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark06(-0.5006476466837146,-31.789139146367212,2.6968471951089423 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark06(-0.5008107211625131,-1.0433826649383593,3.1415926535897967 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark06(-0.5013191564997017,-0.024958161550209468,-14.076743295154444 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark06(-0.5018328790689403,-1.5707963267948963,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark06(-0.5028935659678645,2.148391337768272,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark06(-0.502915979863717,-1.5707963267948948,0.5311465937799085 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark06(-0.5034879099935061,-39.059680393723845,-53.26427222417287 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark06(-0.5036139646314415,-88.50925218357015,-100.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark06(-0.503830326770803,-39.14653691230869,4.5719495651291E-100 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark06(-0.5047229702366167,-101.83090304334974,-89.571533895712 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark06(-0.5052517307240216,-1.5707963267948966,-1.3113700875962304 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark06(-0.5053352316568435,-1.5707963267948966,1.5710404674248282 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark06(-0.5058370410485353,0.7050614941576531,58.36664475400273 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark06(-0.5059831747484367,8.673617379884035E-19,48.35521166463681 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark06(-0.5060828482409079,-1.5707963267948912,-90.35429062429255 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark06(-0.5061842732089077,-1.3570914827476486,-33.01912242303709 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark06(-0.5064940492898748,-44.360982669512175,3.1415926535897927 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark06(-0.5067962281178944,-1.5707963267948966,-2.3135609058104762 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark06(-0.5073997095751898,78.96685149713272,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark06(-0.5075542254230593,90.99721266287187,1.5707963267948966 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark06(-0.508027638502282,-1.5707963267948966,-1.538428185986435 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark06(-0.5082351119173849,-1.353690438460001,15.578120611286366 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark06(-0.5084246459668706,-1.5707963267948966,-73.00231881136936 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark06(-0.5086754602921989,0.24060801853074754,-38.08812652678451 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark06(-0.5087470070384512,-1.5707963267948948,-26.83836004339122 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark06(0.5088385316813344,-55.55788089185336,79.6599095479155 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark06(-0.5092671616464335,-1.5707963267948966,99.98742165243524 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark06(-0.5095374754424284,-0.3720577168570287,-53.77429993697105 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark06(-0.5099836352499981,1.9658113592096251,0.0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark06(-0.5101020053598151,-88.18248111408678,-11.492528792916683 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark06(-0.510680191001498,-1.5564216072717658,-39.918539695471786 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark06(-0.5114619041691936,1.5707963267948966,79.55906980904395 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark06(-0.5119386528809123,84.44431377843532,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark06(-0.5121415715080171,4.3368086899420177E-19,89.43102327333081 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark06(-0.5136538133344202,-1.5707963267948966,70.7455953024677 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark06(-0.5139257103885383,1.5707963267948966,4.690454598905465E-15 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark06(-0.5140108947127501,-2448.2110711941245,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark06(-0.5140832574322303,2.465190328815662E-32,91.4433743109415 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark06(-0.5141079677395726,-1.5707963267948966,-55.72015435334812 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark06(-0.5143749786335309,1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark06(-0.5146622894178515,-27.566292534671916,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark06(-0.5148666524394203,-26.898215215595357,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark06(-0.5150645400692949,-1.5707963267948983,-1.1538703979313512 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark06(-0.5151936134634061,-32.4874189995963,1.5747026004727531 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark06(-0.5153177342021322,-1.5707963267948966,-77.49661320407515 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark06(-0.515592551384108,-45.2115687560811,0.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark06(-0.5159139995963089,-8.673617379884035E-19,65.3942407530748 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark06(-0.5161526508281498,-1.5707963267948948,67.46261284847705 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark06(-0.5162824274368418,-0.7327759211505518,85.82952329890306 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark06(-0.516866643916603,-1.5707963267948966,-9.636203277114632 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark06(-0.5171588903151199,-1.5707963267948966,11.146672648029437 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark06(-0.5177999451278517,-1.3579482698587206,-54.21255889641727 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark06(-0.5179808903844967,-84.58347334053924,-1.5707963265339593 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark06(-0.5180668798326664,-95.55095865913458,-135.31644236613988 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark06(-0.518212321720275,-0.9307351296960837,16.631365383631092 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark06(-0.5185409234169444,-0.5107460039300662,-1.5707963267948966 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark06(-0.5187458826109532,-32.65820857389102,-100.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark06(-0.5188877700811402,10.306919177545868,-100.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark06(-0.5190615448740779,-0.9424096440298273,-0.12782675544381128 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark06(-0.5196240491559402,0.333032318058878,-19.97063156934 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark06(-0.5196896625943737,-1.1806307280912904,-48.71830516612059 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark06(-0.520075694990048,-0.13613670378686393,161.79298091303247 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark06(-0.5203681803319783,-1.5707963267948966,-12.237370924859704 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark06(-0.5206310624620238,-88.41197829684157,-165.76249487764406 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark06(-0.5209683458698703,-1.5707963267948983,-99.79567776524965 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark06(-0.5212980752079484,-39.169923862532194,-1.104588252233449 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark06(-0.5220848776243798,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark06(-0.5223399123540698,66.26047871182227,2115.278806636555 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark06(-0.5230245676385247,1.044442732321167,-53.72945179912481 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark06(-0.5237023485573504,-1.5707963267948966,77.76568257152755 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark06(-0.5242285317879073,-402.17098902332594,-1.3277425674720802 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark06(-0.5243642374100471,-1.5707963267948966,-0.05615422752483251 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark06(-0.5245604763460402,1.5707963267948966,78.70168554672773 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark06(-0.5247294393785051,-1.569532398373699,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark06(-0.5249309052985169,-1.5707963267948963,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark06(-0.5259318475361013,1.5707963267948963,-91.8817916417619 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark06(-0.5262987439832587,-44.46376862203984,2.0707994968089953 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark06(-0.5263619303623064,-1.045525066527795,47.68243211172356 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark06(-0.5270661951810766,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark06(-0.5273579676351587,-1.570796326794897,95.62511679934428 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark06(-0.5284653573999789,-1.57079632502779,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark06(-0.5291161112923647,-1.5707963267949,80.37709515116492 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark06(-0.529198248535801,1.5707963267948966,58.72612347065149 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark06(-0.5292859382824537,-5.852095443365248E-98,-3.284642117424312 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark06(-0.5294675774906877,23.671874585221982,-10.401799143478968 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark06(-0.5297554099265692,-0.2792917183350387,12.566371568069906 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark06(-0.5302323726132504,1.5707963267948966,0.8205626026785756 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark06(-0.5309733089010251,0.22396812368961486,-74.4003795437802 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark06(-0.5317450654899352,-1.5707963267948948,89.9412832944526 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark06(-0.5318700482364188,-2.1684043449710089E-19,0.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark06(-0.5319599477409103,-1.5707963267948966,13.521716861823776 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark06(-0.5322757785348463,4.687541951308585,50.73822045739392 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark06(-0.532776752396875,-32.66421114775275,-0.12082590514850808 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark06(-0.5329627009200466,-31.564993692290955,-8.682854366333203 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark06(-0.5333739431071539,1.5707963267948957,76.15581493685409 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark06(-0.533467281837463,-44.20498394203646,-3.2665928225913006 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark06(-0.5338003259839468,-32.83711933337692,-75.39822368615503 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark06(-0.5342541046895324,-44.999429398273875,-66.40375890531936 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark06(-0.534408704462785,-1.5707963267948957,-82.45974351707115 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark06(-0.5344714512237503,-1.3188958111990285,-55.98381930335617 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark06(-0.5352721560897074,-1.7763568394002505E-15,-59.20844138232411 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark06(-0.5353479768674956,-0.2891212334398148,618.7039079850708 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark06(-0.5357329114241765,-88.38711167483049,-74.18575322018208 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark06(-0.5359078198818555,-88.40404653183248,-1.5707963267948966 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark06(-0.5363493502364527,-1.5707963267948948,-1.4856400543738886 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark06(-0.536891411704248,-32.924412374499994,1.553901973507503 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark06(-0.5377609331040331,-45.39574235695168,-1.5707963267948966 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark06(-0.5380116883498901,2557.251172990958,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark06(-0.538291674357005,-1.1102230246251565E-16,0.11623570842944275 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark06(-0.5384109349327998,-31.89432831762514,-1.5707963267948983 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark06(-0.5390876098664737,0.5703043157182824,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark06(-0.5391159734143572,-1.5707963267948966,42.80714140343419 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark06(-0.5391269689613367,2.465190328815662E-32,-0.04617931695043409 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark06(-0.5396983259664823,-32.86312336014103,-1.5707963267948968 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark06(-0.5400640261103493,-94.28336326763049,-77.71647883991861 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark06(-0.5411615721866737,-31.911126738184123,-22.356434630959683 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark06(-0.5411986108217881,-1.5707963267948966,55.65364695363027 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark06(-0.5413931388619433,-1.252034266723808,-46.92251790007067 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark06(-0.5415990280299807,-1.5696999151318627,-45.30432565948561 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark06(-0.5418339771363989,-1.5707963267948966,-9.262691212230337 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark06(-0.5440580165311957,-1.5707963267948966,-3.6330765065103794 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark06(-0.5443583021799137,-1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark06(-0.5450269072751127,-1.5707963267948966,-21.809926638251426 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark06(-0.5450410850857056,-0.2420530690235383,0.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark06(-0.5459393468100217,-44.096119236923556,-100.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark06(-0.5464580420566602,-0.5528738024290086,5.980713974352948E-14 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark06(-0.5466537371886249,-1.570796326794897,1.47778843057062 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark06(-0.5467095905921223,-1.2035591892863402,2110.8596657884764 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark06(-0.5469952120533867,-37.71049559179721,-116.40845191899447 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark06(-0.547092874771256,-3.1415926535898087,100.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark06(-0.547652805563963,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark06(-0.5487980360515365,-44.12537584034305,-1.5707963267948966 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark06(-0.5490057842789287,-95.76094499856933,65.44819473868107 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark06(-0.5492449966928024,-19.404811874234795,-26.80877662194382 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark06(-0.5499915836678511,-88.23855461084615,-4.977780301549771 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark06(-0.5502512662525945,-1.5707963267948912,39.195758789446984 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark06(-0.5508534022882331,1.0271295891572425,-30.255828411817504 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark06(-0.550986016541878,-32.75963447095051,-83.50025150776735 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark06(-0.5509895686645927,-0.17261599531948854,91.72628944665979 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark06(-0.5519097116969679,255.96156835938837,1.7404376135446436E-11 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark06(-0.5520612057017082,-0.8030307510396781,-1.5707963267948972 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark06(-0.5529250238671299,-0.03837929403827056,91.05072236120365 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark06(-0.5529424356683749,-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark06(-0.5531893896956646,-39.230493400107555,-77.69359234474767 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark06(-0.5533080488421748,0.00909340324647482,-19.517050290182862 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark06(-0.5542200297056995,-2.220446049250313E-16,4.141592653756085 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark06(-0.555046175237955,-1.5707963267948966,-7.875078780837242 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark06(-0.5552924234583118,86.25549223865588,1.5707963267948966 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark06(-0.5557685880095597,-1.5707963267948966,29.603961123352803 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark06(-0.5568827070391398,-53.914876520435385,-3.1847119071402714 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark06(-0.5571522355940185,5.430005273204696,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark06(-0.5573659601198355,-39.10051146084386,9.424777960787821 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark06(-0.5577554050930852,78.8092485843881,1.5707963267948966 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark06(-0.5578323461219972,-3.1415926535897936,1.5707963267948966 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark06(-0.5585757515886551,-0.6925298680394069,-38.76132929852283 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark06(-0.5589494628336849,-1.5707963267948966,26.85774634551734 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark06(-0.5590927593580393,-1.487496834618753,-98.22083360492589 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark06(-0.5591631303135767,-0.7723500581694078,-59.106344862685006 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark06(-0.5594586477347674,-45.5230162619698,-114.93714061142592 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark06(-0.5594660490028893,-1.5707963267948912,-16.345178347269538 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark06(-0.5595156182388707,-31.972725550513815,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark06(-0.5595170772465963,-31.60703916045442,77.7921206127813 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark06(-0.5596827414676936,1.5707963267948948,-79.26631636709611 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark06(-0.5597310237517235,-1.5707963267948966,19.86174237881127 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark06(-0.5599795952881174,59.15323123510959,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark06(-0.5600490873955538,1.5707963267948966,44.29670487817193 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark06(-0.5601060890651574,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark06(-0.5606120735789261,83.73365372451593,-1694.307127427811 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark06(-0.5606215528003055,1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark06(-0.5613088861810032,-0.6249297175046508,-45.31990983141849 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark06(-0.5613453882389413,1.5707963267948966,19.832876301065028 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark06(-0.5613488948588935,54.34782854975066,56.47537561813803 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark06(-0.5615901303346652,-1.5707963267948966,-1.539504073522318 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark06(-0.5616739646058312,2.220446049250313E-16,51.376955849336895 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark06(-0.5617767366242222,4.705067982383192,-1.570796326794897 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark06(-0.5619640575042154,1.5707963267948966,1.1718353729188644 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark06(-0.5623358507965809,1.5707963267948966,0.30357789882351915 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark06(-0.5627812750813987,-0.17310841350525485,-0.04219175453492596 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark06(-0.5628405850961867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark06(-0.5630497000143182,-1.5707963267948966,-4.712450015549773 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark06(-0.5631251710711791,-1.5707963267948966,-40.840704496667314 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark06(-0.5631447539222756,-32.53886671528705,-12.810226763519665 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark06(-0.5632099034586017,-102.10100166955257,-63.70806042337104 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark06(-0.5634902747345745,-32.925773421932405,97.07420873764383 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark06(-0.5635740182695083,16.491834032321243,1.5707963267948966 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark06(-0.5638245425367004,1.5707963267948948,84.89323973266406 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark06(-0.5640306462105542,-44.51498454340276,-1.5707963267948966 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark06(-0.5642326358700789,-1.5707963267948966,37.16154609813258 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark06(-0.564757691665471,1.5707963267948948,10.713798062797224 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark06(-0.5659368666029218,-1.5707963267948966,-1.2550913616048418 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark06(-0.5660079681708661,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark06(-0.5664817968995957,-102.08159261682825,1.5366440707624636 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark06(-0.5670496234474103,-1.5707963267948966,-52.02660116031173 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark06(-0.5676781965779298,-1.5707963267948966,66.90959002272305 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark06(-0.5682499639666828,-1.5707963267948912,0.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark06(-0.5685028149918335,-1.5707963267948966,1.5707962198643899 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark06(-0.5686770232719712,1.5707963267948966,10.974463432602072 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark06(-0.5691636549230765,-31.428912998627055,-26.362608886260738 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark06(-0.5700823925034101,1.5193775903014182,-32.67530724849166 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark06(-0.5701076785875827,-101.8770528281435,-44.35253494127075 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark06(-0.5702223556262439,0.05769667432481945,88.15410891759097 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark06(-0.5703128825925204,1.5707963267948966,42.321931723135364 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark06(-0.5703356348270378,1.5707963267948966,48.62222076271344 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark06(-0.5706313427648079,1.0575065530836958,50.72602394800852 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark06(-0.5706905506394523,1.5707963267948966,0.31916403784744296 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark06(-0.5707391779048727,3.793906918934754E-21,-1.5707963267948966 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark06(-0.5714390416992735,-1.5707963253473638,-45.267828533382826 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark06(-0.5715788892787641,-39.08875272936896,-45.955509792152085 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark06(-0.5723449349179689,-0.02411522481707415,-53.40707511303735 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark06(-0.5723836343914606,-1.5707963267948966,-17.153076582349215 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark06(-0.5725454948673885,-1.5707963267948966,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark06(-0.5736895994378883,-3.552713678800501E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark06(-0.5741128090437029,1.3552527156068805E-20,14.82955784875846 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark06(-0.5749692988759005,-0.5714389031368354,95.8174296190859 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark06(-0.5751318480474606,1.0842021724855044E-19,9.051089855873158 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark06(-0.5759177868787702,-88.27534160970465,-77.88421277608647 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark06(-0.5761657854211931,-95.58703731656516,-25.788957385653205 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark06(-0.576495943203401,-1.5707963267948966,9.329886977763422 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark06(-0.5767030680732155,-1.5707963267948966,-73.58979993952838 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark06(-0.5768980790235658,-1.570796326794845,67.53137816420491 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark06(-0.5776388941511468,-1.5233850096831063,38.65181141394119 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark06(-0.5786062305561747,-95.70913348728287,-1.5707963267948968 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark06(-0.5794406697030415,6.781381906546922,0.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark06(-0.5802749179954888,8.673617379884035E-19,10.607633080741259 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark06(-0.5806328094120522,-1.5707963267948966,-4.714342106340462 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark06(-0.5811080528665511,-1.5707963267948966,44.19546909216597 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark06(-0.5815837875584066,-0.9720387108800128,86.85329087074933 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark06(-0.5817353733819045,-32.5253100081091,0.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark06(-0.5820338143005686,-31.904267498664012,-1.5707963268240006 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark06(-0.5820658056637603,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark06(-0.5822785291230943,-0.6158427912461834,-88.3131461636312 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark06(-0.5832589537198454,-7.322318077812001E-15,1.570796326794897 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark06(-0.5833806290870693,-1.169354419105671,-3.266593049986057 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark06(-0.5839344136187818,6.712388980854561,6.326511655944962 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark06(-0.5841729995928886,-1.5707963267948966,-24.93147603204606 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark06(-0.584578717834745,-39.03136219658714,-35.4542529519874 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark06(-0.5850252254062741,-1.493140914117411,-55.58804372094328 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark06(-0.5864610462253254,-45.29184248904399,-1.5641274181117976E-148 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark06(-0.5865811453989775,-37.69911184307752,-1.5707963267948966 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark06(-0.5876310917592805,-3.141592653589794,25.371700394056734 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark06(-0.5893263497415296,-0.9153998493540632,23.78488395883012 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark06(-0.5900066162994477,-1.5707963267948983,102.74179356631404 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark06(-0.5901370758147073,-1.5707963267948966,43.874728366731425 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark06(-0.5905342165442392,-1.5707963267948966,-32.98974254626505 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark06(-0.5905695932492956,-0.13881646988277563,-1.5707963267948655 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark06(-0.5905977446059838,-94.3711728276833,0.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark06(-0.590941653539829,-32.53982335785655,-0.2987030648588451 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark06(-0.5920299033808193,-37.72626318673587,-14.193005182927212 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark06(-0.5933109993585506,6.7123889804232535,1.1143376670244949 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark06(-0.5945405221263436,-1.5707963267948966,22.022398575131795 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark06(-0.5951697547654301,-1.5707963267948966,49.563453141670685 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark06(-0.5953697807475239,-88.27187275771404,-10.462492697500249 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark06(-0.595609563673456,-44.98818242690534,-82.89791958734469 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark06(-0.5963334096103349,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark06(-0.5972593552564807,-1.5707963267948966,51.600440355741824 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark06(-0.5990716671841814,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark06(-0.5994133494220559,-4.568672112320124E-9,-0.8512421576366775 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark06(-0.5998414874840534,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark06(-0.6001330018062134,13.06362905713732,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark06(-0.601780961385332,-44.1964688862901,-188.09921339675466 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark06(-0.601809660785847,-1.5707963267948966,-1.2789802000035284 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark06(-0.6018467377785391,6.712388980388628,-1.2713665419309594 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark06(-0.6026108386958967,-0.4515618912614372,31.41592653589793 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark06(-0.603722335483457,-1.2520002056696957,-41.92039446531219 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark06(-0.6037325533266628,-31.841324047226863,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark06(-0.6062273879993976,-0.9055010803763821,-9.831201138617814 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark06(-0.6062970896597308,-45.18432210102658,-12.059264070758596 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark06(-0.607008675078248,-158.56294056216788,0.5811281619331949 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark06(-0.6074373086029543,-88.2507677244774,-3.225268849820365 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark06(-0.6078818542829509,-1.5707963267948983,28.29398502497898 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark06(-0.6078839033465647,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark06(-0.6096085760302161,0.0014792277344876548,-14.70458767000261 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark06(-0.6096091694884296,-0.22329288908278014,3.1415926535899104 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark06(-0.6102872068996392,-2.220446049250313E-16,79.36095891777205 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark06(-0.6106636936006169,-95.80689234104878,-15.707997017178776 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark06(-0.610982109004441,-1.5707963267948983,-54.611582131785006 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark06(-0.6122602204921267,-88.24630773284332,0.6188927717717831 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark06(-0.613223375447951,-95.65878014636252,-110.49183538349556 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark06(-0.6152852742905797,-0.27272447394649646,0.5519686339077753 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark06(-0.615394377977259,-1.5707963267948948,43.02000134575573 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark06(-0.6157986994162927,-1.1102230246251565E-16,63.706965561838956 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark06(-0.6160064028371108,-157.46819115959494,-4.71267881071063 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark06(-0.6161585114228819,-95.7304383454448,-248.60716246457855 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark06(-0.6165751113552704,-1.5402166361421226,41.44930754414443 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark06(-0.6174604667758197,-0.11171244352734248,6.121360445377835 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark06(-0.6176995027540468,-0.3142732534902807,1.5707963267948948 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark06(-0.6179304702060193,-1.3478631547522144,88.10256199977971 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark06(-0.619503303257426,-45.172477922837096,-4.2549770402477805 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark06(-0.6203555654871575,-163.80286232751655,-3.1415926535942993 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark06(-0.621109212803224,-1.5707963267948966,-86.82050249320852 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark06(-0.6211298539057709,-3.0417465060722557E-210,-76.05690315114455 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark06(-0.6215201957884693,-37.86980816104969,-74.91741214361852 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark06(-0.6216811197121954,-1.570796326794895,-68.16679054199899 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark06(-0.6219202634002733,-1.5707963267948966,-1.5864213495750705 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark06(-0.622103230146443,-0.010878166067389835,18.323570283637117 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark06(-0.6221150163846332,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark06(-0.6223475587297898,-1.5707963267948966,23.604932035706668 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark06(-0.6226467619113264,-1.5707963267948966,-28.391268155482276 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark06(-0.6230354118820018,-39.17256977041177,-53.111294271248426 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark06(-0.623863325764356,-1.5707963267948966,0.43402223244436217 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark06(-0.6242687060782264,-0.7338252792642087,12.940128497299424 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark06(-0.6286858951221707,-31.435294746564324,-0.024356008976593287 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark06(-0.6290300684175414,-39.18412994096171,-14.081774473822012 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark06(-0.6292076784269449,-1.1958195204035178,0.8059174023322826 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark06(-0.6294231219159518,-1.5707963267948966,49.89774409730146 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark06(-0.6294704566315281,-101.92083624558222,-9.715534449134111 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark06(-0.6302593267549097,-0.9342220973640112,-1.5707963267948963 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark06(-0.6304372823303662,-1.5707963267948966,-4.74376073860509 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark06(-0.630762636033305,-1.5707963267948966,-46.82933843299881 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark06(0.6312882138687276,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark06(-0.6313085084021209,-45.516981557077,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark06(-0.6318685750016826,-1.3104230085035091,71.92501486992987 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark06(-0.6322322741400298,-101.56697430621644,3.2665926535897936 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark06(-0.6332865287619285,-1.5707963267949019,135.3483686961386 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark06(-0.6335692980933026,-44.342335687969495,-27.617821537486805 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark06(-0.6353885937923884,-164.8981905634691,7.861794138637667 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark06(-0.6361112400155988,-0.04688464153905995,100.0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark06(-0.6373933155915034,-45.017834873832946,-40.09677574811766 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark06(-0.6381293030442055,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark06(-0.6389774738439797,-1.5707963267948912,53.9720461535064 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark06(-0.6390155080959738,-3.141592653589794,-100.0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark06(-0.6403121306488324,-32.66896011522641,-3.1415926535897913 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark06(-0.6403172484365802,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark06(-0.6405765510917321,-88.12751997115953,-47.7059263695842 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark06(-0.6411158903548381,-1.1453844745168982,-1.2853962265738383 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark06(-0.6411851256077217,-0.24063751341559803,1.5707963267948966 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark06(-0.6418110031158548,-87.72376478382526,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark06(-0.6429081684751191,-1.5707963267948912,62.386297937340004 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark06(-0.6430596877795959,-1.570796325393342,1.5707963267948999 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark06(-0.6433554121095673,-88.42682902078813,-65.85694478589292 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark06(-0.6440238000255079,-1.4165879368067633,78.09568049246515 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark06(-0.6454251560088097,-0.30919218556927247,-1.5707963267948963 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark06(-0.645966475612627,-1.5707963267948966,2.5707851050587385 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark06(-0.6462018512378975,-38.80525509395528,0.0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark06(-0.6468378768361022,-32.73618786965785,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark06(-0.647030957611614,-1.3234889800848443E-23,100.0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark06(-0.647699219544283,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark06(-0.6478952523660746,-0.7337720447225184,-34.86807011184709 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark06(-0.6479439770845374,-32.670644814883225,-85.76410483605213 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark06(-0.6500387803496023,-215.19909373303213,-73.47906716697568 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark06(-0.6508706213626603,-1.1209881674682833,0.43718929948816765 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark06(-0.65129423641068,-1.5707963267948966,-3.141592707175888 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark06(-0.6528128583318099,-1.3407804512779649,-1.5707963267948912 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark06(-0.6538874862423988,-1.5707963267948966,1041.7852219892902 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark06(-0.6541580704043419,-37.8731498878828,-10.362783306343033 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark06(-0.6543137845090187,-1.5707963267948966,0.9691644224004428 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark06(-0.6543760831226635,-1.5707963267948966,94.14326473032071 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark06(-0.654397184454279,-1.5707963267948948,-82.19830890000878 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark06(-0.6560044819072924,-1.2156050405227004,-48.94333884994833 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark06(-0.6567747466974799,-0.8458511059760787,-3.266597309649549 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark06(-0.657445412868203,-0.9707308730350032,-279.6015651427049 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark06(-0.6579727841182565,-31.505812625151258,-3.1416464936657116 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark06(-0.6581068011124002,-0.2594004336446295,77.98506126491236 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark06(-0.6587956509547199,-95.5339738548598,-90.78996603911337 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark06(-0.6588790362125234,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark06(-0.659056624858442,-44.411056845813185,8.664211631357475 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark06(-0.6595991211195974,-32.87048110435771,-0.8890349209186442 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark06(-0.6598998008070899,-1.5707963267948966,-19.358440691657236 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark06(-0.660411595215344,-44.983715803893524,-100.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark06(-0.661348618002491,-101.84747996377412,-73.38034682365233 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark06(-0.6626102245590129,-1.5707963267948983,82.52945341072106 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark06(-0.6628519021410142,-45.31786005018559,39.27261169531252 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark06(-0.6639852449153643,-1.5707963267948966,18.46956413822109 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark06(-0.6641688666407037,-45.02454394450981,-1.5707963267948957 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark06(-0.6658961868741191,-1.0702194086955093E-196,1.5707963267948966 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark06(-0.666096595800605,-1.5707963267948966,-5.4258907020698075 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark06(-0.6661843325771875,-37.918555756798256,-70.00189117821063 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark06(-0.6668423855654124,-1.5707963267948912,62.12231591623791 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark06(-0.668456598177282,-1.5707963267948966,-58.56171673919856 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark06(-0.6694072014129571,-1.734723475976807E-18,-19.374352015895106 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark06(-0.6706277029687666,-1.5707963267948966,51.93123008618065 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark06(-0.6724487745207721,6.712388981054013,-0.0041355751760467395 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark06(-0.673608754701217,-1.5707963267948966,-21.11104709961014 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark06(-0.6739369062284598,-2.263919769706678E-72,0.4226906005666929 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark06(-0.6739874602717989,-0.3772757307620741,0.0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark06(-0.6752953503895851,-44.325798166393966,-5.683635918376581 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark06(-0.6758027281149916,-1.5707963267948966,-19.426071740368133 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark06(-0.6758948440090545,-1.5707963267948948,-147.869289884321 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark06(-0.6762208970700003,-1.5707963267948966,7.113079169190172 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark06(-0.6766133197172721,-38.95146974984254,0.0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark06(-0.678736603170984,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark06(-0.679250149836969,-1.5707963267948966,-1.5707963267949019 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark06(-0.6797754202662338,-1.5707963267948966,65.54901044120528 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark06(-0.680054135834912,-0.6029747061671511,44.53591947123169 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark06(-0.6800775557315891,-101.04750527852607,-0.021642966693539663 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark06(-0.6806184732937692,-1.5707963267948966,-55.85328687405654 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark06(-0.6809731222204682,-1.5707963267948983,7.808068510318563 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark06(-0.6816184408877461,-31.662946976226664,-26.332614773604774 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark06(-0.6816547647631751,-94.24777960771559,-103.0218743940788 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark06(-0.6818049913753859,-44.09384025807485,-559.1776728588758 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark06(-0.6833445314484572,-0.054905636177330824,9.735615046206203 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark06(-0.6839619169504172,25.132741228719194,-34.282766388882 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark06(-0.6858489645237146,-1.5707963267948966,-6.712388992605334 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark06(-0.6861383497644132,-1.5707963267948966,51.96781797752938 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark06(-0.6867908974875208,-0.35819982707335757,-0.19815605824791552 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark06(-0.687007892584068,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark06(-0.6872722925578428,-1.5707963267948966,3.2665927260533576 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark06(-0.6874938461056652,-1.1008029782440623,-4.712388980392156 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark06(-0.687601717507995,-1.5707963267948948,14.459565359049094 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark06(-0.687728143909905,-84.25245951139681,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark06(-0.6883879192754241,-1.5707963254592898,-1.5707963267948972 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark06(-0.6891217209789005,0.012415881960514172,-23.798089836315725 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark06(-0.6892545883880672,-1.5707963267948961,12.745651830911115 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark06(-0.6893197045766026,-1.3044141645714422,11.167977291857028 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark06(-0.6893677382021298,-1.5707963255054431,15.890562140210278 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark06(-0.6900321204829432,-32.53954605769711,-186.92686327255225 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark06(-0.6904433833733722,6.7123891426508155,-1.5707963267948983 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark06(-0.6905960887263841,-1.5707963267948912,60.36911633480068 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark06(-0.6907765181279293,-1.5707963267948966,-79.41873111762783 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark06(-0.6911667109405792,-1.5707963267948966,67.35990780025085 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark06(-0.6930283985419345,-83.28392537956837,-55.29082383820928 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark06(-0.6933613252621758,-8.25809992450435,0.4429293098651496 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark06(-0.6939270894031321,-0.7985182747281967,88.14966752148501 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark06(-0.6943066932155253,-0.4649559866164116,-0.024296278714108707 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark06(-0.6944378004590478,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark06(-0.6945508516251511,-0.5711762633483113,71.90953597943773 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark06(-0.6946422976222371,-1.5707963267948966,-0.10200436239558375 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark06(-0.6946672649362284,-1.5707963267949054,45.695965126594984 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark06(-0.694748459838479,-0.1209195093183345,-3.271156368876974 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark06(-0.6952969227124914,-0.8252875516800158,77.9014476587839 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark06(-0.6954457294901928,-1.5707963267948912,-70.35590483083175 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark06(-0.6957628650647424,-28.053733789490543,-48.25553853430458 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark06(-0.6963847489950111,-95.26429162648007,-3.1415926535898 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark06(-0.696727647733209,-7.896825413969131E-177,42.56714872799048 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark06(-0.696783131419288,-38.83555841477049,-304.1408459495743 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark06(-0.6974669897238204,-1.5707963267948966,-1.5095442393436067 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark06(-0.6975952331829571,-1.5707963267948948,-37.24496161758547 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark06(-0.6980114171097512,-88.39986403720826,-19.66141638730079 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark06(-0.6983689159762339,-1.329928266250928,100.0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark06(-0.698378848268588,-0.5077125581984352,-44.74221554154501 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark06(-0.6999757646705467,5.551115123125783E-17,67.61236181410163 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark06(-0.7001359157884681,-0.9513480612028344,2.768216026928073 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark06(-0.7002985955817826,-1.5707963267948966,10.938619899491997 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark06(-0.7006348002382518,6.712591059801096,0.380916796413775 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark06(-0.7010310132616703,-1.57065888501443,19.349556159202503 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark06(-0.7046571650003146,1.3877787807814457E-17,-53.755918600349034 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark06(-0.7046681976667416,-43.982428048929364,-177.647893896626 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark06(-0.7065768029169225,-1.5707963267948948,20.985713941398878 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark06(-0.707031098323128,-164.93349385071534,-77.95998517677805 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark06(-0.7071921358540235,-0.027309115876844814,80.29569753452081 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark06(-0.7072230182290499,-38.98194465089264,-33.88851541868701 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark06(-0.7072999935129808,-1.5707963267948966,17.322423279972902 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark06(0.7075229060777593,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark06(-0.7078927980276789,-7.965459555662261E-59,-1.4277781841858062 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark06(-0.7082685626613907,1.3552527156068805E-20,-5.288399189341568 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark06(-0.708748880138974,-37.802866562715735,-41.12559153371114 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark06(-0.7087911041528798,-45.546403834938204,-23.976080214845027 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark06(-0.7088930524845514,-44.40123484117837,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark06(-0.7109134596860236,-32.701892409766,33.346859229678685 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark06(-0.7125415559485312,-1.5707963267948966,-121.3346903810995 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark06(-0.7129369838958441,-44.257983946315434,-64.75592266073434 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark06(-0.7129972678708207,-1.4158303533071617,4.712648134220824 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark06(-0.7144202697225295,1.0842021724855044E-19,0.5288431281230727 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark06(-0.7146794964864345,-1.5707963267948966,-97.22408399596426 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark06(-0.7148237355782127,-1.5707963267948966,14.372071058952798 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark06(-0.7151436081032823,-0.5527425694578515,-90.43690729497925 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark06(-0.7155738308015528,-0.07029039736290432,1.5707963267948966 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark06(-0.7159302409191071,-163.84419103949534,-71.58116521423155 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark06(-0.716221189632958,-1.5707963267948872,-25.448986194092292 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark06(-0.7180035345922047,-45.134203471620594,-42.876061813707324 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark06(-0.7185158269064946,-1.5707963267948966,-73.79061677067784 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark06(-0.7196247871830224,-1.5707963267948983,373.77736434253643 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark06(-0.7197209443167635,-1.5707963267948961,45.6727799745324 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark06(-0.7199673027575635,-1.5707963267948966,-5.863948298142212 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark06(-0.7209314507053535,-1.5707963267948966,33.16498963416447 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark06(-0.7209688788666282,-0.4178596248517895,27.24610136708776 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark06(-0.7218516025561822,-0.2711746028749915,688.5515790460987 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark06(-0.7219995931811383,-0.18252059562961712,-72.33586930234112 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark06(-0.7225036399695234,-1.5707963267948966,-0.9992462802285703 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark06(-0.7235442307637893,-1.5707963267948966,-20.882745536159902 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark06(-0.7242516817461896,-1.5707963267948966,-37.7696891546571 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark06(-0.7253633316662653,-1.5707963267948966,69.28909902571885 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark06(-0.7259273134069373,-1.1711653604393333,37.7453247080467 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark06(-0.7260155781273895,-31.957753009755876,-45.138993751612944 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark06(-0.7272019520641932,-88.1777097483334,0.0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark06(-0.7277710027754937,-1.5707963267948966,50.61195479106719 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark06(-0.7285496692770028,-31.663575739228133,-178.405008189181 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark06(-0.7286615570442571,-3.1415926535897936,34.756834284628525 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark06(-0.7287640506680224,-0.02626664705061628,-4.5082903407156913E-131 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark06(-0.7295021368702166,-0.8386082331184098,73.8577841435038 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark06(-0.7297017422459305,-1.3303232233441353,-6.71240243618121 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark06(-0.7298509950144477,-95.81857593427186,-3.747583710679379 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark06(-0.7299507431761316,-31.877293914055542,-88.48759006921603 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark06(-0.7302010799763942,-2.220446049250313E-16,64.74486867074216 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark06(-0.7302089214009801,-94.27481740003195,-69.16598390836582 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark06(-0.731083265416359,-1.5707963267948966,1.0886541300075931 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark06(-0.7312525089602451,-0.033529383332373555,-1.5707963261159525 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark06(-0.7318531891767179,-95.44407189629655,-72.63441564345541 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark06(-0.7320373865777118,-1.5707963267948966,-58.895688711640425 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark06(-0.733369248466295,-32.74454851528544,-1.5707963267948977 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark06(-0.7334231856855972,-0.2070787416635046,-2.8585647805487038 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark06(-0.7334490189583139,-39.135678891859804,-33.44823442909501 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark06(0.7345621282538802,34.20516359905906,100.0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark06(-0.7347071082466212,-1.3177066537311077,-83.78157849460653 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark06(-0.7350296336244688,-1.0085073515037468,-1.5707963267948966 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark06(-0.7352039099824685,-88.4345161092052,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark06(-0.7352548482200206,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark06(-0.7356153175571454,6.7123889836361785,1.5707963267948983 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark06(-0.7357487704003632,-1.5707963267948966,93.45203261443477 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark06(-0.7369946918773849,-0.3205764133610156,50.698534779781966 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark06(-0.7378721526635887,-38.7450808687742,-1.0151767349262597E-115 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark06(-0.7386229926431724,-1.5707963267948963,582.2559395051214 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark06(-0.7387873898660492,-1.4148388707075727,7.01378991682689E-192 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark06(-0.739105016572871,-1.5707963267948966,2.5707962508244586 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark06(-0.739988874959292,-1.5707963267948966,49.78915512859748 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark06(-0.7404470617660927,-1.2407590055790625,-4.714342105384712 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark06(-0.740856910571728,-3.1415926535903274,-11.278970889848082 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark06(-0.7409423066696803,-95.46341110330809,-38.92887648777166 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark06(-0.7413989394572326,-31.976667441542492,-25.206459580288794 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark06(-0.7423723585224669,-1.5707963267948966,1.5791847988492818 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark06(-0.7431889406231811,-88.44181653630777,-52.70967013189083 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark06(-0.7432687570279539,-0.030957610242998368,43.71123469606334 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark06(-0.7439456931427857,-1.5707963267948966,4.712633257012095 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark06(-0.7444511260025312,-0.801083802637095,140.87937421043344 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark06(-0.7450061235706427,0.2627024661312015,64.13374311504771 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark06(-0.7465359227290774,-1.5707963267948966,-4.743643521551218 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark06(-0.7472867665473037,-1.5707963267948966,12.731643861242034 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark06(-0.7477196032623472,-1.5707963267948966,-49.78689659660074 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark06(-0.7478999132192067,-0.2614327033073405,-72.58831814922526 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark06(-0.748173944236575,-1.5707963267948963,-1.63329657724092 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark06(-0.749284661114329,-19.37820905425953,1.5708092291745328 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580471,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark06(-0.7494688649580488,-1.5707963267948946,1.5707963267948966 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark06(-0.7506961294440572,-0.8506924763310683,-1.5707963267948966 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark06(-0.7553111873472191,-1.5707963267948912,-90.91484442628615 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark06(-0.7562474475476507,-2.220446049250313E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark06(-0.7563298426984137,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark06(-0.7572836188396859,5.141592653589817,-19.69934554800628 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark06(-0.7575675910706363,-45.35175184941049,-3.1415926715066833 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark06(-0.7575890022121157,-1.5707963267948966,-4.712396616037478 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark06(-0.7586698490859407,-101.58741653398249,128.2823615845495 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark06(-0.7601008398469999,-1.5707963267948983,1.5707963267948983 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark06(-0.760182527764097,-45.087801521746954,45.61649314952882 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark06(-0.7602506731882369,-0.5633193324409428,-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark06(-0.7627624562413673,-163.7807466628266,-52.20268910654377 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark06(-0.7640825139334431,-1.5707963267948966,-9.987693216175003 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark06(-0.7646589920940259,-0.01643050507124144,59.69026041820607 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark06(-0.7653794350878513,-1.5707963267948966,31.15005702618936 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark06(-0.7673871435197578,-38.762403049975156,1.5707963267948912 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark06(-0.7687796019271783,-1.5707963267948966,76.94634260459193 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark06(-0.7687902788229437,-19.373925115580924,-0.2876568715033069 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark06(-0.7688549008501149,-31.537991924991655,4.743639044485041 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark06(-0.7702959486168233,-88.37115712027703,0.0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark06(-0.770444354109134,-31.674847669708925,-123.6928465271104 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark06(-0.770501243474683,-0.05952153105797679,1.5716857679568739 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark06(-0.7707397410602809,-1.5707963267948966,-53.75922482884083 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark06(-0.7713355165900011,-0.7720906115910733,0.0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark06(-0.771580303522938,-37.944790314401686,-18.2607599004278 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark06(-0.7716182368940839,-1.4513500833415947,-23.567152178483433 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark06(-0.7716495445949045,-0.27833295814105496,53.40707511102649 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark06(-0.7717256041033407,-163.78467404377076,-13.641314135533236 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark06(-0.7734909452885343,-38.914592913395936,-39.841051845795704 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark06(-0.774157330932091,-1.5707963267948966,-73.9385108149728 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark06(-0.7757416015803281,-37.733364714296705,-0.780886969694734 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark06(-0.7761689900976093,-0.006922085064051231,37.09389396377145 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark06(-0.776302035351343,-1.4437951868159926,-55.78898941009043 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark06(-0.7763866878030425,-1.3828241221580342,-54.36168787894291 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark06(-0.7764399073154808,-1.5707963267948948,-12.269189523470374 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark06(-0.7781377342146163,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark06(-0.778394283032452,-1.5707963267948963,221.73227740785754 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark06(-0.7795757187948036,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark06(-0.7800614084176303,-1.5707963267948966,-71.76034903714788 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark06(-0.7810805628081554,-1.5707963267948966,15.576707045590881 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark06(-0.7811629569017727,-1.5707963267948966,8.037148473847337 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark06(-0.7812259199581302,-100.54282509671532,-4.437385337295089 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark06(-0.781412152521213,-1.5334645637404312,-98.94378936606304 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark06(-0.7818095097360898,-1.5707963267948966,-42.045517794211456 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark06(-0.7825583580994067,-45.141903383989124,-1.5092990844644711 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark06(-0.7838625172582722,19.27845924389704,1.5707963267948983 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark06(-0.7849824747101057,-95.47194095122443,-27.87506429984328 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark06(-0.7864297712412356,-3.469446951953614E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark06(-0.7869505893381858,-38.73292854230594,-1.5707963267948974 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark06(-0.7873500081333026,-32.791037549768504,-0.5959266379054909 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark06(-0.7878746304498121,-37.81201435026128,33.39387589296373 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark06(-0.7880218915849468,-32.908026710425695,-1.5707963267948966 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark06(-0.7882733073714705,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark06(-0.7893152828533467,-1.5707963267948912,-96.87523143940378 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark06(-0.7894950148793253,-1.5333327775303802,136.65917188869992 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark06(-0.791548979830587,-0.045962931834197085,25.534218509635505 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark06(-0.7919700769477287,-0.18852978823492303,-1.574702583674852 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark06(-0.7932095032952764,-0.42479662933040785,-40.72387360824358 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark06(-0.7934409107154052,-1.5707963267948983,616.6480159178202 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark06(-0.7934415891056315,-0.16824661315092915,32.740980707284336 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark06(-0.793869218915036,-1.5707963267948966,-39.09477164460898 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark06(-0.7940598143551031,-95.47615705586618,0.6664521717291765 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark06(-0.7945896633702998,-1.5707963267948966,-14.282981376531295 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark06(-0.7946077961935405,-1.5707963267948966,-27.30398598109588 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark06(-0.7959271704369241,-0.9919386508942395,2.2853331523218734 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark06(-0.796878865699947,-8.673617379884035E-19,1.5707963267948983 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark06(-0.7971212363530916,-31.417836760117595,-36.18310453210657 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark06(-0.7974488708258934,-0.4234127731595975,598.6261700836093 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark06(-0.7979724687414038,-0.4141898256244144,4.714342105645868 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark06(-0.7986651576517686,-94.3568028813392,410.453060485332 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark06(-0.7990277280671634,-0.6475219711661527,3.141592653589793 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark06(-0.8032200237923091,-32.435974719204125,-78.72663330550947 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark06(-0.804104184390123,-1.5707963267948966,3.3695334221713904 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark06(-0.804465648554676,-1.5707963267948966,-3.190677765342187 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark06(-0.8048505238526193,-37.8651898808116,-9.828805222684565 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark06(-0.8052217773115432,-39.10148672711668,1.5707963267948966 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark06(-0.8057811633739388,-1.5707963267948966,-6.434091238442567 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark06(-0.8066365072433324,-1.5707963267948966,-638.1442172373416 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark06(-0.8073911108827545,-95.6454002997941,0.0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark06(-0.8076322642146376,-158.28208573464704,-4.76041823577785E-16 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark06(-0.8078807523270339,-37.7195265876686,-90.13227225295603 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark06(-0.8082294334790977,-1.5707963267948961,-2343.111518954975 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark06(-0.8083251986523394,-157.489763250675,-2.0708121029635977 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark06(-0.8087088156219195,-1.209626830261031,28.5292678857885 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark06(-0.8088363899118223,-78.25641422393149,-7.294011062323893 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark06(-0.8088634714518534,-0.12071747835170486,-87.22413888583031 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark06(-0.809143008500124,-1.5707963267948966,-102.03728307273899 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark06(-0.8096627058989201,-37.69911184307752,-75.772132041901 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark06(-0.8111068150504664,-2.6269035528309608E-287,-1.5707963267948966 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark06(-0.811628355396674,-1.5707963267948966,-55.77772629050797 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark06(-0.8132081915909699,-221.45997773805962,-4.712428500964109 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark06(-0.8132898465214964,-227.76517027092336,1.0015643532093565E-7 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark06(-0.8156530302530371,-88.1719773002668,1.565976882884249 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark06(-0.8170305155048682,-31.891744198668242,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark06(-0.8183332669944741,-0.0023850423613261825,-82.6637419769676 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark06(-0.8184455267879136,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark06(-0.8187244322532438,-1.5707963267948966,53.709018920476396 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark06(-0.8198982203508884,-45.15591202221968,-1.5707963267948966 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark06(-0.8229269391732043,-0.6360630726800437,-72.08918971492442 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark06(-0.8240295993168224,-88.51311582507499,1.4645423244488653 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark06(-0.8243655819515183,-0.07107693547013127,82.50735959010701 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark06(-0.8249754078449758,-3.1415926543456845,-1.3709007620393503 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark06(-0.8250559249319495,-8.198898739345992,1.5707963267948974 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark06(-0.8256165459472079,-0.033967294743222604,91.10667524348129 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark06(-0.8261287589894162,5.8551884644314494E-18,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark06(-0.8270710466566482,-0.02810714088887234,6.7123898253551815 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark06(-0.8293503173939669,-94.29543732492775,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark06(-0.8296068027547394,-1.5707963267948966,1.570796326675222 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark06(-0.8297214994508417,-1.5097732742567516,101.61211458251277 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark06(-0.8306978793590795,-100.5309653820258,0.0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark06(-0.8307095777198225,-0.6783511479278701,-100.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark06(-0.8307120821711412,-0.014777140252866174,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark06(-0.8314285124397944,-1.281133455876679,-42.489000290147125 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark06(-0.8322276480040021,-45.36551931431909,-15.555596979310081 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark06(-0.83244523153957,-1.4873354278585609,-25.72225893667688 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark06(-0.8337408130283385,-31.575857501244307,-8.236092143148846E-84 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark06(-0.8338108641200387,-0.11479500661980069,-86.18815764531547 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark06(-0.8342026940898832,-19.36038084929185,-0.15241597596216752 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark06(-0.8353251846697848,-1.5707963267948966,-27.88922987629368 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark06(-0.8359377505601913,-44.118509579609665,1.5707963267948966 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark06(-0.8365125144031307,-1.5707963267948966,11.442077594539725 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark06(-0.8372150739948836,-1.5707963267948966,83.34524302325053 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark06(-0.8383043261471989,-44.041988587449836,-497.8973098412008 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark06(-0.8384210741289816,-19.349555921638355,-99.04746191735055 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark06(-0.8384352656451605,7.853979580895031,-97.42483723405813 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark06(-0.8385083452856463,-0.6412172239365976,-31.782909433950465 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark06(-0.8387068931885755,-0.23606490848454798,1.4144883231853504 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark06(-0.8390482813679564,-0.5631412206596923,-41.587194349084506 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark06(-0.8397474636343372,-9.373105086847693E-243,0.0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark06(-0.840274016253068,-1.5621618367709023,-0.07831398015714142 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark06(-0.841608179068217,-0.0021283022586321677,68.2390221158258 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark06(-0.8418244558799353,-0.01130936423066249,0.8878534630793038 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark06(-0.8430709332903548,-1.5707963267948912,-2.7368299689115183 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark06(-0.8431877728863575,-101.5487469800477,-50.50833457130957 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark06(-0.8434809749983767,-1.5707963267948966,-73.4277948085569 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark06(-0.8437940741054012,-1.5707963267948966,-71.24227473417166 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark06(-0.8445594549875661,-44.36151897800167,15.275187894113841 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark06(-0.8457078279538108,-1.5707963267948966,61.11143553570521 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark06(-0.846363344780503,-1.5707963267948966,11.766573603716381 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark06(-0.8464281592554875,-44.07950900367049,1.1823659079648972 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark06(-0.8491269801612162,-101.00665933869885,0.4022751943703633 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark06(-0.8494996204436865,-1.2643809955097391,-26.81305652995943 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark06(-0.851060088224531,-0.3168706093271646,62.37421145188334 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark06(-0.8514948444763172,-1.5707963267948966,57.29665940660414 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark06(-0.8515404438802678,-1.5707963267948966,-3.4788904852696376 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark06(-0.8521380039265944,-1.5707963267948966,11.30540499316634 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark06(-0.8521783736583335,-157.2747043969216,-1.5750100127568056 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark06(-0.8527841694357449,-1.5707963267948966,10.949575930124622 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark06(-0.8528531709641296,-1.734723475976807E-18,6.712390807426378 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark06(-0.8528582856980864,-32.69490608326387,-10.492105992710862 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark06(-0.8538422459914171,-1.5707963267948966,88.11738415565449 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark06(-0.8539369500757213,-1.5707963267948966,15.321827941211648 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark06(-0.8541436990746345,-32.71974462350926,33.17592747206908 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark06(-0.8549005365208953,-43.982297150257104,-60.08543329478964 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark06(-0.8554071191802965,-44.34765485307439,-3.1415917617298974 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark06(-0.8558561403546563,-0.03395826089461665,0.0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark06(-0.8596545048013662,-1.5707963267948966,-135.28809055959437 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark06(-0.8599827560195068,0.038870946937204075,1.5707963267949399 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark06(-0.8604783474447197,-0.8875472238404714,-5.462966200633829 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark06(-0.8605990966317163,-101.74029244421891,-53.66214677936871 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark06(-0.8609292022430098,-95.53587570015401,8.020320680741563 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark06(-0.8622494346773948,6.938893903907228E-18,19.400759530976103 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark06(-0.8629318634638632,-1.5707963267948966,58.54052630418957 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark06(-0.8630501953814685,-1.5707963267948966,80.71407339677657 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark06(-0.8655445557909047,-1.5707963267948948,66.52468208971135 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark06(-0.8659641369596079,-45.017887782792386,1.5707963267948983 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark06(-0.8661717175850766,-1.5707963267948912,-40.83421275890669 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark06(-0.8666690222831847,-44.50187027360697,1.5707963267948977 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark06(-0.8673199239605509,-32.88979818084149,-69.49740652650095 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark06(-0.867641800034946,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark06(-0.8688759745134987,-1.4519362691844757,26.477501991942077 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark06(-0.8691393655653181,-31.922430188694978,-1.5707963260510813 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark06(-0.8700348992535752,-37.93007845405223,-4.066591461321292 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark06(-0.8709296395814987,-88.34463027377139,58.1628676497548 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark06(-0.8713171593354356,-44.12817233460907,-10.995574369207976 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark06(-0.8714273758786616,6.712388980384691,21.989115358025288 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark06(-0.8715086443947128,-88.27773373092042,-4.204190711199815 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark06(-0.8718389129723757,-88.34382380201664,-67.493220117378 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark06(-0.8718848604292954,-1.570796326294088,-73.54097319999649 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark06(-0.87208487596506,-1.5707963267948966,84.37803168048777 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark06(-0.8727928615225183,-31.851958820773415,0.20351517885663417 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark06(-0.8734751017001576,-1.5707963267948966,-84.55807081884208 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark06(-0.875976767719223,-0.07494782691711066,-45.301774990588186 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark06(-0.876265671120561,-1.4065581995741625,78.54952715623598 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark06(-0.8766372400570481,-0.7247137379482196,-4.743639028977113 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark06(-0.8775994203188141,-94.30284888047366,-742.5497405952816 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark06(-0.8783928527787781,-1.5707963267948966,44.098636923716896 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark06(-0.8783995001759459,-0.2321479525019774,-33.547973391605595 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark06(-0.8785923581750845,-88.25183532736807,-2.1895288505075267E-47 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark06(-0.8794641481989416,-0.3606229150591045,1.5707963267948983 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark06(-0.8796505149399337,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark06(-0.881654593940297,-1.5707963267948966,-30.154392224348257 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark06(-0.8827312118962324,-1.0292645553532678,-1.5707963267948966 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark06(-0.8839814257089679,-1.0603174522269267,31.08861945448107 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark06(-0.884275927712423,-11.707444499953041,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark06(-0.8855383370749018,-88.26523316369911,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark06(-0.8855602037182848,-37.814802054697736,0.5068128813212971 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark06(-0.8860971538476726,-1.5707963267949054,461.8141177209851 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark06(-0.8866380466383531,-0.5538638492546557,55.83358967544059 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark06(-0.8870311993507443,-1.5707963258838649,96.43383952754186 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark06(-0.8870385932194429,-0.8908608381191245,1.5707963267948966 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark06(-0.8884580184056775,-32.56017163257804,-76.88014254108197 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark06(-0.8889287346177583,6.7123889803945165,-3.2728264837192995 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark06(-0.8900945793661259,-95.32913554210415,77.36000537196898 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark06(-0.8903913839956041,-1.5707963267948912,-3.1415926535897953 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark06(-0.8907647076132394,-0.27988048428619616,-18.14452739667774 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark06(-0.8907689733746831,-1.5707963267948966,-4.723210509160684 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark06(-0.8915076545653121,-1.5707963267948963,3.266592653943579 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark06(-0.8940627937346013,6.712388991521984,59.332704027399636 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark06(-0.8942781705191376,-1.5707963267948966,5.224470840898842 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark06(-0.8943329981931835,-1.5463033980123488,-124.51174504282618 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark06(-0.8948894271973248,0.01780156097429154,15.13313376989069 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark06(-0.895330796143945,-19.388715467857928,-1.5707963267948966 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark06(-0.8984948918070153,-1.5707963267948966,-25.33879219611825 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark06(-0.8990872113629814,-1.1102230246251565E-16,-37.370839987111054 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark06(-0.8992984138515796,-45.278170126321776,0.0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark06(-0.8995227301731555,-1.5707963267948966,-53.780622141006795 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark06(-0.901341780458112,-38.754627031339986,-4.71268734280673 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark06(-0.9014727839141459,-101.04229916797436,-1.5707963267948966 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark06(-0.9026238354556488,-1.5707963267948961,31.41596740131405 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark06(-0.9027182462830812,-0.9755194952129609,53.24656145946501 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark06(-0.9032947732318775,-158.36529699605717,14.137296748838308 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark06(-0.9033392386933885,-44.215357671601936,-73.30840093236039 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark06(-0.9042510425872339,-38.7890604477838,-439.0155272537236 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark06(-0.9043548585725363,-1.5707963267948966,0.2455150240168078 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark06(-0.9053682489097417,-27.789946677664418,83.63624024407775 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark06(-0.9053863082916507,-88.3222762645667,-37.02470960625716 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark06(-0.9066122666693367,-44.19854026781111,-22.522234363005794 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark06(-0.9077909356009518,-1.5707963267948934,-6.7123892763581745 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark06(-0.9088713376070979,-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark06(-0.9095527518877764,-45.516307300327284,134.60843740563675 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark06(-0.9102276586208156,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark06(-0.9108906204634457,-94.37258922071928,39.7144779691905 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark06(-0.9114292558765786,-158.13542221609433,-46.8582642666111 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark06(-0.9119874212076189,-1.2130463774433118,-62.870582761597404 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark06(-0.9130557924504304,-0.06280795907360257,-73.58539900584375 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark06(-0.9133381373730979,-1.5707963267948948,64.53218363848075 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark06(-0.9146251871754747,-95.78309252520738,-53.88046761406522 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark06(-0.9147300896008261,-0.5180798250014126,28.20878774117556 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark06(-0.9158053237900603,-44.3845144987396,0.0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark06(-0.9158619034849286,-101.8513722263909,-512.0369525747523 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark06(-0.9163667679397278,6.712388980385164,-3.670730538105289 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark06(-0.9171925697532831,-1.5707963267948966,-24.258967377493963 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark06(-0.9182133281483402,-37.838663360306256,-1.5707963267948966 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark06(-0.9187137075885414,-45.385042771600716,-40.70805623654127 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark06(-0.9190144864192291,-1.5707963267948966,69.56276896194713 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark06(-0.919298935489358,-1.5707963267948966,26.314377320364528 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark06(-0.9193156257185175,-1.5707963267948966,1.5707963267958063 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark06(-0.9195475836200447,-1.5707963267948912,-181.48065135172587 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark06(-0.9205012766104286,-0.03363690011810613,1.5707963267948974 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark06(-0.9211093972732084,-1.5707963267920027,69.71467071430024 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark06(-0.9213960526722698,-1.5707963267948957,-43.27890164858352 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark06(-0.9215301956554509,-0.19550321593529807,-101.63679128366655 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark06(-0.9224445327382682,-0.2629764986185819,38.35289623230085 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark06(-0.9228363601678495,-84.53583563815447,33.69479842958057 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark06(-0.9228910699104169,-44.09544791858363,-60.31521379756792 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark06(-0.9232582501140546,-7.105427357601002E-15,1.734723475976807E-18 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark06(-0.9257376713290937,-38.70595025566874,0.0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark06(-0.9258955343452877,-32.418110921797734,-59.578533630624776 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark06(-0.9259222443857911,-0.6622461089447471,66.10244345010098 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark06(-0.9260579524074231,-19.34955592724421,-41.51930016307601 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark06(-0.9272212890483711,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark06(-0.927248282682722,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark06(-0.9274113492649678,-0.3176219487810907,9.42477796076938 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark06(-0.9280862812417372,-1.5707963267948961,55.59392982128758 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark06(-0.9294337667197534,-158.22018483630833,-174.3806793786855 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark06(-0.9301088857893305,-1.5707963267948966,40.453059371044375 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark06(-0.9305272667409944,-95.59740533312976,-90.63559179880562 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark06(-0.9321472164500971,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark06(-0.9322330936128563,-39.21930762498038,-46.15559021487405 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark06(-0.933386320850437,-1.5707963267948948,-1.5707963265099452 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark06(-0.9338834991816434,-38.79959563306002,-35.329143065990664 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark06(-0.9344558995819269,-19.417402193342344,-1.5707963267948966 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark06(-0.9361674030794528,-88.50365563319318,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark06(-0.9396314554981338,-0.22607390295599272,-41.54094188296121 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark06(-0.9408457248434666,-0.022558068967036132,38.95888989110502 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark06(-0.9411090328739106,-37.69911184307752,-73.34842012894829 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark06(-0.941894251840877,-88.50230139744824,-193.18106066176028 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark06(-0.9420510815591475,-1.5707963267948966,90.5482173812949 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark06(-0.9421953471752358,-37.88472407644785,-0.3926080338996947 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark06(-0.9426185138375738,-1.367308810899445,65.601806794543 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark06(-0.9426361476317261,-1.5707963267948912,43.85715961704773 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark06(-0.9438396542932028,-1.5707963267948912,-4.321736816076708 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark06(-0.9457252000644482,-31.41592653589793,-67.3572599903634 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark06(-0.9464356191654468,-95.36158972864996,-22.46094355062544 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark06(-0.946553348774078,-1.4878504912654325,67.04617638149836 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark06(-0.946637441042322,-1.5707963267948966,-4.714342107855714 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark06(-0.9503482956316944,-1.5707963267948966,26.00651514492363 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark06(-0.9510947061435644,-1.5707963267948966,21.187736307425766 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark06(-0.9521517562978424,-1.5707963267948966,-111.62451918665147 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark06(-0.9532569499598864,-0.6369460698931323,9.860761315262648E-32 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark06(-0.9537581774948988,-1.5707963267948895,78.04668192815086 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark06(-0.9538897591370109,-37.699112075858494,-1.5707963267949623 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark06(-0.9540244133774576,-0.34995433443698865,10.847897637921252 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark06(-0.9547277897516722,-0.5955340093896506,94.46307951854905 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark06(-0.9549138151377241,-1.5707963267948966,-4.712633121009691 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark06(-0.9556580395295351,-0.04063830863256808,-17.321799561484408 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark06(-0.955826141384442,-0.02811905937726744,0.0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark06(-0.9561146170574624,-4.440892098500626E-16,40.647672421017376 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark06(-0.9564977986261443,-0.04940765063085639,45.099818722222686 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark06(-0.9574605935738495,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark06(-0.9578393848976776,-101.97776387435721,0.17156763124350505 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark06(-0.9582817315354184,-88.41676317998734,90.0391305334187 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark06(-0.9600697080033078,-77.33906993166333,0.0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark06(-0.9611475892881246,-39.14766739261784,-1.5707963267948983 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark06(-0.96153392965836,-32.82577835640896,-0.3999929424566898 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark06(-0.9639020269767021,-1.5707963255927793,-51.270887633836345 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark06(-0.9654671158863963,-1.5707963267948966,-66.90447902435429 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark06(-0.9662086643796775,-0.9848663963166147,-43.982297150257104 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark06(-0.9663663871785925,-1.5707963267948966,-14.472585658608367 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark06(-0.9671993425041239,-0.136480195777144,1.5707963267948966 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark06(-0.9672823797998911,-37.834948743019964,-1.0255869741702242 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark06(-0.9674360132735609,-88.51975234455479,-3.1407942297829767 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark06(-0.9680307133807803,-1.5707963267948966,-4.428333193474799 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark06(-0.9690367410346873,-0.23886262448998719,20.962031721889062 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark06(-0.9692880225200041,-88.52413950430744,-72.68309162975217 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark06(-0.969474889262278,-1.5707963267948966,-59.67375624869778 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark06(-0.9700360342243483,-45.47132060858276,0.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark06(-0.9706008476155072,-0.7969742816816683,3.2665927166799977 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark06(-0.970756454080766,-1.5707963267948841,-182.65017292372917 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark06(-0.970757551932159,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark06(-0.9708760905939178,-1.3927365292218101,-44.19493160690982 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark06(-0.9711891953728733,0.3263046739020651,159.56169693252804 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark06(-0.972594434589765,-88.51056942074231,2279.8236010613605 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark06(-0.9733005196091824,-7.105427357601002E-15,-64.62264282054926 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark06(-0.9734845843353798,-0.28436543271896064,-100.0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark06(-0.9745496078347433,2.1684043449710089E-19,-66.91757291870861 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark06(-0.9745726260330407,-98.6587591537284,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark06(-0.974827222523622,-0.39391728876735477,42.68026283253458 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark06(-0.9757997512801728,-94.26034849616748,-126.96429716591248 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark06(-0.9762979062426913,-1.5707963267948966,-1.5707963256179793 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark06(-0.9793137165999805,-0.34028902542577993,0.4344006062495055 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark06(-0.9795611133360761,-31.656397329562864,14.391577636219289 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark06(-0.9806967473238567,-39.24737245370873,0.0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark06(-0.9808014063110946,-44.0512669997158,-4.882876560341337 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark06(-0.9814113387635759,-1.006271393750427,77.3258083891844 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark06(-0.9826954980568483,-0.16179997426754755,28.118977097395213 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark06(-0.9829014566730008,-1.5707963267948966,-73.30382560691112 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark06(-0.9831442698752871,-0.8484166081229433,-17.90749460671062 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark06(-0.9834513615485134,-1.5707963267948966,-156.467004997259 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark06(-0.9842634222348845,-1.5707963267948966,-3.141592654433316 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark06(-0.9857762424343751,-88.16796613240832,-90.8693382545705 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark06(-0.9866652150169912,0.0018630260212232684,52.03583283924392 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark06(-0.9886520043464821,6.712388980384691,-10.548241486532476 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark06(-0.9888344514679149,-284.30339753384914,-13.202043885965438 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark06(-0.9895241446527153,-1.5707963267948963,1.5707963267948912 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark06(-0.9900704686376485,-31.842852987811302,3.141592653836935 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark06(-0.9901110302471947,-1.570796326794892,-124.60709221112162 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark06(-0.9901569167831544,-19.371510182488016,-41.208006303111084 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark06(-0.9902189129367384,-44.13915623418831,-5.93713660828557 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark06(-0.9906328178224937,-1.4080910603699945,-1.5707963267948966 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark06(-0.9907311540248318,-1.5707963267948961,-1.6440542242316626E-16 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark06(-0.99138738984459,-1.5707963267948983,32.718111531927065 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark06(-0.9924322554206317,-0.3102339148969688,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark06(-0.9924647249259287,-31.708787137424743,-34.694234683323316 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark06(-0.9926269354083064,-39.07546357870213,-3.2665949564990915 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark06(-0.9933113581591018,-1.5707961388829335,1.1045773301511346 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark06(-0.9933927662041546,-1.5707963267948912,-70.84899686642785 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark06(-0.9935201479652066,-38.83693100207096,-32.46062493758511 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark06(-0.993987924578196,-0.7801866418545168,81.69038651850238 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark06(-0.9940917582004748,-39.24518698267548,1.5707963267948983 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark06(-0.9948997316130335,6.712388980384699,-24.235385227771715 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark06(-0.9960224623844678,-0.5626202218501201,1.1975691337123748 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark06(-0.9961564909390084,-44.023425681620495,-3.26659266490531 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark06(-0.9963785704896251,-0.6475571493837662,-37.81890202421353 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark06(-0.9967095486694992,-1.5707963267948966,23.562322584046168 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark06(-0.9969214703946622,-0.3465244935408096,0.0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark06(-0.9970384786088129,-31.55873913602082,-0.2527580902377455 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark06(-0.9976209188585032,-1.5707963267948966,-112.52784352754824 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark06(-0.9977539523488171,-1.5707963267948966,74.06889304062096 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark06(-0.9980550477902811,8.077935669463161E-28,82.84946278619415 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark06(-0.9986712034779298,-88.10632700165,1.570796326794742 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark06(-0.9998265519664395,-102.10175147152626,-68.78129905266712 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark06(-0.9998763630454919,-1.5707963267948966,1.4692399341258608 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark06(-1.0006224151137417,-88.4385585266994,-110.15000449746414 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark06(-1.0009867301182789,-1.035381855926354,0.0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark06(-1.0012445813182105,-1.5707963267948966,61.00220338570292 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark06(-1.0012637704136217E-14,-1.0112325191863478,-91.0242588229234 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark06(-1.0012748015324633,-3.552713678800501E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark06(-1.00292409848467,-37.745967550980126,-15.118985958452896 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark06(-1.0038368381797944,-31.973492173489234,-8.771174277275165 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark06(-1.0043445477067385,-32.702793182892215,-1.5707963267948966 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark06(10.047375693964739,-37.47511781460338,-17.75232534950119 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark06(-1.0052958797604539,-1.5354297748992694,-1.5707963267948966 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark06(-1.0053670887902024,-44.33342769549593,37.89909634241748 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark06(-1.0057186153280497,-1.2394437077551181,-74.26076798513989 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark06(-1.008552731231757,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark06(-1.0091545681811354,-100.95734546775711,-122.66107294205386 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark06(-1.009536230436251,-1.5707963267948983,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark06(-1.0095507470161307,-2.220446049250313E-16,100.0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark06(1.0096993901575138E-11,-1.2332838317675925,40.894465459205534 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark06(-1.0098461351122825,-0.08019210366211654,45.4745020161313 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark06(-1.0099649001734188,-157.33838845914724,-84.55163165861535 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark06(-1.0104205822388441,-43.982297150257104,2.635739794581184 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark06(-1.0113052285418638,-0.3027686415845862,-68.93681878684833 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark06(-1.0115346151707305,-1.5707963267948966,70.6139936108789 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark06(-10.117979995178501,-49.18205595387186,-80.42044392426683 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark06(-1.0118216154734276E-10,-1.5707963267948966,-3.1427554518968357 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark06(-1.0121013646334496,-1.5707963267948966,-3.141592640924274 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark06(-1.0121058242719485,-0.20309102233674273,1.5707959042229833 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark06(-1.012136802074259,-9.098784446709093E-4,73.37602260043053 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark06(-1.0122107222548273,-0.1327520508557733,6.278447993778528 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark06(-1.0123810129933872,-31.764386140522078,-3.3440093349076463E-16 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark06(-1.0127227581094056,-1.4225129026661498,37.75577590292079 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark06(-1.013240325336809,-1.5707963267948966,4.712389351410285 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark06(-1.0138019819301696,-32.429773467544386,-1.6242827758820155E-114 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark06(-1.016341429580248,-44.31674949340763,-67.028760045841 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark06(-1.0167888815213284,-0.6740886791577363,-7.854003054315646 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark06(-1.017159955000413,-0.7796961118314268,0.0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark06(-1.0174938607053767,-1.570796326794897,-4.7924680699869615 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark06(-1.0176333790668046,-1.5707963267948966,-67.22981458681048 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark06(-1.0179715316465659E-4,-0.9355065066579193,1.5707963267948966 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark06(-1.0181647161280634,-1.5707963267948966,2.9217528512239936 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark06(-1.018195476870496,-3.141592653593779,-21.892335683459244 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark06(-1.0191000077068055,-1.5707963267948948,30.01107764158824 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark06(-1.019874628298229,-0.5897629883744477,48.098098662503354 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark06(-1.0201565824855627,-1.5652258480668535,-3.2665926650047745 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark06(-1.0207371652695159,-1.5707963267735245,99.11951959021206 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark06(-1.0226001698653306,-44.15370138602844,-6.916261021693444 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark06(-1.023118233936558,-1.3877787807814457E-17,3.266592653642804 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark06(-1.0238650411471593,-38.966477539135795,0.5772357929939859 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark06(-1.024163156475931,-1.5707963267948963,-10.84834117979462 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark06(-1.0243917503369318,-0.00988288646479063,-1.3525604999281975 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark06(-1.0263955702699419,-44.39799330685238,-53.99663032401446 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark06(-1.0267994512651812,-1.5707963267948966,-97.27102103475445 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark06(-1.028048636888867,-31.704168548223517,1.4370827144157203 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark06(-1.0281956993299541,-0.14439188924615998,40.677547550015134 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark06(-1.0283457465596015,-45.13155669322365,-96.63032282219008 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark06(-1.0287751183514724,-3.1415926535901537,71.81034206237052 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark06(-1.0289138000733362,-88.09832475159915,-99.77685468455272 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark06(-1.0295115178936058E-84,-1.5706936258549327,-20.427496413076618 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark06(-1.0295115178936058E-84,-38.7621962230115,-45.81950565721138 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark06(-1.0299112788773268,-1.5707963267948966,13.857290295887903 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark06(-1.0302022452218513,-44.10578036563878,-2.5707963263385687 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark06(-1.0302192583060028,-0.4527087528845949,33.00415652967661 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark06(-1.0303843441134717,-1.5707963267948983,-138.00005385264498 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark06(-1.030523269033469,14.429223168035762,-100.0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark06(-1.0313869899492714,-1.2277007176084225,-34.376696411175125 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark06(-1.0315593987793931E-4,1.5707963267948966,45.096053201217195 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark06(-1.0319017613058454,-1.5707963267948966,-6.712389054435786 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark06(-1.0320424861574269,-1.5707963267948966,505.0609984481285 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark06(-1.033014613241273,-37.9341631535202,1.734723475976807E-18 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark06(-1.0331202536274642,-1.5707963267948966,-40.46611382283935 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark06(-1.0351500311773387,-3.1415926536045506,4.353884210683216 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark06(-1.0358792622971809,-39.228999831692065,121.05284160666307 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark06(-1.0359587994152921,-0.05924005673349211,56.10856205563284 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark06(-1.0368441932598476,-39.252831161114415,1.5707963267948977 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark06(-1.0370082478480314,-3.141592653687683,-53.084328876758555 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark06(-1.0376177814921006,-1.5707963267948966,-68.08425158956418 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark06(-1.0389805902374074,-1.5707963267948966,-3.266592669905251 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark06(-1.0393442187302555,6.71239568794952,-66.80893178724817 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark06(-1.0399905637005897,-1.0139069636288163,64.6727165646695 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark06(-1.0404095538214837,-37.77864806350196,2.279623366859246 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark06(-1.0426887219727377,-44.478647763205466,-14.560199959569132 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark06(-1.0427105377068715,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark06(-1.043027575625498,-1.5707963267948966,0.8343678801877498 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark06(-1.0430335241899569,-44.19100453426411,-25.50312803423477 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark06(-1.0433943911442252,-3.1415926536078107,1.5707963267948983 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark06(-1.0435817495765392,-88.3115953201213,-0.06814533974604277 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark06(-1.0436425455207867,-88.48732142259544,-10.670047859173891 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark06(-1.0438534966992423,-19.349555921538762,0.5991554820241894 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark06(-1.0452824548817858,-1.5707963267948963,15.707963267948966 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark06(-1.046682684417907,-31.660127999698744,-88.33521581722927 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark06(-1.0467838091461874,-0.2647435426381325,12.210334385211908 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark06(-1.0478750989961947,-95.63770284591419,1.5708268443910147 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark06(-1.048081246617025,-1.5547248981069204,85.3411120544 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark06(-1.0500440339096215,-1.5707963267949019,-93.6344502863682 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark06(-1.050559046303558,-44.37758906391948,-45.09572236581998 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark06(-1.0507264111582284,-31.427118055014883,-53.60381585394619 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark06(-1.0514156607036196,-1.570796326794833,91.96585459985131 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark06(-1.0518213727819359,-283.83823337855983,-100.0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark06(-1.0521511108025987,-1.5707963267948966,-1.253702495990651 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark06(-1.0532168371318475,-1.181433857939096,44.53219921545821 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark06(-1.0534517085500132,-8.881784197001252E-16,58.3365650184916 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark06(-1.0542459855415058,-44.26583698930269,-58.22787887477679 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark06(-1.054350183208611,-1.5571678569429062,58.17403231332941 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark06(-1.0551218679221383E-5,-39.269807680986915,-3.141848455019329 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark06(-1.055182973769933,-1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark06(-1.0559715413912332,-0.015647225173833094,-9.735582960189703 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark06(-1.0560188974603424,-1.5707963267948966,-12.489416032689292 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark06(-1.0563464118983121,-0.03179602165497064,-23.98221957147311 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark06(-1.0564451147008578,-0.4946330262661909,-40.82427916877851 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark06(-1.0572439840102346,-1.5707963267948966,-0.6897967490715411 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark06(-1.0580680891258556,-45.50134236574788,-1.5707963267948966 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark06(-1.0581354952249598,-32.553977428400174,-53.72855261758305 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark06(-1.0585200198903626,7.853981633972706,-1.5707963267948983 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark06(1.0587911840678754E-22,-1.5707963267948966,1.1486522621760284 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark06(1.0587911840678754E-22,-31.909043018934522,83.79505512980342 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark06(-1.0605255211253415,-94.32391827195893,2.570796326497649 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark06(-1.060562347591063,1.1102230246251565E-16,90.35059011790509 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark06(-1.060635392007411,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark06(-1.0607671010811466,-1.5707963267948966,-56.05289140927219 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark06(-1.060853019040697,-1.5707963267987275,124.44512702765459 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark06(-1.0609439476312164,-88.43248226607109,-71.85599212636353 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark06(-1.0613298755819187,-1.5707963267948966,-97.88968420699244 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark06(-1.0620048877976664,-1.5707963267948966,84.82300164692441 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark06(-1.0623871502126945,-45.43133864686889,-71.84034376200086 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark06(-1.0625200184572334,-0.0558524041965621,-133.4497445143195 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark06(-1.0637840349578198,-39.15195737202027,84.39071319298753 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark06(-1.0643315485257534,-1.5707963267948948,-5.480433798733287 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark06(-1.0650833137046383,-88.49476456019295,-1.5707963267948912 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark06(-1.0660887629873814,-95.51306874447769,-0.3205667260449042 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark06(-1.0663427370301122,-8.881784197001252E-16,-60.67923884963085 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark06(-1.0667645503959644,-1.4783877880819658,-4.74363903704224 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark06(-1.0679894177837266,-19.37856596510535,-90.57839629310143 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark06(-1.0681859331106853,-1.5707963267948983,-28.086878472393934 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark06(-1.0683909541037937,-1.5707963267948966,-97.64129056085766 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark06(-1.0686734241746938,-1.5707963267948966,-14.435527516525731 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark06(-1.0696569540994028,-31.978551583418465,-5.2710989716152616E-82 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark06(-1.0696591758487242,-1.188966021426971,-17.278803647928363 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark06(-1.0704379014199688,-0.023858704154560404,9.894928386111204 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark06(-1.0706409959833418,1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark06(10.709601092565606,-18.61192575445685,-26.086907427892697 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark06(-1.0710579432178917,-39.23279216300171,-4.712389369987776 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark06(-1.0721919588286437,-1.5707963267948966,-84.94932551369033 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark06(-1.0725468216862835,-88.19852876248854,-742.942125379822 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark06(-1.0732335597995808,-0.7178927174150003,0.0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark06(-1.0739156157131973,-45.018855222105806,20.655925889940686 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark06(-1.074096178496307,-1.5707963267948961,-32.78285575091546 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark06(-1.074306723242004,-1.5707963267948966,12.442788133686017 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark06(-1.076295425744076,-0.5895210871423601,0.0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark06(-1.0766661059016207,-1.1102230246251565E-16,-0.42380718506329085 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark06(-1.076835132983053,0,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark06(-1.0770375222161825,-1.5707963267948966,43.57584726883351 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark06(-1.077601064959441,-101.6879969975882,-51.64116651959861 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark06(-1.0789187551506585,-1.5391872046109019,80.33830407335545 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark06(-1.0795210693868056E-78,-0.005497012159414658,1.5707963267948963 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark06(-1.0799828759128085,-1.5707963267948966,-88.5159959777447 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark06(-1.080386489255094,-32.89688891358811,38.97096034803772 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark06(-1.080505958941825,-1.5707963267948966,-71.65692974449078 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark06(-1.0810598104016556,-88.44979494453291,3.1415926670884926 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark06(-1.0829753744844495,-45.102934726629435,-1.5707963267948966 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark06(1.0830979186002103,167.75978596845874,-30.591279080430724 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-0.8545744399640487,-1.5075853943951076 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark06(1.0842021724855044E-19,-1.20073075761673,53.70888539112866 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-1.5707919902355394,-65.89756344878354 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-1.5707962310181622,59.68918661015465 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-1.5707962889322131,-39.26905653987366 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842021724855044E-19,-1.5707963267948966,34.55749852195085 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark06(-1.0842456137547136,-1.5707963267948966,-2.8888138752103893 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark06(-1.0844674559934306,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark06(-1.0848596699760715,-95.70003268593914,1.6054767496588557E-9 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark06(-1.0851543344809425,5.293955920339377E-23,-12.141697042294426 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark06(10.855422616874293,-49.24269847712554,-69.77600183046455 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark06(-1.0856278750338626,-1.5707963267948966,3.1415926535897936 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark06(-1.0859739639989496,-95.33868538789228,28.232298715742225 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark06(-1.0865200514121405,-1.5707963267948966,98.61482248741126 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark06(-1.0866237643940426,-1.0260392034837906,-9.983253491873342 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark06(-1.0867002656127136,-45.13905007644923,59.20795150651184 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark06(-1.0868085053845236,-45.55309347689266,0.0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark06(-1.0885574886336584,-1.5707963267948966,58.144879934553515 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark06(-1.0885637816940714,2.465190328815662E-32,18.935748848848206 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark06(-1.0888639676532683,-95.43186922425093,-1.5872232980135952 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark06(-1.0889013935393839,-5.1977048828224496E-113,-66.1545225150913 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark06(-1.0892751483746863,6.712388984172434,0.0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark06(-1.0895938979628996,-45.11331056064715,-1.1330477819110873 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark06(-1.0911270835812104,-95.6109032641603,1.5707947505151032 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark06(-1.0912028303374686,-0.9144232492787521,10.651278323282483 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark06(-1.092433743434456E-177,-0.990225738325316,0.0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark06(-1.0932063482274428,-0.15142609227808687,17.218540703738086 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark06(-1.0940155056728223E-19,-1.5707963267948966,21.991148318401564 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark06(-1.0948481287997183,-1.5707963267948963,42.19675639998174 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark06(-1.0953076702634812,-1.477660194773488,3.266596549924528 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark06(-1.0957579157351587,-32.43547841708266,7.225426619611618 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark06(-1.0961842054877622,-39.10985121721072,-10.865343661769074 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark06(-1.0965666791344744,-38.91010646348332,-53.662128564722 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark06(-1.0968667820299203,-100.0,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark06(-1.0972630693313667,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark06(-1.0973133620889204,-32.62615896916435,-58.54525211630895 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark06(-1.098200497370619,-44.42898654884061,3.1415926535897953 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark06(-1.0982008160583137,6.776263578034403E-21,72.02843021905926 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark06(-1.098582955130671,-1.5707963267948966,13.74382906797848 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark06(-1.0986661345132351,-39.08741268254124,-61.08876770315261 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark06(-1.0990878969207492,-0.2629439873561537,-1.5707963267948966 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark06(-1.0993251171893141,-4.527839539413356E-72,-1.5707963267949054 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark06(-1.0996222283420023,-1.5707963267948966,94.2935528991671 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark06(-1.1002289762205992,-1.4984383129199466,-648.9456289896825 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark06(-1.100372833038504,-0.9034738799490378,-80.3515716665324 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark06(-1.1010206408732852,-1.5707963267948948,1.4268586292420986 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark06(-1.1011308341137496,-0.19431748329966386,-68.45724090150941 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark06(-1.1015909977162006,-1.1889750449643581,6.712388982494095 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark06(-1.102069550398518,-1.5707963267948966,-3.94511173176818 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark06(-1.1029833921229464,-44.410194060892984,-45.15114030955447 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark06(-1.1039888157127162,-0.5900947416389729,-100.0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark06(-1.10441008915498,-88.10809113599518,69.34251289565452 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark06(-1.1048016108158498,-1.0010415475915505E-146,-1.5707963267948966 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark06(-1.1061344944122107,-1.5707963267948966,-16.87507121439068 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark06(-1.1065240266050005,-26.927031450475738,-1.5707963267948948 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark06(-1.1069121501277495,-1.5707963267948963,-98.02264182228603 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark06(-1.1077713264358238,-164.50703630413858,2.9087161602537725E-4 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark06(-1.1080606148044945,-1.5707963267948966,6.12356289923581E-17 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark06(-1.1085395304147059,-1.5707963267948966,26.61701967549871 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark06(-1.1090780546577315,-88.4316596487801,65.95154343764958 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-0.03108524036185012,-46.70450824898154 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-0.04227928787967189,0.0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-0.1251522931045479,100.0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-0.15891253914672887,0.0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.293103900243036,-77.72321889456349 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.34007047658604006,-32.200461243604394 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.5488454719341487,77.24958749210168 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.6092298426558289,-7.443611528663823 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,0.8112414019966445,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,100.0,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.0219803319722938,34.552742102324586 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,10.428460080400086,0.0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.052726587034138,20.926376936646875 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5072815349007407,-48.694322894069266 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5157753469655972,-31.728669556328278 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5397029021252377,100.0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.545422394498458,-1.2848426483869417 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5550278884711972,-19.787437131670544 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,10.562906899656362 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,1.1144959663741938 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,1214.487114367912 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,-1.3889484808541157 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,1.4459867060596132 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-1.5707963267948966,25.63815168183438 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,32.57142272245052 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,-37.87384386606328 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,53.6744131300604 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,59.610935390853065 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,66.30740881485107 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,79.42832362978606 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,80.1145063957431 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,86.37518959669853 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,1.5707963267948966,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,16.702642910303716,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-2.742565972207177E-15,19.322361767456613 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-2.7755575615628914E-17,-0.8089548177635706 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,4.126316683927566,571.6086814238778 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,4.404996704241801,56.16726936839852 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-44.47065866113255,-74.82190336304701 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,-45.140273851106286,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,56.38621802683464,0.0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,60.82985171970491,0.0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,72.47831524271774,0.0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,73.62206811623307,-14.430545928920445 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,79.26661440064125,0.5646274749965671 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,8.536555586570088,-5.161639760296509 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,85.80501202980152,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,86.14235593488557,1.5707963267948966 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark06(1.1102230246251565E-16,-8.922196717847698E-4,36.65337221542356 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,90.30353910270588,11.380598643615393 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark06(-1.1102230246251565E-16,91.55630164929683,0.0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark06(-1.1108956340467522,-88.20330541272706,-9.529129591528545 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark06(-1.1113793747425387E-162,-95.41764692489636,38.97594452164762 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark06(-1.1127210212519272,6.712388981013868,-56.940366617062644 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark06(-1.1136890550297278,-3.1415926535897967,-11.536117706831163 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark06(-1.1162405583765747,-1.5707963267948912,2.1146645472677363 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark06(-1.116627373425319,-101.66207742014372,-33.15998181329827 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark06(-1.1171161692388997E-6,-284.3137634859724,-97.39068206142932 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark06(-1.1181073919189026,-1.5707963267948912,-59.571683478240615 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark06(-1.118534566740946,-1.5707963267948961,42.4972062698568 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark06(-1.1190046332123091,-1.1784994716175647,-158.2784817605772 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark06(-1.12027994831613,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark06(-1.1207415104687934,-1.5707963267948963,-4.712633121014018 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark06(-1.120918607242198,-0.9529065772614943,-51.63841863687786 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark06(-1.1219992298000714,-1.5398825540060272,0.0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark06(-1.1222063866923024E-190,-1.5707963267948966,-1.5707963262687876 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark06(-1.1229299786076181,-1.2713368192818878E-10,41.106726075907964 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark06(-1.1229302606350957,14.458626358141537,0.4012676821037646 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark06(-1.1231871711367116,-1.3071820113986743,-33.53249539925571 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark06(-1.123241807718317,-0.7042942496622431,-44.81137133128392 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark06(-1.1237040784679337,-1.2497529677198342,-24.2823644189988 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark06(-1.1242046847513798,-94.26614562445522,-48.741148867811 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark06(-1.124968809528102,-1.5707947904126518,1.5707963267948966 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark06(-1.1252193547434028,-3.469446951953614E-18,-22.13742651924264 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark06(-1.1253128447992609,-20.74944558738379,-34.25348056731209 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark06(-1.1268508076905854,-0.1927915758051108,-2.4049510458874304 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark06(-1.1273121157292636,-1.283836125203548,-45.781377882481344 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark06(-1.128875702754849,-31.647501611466154,-1.357957675634335 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark06(-1.1303644762200988,-1.5707963267948966,-5.9736034527486375 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark06(-1.1305528731000485,-1.5707963267948966,-80.49170176442135 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark06(-1.1307497878879832E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark06(-1.1314881589461583,-95.78810382707348,166.0988586715058 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark06(-1.1316736422374256,-1.1566089623006377,91.2566042399271 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark06(-1.1320175831243922,-157.41843075046216,96.55062407977235 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark06(-1.1322177959515786E-10,-0.48631025797989386,-38.76379241480283 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark06(-1.1323468546720528,-1.5707963267948966,31.268956037621678 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark06(1.1326583341710117,1.5707963267948966,78.80625511993439 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark06(-1.1326975161445418,-44.08892803843507,-23.587943875877034 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark06(-1.133041447685212,-37.81944458503399,1.0097496816695464 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark06(-1.1331074834977148,-0.4357913112777445,-3.141592653589793 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark06(-1.1351020258636513E-5,-1.5707963267948966,8.190094526847062 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark06(-1.1351062870042554,-0.3645300447830399,71.36922674369508 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark06(-1.135302411282637,-1.5707963267948966,45.388104647640034 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark06(-1.135496503678115,-1.423319031513081,607.4336843661665 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark06(-1.13581759980503,-0.2181793280097693,-85.31513039372473 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark06(-1.1358648079920681,-1.5707963267948966,40.84070449666731 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark06(-1.136059260697502,-1.5707963267948966,65.97344597469424 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark06(-1.1365920330773565,-9.232978617785736E-128,14.58082380400814 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark06(-1.1365959324281651,-31.837748871310964,1.0635909591440864 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark06(-1.1366000852471032,-90.96674742970121,-16.637433271238816 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark06(-1.1375537410215062,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark06(-1.1381488484967521,-37.88931868957178,-87.24406458033518 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark06(-1.1383456306359196,-32.557984856527824,-42.582339451094626 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark06(-1.1401038996321495,-1.554353728471238,100.0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark06(-1.140909814573787,-0.8307777649655963,-4.917253988951096 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark06(-1.141620326390806E-16,-1.5707963267948966,72.62135352752153 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark06(-1.1418306798956344,-0.5707788980317595,-7.893668040429531 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark06(-1.1425377836001716,-32.59308069247166,-23.128117337679615 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark06(-1.142987391282275E-100,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark06(-1.142987391282275E-100,-31.958642264828466,-39.24093117812764 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark06(-1.1433481285509661,-1.5707963267948966,-67.50545388441472 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark06(-1.1441714529980591,-0.0015585306092792488,4.7436515900421945 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark06(-1.144189282576054,-1.5707963267948968,-8.103981633974485 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark06(-1.1447669703774903,-101.00828364952996,-16.898453021283743 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark06(-1.145302312595914,-88.36805772228934,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark06(-1.1455237156827436,-1.5707963267948932,10.459094255179844 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark06(-1.1458311321564114,-1.5707963267948966,12.473367851636345 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark06(-1.1464794818587798,-1.433663729781473E-16,45.539803207889264 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark06(-1.148171900344294,-1.2310042516572894,-34.80941744141539 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark06(-1.1489766036624545,-1.495050466074988,100.0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark06(-1.1490975635112826,-1.5707963267948966,32.948456197786015 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark06(-1.1495942564924784,-0.1273100343407572,-2.514877693153281 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark06(-1.1497218300943097,-0.9061095486586774,1.3070853923796761 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark06(-1.1497441145236102,-38.918720432125234,0.6645564751931816 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark06(-1.1503202388566445,-19.350302244829525,-0.5286629216423194 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark06(-1.1508310330699663,-1.5707963267948966,-24.23844989496314 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark06(-11.516900945486185,-80.92855584874712,57.65566722952761 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark06(-1.1522106781277264,-45.10819933227803,-124.00940142470468 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark06(-1.1523266615470504,-1.5707963267948966,-1.5627984296727289 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark06(-1.1530314970458173,14.429503581824584,1.5707963267950016 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark06(-1.1534637736685052,-1.4467285943289452,-27.104023749585537 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark06(-1.1535163150904177,-0.3504805142284686,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark06(-1.15381178598264,-0.7291820617106888,96.33375123402602 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark06(-1.154097000672448,-0.821897611424442,0.0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark06(-1.154122327223217E-128,-1.5707963267948966,10.920604348925043 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark06(-1.1542386957463095E-13,-1.5707963267948966,-52.07192267273229 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark06(-1.1546251105192063E-14,-1.5707963267948966,-3.141592652488172 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark06(-1.1557204648058956,-1.5707963267948963,-84.22979788405306 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark06(-1.156613156895351,-0.7522117099440111,65.32007130292547 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark06(-1.1567516040850105,-0.31597370172168493,83.52606389968074 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark06(-1.1570324575381883,-2.220446049250313E-16,-40.46840117798135 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark06(-1.1570743777016963,-1.4961691486175983,54.911505372294464 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark06(-1.157976523588703,-88.42901958806496,0.0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark06(-1.158677535178848,-1.4210854715202004E-14,-9.657154302523537 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark06(-1.1587086732712357,-0.9272535839815239,-158.3800568740225 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark06(-1.1587779757998642,-0.07758202118069235,39.11000219630398 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark06(-1.1589119511331194,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark06(-1.1602019862357025,-1.5707963263362608,1.5599324202035867 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark06(11.605153854024366,-57.157418430094296,-46.70458917922979 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark06(-1.1612629607826062,-32.46179483447646,-1.5707963267948966 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark06(-1.161368557263089,-3.141592653589794,-87.66445391629154 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark06(-1.1637105651503963,-31.59578706110441,0.3225406182298465 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark06(-1.1639392644039868,-1.5707963267948966,125.10232849131242 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark06(-1.1639597009923541,-1.4150301103518927,-54.183484729142364 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark06(-1.1641545444115933,-1.570796326794891,4.7436389810861215 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark06(-1.1647724490809366,-1.5707963267948983,-48.70886905159737 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark06(-1.1650326414301908,-1.5707963267948912,-58.217468189833866 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark06(-1.166425530691694,-158.52973672865238,-45.69025501630216 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark06(-1.166958329369976,-1.570796326794774,-100.0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark06(-1.1671088035065742,-32.73651834871838,14.348506520282827 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark06(-1.1673381896239863,-95.58172334299674,-95.16563979949632 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark06(-1.16824607604185,-32.743091140531696,-46.15462421464313 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark06(-1.1690934197277065,-0.22292974583802305,-85.28536686209623 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark06(-11.700358441308524,34.39383816653586,81.34647911755619 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark06(-1.1704190886730496E-97,-44.03337683349861,0.8949394110763884 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark06(-1.1709503009633782,-31.48584985057873,0.0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark06(-1.1713915297429587,-1.2738619354200773,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark06(-1.1722322904236528,-1.5236976602524449E-15,62.55046628908409 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark06(-1.1723460018561915,-1.5707963267948966,740.9125825548897 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark06(-1.1733618531385446,6.712388980384698,-1.5707963267948983 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark06(-1.1744297541138136,3.469446951953614E-18,26.896108228099635 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark06(-1.1745904449698734,-88.15072908146935,-33.973605683968515 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark06(-11.746328546470309,95.740801749806,87.96129974096044 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark06(-1.175091500024727,-0.9428800139703668,-53.9766652911052 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark06(-1.1757452327447513,-1.5707963267948948,-93.38599006335504 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark06(-1.1761588668951886,-31.659497371432522,-4.712396610377044 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark06(-1.1763650629736784,-1.5707963267948966,0.261091603543294 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark06(-1.1764978188063744,-0.1338371738675594,-3.24767323764938 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark06(-1.176877918090213,-1.3159799880576202,11.179502912986205 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark06(-1.177017736064482,8.470329472543003E-22,-0.7774908509923415 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark06(-1.1771366161634338,-1.1102230246251565E-16,74.7928538671815 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark06(-1.1777311776705497,-38.80903288758157,1.5707963267948957 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark06(-1.178766793081175,-38.722330466401104,109.46160234702167 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark06(-1.178965212824622,-88.3644069788922,1.5707963267948963 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark06(-1.1792420925774048,-0.09066775292768946,34.90938343430132 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark06(-1.1796317546413222,-1.5707963267948966,14.429305156872957 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark06(-1.1813989242703817,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark06(-1.181761891460131,1.1102230246251565E-16,-96.94717856475454 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark06(-1.182386060427252,-31.43175853607405,-0.6670376902037986 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark06(-1.1828472124108813,-1.5707963267948966,79.1050468513626 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark06(-1.1830521861667747E-271,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark06(-1.1832162168926805,-1.5707963267948963,20.5160039351765 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark06(11.833556311420935,24.183200196581026,-94.32456245563871 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark06(-1.1840271901220802,-32.94192159458318,-13.516558309106472 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark06(-1.184177719685422,-1.5707963267948912,50.833473348892 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark06(-1.1844778707729766,-1.5707963267948966,39.020276001342936 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark06(-1.1844844515785422,-95.49518370282968,1.5707963254899922 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark06(-1.1856434891368037,-1.1102230246251565E-16,50.52240378213924 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark06(-1.1859059377596308,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark06(-1.1870273541803453,-95.73778137783795,1.3379171758077462 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark06(-1.1874763806628141,-0.5652688361830119,0.39083467106450664 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark06(-1.187610237179243,-0.3408734143641272,-47.46538716921685 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark06(-1.1877470701789306,-101.81543224473197,-127.4132982969065 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark06(-1.1878904093744467,-1.5707963267948966,-96.42414376306945 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark06(-1.1879420797900375,-1.5707963267948963,-85.5893409796938 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark06(-1.1879507273736358,-1.5707963267948966,4.293654617144 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark06(-1.1882365731086817,-2.9071435571716405E-15,0.0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark06(-1.18917654109591,-88.36183417041089,-1.5707963267948966 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark06(-1.1892807054961738,-0.09567854468067427,2.5707954061287466 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark06(-1.1899558914277645E-18,-1.5707963267948966,58.1194121840223 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark06(-1.1900063013765685,-32.9787253239276,-3.141592653589793 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark06(-1.190175201466203,-78.05317382639932,-1.5678789560709658 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark06(-1.1907203922730751,-44.438617925637665,-59.57292493113565 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark06(-1.1912870167798064,-88.45454357662972,-51.66789892425599 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark06(-1.191629144197364,-1.4432213354515273,-441.2430891325223 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark06(-1.1920927244088377,-32.73285486748972,-1.5707932890037983 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark06(-1.1922238702611825,-1.5707963267948966,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark06(-1.1933536504639641,-32.8348754641944,77.12380815376858 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark06(-1.1934053867499261,-1.5707963267948966,-61.96039457206055 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark06(-1.1938638812017013,-37.85795619814674,-64.41569271227054 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark06(-1.1947963131954538,-45.3040319666008,97.04488045655935 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark06(-1.195009652404288,-0.036233256982148854,48.36506787867891 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark06(-1.1957279587926715,-0.7050842405352995,-5.317822932049438 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark06(-1.1966029346123914,-0.9557738876965851,-1.431619855771092 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark06(-1.1983898167259919,-1.5707963258160582,-1.5707963267948966 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark06(-1.1984668883090421,-3.4247021078256297E-195,-58.509320216755114 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark06(-1.1985271748256299,-0.007959044294514562,21.803407829842026 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark06(-1.1992610185886836,-1.3980313305595011,0.4815679185754581 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark06(-1.1999728979852187,-1.5707963267948966,-342.43355202223637 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark06(-1.2009484729561883,-88.51324895660925,0.5696454032220195 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark06(-1.2013433189641358,-37.77720174210261,-4.142172250978446 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark06(-1.2015761346353284,-31.53272451203087,-1.5707963267948983 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark06(-1.2020136261516878,-101.98927041185439,-7.857523228031437 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark06(-1.202948718137863,-1.5707963267948966,-11.567471840396875 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark06(-1.2037062152420224E-35,-0.22911650564735464,51.48106654841957 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark06(-1.2037406177582197,-1.5707962921055714,32.80596866205144 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark06(-1.2055429917691542,-100.73713168443977,-10.641413214933676 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark06(-1.2059401435681543,-1.5707963267948948,17.356223607763766 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark06(-1.2059749774424473,-1.505257662249491,-55.49103707465693 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark06(-1.2070806821907532,-6.938893903907228E-18,-38.77551196625038 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark06(-1.2079399404190942,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark06(-1.2084297829267037,-1.5707963267948966,1.6135737945277597 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark06(-1.2087760616176386,-0.3115451414188901,-3.1415926535897967 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark06(-1.2099200964357322,-164.37473052884658,58.87500979608059 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark06(-1.2099289326953162,-1.227044820835376,32.8408927998253 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark06(-1.210312722469837,-1.5707963267948983,113.05047382605593 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark06(-1.2104269047553675,-0.25887125590249416,-0.3791751323721849 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark06(-1.2106915817392256,-0.5705432017061655,-1.9259299443872359E-34 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark06(-1.2110831736837087,-1.5707963267948966,9.424779868205176 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark06(-1.2111060274443926,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark06(-1.2113813026616973,-0.2272181559446933,-48.47462596165698 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark06(-1.212349036233633E-4,90.14605222063271,100.0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark06(-1.2130193772392812,-1.5707963267948966,-5.19708638124538 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark06(-1.2130618908687858,-88.1816895014691,-27.03158786307624 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark06(-1.213673273960779,-1.5707963267948966,0.4382560542925808 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark06(-1.2137887133138299,-3.1415926535897936,40.550965518302434 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark06(-1.2146474325385794,-157.08211206733864,-285.87947194706294 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark06(-1.2146548302868467,-0.1895846345964706,1.570796326794896 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark06(-1.2151455752749816,14.429207399920578,0.42565187589074743 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark06(-1.21518270605128,-1.4455399369338195,44.759631672081724 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark06(-1.2154326714572542E-63,-0.3421494317909045,-72.69046841171956 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark06(-1.215503399376754,-1.5707963267948892,-62.49721920202964 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark06(-1.2160869733518433,-1.5130082311654964,44.00059322307598 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark06(-1.2166986024289023E-209,-1.4480977100668213,-37.76852582047078 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark06(-1.2166986024289023E-209,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark06(-1.2166986024289023E-209,-1.5707963267948966,40.751040293504616 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark06(-1.216919296223578,-37.85701754078881,-1.5707963267948966 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark06(-1.216941662285599,-0.9082758699545245,0.0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark06(-1.2169419715491325,4.4979263812009243E-4,-20.234056940994623 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark06(-1.2190640647643844,6.462348535570529E-27,88.20937764510023 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark06(-1.2193494651085095,-0.745165800763004,1.5707963267948963 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark06(-1.2194280319047006,-0.19815547596107144,-89.61845656000538 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark06(1.2196099686894877,0.8121270136695465,59.484560946028665 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark06(-1.2196128757664737,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark06(-1.221709671149735,-0.0011605313908518836,5.978902467471023 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark06(1.2218516436732203E-20,-1.5707963267948966,2.42416098655983 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark06(-1.2219745453998419E-150,-1.5707963267948966,69.2636407319072 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark06(-1.2219745453998419E-150,-32.75533397467974,0.0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark06(-1.222977639331116,-2.7755575615628914E-17,-1.5717728900715688 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark06(-1.2235691049640758,-3.552713678800501E-15,20.68380692477553 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark06(-1.2236275093671996,-0.5758183062560107,48.35126932007344 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark06(-1.22411579914964,-39.102707891849235,-52.310758725431114 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark06(-1.2262692835424167,-0.04104560134923718,1.5707963267948983 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark06(-1.2271902001289794,-1.5707963267948966,1.570796326794895 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark06(-1.2274767596811997,-44.24028781789259,-104.2385907406576 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark06(-1.2283314494235524,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark06(-1.2300511939048602,-38.79384885914121,-9.995583174781062 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark06(-1.230364639872815,-19.350879700602952,-21.151573757476477 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark06(-1.2311778565249796,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark06(-1.231200549540361,-31.86177520939816,20.728335143161672 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark06(-1.2325668500493232,-100.55273050746015,-84.70943510495448 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark06(-1.2331909557330441E-6,-32.98057328369765,-97.43510399557853 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark06(-1.2334386099319916,-38.86017121382068,-0.00825294101395258 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark06(-1.2334486627943875,-100.57185336596754,-244.9115013009648 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark06(-1.2336391943495464,-1.5707963267948966,37.292185477814996 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark06(-1.234475606438222,-0.20019277242543865,-45.553093476815874 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark06(-1.2346766060809644,14.434651249778,47.70937724620505 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark06(-1.2348338633232276,-1.5707963267948983,40.21531788533406 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark06(-1.2348441822115501,-44.49438036050497,3.606632272572553E-130 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark06(-1.2351705094907899,-1.5707963267948966,79.37530557466147 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark06(-1.2358131716980343,-3.1415926536933294,-84.66250795468328 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark06(-1.236753954555072E-13,-88.38756720973737,-1.5707963267948983 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark06(-1.2369793652518117,-101.60570841907729,-4.448041226111137 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark06(-1.2375715177469622,-31.698735335519686,-70.31380414313901 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark06(-1.2391295797648438,-1.5707963267948966,0.5753489890468545 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark06(-1.2396169004923767,-38.94597845974825,39.99949929081782 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark06(-1.2410503641437278,-0.6967682742415916,-1.5707963267950105 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark06(-1.2416644937469885,-0.0036322846294325473,482.5284741836225 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark06(-1.2418350894684522,-45.25745492162045,-94.68472317412424 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark06(-1.2419307317194578E-5,-45.553080633569266,65.9548445920875 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark06(-1.2424484765685073,-1.2374213784443844,-45.348889350734716 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark06(-1.2429323031162058E-17,-1.5707963267948966,-48.71752458045893 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark06(-1.243472313505902,-45.14252060985303,-1.571193983003337 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark06(-1.2435448988722984,-0.2997889296504634,-5.114349440380916 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark06(-1.243709647806041,-1.4908571478567414,-88.36052478656029 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark06(-1.2440073739483688,6.712389012013806,89.70650027785459 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark06(-1.244090459965833,-32.591974056425116,1.5707963267948966 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark06(-1.2442708025407967,-284.3071659251331,-1.5872020679538845 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark06(-1.244842520861369,-1.5707963267948983,401.50821687672595 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark06(-1.2449779807073664,-0.2385243909103849,1.570796326794893 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark06(-1.2463756965257362,-44.01501259500888,-137.7621838952141 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark06(-1.2467153848477233,-88.32758294975487,83.55881111599152 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark06(-1.2476019554488469,2.465190328815662E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark06(1.2480328012450375,16.958710917027414,1.5707963267948963 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark06(-1.248186776706599,-1.5707963267948966,84.47757971022858 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark06(-1.2486701485916072,-1.5707963267948983,-90.70263289960425 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark06(-1.2488291683266657,-1.4450967011784104,34.64734954580734 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark06(-1.2494412187909507,-1.5707963267948966,78.89736526252398 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark06(-1.2497068064862573,-37.82452494553085,0.0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark06(-1.2498799930774211,-0.23185815738560264,73.19197129483561 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark06(-1.2499173529713878,-1.0707415909123135,4.837388982288638 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark06(-1.250188476534133,-0.2711216359806498,8.065101947414242 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark06(-1.2505485001598338,-3.895593333674503E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark06(-1.2510568459369538,-0.01575200766245366,21.375396567639598 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark06(-1.2511329315334785,-0.3734665565764987,4.712414155688664 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark06(-1.2511611530678828,-1.5707963267948983,5.378204896391028 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark06(-1.2512115822337386,-100.80516792508851,1.5707963267949054 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark06(-1.2513019344894381E-147,-95.35417388319065,69.45876382728763 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark06(-1.2515474650895373,-39.15518864085913,-77.147261294094 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark06(-1.2520320461205472,-1.5707963267948966,-87.10611483839834 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark06(-1.2527295347417602,-1.5707963267948966,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark06(-1.2535812238100557,-37.88863293227527,-3.2665926997784474 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark06(-1.254315284195171,-1.5707963267948966,51.51316000990775 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark06(-1.2549322954195177,-5.803747240565071E-16,-0.816554518754796 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark06(-1.2558540453444906,-0.06598931898411173,0.0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark06(-1.2565914586638804,-0.22066455971971322,-56.39010738597334 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark06(-1.2577611736585226,-1.5707963267948966,4.21820506625629 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark06(-1.2585221353211133,-1.5707963267948966,3.1415891479831077 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark06(-1.2589329137820922,-1.5707963267948966,4.26642320681254 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark06(-1.2590908972419657,2.465190328815662E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark06(-1.2591380323066184,-1.5707963267948966,27.044508905760704 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark06(-1.2602028150141806,-1.5707963267948966,4.712635503977882 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark06(-1.2609728314302195,-1.2583343451840978,43.477603404591335 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark06(-1.261578181536105,-7.352570985549728E-4,37.83213880533293 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark06(-1.2617690040976584,-44.3873496700425,53.368942414469124 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark06(-1.2621774483536189E-29,-1.5707963267948966,-28.27433391123943 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark06(-1.2623226258834201,-1.0129373766146204,-10.623933810517077 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark06(-1.2628036870704216,-1.5707963267948966,17.822302547733077 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark06(-1.2632674426070465,-37.69911184307752,-29.81459786643317 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark06(-1.266248127467493,6.712389044449097,-94.98473341691086 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark06(-1.2673779727166237,-1.5023155772327532,-91.10618858069382 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark06(-1.267685666087283,-0.22009361337421818,3.1415926409502952 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark06(-1.2680455517267788,-0.1146169280991034,-57.37620818779222 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark06(-1.268048971750427,-44.47632284729602,-101.35209581652454 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark06(-1.2681216776742676,1.7414398020912472,29.897374791697445 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark06(-1.2681802838792107,2.465190328815662E-32,100.0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark06(-1.2684094697722974,-3.2036562480593E-15,49.96511193896015 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark06(-1.2686953458877929E-15,-95.52129378073889,-1.5707963267948966 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark06(-1.2687574628604317,-0.014334723510464054,-0.6819606358393602 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark06(-1.2692773380331288,-1.5707963267948966,99.6003476579422 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark06(-1.2700273099370457E-5,-38.85053756951653,4.5719495651291E-100 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark06(-1.2701312380781982,0.02726215814764854,1.5707963267948983 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark06(-1.2703307085253588,7.853981261430597,-3.4111330550079515 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark06(-1.270840445631785,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark06(-1.2718162047556347,-32.9266020073888,1.5707963267948983 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark06(-1.2719032525535579,-0.6766581973335306,63.239897828586166 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark06(-1.2721562368881227,-101.67417725301019,-75.87051485690353 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark06(-12.723291741340176,-18.188016365197896,30.200354902925994 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark06(-1.2723467705616456,-0.7959791830369164,125.26614602651601 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark06(-1.2725358126040744,-39.19432429055364,-1.5707963270673655 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark06(-1.2738220589461138,-95.68407667464085,-9.424809686755813 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark06(-1.2743019377784606,-27.893110227526503,1.5707963267949054 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark06(-1.2753193945006072,-0.23511708994174366,26.272052868097134 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark06(-1.2755513438750514,-1.5707963267948966,28.088577619844518 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark06(-1.2758000153280433,-1.2251285648376833,-1.5708115903350184 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark06(-1.276253406475769,-88.09832196187232,-517.7884864706549 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark06(-1.2763873354452075,-1.5707963267948966,5.635362925894614E-132 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark06(-1.2765817109655515,-1.5707963267948983,-129.89567218591992 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark06(-1.2768212133764565,-1.5707963267948963,44.94271865278925 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark06(-1.277034897122939,-1.5707963267948983,-1.5707963267949019 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark06(-1.2774752723029739,-31.4159265360724,-67.46661982917902 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark06(-1.277765834032735,-1.5777218104420236E-30,-122.59456146636082 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark06(-1.2778045734802295,-0.7488780567738813,-72.07029755920856 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark06(-1.2792597610595653,-1.0269392223770046,1.1851495363739597E-15 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark06(-1.2797551531516693,6.774209464399084,-39.69270241655284 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark06(-1.2797589766442434,-37.89545086595743,121.97021993873426 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark06(1.2803744737241096,79.8180621283786,0.7691948953710915 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark06(-1.2804190871289747,-95.35166737828068,39.967867935230345 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark06(-1.2804791503294808,14.431551146782347,1.5707963267948912 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark06(-1.2808551804780604,6.712388980397068,65.75900606678887 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark06(-1.2812499820011307,-0.06533637455309904,-3.141592653589793 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark06(-1.2813331809171846E-144,-1.5707963267948912,-1.6511467327544835 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark06(-1.2814266266522565,-0.4385738966424779,-39.6514875117755 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark06(-1.2815791795614885E-9,-39.26990812606076,-65.96855389178518 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark06(-1.2816862739332524,14.429203696816003,1.5707963267948966 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark06(-1.2826234270716887,-1.5707963267948983,925.1781625288352 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark06(-1.283185162744152,-0.21425563592826524,-116.82563763662768 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark06(-1.283412614044131,-0.06413512606212257,3.1415926535897896 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark06(-1.2836252941769057,-45.26871236395983,-39.68161291149416 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark06(-1.2838637251567302,-1.5707963267948966,30.226581250341535 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark06(-1.2844175679652403,-1.2517625012365716,4.7216052551236665 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark06(-1.284692287607263,-1.0474852713549136,-78.90972579624892 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark06(-1.285613197618522,-1.5707963267948966,2.0835290656743233 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark06(-1.285800435071815,-1.5707963267948966,-72.49932246361026 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark06(12.859575887101471,-19.203027656395406,55.429559930186684 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark06(-1.2859971314771197,-1.5108708548477106,-8.254850984713203 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark06(-1.2865194037609435,-32.67258524351391,-11.924422800098037 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark06(-1.286585757588202,-31.41592682315801,0.6362884299461948 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark06(-1.2867102073191488,-1.5707963267949019,-10.52940493327322 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark06(-1.2868838913203537,-0.3281421011661465,1.5707963267948966 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark06(-1.2876754005601454,-1.570796326794891,-15.734909544493956 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark06(-1.2880294231407545,-1.570796326314743,52.01631707431215 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark06(-1.288463482571001,-1.5707963267948966,-639.811755337392 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark06(-1.2886983615967815,-1.5707963267948966,63.92625723316743 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark06(-1.2889367660186126,-1.5707963267948966,5.880072919305674E-16 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark06(-1.289044096640223,-0.22482769132651426,100.0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark06(-1.2892560879332773,-1.5707963267948966,-52.88142941163031 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark06(-1.2893744740344237,-1.5707963267948966,-52.46684961571083 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark06(-1.2896050696857275,-164.40740240715107,-30.073503116930226 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark06(-1.2896970087229185,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark06(-1.289795836265882,-0.35888572111373374,2.507852493929917 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark06(-1.2898089304239824,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark06(-1.2898154434635143,-1.5707963267948966,-4.743639831525216 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark06(-1.2900569173769183,25.132759799683665,-123.81300165287021 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark06(-1.2907216761564615,-1.5707963267948917,1.5707963267948966 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark06(-1.2909251597013534,-1.235769207012919,-54.41878190578045 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark06(-1.2910064428250378,-44.20734559539709,-739.0818261245464 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark06(-1.291584020331597,-31.44028695747294,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark06(1.2924697071141057E-26,-1.5707963267948966,-49.874794784400606 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark06(-1.2934408077506845,-1.5707963267948912,32.469410773731965 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark06(-1.29372561255455,-1.5707963267948966,-36.70794825910928 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark06(-1.293752240957519,-283.8181969033197,-3.1415926535897896 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark06(-1.2940694934785784,-227.4509185316592,-60.14382951452399 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark06(-1.2946412159865044,-1.5121257935224763,20.43878659340818 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark06(-1.2953987530967628,1.734723475976807E-18,0.9269526673004544 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark06(-1.2954427796552528,-0.9227600940971741,23.01898696530489 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark06(-1.2961342045654038,-1.4421989709087335,-57.60095033187884 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark06(-1.2962333992668045,-0.8524108530738488,-1.5707963267948966 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark06(-1.296491582215013,-39.05197020235363,-1.5707963267948966 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark06(-1.297766159952232,-1.5707963267948966,-64.62033544391284 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark06(-1.2986288413852374,-1.570796326794894,-145.05738393719236 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark06(12.991297476859344,-40.7919490574725,-66.31066606891585 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark06(-1.2991623651620154,-45.164527438937334,-73.96248569686374 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark06(-1.2994262207056124E-113,-0.5139368629647612,-0.8528220268921727 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark06(-1.2994262207056124E-113,-1.5707963267948966,-88.4125075512165 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark06(-1.3014776140147923,-0.9318332355114292,10.919171642421722 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark06(-1.3021854344282946,-0.006597269356123037,0.0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark06(-1.302472648788222,-32.74287278618078,-89.18121800185847 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark06(-1.3036592996649286,0.3548663546487999,63.27916891598993 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark06(-1.3039932850067162,-0.5046820005078508,29.204859031544828 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark06(-1.30507239994593,-38.87197276031269,1.515965103006846 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark06(-1.305431708130875,-163.5815096251615,-1.5707957916029873 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark06(-1.3056529008330977,-1.279771165108778,3.141592653589811 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark06(-1.3067772474234518,-45.07258905299039,-2.3055835075199433 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark06(-1.307624149208177,-1.5707963267948966,97.84443943860128 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark06(-1.307800210606704,-1.1929858903716566,-71.4800006522997 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark06(-1.3078187797514012,-32.89096491926145,648.869043503027 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark06(-1.3088379195590814,-88.3283511867488,-1.2680363930029994 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark06(1.3097762821624528E-10,-88.09688539860203,-123.73917966651439 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark06(-1.3097978442798528,6.712388980389075,-29.937617916375714 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark06(-1.3102095626058332,-1.5707963267948912,-4.383077415204895 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark06(-1.3103668160668747,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark06(-1.3107703627088299,-84.50123595311834,1.5707963267948974 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark06(-1.3144423100275626E-7,-39.26968108818278,-40.84132726709359 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark06(-1.3152359047112754,-0.08031349287157874,-186.48137583537962 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark06(-1.3160631028395284,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark06(-1.316806717801251,-88.17207342630991,0.0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark06(-1.3172531660885127,-0.14665254523879412,-46.95535295891373 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark06(-1.317549442317734,-0.33205992208109,4.444183066408 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark06(-1.3177747429038154E-82,-0.620804693527126,62.974577260317176 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark06(-1.3179450085429736,-1.5707963267948966,-50.597555691577064 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark06(-1.3183855866837029,-0.19438192979593136,-0.789192523668908 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark06(-1.3186839882370385,-1.5707963236617548,24.645167940727884 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark06(-1.3197578736356637,-1.122338114767367,4.246355402415745 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark06(-1.320356096267019,-1.5707963267948966,-33.7599500651613 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark06(-1.3208849173004564,-38.81593374015773,-91.28229325950983 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark06(-1.3213061518790228,-32.94535957691163,-4.71441563199822 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark06(-1.3220045264927076,-1.5707963267948988,1.252670246354886 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark06(-1.322006207600879,-3.1861838222649046E-58,0.0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark06(-1.3232227338938856,-213.74612500227778,-3.2666946747079777 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark06(-1.3232976593434445,-19.40901124338648,-3.266592981572739 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark06(-1.323319783182049,-100.53096531958367,-10.849953225931163 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark06(-1.3238344685910695,-32.734296801340314,1.0604607791116434 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark06(-1.3242153046244987,-158.38382434888274,-19.20127114438243 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark06(-13.246191334997832,-14.009215444529175,-11.341242472035447 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark06(-1.324801623504472,-1.5707963267949,1.5707902982618251 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark06(-1.3251153430153895,5.421010862427522E-20,-34.501918488172045 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark06(-1.3251434847549375,-1.5707963267948966,-11.75104549918079 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark06(-1.3252262013827618,-88.48171423757462,-49.60398305015602 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark06(-1.3253120930071134,-0.28347465147829093,0.0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark06(-1.3267708982648134,-31.41592653589793,-67.02520407382156 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark06(-1.326890584014218,-1.5707963267948966,7.58767866271549 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark06(-1.3270574879108827,-37.933977325581544,-1.5747028631315223 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark06(-1.3282585545460537,-37.835977136466866,-13.704458632523187 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark06(-1.32926310884447,-88.24981532469562,-59.15589648155832 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark06(-1.3295510542828106,-1.5707963267948966,19.419959764829418 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark06(-1.3297329254612071,-45.49992458840826,-3.141592653589793 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark06(-1.3298774779806313,-95.2554489488843,-1.5707963267948912 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark06(-1.330440419668694,-31.559883156205082,-9.906154897009948 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark06(-1.330965234617555,-1.5707963267948966,-28.274578022933472 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark06(-1.3309664785572541,2.1175823681357508E-22,0.0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark06(-1.331176604293036,-37.69911184307752,-66.38691154051554 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark06(-1.3311979991360092,-1.5707963267948966,-10.47441956120615 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark06(-1.3316110711457831,-6.420118221951753E-14,3.266592654697469 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark06(13.317954481690947,6.6596650864108256,-54.21895908792804 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark06(-1.3320791475782698,-31.892629682442866,-56.420333657175874 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark06(-1.3321651641783485,-0.43032154035706816,240.571715483304 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark06(-1.332926920462695,-0.010689698294881613,-31.652078433807006 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark06(-1.3334833851933356,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark06(-1.3339339057390147,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark06(-1.3340470738440429,-37.72437838405073,-66.25242694939102 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark06(-1.334193683731702,-1.4759320421663138,1.5707963267948983 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark06(-1.3349754669521487,-88.34137810172572,-64.191530029176 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark06(-1.335085303131521,-31.416027702020752,-50.63507053095297 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark06(-1.3353682811194654,-6.811065871352291E-4,1.232595164407831E-32 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark06(-1.3354833592865036,-1.214151998824116,-1.5707963267948966 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark06(-1.3363243004276961,6.712388980711719,-10.099465405699135 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark06(-1.3365278614043332,-1.2864247639554014,-1.3646000938125975 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark06(-1.3371925692820414,-38.95815241996152,3.469446951953614E-18 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark06(-1.338256914672148,-95.81855705795999,1.5707963268046972 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark06(-1.339283440579759,-1.5707963267948968,4.743638980384691 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark06(-1.3392849609479671,-0.846379056522576,-61.069560765517885 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark06(-1.3396660338820476,-0.73779155797399,4.712397417924955 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark06(-1.3398402631031412,-44.518764328654434,-46.39248816651529 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark06(-1.3401054976707965,-1.5707963267948966,-3.1415926730759 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark06(-1.3406287947358302,-1.4151235885890827,-137.6533954226835 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark06(-1.3412577683184561,-1.5707963267948966,0.2547962379274357 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark06(-1.3414222501736113,-1.5707963267948966,42.36245463607348 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark06(-1.3415652246446352E-16,-1.5707963267948966,36.128315871088624 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark06(-1.3416654470864924,-1.5707963267948966,-49.14942416963421 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark06(-1.3417015823116736,14.429314607092984,-30.661327901496534 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark06(-1.3420231866825447,-0.2972393772736277,1.05898996566996 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark06(-1.3424522227411502,-45.369058195593404,-1.570796253923509 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark06(-1.3437991401901206,-102.00298726236521,6.712393129636752 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark06(-1.3438221096364158,-0.08734118281261222,60.667680394712626 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark06(-1.34393827742606,-1.570796326794895,146.320318205229 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark06(-1.344959630240738,-1.5602432436226725,-100.0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark06(-1.3462429883345066,-1.5707963267948966,-64.43219505401122 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark06(-1.3471704806804021,-1.5707963267948966,23.869933268187985 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark06(-1.3474358954655627,-1.5707963267948966,43.821301737413584 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark06(-13.476897843029121,99.11545846671919,48.255013789151946 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark06(-1.3479570667106042,-1.5707963267948966,71.29862330553051 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark06(-1.3482387862411342,-37.89287313895178,0.11645344861349827 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark06(-1.3488519943972819,-39.1028334046804,-99.95775867598948 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark06(-1.3494617911181783,-158.25242295106048,-65.64369776157642 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark06(-1.3499274244010433,-0.5632584315356084,-67.77732194234184 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark06(-1.3499329900610189,-31.41592653589793,-9.835337486899453 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark06(-1.3499650975894022,-1.5707963267948966,-67.77323030387892 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark06(-1.3501579158596329,-38.93406852896574,-4.192614178567235 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark06(-1.3504429075813444,-0.8172201748631842,1.934706344267056 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508023046046056,-1.0321354472021937,0.7973897003307862 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508408370101348,-39.15288470543515,-688.5540647071641 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508887953521298,-0.40010779129499874,42.36319236399564 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark06(-1.3508974208233155,-39.16374666309863,-498.8370619547324 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark06(-1.3510303156860721,-32.66053139328761,-3.1415926535897953 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark06(-1.3514763609242806,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark06(-1.3520464424274625,-45.1200257435429,1.5707963267948954 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark06(-1.3535781244725715,-32.70775658575738,0.0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark06(-1.353767611679209,-1.2166986024289023E-209,39.34829244748347 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark06(-1.3538208242740957,-0.002311653038508504,1.5707963267948966 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark06(-1.3538299356302885,-4.930380657631324E-32,1.570796326794898 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark06(-1.3541561035944967,6.811126432783222,-112.60743238338031 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark06(-13.54755115032556,-21.546153650697008,99.70954648707749 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark06(-1.354851379719128,-1.490737690927847,97.06303017842214 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-1.5707951230351767,72.25595766067124 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,-1.5707963267948966,1.6158501275431838E-15 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-32.9867228578329,65.97093210951077 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark06(-1.3552527156068805E-20,-38.787525406853675,0.2756818096736152 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark06(1.3552527156068805E-20,6.480910148999254,63.10926661800019 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark06(-1.3560497200429458,9.802643474716742,17.44907304101846 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark06(-1.3560718932130982,-2.7755575615628914E-17,99.62971411271425 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark06(-1.3566718925852523,-1.5707963267948966,64.97847503104181 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark06(-1.35688035902762,0.08641814663438556,1.5707963267948966 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark06(-1.3568931572901342,-45.38512898723697,-1.5707963123214277 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark06(-1.3571847683970593,-1.174022035605175,58.39695246832568 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark06(-1.3577843858302856,-44.100516602277075,-3.292326273403716 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark06(-1.3580930086345782,-39.1296383502811,-1.0330008378172977 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark06(-1.3581731940483595,-1.5707963267948966,-15.592070340054256 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark06(-1.3584064935335898,-1.5707963267949019,-37.819758178281205 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark06(-1.3589457577960948,-0.431311187807098,-27.029243535819027 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark06(-1.3606481190622457,-3.141592653595058,-88.27821221393071 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark06(-1.3606769772665679,-1.5707963267948948,-1.5707963267948983 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark06(-1.3610332291999794,-1.5707963267948966,2.130851734226887 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark06(-1.3613760471750258,-0.19251330942702366,-6.903216437125664 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark06(-1.3616211535068923,-32.56319558824196,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark06(-1.3617543237775784,-1.5707963267948948,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark06(-1.3619097381785124,-6.938893903907228E-18,39.11777530085931 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark06(-1.3625696538509797,-101.63765955214268,-0.9389541900874939 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark06(-1.3629592044724248,-45.120418320302115,-85.65277878926263 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark06(-1.364130769547165,-0.2259043459736614,-2376.7940921534387 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark06(-1.364498875118361,-31.971408105323356,0.1596177763769776 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark06(-1.3648016207784732,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark06(-1.365405381885695,6.712388980437248,-39.183063103847026 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark06(-1.3660703727080232,-44.50924890531624,-9.981029644524781 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark06(-1.36691563731796,-1.5707963267948966,-49.97124696587295 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark06(-1.3670105367716514,-84.5851434518962,-1.5707963253985768 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark06(-1.36765482044119,-0.9088803437162127,-70.71079115780245 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark06(-1.3684116526165777,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark06(-1.3684467913124032,-1.5707963267948966,15.812202915996636 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark06(-1.3685767452693876,-95.57086272615692,317.2730798908995 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark06(-1.369264973659791,-0.5345574639312893,-1.5707963267948966 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark06(-1.3697293257560128,-31.438365695187514,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark06(-1.3701852750636299,-44.98251571621811,46.14390286186789 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark06(-1.370316976390067,-20.513235966170164,-1.5707963267948974 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark06(-1.3720561182503754,-0.018489748802820793,-41.17010338921773 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark06(-1.3727473076949137,-0.2189840667227818,169.56115332298964 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark06(-1.3732273282548946,-1.5707963267948966,-1.6332963302308428 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark06(-1.374208759691291,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark06(-1.3742708729137465,-1.5707963267948966,-51.749145749666084 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark06(-1.3743858677100327,-1.5707963267948966,-4.7143421059270905 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark06(-1.3744373417105669,-1.5707963267948966,97.42116273478068 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark06(-1.37444673575144,1.5707963267948806,14.919158768361825 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark06(-1.3744928109476595,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark06(-1.374543123787382,-0.04869798250310803,75.82313112629862 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark06(-1.3748143670539947,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark06(-1.3752098067506189,-94.26035611659567,-3.141592922095889 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark06(-1.3757748119977644,-1.5707963267948966,-78.11713850941855 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark06(-1.3766003005083391,-1.5707963265658373,38.4186684014552 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark06(-1.3768556895500463,-0.44846721834554515,-44.032132259356445 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark06(-1.3768877755403996,-0.30028121456570034,38.86703156563868 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark06(-1.377144140087206,-0.25360076084560446,48.59337975405114 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark06(-1.3771653642518151,-1.2774710179436803,1.3479845172516889 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark06(-1.377478070714832,-77.20575288237409,-9.825738987544756 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark06(-1.377494949395134,-31.90063191463878,90.65960601575213 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark06(-1.3775838021815126,1.3877787807814457E-17,-57.960456954812045 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark06(-1.3778963723268736,-3.1415926535897944,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark06(-1.378622497323991,-0.10469924623315408,34.66880501251089 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark06(-1.378812486503413,-1.21194053738121,-21.5214528169156 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark06(-1.3792688149576147,-1.0675804917333656,-59.22368905963644 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark06(-1.380477220031498,-1.5707963267948966,-25.027625692394643 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark06(-1.3814880410766912,-0.5047894958677782,-85.10567472343125 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark06(-1.381500771514264,-45.29266184522458,-130.6917268121125 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark06(-1.3819027684326533,-32.50026273409246,115.40494352881922 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark06(-1.382357073154747,-1.0598578643905363,-3.1415926535897967 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark06(-1.3823904867849959,-0.38670932538111913,1.5710455387002507 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark06(-1.3832658633896109,-0.5706331598296349,1.5707963267948912 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark06(-1.3837896105481793E-5,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark06(-1.3842945676242737,-1.4614214513616313,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark06(-1.385680341446543,-1.5707963267948966,84.2556250703712 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark06(-1.3862011091971786,-1.5707963267948963,-80.91152594169215 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark06(-1.386834880217748,-101.72657723942756,-107.98528548658653 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark06(-1.3868506914225454,-0.39467175375480273,24.81967066039769 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark06(-1.3872083253568157,-1.5707963267948966,23.166741819870268 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.3261707121475497,61.63384329682682 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,14.430626423184052,1.5707963267948912 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963251200927,45.55307040934986 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,122.51082281187705 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-1.5707963267948966,-1.5707963342899434 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-1.5707963267948966,95.3124958554327 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,3.5213037318941125,0.0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877787807814457E-17,-38.8533051634199,-46.98386769845257 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark06(1.3877787807814457E-17,-95.47164053115056,1.5707963267948966 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark06(-1.3877810163811928E-17,-32.9867212556033,3.1413445313436354 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark06(-1.3879073940080118,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark06(-1.3884613373165682,-32.88254412696524,-33.2714754486796 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark06(-1.3889197051599869,-1.5707963267948966,56.35011157329435 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark06(-1.3889510900777569,-0.9556923512843041,-88.13252851747355 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark06(-1.3892242184281734E-163,-32.60623227073927,-55.27388609423793 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark06(-1.390211969635415E-4,-39.26644537093397,-1.5707963267948974 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark06(-1.3903699361288615,-84.58522893287848,71.3498240114945 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark06(-1.3910038551562978E-15,-88.29263985891717,-3.6775352248649114 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark06(-1.3916592544625284,-1.4714558641745188,-72.32700302242112 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark06(-1.3916681889572673,-1.5707963267948966,-5.611031933461512E-191 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark06(-1.3923189923644785,1.9721522630525295E-31,-11.146139285795803 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark06(-1.3938416569682675,-88.52641769192418,-1.5707963267948966 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark06(-1.3942803482916932,-39.19909829811729,-14.48859487243513 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark06(-1.3945699477651896,-0.9321523905169321,43.84766472297477 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark06(-1.3948536499967952,-227.62546424704513,-67.7937471495031 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark06(-1.39512364220015,-0.4978851016778639,93.2092245457696 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark06(-1.3954408799400118,-1.4020695813055062,-4.7123889964335985 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark06(-1.3961333265906322,-37.72138792516661,-10.474006207391394 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark06(-1.3964573478019795,6.7123889804248265,-26.432431814096834 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark06(-1.3965546424645565,37.94911184308422,-65.98348171233921 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark06(-1.3971754544299946,-1.5707963265551177,-10.865906574941217 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark06(-1.397811496711749,-1.5707963267948966,-95.52662674305505 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark06(-13.980834254865869,-12.044032915191607,87.06504245045278 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark06(-1.399955536804764,-163.7185822840409,-3.2666026437135454 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark06(14.009723545168868,-82.49857122943753,6.345999979780174 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark06(-1.4016849654455568,-32.47798830353441,2.710505431213761E-20 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark06(-1.4026371084328608,-1.5615829475481169,72.4732345320567 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark06(-1.4033100336492463,-1.3554272090770425,-59.20354813303012 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark06(-1.4039014683169966,-1.5707963267948966,-73.53785280145453 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark06(-1.4042520526646807,-1.5707963267948966,-62.823891210381845 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark06(-1.4044321445319998,-88.11985844852445,-1.5707963267948983 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark06(-1.405307174191538E-16,-0.25418097319130695,-48.34485022792951 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark06(-1.406373332556457,-88.40418397609123,-10.242484860252457 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark06(-1.4065958567048862,-45.41180659985718,-8.624684603105266 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark06(-1.4076794762477824,-0.4164876892706688,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark06(-1.4095799448564799,-1.5707963267948966,-75.25341450508111 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark06(-1.4099175785946283,-0.4734523718062108,64.28572740083847 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark06(-1.4102561251645451,-0.6669971483062629,-7.876914642544538 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark06(-1.411497053908005,-95.79500476258194,-13.723896506841777 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark06(-1.4116172790628594,-20.596800598521376,-14.121920515188478 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark06(-1.412606239069192,-0.5913067495997084,-1.5707963267948983 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark06(-1.4137456196316492E-14,-1.5707963267948966,-94.33292785545324 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark06(-1.4145495038351363,-0.267284484993128,65.11259720273884 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark06(-1.4150480602574607,-1.5707963267948966,-34.28851666526724 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark06(-1.4165806093702964,-100.64997246255479,-4.7241117325697015 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark06(-1.4168623037374437,-1.5707963267948966,-85.35824897759524 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark06(-1.4172940123771218,-39.23227589249922,-1.6332963643452878 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark06(-1.417328197014263E-5,67.42213131285072,100.0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark06(-1.417569060688777,-226.5225964120474,-73.48529167902869 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark06(-1.4177706821810094,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark06(-1.4182919815146062,-32.65899110946161,-9.42477796076938 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark06(-1.418784088650606,-0.31235620431760147,-38.03802804234572 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark06(-1.41886557774139E-5,-1.5707963267948948,100.55684520846738 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark06(-1.419592054381818,-44.50381555767922,-6.681911775230489E-52 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark06(-1.4200796725357345,-1.5406043010222383,-1.570796326794898 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark06(1.4201611723277918E-20,-1.5707963267948966,-93.28590967426429 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark06(-1.420250839896064,-19.369872331246835,-0.04329155237388764 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-26.799143528355444,-83.49877136666375 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark06(-1.4210854715202004E-14,-32.63223796436795,1.5707963164851428 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark06(-1.4211155760326988,-1.4463889506519756,-109.95660584662963 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark06(14.219732329068407,-42.46257632847259,-17.908300737659417 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark06(-1.4225655996704496E-160,-1.4144323626848787,-1.5707963267948966 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark06(-1.422823114433863,-1.5707963267948966,50.089528016379255 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark06(-1.423367132838237,-88.14781823271743,-48.42625742911025 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark06(-1.4234407741041535,-0.14494521497568522,6.084517284025168 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark06(-1.424976515243521,-1.0542197943230523E-81,-67.61970789298573 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark06(-1.4252951662365514,-1.570796326794898,-66.18754232389853 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark06(-1.4256166860879576,-164.8627371032939,-5.221369795339724E-9 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark06(-1.4258839811003887,-1.316729180654676,-1.5707963267948966 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark06(-1.4258884168443742,-44.14994204974468,-14.213850679278401 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark06(-1.4259796594825487,-84.78105976063682,-7.8744003293320075 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark06(-1.4262759534027252,-0.4750433207192868,-11.17540669182867 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark06(-1.426305147624311,2.6469779601696886E-23,78.03034605397627 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark06(-1.4270469383724578,-1.5707963267948912,65.65010218262296 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark06(-1.4271490012624668,-1.385379452960385,108.00655250731376 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark06(-1.4271690396753212,-32.71085285171323,1.6335435015026525 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark06(-1.427662557831737,-1.5707963267948966,1.1804402221710184 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark06(-1.4283559725144328,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark06(-1.4289153077500871,-1.5707962988249777,-85.22282155922191 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark06(-1.42896228302955,-0.08671039856726903,-31.900285372463486 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark06(-1.4292742141752774,-0.44409991332728116,559.1148327629356 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark06(-1.429757407085325,-1.1102230246251565E-16,2358.5176014325707 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark06(-1.4303946081800794,-3.1415926535897936,50.50655424120976 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark06(-1.4305164042954392,-1.2291339377378083,641.8421729849141 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark06(-1.430586150923771,-1.5630065039243115,2.070796436294757 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark06(-1.431317742002193,-1.5707963267948966,15.37109266059771 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark06(-1.431371534013756,-1.4594214006458757,-65.71412775238147 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark06(-1.4321060118897684,-45.0273811124646,-66.13112678317334 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark06(-1.4321121065571845,-0.6990713521230415,-2.7971644445321573 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark06(-1.4323434315459849,-1.5707963267948966,-5.185488128905475 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark06(-1.4327751385461627,-2.220446049250313E-16,-3.266592653722829 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark06(-1.4328280792379942,-3.14159265359152,-1.5707963267948966 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark06(-1.4329370504474113,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark06(-1.4340272850123459,6.719555061490963,0.0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark06(-1.4348731550778804,-1.5707963267948963,-752.52492605939 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark06(-1.4349479419054934,-32.95874012022918,0.0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark06(-1.4350764105238907,-1.5707963267948966,-49.9716254786348 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark06(-1.4355614893691353,-94.28377760900581,-1.5707963267948966 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark06(-1.4357197795209566,-44.51265749504719,-14.239082697450595 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark06(-1.436593927689438,-1.4263827588251452,77.16756030758182 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark06(-1.4369173607647623,-44.20355749547093,-77.94987212485294 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark06(-1.4374993877342206,-0.09232625632573171,45.263170451279215 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark06(-1.4376424945202562,1.5707963267948983,-0.277263954554003 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark06(-1.437646686643594,-0.5620990225582968,-0.3383900614162594 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark06(-1.438233270123368,-1.5707963267948948,-85.94355148217775 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark06(-1.4385451217321017,-0.18503105016957788,-20.36317390437542 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark06(-1.4386753995838961,-1.5707963267948966,48.587046335553225 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark06(-1.4387772997347543,-1.5707963267948966,-23.060495123365556 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark06(-1.4389035760105664,-1.5423663937384726,55.65958741602911 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark06(-1.4389627339645903,-0.26879541943559104,71.81798648175543 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark06(-1.4389739610612509,-0.11377897705030104,91.82599367962231 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark06(-1.4391784017968017,-1.5303062889498682,24.87380300478551 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark06(-1.4393602435377202,-1.5707963267948912,84.36282526361933 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark06(-14.393655722018167,79.13107078246958,35.58638890500686 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark06(-1.4399062393175754,-1.0571872205671429,79.9561806570471 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark06(-1.4400988171764686,-94.25461807644902,20.96943292870327 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark06(-1.4402551483775206,-1.5086188725032776,-50.320321025216614 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark06(-1.4402641992537177,-1.5707963263028644,23.189543700053 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark06(-1.440281878733927,-1.5707963267948966,80.12307501956292 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark06(-1.440797733944592,-3.552713678800501E-15,1.5707963267948966 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark06(-1.4414458830521397,-1.2629451882478406,-909.4781963116228 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark06(-1.44205341881694,-1.5707963267948983,49.484414493427124 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark06(-1.4424154198722716,-45.48209203345321,-82.68698995947786 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark06(-1.4426529090290212E-129,-0.0998939199039301,10.082568193238409 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark06(-1.4427195618582083,-39.24945840664474,-3.1415697618631504 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark06(-1.4427917799186187,-1.5707963267948966,-65.42452256884143 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark06(-1.442855343614754,-1.2185259303007936,-11.378370032375111 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark06(14.429204050447268,0.6120220377118596,-34.7518625262631 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark06(14.429204052067305,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark06(14.42920417255229,1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark06(14.42920422154313,1.5707963267948966,66.00117145009774 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark06(14.429204796009977,79.41134622040492,100.0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark06(14.42920682969769,85.02780236582123,100.0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark06(14.42920689385744,17.237087172989217,1.5707963267948966 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark06(14.429209766090736,-0.3085546010025956,-76.34299202927967 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark06(14.429209790295552,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark06(14.429211346276993,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark06(14.42921376654943,1.5707963267948966,91.48176192519531 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark06(14.429215610222315,1.5707963267949054,97.00375731817162 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark06(14.42922974944564,1.1598967427856717,42.19641269679308 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark06(14.429230261516295,71.48936572548311,-0.01086134922066424 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark06(14.429236691464162,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark06(14.42924042742559,10.58085601658735,-1.5707963267948966 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark06(14.429264713544939,-1.5707963267948966,-1.568405754331037 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark06(14.42926619539714,-0.7602072660483857,7.35188827638984 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark06(14.42927721667344,1.475711951440035,-35.669118715031985 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark06(14.429339769605932,0.6884681732629325,-3.9816185072265036 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark06(14.429340473409674,1.5707963267948986,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark06(14.429351239857311,1.5707963267948966,5.049739560143648 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark06(14.429435871930437,0.792257217296104,72.95428931825536 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark06(14.429483306046599,1.5707963267948912,96.07010156681885 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark06(14.429534388986134,71.75514968254625,18.245620968167252 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark06(14.4296443001937,-1.5707963267948966,26.367681822582156 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark06(14.430201219684022,-1.3167255492214724,0.0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark06(14.430245809109344,1.570796326794897,0.0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark06(14.43048433649141,0.0,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark06(14.43072795567948,1.5707963267948966,4.446501671488844 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark06(14.4308294139774,0.7740710723588139,10.88506846383713 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark06(14.430968591464953,-1.5707963267948966,-16.889312912925476 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark06(14.431076652279295,14.224395964045398,1.0859863699245116 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark06(14.431174032017019,1.5707963267949054,1.570796326794899 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark06(14.431698174621296,-1.2529479008491906,1.5707963267948966 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark06(14.431703629581207,100.0,12.83798603023148 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark06(14.431834978499687,1.0573606530929087,45.553093477052 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark06(14.432159609256757,80.26459757873175,0.0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark06(14.432365096926716,4.065998659083809,0.4992896103880225 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark06(14.43253344432977,1.5707963267948966,1.3850408430258911 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark06(14.432659845513363,0.3271617320446702,-137.10716884448485 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark06(14.43288793089166,-0.2211918649693555,0.0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark06(14.432895624095025,1.4648388643431565,45.553093477052 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark06(14.434590716779972,134.82225610241022,76.89533552755148 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark06(14.434685125959845,146.52395792572713,1585.4792497393407 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark06(-1.443545827196425,-1.5707963267948966,2.603539853106755E-15 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark06(14.43885888052688,39.37117661173343,95.52271550305787 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark06(-1.4443032464386194,5.141592653589801,-56.0628706527607 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark06(-1.4443532393759637,-163.68648972549767,1.306142290470348 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark06(-1.4444686923837478,-44.45127356022633,0.0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark06(-1.4444942382189567,-0.06394285140842794,-56.44966136414216 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark06(14.444965182032483,1.570796323292128,-1782.5765645063802 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark06(-1.444644227988009,-31.41977186072052,-4.218562503974098 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark06(14.449432537409542,4.409859071038753,51.40487113006773 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark06(-1.4450184214451518,-95.34213294151643,-23.50743363010767 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark06(-1.4455257102186796,-1.447189836475382,-2.0707965134477866 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark06(-1.445559269113148,-44.05972880458107,-151.2586419281335 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark06(-1.4465183219601034,-1.5707963267948948,-28.218974440393595 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark06(-1.446837066719084,-95.63923461439546,-125.69934232828311 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark06(-1.4475690262565881,-45.26844149485749,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark06(-1.4476486749289795E-5,-1.5707963267948966,72.25240531171694 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark06(-1.4484776037920801,-1.5707963267948517,-3.141592653589793 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark06(-1.4486183970723456,-1.0434178878316724,18.238684602290142 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark06(-1.448820908715011,-1.2984452907058297,-192.91722740316348 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark06(-1.4492315832247697,-0.38378480739955023,180.00218877847885 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark06(-1.4492532344218627,-0.9609150329797346,-36.93598473196989 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark06(-1.44934372343742,-44.49321092733328,-9.717562298682353 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark06(14.49415705539078,96.43469357488434,-100.0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark06(-1.4501801546606927,-88.21817686662804,-85.71985908566475 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark06(-1.4508544541340804,-95.64743774673741,-68.10826780602625 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark06(-1.451067437243991,-1.5707963267948912,110.3799935748504 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark06(-1.4517936234157218,-1.5707963267948966,4.712389935796563 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark06(-1.451931536334554,-164.8835046823046,-5.9297074784404336 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark06(-1.4521369117585792,-94.29051867926226,-3.52478583082043E-16 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark06(14.531308600707924,1.5707963267948966,0.39679518757160315 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark06(-1.4531660994290194,-1.5582015210589892,17.956003026834534 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark06(-1.4534174083059774,-1.278522984379086,26.25430790795728 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark06(-1.4536787196880046,-32.71382513776005,-56.302996916174905 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark06(-1.45459261947868,-20.65145143367016,0.0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark06(-1.4550373299540587,-1.5707963267948912,85.65554058373323 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark06(-1.4555406084714724,-101.73769493243383,-7.972562645545247 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark06(-1.4556064573894616,-0.3410149977994541,-79.85135251947463 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark06(-1.455687556027442,-0.6737220672403819,28.539887774803788 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark06(-1.4558614438128241,-88.43102827709586,-3.141592653589793 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark06(-1.4571739533761559,-102.10029627874802,0.0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark06(-1.4573240822869844,-1.5707963267948966,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark06(-1.4579555724685895,6.712388980385111,0.0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark06(-1.4579900421741556,-9.016580681431383E-131,0.9161836510521191 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark06(-1.458022330193154,-37.937599864422566,-3.1415926750833023 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark06(-1.458227646828977,-158.28027933982483,-73.31991540376083 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark06(14.594626462885259,-100.0,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark06(-1.4597518803264924,-1.3850111976368387,1.570795912582455 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark06(-1.4600943284813368,-2.13947593889409E-15,84.00689477071074 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark06(-1.4601710913708328,-0.05417107092286599,0.0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark06(-1.4604079935625702,-83.44956264835577,-1.5707963267948963 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark06(-1.4608041400060663,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark06(-1.4630524369088442,-1.5707963267948966,93.36645486069494 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark06(-1.4634381818307503,-1.5707963267948966,-8.853981633992346 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark06(-1.4635782955757979,-32.83294849689625,-0.34551096920811575 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark06(-1.4636360798964119,-31.715175800200278,-0.5084925754143851 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark06(14.641294016954575,-54.139689716547146,-21.9297192448622 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark06(-1.4641533271531482,-0.05954179466731691,4.978677532697591 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark06(-1.4642658404958908,-8.086706049300413E-8,167.5672302380015 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark06(-1.464705718584122,-1.5202095922630543,3.1415968579098443 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark06(-1.4651109607201485,-1.5707963267948966,-815.1144102045818 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark06(-1.4652625127957675,-1.33438091268022,93.19310661768361 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark06(-1.4652839982221346,-0.0483137868123525,9.816924595943192 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark06(-1.4664045270732162,-19.36859791749091,0.0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark06(-1.467111235589813,-1.5707963267948966,47.87503624755266 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark06(-1.4675538706107425,-0.24647642317338014,-1.5707963267949197 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark06(-1.4677580770945156,-44.38708960019724,-90.51985350268276 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark06(-1.4680365859002706,-3.141592653590946,-18.921596030754614 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark06(-1.4682314617864682,3.3881317890172014E-21,72.73704803127093 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark06(-1.4684328867663257,-32.78634396335248,69.32424169868415 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark06(-1.4684815887907385,-1.278984987074172,55.455698565586516 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark06(-1.4686139777863632,-0.32854019224921893,18.40506598219362 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark06(-1.4686922012882277,-1.5707963267948983,-62.59407689539292 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark06(-1.468997548472556,-0.5287213473676222,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark06(-1.4690924119040445,-44.079955910561,-3.141592653589793 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark06(-1.4693498635937497E-15,-1.2338864831329814,43.84940681951069 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark06(-1.4698229156453582,-1.3118969792415829,-139.80868618868962 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark06(-1.4703672634260874,-1.5707963267948966,-2.3477938424160953 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark06(-1.4706465002248659,-1.5707963267948966,20.381114431063036 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark06(-1.4715292759729373,-8.881784197001252E-16,53.1791662153682 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark06(-1.4716139149322134,-7.346839692639297E-40,-88.29768697745273 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark06(-1.4718197070498051,-37.93034557175713,-664.3709082791955 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark06(-1.4722864673354188,-1.5707963267948966,-45.29355077267618 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark06(-1.4729802492612072,-1.5631526515007859,3.141592653589793 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark06(-1.4732544160209529,-1.476394154922944,-74.83082579789468 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark06(-1.473976929650192,-43.98257363936462,2283.6515540233963 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark06(-1.4739999225917702,-44.017094303189666,1.571772892428417 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark06(-1.4742075706443671,-32.7037267788437,-20.692021519283323 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark06(-1.4742165267781484,-1.5707963267948966,-78.05130561652896 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark06(-1.4744195898656134,-0.3561672291148678,-1.5707963267948966 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark06(-1.4744979477712077,-31.924400336317646,1.5707963267948966 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark06(-1.474504644486399,-0.6525301921596329,0.0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark06(-1.4751689648952422,-1.5707963267948966,15.271940304388991 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark06(-1.4764799786190195,-1.5707963267948966,3.266592653805145 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark06(-1.476608262069842,-1.5707963267948966,21.991148575128552 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark06(-1.4766886475018401,-45.06181047502762,-78.23516568325807 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark06(-1.4782865089667063,-8.881784197001252E-16,-30.57331109656151 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark06(-1.4796250703086504,-1.5707963267948966,-44.29280665491042 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark06(-1.4796736008060325,-1.5707963267948948,28.250540913652678 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark06(-1.4797258590389413,-2.220446049250313E-16,-13.502600779931015 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark06(-1.4799366420018052,-88.34629769706557,-1.5707963267948966 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark06(-1.4799410806417228,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark06(-1.4804768741825882,-1.5231743457227453,-11.231557500914095 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark06(-1.4810528512530725,-1.5707963267948966,-7.7734911456521125 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark06(-1.4814704531442044,-1.5707963267948966,59.690260418206066 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark06(-1.4818222268217938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark06(-1.4821146741637607,-1.570796326794893,55.926917651480856 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark06(-1.4832846516458815,-1.5707963267948966,-4.731275838502054 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark06(-1.4838427695383973,-2.2227587494850775E-162,-37.72333333109818 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark06(-1.4842444473866878,6.712561962191145,-12.338170366341672 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark06(-1.4845635811220168,-45.495211845491305,15.435724863342394 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark06(-1.4848340567036828,-31.803157584728623,-0.17608824930287284 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark06(-1.4852189891990215,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark06(-1.4857903226705638,-45.44875964759643,-320.440724827192 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark06(-1.4859290316833818,-3.97497387995593E-162,1.5707963267948966 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark06(-1.485933585529998,-1.5707963267948966,-123.87896733001828 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark06(-1.4859453056405116,-100.81729854700563,-2.0708655211865556 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark06(-1.4864982537946776,-1.5707963267948966,-1.3054294162756908 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark06(-1.4866082165086416,-1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark06(-1.4872161116770928,-0.7838496183394354,-21.088157282822777 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark06(-1.487532298874987,-88.42382955093524,-139.98749744991355 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark06(-1.4896138265599228,-31.67292447207298,-1.5707963267948983 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark06(-1.4899752318926218,-38.99347888479467,-73.52810016038237 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark06(-1.4910431735294294,-45.549518181376314,-53.38723342520446 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark06(-1.4912993415303228,-44.322961767254576,-85.32580987761018 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark06(-1.492164755746945,-94.2832363976179,-67.43117397036337 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark06(-1.4923782078407006,-19.382799335525444,-97.50178632482472 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark06(-1.4927804330991425,-95.29522002937118,-1.315430670807166 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark06(-1.493656068938099,-88.33988355661964,-84.03398920595247 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark06(-1.4941237435175667,-101.90369719037419,-7.857111613690371 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark06(-1.494789139904556,-31.778823104217167,95.61334507145565 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark06(-14.953785507634862,-98.05476166121436,53.41128197848829 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark06(-1.4956320949987219,-0.6107205334845801,33.393067737801836 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark06(-1.4961323760560354,-1.5639970015890232,88.2781539269183 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark06(-1.4962426015336447,-1.5707963267948966,-16.141939083658045 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark06(-1.4963762355057,-1.5707963267948966,2.9714366681108118 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark06(-1.4971229977015885,-163.46412019846073,-0.4308266741526774 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark06(-1.497312676523587,-1.5707963267948966,52.695810066039115 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark06(-1.497464996834415,2.465190328815662E-32,-9.782509320869774 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark06(-1.4979042258808049,-3.910318545279494E-149,-25.090646016620514 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark06(-1.4985749362023273,-32.61596316226001,-4.712388995293272 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark06(-1.499403399430091,-0.4564298172511805,3.141592964404238 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5002313928545667,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5003570698368285,-1.5707963267948966,-35.25033116796872 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark06(-1.500413997084137,-1.5707963267948966,-23.84577624877535 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark06(-1.501110900927771,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark06(-1.501168129797738,-1.0391978580708747,-9.93160700966888 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark06(1.5012608964606073,0,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark06(-1.5017353793047525,-1.5707963267948966,-7.044203657368268E-133 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark06(-1.5019160313903213,-0.12299026239468613,-1.5707963267948957 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark06(-1.5021157331447064,-1.1463094603979471,-24.614366770344674 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark06(-1.5029675004033567,-1.5707963267948966,-31.539773688124342 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark06(-1.5030186384779067,-95.26380961330617,-67.65188343199316 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark06(-1.5030335082232966,-1.4235136920207214,1.5707963267948966 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5034317442877267,-44.04325190332517,21.239068031274964 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5035735189009554,-1.342422621480391,-8.403981192058304E-15 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5035827675905487,-101.72959551577358,-10.857273838961248 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark06(15.038500865755893,-78.0342492778558,16.58758237472111 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5039059026528174,-1.5707963267948966,3.2667090217182713 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5042334334505274,-277.89629291373495,21.468646685613862 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5043804978196982,-32.98026437634084,3.085203552809247 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark06(-1.5043948542792334,2.688325831244098E-19,1.5707963267948966 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5044260609459479,-88.41250950561957,1.5707963267948966 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5044370054117586,6.7123889803847065,1.5707963267948983 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5046952100803368,-1.5707850710429492,-166.30191762191922 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5049178302702684,-0.5795801258812886,-1.574702576804815 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5049553982480233,-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5054741556623235,-0.07274000934422215,-93.3880775847345 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5057692020088966,-1.5707963267948966,-8.103981637456608 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5059388925878616,-94.32923464900166,-4.712411548402906 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark06(-1.5061310037580575,-1.5707963267948966,-93.6027154107816 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5062327412829493,-1.5707963267948948,-0.19506465860789413 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5070531750502365,-1.5707963260004547,1.5707963267948966 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark06(-1.507435287644257,-1.5707963267948966,57.13426694111851 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5080145228382626,-1.5707963267948966,-687.3757821826199 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5087542162468501,-1.5707963267948983,1.570796326794905 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5089845485125002,-1.5707963267948966,-73.24056467591987 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5094503181566477,-88.15265579674366,-1.7710586197922318 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5095751539948308,-1.3936860690601018,-74.2064044675605 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5098708997295724,4.3368086899420177E-19,4.714627989105792 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5101290800968337,-0.048501097597201545,-1.1924759163048941 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5113598740366736,-3.552713678800501E-15,-30.883630331289027 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark06(-1.511452661744893,-0.14451040847324872,91.64714251951926 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark06(-1.511644800930206,-0.4299256801869312,-4.742368356771816 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5118933648994222,-1.5707963267948966,-88.31699247659591 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5141727747038722,-20.610469873530697,-9.610648745033416 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5142252210936986,-95.76994065433905,0.2561451151528331 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5143794747358967,-0.8712194157421583,-61.345381315844634 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark06(-1.514418984260873,1.6940658945086007E-21,-38.940723798034995 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5149035289393193,-0.3348737152560885,-82.7221102769082 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5152733749865641,1.3398814296839336,-21.51046226834768 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5154131895559129,-0.2803875593229549,9.495567745759799E-66 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5155710451991633,-44.51519873841853,-4.712396893821277 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark06(-1.517087500390092,-1.5707963268296559,-100.54120378281698 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark06(-1.517315478842368,-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5178191212155723,-1.5707963267948966,-49.99723041173863 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark06(-1.518050232243192,-3.141594802567554,100.0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5184824635664207,-0.7123245546614969,-33.383608600415144 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5193231998679984,-37.77191885287337,-34.875687328899524 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5202417494084055,-1.5707963267948963,-69.99664211381798 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark06(-1.520345334870036,-1.570796326794894,-64.84217016118174 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark06(-1.520746638836298,-1.5707963267948966,-68.73649599225085 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5208936560725266,-1.1006424059601716,51.498935293432616 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark06(-1.520965974164183,-0.5489022521228781,12.726347966798684 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5210661494058675,6.712388980384691,1.5707963267948912 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark06(-1.521869083299577,-1.5525897212291573,-4.712728515171484 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5218766318444263,-0.7763033647758988,1.5707963267948983 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5222955821287163,-0.3781921356054825,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark06(-1.522759116001951,-4.5082903407156913E-131,5.250837714522944 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark06(-1.523099463033673,-0.554333472416095,100.0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5231557775980766,-31.85584978526137,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark06(-1.523382015324141,-32.71283639017294,-41.86384550691364 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5235294240840536,-94.2477796076938,-1.5707963267948966 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5238678599817668,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark06(-1.523980605075964,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5240700743663718,-38.725861339812425,0.0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark06(15.242362431466063,78.55648501884986,-46.535342909787445 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5251108781880063,-39.13030412906074,-98.3009658688868 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5251684467279703,-37.81172649018346,-47.49602767842405 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5255820628472656,-1.191752330592065,8.3688347939391 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5256068670936593,-88.13571887186723,-3.141592653589796 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark06(-15.259529844093223,78.84583691484619,38.73566116216688 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5266859217859798,-0.24871475578019175,-56.864484786657606 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5267978245311096,-1.5707963267948966,-85.41344466193357 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5269639125603287,-0.001851549241006002,-3.141592653589793 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5269695237632075,-39.12780495675781,-80.35599032300003 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5271550677555878,-1.146254414479479,-17.103037445393092 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5273942591521352,-1.5707963267948966,4.712396728566146 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5280077685349638,-101.81804249324773,1.5707963267948912 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5285626373277488,-19.39384810879291,-52.190817319977285 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5298546235053039,-1.5707963267948966,-2.2924804937685463 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5300768940028886,-0.8139838240850714,20.303668987322787 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5303805928222944,-32.48312047681786,-78.5399401937864 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5307278018167203,-1.5707963267948966,67.90195023612256 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5308084989341915E-17,-1.2055646197875816,30.98215932026243 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5309885733630442,2.710505431213761E-20,0.0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5312708983335284,6.886715526612083E-5,0.5383355534455792 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark06(-1.531310152304342,14.429567033047547,3.541714738544119 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark06(-1.531481767133481,-38.999175599478555,1.5724437415171733 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark06(-1.5317725128574649,-44.54051670567533,-1.5707963267948948 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark06(-1.531795586577216,0.16401101078029956,32.001321133100845 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark06(-1.5318472921131236,-37.87844871172725,-1.5707963267948966 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark06(-1.5325046721398627,-3.1415926535903558,-85.39945077259277 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark06(-1.5327212191475472,-0.7897599510672952,1.5707963267948974 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark06(-1.5328300710138352,-1.5707963267949003,-17.278801734889374 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark06(-1.5335980023083393,-0.8704994915607748,66.4061688797753 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark06(-1.5337846524909543E-15,-1.5707963267948961,-1.5707963267949125 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark06(-1.5339383068120789,-43.982297150257104,1.497814137696748 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark06(-1.534126613306631,-0.026598387115429393,-20.59597454827508 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark06(15.341939706255744,1.5707963267948966,-69.30883301104893 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark06(-1.5342361118096628,-1.5707963267948966,0.8400505308992776 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark06(-1.5346144162836206,-1.5707963267948966,58.171586159029886 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark06(-1.5348635901696732,-1.0987454870312747,110.67053981307102 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark06(-1.5349954719611043,-1.570796325813785,38.80557963835146 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark06(-1.535124549509341,-0.5343702312756821,-1.5707963267948966 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark06(-1.5353840516785746,-1.563246418892212,1.5708370226036836 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark06(-1.5357297519637547,-2.220446049250313E-16,-1.4617988994289843 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark06(-1.5361599897758649,-101.05420679721045,-28.682693671650227 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark06(15.364596764983233,40.885199786784256,-69.32597718293604 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark06(-1.5364644943192356,-1.5707963267948966,54.0612235120975 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark06(-1.5371540165958155,-31.945100146056816,-0.07963672980225234 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark06(-1.5376547623753156,-0.7274281887867033,-97.32478448049645 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark06(-1.537777843943754,-1.5707963267948966,22.035148240398556 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark06(-1.537985783337773,-0.5295936940242854,-0.5704112070848338 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark06(-1.5385955248737857,-31.536586255008288,-385.0868545619247 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark06(-1.539446094523037,14.42928933240082,10.814996185395536 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark06(-1.5398041028657328,-31.475392303985757,-1.5707963267948977 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark06(-1.5398826944863853,-95.270566243536,-32.53992017872153 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark06(-1.5406029511403805,-88.2574461134479,-0.573838507338742 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark06(-1.5406265221145385,-0.7441893302340391,-1.5707963267948983 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark06(-1.5406513533601345,-102.10167670745302,-1.5707963267948983 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark06(-1.5406584498060611,-1.387030755917432,-3.142031858340129 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark06(-1.540676608258346,-215.1933911635129,-90.83072005977837 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark06(-1.540695695353526,6.712388980386461,-1.5206634720056622 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark06(-1.5407439555097887E-33,-1.570790483279153,-65.97344188947741 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark06(-1.5408099521047518,-32.763916723231674,-13.46884483356024 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark06(-1.5410036175025579,-1.2026666573703921,-1.5707963267948966 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark06(-1.5411121788142832,-38.84049117581614,-1.5707963267949054 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark06(-1.5412269195480854,-0.17191357275140717,-26.860859591995265 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark06(-1.5413580331995234,-1.5707963267948966,4.995788879470254 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark06(-1.5415613615591293,-45.110845313415396,-1.5707963267948966 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark06(-1.5416265939002676,-1.7859177988785547E-102,19.102677380850015 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark06(-1.5419447802139075,-1.5707963267948966,0.4455187207728047 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark06(-1.5423228537598177,-1.5707963267948966,55.77492313692245 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark06(-1.5423487136658458E-179,-1.5707963267948966,1.570796326794896 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark06(-1.5425379808214543,-88.3735294283575,-85.87408214999462 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark06(-1.5430108997790846,-1.127021216021634,-83.8890135126641 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark06(-1.5435997335514724,-0.5699073251538791,1.5707963267948966 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark06(-1.5450430744709487,-1.394602983058336,2.3153317602815378 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark06(-1.5451282951001153,-44.07796819174274,-49.90457489344837 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark06(-1.545827404543388,-94.33144809383025,-96.6239950540152 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark06(-1.5458632361303701,-1.5707963267948966,33.97660871763606 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark06(-1.5459808450536312,-32.43406043154668,-52.621380846645856 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark06(-1.546117798142016,-1.5707963267948912,-1.5707963267948983 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark06(-1.5465379109837727,-1.5707963267948966,1.7710989892480635 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark06(-1.546771574629939,-1.5707963267948966,11.365914117065378 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark06(-1.547093552453465,-3.141592653590035,-4.578822626041429 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark06(-1.5475615537340488,-1.5707963267948966,-77.23701984162011 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark06(-1.5482507692065481,-32.5127630336589,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark06(-1.5485902640439726,-1.5707963267948966,27.330212440191573 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark06(-1.548788917188424,-1.5707963267948966,-72.23790357494846 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark06(-1.5490283032701757,-1.5707963267948966,-11.79718392404226 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark06(-1.5492886706653302,-32.71500010782046,-10.907612207626007 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark06(-1.5495371331533405,-0.13167694967656196,-4.837630530701466 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark06(-1.549751899889756,-0.9449725990452293,16.281196379053693 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark06(-1.550410030810641,-0.20516407046219598,13.720481455097069 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark06(-1.5506010530956686,-31.441048848889242,84.17978329412057 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark06(-1.5511589144578306,-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark06(-1.5511851239158103,-32.495252063160265,-78.0050024388929 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark06(-1.5512220854022838,-39.154513352790644,-4.714342105446395 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark06(-1.5513161622058569,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark06(-1.5515734923679558,-1.419307834680368,7.860479946300375 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark06(-1.5518338623699535,-1.5707963267948966,-1.011685271189347 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark06(-1.5518929868262852,-1.5707963267948961,38.78421665270312 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark06(-1.5521493422397228,-1.3469532571459424,23.557422404024823 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark06(-1.552377653648134E-11,-1.5707963267948983,-191.6455236623617 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark06(-1.5524277612509672,-31.757743620843186,1.5707963054448684 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark06(-1.5525585385682472,-1.5707963267948966,58.615147510759876 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark06(-1.5530208690896523,-32.56339870830096,0.0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark06(-1.5533935595875499,-1.5707963267948966,-24.368469587045563 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark06(-1.553585156043867,-1.3573042065962042,62.377845339903985 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark06(-1.5537565256033123,-1.5707963267948966,5.202479337255404 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark06(-1.5538197833794456,-44.480141489950704,-0.9886460794289516 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark06(-1.5539951772979412,-88.28471854480112,8.720152880761944 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark06(-1.5541580950071645,-95.4924962290525,-114.97157448141932 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark06(-1.554217733561582,-1.5707963267948966,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark06(-1.554296984725553,-1.5707963267948966,-3.8452451907564963E-16 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark06(-1.5550747758910535,-32.904048127738704,-3.1416446764623025 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark06(-1.5551868292556126,-0.02985739430215488,31.835812604732666 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark06(-1.5552075667227832,-1.5707963267948948,-35.025423089531614 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark06(-1.5552082119138413,-94.28542687079533,-13.64709468101403 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark06(-1.5557517419890767,-1.7763568392591337E-15,1.5707963267949032 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark06(-1.5559704719050653,-95.59819677048526,-76.57569225674463 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark06(-1.5561867447390219,-1.3266015364827772,-25.446691125266348 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark06(15.563686603640122,87.75323748146869,-36.6670182958309 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark06(-1.556478751093568,-88.46730744177505,-1.5707963267949054 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark06(-1.5567740646472197,-1.370484487468049,-112.15869718057411 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark06(-1.556992081503074,-39.07565646807644,-96.12689131965018 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark06(-1.5575316234004042,-0.21189173153713414,36.1283189226688 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark06(-1.557858477356975,-1.5707963267948966,-22.758728540841005 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark06(-1.5578832359505488,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark06(-1.5585127710460502,6.712388980418925,-73.84929617885078 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark06(-1.55874211092533,-1.5707963267948966,26.054329380467124 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark06(-1.5589340701367038,-0.17266152757770692,24.433126825800766 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark06(-1.559312132994775,-1.5707963267948963,3.2665933284961017 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark06(-1.5594659540079001,-95.37423249423786,-54.167020175438324 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark06(-1.5594894386220548,-95.3324585787871,84.70240852970566 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark06(-1.5598682761502274,-39.26229882773138,-459.6710405497412 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark06(-1.5600630284027344,-1.1955372501767243,65.97345267271312 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark06(-1.56036313985637,-44.12475285896351,-4.476740693088857 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark06(-1.5606132494163882,-1.0300229694190732,95.80723989494999 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark06(-1.560682212030784,-0.02326691851818019,-56.78694593073836 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark06(-1.5607730091090202,-1.5707963267948966,-115.02154181553034 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark06(-1.5609688600244278,-0.03775859910684751,-9.737929249949596 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark06(-1.5609883313036867,-0.548694200804011,79.06121251658331 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark06(-1.5610774711526645,-0.2965804263999322,-17.39850136250753 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark06(-1.5611240820272714,-1.5707963267948966,-1.2910167408269302 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark06(-1.5613389226798304,-1.121005416646013,24.72692237745622 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark06(-1.561465541767632,-0.059807885457284805,1.5869583560347942 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark06(-1.5616880040026269,-19.42021577069743,-4.744050201100209 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark06(-1.5622417714270367,-1.5707963267948966,-7.853981634241294 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark06(-1.5623015276821417,-45.458561945341124,-51.13760777117837 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark06(-1.562411257925649,-45.238712102891526,-38.68308868243495 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark06(-1.5624808259921832,-2.220446049250313E-16,47.339024044842844 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark06(-1.5626827474873284,-1.5707963267948966,-2.570796097404644 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark06(-1.5627735758904933,-94.3225504855283,-73.44202058976984 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark06(-15.627966739740714,-18.306206455318915,-53.09275067750321 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark06(-1.5629595636243294,-1.5707963267948948,-145.2693834739282 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark06(-1.563054506265135,-3.141592653601811,0.0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark06(-1.5630634637278307,-1.52653079858745,-65.44872512904952 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark06(-1.5633871688633647,-157.1254443815176,-186.83396444434476 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark06(-1.5636620839151691,-88.36297398278525,-73.82741989624171 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark06(-1.5638200021680244,-1.5707963267948966,6.283185317652663 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark06(-1.5640004048134633,-1.2140541505386602,-37.27635355360595 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark06(-1.5641274181117976E-148,-0.1208055731478371,10.426519338336515 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark06(-1.5641274181117976E-148,-1.5707963267948966,-16.735936680685192 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark06(-1.5641998140202338,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark06(-1.5642275496246276,-1.5707963267948966,-42.08437378909898 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark06(-1.5642479868243009,-32.51173792439678,88.3484397995717 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark06(-1.5642945412150508,-0.09266621329645297,43.89033063310567 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark06(-1.5643339295285406,-44.9868588277063,-7.159239115365861 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark06(1.5644115043990744E-4,53.827708687684556,-1.5707963267948966 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark06(-1.5649576473042095,-31.5949344517665,1.5707963267948966 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark06(-1.5652028426095062,-5.274187280462298E-9,123.78227170124285 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark06(-1.5652640643833284,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark06(-1.5653289792845222,-1.5707963267948966,-2407.947083793952 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark06(-1.5653552846441077,-0.8146940308269971,-73.8742382789964 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark06(-1.565644467099047,-32.89772845826066,-48.73955594449005 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark06(-1.5657249412138652,-1.5707963267948966,-5.255489486147633E-18 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark06(-1.565766149254033,3.944304526105059E-31,-77.33213346720959 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark06(-1.5661049229546766,-1.5707963267948966,-1.5703042030285121 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark06(-1.5661059692947352,-1.4278367025249912,-4.712458587483055 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark06(-1.5661165598235314,-0.03490758328794613,85.11443430785114 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark06(-1.5665530852646345,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark06(-1.5669724270854224,-2.220446049250313E-16,7.190194706160569 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark06(-1.5669954269446542,-1.5707963267948881,-78.88291960651233 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark06(-1.5670039110456158,-8.23756371004509,-97.77446020397001 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark06(-1.5670951079393005,-1.146080414580909,4.743739073948785 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark06(-1.5672897515563897,-1.570796326792268,43.41740514736929 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark06(-1.5675228641563266,-1.5707963267948961,-42.906392116808576 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark06(-1.5675731737935032,-1.5707963267948966,55.707088888839735 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark06(-1.5675959567643374,-1.5688545210303024,-43.9417895106869 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark06(-1.5676292120961877,-0.6663138937292328,61.217956513714086 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark06(-1.5677123912710886,1.048250869567929,5.228796663378716 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark06(-1.5677435203312036,-88.43845295268791,-1.5707963267948983 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark06(-1.5677983068656278,-32.986319848127565,-43.11982541685326 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark06(-1.567903680104214,-1.5707963267948966,28.274333882308138 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark06(-1.5679968750378632,-32.61746596425844,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark06(-1.568115709796517,-0.10780864259271805,72.74688039521004 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark06(-1.5681553056016175,-1.5707963267948966,-84.82300310967022 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark06(-1.5681807726742698,-31.784682656023552,-65.15675073651158 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark06(-1.5684135358042537,0.33627797847614793,-38.254566980614236 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark06(-1.5684815996991939,-88.16086099711156,-1.5707963267948963 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark06(-1.5684936757400592,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark06(-1.5686159950912246,-6.776263578034403E-21,-1.5691914243298195 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark06(-1.5687488197493804,-37.83879930261387,-54.89453715325227 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark06(-1.5687655044082403,-0.5236326611948728,0.0 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688560524356063,-1.5707963267948966,2286.157008492034 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark06(-1.5688862480917436,-0.002019309041128239,160.25009503020954 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark06(-1.5690264343706222,-31.419947248865544,-70.68295539411142 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark06(-1.569066627888199,-1.3052546744264377,-0.3835061936439327 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark06(-1.569066719000468,-0.00500730382556433,17.19987315014076 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark06(-1.569147544229311,-1.33102131441812,-82.67351115442058 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark06(-1.5691736397442066,-2.5026038689788762E-147,21.115830733075974 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark06(-1.5691919796777127,-1.5707963267948966,-31.415926591410788 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark06(-1.5692301457732036,-0.25571138546377004,1.5707963267948966 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark06(-1.5693288433689772,-1.5707963267948966,25.132741229989403 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark06(-1.569464628369202,6.712388980391503,-57.30728194515439 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695524379385262,-1.222181178752266,143.44574646747833 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark06(-1.5695709293999631,-0.059167499480586916,19.34955636823039 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696252907901254,-31.48352253743176,27.027064724217922 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark06(-1.5696718423939966,-1.5707963267948966,-21.28542381378275 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark06(-1.5699055894252862,-1.5707963267948966,67.33859258257718 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark06(-1.569911500422963,-37.69916170596062,-2.5680348212573816 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark06(-1.5699143756224032,-1.5707963267948966,1.1778035339788957 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark06(-1.5699317488386297,-158.64999621007507,-113.04622668804245 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark06(-1.5699547762057684,-1.5707963238141793,100.42425031822079 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark06(-1.570036454912364,-1.5707963267948957,26.780530640831415 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700502509749963,-44.04500003937854,-21.9684472679942 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark06(-1.5700984549374435,-95.36050503684551,0.0 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark06(-1.5702366932858047,-1.5706737334123348,-106.78623488615565 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703318974905898,-1.5707963267948966,18.245434222750053 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703463654905563,-270.4276647232163,-135.28110095256113 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark06(-1.5703614941879362,2.973589079734777,56.495660526823805 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark06(-1.5704369624877603,-88.36468587998704,-1.5707963267948966 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark06(-1.570527123631992,-1.5707963267948966,-55.977867385161204 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark06(-1.570541221403259,-44.40472216373543,4.5383831942026205E-7 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705505035861536,-0.06457881931116081,37.77160245460889 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705576868407016,-1.1102230246251565E-16,4.846258336858913 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705608375019398,-39.06959596871347,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark06(-1.5705994707864375,-1.5707963267948966,53.123638878823186 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706017398356082,-19.396006969512104,-1.5707963267948966 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706054797828735,-45.099389726422935,-25.132741344669174 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark06(-1.570634311399554,-45.55303314094633,-112.97547033961914 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark06(-1.570643202149768,-1.0278271931649847,-82.94375535709254 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark06(-1.570655924322444,-1.7655694528338596E-7,-1.5707963267948966 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706572999464539,-45.55296841315182,-18.870572777917424 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706578344191446,-1.5707963267948966,-119.38041171354051 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706668009057976,-88.09043293739971,-91.10240168866372 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706834245248984,-1.5707963267948966,-10.995574226736109 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706863488435707,-1.5707963267948966,58.504271477872145 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706879129615776,6.712388980384884,0.0 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706946526977021,-0.05512029475644553,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark06(-1.5706983387648854,-1.5707963267948966,4.712389417479544 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707037209134402,-157.47168005171648,44.27990274894532 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark06(-1.570704876888733,-1.5707945155607264,-56.54802307928411 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark06(-1.570719666568231,-1.5707963267948966,100.53095790334507 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707225905622293,-1.5707225537853373,18.850598672774275 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707373314480013,-31.986648783283318,-1.5707963267948963 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark06(-1.570748417404081,7.853981633947007,58.88891652011748 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark06(-1.57075009135849,-88.08973032535721,-1.5707963267948966 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707515110291768,-1.3552527156068805E-20,-3.1415926535897967 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707554924673384,-31.553891800144044,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark06(-1.570757711677321,-100.5309660147554,-53.89661679059297 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707580349071106,-3.1415926541399366,0.0 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark06(-1.57076303639279,-3.196361941217913E-4,-26.67754643994173 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707763293474553,-1.6970486249411756E-5,-3.141592653589793 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707801693524084,-45.37270815701393,-0.09152712008853832 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707821526386525,-1.5707959279128716,-62.879534053713385 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707838695110823,-3.5590823914107195E-9,70.68528711744997 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707860738463406,-1.4333737720727558E-7,97.38927185826789 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707885838520952,8.673617379884035E-19,0.0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707895669406546,-32.98672286086347,0.0 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707897129265092,-3.1416089499595756,134.3751414571749 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707904203939969,-1.5707963267948821,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707916385339562,-95.81631394061355,-55.9873762867005 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark06(-1.570792235633108,-1.5707963267948966,-156.99405216149026 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707926183649457,-1.3792870267523294E-6,9.437605477538353 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark06(-1.570792641373867,-44.04479813559994,28.236907838382034 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark06(-1.570792885691784,-145.01700363292198,-21.420282825987425 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707948593592327,-1.5707955307334094,0.0 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707948600501946,-1.5707963267948966,-18.836519382324074 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707952760069104,-39.269808174273265,0.0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707955144979815,-1.570796157334235,13.311797129329744 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707956245962797,-1.8005046049500113E-6,-15.705087434296688 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707956422262908,-6.938893903907228E-18,-3.142838885523947 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark06(-1.570795691054329,-32.966584771917866,-152.86110960899862 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959327024408,-37.69911965672047,-91.10881733718378 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959576197474,-0.8389755114324782,99.84896490913422 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959581646667,-1.5707963267948966,-62.082383894428624 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707959726738279,-88.08970175345102,-53.34812437696167 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796047173392,-44.044887926232164,-47.12340089309662 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707960471744542,-1.5707961078423962,-43.87322109783872 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961401879869,-31.447737165193523,1.5707635604665802 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796171786815,-1.5707963267948966,0.15395665689112303 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961804717938,-44.02859261216354,0.0 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961945616682,-8.252223510184094E-7,-15.709897060460001 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707961995289537,-1.5707963267948966,-56.54865264155667 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962017207668,-0.126037364551034,-97.41655403532809 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962044108468,-0.022910535907719486,-1.1254698783950736 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962114097818,-157.08200846524596,3.141526444363628 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796234653648,-4.165585106830114E-6,-53.686054249243654 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707962475335457,-1.5707963267948966,2.8323586677764157 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796256734227,-0.18600585171074988,37.778294193353666 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796299061426,-1.2505293153820172,73.64513171800934 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963035446761,-0.4969964238529254,1.5707963267948966 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963043206898,-0.8379510313949609,28.86141623130152 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796308758941,-1.5707963179531628,124.65437334125227 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963097016682,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963117760833,-0.33704754297518774,0.09989761408494596 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963173186597,-1.5707963267948966,39.594066216419655 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963177895063,-1.5707963267948963,214.1501333603066 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963184179545,-95.7460721027782,-884.3021335559911 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963193421137,-1.5707963267948966,-29.442087644075915 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796320508895,-38.70562671637498,1.3548295414998244 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963217448526,-1.5707963267948966,74.68480988458172 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963218040113,-1.5707963267948966,17.551438766058812 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796321986244,-1.5707963267948948,-194.7691143780258 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963220080103,-1.5707963267948966,25.123911287389156 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963228896222,-1.5707963267948966,-73.87424256162119 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796323946682,-0.8163754437454074,-43.36679838448965 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963240925842,-8.881784197001252E-16,-22.935560462951248 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963242571703,-1.5707963267948966,-28.206175633831368 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963244402485,-0.6776155219850301,15.513783099128943 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963245685335,-1.5707963267948983,-77.38462219160671 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963248668706,-0.7630585756523747,-78.93597258568524 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963249726242,-1.294048052574099,-95.36912942213075 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963250564827,-3.705301796939987E-11,70.68550109448404 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963251541512,-88.08959446852339,-40.82645104168684 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963252980364,-1.5707963267948966,9.527130037641157 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963253790864,-38.77583415562038,-49.701514445356175 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254078123,-1.5707963267948966,16.390304459594063 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254404242,-1.5707963267948966,1.5707963267949574 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963254512751,-0.05864512166777813,58.026555068272046 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255172015,-37.85161943323848,-10.652561385663738 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255228363,-0.10962261492745083,83.4528461063046 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325548872,-94.36871552973355,-1.084303049843374 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963255575068,-0.01614421529352398,-128.99418638155365 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632559266,-1.5707963267948966,31.350386044280125 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963256074455,-45.39344746632204,-32.731220097267396 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325691426,-1.5707963267948966,23.465332145065965 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963256949498,-1.5621481403399113,-21.458812423729086 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963257175608,-32.92327380116242,-1.5707963267948983 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325787891,-94.2789452893853,-32.84507721340525 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963257934847,-31.4373512477694,19.36283909380907 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325872731,-0.43039015848750206,-30.7922667903837 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796325914431,-1.2554505036828427,-27.878348185622663 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963260686038,-32.532053405152915,-51.122511283651335 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262774345,-1.5707963267948966,-45.116594337219354 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326279528,-95.38323143268065,-1.5707963267948966 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326291011,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963262915072,-0.365937946455809,-1.5447535753167188 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263056086,-1.570796326794897,45.51771050327727 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326316049,-31.841090085040324,-83.88621572378858 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326332949,-38.77939552999062,1.5707963267948912 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263351112,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326336604,-0.23152226320145303,95.42846679888294 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263570968,-37.76138229730133,-16.262542779754757 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263585967,-0.26263840814990036,-72.7044366429977 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263694351,-0.976961472982712,9.628799213217704 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263735734,-0.6056891856124111,-62.674185797837055 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963263866804,1.5573771643285752,-3.83907123658048 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326397764,-1.5707963267948966,74.16898122302567 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264055345,-1.5331635395129906,71.16590101909281 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264077216,-0.12409277518466222,15.580135779432625 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326413967,-1.5707963267947609,42.1873950242651 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326433305,-0.2387255490104063,88.38542376700049 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264353728,-1.5707963267948966,0.6887480161337278 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264407072,-95.4402565016469,-1.134226598345041 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264449634,-1.2033024832698924,-100.0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264462592,-1.5707963267948966,-65.76604681947441 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326451807,-0.5649022914459934,1.5707963267948966 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264644278,-1.5707963267948983,10.992725628161843 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326469243,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264773233,-2.0611864790856917E-147,8.448714218253773 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264868967,-88.51043291960399,84.24887054009345 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963264882907,-1.5707963267948966,-73.48740825221017 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265088574,-0.8087539614253294,37.09519237790987 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265115803,-0.056486156770918894,18.693621753734163 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326517783,-0.4488319016654714,55.30473730311722 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265186518,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326545806,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265587346,-1.5707963267948961,94.43099545212314 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265681977,-1.5707963267948966,19.38179200519988 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265752098,-1.5707963267948966,-96.44840109092648 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963265860199,-0.09023252508885568,-100.0 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266057674,-1.5707963267948966,66.24657047564831 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326614869,-1.5707963267948948,-69.1101429158602 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266286145,-44.45345581523779,-32.72218626093222 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266294307,-1.5707963267948966,-69.10814547872693 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266401164,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266421088,-88.21187236850511,-52.17764262664624 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266536802,-1.5707963267948966,-0.20994533526519144 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632666219,-0.4372895515648918,-1.5707963267948983 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266734428,-1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266740237,-45.11078799704691,-100.0 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266755287,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266840437,-39.26947846194299,0.0 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266864082,-1.5707963267948948,56.852000318913554 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632668687,-1.125930922510906,-57.04555323684611 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963266993408,-95.30209146325068,44.069733173993 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326714435,-1.5707963267948966,-56.522058413357456 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326722219,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267437233,-1.5707963267948966,-8.785415729089266 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267472265,-39.09852908953463,-92.07829868020531 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326749697,-45.290653056179565,-62.838003936545036 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267531062,-1.5707963267810425,51.69752546424454 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267576255,-94.28194351444571,-78.17217898361562 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326763269,-1.5707963267948966,27.13970172992599 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326763598,-1.5707963267948966,132.03390558433279 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267660863,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267694782,-0.8865811295468263,-1.5707963267948966 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326770316,-1.5147873539499492,1.1080122866340116 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267711953,-1.4635226176885385,25.248634651254836 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267721783,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267757337,-7.105427357601002E-15,-2.565898987950554 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267760046,-1.5707963267948966,-21.259089203131335 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267818572,-1.0500185493415422,-0.49319068227702423 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632678449,-1.5707963267948966,-10.321301692194165 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267853233,-88.429227186823,-29.979366461846496 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326785832,-0.20915134214328646,58.48331634000232 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267871887,-0.3435980417324848,67.43970924291284 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326788944,-0.8856528124644415,-25.11508569772822 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267899168,-1.5707963267948966,98.27524028391758 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267904859,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267907346,-45.55293723241785,-21.878084064025465 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267922025,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267936458,-0.6861424099880983,0.0 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267936509,-1.570796326764228,26.751852451420316 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326793688,-44.36197085958258,-52.32676185698928 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267936929,-1.5707963267948966,-73.90276753957264 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267938652,-1.5707963267948966,3.0983520478053146 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794125,-1.5707963267948966,56.47457695505448 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267941332,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267941853,-1.5707963267948966,40.464470188788425 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267941925,-1.570796326794746,40.85714773870337 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942218,-1.5707963267948966,-10.312772030319024 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267942757,9.860761315262648E-32,-73.38209171869522 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794283,-163.37295406397533,-3.0852046073010904 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944105,-0.06295580713949625,12.041625866678359 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267944223,1.9721522630525295E-31,11.992653619119523 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267945861,-88.0896068258841,-53.65974449129889 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946035,-0.14201671218543765,50.25676362865369 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946,-100.92245445226298,33.119530266430374 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946567,-32.848900909218116,39.485414914031224 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267946883,-0.16817793970134365,1.5707963267949054 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794703,-32.60786466220148,-97.86987019524511 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947207,-45.171087738252716,-46.51487988039402 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947314,-1.5707963267948926,-75.39823894515042 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794735,-1.5707963267948966,56.550076578503244 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947358,-1.3142142088732383E-16,11.002261139624366 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947598,-39.080958026492226,4.743802552308541 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947704,-0.8679727645755317,91.97770987818163 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947704,-1.5707963267948966,-88.38086443804202 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947869,-0.010273704788703514,23.59516051708242 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947882,-32.82581380954635,-54.50764168326554 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267947918,-88.2497085572883,-53.47628675555012 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948009,-0.011954048989864186,-5.9960183889571095 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948024,-44.17037341042942,0.0 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948024,-95.4271706599177,-113.71402123458986 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794813,-31.434796363008687,-60.65356078883173 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948273,-83.20422449503091,0 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794838,-1.5707963267948966,-0.23199860338548106 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948384,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948384,-1.5707963267948966,-35.375038362669926 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948415,-1.5707963267948966,-0.6224038103497204 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948513,-1.5707963267948966,-0.7900212134087081 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948553,-1.5707963267948966,-9.680230959439882 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948584,-4.3978160446334464E-13,1.5707963267950067 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948615,-37.901663554047595,0.0 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948617,-1.5707963267948966,-30.65599294384157 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948655,-1.5707963267948966,0.0016620307217463802 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794869,-1.5707963267948966,-3.2665926582822653 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948692,-1.5707963267948966,-43.078392247573134 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948697,-88.19213561278369,-40.339349489276756 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679487,-0.03935836980278218,64.96550142150402 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-1.5707963267949019,28.22767213887067 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-31.60232696295897,59.24886573185191 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948735,-44.033482728986016,1.5707963267948948 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948737,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-0.7181241497385855,-9.879805338721908 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.1016782576491515,38.04758155185665 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.460066786334029,4.395852385499069 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-1.5707963267948957,-10.608934963262953 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-31.4540331485957,-24.81269055274207 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-44.25325417161985,-73.42140425498707 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794877,-94.2477796076938,-10.499485829621335 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948781,-1.4836824602749686E-67,-73.65766731827689 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948797,-1.5707963267948966,-1.574704571621053 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948801,2.465190328815662E-32,-80.58389050409708 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948806,-1.5707963267948966,31.444442898243352 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948806,-95.3577544552621,-4.712388995975386 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948812,-0.6920659596290694,-4.194384684141596 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948815,-39.201803801460045,1.5707963267948954 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948826,-1.5707963267948963,-56.548667763383726 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948828,-1.5707963267948966,96.15602046037594 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-0.2974020168434184,-83.18900555503538 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-0.5115416977864116,72.47116341630337 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.2849302900514428,-88.46047059449604 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,1.3877787807814457E-17,-60.663215289704816 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-1.5707963267948966,82.62128019908667 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948841,-31.749840643163424,71.27650220737816 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948846,-0.9564399056261649,62.21259168490175 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948852,-0.4356746563766411,-14.436560211000206 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948855,-0.1888720332898527,-4.6816763546921983E-97 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948855,-1.5707963267948966,-2.5626663618343692E-144 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794886,-100.93009045201522,1.481808034436205 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794886,-1.5707963267948966,32.61251816246002 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948863,-2.5849394142282115E-26,-76.96901979965429 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948866,-1.3582893094568869,44.234300405590304 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948866,-31.41592653656332,-88.21074056501995 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948868,-1.5707963267948966,-9.46579778819874 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794887,-1.5707963267948966,-66.20906794709673 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-0.20113242376364873,-96.58032245434 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-0.5328489515641488,-1.5707963267948966 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.1102230246251565E-16,77.78516098040467 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-1.5707963267948983,-87.10512616264793 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-2511.25352796749,0 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-31.60847753813983,-3.14159265361697 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-32.924984902731765,-12.211796204062068 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948877,-39.0356266236472,-87.06849568546792 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794888,-1.5707963267948966,-53.425494287299834 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794889,-0.5503680330595742,-45.50502491487989 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-3.1415926535897936,-1.5707963267948983 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-31.831217575198,0.26772017836079115 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948895,-44.50751166410818,20.958744000813013 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948901,-1.5707963193143346,-2.784993827842708 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,0,0 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-31.523729017391844,1.5707963267948966 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948903,-31.528322249819567,0.4435153449844558 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948906,-1.5707963267948954,31.800631924286364 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948908,-1.3552527156068805E-20,-30.33607363956594 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,1.570796326794896 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,58.442998477202906 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948966,62.8678327142467 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794891,-1.5707963267948968,-49.38819322741334 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.02683218560211008,-1.5707963267948974 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.03468338375294745,78.22534102516212 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.07216661249579559,-51.16543728085496 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.0977607838595248,0.0 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.12250956255515533,30.698922751212365 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.13592611560147994,-66.63412295133321 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.14384189179096651,-12.473285775848566 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.19059319767447164,-10.179452223935606 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.193672964462543,-58.313547308223235 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.23446309779994282,-4.712438565936877 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.25086708610825953,31.46106767053351 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.3804164652733366,75.993366642078 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.47959225089930435,-47.42937455586465 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.48904243263078695,-57.25347293810146 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5777334157238823,-4.256290516172783 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.5870597626040199,-95.3630662475415 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.594533296685161,66.33061169230595 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.602681291638238,66.48995123705961 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6105644879528583,-3.1415926535897944 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6403900294027562,1.5707963267948966 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.6413504026447137,1.4088407314736535E-132 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.698680467960969,-9.852273347802637 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7210702713539661,1.5707963267948963 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.723212660875254,69.98512233839537 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.7690721302488948,-58.236929156840375 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.78855161488646,21.935500410315285 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.8761587281444402,14.42923649543986 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9291811107428067,68.96399078569468 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9387802588378311,1.5186503770291235 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9496396597375636,28.07513991680156 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-0.9792839938555714,-27.728115532897306 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-100.76526176068546,63.104900457593885 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.05911054536784,40.14963196713566 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.85227639898868,-4.657367597496946 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.0188499267999238,1.510164962594618 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.93304787061874,-58.15518118388041 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-101.97416745576116,-148.51908250340068 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,11.02922629677549,0 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.1126026106678147E-16,-67.42124388918414 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.161274715508293,-77.2424843912387 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.237332177834465,164.41454734130605 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,1.2472685362322646,-10.94316167461208 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.250232934778444,-9.633969921739661 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.2507163640871586,-81.68901216006108 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.3014964119848886,-53.75550173887127 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.3180569184437534,4.482636614457327 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.345688716087615,-82.71589720784719 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.4008158388360352,-31.41592653761521 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.4207982561613133,0.0 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5529441234328076,-99.42975780331224 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5588755519266781,96.4727032042623 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963149801183,-37.70188741656881 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963266024025,72.41337813683705 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267947846,45.257106257618915 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948788,-7.971061745819338 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-17.635881400141542 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,39.48555796741189 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,39.77040380927443 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-86.42847072919837 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948912,-9.146476404306839 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.570796326794893,-31.56875453659784 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,14.479935997161334 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,15.572110205880733 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,43.836033013979176 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,5.621152160805854 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948948,71.21641307395313 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948961,4.840697137017898 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948961,9.67391832720227 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,28.10402024526782 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948963,-47.35262172901339 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,100.53096491478087 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-112.00608868649334 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,14.433934557333366 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,14.630765196510723 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-15.183508746368844 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,15.636531623964402 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-16.69717528846502 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,19.308463361826057 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-21.080660810037298 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-23.6670397906626 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,27.062116775084768 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-3.265169605868845 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,37.93321461228015 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,38.287930752112274 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-39.942313663017686 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,40.90674322204544 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-42.245604288065984 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,43.6265945046859 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,44.50945364286315 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-45.15804106033525 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,47.12940745318929 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-53.90542825362992 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-65.51810708472934 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,6.588873714519077E-83 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,72.6696930486506 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-73.32946216536685 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,82.1397109052613 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-87.68174171666823 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-88.59218541076602 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,-90.27782965547053 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.5707963267948966,92.90175433307556 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-163.77726445092227,-28.711469320882827 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-164.61873536270994,-91.7861256338711 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-1.734723475976807E-18,-100.0 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-19.349555921538762,-24.470908507121322 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-19.351998553927125,-93.1882036830959 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,2.1175823681357508E-22,-29.63273038420722 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-227.76546603593573,-86.69390746595144 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.44544503706298,-37.02214760838382 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.5709805547364,-414.6876137930811 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.593948757563908,-1.5707963267948966 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.617279161545515,0.0 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.798862940911192,0.1899801003702436 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.801360340247868,-27.45070861479161 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.808101632123012,-100.0 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.87910116199089,-69.98423754114648 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.97147107142328,-43.82003149474123 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-31.975494936753407,33.79818792539059 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.54704574862578,-38.92610592403353 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.56953970828681,-1.5707963267948966 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.57158332526502,-74.69120989017921 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.59645039967285,-366.9902220517083 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.76582763265063,-1.5707963267948966 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.804240375997175,-1.5707963267164795 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.823058914400534,58.863204066587635 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-32.98172447105692,-0.4166214159248227 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-3.534764514608385E-16,100.0 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.69911184307752,0.0 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.69911184429198,-15.707141845961672 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.8847575967759,-7.883669430182329 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-37.89247346770143,-0.38360909011306676 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.70708998608052,-3.7538696337966684 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.736502231969475,-69.67092080908651 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.80835161716994,-1.5707963267948966 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.882579611565674,-85.35441605643278 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-38.95722353048359,-66.27436384427091 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.14677042805269,-53.715588390845184 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.15055686908946,-0.9363301200740738 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-39.219923264978206,0.0 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.00539156124481,84.20701460543941 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.04479715025713,-34.55752945604913 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.06126322303645,-96.43049433822213 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.08713906835033,-63.660372983025916 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.134495982572204,-8.488011610852027 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.2977514463438,-3.1415927393444547 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.332511339976534,-58.42093352752177 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.42043763060044,-1.5707963267948983 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-44.519118352110695,-56.816632777906676 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.17376477445703,8.805193202674136 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.22774419390445,-9.15511060195438 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.267210839528374,-73.75862736620557 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.3653923064264,-8.953384126632722 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.45522709603391,0.058416488597856815 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.472703578803035,-20.473141937519415 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-45.494243975358685,-66.0632959724737 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-5.603243092053726E-16,90.98717351191965 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,6.5205426523497865,100.0 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,6.712388980384692,-82.22862513580625 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,6.712388980384701,97.37233761898324 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-83.48593777751263,-30.317417261989448 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.08959430051422,-2.5707058342377365 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.11758527383518,-90.4669027141131 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.18106072290806,0.0 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.40592592669977,1.8033161362862765E-130 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.45556060499293,0.0 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-88.459655848241,-1.5707963267948966 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679489,-1.2895721616904008,-82.79011526969629 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-89.59115244844617,-1.5707963267948983 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,89.65496608700215,60.57687093130144 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-89.94836993987875,-15.080128039995273 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-89.95291953493472,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-94.2477796076938,1.5707963267948983 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.34933142780883,0.0 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.43170177299419,-37.187077592848915 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.51142738948865,-83.94510823027332 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.58280751504705,72.07132762953975 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948912,-95.61512141081374,20.456756294455282 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-1.5707963267948966,-27.129423289842794 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948915,-1.5707963267948966,-46.008053651627996 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark06(-1.57079632679489,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794892,-0.7494688649580494,1.5707963267948983 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-1.5687665368407304,-1.5707963267948966 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,-38.7686605378155,-3.141592653589793 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948921,6.7123889850817156,1.5707963267949125 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948923,-1.2105796950746954,163.53996302627058 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948928,-0.4577420169386842,-12.340944252370761 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948928,-1.570795270448596,-1.4131728929412959 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.10672025977713606,-55.744570310646075 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-0.7398356056527322,-1.5707963267948966 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.2579824512313553,-65.74066447334425 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.2667053816482858,-4.7436632796303515 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948966,-44.13233955886043 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-1.570796326794896,-71.67835852579196 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-2.710505431213761E-20,-1.5707963267948966 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948932,-44.054398925221875,-2.6862031748514217 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-31.852006957704894,-74.56523775009029 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-32.4739434963418,-1.570796326795012 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794893,-37.94692340706398,-1.5707963267948968 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948934,-1.5707963267948966,-43.116827685884985 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-0.15797995170722645,-1.350010201092088 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948937,-0.3818763204834281,12.490740722648184 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-0.19322506513246104,10.667908566445437 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-0.9619774811729065,2.070796481140411 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.5707963267948966,0.573087898679342 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.5707963267948966,-1.5708002488187585 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794894,-1.5707963267948966,1.5710405247186203 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.3183676021352548,0.0 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948943,-1.5707963263086357,100.0 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.04115420889344822,64.85417906224977 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.04147575109938084,28.0897213484955 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.08615848152886713,-859.6980724449696 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.11518109196052251,64.88975936394483 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.2474851636017269,-57.3235404075903 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.26735854948691495,51.301907780626834 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.30436265920555683,0.7946320801101052 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.3234247072706371,-54.18962758314803 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.37939091279733195,30.272283042344302 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.4415875944934413,-35.10528797585956 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.49274232710341337,-85.03887829623305 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.49702161184451366,0.0 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.5777094384018566,-65.50771954004225 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7676070684083405,30.858124238826942 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.7718613506293837,67.5585173709247 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,0.7811232628772554,-100.0 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.8390221913642455,1.5707963267948966 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.8421383185560106,66.29084758677143 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9306069975149995,54.80760311375556 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-0.9897168084447654,0.0 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-100.77182753339626,-1.5707962197925354 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.2188645095501007,53.89886254555739 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.35257172382234,-37.374291800803384 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3552527156068805E-20,73.84305236536227 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.3617479812729418,-87.60922491580408 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5083928315286386,-99.14116777486599 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5098709589792219,-4.325380745365521 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5327274741376404,-1.5707963267948948 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.550824273552894,-181.5774999325981 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.570796326793161,93.55734106553842 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948801,-8.795579114829579 ) ;
  }

  @Test
  public void test4430() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948912,11.0880624545608 ) ;
  }

  @Test
  public void test4431() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,53.54171853578803 ) ;
  }

  @Test
  public void test4432() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948948,-81.68140899333463 ) ;
  }

  @Test
  public void test4433() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,65.7346993971803 ) ;
  }

  @Test
  public void test4434() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948957,-67.15287943815139 ) ;
  }

  @Test
  public void test4435() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4436() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,0.7494688649580485 ) ;
  }

  @Test
  public void test4437() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-0.8887015523428544 ) ;
  }

  @Test
  public void test4438() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4439() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test4440() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4441() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-1.5707963267948974 ) ;
  }

  @Test
  public void test4442() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,21.24892558137054 ) ;
  }

  @Test
  public void test4443() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,26.539782934987315 ) ;
  }

  @Test
  public void test4444() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-37.13848770668663 ) ;
  }

  @Test
  public void test4445() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,43.38025910345891 ) ;
  }

  @Test
  public void test4446() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-44.908872390816626 ) ;
  }

  @Test
  public void test4447() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,54.31590325547473 ) ;
  }

  @Test
  public void test4448() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,58.49796008563989 ) ;
  }

  @Test
  public void test4449() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-64.94459348737351 ) ;
  }

  @Test
  public void test4450() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,66.4807794531566 ) ;
  }

  @Test
  public void test4451() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-72.25769644287723 ) ;
  }

  @Test
  public void test4452() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948966,-8.962040665460627 ) ;
  }

  @Test
  public void test4453() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-1.5707963267948986,94.02010875614846 ) ;
  }

  @Test
  public void test4454() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-19.354865556801286,-54.84999255708407 ) ;
  }

  @Test
  public void test4455() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,2.220446049250313E-16,-32.868341575618885 ) ;
  }

  @Test
  public void test4456() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-26.925561647643065,-138.8781727755563 ) ;
  }

  @Test
  public void test4457() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-28.163789568970618,-66.32605768312476 ) ;
  }

  @Test
  public void test4458() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-30.16383268971098,0 ) ;
  }

  @Test
  public void test4459() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.1415926535897998,-1.5707963267948966 ) ;
  }

  @Test
  public void test4460() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.4400556085073,-44.42880349373511 ) ;
  }

  @Test
  public void test4461() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.448088103395335,-17.354659467463513 ) ;
  }

  @Test
  public void test4462() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.44989500774046,-84.69642759898413 ) ;
  }

  @Test
  public void test4463() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.453311029483274,-1.5707963267948966 ) ;
  }

  @Test
  public void test4464() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.578066469435935,1.5717745021095824 ) ;
  }

  @Test
  public void test4465() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.60522661836645,-2348.9724235071267 ) ;
  }

  @Test
  public void test4466() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.823225854212023,1.5707963267948983 ) ;
  }

  @Test
  public void test4467() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-31.940764283398575,0.586888893151216 ) ;
  }

  @Test
  public void test4468() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-32.60201930776826,-76.00217967705362 ) ;
  }

  @Test
  public void test4469() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-3.552713678800501E-15,27.916286278620664 ) ;
  }

  @Test
  public void test4470() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-38.884418825941914,-80.56622754047311 ) ;
  }

  @Test
  public void test4471() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.099636117006106,0.0 ) ;
  }

  @Test
  public void test4472() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.18450661585672,-1.5707963267948966 ) ;
  }

  @Test
  public void test4473() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-39.20245325512306,38.88470396023077 ) ;
  }

  @Test
  public void test4474() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.042855195486894,-4.141592653589794 ) ;
  }

  @Test
  public void test4475() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.15862319518219,-83.274955847742 ) ;
  }

  @Test
  public void test4476() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.22319421847343,-33.220216314664256 ) ;
  }

  @Test
  public void test4477() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-4.440892098500626E-16,88.44666785064544 ) ;
  }

  @Test
  public void test4478() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.425349756253226,-1.5707963267948983 ) ;
  }

  @Test
  public void test4479() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-44.547062424880785,-39.49990260985213 ) ;
  }

  @Test
  public void test4480() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.05648408912815,-48.65997974625316 ) ;
  }

  @Test
  public void test4481() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.062525128156246,-1.5707963267948912 ) ;
  }

  @Test
  public void test4482() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-4.5082903407156913E-131,-58.33970286869062 ) ;
  }

  @Test
  public void test4483() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.08490255984794,-1.933290706257056E-15 ) ;
  }

  @Test
  public void test4484() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.12562448097739,-87.39290895032433 ) ;
  }

  @Test
  public void test4485() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.15492483880446,-1.5707963267948966 ) ;
  }

  @Test
  public void test4486() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.18948204052498,-1.5707963267948966 ) ;
  }

  @Test
  public void test4487() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-45.42675838921102,-84.60532108463667 ) ;
  }

  @Test
  public void test4488() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-8.208743691573488,65.79223463454724 ) ;
  }

  @Test
  public void test4489() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.16119263734538,-5.026911708464872E-88 ) ;
  }

  @Test
  public void test4490() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.30116863321683,0.0 ) ;
  }

  @Test
  public void test4491() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-88.3631470192603,-41.050586317402725 ) ;
  }

  @Test
  public void test4492() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-94.2477796076938,1.3234889800848443E-23 ) ;
  }

  @Test
  public void test4493() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-94.2477796076938,84.5659003906233 ) ;
  }

  @Test
  public void test4494() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-94.30258133967024,-25.62691284115705 ) ;
  }

  @Test
  public void test4495() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.46163834884592,-579.6130558469538 ) ;
  }

  @Test
  public void test4496() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948948,-95.63032098363612,-1.5707963267949054 ) ;
  }

  @Test
  public void test4497() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test4498() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4499() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-1.5707963267948966,46.14675262268308 ) ;
  }

  @Test
  public void test4500() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948952,-31.757319190164367,-0.8643635786133298 ) ;
  }

  @Test
  public void test4501() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4502() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4503() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,40.22707742406811 ) ;
  }

  @Test
  public void test4504() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-1.5707963267948966,-4.712389041824312 ) ;
  }

  @Test
  public void test4505() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-32.64296029454408,-10.74439919133027 ) ;
  }

  @Test
  public void test4506() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794895,-44.241695462111274,-1.5707963267948966 ) ;
  }

  @Test
  public void test4507() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948954,-88.12939135890142,-1.5707963267948948 ) ;
  }

  @Test
  public void test4508() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.18239420368334724,-44.069256373613804 ) ;
  }

  @Test
  public void test4509() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.4559435175279454,37.74546174441163 ) ;
  }

  @Test
  public void test4510() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.47040824193274,11.01681091681381 ) ;
  }

  @Test
  public void test4511() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.5256830309868652,-5.54953296181705 ) ;
  }

  @Test
  public void test4512() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.6124402157175112,-3.1415926535897936 ) ;
  }

  @Test
  public void test4513() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.9324605932884941,-40.47915488729065 ) ;
  }

  @Test
  public void test4514() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-0.9590879740037985,-164.9296897032275 ) ;
  }

  @Test
  public void test4515() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.4210854743395687E-14,-3.1416306348745184 ) ;
  }

  @Test
  public void test4516() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5529137333755836,-82.39057857295087 ) ;
  }

  @Test
  public void test4517() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5613278090704548,-6.712408930326988 ) ;
  }

  @Test
  public void test4518() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948912,-45.53641472547277 ) ;
  }

  @Test
  public void test4519() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948912,57.888910420978505 ) ;
  }

  @Test
  public void test4520() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test4521() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4522() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-1.3130132317207455 ) ;
  }

  @Test
  public void test4523() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4524() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-3.1415926535897927 ) ;
  }

  @Test
  public void test4525() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,38.043357027259674 ) ;
  }

  @Test
  public void test4526() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-45.967292720606295 ) ;
  }

  @Test
  public void test4527() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,58.585761100616665 ) ;
  }

  @Test
  public void test4528() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-66.0494626729694 ) ;
  }

  @Test
  public void test4529() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-75.10814878999443 ) ;
  }

  @Test
  public void test4530() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,-80.20381767799212 ) ;
  }

  @Test
  public void test4531() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948966,99.7475586388438 ) ;
  }

  @Test
  public void test4532() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948968,16.959090228721386 ) ;
  }

  @Test
  public void test4533() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-1.5707963267948974,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test4534() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,1.734723475976807E-18,36.18301582353121 ) ;
  }

  @Test
  public void test4535() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-19.355414668878957,-1.7551432582044484 ) ;
  }

  @Test
  public void test4536() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-20.802777812529563,-1.5707963267948966 ) ;
  }

  @Test
  public void test4537() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-3.1415926535897936,1.5707963267948966 ) ;
  }

  @Test
  public void test4538() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-31.71549711594561,-1.5707963267948963 ) ;
  }

  @Test
  public void test4539() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-31.869602884651997,-61.34763689583682 ) ;
  }

  @Test
  public void test4540() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-32.74478373181937,1.4516015217836558 ) ;
  }

  @Test
  public void test4541() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-39.14255993947992,-3.8346439269186677E-16 ) ;
  }

  @Test
  public void test4542() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-39.21992458407742,2.2227587494850775E-162 ) ;
  }

  @Test
  public void test4543() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,4.3368086899420177E-19,1.3838030498736593 ) ;
  }

  @Test
  public void test4544() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-44.54501394660815,-72.40528362067292 ) ;
  }

  @Test
  public void test4545() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-5.747509799259562E-16,74.20890067542693 ) ;
  }

  @Test
  public void test4546() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948957,-95.50379598828997,-42.996088869002655 ) ;
  }

  @Test
  public void test4547() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.037856269025282385,-73.36760011136914 ) ;
  }

  @Test
  public void test4548() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.2165859330492892,0.0 ) ;
  }

  @Test
  public void test4549() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.28889166481833994,1.5707963267948966 ) ;
  }

  @Test
  public void test4550() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.5388548700930406,0.0 ) ;
  }

  @Test
  public void test4551() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.6711607765441041,1.5707963267948966 ) ;
  }

  @Test
  public void test4552() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-0.6770387038748993,0.0 ) ;
  }

  @Test
  public void test4553() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.0842021724855044E-19,0.7516577875033925 ) ;
  }

  @Test
  public void test4554() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.0873810449245729,-89.02099371095555 ) ;
  }

  @Test
  public void test4555() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.0288659396197446,-3.2665927163005515 ) ;
  }

  @Test
  public void test4556() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.496171964860423,-54.73229868723766 ) ;
  }

  @Test
  public void test4557() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5131708495619625,36.225209114627525 ) ;
  }

  @Test
  public void test4558() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963259682178,94.25116702134454 ) ;
  }

  @Test
  public void test4559() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948912,-1.3689826717760634 ) ;
  }

  @Test
  public void test4560() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948961,-102.05606775887533 ) ;
  }

  @Test
  public void test4561() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948961,-71.68789350320941 ) ;
  }

  @Test
  public void test4562() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948963,-2326.1147423359675 ) ;
  }

  @Test
  public void test4563() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.258080153596759 ) ;
  }

  @Test
  public void test4564() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,12.782328712259599 ) ;
  }

  @Test
  public void test4565() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5341492270707273 ) ;
  }

  @Test
  public void test4566() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-1.5707963267948961 ) ;
  }

  @Test
  public void test4567() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4568() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,33.799845986602264 ) ;
  }

  @Test
  public void test4569() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,42.41898108163725 ) ;
  }

  @Test
  public void test4570() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,-5.331473598011305 ) ;
  }

  @Test
  public void test4571() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,63.91709993214084 ) ;
  }

  @Test
  public void test4572() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-1.5707963267948966,78.40000136848609 ) ;
  }

  @Test
  public void test4573() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,2.220446049250313E-16,-78.34539463621513 ) ;
  }

  @Test
  public void test4574() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-31.415926707486495,0.0 ) ;
  }

  @Test
  public void test4575() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-31.5913532825329,34.038855044338746 ) ;
  }

  @Test
  public void test4576() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-32.621378522374314,1.5707963267948983 ) ;
  }

  @Test
  public void test4577() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-3.7205212042911086E-16,-33.66965466759256 ) ;
  }

  @Test
  public void test4578() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-37.70881649110828,-3.142492869055748 ) ;
  }

  @Test
  public void test4579() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-39.062138861421566,0.7592379429471807 ) ;
  }

  @Test
  public void test4580() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-39.15907155176955,-3.1415989696600315 ) ;
  }

  @Test
  public void test4581() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-39.21560583224902,-9.907396012499326 ) ;
  }

  @Test
  public void test4582() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-43.99505709473103,2.8964660032877245E-11 ) ;
  }

  @Test
  public void test4583() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-44.39833980792038,33.99090223167965 ) ;
  }

  @Test
  public void test4584() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-45.03333100187377,-90.60376311801103 ) ;
  }

  @Test
  public void test4585() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-45.0937064046432,0.0 ) ;
  }

  @Test
  public void test4586() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-45.11800917425092,-41.27751079959301 ) ;
  }

  @Test
  public void test4587() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948637,18.84955592153876 ) ;
  }

  @Test
  public void test4588() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948948,-1.5707963267948912 ) ;
  }

  @Test
  public void test4589() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,0.5892527034591117 ) ;
  }

  @Test
  public void test4590() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4591() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-88.21771896548647 ) ;
  }

  @Test
  public void test4592() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,-1.5707963267948966,-99.8524020907402 ) ;
  }

  @Test
  public void test4593() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,6.712388980610808,-1.029119959650919 ) ;
  }

  @Test
  public void test4594() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-88.17328785407165,1.5708012301847811 ) ;
  }

  @Test
  public void test4595() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948961,-88.22276144302691,-89.85952877283407 ) ;
  }

  @Test
  public void test4596() {
    coral.tests.JPFBenchmark.benchmark06(-1.570796326794896,2.7755575615628914E-17,38.82891655030334 ) ;
  }

  @Test
  public void test4597() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test4598() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.011408507995364829,-24.721136445025728 ) ;
  }

  @Test
  public void test4599() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.030847862453944812,1.5707963267948966 ) ;
  }

  @Test
  public void test4600() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.0316380761138592,-1.463023860841312E-98 ) ;
  }

  @Test
  public void test4601() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.075312486172533,0.0 ) ;
  }

  @Test
  public void test4602() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.11932503563091293,3.1416220917985935 ) ;
  }

  @Test
  public void test4603() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.26329273572540046,-59.4583144158648 ) ;
  }

  @Test
  public void test4604() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.2677271547822579,-32.559448966296884 ) ;
  }

  @Test
  public void test4605() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,0.3637166110141544,-99.03420254973989 ) ;
  }

  @Test
  public void test4606() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.4064359212526245,0.0 ) ;
  }

  @Test
  public void test4607() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.45774528486365057,-72.13707930705542 ) ;
  }

  @Test
  public void test4608() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.504912255298402,-95.41448773758201 ) ;
  }

  @Test
  public void test4609() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.5078226800591058,-19.762596793741064 ) ;
  }

  @Test
  public void test4610() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.5688137861917625,-37.27820486784241 ) ;
  }

  @Test
  public void test4611() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.6173384880391193,88.36092375528108 ) ;
  }

  @Test
  public void test4612() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8146178432597124,36.16649078794566 ) ;
  }

  @Test
  public void test4613() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.8525601120987053,6.929767996871801 ) ;
  }

  @Test
  public void test4614() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-0.9936557835459272,6.712389062022885 ) ;
  }

  @Test
  public void test4615() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.0623781176698348,-3.141592611878046 ) ;
  }

  @Test
  public void test4616() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.2785153456960265,-52.91509254077947 ) ;
  }

  @Test
  public void test4617() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.293080439976709,-56.39719670622418 ) ;
  }

  @Test
  public void test4618() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3028000744912707,0.0 ) ;
  }

  @Test
  public void test4619() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3465074712453244,0.9484511175281849 ) ;
  }

  @Test
  public void test4620() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.3502842020377441,-92.50034075790118 ) ;
  }

  @Test
  public void test4621() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,1.3552527156068805E-20,72.29268215283062 ) ;
  }

  @Test
  public void test4622() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5393223404404666,-32.1370916653368 ) ;
  }

  @Test
  public void test4623() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5558666655735378,-4.33811925801381 ) ;
  }

  @Test
  public void test4624() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707872913635197,100.53012073887865 ) ;
  }

  @Test
  public void test4625() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267947256,55.70413517744971 ) ;
  }

  @Test
  public void test4626() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test4627() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948961,31.447176709017874 ) ;
  }

  @Test
  public void test4628() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4629() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,0.09826509760743482 ) ;
  }

  @Test
  public void test4630() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-0.24972235435618217 ) ;
  }

  @Test
  public void test4631() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-10.087593041266947 ) ;
  }

  @Test
  public void test4632() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-10.831813070137713 ) ;
  }

  @Test
  public void test4633() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test4634() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948948 ) ;
  }

  @Test
  public void test4635() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4636() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4637() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,25.88221009367639 ) ;
  }

  @Test
  public void test4638() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-28.05213229685073 ) ;
  }

  @Test
  public void test4639() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-3.1415926536641727 ) ;
  }

  @Test
  public void test4640() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-4.349250511532599 ) ;
  }

  @Test
  public void test4641() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-45.18647203868178 ) ;
  }

  @Test
  public void test4642() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-50.09421916157859 ) ;
  }

  @Test
  public void test4643() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-60.305463684717616 ) ;
  }

  @Test
  public void test4644() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,-85.09584605974374 ) ;
  }

  @Test
  public void test4645() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-1.5707963267948966,95.19027370508745 ) ;
  }

  @Test
  public void test4646() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-221.3470313403418,-67.33354889527664 ) ;
  }

  @Test
  public void test4647() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.447176538225662,1.5707963267948948 ) ;
  }

  @Test
  public void test4648() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.642011857351378,0.0 ) ;
  }

  @Test
  public void test4649() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.67364678409959,0.13363821522046276 ) ;
  }

  @Test
  public void test4650() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.677746159702778,8.853455100726933 ) ;
  }

  @Test
  public void test4651() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-31.914504718567827,-4.537710818178672 ) ;
  }

  @Test
  public void test4652() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-32.54770883931252,-1.5707963267949019 ) ;
  }

  @Test
  public void test4653() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-32.69505294842957,-0.1665334155395338 ) ;
  }

  @Test
  public void test4654() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-32.8230587349121,1.5707963267948983 ) ;
  }

  @Test
  public void test4655() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,3.3087224502121107E-24,-5.07947859521202 ) ;
  }

  @Test
  public void test4656() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-37.806604461292906,-9.85596312961994 ) ;
  }

  @Test
  public void test4657() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-37.824801063034826,15.399397315948931 ) ;
  }

  @Test
  public void test4658() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-37.915695593432986,-32.93455676205848 ) ;
  }

  @Test
  public void test4659() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.18364669687356,-43.715443598068696 ) ;
  }

  @Test
  public void test4660() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.22416016484869,1.1591269220898192E-69 ) ;
  }

  @Test
  public void test4661() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.2938610481499,59.19500594066068 ) ;
  }

  @Test
  public void test4662() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-44.46794521315367,84.11976530879875 ) ;
  }

  @Test
  public void test4663() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.013225017356326,-629.3714262028686 ) ;
  }

  @Test
  public void test4664() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-4.512192178225392E-21,-53.65707511102872 ) ;
  }

  @Test
  public void test4665() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.185254348418894,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test4666() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-45.2336866450818,-66.82867855223249 ) ;
  }

  @Test
  public void test4667() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,5.14159265360069,1.5707963267948912 ) ;
  }

  @Test
  public void test4668() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-6.308771682994227E-13,-1.5707963267948966 ) ;
  }

  @Test
  public void test4669() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,6.712388984756465,0.0 ) ;
  }

  @Test
  public void test4670() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-88.13107555597405,7.861794153702886 ) ;
  }

  @Test
  public void test4671() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-88.16021259250418,1.5707963267948983 ) ;
  }

  @Test
  public void test4672() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-88.4240458500826,-60.10304739451935 ) ;
  }

  @Test
  public void test4673() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-95.55118983711145,-114.0860496790182 ) ;
  }

  @Test
  public void test4674() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-9.566129265174277E-25,-3.141592653589793 ) ;
  }

  @Test
  public void test4675() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948963,-95.8185759343452,0.0 ) ;
  }

  @Test
  public void test4676() {
    coral.tests.JPFBenchmark.benchmark06(-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test4677() {
    coral.tests.JPFBenchmark.benchmark06(1.5747783874403163,1.5707963267949197,100.0 ) ;
  }

  @Test
  public void test4678() {
    coral.tests.JPFBenchmark.benchmark06(1.5777218104420236E-30,-31.97493765646341,-83.68708550554607 ) ;
  }

  @Test
  public void test4679() {
    coral.tests.JPFBenchmark.benchmark06(-1.5793650827938261E-176,-0.03854992740585158,-17.476880274503692 ) ;
  }

  @Test
  public void test4680() {
    coral.tests.JPFBenchmark.benchmark06(1.5892530491088037E-17,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test4681() {
    coral.tests.JPFBenchmark.benchmark06(-1.595796048969769E-8,-1.2794420070282753,-100.0 ) ;
  }

  @Test
  public void test4682() {
    coral.tests.JPFBenchmark.benchmark06(-1.6016664761464807E-145,-1.7763568394002505E-15,-45.048681445397065 ) ;
  }

  @Test
  public void test4683() {
    coral.tests.JPFBenchmark.benchmark06(-1.6071690242423622E-9,-1.5707963267948966,56.11391664196334 ) ;
  }

  @Test
  public void test4684() {
    coral.tests.JPFBenchmark.benchmark06(-1.6107948995098924E-17,-3.1415926562026324,-0.4070513830704101 ) ;
  }

  @Test
  public void test4685() {
    coral.tests.JPFBenchmark.benchmark06(16.139426553644796,-64.52910243891557,95.80550458406438 ) ;
  }

  @Test
  public void test4686() {
    coral.tests.JPFBenchmark.benchmark06(-16.179059505072942,36.18081115437673,96.51487756013475 ) ;
  }

  @Test
  public void test4687() {
    coral.tests.JPFBenchmark.benchmark06(1.6206510184913678,2.220446049250313E-16,-100.0 ) ;
  }

  @Test
  public void test4688() {
    coral.tests.JPFBenchmark.benchmark06(-1.6242827758820155E-114,-0.44505237229837713,17.321615647144785 ) ;
  }

  @Test
  public void test4689() {
    coral.tests.JPFBenchmark.benchmark06(-1.6242827758820155E-114,-1.5707963267948966,-97.16812507140583 ) ;
  }

  @Test
  public void test4690() {
    coral.tests.JPFBenchmark.benchmark06(16.271560450838905,-19.223052766007328,95.36449405731872 ) ;
  }

  @Test
  public void test4691() {
    coral.tests.JPFBenchmark.benchmark06(1.630781743646727,1.2160679126259015,177.28718384175505 ) ;
  }

  @Test
  public void test4692() {
    coral.tests.JPFBenchmark.benchmark06(16.339189571764166,-95.00764876046462,-4.714943511841668 ) ;
  }

  @Test
  public void test4693() {
    coral.tests.JPFBenchmark.benchmark06(-16.399593032229134,-63.00718432331382,55.78677060884539 ) ;
  }

  @Test
  public void test4694() {
    coral.tests.JPFBenchmark.benchmark06(-1.6401064715739963E-142,-1.3058282159626056,12.423448319234048 ) ;
  }

  @Test
  public void test4695() {
    coral.tests.JPFBenchmark.benchmark06(16.46469146207093,87.92344570260221,-45.264578135594306 ) ;
  }

  @Test
  public void test4696() {
    coral.tests.JPFBenchmark.benchmark06(-1.6472184286297693E-83,-0.24222908051933897,36.133913436234344 ) ;
  }

  @Test
  public void test4697() {
    coral.tests.JPFBenchmark.benchmark06(16.52933016290585,35.83963290633352,-0.4301535357635373 ) ;
  }

  @Test
  public void test4698() {
    coral.tests.JPFBenchmark.benchmark06(1.6543612251060553E-24,-0.0049034217077066535,-32.18311234231056 ) ;
  }

  @Test
  public void test4699() {
    coral.tests.JPFBenchmark.benchmark06(1.6543612251060553E-24,-44.016294134753835,32.52022712482421 ) ;
  }

  @Test
  public void test4700() {
    coral.tests.JPFBenchmark.benchmark06(1.6543612251060553E-24,-44.18475452745205,-2.0517718600599117 ) ;
  }

  @Test
  public void test4701() {
    coral.tests.JPFBenchmark.benchmark06(-1.6649979327439179E-257,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4702() {
    coral.tests.JPFBenchmark.benchmark06(-1.675668980545003E-15,-1.5707963267948966,-64.72834990446138 ) ;
  }

  @Test
  public void test4703() {
    coral.tests.JPFBenchmark.benchmark06(-1.6804969461421161E-15,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4704() {
    coral.tests.JPFBenchmark.benchmark06(-1.680701850451411E-15,-1.5707963267948948,-42.411528388137704 ) ;
  }

  @Test
  public void test4705() {
    coral.tests.JPFBenchmark.benchmark06(1.6940658945086007E-21,-1.2909291835875505,38.76019564431312 ) ;
  }

  @Test
  public void test4706() {
    coral.tests.JPFBenchmark.benchmark06(1.6940658945086007E-21,-1.5260022963059323,-1.5707963267948966 ) ;
  }

  @Test
  public void test4707() {
    coral.tests.JPFBenchmark.benchmark06(-1.6940658945086007E-21,-1.570792770891596,-2.5707067582784955 ) ;
  }

  @Test
  public void test4708() {
    coral.tests.JPFBenchmark.benchmark06(1.6940658945086007E-21,-94.29462388478332,46.74546006638545 ) ;
  }

  @Test
  public void test4709() {
    coral.tests.JPFBenchmark.benchmark06(1.6946114951060696E-17,-0.08507638567302209,0.012098092798143195 ) ;
  }

  @Test
  public void test4710() {
    coral.tests.JPFBenchmark.benchmark06(-1.6958303447609539E-167,-31.509384950769167,-1.1110235625201241 ) ;
  }

  @Test
  public void test4711() {
    coral.tests.JPFBenchmark.benchmark06(17.09003990286797,34.28026778478204,-18.49053351135035 ) ;
  }

  @Test
  public void test4712() {
    coral.tests.JPFBenchmark.benchmark06(1.7142961034171822,1.5707963267948966,63.84953280919023 ) ;
  }

  @Test
  public void test4713() {
    coral.tests.JPFBenchmark.benchmark06(-1.7290327071306454E-223,-1.5707963267948966,-0.3064087823990887 ) ;
  }

  @Test
  public void test4714() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.1475100613701699,0.0 ) ;
  }

  @Test
  public void test4715() {
    coral.tests.JPFBenchmark.benchmark06(-1.734723475976807E-18,-1.5700393553126528,47.1162898573981 ) ;
  }

  @Test
  public void test4716() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948963,55.633226195294746 ) ;
  }

  @Test
  public void test4717() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,15.00133524656598 ) ;
  }

  @Test
  public void test4718() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,-1.5707963267948966,-4.470538088588775 ) ;
  }

  @Test
  public void test4719() {
    coral.tests.JPFBenchmark.benchmark06(1.734723475976807E-18,6.4570100221381255,4.231366726856251 ) ;
  }

  @Test
  public void test4720() {
    coral.tests.JPFBenchmark.benchmark06(-1.7353103910890844E-6,-1.5707963267948966,185.33984070618692 ) ;
  }

  @Test
  public void test4721() {
    coral.tests.JPFBenchmark.benchmark06(-1.7365302730352168E-164,-0.18035388449950995,1.5707963267948983 ) ;
  }

  @Test
  public void test4722() {
    coral.tests.JPFBenchmark.benchmark06(-17.36875151705175,90.97516854793304,78.82972981603376 ) ;
  }

  @Test
  public void test4723() {
    coral.tests.JPFBenchmark.benchmark06(17.514942060649517,69.85210388970899,-22.317772814520694 ) ;
  }

  @Test
  public void test4724() {
    coral.tests.JPFBenchmark.benchmark06(17.52490865133514,68.8475133606479,-72.2782177995256 ) ;
  }

  @Test
  public void test4725() {
    coral.tests.JPFBenchmark.benchmark06(-1.7642838569345816E-15,-1.5707963267948912,3.141592653589793 ) ;
  }

  @Test
  public void test4726() {
    coral.tests.JPFBenchmark.benchmark06(-1.7654412687816862E-13,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4727() {
    coral.tests.JPFBenchmark.benchmark06(-17.656154129076313,-56.915792683679165,-13.31359036026187 ) ;
  }

  @Test
  public void test4728() {
    coral.tests.JPFBenchmark.benchmark06(-1.77117003878451E-4,-1.5707963267948966,-0.84596307002763 ) ;
  }

  @Test
  public void test4729() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.3189325791276467,89.53545498585139 ) ;
  }

  @Test
  public void test4730() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.6366068511203582,145.53605444817612 ) ;
  }

  @Test
  public void test4731() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-0.9682876479388369,-4.3755231915809 ) ;
  }

  @Test
  public void test4732() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.1849137183886995,136.60882200817878 ) ;
  }

  @Test
  public void test4733() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.4825701950400876,1.5707963267948977 ) ;
  }

  @Test
  public void test4734() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707962812869647,-40.840947353625666 ) ;
  }

  @Test
  public void test4735() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948186,63.95453900408761 ) ;
  }

  @Test
  public void test4736() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.570796326794889,100.0 ) ;
  }

  @Test
  public void test4737() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948912,-73.45319434121387 ) ;
  }

  @Test
  public void test4738() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948963,83.65208777361333 ) ;
  }

  @Test
  public void test4739() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test4740() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,41.35891840588439 ) ;
  }

  @Test
  public void test4741() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,-55.69420363425235 ) ;
  }

  @Test
  public void test4742() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948966,56.618971092487755 ) ;
  }

  @Test
  public void test4743() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267948983,-45.87552793291692 ) ;
  }

  @Test
  public void test4744() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-1.5707963267949019,81.39403091423233 ) ;
  }

  @Test
  public void test4745() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-2.220446049250313E-16,47.383891609657525 ) ;
  }

  @Test
  public void test4746() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,2.465190328815662E-32,53.76700534285344 ) ;
  }

  @Test
  public void test4747() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-31.85525498073995,-54.66779146717143 ) ;
  }

  @Test
  public void test4748() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-31.897347470419316,-7.413964812818556 ) ;
  }

  @Test
  public void test4749() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-33.27603573822719,0 ) ;
  }

  @Test
  public void test4750() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-37.79807237572017,-1.5707963267948966 ) ;
  }

  @Test
  public void test4751() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-39.26302679519337,-1.5707963267948966 ) ;
  }

  @Test
  public void test4752() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-44.149133802267535,0.0 ) ;
  }

  @Test
  public void test4753() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-45.00639235902895,-57.63449345169809 ) ;
  }

  @Test
  public void test4754() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-45.46642150719772,0 ) ;
  }

  @Test
  public void test4755() {
    coral.tests.JPFBenchmark.benchmark06(-1.7763568394002505E-15,-8.145370155254454,-78.41884993923593 ) ;
  }

  @Test
  public void test4756() {
    coral.tests.JPFBenchmark.benchmark06(-1.776356840414777E-15,14.432205603277083,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test4757() {
    coral.tests.JPFBenchmark.benchmark06(-1.778206999588062E-161,-1.5671850938431495,-10.749529308729857 ) ;
  }

  @Test
  public void test4758() {
    coral.tests.JPFBenchmark.benchmark06(-1.7859177988785547E-102,-45.129199143941555,-14.148619395922772 ) ;
  }

  @Test
  public void test4759() {
    coral.tests.JPFBenchmark.benchmark06(-17.885901023817837,-69.21684202216454,-62.47075219666984 ) ;
  }

  @Test
  public void test4760() {
    coral.tests.JPFBenchmark.benchmark06(1.7935378460810666E-17,-1.5707963267948966,-10.809193241865177 ) ;
  }

  @Test
  public void test4761() {
    coral.tests.JPFBenchmark.benchmark06(18.113730760126074,85.02242440808013,-86.421088242928 ) ;
  }

  @Test
  public void test4762() {
    coral.tests.JPFBenchmark.benchmark06(-1.822494865124212E-14,-1.5707963267868839,72.25913703246 ) ;
  }

  @Test
  public void test4763() {
    coral.tests.JPFBenchmark.benchmark06(-1.8377023529581932E-9,-1.5707963267948966,-99.83139625136884 ) ;
  }

  @Test
  public void test4764() {
    coral.tests.JPFBenchmark.benchmark06(1.8444673058825797E-20,-1.5707963267948966,-38.94515947905485 ) ;
  }

  @Test
  public void test4765() {
    coral.tests.JPFBenchmark.benchmark06(-1.848509848238803E-14,-1.5707963267949054,15.582572515159981 ) ;
  }

  @Test
  public void test4766() {
    coral.tests.JPFBenchmark.benchmark06(1.871919263966762E-18,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4767() {
    coral.tests.JPFBenchmark.benchmark06(1.873761421163064E-18,-45.45203815720078,-0.33656074181177875 ) ;
  }

  @Test
  public void test4768() {
    coral.tests.JPFBenchmark.benchmark06(-1.882117647925071,63.92606732250786,17.848762949342813 ) ;
  }

  @Test
  public void test4769() {
    coral.tests.JPFBenchmark.benchmark06(-1.894399862106065E-15,-1.5707963267948966,-73.30714604410917 ) ;
  }

  @Test
  public void test4770() {
    coral.tests.JPFBenchmark.benchmark06(19.149311900058734,-81.01486188105163,-27.796208368609527 ) ;
  }

  @Test
  public void test4771() {
    coral.tests.JPFBenchmark.benchmark06(-19.229445452081478,-64.44332001406903,-10.933824978122303 ) ;
  }

  @Test
  public void test4772() {
    coral.tests.JPFBenchmark.benchmark06(-1.9259299443872359E-34,-1.5707963267948966,-53.40707441045715 ) ;
  }

  @Test
  public void test4773() {
    coral.tests.JPFBenchmark.benchmark06(19.289642668300473,56.80406235820436,-54.24112078867576 ) ;
  }

  @Test
  public void test4774() {
    coral.tests.JPFBenchmark.benchmark06(19.462337856176745,-98.78095986492174,-30.180131803024125 ) ;
  }

  @Test
  public void test4775() {
    coral.tests.JPFBenchmark.benchmark06(-1.947571038436579E-4,-1.4277366572253043,53.886856554298475 ) ;
  }

  @Test
  public void test4776() {
    coral.tests.JPFBenchmark.benchmark06(-1.947787278639072E-15,-1.5707963267948966,45.69225937547361 ) ;
  }

  @Test
  public void test4777() {
    coral.tests.JPFBenchmark.benchmark06(19.478461234423335,18.25272535850138,-11.570510411232334 ) ;
  }

  @Test
  public void test4778() {
    coral.tests.JPFBenchmark.benchmark06(1.9515430022775552E-5,-1.5707963267948966,-1.2668861560727578 ) ;
  }

  @Test
  public void test4779() {
    coral.tests.JPFBenchmark.benchmark06(-1.9583723193516823E-8,0.15517957738754104,34.09000882157642 ) ;
  }

  @Test
  public void test4780() {
    coral.tests.JPFBenchmark.benchmark06(-19.793936135243783,-52.78923161323876,84.42817212517355 ) ;
  }

  @Test
  public void test4781() {
    coral.tests.JPFBenchmark.benchmark06(-19.929208951473626,90.22097040025943,-69.58005686455647 ) ;
  }

  @Test
  public void test4782() {
    coral.tests.JPFBenchmark.benchmark06(19.979258496897884,30.754625157124934,-81.47242420784961 ) ;
  }

  @Test
  public void test4783() {
    coral.tests.JPFBenchmark.benchmark06(-2.0215873059760975E-174,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4784() {
    coral.tests.JPFBenchmark.benchmark06(-2.0215873059760975E-174,-1.5707963267948966,-4.181611804823419 ) ;
  }

  @Test
  public void test4785() {
    coral.tests.JPFBenchmark.benchmark06(-20.23353417024785,30.144531502014758,74.89118786304988 ) ;
  }

  @Test
  public void test4786() {
    coral.tests.JPFBenchmark.benchmark06(-2.0303534698525194E-115,-88.09255689091206,1.5707963267948966 ) ;
  }

  @Test
  public void test4787() {
    coral.tests.JPFBenchmark.benchmark06(-20.516739730139477,-26.82548491097843,-44.49650839135477 ) ;
  }

  @Test
  public void test4788() {
    coral.tests.JPFBenchmark.benchmark06(20.536565217366174,-84.66515700967847,51.14360201537181 ) ;
  }

  @Test
  public void test4789() {
    coral.tests.JPFBenchmark.benchmark06(-2.0679515313825692E-25,-1.5707963267948983,-38.25036545786362 ) ;
  }

  @Test
  public void test4790() {
    coral.tests.JPFBenchmark.benchmark06(2.0679515313825692E-25,-95.39522596437709,14.849807212431296 ) ;
  }

  @Test
  public void test4791() {
    coral.tests.JPFBenchmark.benchmark06(20.895141560425017,-38.64265585381372,49.67522801696981 ) ;
  }

  @Test
  public void test4792() {
    coral.tests.JPFBenchmark.benchmark06(20.902141236924024,-92.09367478330887,-90.46037279830503 ) ;
  }

  @Test
  public void test4793() {
    coral.tests.JPFBenchmark.benchmark06(2.0962753728526437E-14,-0.17429529329422355,54.889229908359525 ) ;
  }

  @Test
  public void test4794() {
    coral.tests.JPFBenchmark.benchmark06(-20.995386641225508,-13.278165662133802,88.48847683015705 ) ;
  }

  @Test
  public void test4795() {
    coral.tests.JPFBenchmark.benchmark06(-21.023202425446357,16.80075953535693,-28.598874902388943 ) ;
  }

  @Test
  public void test4796() {
    coral.tests.JPFBenchmark.benchmark06(-2.1106356288215886E-227,-1.5707963267948966,16.902817597608987 ) ;
  }

  @Test
  public void test4797() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-1.201574410890155,-72.52829694434351 ) ;
  }

  @Test
  public void test4798() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-1.5707963267948966,-45.10135773827026 ) ;
  }

  @Test
  public void test4799() {
    coral.tests.JPFBenchmark.benchmark06(2.1175823681357508E-22,-88.40797801455034,95.50355034310435 ) ;
  }

  @Test
  public void test4800() {
    coral.tests.JPFBenchmark.benchmark06(-2.1199790534196105E-21,-31.642873694273643,1.5707963267948983 ) ;
  }

  @Test
  public void test4801() {
    coral.tests.JPFBenchmark.benchmark06(21.27649049906934,-56.68938692129415,-50.697110365350696 ) ;
  }

  @Test
  public void test4802() {
    coral.tests.JPFBenchmark.benchmark06(-2.1612908839133068E-224,-1.441763703277842,4.145797003877367 ) ;
  }

  @Test
  public void test4803() {
    coral.tests.JPFBenchmark.benchmark06(-21.616852106127112,92.94297289926206,24.581513780754506 ) ;
  }

  @Test
  public void test4804() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.01153477926848429,-45.537523951064344 ) ;
  }

  @Test
  public void test4805() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-0.23033166220778944,0.06259125941843381 ) ;
  }

  @Test
  public void test4806() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.0091568886046514,-100.0 ) ;
  }

  @Test
  public void test4807() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4808() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-1.5707963267948966,27.316863060460108 ) ;
  }

  @Test
  public void test4809() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-44.08837476241362,-0.867439874993556 ) ;
  }

  @Test
  public void test4810() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,6.712388980417846,-100.0 ) ;
  }

  @Test
  public void test4811() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-88.16035404443916,-1.5707963267948974 ) ;
  }

  @Test
  public void test4812() {
    coral.tests.JPFBenchmark.benchmark06(2.1684043449710089E-19,-95.28868003442162,-1.5707963267948966 ) ;
  }

  @Test
  public void test4813() {
    coral.tests.JPFBenchmark.benchmark06(-21.68682722449489,-65.21253180347776,41.917198427826264 ) ;
  }

  @Test
  public void test4814() {
    coral.tests.JPFBenchmark.benchmark06(-2.1750233042182888E-16,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test4815() {
    coral.tests.JPFBenchmark.benchmark06(21.832923583104517,-21.094504889053667,-70.0267090010279 ) ;
  }

  @Test
  public void test4816() {
    coral.tests.JPFBenchmark.benchmark06(21.88687169131363,-98.47013690734217,-10.344968417565909 ) ;
  }

  @Test
  public void test4817() {
    coral.tests.JPFBenchmark.benchmark06(-2.208266556277846E-15,-0.3768053162353694,-53.593306078862085 ) ;
  }

  @Test
  public void test4818() {
    coral.tests.JPFBenchmark.benchmark06(-22.102984028633415,-56.92370572174348,95.32643344988793 ) ;
  }

  @Test
  public void test4819() {
    coral.tests.JPFBenchmark.benchmark06(-2.218124574077494E-16,-1.0010610263018853,-5.0052077379577523E-147 ) ;
  }

  @Test
  public void test4820() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.10968188405955627,0.0514955123368867 ) ;
  }

  @Test
  public void test4821() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.17512828299360106,10.588215287853062 ) ;
  }

  @Test
  public void test4822() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.4242531932045863,-0.012234748689862705 ) ;
  }

  @Test
  public void test4823() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-0.9087628417304695,0.3456917028585876 ) ;
  }

  @Test
  public void test4824() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.1163089741113084,-3.141592652502618 ) ;
  }

  @Test
  public void test4825() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948957,-3.1415926536090746 ) ;
  }

  @Test
  public void test4826() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948963,-3.229509487011928 ) ;
  }

  @Test
  public void test4827() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.4252807966424834 ) ;
  }

  @Test
  public void test4828() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4829() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,1.7030632091072457 ) ;
  }

  @Test
  public void test4830() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,17.380722224206256 ) ;
  }

  @Test
  public void test4831() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-1.5707963267948966,3.141592654863369 ) ;
  }

  @Test
  public void test4832() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-27.955223086256815,-1.5707963267948966 ) ;
  }

  @Test
  public void test4833() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-31.75266482587662,-0.003716077980175164 ) ;
  }

  @Test
  public void test4834() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-31.83060750731631,10.515702239389995 ) ;
  }

  @Test
  public void test4835() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-31.83636193643399,6.776263578034403E-21 ) ;
  }

  @Test
  public void test4836() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-37.77850475759172,83.8570718681745 ) ;
  }

  @Test
  public void test4837() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-37.857241824976136,-1.5707956198579953 ) ;
  }

  @Test
  public void test4838() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-39.26990816986999,-1.5707963267948966 ) ;
  }

  @Test
  public void test4839() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-45.11756729290695,1.633296326794901 ) ;
  }

  @Test
  public void test4840() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-5.690114989408972E-16,4.024638972927967 ) ;
  }

  @Test
  public void test4841() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,6.712388980421198,-73.0108577510698 ) ;
  }

  @Test
  public void test4842() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,7.999441942597361E-5,-100.0 ) ;
  }

  @Test
  public void test4843() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-95.25771686265884,-1.5707963267948974 ) ;
  }

  @Test
  public void test4844() {
    coral.tests.JPFBenchmark.benchmark06(-2.220446049250313E-16,-95.8120923612707,-59.425884364046254 ) ;
  }

  @Test
  public void test4845() {
    coral.tests.JPFBenchmark.benchmark06(22.221415726031864,-65.88558637986208,71.75000102090809 ) ;
  }

  @Test
  public void test4846() {
    coral.tests.JPFBenchmark.benchmark06(22.2225585175609,51.94425980120883,-11.779678576282791 ) ;
  }

  @Test
  public void test4847() {
    coral.tests.JPFBenchmark.benchmark06(-2.2227587494850775E-162,-88.12873751251303,1.4841792540297154 ) ;
  }

  @Test
  public void test4848() {
    coral.tests.JPFBenchmark.benchmark06(-2.2416821552079728E-14,-5.421010862427522E-20,-64.68464237848553 ) ;
  }

  @Test
  public void test4849() {
    coral.tests.JPFBenchmark.benchmark06(-2.2436009990516042E-4,-0.33150390016972686,-82.32795607311319 ) ;
  }

  @Test
  public void test4850() {
    coral.tests.JPFBenchmark.benchmark06(-2.2444127733846047E-190,-0.014052351864991874,92.53165086805403 ) ;
  }

  @Test
  public void test4851() {
    coral.tests.JPFBenchmark.benchmark06(-22.53841713681743,76.73575960675021,74.3644604384481 ) ;
  }

  @Test
  public void test4852() {
    coral.tests.JPFBenchmark.benchmark06(-2.263919769706678E-72,-1.5083358099967739,-7.534358294687477 ) ;
  }

  @Test
  public void test4853() {
    coral.tests.JPFBenchmark.benchmark06(2.2646986435099903E-17,-88.27313860109378,-8.966826785866928E-17 ) ;
  }

  @Test
  public void test4854() {
    coral.tests.JPFBenchmark.benchmark06(-2.2761049594727193E-159,-1.5707963267948966,47.12388980384695 ) ;
  }

  @Test
  public void test4855() {
    coral.tests.JPFBenchmark.benchmark06(-2.2825398862752203E-15,1.5707963267949623,100.0 ) ;
  }

  @Test
  public void test4856() {
    coral.tests.JPFBenchmark.benchmark06(-2.28403798767535E-14,-1.5707963267948966,-53.112127014096146 ) ;
  }

  @Test
  public void test4857() {
    coral.tests.JPFBenchmark.benchmark06(22.9029276263212,-10.0578529176925,42.2619297449759 ) ;
  }

  @Test
  public void test4858() {
    coral.tests.JPFBenchmark.benchmark06(-2.2958874039497803E-41,-1.5707963267948966,35.185781159240584 ) ;
  }

  @Test
  public void test4859() {
    coral.tests.JPFBenchmark.benchmark06(2.3056617054808563E-9,-88.28282340122826,-170.67318234052476 ) ;
  }

  @Test
  public void test4860() {
    coral.tests.JPFBenchmark.benchmark06(-2.3314142767787892E-4,-45.551634908260986,53.4068064548993 ) ;
  }

  @Test
  public void test4861() {
    coral.tests.JPFBenchmark.benchmark06(-2.3324488677675095E-15,-1.5707963267948966,-9.398629716460064 ) ;
  }

  @Test
  public void test4862() {
    coral.tests.JPFBenchmark.benchmark06(-2.3481509007826944E-6,-1.5707963267948966,90.25311653320443 ) ;
  }

  @Test
  public void test4863() {
    coral.tests.JPFBenchmark.benchmark06(-23.532539792490454,71.47066517141133,13.67217829194712 ) ;
  }

  @Test
  public void test4864() {
    coral.tests.JPFBenchmark.benchmark06(-23.63319829581947,49.235772719056484,12.238495340439641 ) ;
  }

  @Test
  public void test4865() {
    coral.tests.JPFBenchmark.benchmark06(-23.798889276630717,-79.69382109916637,-94.36114812967398 ) ;
  }

  @Test
  public void test4866() {
    coral.tests.JPFBenchmark.benchmark06(-2.3841228693842827E-15,-88.41387991702554,-1.5707963267948966 ) ;
  }

  @Test
  public void test4867() {
    coral.tests.JPFBenchmark.benchmark06(24.083038459228163,-28.793450401451736,39.50864493503735 ) ;
  }

  @Test
  public void test4868() {
    coral.tests.JPFBenchmark.benchmark06(24.10349093124229,-38.49952471768907,-69.18024164883533 ) ;
  }

  @Test
  public void test4869() {
    coral.tests.JPFBenchmark.benchmark06(2.4292045437742007,1.515890790464281E-25,1.5707963267948948 ) ;
  }

  @Test
  public void test4870() {
    coral.tests.JPFBenchmark.benchmark06(2.429463031064653,174.0261303561188,1.5708112843669177 ) ;
  }

  @Test
  public void test4871() {
    coral.tests.JPFBenchmark.benchmark06(2.4295238035880486,44.9815355268033,0 ) ;
  }

  @Test
  public void test4872() {
    coral.tests.JPFBenchmark.benchmark06(2.4308975956739096,0.9320310012580482,100.0 ) ;
  }

  @Test
  public void test4873() {
    coral.tests.JPFBenchmark.benchmark06(-2.4335226997176292E-8,-1.5707963267948966,-1.5707757096281931 ) ;
  }

  @Test
  public void test4874() {
    coral.tests.JPFBenchmark.benchmark06(24.37654428724656,-24.467285930252686,18.38426021884527 ) ;
  }

  @Test
  public void test4875() {
    coral.tests.JPFBenchmark.benchmark06(24.44403119161042,-91.47668665110129,80.8366388859321 ) ;
  }

  @Test
  public void test4876() {
    coral.tests.JPFBenchmark.benchmark06(2.4456505675428662E-5,0.0199654487849472,-76.30936100716734 ) ;
  }

  @Test
  public void test4877() {
    coral.tests.JPFBenchmark.benchmark06(24.47978180566662,-35.40784100041134,59.583953593733156 ) ;
  }

  @Test
  public void test4878() {
    coral.tests.JPFBenchmark.benchmark06(2.450499149301469,66.17040346788687,5.63689032574039E-4 ) ;
  }

  @Test
  public void test4879() {
    coral.tests.JPFBenchmark.benchmark06(2.4602572044718385,1.5707963267948966,1.0313226673851252 ) ;
  }

  @Test
  public void test4880() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-0.7114160693635425,76.39633092877013 ) ;
  }

  @Test
  public void test4881() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-1.2209328308391798,1.5707963267948954 ) ;
  }

  @Test
  public void test4882() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-1.5707963267948966,-2.570796319978433 ) ;
  }

  @Test
  public void test4883() {
    coral.tests.JPFBenchmark.benchmark06(-2.465190328815662E-32,-39.15543682675633,1.5707963267948928 ) ;
  }

  @Test
  public void test4884() {
    coral.tests.JPFBenchmark.benchmark06(2.465190328815662E-32,-5.000740641930097E-17,-70.88801318228367 ) ;
  }

  @Test
  public void test4885() {
    coral.tests.JPFBenchmark.benchmark06(-2.4677579418653533E-178,-0.30498226177451476,-81.97090880378349 ) ;
  }

  @Test
  public void test4886() {
    coral.tests.JPFBenchmark.benchmark06(-2.4677579418653533E-178,-1.5707963267948963,-46.17890281956652 ) ;
  }

  @Test
  public void test4887() {
    coral.tests.JPFBenchmark.benchmark06(-2.4677579418653533E-178,-1.5707963267948966,95.99684536336622 ) ;
  }

  @Test
  public void test4888() {
    coral.tests.JPFBenchmark.benchmark06(2.478618465383318,10.47255120881496,-1.5707963267948912 ) ;
  }

  @Test
  public void test4889() {
    coral.tests.JPFBenchmark.benchmark06(-2.5026038689788762E-147,-1.1210541681563642,24.175411670586712 ) ;
  }

  @Test
  public void test4890() {
    coral.tests.JPFBenchmark.benchmark06(25.118160421555388,-55.37805239271909,-17.508349261297965 ) ;
  }

  @Test
  public void test4891() {
    coral.tests.JPFBenchmark.benchmark06(-25.21615764622382,99.22611806161206,-45.77020220989512 ) ;
  }

  @Test
  public void test4892() {
    coral.tests.JPFBenchmark.benchmark06(-2.525187258649797E-13,-1.5707963267948966,-53.77012192828553 ) ;
  }

  @Test
  public void test4893() {
    coral.tests.JPFBenchmark.benchmark06(2.5260305116853625,0.1954607383505261,1.6947718908946697E-31 ) ;
  }

  @Test
  public void test4894() {
    coral.tests.JPFBenchmark.benchmark06(-2.5306684723109863E-16,-1.5707963267948966,-55.25082117340039 ) ;
  }

  @Test
  public void test4895() {
    coral.tests.JPFBenchmark.benchmark06(-2.5379418373156492E-116,-1.5707963267948966,-57.2198427928838 ) ;
  }

  @Test
  public void test4896() {
    coral.tests.JPFBenchmark.benchmark06(-25.635598869670332,-33.84240752835066,63.10225061299025 ) ;
  }

  @Test
  public void test4897() {
    coral.tests.JPFBenchmark.benchmark06(2.583960746229296,1.2724963373977123,624.2097343709734 ) ;
  }

  @Test
  public void test4898() {
    coral.tests.JPFBenchmark.benchmark06(-2.6061990111226513E-16,-1.4908315587309728,-55.24924983189266 ) ;
  }

  @Test
  public void test4899() {
    coral.tests.JPFBenchmark.benchmark06(-2.6066313318916113E-13,1.9721522630525295E-31,-0.5096178163993969 ) ;
  }

  @Test
  public void test4900() {
    coral.tests.JPFBenchmark.benchmark06(-2627.0245811689233,0,0 ) ;
  }

  @Test
  public void test4901() {
    coral.tests.JPFBenchmark.benchmark06(-2.6273042258081883E-4,-1.5707963267948966,808.4609644882177 ) ;
  }

  @Test
  public void test4902() {
    coral.tests.JPFBenchmark.benchmark06(-26.281882121969005,-39.119027512095215,7.316041702262339 ) ;
  }

  @Test
  public void test4903() {
    coral.tests.JPFBenchmark.benchmark06(-2.6355494858076308E-82,-0.03387869370227048,19.06430328968061 ) ;
  }

  @Test
  public void test4904() {
    coral.tests.JPFBenchmark.benchmark06(-2.6355985991040446E-8,-1.5707963267948966,-28.27400155312721 ) ;
  }

  @Test
  public void test4905() {
    coral.tests.JPFBenchmark.benchmark06(-2.6771177316047374E-16,-1.57079632679484,-39.04791317689564 ) ;
  }

  @Test
  public void test4906() {
    coral.tests.JPFBenchmark.benchmark06(-2.6933872141597366E-4,0.36902314603386044,71.96484666352004 ) ;
  }

  @Test
  public void test4907() {
    coral.tests.JPFBenchmark.benchmark06(2.6961959287844777,28.016493953815687,65.5968434923651 ) ;
  }

  @Test
  public void test4908() {
    coral.tests.JPFBenchmark.benchmark06(-26.96806415795831,6.093560105592076,-74.00410046857404 ) ;
  }

  @Test
  public void test4909() {
    coral.tests.JPFBenchmark.benchmark06(-26.988864441341903,-44.6180649979858,-37.712415317090375 ) ;
  }

  @Test
  public void test4910() {
    coral.tests.JPFBenchmark.benchmark06(-2.7016136048916335E-225,-95.52687491166274,-1.5707963267948966 ) ;
  }

  @Test
  public void test4911() {
    coral.tests.JPFBenchmark.benchmark06(-27.03375561446235,-18.56148463700808,60.487759511652484 ) ;
  }

  @Test
  public void test4912() {
    coral.tests.JPFBenchmark.benchmark06(2.7080524951019167,34.72125784549421,0.5159195963551483 ) ;
  }

  @Test
  public void test4913() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-0.3402697265537584,-84.473120996668 ) ;
  }

  @Test
  public void test4914() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-0.7516654259171113,15.642370707042936 ) ;
  }

  @Test
  public void test4915() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-0.9924483300547094,-3.1474855653758524 ) ;
  }

  @Test
  public void test4916() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-1.4100528017312375,1.5707963267948966 ) ;
  }

  @Test
  public void test4917() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5705090240578987,72.23814977858531 ) ;
  }

  @Test
  public void test4918() {
    coral.tests.JPFBenchmark.benchmark06(-2.710505431213761E-20,-1.5707956179003224,-28.27480124592799 ) ;
  }

  @Test
  public void test4919() {
    coral.tests.JPFBenchmark.benchmark06(2.710505431213761E-20,-94.28366627310234,-31.465210561696622 ) ;
  }

  @Test
  public void test4920() {
    coral.tests.JPFBenchmark.benchmark06(-2712.956290416512,0,0 ) ;
  }

  @Test
  public void test4921() {
    coral.tests.JPFBenchmark.benchmark06(2.713807889759847E-4,-1.5707963283398294,186.90083771477555 ) ;
  }

  @Test
  public void test4922() {
    coral.tests.JPFBenchmark.benchmark06(27.20407454511775,-69.36748498535373,53.66084670379897 ) ;
  }

  @Test
  public void test4923() {
    coral.tests.JPFBenchmark.benchmark06(-27.267837787188753,84.88772322059145,-92.22526871645944 ) ;
  }

  @Test
  public void test4924() {
    coral.tests.JPFBenchmark.benchmark06(-27.30246674890499,72.55351728075212,63.59284613543261 ) ;
  }

  @Test
  public void test4925() {
    coral.tests.JPFBenchmark.benchmark06(-2.7397616862605038E-194,-1.5707963267948966,1.570796326794905 ) ;
  }

  @Test
  public void test4926() {
    coral.tests.JPFBenchmark.benchmark06(-2.7397616862605038E-194,-31.45061034936891,-0.31986930726689466 ) ;
  }

  @Test
  public void test4927() {
    coral.tests.JPFBenchmark.benchmark06(-2.742279100740624E-7,-95.81854410604404,40.8406022337659 ) ;
  }

  @Test
  public void test4928() {
    coral.tests.JPFBenchmark.benchmark06(27.464359477365946,-90.45283445508045,-46.561289901348516 ) ;
  }

  @Test
  public void test4929() {
    coral.tests.JPFBenchmark.benchmark06(2.7653885773885913,0.4723138568386835,45.553093477052 ) ;
  }

  @Test
  public void test4930() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-0.28642482058496743,11.194878657068102 ) ;
  }

  @Test
  public void test4931() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.2650050776802888,-3.457122546907049 ) ;
  }

  @Test
  public void test4932() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-1.419542707267087,-74.20757519314184 ) ;
  }

  @Test
  public void test4933() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5011847444099948,10.776550826464176 ) ;
  }

  @Test
  public void test4934() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948966,10.389777789935877 ) ;
  }

  @Test
  public void test4935() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-1.5707963267948966,-30.49026918480449 ) ;
  }

  @Test
  public void test4936() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-39.01928077366969,0.8958878847281634 ) ;
  }

  @Test
  public void test4937() {
    coral.tests.JPFBenchmark.benchmark06(2.7755575615628914E-17,-45.34125599703604,0.0 ) ;
  }

  @Test
  public void test4938() {
    coral.tests.JPFBenchmark.benchmark06(-2.7755575615628914E-17,-45.55309347704853,-7.8350192059164225 ) ;
  }

  @Test
  public void test4939() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-0.24295206803276745,1.5707963267948966 ) ;
  }

  @Test
  public void test4940() {
    coral.tests.JPFBenchmark.benchmark06(-2.778448436856347E-163,-31.787753870934765,-18.543109983675485 ) ;
  }

  @Test
  public void test4941() {
    coral.tests.JPFBenchmark.benchmark06(2.787606422027139,45.043809409431844,96.5118945996553 ) ;
  }

  @Test
  public void test4942() {
    coral.tests.JPFBenchmark.benchmark06(28.249128953873026,-98.04139835220357,90.14723761791285 ) ;
  }

  @Test
  public void test4943() {
    coral.tests.JPFBenchmark.benchmark06(2.852051196259095,1.5707963267948966,0 ) ;
  }

  @Test
  public void test4944() {
    coral.tests.JPFBenchmark.benchmark06(-28.543769640963276,99.08031840529014,28.062101313687748 ) ;
  }

  @Test
  public void test4945() {
    coral.tests.JPFBenchmark.benchmark06(2.856660485065831,-45.658538979203755,43.2732194885474 ) ;
  }

  @Test
  public void test4946() {
    coral.tests.JPFBenchmark.benchmark06(-2.8595041263424876E-17,-1.5707963267948966,99.58175116688969 ) ;
  }

  @Test
  public void test4947() {
    coral.tests.JPFBenchmark.benchmark06(-2.864650348331005E-144,-1.570796326794895,-1.5707963267948917 ) ;
  }

  @Test
  public void test4948() {
    coral.tests.JPFBenchmark.benchmark06(-28.738177352888414,-44.742591899590735,19.570624754747712 ) ;
  }

  @Test
  public void test4949() {
    coral.tests.JPFBenchmark.benchmark06(-2.8788631899622456E-4,1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4950() {
    coral.tests.JPFBenchmark.benchmark06(29.10033940127346,-86.1498257949278,-31.373367692569417 ) ;
  }

  @Test
  public void test4951() {
    coral.tests.JPFBenchmark.benchmark06(29.32796544495153,78.60990272972782,-85.9640592283522 ) ;
  }

  @Test
  public void test4952() {
    coral.tests.JPFBenchmark.benchmark06(29.604857335744555,27.11709076908575,8.880941931539724 ) ;
  }

  @Test
  public void test4953() {
    coral.tests.JPFBenchmark.benchmark06(-2.967364920549937E-67,-0.8778594579153038,85.50132947399933 ) ;
  }

  @Test
  public void test4954() {
    coral.tests.JPFBenchmark.benchmark06(-2.967364920549937E-67,-45.09253447320239,-45.36424195937675 ) ;
  }

  @Test
  public void test4955() {
    coral.tests.JPFBenchmark.benchmark06(-29.755875948328708,56.97340411487119,26.935666652471312 ) ;
  }

  @Test
  public void test4956() {
    coral.tests.JPFBenchmark.benchmark06(3.0020305893018673,-1.7613618354380236,-47.19529879112281 ) ;
  }

  @Test
  public void test4957() {
    coral.tests.JPFBenchmark.benchmark06(-3.0055196423445777E-7,-1.5707944522304145,-1.5707963267948966 ) ;
  }

  @Test
  public void test4958() {
    coral.tests.JPFBenchmark.benchmark06(30.173906891105077,-79.51582648520093,-35.011678170593456 ) ;
  }

  @Test
  public void test4959() {
    coral.tests.JPFBenchmark.benchmark06(3.037273722816472,0.7047093289066401,-49.7127007438837 ) ;
  }

  @Test
  public void test4960() {
    coral.tests.JPFBenchmark.benchmark06(30.39462472726032,-96.73850107488981,54.3797204055538 ) ;
  }

  @Test
  public void test4961() {
    coral.tests.JPFBenchmark.benchmark06(-30.445383826847376,-99.42030206297257,0 ) ;
  }

  @Test
  public void test4962() {
    coral.tests.JPFBenchmark.benchmark06(30.662682279460483,65.66782823325693,-55.45068098514994 ) ;
  }

  @Test
  public void test4963() {
    coral.tests.JPFBenchmark.benchmark06(3.0814879110195774E-33,-95.67794350744795,1.3764969276559769 ) ;
  }

  @Test
  public void test4964() {
    coral.tests.JPFBenchmark.benchmark06(3.084278419400448,11.24904176475674,-68.00305206187838 ) ;
  }

  @Test
  public void test4965() {
    coral.tests.JPFBenchmark.benchmark06(-3.1129898953693087E-32,-1.5707963267948966,17.230147806189315 ) ;
  }

  @Test
  public void test4966() {
    coral.tests.JPFBenchmark.benchmark06(31.257744105738283,-78.1981362322278,-3.469354688739486 ) ;
  }

  @Test
  public void test4967() {
    coral.tests.JPFBenchmark.benchmark06(-3.1282548362235952E-148,-1.5707963267948966,-1.6445208828945965 ) ;
  }

  @Test
  public void test4968() {
    coral.tests.JPFBenchmark.benchmark06(-3.133065268216754,0,0 ) ;
  }

  @Test
  public void test4969() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-0.4600417006246374,32.98344914457144 ) ;
  }

  @Test
  public void test4970() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.3418024212659063,72.39005479253689 ) ;
  }

  @Test
  public void test4971() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.4210854715202004E-14,28.96741745872653 ) ;
  }

  @Test
  public void test4972() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,14.475413508250803,1.5707963267948912 ) ;
  }

  @Test
  public void test4973() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948948,83.15866238575651 ) ;
  }

  @Test
  public void test4974() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948957,-22.862946674115758 ) ;
  }

  @Test
  public void test4975() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4976() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4977() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,31.483233627736833 ) ;
  }

  @Test
  public void test4978() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-1.5707963267948966,-91.73456754404246 ) ;
  }

  @Test
  public void test4979() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897936,-88.43479756679756,-1.636390789608394 ) ;
  }

  @Test
  public void test4980() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-1.5707963267948948,-50.846387214586 ) ;
  }

  @Test
  public void test4981() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-1.5707963267948966,-10.436860826487038 ) ;
  }

  @Test
  public void test4982() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-1.5707963267948966,68.27314039984219 ) ;
  }

  @Test
  public void test4983() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-1.5707963267948966,82.29668812584379 ) ;
  }

  @Test
  public void test4984() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897944,-95.81547183522989,-32.386389122905996 ) ;
  }

  @Test
  public void test4985() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589794,-94.33859903291919,84.5860366300314 ) ;
  }

  @Test
  public void test4986() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897953,-44.16864873779643,1.5707963267949125 ) ;
  }

  @Test
  public void test4987() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,0.2656846191737364,5.376300810317378 ) ;
  }

  @Test
  public void test4988() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-0.3242652435621079,-56.111629960767885 ) ;
  }

  @Test
  public void test4989() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-0.6705611189367985,0.32267977194208514 ) ;
  }

  @Test
  public void test4990() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-1.5707963267948966,4.586888615561763 ) ;
  }

  @Test
  public void test4991() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535897967,-157.08457878970881,-36.72312839727991 ) ;
  }

  @Test
  public void test4992() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589797,-44.4568260148072,-3.8897188809374796 ) ;
  }

  @Test
  public void test4993() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589807,-39.05803932301889,45.08958493196678 ) ;
  }

  @Test
  public void test4994() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589811,-1.5707963267948966,39.62673694473595 ) ;
  }

  @Test
  public void test4995() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589831,-1.5707963267948966,-88.4184727725461 ) ;
  }

  @Test
  public void test4996() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653589907,-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test4997() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535899303,-1.5707963267948966,-3.020464972121073 ) ;
  }

  @Test
  public void test4998() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535900476,-31.72247341917165,-1.5707963267948957 ) ;
  }

  @Test
  public void test4999() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535901075,-31.944803019725384,0.24731003586170922 ) ;
  }

  @Test
  public void test5000() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653590119,-1.5707963267948966,9.101515257452508 ) ;
  }

  @Test
  public void test5001() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535908083,-31.81282150499689,-1.5707963267948966 ) ;
  }

  @Test
  public void test5002() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653591859,-38.83960255555091,-100.0 ) ;
  }

  @Test
  public void test5003() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535920313,53.4908047860187,1.5707963267948983 ) ;
  }

  @Test
  public void test5004() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653592669,-1.1188359746592216,-71.36675824071473 ) ;
  }

  @Test
  public void test5005() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926535952803,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test5006() {
    coral.tests.JPFBenchmark.benchmark06(-3.1415926536018244,-1.4332059142691547,-135.52723295002244 ) ;
  }

  @Test
  public void test5007() {
    coral.tests.JPFBenchmark.benchmark06(-3.14159265360218,-1.5707963267948966,3.589112920199465E-16 ) ;
  }

  @Test
  public void test5008() {
    coral.tests.JPFBenchmark.benchmark06(-3.141592653617166,-1.5707963267948966,1.5707963267948966 ) ;
  }
}
