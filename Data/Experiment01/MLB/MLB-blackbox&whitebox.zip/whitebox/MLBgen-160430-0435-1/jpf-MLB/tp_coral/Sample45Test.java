import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
//    0.6722996777689119;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(0.0842325452313939,-752.1185941433461,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-646.3074774355175,22.400280372465303 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-647.1380122948584,50.07529622070891 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-648.2629973496129,19.136380409727394 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-649.7609361372291,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-652.0395595433992,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-657.8819384127796,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-658.0352742268834,88.5537727067099 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-658.8037921118765,100.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-658.8129843213981,68.17440727130733 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-659.7192723236877,100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-660.5462434525786,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-660.9008318868358,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-662.244156848801,100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-663.0234853661077,56.38311306888079 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-664.3636349501226,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-666.169068758574,91.53138532350206 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-666.9718666908309,100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-667.0983576569326,76.5586747959363 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.263041931368,100.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-670.7639519822717,100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-671.5640605477823,8.014857014626223 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-672.5168796806516,100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-673.7294197784337,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-673.8007825889916,93.24838423587352 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.108641369672,100.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.2020410742443,100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.2622709851569,100.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-675.403492905351,100.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-679.4584956187077,1.7537339159252099 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-681.3256399524654,100.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-684.5761231330679,100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark45(-100.0,-686.3893458800006,4.099997276694992 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark45(-101.4240881289156,-660.2107501138803,57.64514368238565 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark45(-101.59048474381437,-669.2771244297923,92.30767995500736 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark45(-102.5708008717981,-670.4213347522193,59.01697009283805 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark45(-103.12577763236412,-650.0057591547534,80.4325597894684 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark45(-103.42883067626946,-642.7400100030671,100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark45(-106.72985602108932,-647.6976052946493,35.60762014363874 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark45(-110.27377727759993,-669.7436031484647,3.597124877361196 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark45(-110.90726492067736,-635.2233478814425,74.83656377790231 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark45(-111.32216574635095,-663.9338866496662,31.738890428717212 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark45(-111.37997716468898,-654.5431035641375,53.36919973590969 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark45(-112.01614489675583,-655.1775630275392,79.14462354893604 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark45(-112.53534959954919,-645.2661855979638,36.695303341211485 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark45(-113.0540980975094,-662.9481868582737,13.90701936182586 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark45(-113.24192410214737,-633.5461110692833,26.258268772699168 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark45(-114.10915690625411,-645.5446338941633,80.14755130220078 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark45(-114.6804994089801,-639.3510254494316,7.77411666702163 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark45(-114.78336698050035,-638.1300382637947,7.844873771695305 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark45(-115.77943214039428,-657.547777706598,74.50017613196496 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark45(-115.80179071708832,-647.8761664327942,39.609622146198916 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark45(-116.05184792013442,-631.5742380919291,29.028926668393694 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark45(-116.7691280895427,-640.6152476620094,21.071535398574426 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark45(-117.2755832167041,-696.5303170146359,2.122914196195154 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark45(-117.70096629164337,-631.971904944185,87.37420715849927 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark45(-118.7619394869762,-638.4557844374502,65.19148356883466 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark45(-118.88420614451697,-686.1849954398474,17.18713416190498 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark45(-119.07763379649258,-630.5051329627876,95.93617783636984 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark45(-119.35970059462042,-633.8330976693358,57.34991669261217 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark45(-121.20882865325018,-635.527900023986,28.11418132966267 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark45(-122.5047463805199,-644.9906409701905,46.92975573536873 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark45(-123.07357396536656,-638.0787910404664,60.07628606885922 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark45(-123.1879196446298,-683.5135618741916,100.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark45(-124.79313953654541,-623.9315236255767,10.259977812687836 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark45(-125.17843706289894,-644.5105575761419,34.33455740354202 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark45(-125.52531891575755,-625.0694782239541,72.0514104358158 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark45(-125.85700912872338,-622.4544884217175,99.2966915877831 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark45(-126.16278028900699,-644.6986940165851,0.5311957176440103 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark45(-126.4491246306115,-633.5244583486317,100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark45(-127.2254478712022,-623.0786836756645,88.56978963276534 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark45(-127.3790270607109,-683.3951385451128,58.48566046053395 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark45(-127.53414078760923,-636.0989424357504,94.07514099866344 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark45(-127.83781212904469,-677.0502985106668,23.39701731303812 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark45(-128.16426737896754,-708.0170117295798,36.75122087365173 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark45(-128.31026832175775,-639.9566707357706,55.22597087648941 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark45(-128.61199303314044,-621.8314130973589,26.804809103252808 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark45(-128.69455021967224,-619.0767610593085,28.863183825800434 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark45(-129.04072336698115,-620.8343676131071,28.418434744140995 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark45(-129.12133508449236,-639.5850390390556,92.61329890059739 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark45(-12.972706185678405,52.27604993769057,45.3879585945495 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark45(-130.13427207256913,-638.4787971524504,89.54866007608328 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark45(-132.27512584428007,-641.3477625718165,47.78977929380858 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark45(-132.79818218293127,-619.8420451819532,3.628077915541695 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark45(-132.9648246272867,-653.1926534396797,37.79614998595807 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark45(-133.36187730496263,-622.5171090212416,54.938781193623186 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark45(-133.58309880377647,-638.8467508502152,48.787806884150285 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark45(-133.9311394574774,-657.5842776762149,5.769193016892743 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark45(-134.32495162788402,-627.1045923033934,6.30816759018235 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark45(-134.47229363325243,-616.7698651747371,80.43498223974578 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark45(-134.54371441300046,-611.9780322103394,16.589221596138586 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark45(-134.6328219423866,-690.7508330219121,54.38187933791315 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark45(-134.9874700930122,-615.6393110516693,20.742238735265843 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark45(-135.95787794655797,-727.8531004457158,53.21474460213352 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark45(-136.04622000368096,-617.2022189382662,95.93552480869572 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark45(-136.05945470031338,-630.2522565284846,97.14057785427065 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark45(-136.92658446393702,-630.3602319924397,1.3681178451026892 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark45(-137.40883692304686,-641.8284621887499,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark45(-137.61997738679187,-612.6153092960343,56.53451107728006 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark45(-137.68206987686264,-617.6567284358623,51.57844567348661 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark45(-138.05616802632187,-635.4917305787142,94.35525498476295 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark45(-138.17123025239957,-639.174232193381,2.3275818448031913 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark45(-138.77968242884575,-634.872581813961,45.58844736976749 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark45(-138.82894801879186,-622.3478005746526,62.48077291443221 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark45(-139.25702646637097,-620.0305039581729,32.835021985703804 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark45(-139.3124355205332,-624.5729544396693,76.83170928530768 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark45(-139.81431550479476,-664.4019904535014,85.6366104884701 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark45(-140.51724442578578,-607.0853077709185,55.05245381524685 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark45(-140.54931214024657,-618.0127592439882,47.38433946328243 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark45(-140.83596739030668,-633.0394188170583,53.733270969748645 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark45(-141.07865000619245,-652.1073311543179,100.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark45(-141.15430716626054,-611.6649406117124,19.224194190488575 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark45(-141.72634574797917,-632.5403821338248,65.49852184640073 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark45(-142.7713916346502,-649.492633361286,67.90451313099243 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark45(-142.78303965183656,-609.6444715609605,66.36804159085801 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark45(-143.02523693957326,-653.2997504355861,40.61201015996275 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark45(-143.1612842442849,-624.5230492030092,50.723786488940675 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark45(-143.19745865998655,-621.5410452645216,50.076801195485444 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark45(-143.33359072733893,-665.8669276392746,100.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark45(-143.35461827118496,-687.0044637173379,75.10835985537767 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark45(-144.3276574154656,-629.5708624540072,78.04700083507939 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark45(-144.36062509260933,-659.8361562006788,73.68896854239756 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark45(-144.6061409943521,-644.3565869663706,59.59892211745466 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark45(-144.6322765385712,-606.1679431660237,34.20439225756934 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark45(-144.6506039201804,-663.6079211243541,100.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark45(-144.74894608192147,-625.6390755956367,16.30375563390953 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark45(-144.81697792496132,-632.3369479967703,11.47816637553403 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark45(-145.0563239624459,-646.2208851382203,34.36755028319746 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark45(-145.43858923530715,-649.2393383218076,100.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark45(-145.90545164723335,-666.6926241586142,62.6647154165652 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark45(-146.08116097587643,-610.4375172416811,22.93480192878154 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark45(-146.16934332192042,-604.7164043852929,85.77214269520951 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark45(-146.54698439717075,-622.6750851041838,90.28305626751 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark45(-147.18920028783546,-635.8358199021457,85.85413560073044 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark45(-147.34619244878806,-616.7146904617534,69.08954398046657 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark45(-147.72551136388947,-611.994235042242,12.3768362990145 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark45(-147.83549507947387,-618.7921467089675,50.764791268096246 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark45(-148.19884588236965,-604.1176501184547,24.314435307284498 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark45(-148.57168164506942,-621.9666521721409,100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark45(-148.7464309031294,-655.7428135864945,27.449655943984467 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark45(-149.07179643194593,-629.3027434303434,18.92833858633464 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark45(-149.18716765650763,-607.8561847667335,14.004186551150582 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark45(-149.27056472375295,-611.4999137934672,100.0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark45(-150.07821157676992,-614.6280014564728,37.77532640675582 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark45(-150.12230453036003,-597.8680453942432,16.113911115289 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark45(-150.19240442115716,-635.8693217936172,100.0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark45(-150.57281014925167,-659.6322473273203,19.843514934653214 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark45(-150.65187233888366,-611.3070042226448,45.697201886004294 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark45(-150.67901901417594,-634.4294107281243,44.7559527183463 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark45(-151.30659428651003,-594.8203259493157,96.13274768890747 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark45(-151.50110143977875,-673.4183759260699,68.6800480266512 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark45(-151.628229883726,-608.7537595522524,43.15401673434337 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark45(-152.12162671721165,-596.1653187393016,1.945563120067618 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark45(-152.32218916012565,-612.0581545631838,10.19392063999338 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark45(-152.4878464275515,-596.697135918615,21.53854172340533 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark45(-152.62413841980037,-611.7179667460725,38.83391526526776 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark45(-152.62728280971237,-594.3936457446005,32.619171244462734 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark45(-152.79221717266677,-595.7763861999792,81.11921065877382 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark45(-153.10113669358583,-618.1281216739034,68.76857117907636 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark45(-153.32514316780345,-629.0435562855663,100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark45(-153.42527514751623,-614.3215186043244,8.9018449308154 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark45(-153.58550679975062,-608.4739450398539,20.71790492806747 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark45(-154.1310925170946,-615.5889913711549,16.082618529319717 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark45(-154.5709548232691,-622.6585070106638,100.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark45(-154.7428767128437,-634.0745077507528,83.80886307051702 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark45(-154.7662352269559,-636.0257448804649,85.10724467770464 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark45(-154.76942773492135,-626.195009453228,23.645955421216925 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark45(-154.778289870836,-600.261588459226,86.20291247206708 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark45(-155.23744253840619,-624.269403601448,44.24553923190095 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark45(-155.5386156544304,-605.0083966234268,35.76487748820537 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark45(-155.5774539989507,-596.8024414410617,34.75307779037581 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark45(-155.63414300481156,-593.7336273718295,39.224102051317146 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark45(-155.84567787691043,-608.3952539171564,100.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark45(-156.0911773150106,-591.5440769591539,54.72856762464181 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark45(-156.28375483973662,-701.3678065544437,19.344878648234413 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark45(-156.6694935289927,-606.7681976253857,59.87195742633398 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark45(-156.7646645480745,-605.8189331673991,35.40848671732739 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark45(-157.73092922532825,-612.1497549219447,64.33371657858277 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark45(-157.74061963248337,-588.5378299101573,15.716100701009708 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark45(-157.7504599670054,-599.870536573558,8.508885708659491 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark45(-15.79451025391485,32.69907799612889,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark45(-158.31378001304157,-598.5243660866663,94.77114655850124 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark45(-158.6509806520262,-615.47525635045,100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark45(-158.6657112883632,-608.6365976538788,39.683077777182774 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark45(-158.82900297973728,-605.1918679388386,57.30407975973469 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark45(-158.9325530317365,-600.9348445074262,59.53476228684039 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark45(-160.32688378253593,-597.8758761387651,74.54899584467643 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark45(-160.46140998851814,-586.5601239648668,12.605214212209546 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark45(-161.12251637594,-654.1180141801299,100.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark45(-161.22289897593873,-585.3589173817608,60.53796529657728 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark45(-161.23182829155155,-596.61017935079,3.5119897889408094 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark45(-161.2459673557804,-632.6360132653459,82.30655110301072 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark45(-161.67107072146507,-601.9747534202722,29.71839550763923 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark45(-161.71538171439275,-614.5717926951156,100.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark45(-161.82829856416794,-596.0443724786265,32.0327075644893 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark45(-162.0789149607577,-638.9874841517336,16.67443051582842 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark45(-162.70759847514285,-586.0467449037695,100.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark45(-163.10147087036654,-607.6466862518101,47.96480563318627 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark45(-163.1295767406644,-590.7805944586476,54.135932491994026 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark45(-163.16722908468924,-607.7136970861628,78.71030194564295 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark45(-163.3876410399838,-591.8217448425762,51.762787390737316 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark45(-163.45765100538333,-588.0484140863094,41.1101067903206 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark45(-163.4847808094371,-637.9288545965702,100.0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark45(-163.68332549533207,-607.0381510871645,69.90087889375303 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark45(-163.98147849053862,-620.2284314552237,92.49588648879907 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark45(-164.07174231932683,-621.0386572655125,2.6810332871416875 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark45(-164.4789787099183,-589.5022357623898,39.155753503892726 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark45(-164.4920351295575,-593.6307339714616,35.117201646857026 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark45(-164.6343600003965,-585.4038800907316,2.4597446485611414 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark45(-164.64866460721703,-584.2715787750839,78.3592227476739 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark45(-164.88709089213413,-599.8125020721151,69.72429334158733 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark45(-164.9138943140781,-606.5069765031079,61.450303352745806 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark45(-165.07860672636372,-587.5700841738654,100.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark45(-165.1674968034207,-580.8404262518604,8.204425407250639 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark45(-165.2932554859533,-612.2497483948017,16.894802260822317 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark45(-165.42813363149943,-586.2518085875466,100.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark45(-165.49957459662346,-608.2046224762411,45.304063834198416 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark45(-166.19494295879454,-583.6236332814268,92.67058106089036 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark45(-166.37014739411845,-629.7845034372436,80.51342595183729 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark45(-166.40250411489626,-676.8684666936967,68.200368658444 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark45(-166.4883269588981,-623.6217997518364,42.937209779767095 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark45(-166.49258581326382,-661.1875384112087,100.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark45(-166.69615259086268,-612.6522465845751,86.83509459947604 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark45(-167.2777629045028,-613.7387137117759,10.487851384442763 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark45(-167.51055501483296,-597.7854660101079,3.044778446324713 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark45(-167.87252349290046,-634.9310879384514,91.69082441301188 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark45(-167.95806483237197,-620.5644624075222,52.76109366814589 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark45(-167.98036142949485,-615.3420508959331,100.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark45(-167.99199094802563,-585.4700215498183,58.39039505812568 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark45(-167.99485746103767,-657.4846878611276,17.94120870158082 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark45(-168.00051026322046,-582.024874541743,100.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark45(-168.0557820887742,-627.0419934272595,74.6975730553009 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark45(-168.30220987183012,-582.8292004712212,24.26855368144396 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark45(-168.94317123073964,-580.6414216622732,64.3531556026335 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark45(-169.7507893438218,-612.5016569182093,42.27669868444994 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark45(-169.77811928449628,-596.4804058138292,85.89460806358204 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark45(-169.8879565015975,-576.1774914159065,30.229449556365125 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark45(-170.09608866504,-577.415803375228,100.0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark45(-170.2204507647629,-581.4567681360369,25.330032002242646 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark45(-170.33538672336013,-611.0126219741519,38.604564935761175 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark45(-170.93866693044168,-608.1698514118069,28.633005103211588 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark45(-171.1588116262033,-586.7887104677569,100.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark45(-171.60337604220368,-619.5157301024809,7.105427357601002E-15 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark45(-171.62170200758428,-578.7138780217554,88.79923385265815 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark45(-171.6304781134121,-578.3242893788456,100.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark45(-171.79664448955566,-583.954060637394,7.105427357601002E-15 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark45(-171.9364241789545,-580.0792720417147,13.980672814878119 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark45(-171.9824146335377,-601.4944951943953,94.9918951925153 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark45(-172.22589707640003,-581.7450960442318,48.86241791326859 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark45(-172.85338620936398,-584.1150840846097,100.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark45(-173.00662390306152,-653.2667354116339,23.816292452230243 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark45(-173.0950108316577,-611.5607342222713,77.32077629302526 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark45(-173.32542367784615,-589.1377526046826,100.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark45(-173.71284713054808,-589.9549356620747,85.50731549764313 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark45(-173.72892308009327,-577.6989516154032,26.018163371588116 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark45(-173.8863272410046,-604.2478480533962,50.58138204036561 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark45(-173.88759165630563,-591.1753538450068,86.24935675886124 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark45(-174.6621025375405,-584.795752827909,33.76244536306697 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark45(-174.70701818591596,-611.5222396784579,99.0695352761231 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark45(-174.85401514264095,-636.876583093146,9.45356984247907 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark45(-175.07347867687287,-593.0082669140519,7.929824390942315 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark45(-175.19401503431027,-589.3402857714567,39.42643498480015 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark45(-175.54206693802342,-600.026886203721,58.85533231036729 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark45(-175.58161126838604,-625.7727895028378,44.177361129547165 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark45(-175.59696557835377,-582.0207310423433,45.760644413510335 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark45(-175.62692856274307,-611.1027705731184,20.35153092419688 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark45(-175.63445919336655,-573.7603134298236,100.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark45(-175.67349209315668,-580.4849122205203,36.8105639217988 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark45(-175.97184856945296,-610.4359460281282,14.97309396599573 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark45(-176.2142697234519,-571.7409474532075,7.677285398613236 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark45(-176.610558136897,-590.7168468323888,5.953720816441404 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark45(-176.63250012385552,-600.6741233402371,22.278009577552837 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark45(-177.1205952537716,-576.6026141636048,47.43228422619282 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark45(-177.13887791423798,-578.3544777456407,100.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark45(-177.21681092629,-569.0916615626277,73.72181091050649 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark45(-177.70991269230802,-635.1627083915738,69.04022533259487 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark45(-178.06179792311636,-581.7194127087632,100.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark45(-178.0955826995527,-623.6798788813261,36.611118046737715 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark45(-178.31703415699639,-595.0871642335982,91.54947420595141 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark45(-178.92327993640703,-573.3398454854295,35.382291808950924 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark45(-179.116085591721,-580.7664185680728,100.0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark45(-179.18576502916747,-600.6186468375739,2.1595015867335405 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark45(-179.20018899679567,-595.2496268658745,100.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark45(-179.3718775169663,-610.8537759892953,100.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark45(-179.41221021900785,-592.2705578175585,84.3759700794385 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark45(-180.20702975850563,-578.0501589633329,21.53025041531183 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark45(-180.76748703632518,-576.177043717205,87.21091343888085 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark45(-181.25236848965284,-580.0753393567633,98.38781784931237 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark45(-181.26410319151148,-573.4738516329343,100.0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark45(-181.47182907390462,-574.7168442858031,44.58906003264867 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark45(-181.60921724818508,-611.0257547221046,29.562114157302634 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark45(-181.85646093121548,-587.5555752746461,13.875924292343257 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark45(-181.92173404310677,-586.2043531531715,51.53167449047834 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark45(-182.2643595760524,-606.581988462778,63.90810864892799 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark45(-182.65188939596484,-583.3002155120814,10.095962413206806 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark45(-183.13246904400242,-568.4236567909008,16.115723951186254 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark45(-183.22979700808557,-564.8103225977401,100.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark45(-183.38393992939277,-605.2547725056581,28.45494906493974 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark45(-183.6773312305565,-598.6156913529211,100.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark45(-184.1099459185105,-635.8853097037461,100.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark45(-184.53676664101036,-569.9570485144001,76.12512555124744 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark45(-184.74597751253935,-633.7598258141634,13.805708384299393 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark45(-184.76078951307622,-597.2757502058389,85.67142869493316 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark45(-184.79052150284105,-577.4175427984773,85.99480406099957 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark45(-184.794691692239,-621.7217127646167,100.0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark45(-184.84323017839847,-562.6812579302373,100.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark45(-184.86281066289786,-564.5957502215538,43.20655818732084 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark45(-184.93908575381408,-574.8967161305409,3.332201200955609 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark45(-184.9549365189355,-603.2831210735379,7.153880100547852 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark45(-184.98521885276844,-561.9074846120656,60.280589755087334 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark45(-185.17526205764017,-606.3362344318373,26.540643701966076 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark45(-185.2624846161647,-580.3759537965523,100.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark45(-185.3176419292489,-566.5187364833995,50.977908372362435 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark45(-185.42344901799495,-607.2911814384677,100.0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark45(-185.63010372361794,-598.4537475725027,31.69703879594954 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark45(-185.77740490317905,-597.8565217748808,3.491260876570479 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark45(-185.8668917914999,-567.1329859018446,70.26372178111095 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark45(-185.88426102024295,-571.3195535303424,100.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark45(-185.98728322349558,-561.2706433869006,100.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark45(-186.1532600982748,-600.6511799791444,34.628657042072604 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark45(-186.18051809586248,-566.1828559140591,4.395473846991905 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark45(-186.2696359830921,-631.0815851050962,72.78344398487923 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark45(-186.28964360846948,-583.8767986198277,3.267306160500837 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark45(-187.23176690662333,-616.8916403922053,87.62789238510499 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark45(-187.26491795934388,-598.525414882303,100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark45(-187.35203313942236,-582.1735362243531,2.2298842832280314 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark45(-187.67926146500457,-620.1798897346944,90.58796962230687 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark45(-187.85813864720174,-569.0498189504414,49.08123341477523 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark45(-187.8618436007632,-579.0828442994953,59.75245692630281 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark45(-187.88763803258516,-613.7935800723385,25.510569380197424 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark45(-187.92791233245532,-563.6030820068337,100.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark45(-188.42589612159856,-638.461486945269,35.83920549109604 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark45(-188.4512638219608,-561.1419181387816,32.47328190124938 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark45(-188.5352585272432,-603.3337476330012,100.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark45(-188.92811526347288,-583.2104610003927,100.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark45(-189.17045399315663,-581.5772388394436,37.52137898339129 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark45(-189.26505892991722,-558.263976435271,38.84003360635876 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark45(-189.40819880670946,-599.9745163619723,1.5601573031779736 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark45(-189.41511667400522,-582.219767096926,100.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark45(-189.4792878660298,-561.3095432089506,100.0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark45(-189.66728476833214,-568.1992240877496,100.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark45(-189.69009032343132,-576.2822387866427,42.37651702109352 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark45(-190.48828171363624,-569.420110169607,58.767979361145805 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark45(-190.75510400698025,-569.6514884813287,100.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark45(-190.7701068786864,-571.9460186671246,63.021689330748785 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark45(-190.84438687466158,-564.0485847530822,71.33797725320207 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark45(-191.08161870335016,-610.6172069117109,65.0891146469331 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark45(-191.10366480769727,-582.1808572904424,100.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark45(-191.23871321443488,-570.8364750693539,8.396721715932799 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark45(-191.3686314501355,-558.7188318078432,36.305565329283695 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark45(-191.5048641017643,-594.9250786412475,42.979458695949404 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark45(-191.5364626607697,-577.9924525493732,100.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark45(-191.84449757853267,-587.2952683416049,10.479004234452518 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark45(-192.13354820778764,-695.7474466969911,80.4048217116108 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark45(-192.51628488981112,-559.9270900180462,83.42723126057194 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark45(-192.839017835836,-557.8760433377506,100.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark45(-192.87615667386325,-605.4887960500827,54.14048503366712 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark45(-193.1252999305489,-556.5545857665139,60.314388116050225 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark45(-193.2164160954763,-560.0136842720826,1.8845404332989517 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark45(-193.28995968032928,-594.7513289269257,36.357244041926776 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark45(-193.29352751161798,-570.6584180368089,44.064193860100545 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark45(-193.75824416586374,-565.7979458298478,92.22148271390012 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark45(-194.08225638370465,-553.555245561286,74.12457637886365 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark45(-194.09304375639698,-560.2884907802822,16.098418535303225 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark45(-194.2762131792502,-565.4110243670162,81.80535600379645 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark45(-194.3922931107764,-605.7525927509685,100.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark45(-194.4208173660421,-565.7740588877724,27.626173778563953 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark45(-194.57969261247382,-556.8456674728029,100.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark45(-194.78434635672767,-626.6771483403461,100.0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark45(-194.8138549925505,-565.5875451237514,97.80750454076792 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark45(-194.87023574656075,-552.0074244495424,86.50499683444227 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark45(-194.91343241759753,-560.7111143768661,100.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark45(-195.37217428721976,-553.3304115554517,100.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark45(-195.39930459718715,-582.954639367726,100.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark45(-195.72574717420056,-550.8569239674113,31.04114740572396 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark45(-195.82555428792392,-573.8435907881457,80.78266471109436 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark45(-196.0842157564797,-589.6392169603345,44.21339971067617 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark45(-196.30710903344107,-550.916850700118,100.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark45(-196.34217630640728,-557.7988149032324,58.34507933867138 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark45(-196.65119765220288,-558.4467592912115,100.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark45(-196.7201414711994,-550.1832153492194,100.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark45(-196.7408336682934,-564.1241747103193,100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark45(-196.97399528021455,-555.0123568777175,54.98779068395004 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark45(-197.13378193039,-564.5301298157902,32.331596476692155 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark45(-197.1497004270232,-569.0188984706831,12.153994495332768 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark45(-197.27468349916404,-555.8928643033025,2.1565908558671225 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark45(-197.48611575054875,-619.1174384397086,81.90600261265487 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark45(-197.5106363604592,-565.040942175751,68.01454727404541 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark45(-197.51574120438423,-620.2681862662151,19.84096293948086 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark45(-197.52412450811576,-570.0715194992208,46.28280345180164 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark45(-197.5597437857934,-565.13456365719,53.19158673566932 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark45(-197.56835933627383,-580.2658223359587,52.79064478730726 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark45(-197.6630746233089,-556.1295645021149,21.74279568590218 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark45(-197.67642720567156,-615.9476244410355,100.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark45(-197.9401302074444,-571.9517608881315,5.848437494148911 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark45(-198.106050671501,-578.1516356271968,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark45(-198.30322599783247,-586.6206461448112,43.18339389603841 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark45(-198.33712096319823,-567.7250000943928,100.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark45(-198.44173913782652,-577.6636169230294,50.07735848282755 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark45(-198.52647628624942,-548.5816930648648,34.48612229825642 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark45(-198.63586030436392,-550.1709792690884,81.98887849207838 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark45(-198.70349204907387,-554.8009098843943,100.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark45(-198.87928329815549,-601.5732246173724,72.2056305986473 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark45(-199.1332517418929,-621.6860596032814,55.49821448824429 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark45(-199.2091972426022,-552.6619393264127,76.46474526545995 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark45(-199.21575176863794,-555.9241934649664,19.184651722244794 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark45(-199.2253648885069,-625.6284370614114,5.498255851842121 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark45(-199.77679350611578,-554.5182211852873,100.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark45(-200.25505276519095,-558.0895730451335,23.62544611691635 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark45(-201.1415018670105,-605.7936582956132,68.8840410095556 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark45(-201.6744072853462,-566.9445900209068,55.9249394617085 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark45(-201.79809586795614,-606.9950196283053,7.426692214344001 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark45(-202.41446112944496,-577.8737669564669,18.49863058702877 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark45(-202.50586474517465,-577.1499306022715,54.12305971098786 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark45(-202.73959360538467,-631.3348212144446,27.038914476123438 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark45(-202.88218309982227,-557.7502010471534,10.117999399077632 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark45(-203.04235543192132,-562.7544542448612,88.96482170801724 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark45(-203.100743636672,-543.6776003888872,89.6682955805376 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark45(-203.1336118437864,-585.7291091165929,86.38946381080544 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark45(-203.1920462783695,-547.862689711094,62.31207045730147 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark45(-204.10456042807215,-571.8199912953055,88.87707207462446 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark45(-204.15902420145676,-583.5241328137669,6.870253497355463 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark45(-204.523631808217,-548.3762264728337,100.0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark45(-204.8484590071832,-546.0475613555187,11.060172736678481 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark45(-204.94210455928123,-545.6117038973613,43.692595047834345 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark45(-204.98053682656067,-573.4758676467234,90.98271878173148 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark45(-205.09269941835527,-544.2050443677255,30.794774342346955 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark45(-205.59936212158317,-550.912935236886,17.694847699091383 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark45(-205.6222562037126,-583.7791998030203,15.029947307500223 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark45(-206.22351304232384,-569.0024025586437,65.36340959417143 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark45(-206.25645554427135,-589.6029080915579,78.30465276501994 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark45(-206.56022364463848,-542.5415022495336,46.27157762065096 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark45(-206.8715215879476,-553.6018149143899,15.710967817310078 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark45(-206.88400534701654,-644.07359261975,95.03727710871058 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark45(-207.00033297066238,-552.4201964189577,38.20445209332783 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark45(-207.44341165826722,-584.3316867879389,100.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark45(-207.5034152508617,-545.3471468005554,92.48294873976309 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark45(-207.57628697946944,-545.3469753651973,90.59919646392521 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark45(-207.82861269234084,-553.4902688104589,32.94163517884655 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark45(-208.19026588744512,-540.6288257969906,16.710076470437187 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark45(-208.23145400758,-543.8821613888822,35.22177961721263 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark45(-208.2711077291229,-586.7840036092196,8.910910252403596 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark45(-208.29596631893537,-545.8594051831004,34.72328170242528 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark45(-208.37156763531385,-589.9991966541545,94.90462225601743 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark45(-208.44129431110233,-561.5780922004021,82.27296204906486 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark45(-208.48542174642313,-553.7665229985888,61.68995874107655 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark45(-208.58738018125746,-538.5923783516668,94.93295353877394 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark45(-208.61077164760496,-555.0395983205641,2.7574355905170904 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark45(-209.2704179656402,-544.5802426425527,14.803178852899464 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark45(-209.4222540656512,-553.988313064423,1.9185956111112006 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark45(-209.51024980413936,-565.2965675624531,89.68959734223714 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark45(-209.52371626557914,-542.8609291735502,12.12319923670222 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark45(-209.63435576965168,-536.7563815821077,100.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark45(-210.1861524112157,-538.0165711531957,64.68034405287372 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark45(-210.19048895020535,-596.3230519153396,7.749149494382522 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark45(-210.72001706147537,-539.714085002881,51.18084766923343 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark45(-210.90780889563388,-550.6470222508752,60.03875179787531 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark45(-211.13414785669875,-556.898347455705,63.80335284623683 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark45(-211.9821441268653,-538.5189968008383,100.0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark45(-212.02036202300346,-553.960927859117,61.13790668477773 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark45(-212.03944650768275,-564.1270571858429,35.75629238078844 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark45(-212.36697813748287,-536.8910545510669,29.70023883878838 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark45(-212.74709118598048,-547.2760204772962,72.127456535963 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark45(-212.91602087117647,-542.3242799737584,82.48780110467015 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark45(-214.0193773708948,-543.7478469995535,73.3539809145802 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark45(-214.15266652782714,-536.5154494136923,84.93607231770577 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark45(-214.53226619998628,-531.6035013193942,99.41382513472183 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark45(-215.49617156453314,-608.4176941047273,38.544543044444 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark45(-215.57087794706123,-546.9142805933799,76.58512565915044 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark45(-215.65576137266507,-574.8037066383986,78.7411693755235 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark45(-215.91232604644827,-543.6445807638856,97.99555200226555 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark45(-216.37029541603835,-565.3053280321449,78.19963133109283 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark45(-216.37324689936506,-592.3324750077427,24.7460543994775 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark45(-216.67640920118228,-538.3135837865943,69.3963173974239 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark45(-216.76885165947002,-562.9553214349543,57.889686192620076 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark45(-216.8594024489489,-578.279548843472,23.05069606880798 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark45(-217.0055251007564,-533.1061068749214,96.49674049330372 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark45(-217.01961605460212,-609.1067337916226,84.31780770339043 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark45(-217.03453700770433,-557.038652123033,70.16605590947387 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark45(-217.08772402040898,-552.6062461656311,1.3866805871570307 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark45(-217.1356615519862,-570.6455318091498,2.131538382182626 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark45(-217.60187940682292,-552.4444364456025,24.462129244560856 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark45(-217.6150272244205,-583.852340917275,91.74207220671653 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark45(-217.85241345756165,-533.2366313965603,58.357167501938505 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark45(-217.88779518650972,-548.7964830815108,32.27991574374914 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark45(-217.92395720445654,-551.1783324761008,48.21658549910677 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark45(-218.08121254324288,-563.2143046362938,82.07611131291927 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark45(-218.10697264371134,-579.2833579481397,94.83187247502022 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark45(-218.31100456562277,-551.6032592373623,35.23942944608217 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark45(-218.41508798727727,-534.165924421007,52.11728008618064 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark45(-218.45816379314007,-566.812122267035,9.23362490155381 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark45(-218.87707379637985,-545.0316249870407,65.38369597098074 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark45(-218.94939062185406,-535.1017837950766,48.99692256534237 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark45(-219.0183913300561,-528.3730568465617,86.51836375827827 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark45(-219.0818525588009,-537.5821840712775,44.32511192546738 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark45(-219.082539365405,-553.604666492615,100.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark45(-219.28650227676482,-558.3618080355675,84.05197215360326 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark45(-219.37039794593287,-526.8088146530276,39.51793384363097 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark45(-219.42835430308963,-535.7963686799028,74.35671420970105 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark45(-219.6830860689342,-550.485532290251,0.17549148235937295 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark45(-220.18422139852134,-568.2890171282854,92.38731784428882 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark45(-220.20471439903844,-526.8979792301054,74.01641805521143 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark45(-220.60769168606015,-573.7714601759214,27.197010391886394 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark45(-220.8946225369546,-573.9605314541078,86.13235089102588 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark45(-221.3751027866555,-552.2871527541434,45.53179848626664 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark45(-221.75873878177435,-537.3911910744499,49.6929326206683 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark45(-222.09075498219437,-562.1531124371468,63.20479258566493 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark45(-222.3060339806467,-552.9232086669776,82.16534969956183 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark45(-222.3644068957057,-525.5875429705198,7.983776122731712 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark45(-222.4688858835794,-528.2341746984007,3.5671209069602696 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark45(-222.59472464687454,-523.6064893077087,49.561332958893416 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark45(-222.64785051380278,-556.8365755694275,30.932250626928806 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark45(-223.02734862528646,-582.7914078937534,13.214117576440685 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark45(-223.32266331419544,-541.8048355795,100.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark45(-223.3948385076203,-524.0225317705091,18.3962579301741 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark45(-223.40706623144595,-553.6074442938747,100.0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark45(-223.49246677143142,-532.753674528759,91.26501862097308 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark45(-223.59600942206512,-537.3014689531726,25.53658466426026 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark45(-223.6801322337857,-529.900022949578,100.0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark45(-223.7326807366859,-523.1333316989962,100.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark45(-224.05303645910848,-522.6091282275631,100.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark45(-224.34702375146966,-532.3312561301498,20.191970586484658 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark45(-224.55764777210243,-531.8150252768722,78.39776599104133 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark45(-224.59096884390345,-596.326097348046,43.679210676471456 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark45(-224.62689619240078,-534.7555877483339,97.83441606791158 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark45(-224.69774821788081,-521.8968904135328,59.09432067027342 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark45(-225.00894983812373,-524.5378062254911,22.039652428677286 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark45(-225.1323092605023,-560.6859305715476,56.041298468794 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark45(-225.22153756215812,-552.0977390004035,43.381285209280435 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark45(-225.45295801900357,-565.1142033874878,100.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark45(-225.70154808364913,-588.8736788799915,31.717488071212358 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark45(-225.89845144090398,-525.086909063667,86.1718815103614 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark45(-225.92699880123283,-587.9860352344754,1.0555721653470869 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark45(-226.02404972495913,-539.0685329136594,59.47519439447058 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark45(-226.38592130944318,-594.9202450876661,69.31089416544529 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark45(-226.70348204871104,-595.110811464122,80.10763286811647 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark45(-226.79872414890536,-536.8817044430999,98.53847775879498 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark45(-226.85749153453023,-563.5335834375693,64.47965314976256 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark45(-226.91213847964332,-520.3647446759163,95.4969550738576 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark45(-226.96124048604793,-567.4506197857428,18.99948357396228 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark45(-227.17583417616493,-557.6032095047206,8.220001349901864 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark45(-227.31628913642666,-519.4705944823096,15.901360599080135 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark45(-227.34352216468693,-521.084954961484,34.89511363521828 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark45(-227.3909373205327,-584.7790044053473,86.90052990159629 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark45(-227.40829025914124,-520.5468223006894,100.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark45(-227.56527812652368,-565.1091985307414,65.21831817628609 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark45(-227.74788041665187,-542.0731526168566,14.131990230342069 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark45(-227.79447412810936,-609.9404046061728,27.690258360597113 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark45(-227.80154701904004,-555.2854632033215,78.30948350572268 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark45(-227.8719470816238,-558.9683177866447,100.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark45(-227.9753198304801,-547.5420763322544,4.166444902846209 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark45(-228.16627974482927,-564.3175902984418,0.177756725008976 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark45(-228.26855469852285,-526.2478727179113,44.20271674960071 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark45(-228.35851513908347,-567.6633904213475,98.23384737258974 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark45(-228.43416274843838,-527.4476471926677,25.839267740638732 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark45(-22.871089819685793,-55.24906953852804,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark45(-229.00463819409947,-539.6956706598869,100.0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark45(-229.0605527634426,-525.7687774924333,48.54055497458785 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark45(-229.1833927404495,-589.8469223044771,99.90320670829698 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark45(-229.46567972440732,-546.5378557374905,7.4595189725328765 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark45(-229.85945203773957,-525.8957284200333,42.94828807703996 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark45(-229.9807457630169,-521.0001590960708,24.465996439750157 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark45(-230.27998389053727,-582.4446136537299,100.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark45(-230.46914489342177,-527.4811765058919,45.08149204918422 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark45(-230.499468363956,-531.3725046276521,49.72365333241589 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark45(-230.59020477092082,-525.059880229594,83.53191404200544 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark45(-230.61705976477919,-529.6469607016069,40.64219438776172 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark45(-231.3339270217695,-557.1162739142528,80.78337746641242 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark45(-231.39697987479252,-631.9280720395847,0.8279048929393298 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark45(-231.4983873611965,-522.1022192971827,3.959587648923943 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark45(-231.661638834,-544.5147084436546,6.034019095710107 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark45(-231.70033456232852,-520.0138937719505,67.81490068814949 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark45(-231.8759007051441,-535.6591263963435,30.60548423411572 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark45(-232.0251373871013,-560.5712032998681,34.256198421998135 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark45(-232.07449975167782,-530.1210588993738,100.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark45(-232.09126196636026,-516.2658791216486,90.20247782741671 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark45(-232.0971136330834,-546.5875965019162,13.598743736672418 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark45(-232.19621748405288,-533.3028226528172,100.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark45(-232.26132919473275,-535.1255585724034,66.87076853792234 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark45(-232.28254122966274,-532.1721552054546,41.37472972683631 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark45(-232.3249966992505,-553.9438656140006,11.491596018376253 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark45(-232.32734160720338,-523.5583791930118,98.70245860041456 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark45(-232.498187166098,-536.027998231804,42.14538784400335 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark45(-232.5066689743454,-545.5587292938894,98.66992515745238 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark45(-232.58967970642757,-572.8824381933247,15.580276484932853 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark45(-232.59635973884178,-561.9091483122327,45.88456101362024 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark45(-232.67066639710703,-519.4271987005617,-91.2548610943019 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark45(-232.71920302735157,-533.0199651693093,52.48742402658897 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark45(-232.9073406287182,-520.2470902378375,31.02611116603893 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark45(-232.93253480344507,-548.8339742745133,58.12004697004741 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark45(-233.47820756999204,-513.9694099662336,59.92097120832864 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark45(-233.63937710611958,-516.3174918120121,38.57944134526099 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark45(-233.77901436771293,-514.7713429551642,60.912829523511704 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark45(-234.08874340433468,-518.5819858149796,50.991921042673965 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark45(-234.32041171645352,-519.1461528810348,4.721775430204687 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark45(-234.35289764298534,-568.0715033060783,63.05828897963087 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark45(-234.42751963386675,-564.138788691663,20.21890203262498 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark45(-234.4980375944046,-535.1837466365802,42.414820523082284 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark45(-234.50219662903694,-551.7184910544107,77.0773882122244 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark45(-234.58780237268508,-552.6851841856233,100.0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark45(-234.6547625443686,-563.9663962290572,83.73274324728109 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark45(-234.83852671554132,-535.9972610613843,54.51580110556753 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark45(-235.35041589636964,-531.1960882965077,75.02462138019777 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark45(-235.9463530385046,-514.3643274056527,1.5442932667653224 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark45(-236.00520465482066,-515.8866012442681,77.46741919065812 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark45(-236.18626374398832,-550.4507605035512,92.59810674193002 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark45(-236.3146044488874,-585.5741521510618,51.65866343748107 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark45(-236.4446625861014,-542.6525532792758,40.95085536787974 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark45(-236.57530186295787,-519.412317868893,96.60950169789368 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark45(-236.66538529869854,-515.8526207642556,100.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark45(-236.8743386356633,-528.7975917106627,65.23025187285597 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark45(-236.94651147730528,-555.9051876923596,94.80384409546042 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark45(-236.9783117747303,-526.5122616356498,12.886056855731098 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark45(-237.33641505242235,-526.4609180106293,32.296563288123025 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark45(-237.8112933622245,-562.9699789152202,2.059949437272323 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark45(-237.8727004732047,-514.3393494674269,16.55728150312146 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark45(-238.0299321940853,-531.6610740043064,100.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark45(-238.07903080818738,-519.4912961115098,45.284499671431945 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark45(-238.41392224925553,-549.3900056100135,62.464513890062506 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark45(-238.46967205919157,-551.0661688399549,57.490602327908306 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark45(-238.48870100250494,-549.0028942655783,77.18137649930563 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark45(-238.51637039487548,-507.64945245480925,100.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark45(-238.58554222618525,-551.8297204771624,46.44744427414213 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark45(-238.6817999547822,-528.6541638915669,20.89845937192368 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark45(-238.7188106804895,-555.4094366971894,100.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark45(-239.00360345459765,-508.7379026844517,79.40056842814553 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark45(-239.2397795394949,-516.8868625168485,94.59067984511108 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark45(-239.3311436442284,-507.1599267531319,87.68402298081867 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark45(-239.6308560011237,-534.1819816692156,87.53157066109878 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark45(-239.76188188453645,-588.7426846137976,70.7569872041417 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark45(-239.8617139118323,-529.8852779314584,57.03796897615706 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark45(-240.08568457725318,-522.080216126216,23.975250553836844 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark45(-240.10500617639312,-573.1463386504223,59.550189538117785 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark45(-240.1131086246738,-535.8878143768993,41.53867600392613 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark45(-240.42784665410272,-532.7573798634753,44.36648314956449 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark45(-240.44667817696384,-526.2380250567714,100.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark45(-240.8864071322067,-546.6687465146587,96.78881746462793 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark45(-241.00812855115294,-549.2708298625921,51.4323767977985 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark45(-241.3490352261359,-517.60715470232,66.33682117009897 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark45(-241.43603045066828,-549.570352357691,5.470258719871637 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark45(-241.55447156918225,-563.238515041981,42.408687910517585 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark45(-241.58988685363897,-570.4955304013358,39.3356175080383 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark45(-241.59857818167345,-562.6264689060417,63.91730979113953 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark45(-241.7361519336478,-518.8179928012395,90.69594555070853 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark45(-241.90815284682492,-578.1173051625009,40.88962465575449 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark45(-241.97205536061955,-542.3829859198772,63.68924369302846 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark45(-242.0270025499854,-531.1601877564503,37.341299950586574 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark45(-242.06217076429675,-529.9364295667307,45.756271172763405 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark45(-242.1690360016309,-522.2551073905065,26.375935722839444 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark45(-242.22010096037485,-526.5623350735259,91.33458096300515 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark45(-242.80226519912082,-540.2063740316082,8.462389018404593 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark45(-242.94927785967653,-514.0794225376992,23.70457364266916 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark45(-243.2793544614196,-506.95338392708305,89.3386444973095 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark45(-243.40597874546575,-557.5954388619148,64.05887869186873 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark45(-243.5429415503706,-507.422547266268,41.02927024923757 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark45(-243.6461622280467,-553.0975196620101,100.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark45(-243.74459671709718,-522.4373157288662,58.000973148299636 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark45(-243.7556887179269,-547.6143394624515,94.12959822479286 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark45(-243.83556757651724,-513.86395198659,21.05262536912032 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark45(-243.88349433217786,-516.3344195417318,71.07222066853338 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark45(-243.90270194047625,-543.8319860318283,17.01399028556179 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark45(-244.20492558173441,-503.97035228564226,30.12981759191399 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark45(-244.21373687470714,-554.6897882116524,52.61061702053783 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark45(-244.25834426239334,-521.0515475499808,100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark45(-244.34973730921544,-571.764374734623,100.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark45(-244.43452151693535,-544.3432996698226,54.05543996426269 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark45(-244.54428569273352,-507.95648317282445,15.501891848696332 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark45(-244.55178979891014,-535.1841877861751,26.44894873705232 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark45(-244.65322143153128,-511.37289520072386,46.367172033649325 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark45(-245.08323350561795,-506.70805302702297,90.21229198768137 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark45(-245.09250972849478,-528.8514736911599,1.4195528080408195 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark45(-245.2173505944203,-545.8855034481273,64.90481797561361 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark45(-245.58774601487258,-511.4282198874689,100.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark45(-245.62193017781738,-534.318232064431,53.106775103029776 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark45(-245.6759159925878,-509.4686867420864,37.34900996836507 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark45(-245.67991008645183,-524.0861830358226,33.53007518871206 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark45(-245.7879988413906,-507.3569069779857,64.8554791552931 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark45(-245.89288901016474,-554.8547699853679,76.74623898440049 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark45(-246.01211281457654,-575.4227799353984,19.96832079845096 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark45(-246.07691846743512,-538.101149083158,98.09717081878786 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark45(-246.11361257568504,-507.6896508189245,2.5890474898865454 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark45(-246.4484864555801,-508.17797497881014,88.87244331454289 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark45(-246.54130140371217,-514.092790837513,84.82013084253964 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark45(-246.54317958489503,-560.1738748487883,100.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark45(-246.64135305652937,-563.9423552658366,42.93550842440891 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark45(-246.78202752256536,-571.1857882880588,18.12633438899156 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark45(-246.9973731921039,-523.9370289767102,97.0841425105121 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark45(-247.09259039176683,-506.76737664353124,86.62449397906437 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark45(-247.17234151387757,-503.650067588345,67.48745250726901 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark45(-247.20014761111972,-500.3338189890502,29.840245117025887 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark45(-247.35069347968266,-520.2690463092466,100.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark45(-247.40147692287547,-528.7134280665605,9.83269316666879 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark45(-247.46229528560983,-506.8636744756272,52.68152711184405 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark45(-247.4767984972492,-534.9689542843784,22.215596590011828 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark45(-247.5662878277053,-551.4242666227909,69.73014381587572 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark45(-247.68364368694637,-508.34123689217495,54.17428885902984 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark45(-247.8093898958012,-614.385905569178,22.697683053989934 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark45(-247.8483037391111,-542.367955527813,100.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark45(-247.8547148936531,-542.5787546651372,46.91034606570784 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark45(-248.04623203617922,-499.6860202052197,96.54745107141375 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark45(-248.18459532163837,-500.90442637042236,54.03060907095275 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark45(-248.54806705338214,-508.33899095413545,100.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark45(-248.7449162921129,-538.689772501256,90.60676582512704 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark45(-248.95902577784543,-527.7766890335786,51.193265899014705 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark45(-249.0084175484466,-525.1970689609877,100.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark45(-249.02932160662266,-605.2449363572927,-20.39804596726836 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark45(-249.08480542336528,-532.6741389962398,66.27149901801748 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark45(-249.23357645969998,-515.6061695444854,31.78123069781094 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark45(-249.2662303517684,-507.4629721286857,9.517371351727988 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark45(-249.27298729767966,-513.1986840037745,100.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark45(-249.6170406059626,-549.4234079892849,97.83943753555901 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark45(-249.85520964380197,-510.47313603950437,77.7765508095967 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark45(-250.13181300489464,-526.3048943403995,57.149773315896454 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark45(-250.1394058778081,-562.7799701289609,100.0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark45(-250.38062336337362,-500.9319673382175,64.86995682354365 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark45(-250.47901162050425,-513.281738721371,8.8991713269243 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark45(-250.71537729932245,-509.0791312466914,5.496153315731675 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark45(-250.78323681397782,-499.1444453485677,94.17231944968637 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark45(-250.79840604210995,-518.6730820660702,88.63790794089104 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark45(-250.81628804446711,-502.5125945393505,15.083477619667136 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark45(-250.8388485335256,-536.6537514240802,59.06912412928327 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark45(-250.9405892194341,-509.7309929424292,60.85128086241437 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark45(-251.00745445061636,-526.3564094545119,80.11508371751808 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark45(-251.0871872609348,-504.19883878071226,78.06409383099827 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark45(-251.10985852456224,-574.9812545988666,9.910045424893639 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark45(-251.25720526763965,-531.6080830045572,94.21219275622661 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark45(-251.5110241336692,-500.26092697212266,100.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark45(-251.5305983799497,-500.03534439421696,54.911345781041746 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark45(-251.67316779510566,-500.16990649638103,14.365411243591225 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark45(-251.69848684327027,-524.2609449917722,4.754391404671196 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark45(-252.0514989162231,-512.947593886187,16.600280366326587 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark45(-252.09864414761478,-499.78702461262037,19.9078233584453 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark45(-252.17600564390182,-569.5510373478547,100.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark45(-252.32596041757583,-496.33204519669476,66.52070244442615 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark45(-252.4660128212724,-509.5645736533278,50.73637970093313 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark45(-252.5213600021469,-504.46475417775315,16.483768227822658 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark45(-252.6105643650033,-527.2523460009271,100.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark45(-252.70537089693553,-493.3457652242023,52.08870847021788 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark45(-252.92588520061753,-542.1879760620203,1.2615446115465971 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark45(-253.0942090496345,-515.1445769167408,76.1757191228981 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark45(-253.22141045072394,-539.5551994707494,100.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark45(-253.23385213716594,-514.2524214493482,33.69720063971519 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark45(-253.25467164143998,-505.27470890040706,71.82333368428002 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark45(-253.27290447323344,-509.5259077646644,96.91148124966188 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark45(-253.2797096591199,-498.19337372663836,82.46659930767407 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark45(-253.33459351324996,-566.5766035288258,58.58888966568179 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark45(-253.35173580161427,-512.5053465137656,46.17999419800924 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark45(-253.3577682690023,-522.5089129876657,28.08220467906827 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark45(-253.4691259965034,-513.9754998125537,70.24369074994613 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark45(-253.88658833931535,-572.3718997758571,6.897864449079179 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark45(-254.00572587150828,-557.9297909997788,97.70027581140616 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark45(-254.0322772425525,-492.0681103748221,76.33009766868341 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark45(-254.1865510234702,-540.7143320342283,11.414045007576473 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark45(-254.32337005926075,-521.0959411947234,98.14656650459435 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark45(-254.35365720356816,-501.34527668302434,8.448726981238025 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark45(-254.42289207622593,-504.94420192169275,44.6945181397119 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark45(-254.430359701161,-522.5032441163356,63.230389567217344 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark45(-254.4432175244861,-513.8717338465493,44.7838184289906 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark45(-254.45966872690707,-514.7402788343039,96.3684642283734 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark45(-254.48955467436554,-498.1121272068032,23.401867854443168 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark45(-254.5014887995765,-533.7487538402235,77.3154992229617 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark45(-254.54808430396088,-494.84621588073236,100.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark45(-254.68615627991213,-520.810134402901,13.097204072880047 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark45(-254.76242341105913,-513.9245199248011,18.270132274355745 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark45(-254.88410559897144,-518.4344850852086,31.560375217496954 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark45(-254.99791391231196,-504.892198451314,18.640908375532916 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark45(-255.27374613915748,-533.827296633592,45.65241555894909 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark45(-255.42918952788588,-504.4998832319069,70.78795471406801 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark45(-255.4392777704338,-511.61325499845793,77.83027874912807 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark45(-255.66535365601257,-511.50333754835265,100.0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark45(-255.6820983346742,-499.8606471855957,100.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark45(-255.7887295825691,-512.2359489936382,90.7322276897134 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark45(-255.84299103255984,-571.151083124785,100.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark45(-255.90024189875086,-527.5560772805426,100.0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark45(-255.96216424081882,-530.4035941682715,44.25322155242628 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark45(-256.7327415704501,-555.5927976048307,5.644507160305039 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark45(-257.0022331113727,-521.7239657611188,61.54839908484402 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark45(-257.0237869414069,-564.95274266758,99.07079840147787 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark45(-257.11520669447935,-494.47111181934133,100.0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark45(-257.2128676922673,-566.8870265426875,26.502059220746645 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark45(-257.2944789251941,-573.161072920954,93.13496266444204 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark45(-257.32656588252905,-523.0803679552001,81.89047327474265 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark45(-257.3820468071804,-513.4079137544809,51.56010951708237 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark45(-257.404110754758,-497.89178174822996,64.94617544579427 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark45(-257.6713666714361,-512.621472386319,54.70083501242513 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark45(-257.83182788483714,-497.9364972333319,55.22659947065608 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark45(-257.9375992876407,-498.6778519950407,78.49390341041087 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark45(-258.30187785805805,-490.7790452911511,62.71459172708006 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark45(-258.3065957343913,-556.255306392178,48.79272092251381 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark45(-258.5109127573609,-560.366039370382,58.77275166918287 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark45(-258.6317559765003,-488.53517904955163,91.55968306876693 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark45(-258.7115772758922,-513.109880513441,80.48557237556196 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark45(-258.9581116374481,-520.6652440339741,13.045272014633412 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark45(-259.0954089986283,-492.2569646270041,88.9220939188277 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark45(-259.16025676599304,-508.47672633085074,100.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark45(-259.4023442349721,-493.7460193706859,31.73236352359075 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark45(-259.4680311924885,-527.8383433471596,10.955243475265306 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark45(-259.46960852641286,-500.91791406399204,13.349745617710695 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark45(-259.90125121826736,-537.6288005558133,6.349022752590599 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark45(-259.9035695491945,-487.4819373655238,65.47822461992135 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark45(-259.9949354630866,-627.6885022333686,80.29427290633629 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark45(-260.13671305766707,-503.487077731321,100.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark45(-260.4074434202939,-520.3158862300323,35.56445786983741 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark45(-260.5697563803642,-492.288938898665,47.54422828627341 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark45(-260.6611935316448,-509.4037386844497,78.30815946984663 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark45(-260.9759034354099,-500.1937926670919,100.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark45(-261.14184758762445,-487.0406896454387,1.831389317949383 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark45(-261.38425853004503,-518.7798866569326,23.81478111742301 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark45(-261.47974911751623,-509.524344428743,14.857100609753402 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark45(-261.6474470484377,-495.2181927781497,1.322479511928762 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark45(-261.6571698792508,-497.45171675908887,71.97988862037982 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark45(-261.7144376010962,-518.6659054838586,66.74837705082948 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark45(-261.77155847005906,-543.442131396108,55.609460235533575 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark45(-261.9715700160724,-495.07010102600503,100.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark45(-262.01781595778215,-499.47727963205523,4.440892098500626E-16 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark45(-262.0948255511879,-531.9260271228989,100.0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark45(-262.21223937167304,-490.78243025126477,100.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark45(-262.47718275272,-484.66635135148306,89.4109295078558 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark45(-262.49081248170745,-514.4693264747052,50.26286133320872 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark45(-262.65697463756936,-505.73075945475426,65.45040285190146 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark45(-262.80026580801973,-507.5999813450921,70.42951019196786 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark45(-262.84035528754157,-534.5817192055096,100.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark45(-262.9873182479138,-503.66684160491434,11.716190806611309 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark45(-262.9883141806792,-484.95941686025344,100.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark45(-263.06354501250263,-512.2586196831581,48.764236094173015 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark45(-263.1268250315024,-490.72441333361655,8.743918768555076 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark45(-263.1740279231603,-512.9245431561825,100.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark45(-263.25328209453943,-496.9598925303379,34.50763462412459 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark45(-263.5791439582323,-506.1266244187065,1.752613922364595E-5 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark45(-263.59130808209966,-504.58038266779874,1.573882999042624 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark45(-263.73264792157977,-505.64201921695195,25.88686040360149 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark45(-263.8038912406071,-487.43742396136184,89.876175046481 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark45(-263.8235948081263,-507.2096523810264,92.6725902667722 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark45(-263.93608179864253,-504.83118422914276,89.83574782785598 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark45(-263.9397480624867,-489.53698865202256,71.14252602659522 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark45(-263.95571415603786,-499.3661971487368,100.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark45(-263.9720793289493,-485.71337057769574,57.52911544455402 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark45(-263.9885748579148,-545.8027836177922,100.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark45(-264.13942169113005,-553.5534887705121,22.668832969579043 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark45(-264.14085063458464,-487.60751819696367,100.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark45(-264.14659045608175,-499.02676839972594,100.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark45(-264.27284066377683,-518.447889150768,100.0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark45(-264.43298038285855,-559.5939062344513,9.374079690644365 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark45(-264.43423200457727,-482.02134733793656,100.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark45(-264.60626794857814,-489.80087562424234,95.26146946996872 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark45(-264.8977571241483,-489.90629178119946,19.303592677286247 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark45(-265.1626666273436,-497.57473219308616,89.93134291060497 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark45(-265.5012732105711,-536.4529154123338,71.95369962574085 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark45(-265.6960460917946,-514.4443433917545,29.903024477317132 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark45(-265.72778489135806,-482.59978032010116,55.467069218836514 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark45(-265.74431297226994,-538.6377022297576,100.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark45(-265.877200779313,-508.9281782032202,42.81947436249894 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark45(-265.9051827715885,-552.768831868027,51.43371000179036 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark45(-266.04378678897706,-518.7370913360883,96.25151188730149 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark45(-266.0900906355196,-513.1020160808664,34.8238971662048 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark45(-266.1677643863962,-481.4697825248211,21.23781288084885 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark45(-266.2630099858918,-536.4436640186437,10.44237185604102 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark45(-266.2891443411828,-497.1922576552609,91.60311875084349 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark45(-266.39410693464777,-481.5380955090437,9.177455060584492 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark45(-266.4503802197856,-479.78874929903634,73.63157094868373 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark45(-266.81390440684953,-532.1812561018613,4.668285374910269 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark45(-267.05788754460343,-488.9071874368023,72.73896932704059 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark45(-267.26113329298767,-483.3465198707897,37.173335217977126 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark45(-267.3407819148379,-498.06281253424464,1.8620211408729972 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark45(-267.53561970903746,-486.203544600698,4.779568633684178 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark45(-267.6575372062672,-513.8456450330547,16.335086283036844 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark45(-267.73268703270173,-479.9010748963718,100.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark45(-267.92138137813856,-503.9854667437199,40.31159205346938 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark45(-268.003940654486,-494.07157290829247,67.26244462378244 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark45(-268.0907636483185,-509.69788973220136,67.5203600690233 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark45(-268.1396786595181,-484.2562434939622,35.63951239211346 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark45(-268.15879058521205,-500.9019871085895,99.24181983968779 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark45(-268.23004597568246,-482.6545230920325,100.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark45(-268.7901140063299,-496.12951805907386,10.374014850246184 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark45(-268.81946689230864,-513.2434276806523,36.20255124779362 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark45(-268.98869245289774,-556.8658646654811,81.28866757400189 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark45(-269.02835693469143,-487.4544194614098,38.92428018629579 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark45(-269.12942462658157,-525.2834343321458,100.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark45(-269.19432649483804,-494.1680805116732,71.22528741975404 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark45(-269.2282386831083,-528.5891553978709,98.7828657588355 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark45(-269.51872967307395,-502.1682451720931,50.24127690511017 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark45(-269.5728116871103,-494.78374130014004,15.024229841583676 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark45(-269.6523381791897,-491.57057542307336,29.657731128665517 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark45(-269.70969079097546,-476.5198675790296,66.4571745768437 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark45(-269.8539341319028,-514.6806300934427,76.31789785918886 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark45(-269.8933542940549,-514.0264211473701,26.210635720518155 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark45(-269.9523465280705,-503.63421046469193,11.473343451379563 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark45(-270.12140991107384,-484.96837076224074,100.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark45(-270.1341798652507,-476.0816646333769,27.991193753618518 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark45(-270.18671345204865,-506.44860508840975,13.670430417931698 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark45(-270.3168591780062,-509.61473916118933,100.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark45(-270.9201531680815,-476.7532759841289,100.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark45(-271.00854089904925,-479.1769731842064,23.564629045600796 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark45(-271.06369644996744,-504.27958245066714,96.18281050919956 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark45(-271.25307356333445,-512.9276970254839,100.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark45(-271.3498623899393,-507.6580940769295,12.13361920242005 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark45(-271.4456379420774,-479.91306199848884,21.438780639530535 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark45(-271.5082383930802,-623.8876915916248,25.172879308733314 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark45(-271.53858795960923,-505.4769409131459,29.37130199480697 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark45(-271.8630412368202,-503.0753608159854,3.552713678800501E-15 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark45(-271.9381518989408,-474.9081493994614,20.036227695275414 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark45(-272.0464767209071,-475.5667334475683,14.292395481044196 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark45(-272.07304709202526,-488.6330265724049,100.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark45(-272.19623979826054,-494.5548646861716,46.81351244443363 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark45(-272.20156828070844,-523.9295927718164,46.23248726131891 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark45(-272.22288908782934,-484.6659123118315,100.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark45(-272.5570191005106,-558.962127003656,43.47309164458355 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark45(-272.63836501369803,-533.9171966260661,73.37245444444227 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark45(-272.6849126800901,-483.99640284254167,100.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark45(-272.7050270003895,-515.4077070719068,6.379882169392985 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark45(-272.72454702769113,-530.7433662460095,100.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark45(-272.76360767676186,-475.5704898373919,1.3871129715342162E-15 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark45(-272.78348309238265,-551.1274673394493,8.98467549245872 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark45(-272.7987691455014,-486.74385752440764,59.11764548673594 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark45(-272.89614630840344,-496.8102292699442,66.91891212815355 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark45(-273.005075682401,-473.5108436949646,45.428973851839686 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark45(-273.0284574014959,-492.8066833296255,60.93855091912242 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark45(-273.0409191096957,-476.915182659099,100.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark45(-273.156749391603,-474.63473701944645,12.737867590478572 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark45(-273.19977109495443,-488.19624829639105,34.65225012534128 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark45(-273.2896770446665,-550.0741682200442,95.5819408948953 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark45(-273.33534122304695,-487.78351272062525,100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark45(-273.7596431164851,-545.2497901595689,100.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark45(-273.82062836624806,-495.7491794310889,7.873323879216116 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark45(-273.92951430773,-533.5577959433951,51.15163265675665 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark45(-274.0853804070532,-503.22182873069687,63.920262819616084 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark45(-274.4386868768724,-474.05251906265346,52.55943204516194 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark45(-274.60098552380504,-510.3110779495418,54.67974129327669 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark45(-274.80710633890845,-502.7877238889097,43.8748623491183 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark45(-274.9822156556251,-519.8684648425965,8.06595574155213 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark45(-275.0835864532403,-522.1214246975302,88.2749420217805 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark45(-275.33178410234257,-474.31064041952027,80.1036920976812 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark45(-275.457745277364,-472.35484747908095,31.527857998944313 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark45(-275.5283434780105,-473.4046272475883,89.68297157081761 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark45(-275.6451178150796,-516.6428500314206,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark45(-275.9651206645566,-504.0211891969889,11.686051315709008 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark45(-276.30528094469446,-513.8286578014785,83.92855593534547 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark45(-276.35983219812937,-489.37711528971,34.19642419034713 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark45(-276.3893387984667,-472.40980038007285,100.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark45(-276.45751313075084,-532.4795877659524,0.361182123902239 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark45(-276.46082147980707,-485.25667628979744,69.9775031075985 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark45(-276.50103234413524,-476.311654714205,89.6137606548663 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark45(-276.6688143216939,-497.894417132194,25.547494579630253 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark45(-276.72759862638713,-561.9537692413626,54.359406942831754 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark45(-276.8059094171336,-478.52632210601803,95.03948020505203 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark45(-276.8193338319942,-472.9270063659885,47.916808357027264 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark45(-276.98242673804424,-483.7531536971693,34.58740312717319 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark45(-277.22164621504925,-469.7749211651268,26.43171022966922 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark45(-277.44965575779486,-486.25406032679456,65.21199626453463 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark45(-277.49017505085607,-475.8000068847512,100.0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark45(-277.578111164329,-484.99742496646013,90.1836305121798 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark45(-277.58453092533415,-515.12125130028,16.780664485856533 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark45(-277.84761936390055,-490.12730627770236,100.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark45(-278.2501868187648,-491.49372811915606,54.18610433939122 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark45(-278.44406283224555,-545.2859948511073,3.1909716778685038 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark45(-278.69228787240746,-490.2812488362781,100.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark45(-278.78936124793603,-496.92378841932515,89.14145086200534 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark45(-278.80339161823616,-488.6634641237636,4.643179746872008 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark45(-278.83129867323555,-467.6819921855572,99.90379425814751 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark45(-278.86883418486525,-479.5174617155528,69.50417409645115 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark45(-278.916073626451,-544.9421609523727,49.330989801216845 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark45(-278.9667234600972,-496.7319313304463,71.51842888527301 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark45(-278.99320424224106,-499.76107015098836,91.73917637919698 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark45(-279.00041706897116,-467.2670880461187,90.61511434928329 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark45(-279.0815013410723,-488.53833434033425,100.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark45(-279.0952246245918,-512.9096123938424,69.75110878020308 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark45(-279.26804616760984,-487.57589036712005,13.526454971742268 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark45(-279.34068121128104,-490.7686898858254,43.519070398230355 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark45(-279.40760993914677,-540.1750932613413,78.1908184775314 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark45(-279.4543943836733,-469.5006837648292,18.72109310020275 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark45(-279.5081562858154,-491.79343324263664,74.88095387215563 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark45(-279.53750609363465,-496.54271995736275,91.11214395641981 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark45(-279.62951545326473,-491.7585565158954,19.706136413274123 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark45(-279.6534438875783,-527.3863009588804,100.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark45(-279.76790026605516,-484.791301123838,2.4524611647241557 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark45(-279.8609846901336,-512.6101207317579,89.92768867480657 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark45(-279.8734694787149,-506.0169354194529,90.50676646115866 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark45(-279.9686734351219,-484.2268559168037,44.98158014694124 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark45(-279.9733025294456,-502.20743038531265,15.710618097858614 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark45(-280.03878827250185,-492.40446972582544,11.908253286133473 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark45(-280.06558733089776,-491.7513530955017,95.72070403235145 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark45(-280.2028917139821,-468.14106240000143,91.80494461625094 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark45(-280.2554016176577,-478.19117511431625,16.624022524880537 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark45(-280.38355933518756,-468.1252331494546,51.43491302899247 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark45(-280.4732184360086,-526.8343674583477,25.727852888220298 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark45(-280.5210835929827,-471.03346356318934,35.380943112109975 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark45(-280.7571955441568,-489.3539787691774,74.11302818216626 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark45(-280.8565953217346,-517.4289006559083,27.87078301079491 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark45(-280.94350734771615,-487.67167510457307,80.81855497667783 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark45(-280.9985188218666,-477.0320478830244,70.71015716870536 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark45(-281.12404611068365,-480.9805146336674,2.1729390557105717 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark45(-281.26372242456887,-467.0444005686808,46.46135283079741 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark45(-281.26864432017305,-484.57197408505533,100.0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark45(-281.41139997776907,-556.4638702323001,39.87180176045945 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark45(-281.4973217507689,-511.4021336793216,13.138729637303584 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark45(-281.6698710291357,-469.0569214835988,52.868739055465134 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark45(-281.7519530828327,-478.81890907161943,94.453612535021 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark45(-281.75305276974535,-495.5937930838363,100.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark45(-281.75724312946124,-491.747226291333,77.66576393114158 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark45(-281.8586802693289,-464.32726502587616,37.58883025332668 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark45(-281.8748334893704,-483.7533079990567,9.602169260302347 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark45(-281.8773192962525,-475.1722247441141,100.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark45(-281.91691369950155,-539.130386165655,44.28287872420324 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark45(-281.9244397066128,-491.280994325907,81.95718491855567 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark45(-282.0508541158768,-514.3908882076879,100.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark45(-282.08175691798783,-500.2003163446447,8.096838863595487 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark45(-282.2442973453014,-501.27660186742816,55.726747562236454 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark45(-282.4430072354652,-467.6556703861887,100.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark45(-282.5996961873938,-509.92658698823425,17.568453314197157 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark45(-282.78259220265875,-482.06350105841807,51.16281506293387 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark45(-282.94406350262966,-480.22047007459173,69.35798934992192 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark45(-282.9856165964578,-464.42047004788947,40.23660118643333 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark45(-283.0289079553746,-468.23507601353026,5.137177842689923 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark45(-283.11200998065664,-477.6897913688917,100.0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark45(-283.3354864630599,-465.4660401796877,74.01341687113384 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark45(-283.4060807347338,-500.8549680908585,100.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark45(-283.7448487930536,-483.0001365887861,84.75774525905791 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark45(-283.96951654389704,-508.42878841858646,31.784710178635635 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark45(-284.0249023095121,-477.54082062156215,47.25969338387259 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark45(-284.04113435828054,-472.5264505998819,2.669705398020696 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark45(-284.05068611793905,-477.55654902851194,10.043639670425392 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark45(-284.2320246241667,-505.74162435218005,2.08320890136757 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark45(-284.2990784197554,-465.04172337190965,49.84587629854721 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark45(-284.3987794956164,-513.9144252576413,35.89720803253445 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark45(-284.4276174751134,-473.9349137175859,93.27671530334138 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark45(-284.42857231017206,-463.3223316448614,37.55539005832682 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark45(-284.6007393780325,-473.13205510564984,100.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark45(-284.60973316329563,-475.05261618630095,100.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark45(-284.9808997912364,-465.8907854921768,39.55391123022335 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark45(-285.01164675597084,-466.0465688127971,100.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark45(-285.0155898375903,-489.38170004245046,100.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark45(-285.14030035902425,-470.76986452907875,55.33324328139157 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark45(-285.1437310574451,-550.6405117568864,59.551610542115185 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark45(-285.40084864407504,-486.3030906423231,36.757052509186025 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark45(-285.62264126096466,-497.38860594894106,23.06957443551609 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark45(-285.7571433889233,-525.4315904282936,45.90023943095889 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark45(-285.83480318349564,-461.59870203344605,29.821095825543267 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark45(-285.8781578984853,-501.0133140204059,-2.7237050782251793E-6 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark45(-285.8888320250612,-470.7908883271646,26.333905858165835 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark45(-285.91535017185856,-480.2561251581178,38.06508434428724 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark45(-286.0600454190174,-472.71153636115275,9.70452212804102 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark45(-286.2056201058446,-464.65745070492994,1.074160285452436 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark45(-286.2670953056664,-474.525312444051,100.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark45(-286.5053724449275,-474.4060765626798,14.352416438926909 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark45(-286.5371493531604,-472.90444998721364,29.150361420820474 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark45(-286.6307698707106,-478.2000133782581,56.44207440329532 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark45(-286.74009486697844,-469.8828003404036,76.02768062420117 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark45(-286.9213104804821,-476.57573562090505,100.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark45(-287.14880119164286,-464.247383744334,100.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark45(-287.166274389376,-464.4555961563195,54.73587583407814 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark45(-287.31843341272594,-474.49045767146765,4.94260764946695 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark45(-287.4525280780436,-470.5006493217117,100.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark45(-287.4681381365598,-507.89976163824434,100.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark45(-287.87252340086,-466.4270013535493,5.810102137078815 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark45(-288.0415916399023,-484.30544296237974,100.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark45(-288.1578606178473,-475.24371829486324,18.50482409410965 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark45(-288.209604281928,-484.7108492837587,27.142387757528866 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark45(-288.2354400093734,-492.89865177937725,93.28827937021208 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark45(-288.26400596597483,-467.6927342121168,23.942365741380087 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark45(-288.381008686781,-458.70771607920045,100.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark45(-288.4714838009571,-497.11041623160634,91.17262735512736 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark45(-288.50764202959107,-463.95329430647365,44.79648166280114 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark45(-288.52036344280725,-465.8411489474657,47.940084271639364 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark45(-288.56466902366094,-468.4128798207279,87.96737047200384 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark45(-288.60563903643526,-464.73724592501287,18.931695244058716 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark45(-288.6649024262035,-491.2094032494557,100.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark45(-288.6653754908894,-487.4835961927532,54.37392908918302 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark45(-288.7100545518582,-468.82360371425466,100.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark45(-288.71372937787055,-526.3551309534929,22.5521162303379 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark45(-288.96240285869436,-468.7437640823024,47.489643571882084 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark45(-288.96442811848834,-466.1526255585782,58.90832787171658 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark45(-288.9908325178597,-502.5804643250437,91.58686036044361 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark45(-289.0868400419024,-563.8306349878692,55.881958672111864 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark45(-289.0951270002757,-513.3400700989374,42.1393207977265 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark45(-289.1212846617243,-534.0253673309953,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark45(-289.2977773803279,-472.48825219541493,48.55125707289997 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark45(-289.3097659407434,-501.78107854148425,41.113464806436326 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark45(-289.46112492525987,-506.75497235503343,100.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark45(-289.50161181001874,-516.1738354289552,71.27871422240185 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark45(-289.5163566529415,-484.7352967360315,43.11231402535179 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark45(-289.52895065040695,-491.38588014650895,97.71995222287838 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark45(-289.58085909582474,-514.7636138898642,60.564007515820435 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark45(-289.71808801540556,-464.23878275798285,57.506126689217524 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark45(-289.7894596724904,-483.6755477725816,46.59546074545446 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark45(-290.0599615618255,-477.31978038987427,100.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark45(-290.1102389975111,-508.99444492730765,4.638089238165264 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark45(-290.25416355560657,-463.4403951483997,30.68112148369795 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark45(-290.25729209565975,-485.6399925564337,57.92902509278477 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark45(-290.48840858273576,-456.4729496256467,88.36529065332141 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark45(-290.49308096516364,-458.23149780443,40.190066489947554 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark45(-290.5065343619893,-504.1255732965339,36.06344339911229 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark45(-290.88779261283173,-509.24898958233206,3.1570803335379622 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark45(-290.9537491870637,-471.3590315305376,72.26137490247245 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark45(-291.07138959805064,-482.9103014907822,90.04253187191676 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark45(-291.1326810624242,-493.018912771422,100.0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark45(-291.135275905112,-457.028867921098,8.99091602134125 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark45(-291.154491185227,-470.21645167522246,40.788262887243945 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark45(-291.2160250348074,-459.86758053709224,10.77883855253559 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark45(-291.51136655106075,-461.7829052491347,70.31826427297844 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark45(-291.6629225850484,-477.4626702001498,66.39786598831628 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark45(-291.7844397428717,-491.1791562272885,9.67394305636627 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark45(-291.8521749373937,-466.8292281827368,19.789704880696874 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark45(-291.95775086643215,-457.9071851544186,61.7324598213834 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark45(-292.098374710565,-497.06293942651894,99.26702413132952 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark45(-292.2800130529461,-496.30469324994306,58.232274437455914 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark45(-292.3176453164181,-516.682146118235,100.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark45(-292.35482234850343,-458.37312225624737,97.3601981199416 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark45(-292.36882139512494,-471.6364886986544,100.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark45(-292.67062839272626,-499.18473758241447,14.901503784635011 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark45(-292.72393923806504,-471.259903719167,87.06271110421864 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark45(-292.7843120036116,-455.2836427518567,61.76350671105013 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark45(-292.809413165478,-499.4941696501902,57.337383398309555 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark45(-292.9838763196614,-460.5167065817495,76.10592827306257 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark45(-293.1500246883653,-455.1675472175695,20.52713592625925 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark45(-293.4143570482407,-456.3622102765777,60.91315266339109 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark45(-293.4219484670084,-505.1818644248979,77.29387368501821 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark45(-293.43720018666755,-468.4396985237171,42.390976553534216 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark45(-293.4386717647415,-469.7718191906243,8.075147767189634 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark45(-293.90875402969806,-517.4171575554868,100.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark45(-294.7065157692989,-470.2823716422329,52.88273424265694 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark45(-294.7230995968232,-503.8298407630228,81.54279769710854 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark45(-294.9328829435449,-470.7391676773248,93.81541605529881 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark45(-294.95530512909727,-480.58635027377426,33.63006011527128 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark45(-295.0008047743939,-471.95414747507175,59.952322631749695 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark45(-295.2745273390368,-495.33642523331537,0.9146360291800333 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark45(-295.4215415557148,-490.68209137184743,32.94035090172608 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark45(-295.4753621935462,-455.2798303371036,23.044972038429876 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark45(-295.6693948802206,-500.11455927471485,64.25716112450411 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark45(-296.08171299285533,-468.3161960919573,41.022558197439196 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark45(-296.2349940714107,-506.4547607816827,100.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark45(-296.2785651729331,-485.89985863841633,47.55733034401214 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark45(-296.29797768341075,-465.1758062580055,50.053901891200496 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark45(-296.3936206623689,-463.1929995316086,26.735181632000987 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark45(-296.4885104235406,-519.6685751102939,18.360339195479483 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark45(-296.53894593170986,-476.85988999999665,30.443959297978477 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark45(-296.7212097363805,-449.3194479535624,40.585146928276146 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark45(-296.7226407351405,-449.9665650792118,59.39824061606501 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark45(-296.8259886915307,-461.58487403931736,29.890630692352687 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark45(-296.97166124332995,-450.80002602352823,90.15730877404206 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark45(-297.0114159354503,-540.4465418495889,39.091568764442854 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark45(-297.0858765153973,-493.84839133484576,61.617875302427336 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark45(-297.23616326555674,-497.96574511729506,25.913869988382075 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark45(-297.32076586320005,-461.0646830242132,52.564567193828594 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark45(-297.49710422741714,-464.4228263983286,70.3520645553541 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark45(-297.5272933530636,-464.7791864798878,61.61361114210099 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark45(-297.58410035207305,-459.0635181558293,71.68845316419143 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark45(-297.65431991061695,-458.3312279987273,100.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark45(-297.688406290482,-508.2186193275249,54.56200011019726 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark45(-297.6939803576711,-452.8936022889062,70.9588951865178 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark45(-297.8322174268834,-462.8489160274568,79.87208810249265 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark45(-297.85628266844714,-494.68810092311,61.99605585884592 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark45(-297.9176698240222,-484.67182434532504,100.0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark45(-298.25376682455095,-466.4662769193589,12.86618799299815 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark45(-298.41962782290153,-452.8936206689935,57.5152987320688 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark45(-298.5213837147373,-483.1633769441964,5.273270880756513 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark45(-298.5963929315983,-465.6975364026672,26.86448713150726 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark45(-298.81917299694885,-479.2830544266605,23.466957667170547 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark45(-298.82911603771015,-448.8123748703682,29.27248506883572 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark45(-299.00651616631194,-454.7021818205425,75.53659064979757 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark45(-299.14414800541135,-460.7676349971746,61.174288480673965 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark45(-299.23420552027153,-464.36590018324796,21.428434531089465 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark45(-299.30595795187037,-452.81135431753205,89.09613604021902 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark45(-299.4055256123403,-483.97110278468944,46.36681342519401 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark45(-299.5171221972797,-466.499834061589,66.76824253058535 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark45(-299.5442068363134,-473.21285413184194,27.12609441538558 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark45(-299.8485092246387,-449.77358088432624,39.09555719585839 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark45(-299.9573382821105,-470.763093475904,11.353044624771599 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark45(-300.01706907617626,-489.3006909021784,91.26366579581381 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark45(-300.11068513047854,-460.2080167446355,100.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark45(-300.1875676744618,-448.3427138536358,91.24186578882035 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark45(-300.22178498659844,-494.2098333277378,16.271220380360333 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark45(-300.25160264812746,-478.1019768679434,15.914610421160774 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark45(-300.4319656095949,-459.18570815666504,41.38879484944985 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark45(-300.4725532421946,-454.90624888254916,59.686965730204086 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark45(-300.65973312351696,-445.9845363288543,16.85940679665832 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark45(-300.92975371470214,-451.4604351020597,23.017218144430387 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark45(-301.2271736968882,-445.67807927418954,38.894417266146434 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark45(-301.31517468959237,-467.64779100794135,100.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark45(-301.4715985841579,-459.3391505238974,2.1998879382784082 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark45(-301.6113187596688,-458.36984641460003,100.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark45(-301.6752473923396,-506.52985400165755,62.38208582157756 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark45(-301.6852667625427,-470.0462443965489,81.3984586958077 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark45(-301.83183678956266,-477.5076564260079,57.4753946271681 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark45(-302.14106007607484,-468.24775916811416,62.532717137380786 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark45(-302.30554013836183,-447.824817832353,100.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark45(-302.3195066503863,-447.6477800651856,54.176803725590474 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark45(-302.3747674912243,-450.48677504877963,16.721156594916213 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark45(-302.4498264274597,-467.76196210307774,23.47408487033158 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark45(-302.4695842421965,-456.6951279226303,100.0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark45(-302.54523736295505,-496.01570696496543,54.964746551079855 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark45(-302.70875919483154,-447.0428603564456,100.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark45(-302.94186820224184,-531.7312278109049,22.237463498413916 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark45(-302.9892036900345,-478.05579176504796,11.26577498613004 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark45(-303.0029808621859,-490.3607891008676,45.95032273795024 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark45(-303.1064770597627,-467.35439333412273,89.51386950366722 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark45(-303.1212841453422,-467.9390476420096,22.271906678911122 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark45(-303.5434822986082,-448.8047524405085,51.73014543849507 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark45(-303.66299785557635,-464.5296159540048,91.63850306669389 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark45(-304.0418947504123,-485.94475559376474,100.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark45(-304.115365832248,-457.4968428647053,66.53858963108333 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark45(-304.14453995399106,-484.7117055310932,2.842295802735805 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark45(-304.1468815339254,-448.1076961990738,34.803972406202604 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark45(-304.1583047730241,-464.5238499091998,6.548476319689826 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark45(-304.1744165225383,-455.17429798148515,19.25627154444772 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark45(-304.19090687107246,-445.9511506421294,49.47373654401051 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark45(-304.2559931642701,-471.4329470105951,24.881639609183125 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark45(-304.4019409146519,-443.72410957356243,96.36916401218969 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark45(-304.48725935779805,-460.60278968254784,69.95433660417058 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark45(-304.7712105275997,-508.0936626035366,52.17554460643365 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark45(-304.91328325647623,-477.7139126649792,30.03247588126908 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark45(-304.9467410987701,-445.93864508608203,39.137619131040196 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark45(-304.95247560379295,-442.3182195551035,72.7275505086109 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark45(-305.0213537578148,-476.7857311694593,9.805590462202446 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark45(-3.0506024371835443E-18,-778.9363555667748,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark45(-305.1690534953939,-443.75938632139906,17.2357241831496 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark45(-305.1786997461359,-452.6954920917882,100.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark45(-305.250058940815,-512.9343849265356,26.78781296169541 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark45(-305.545868717049,-459.6372608511278,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark45(-305.65971900910495,-446.323548327821,91.55647341323458 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark45(-305.6703955814536,-551.6197700751075,100.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark45(-305.71513417906334,-468.0244117339103,99.59888070256781 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark45(-305.76409665448324,-445.1538986115097,1.8564128642384503 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark45(-305.76690257816983,-453.9158457305831,64.85512930292964 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark45(-305.9720369640269,-448.9077944320465,70.6681972350099 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark45(-306.26577740186923,-452.26448603654137,10.517114728535802 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark45(-306.62778192395564,-455.1245055917474,89.92329332080314 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark45(-306.7119340731,-462.7496939600245,87.31178192887833 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark45(-306.7378629685457,-448.3961825054131,47.56455829318301 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark45(-306.7851615722614,-495.48600598299777,35.636761809170764 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark45(-306.89134123984934,-471.4437486360184,52.55484327120445 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark45(-306.935008279068,-447.89993154575967,38.11122477971176 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark45(-306.9759112837191,-450.89411904462264,83.40114831349399 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark45(-307.0065708238117,-461.9135622546508,99.93873665741745 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark45(-307.04198063227255,-508.0649367937078,100.0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark45(-307.0866863719301,-470.7439694364561,100.0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark45(-307.109639888556,-529.317764178696,12.46430908506322 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark45(-307.23341323729744,-471.0153695583741,54.77580109044945 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark45(-307.3802632008773,-455.0305475468097,46.2747817138339 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark45(-307.4618690499695,-447.1996175491088,4.970367863785 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark45(-307.49763112073106,-493.31069624202354,1.0038465491228692 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark45(-307.50067416499064,-462.2739947686926,38.19360559105991 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark45(-307.5227750016726,-438.8377060139049,86.86570564624745 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark45(-307.87725493907647,-476.10032047186564,23.33611954538695 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark45(-307.95065902516535,-449.1848400105792,42.764012047647896 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark45(-307.96081166916423,-439.6141407037702,2.133203275824087 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark45(-308.1995278256454,-476.4679963609169,61.3561954813207 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark45(-308.22785596795944,-507.99419903944715,100.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark45(-308.2750013908546,-466.75454908672896,72.82950452656388 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark45(-308.391568345217,-452.39541711714253,35.25295940121498 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark45(-308.4263111851693,-480.91987061286164,99.39767410334369 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark45(-308.43344939354,-448.60394087676616,32.09854994136421 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark45(-308.5415580158037,-442.25136188295824,18.230417980729953 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark45(-308.60954610582166,-444.1092214102702,19.114207057109866 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark45(-308.6666774501155,-477.32289006997433,87.89919696480499 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark45(-308.6758319294913,-473.2564007152063,100.0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark45(-308.74996037637976,-444.0724177053084,100.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark45(-308.89470450088515,-504.96891711114034,51.722748752404954 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark45(-308.98730386013835,-454.0869479944433,16.761497692900207 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark45(-309.27048782444353,-454.918463475054,92.45188599603551 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark45(-309.3615974973021,-485.43056911285703,100.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark45(-309.43704088855077,-482.30104557779026,3.890490534150672 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark45(-309.5334239993312,-437.7587935978104,0.7708976145829143 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark45(-309.636464501947,-454.40609817465406,54.43186043122475 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark45(-309.7135619589992,-454.0698652103871,62.9627580551703 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark45(-309.754622070215,-461.6102726096228,60.93431776503303 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark45(-309.7887520272253,-451.57941864524247,25.869652556657414 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark45(-309.79231344765026,-442.6798330744722,21.983675662642298 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark45(-309.8011027851216,-463.35020050106186,86.7402798807513 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark45(-309.865026712268,-453.34527606389105,24.423833081295385 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark45(-310.09650865968047,-493.89552080146746,86.77140051131502 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark45(-310.2356704188061,-446.4733789933356,100.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark45(-310.3194078587918,-437.7313033348125,100.0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark45(-310.3728447535098,-435.9302665474571,100.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark45(-310.44666677169937,-451.91813686472585,100.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark45(-310.4723966073004,-447.3565569841103,50.39213715923546 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark45(-310.5981743269668,-490.5159235954408,47.0642735167784 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark45(-310.82314355262326,-478.80225417117776,65.74477334338437 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark45(-311.00440753302405,-436.30696934664945,33.89533251929976 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark45(-311.15290797880897,-437.43114460346675,94.27045687449237 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark45(-311.22667450826407,-447.46962079058983,43.18601480445904 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark45(-311.32848779060964,-434.7003703968026,44.72552624489103 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark45(-311.33200795503956,-491.13973872241183,2.5989787459274254 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark45(-311.395378428282,-449.43031067879474,7.782125627871338 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark45(-311.4008899047665,-456.28676984672563,100.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark45(-311.4129620418174,-449.2517614388702,81.12641568297082 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark45(-311.52364957031295,-444.15012963544655,89.71613774635813 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark45(-311.56237252621776,-446.74138563737904,56.594843402986726 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark45(-311.58032379858753,-481.4359936383485,29.316101319216017 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark45(-311.7534667221392,-478.11798908770226,100.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark45(-311.82176927812594,-487.04240177967284,73.5022940598777 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark45(-311.8853010602328,-465.91035356932935,100.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark45(-311.93232906089554,-443.5026836034429,50.758660273872806 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark45(-312.016595668266,-545.5011997591297,15.872047273685212 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark45(-312.2325562658767,-494.1464581619797,21.07324035748894 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark45(-312.4360851461206,-438.857492202244,28.099928524942754 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark45(-312.4957977356152,-478.1520717021209,71.19968965327504 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark45(-312.80565259723255,-447.4126515369188,75.23488621787615 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark45(-313.13233823263715,-519.3403463488439,45.63012053449239 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark45(-313.19592812225767,-433.0470623073242,6.874551687940272 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark45(-313.22416971463804,-438.58081034104174,17.42106036125446 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark45(-313.2704366152577,-451.0970592531038,100.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark45(-313.3400614451361,-442.1962931066911,85.66065445782074 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark45(-313.67481780544176,-447.3049129230366,20.200579800969606 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark45(-313.8291505906388,-445.07126566834665,16.98074237053069 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark45(-314.0035754563665,-434.47750423541254,25.138683231899336 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark45(-314.1031941889438,-445.57273370325476,86.86151054357242 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark45(-314.1129685809591,-489.74932638596385,49.626232831814576 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark45(-314.23441590809534,-514.0735496491193,2.113982931593995 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark45(-314.4366388196737,-498.67951627461775,43.73501313510553 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark45(-314.46378084914807,-478.68607188702316,70.18920074252793 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark45(-314.50466442172814,-486.11750822790333,23.56338953611572 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark45(-314.56914810439775,-488.50244035877137,100.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark45(-314.6232976264196,-483.66190069174786,19.256021453820566 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark45(-314.72206875521596,-435.1453316172497,100.0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark45(-314.83829649543867,-438.5471827267007,100.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark45(-314.86742641264186,-471.1724622235206,19.337778858114405 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark45(-314.8876831765649,-450.9973332374846,36.68977352000195 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark45(-314.9002597894762,-462.25204849078017,88.12821503400886 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark45(-315.20636276745324,-439.7205208041895,8.909732690585443 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark45(-315.3483762300927,-451.70837550159064,19.366270481330233 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark45(-315.3663310970697,-436.9487550645333,34.07309515347933 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark45(-315.44722429985296,-435.1615094376947,23.62248830799291 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark45(-315.4842123403226,-459.26965130248834,99.93982197357064 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark45(-315.487672079626,-487.9869289192262,84.82011029697806 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark45(-315.63156514325476,-538.2849881177193,99.9294288581668 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark45(-315.64222769745413,-441.9196687913803,66.8645930154272 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark45(-315.775920518995,-431.8809612755549,100.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark45(-315.8064524731429,-434.41097658164904,68.52207305183606 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark45(-315.938485663471,-451.8904468628566,86.79601919427006 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark45(-316.05282289579594,-473.55264494245785,20.22847643403496 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark45(-316.0708905568559,-430.9081489431674,60.29874413805348 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark45(-316.1080472065046,-442.38424231465814,61.50000656023283 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark45(-316.35834046219657,-479.2743000678723,10.39220076598788 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark45(-316.41041575511537,-449.72786309097484,34.3445391639684 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark45(-316.5452367359767,-436.6138792221208,61.43687143387427 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark45(-316.6864887197137,-453.54081868927426,7.3908306786479585 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark45(-316.7081227350125,-448.4326016945921,3.51837126100844 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark45(-316.8855332326349,-474.2529874345962,15.538282268188695 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark45(-317.00195146223683,-448.10524117137726,42.08258058678621 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark45(-317.35547386792365,-498.25623111506843,56.961059609009226 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark45(-317.38388416552255,-437.03986873359656,100.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark45(-317.53863625696937,-442.66873365332617,74.84517718483619 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark45(-317.59811440107876,-444.0145849102111,7.139440233990676 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark45(-317.6126250990478,-452.4690276939722,71.12798415766446 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark45(-317.63971115747523,-439.1434692564868,100.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark45(-317.80286166381984,-436.1675006333312,44.119866168356225 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark45(-317.8357001275147,-466.3287755296167,63.83885661658914 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark45(-317.86569969862285,-450.6456959622899,3.909467573924431 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark45(-317.94147684865436,-454.5170539064205,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark45(-318.0074947774822,-451.3522459573623,52.0262042853081 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark45(-318.0197444098336,-459.0285335049387,98.7758295730543 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark45(-318.0768144376803,-457.186506689027,4.423887567219367 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark45(-318.13247585564494,-428.98150938727275,5.057761969814422 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark45(-318.20373952276685,-430.65530143647095,27.87638527505551 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark45(-318.22200599359326,-450.21275768313615,6.259700845012659 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark45(-318.2394191098874,-448.1425195664778,66.66031843114814 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark45(-318.2666522815823,-507.7666115528252,34.58285508152787 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark45(-318.346479878287,-455.9970871571212,43.93842710326581 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark45(-318.5189963905789,-480.9183757037388,53.49287955167043 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark45(-318.60187151689115,-429.25495133079255,13.208901604393873 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark45(-318.65697730986284,-439.1247902587409,14.696046594743706 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark45(-318.6753629699914,-460.82219829105117,39.18989310452102 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark45(-318.82925638847985,-437.56245187534614,93.41045412299758 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark45(-318.95800130362005,-453.0812494508322,65.35986668889319 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark45(-318.99209986355805,-511.57805533447697,13.718362807550676 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark45(-319.047526209889,-456.8577945126508,17.85021338206174 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark45(-319.0960436340813,-459.6399168462429,64.2776435745347 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark45(-319.17586960624703,-439.5499583170214,74.97442995223753 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark45(-319.32730108084615,-449.30449489940713,33.47118479822541 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark45(-319.3473143269141,-433.7050689551207,71.42951466348217 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark45(-319.45921088441884,-455.8617135472419,50.71977069727603 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark45(-319.47165583643334,-426.9470459438759,24.110598859530114 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark45(-319.6976872768587,-505.88862086026523,59.11407147110191 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark45(-319.703472106739,-465.79061611978887,57.81329575252764 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark45(-319.74638938882384,-453.66465314491177,14.008867093977202 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark45(-319.95514116299626,-479.4776749829195,95.45564802239144 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark45(-320.07082970176987,-437.5451072630909,89.06866678553592 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark45(-320.14567959425034,-430.45553673264726,31.41230262449912 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark45(-320.2195052236917,-461.0674181002024,4.858179643209354 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark45(-320.2418887018925,-435.05944622446316,84.51163634805974 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark45(-320.2997232949283,-428.4391424868759,5.844825225573217 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark45(-320.3494701792332,-464.985932177145,100.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark45(-320.5039577369653,-479.76010311688475,40.94839725222471 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark45(-320.5177129823351,-461.7974009468187,34.629226283574525 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark45(-320.5880072323948,-447.8815000338324,100.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark45(-320.6110613748855,-453.8246679622926,20.222259405063838 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark45(-320.6814993931371,-438.9997514639956,100.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark45(-320.739894684153,-448.4744793271686,84.54445899987789 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark45(-320.7463196808639,-431.5713666056598,72.14760307736262 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark45(-320.81698988929855,-440.46562545952224,98.14366843482708 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark45(-320.8309768166956,-450.35851171358473,32.980084452209155 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark45(-320.8358386830267,-494.73901306744244,100.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark45(-320.9141454025651,-427.61041852966184,64.45424469611348 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark45(-321.013466996,-426.19081067535046,100.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark45(-321.05882724129265,-450.3009718001514,3.8776054458486584 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark45(-321.08493117321865,-433.3187125512492,66.65707288252253 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark45(-321.1466636009421,-439.10539488855983,72.2415528049446 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark45(-321.25216646915084,-453.94413522119555,77.65382724824084 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark45(-321.3468946821842,-469.981610560157,100.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark45(-321.4154869803554,-429.32260829570214,71.75705875998267 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark45(-321.43987036154823,-426.57892255272935,7.106713981701233 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark45(-321.4696136083749,-424.8558158068535,100.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark45(-321.71271335392026,-480.50793380797654,34.92203085662376 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark45(-321.80090180895803,-472.3472724226802,70.60317918500829 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark45(-321.8753075469043,-427.26443278257165,97.09494421544719 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark45(-321.8786949385802,-514.2488516762205,14.03841328061948 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark45(-321.9470624634275,-502.66840977598866,63.302089782307235 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark45(-322.0564946703433,-435.8051943134011,39.57157778165049 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark45(-322.06135751761855,-471.38108870700637,100.0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark45(-322.09186098367786,-430.35948692662276,26.918742869432492 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark45(-322.169096509725,-465.29319960204407,57.888239772083864 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark45(-322.1744875373384,-447.8462921952298,8.57694497598709 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark45(-322.2407624092534,-440.68060419020054,55.02869126591716 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark45(-322.28981613840534,-429.9739811699805,18.191091736773004 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark45(-322.43617999033773,-455.8231253923764,100.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark45(-322.44463968163853,-444.4558703902675,100.0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark45(-322.4909956367256,-433.5290489863181,100.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark45(-322.56071928528985,-440.8511026770269,51.23220883768022 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark45(-322.83273007534757,-425.09142686591053,63.44418495184496 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark45(-322.95309249343063,-478.7535134887492,87.6107391737468 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark45(-323.2498896424747,-441.7409364938035,76.4615216683568 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark45(-323.3710474566828,-433.9544427003935,10.277023403741055 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark45(-323.52502702789354,-478.066970299358,72.99752777471238 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark45(-323.6810102153265,-478.4428147410051,100.0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark45(-323.74829847488286,-432.20325799422983,83.76799828144394 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark45(-323.8235411805799,-447.9271480464823,75.3626044789464 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark45(-323.95224459953397,-448.09650004097693,100.0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark45(-324.0642572466274,-498.1024742534168,77.23398633643569 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark45(-324.1761682561447,-455.46172113089614,94.00186223627463 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark45(-324.1958901898447,-464.1073478838079,6.012296352218399 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark45(-324.1963781725545,-460.66793949400613,70.42151874582737 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark45(-324.30303214001077,-430.61645811136333,88.64413515218365 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark45(-324.3287888515577,-470.1552265425456,98.85421104525912 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark45(-324.4222504289409,-481.53022137812144,57.87527450228214 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark45(-324.5972092970419,-425.9833182637726,100.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark45(-324.6265044256881,-428.5038856271557,95.22111049630914 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark45(-324.650023345545,-457.2893501573059,100.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark45(-324.6543244441861,-441.05852815372623,10.059093466396291 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark45(-324.9280887385946,-469.2285381943258,45.609451912408474 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark45(-324.98147971393837,-532.8402359753684,54.024683243819396 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark45(-325.1896330762463,-424.12727318388636,27.119269435327254 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark45(-325.2553443252126,-447.04599727441683,12.297118896135672 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark45(-325.2987775978047,-468.38954860192746,23.16117285309585 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark45(-325.4783176056997,-426.0797939122646,32.14753762986845 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark45(-325.5525629894526,-442.3262447156758,42.44959412534351 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark45(-325.67813268402085,-424.13556428432406,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark45(-325.7189781991023,-435.0238799432735,0.1760449191530178 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark45(-325.7357753784181,-481.6935797751898,88.06822902565514 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark45(-325.74741860242676,-427.1272220296594,49.35263979185237 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark45(-326.12706809184596,-423.129192914063,52.930493786667114 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark45(-326.5105506838681,-431.48274121705236,40.73484769458463 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark45(-326.758724233731,-427.0715490682759,77.07700324663162 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark45(-326.8108357071411,-460.2124046522202,60.4681663448865 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark45(-326.89636836605473,-422.6473320766779,100.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark45(-327.2699356434969,-428.4016588962065,40.54030769018172 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark45(-327.31224633527296,-421.4379681057716,48.33365194675736 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark45(-327.4327549185528,-470.1091997864445,69.79722673948464 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark45(-327.5137164381975,-420.67659339197104,24.633411827087272 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark45(-327.54573510727096,-432.84493154853527,8.23238584721031 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark45(-327.58721100703286,-442.29573651638685,13.911698311283956 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark45(-327.6488756820901,-483.4567879416586,86.49085279120584 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark45(-327.65374477713414,-438.4648298051093,68.58484182111275 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark45(-327.67272414847145,-444.5703899955879,6.172189242021389 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark45(-327.70808876491935,-419.3913987259539,91.60764171951857 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark45(-327.7240347137417,-418.56471759351496,85.56280037762005 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark45(-327.93140614696864,-428.63099284541954,41.86467134506924 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark45(-328.05236959389316,-433.57153242441973,91.23380594230912 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark45(-328.09277592694974,-438.33050820371204,39.06081142987466 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark45(-328.15186163883106,-421.3253077401534,91.20105817077936 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark45(-328.16871437927915,-420.663512467357,43.67324378095182 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark45(-328.3730904102859,-426.62918230132135,12.502457554485133 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark45(-328.5227181982124,-472.21742706454506,91.79822341753805 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark45(-328.69989687139923,-420.09262492536175,74.16940946612226 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark45(-328.71831103832426,-421.5677196964399,27.02718505842003 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark45(-328.7256505989419,-428.763330684037,41.83483257569526 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark45(-329.0114179171305,-452.1077959582345,100.0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark45(-329.04365955468506,-474.46403760485276,81.59767859401316 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark45(-329.05736246290417,-451.508029523822,28.094600537521814 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark45(-329.06116327470573,-451.4927715503534,100.0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark45(-329.1530095635806,-422.7427712748281,5.012510484250598 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark45(-329.229734828252,-428.6249460418608,100.0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark45(-329.24527607206346,-423.44587888668997,0.3811983428882826 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark45(-329.281569115812,-479.0885329536768,26.919224195711138 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark45(-329.5151338989701,-465.36347091317924,91.76674065247926 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark45(-329.7481510634761,-420.81485194332845,100.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark45(-329.81840977826147,-469.06286090082517,43.49795721466191 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark45(-329.94623564590074,-475.6788384539837,100.0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark45(-330.16174263318914,-446.8335251129611,98.84766019786129 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark45(-330.17265684528417,-454.1975601583771,17.28934346708246 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark45(-330.17952320875634,-447.84830105943627,51.88281736250951 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark45(-330.5564835939652,-470.00671807776445,6.544349371055901 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark45(-330.60183548590186,-444.69317456463165,100.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark45(-330.61270335749015,-422.81758427962467,21.627055184831164 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark45(-330.6871610339395,-431.07672577588534,15.1152361891413 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark45(-330.7405295778245,-427.08208774495654,62.82489251862813 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark45(-330.8906255050233,-525.3978635281375,18.122644048938284 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark45(-330.8998494570092,-442.3171790121739,13.234896789301345 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark45(-331.0166173085775,-426.9441992650341,100.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark45(-331.100057899856,-421.45138444566214,69.52830518187666 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark45(-331.1270608149306,-426.100124830611,100.0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark45(-331.16671323919365,-445.52230587232845,13.321342297885735 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark45(-331.3852914923045,-419.86053267378907,57.96554967697327 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark45(-331.386656423336,-444.5467656020179,78.80461975618067 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark45(-331.414629636535,-416.14887348323305,100.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark45(-331.4725419737994,-417.24100247307456,100.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark45(-331.5403903277998,-476.6828508618956,77.07156595884314 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark45(-331.6277820014436,-435.9827336754924,100.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark45(-331.7970352204059,-479.55344895164046,6.710283552931216 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark45(-331.9250124115308,-455.0783334987542,2.227324760684967 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark45(-332.0437817062051,-423.5136472087733,85.40292928690468 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark45(-332.183350584803,-460.1267919642479,89.13931956120175 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark45(-332.29185351376196,-458.51649141449684,95.82327567418497 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark45(-332.32351869109885,-443.9891177517001,75.61941588306027 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark45(-332.38464416311956,-420.0787773411245,4.797499982237596 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark45(-332.57929038067516,-429.3619045956955,58.5678116797601 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark45(-332.6718240709293,-428.47575293645474,96.39957435682105 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark45(-332.7245064969993,-420.3551753497915,71.40029812004661 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark45(-332.9370760268412,-413.6453252300692,59.67494933137307 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark45(-333.1573737455464,-420.34366902633536,38.089999445845336 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark45(-333.5828317535788,-428.27564718238057,100.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark45(-333.81257322268215,-451.0255355256428,11.906440922478296 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark45(-334.18298448867176,-431.1289425156296,59.86684708834284 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark45(-334.2733253308618,-453.03677469995733,14.889819513306296 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark45(-334.286944213832,-451.29979855843976,33.47645570756572 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark45(-334.33606044777764,-454.6093783753619,56.3508843229921 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark45(-334.345500195109,-506.4580743896586,9.800436195415244 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark45(-334.3581702504492,-446.1311028478752,19.04889772773477 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark45(-334.3862382788585,-431.80398350536825,86.59541986616327 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark45(-334.44431314251443,-417.5954595418907,33.42631952641776 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark45(-334.46632370897134,-459.7027709534466,18.848881488482373 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark45(-334.49513435572084,-466.6452132612531,100.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark45(-334.547456919122,-493.15462870261484,43.452108478732896 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark45(-334.60787541477276,-442.07897552512196,94.35820307532975 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark45(-334.6175517862435,-424.93989780109587,100.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark45(-334.62454467524276,-425.62546838654794,90.45262578520348 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark45(-334.70353681854283,-472.1693821791215,100.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark45(-334.7071468178383,-458.8226556823256,100.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark45(-334.7837365462062,-445.14332231571836,85.04440354391258 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark45(-334.8241651270713,-443.1518943275188,48.128919898503824 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark45(-334.87582465588275,-433.08601351852457,86.03942176829474 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark45(-334.8952742398746,-494.66881751334375,97.39624703184597 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark45(-334.8997484895234,-414.6907666513021,77.93301888537127 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark45(-334.945821356339,-464.1880827689824,81.75103966492449 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark45(-334.97411557716936,-449.9539059537823,84.72397177570659 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark45(-335.0977224060227,-419.70313619427566,15.857843246433816 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark45(-335.13452317895104,-453.7374326795934,80.5820542611459 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark45(-335.31273924827076,-458.4147655696713,93.24181551243231 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark45(-335.32089069966236,-423.45172827474,100.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark45(-335.37172108109803,-479.1077425863557,100.0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark45(-335.4015440471868,-418.2024303116604,100.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark45(-335.4863345460448,-458.0798168091804,50.096832620133426 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark45(-335.4970956528997,-422.3572898677583,20.66791386599205 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark45(-335.5744463535113,-430.07167653319266,67.97519019823818 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark45(-335.85585315195027,-448.4905383821358,34.10734683385357 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark45(-335.88202133642125,-423.4424178002682,21.660738182434372 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark45(-335.9264998184573,-443.3774138621717,54.28235022675293 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark45(-335.9718293914043,-416.06873057067236,60.92019983120457 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark45(-336.0169077750396,-423.2178041650723,2.9415770620925485 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark45(-336.05962160362037,-422.49821507287686,100.0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark45(-336.17002008328774,-423.599779846785,100.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark45(-336.22488844254775,-446.05639522244417,36.43245437462389 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark45(-336.2925329261428,-434.79491959722674,7.9759188860356005 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark45(-336.45987079705895,-412.2157143771154,50.603848401895135 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark45(-336.53860779569595,-418.40183433240526,38.57092485194334 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark45(-336.56621965311433,-424.3133934619029,44.662780459632955 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark45(-337.0610858796246,-466.0684042015837,74.3281376857928 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark45(-337.07062202868815,-429.6503704999576,98.17849793039201 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark45(-337.08209660001006,-432.6398668324595,68.67461952011803 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark45(-337.20604000348453,-443.6006117879402,56.58069537910228 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark45(-337.21369354394676,-436.8920531759416,67.12400905059008 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark45(-337.2602445625345,-418.1243879625312,43.846073574996524 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark45(-337.26723923638247,-423.7635473242718,1.1659855475703012 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark45(-337.40561245984463,-431.5950361648768,15.66493445790546 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark45(-337.57366080598433,-409.95041313581584,63.50289536400256 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark45(-337.7634968719764,-410.83807885573157,100.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark45(-337.9666825649129,-458.85519115029945,3.6589713886565107 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark45(-338.01503476926206,-414.9629360887089,67.52314135870867 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark45(-338.0164737489399,-466.94074402419494,41.612466838602614 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark45(-338.1029390536081,-441.50071408481017,42.91310130373189 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark45(-338.1763215920814,-454.0124541357955,6.179866006379072 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark45(-338.2992455251174,-447.8954895618799,71.11876928083453 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark45(-338.45762825244907,-448.1221169711824,29.718517658777245 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark45(-338.52069165785923,-425.7235600965801,77.19124969817284 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark45(-338.68765078783326,-490.2744028162878,90.87369548761009 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark45(-338.7801633668287,-428.7767153597923,100.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark45(-33.88219632733953,-733.7197513740039,94.60225034530325 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark45(-339.1337882944602,-414.8856376300848,24.95041030294773 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark45(-339.13787915750476,-416.9634015017985,85.777928903712 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark45(-339.1422048015084,-408.674402332638,74.55318956003723 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark45(-339.20167119595266,-408.99526276116904,9.328624865522556 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark45(-339.3301911482275,-410.73164793146304,88.23995751266688 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark45(-339.43284456178316,-410.80590874116956,46.2678305312802 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark45(-339.4614899975355,-408.8078527113105,38.53035449937829 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark45(-339.5962039524772,-429.8988204132458,100.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark45(-339.86920056519244,-406.64545045596054,23.484674768543726 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark45(-339.9686763490814,-487.1324941976428,24.911355871280634 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark45(-339.98757275122733,-444.08780762857197,100.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark45(-340.0340961951125,-429.71636710597664,55.8639591397789 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark45(-340.16253623672696,-423.51297048604096,77.34922070694984 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark45(-340.38563781349893,-435.02368866466674,45.881325557976936 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark45(-340.3995606533574,-453.21703205842874,100.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark45(-340.54345558127625,-413.7886153927282,26.90462838742944 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark45(-340.5555423513098,-426.57944705926855,87.61962399034496 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark45(-340.5948910248044,-408.6422871026118,41.34863760745756 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark45(-340.5978882072368,-450.7587446620419,30.99734001371104 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark45(-340.60484924374765,-442.3113684260224,84.25013220635927 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark45(-340.6086914406182,-444.54115077792113,8.540859685664472 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark45(-340.6972717364393,-413.7409304379007,70.49448756079681 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark45(-340.7788244163809,-411.80308759145566,39.15385833105759 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark45(-340.78533529738434,-416.4690546937048,39.510478080050575 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark45(-340.80147707549014,-413.3825472741951,100.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark45(-340.82132467691326,-439.84095970038044,86.3956823498954 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark45(-340.9738893574049,-472.3574149758749,78.83146960540586 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark45(-341.28370133411426,-419.9414629297115,13.425428466812235 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark45(-341.30159608933434,-434.02640551119663,40.524171185838696 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark45(-341.4129183472202,-436.5677540756077,20.713578553144885 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark45(-341.44679662099674,-428.56237248095647,76.3831622340264 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark45(-341.478059417409,-446.0569199558281,87.80623051829826 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark45(-341.5207847163517,-421.7096550873828,91.6912325603015 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark45(-341.5794649166333,-416.9902548469448,93.14849580646978 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark45(-341.7756510237504,-428.6724769302679,56.09580737099955 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark45(-341.88562335029036,-418.8081272129968,41.87813781371577 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark45(-342.00616616869655,-405.57297948663097,100.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark45(-342.1146809888595,-455.59060004560337,100.0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark45(-342.3174718010762,-420.95177398359624,100.0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark45(-342.3927631851525,-430.8877859806591,83.46329594012894 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark45(-342.4802682788302,-420.45889896237253,95.4089023086483 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark45(-342.5508223806561,-462.16121661651357,100.0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark45(-342.5626580648898,-416.18138664089975,61.36352112544719 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark45(-342.574545302562,-435.4859320740158,67.46648588896306 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark45(-342.64514902772476,-414.9326655763819,100.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark45(-342.8274067886834,-447.22320336960667,44.95013306743465 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark45(-342.9026474831833,-405.95133735029225,48.95485803217653 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark45(-342.9097961746617,-416.14103693568643,68.46782970469292 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark45(-343.03472716247535,-409.0481234089318,100.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark45(-343.0731458835448,-453.75627348325304,77.64570636432202 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark45(-343.078130208397,-451.7026392125604,3.530035898734411 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark45(-343.1555427712431,-407.90045031021936,81.32533839810904 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark45(-343.3912329858842,-405.17180042616206,32.73782484944542 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark45(-343.3997973181496,-410.63093642645293,49.2346563066786 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark45(-343.56057503100936,-418.9925805940205,87.94660928338544 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark45(-343.570367350586,-412.4194452051154,70.41579114906506 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark45(-343.5923512765224,-406.1071577080839,71.81386712721641 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark45(-343.68119979089033,-440.5722954076886,14.538025453002007 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark45(-343.75623261342,-415.84708980872364,88.35222611823818 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark45(-343.7573389819175,-441.34058454252363,100.0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark45(-343.7723411090494,-417.75061612900754,12.619352973650905 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark45(-343.8730938797223,-422.11088046821106,66.65115369766983 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark45(-344.10486346609895,-524.057365381224,45.56501366021669 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark45(-344.1366431007704,-459.0438717243364,84.12165111789281 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark45(-344.3108257280844,-429.23756817895855,100.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark45(-344.479943245127,-429.1594121193508,68.15828845654389 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark45(-344.5150177297194,-414.0057849952275,0.035620351494543456 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark45(-344.5321128276027,-405.7362929774878,53.5568287031239 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark45(-344.53830200150406,-406.79357689788947,70.57817448558725 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark45(-344.5806804737393,-419.63827069412116,85.35446313408696 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark45(-344.60128341986285,-456.4193416934456,6.3518536508969845 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark45(-344.7079432783334,-418.85914035969233,33.581845371379444 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark45(-344.858902196005,-455.09771785737064,100.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark45(-344.96661606767225,-413.32685251174865,99.5449975368127 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark45(-345.1372215788673,-423.3525907920826,4.222062676780894 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark45(-345.3051236080866,-405.1264995291265,94.01291942317309 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark45(-345.3305325245193,-402.2034375985274,42.94462695526454 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark45(-345.3506756005929,-407.1138143639605,29.91362931458329 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark45(-345.4418236123316,-424.1596728177086,20.623308431992555 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark45(-345.47641158973863,-412.2290836469753,100.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark45(-345.51101366944266,-442.042419973824,99.74625343052055 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark45(-345.5444586060722,-400.7623526718327,79.679975893089 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark45(-345.54644748523407,-447.8858402382561,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark45(-345.75952346521586,-451.3571738912666,54.278380433085516 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark45(-345.76793037729794,-464.6135867410786,100.0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark45(-345.8231432665795,-412.2502930141184,57.08950513369629 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark45(-346.007444682696,-415.25725355005494,77.52030531546436 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark45(-346.07419804848723,-403.2416548095335,100.0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark45(-346.0798426549005,-455.8187872963409,97.17512648398042 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark45(-346.14017752260526,-413.99453840035943,53.90092035752255 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark45(-346.2032086402271,-537.0521540742097,100.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark45(-346.23909466265377,-474.3042708312202,94.5894376341574 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark45(-346.4723174800435,-433.0244031983544,41.901661671827554 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark45(-346.5926842865047,-479.5448047600807,19.70315945637897 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark45(-346.6037337139832,-425.116757696506,100.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark45(-346.629713784346,-415.9287628658873,9.644107167739303 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark45(-347.14136047955094,-433.902108069595,73.40526588391313 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark45(-347.38131225948536,-417.4494387565707,5.484845734792756 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark45(-347.43026998135616,-420.178954402078,66.84071305214036 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark45(-347.6035835622059,-399.57161774965596,84.32955292811604 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark45(-347.65102069699515,-420.86740834706666,99.50956701189196 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark45(-347.6682884517038,-417.2872767877584,28.09330461314258 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark45(-347.72715696289004,-398.59467772841856,100.0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark45(-347.7681422295793,-414.6855797877017,75.66033908100468 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark45(-347.77123661577446,-416.92711788633187,25.666357472123806 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark45(-347.86013322891466,-462.17828607404084,21.693886821179092 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark45(-347.8658650956426,-464.5412296200611,100.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark45(-347.8928367902737,-428.22783615224836,100.0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark45(-348.00155914920157,-404.15499337792056,36.247357574855585 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark45(-348.0999929907804,-430.2135837862899,31.39611571437746 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark45(-348.11672852842196,-452.32163063139757,68.66990981814328 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark45(-348.139220891622,-424.2658416635793,1.01040326420447 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark45(-348.3138898051726,-418.45971254590484,92.79327854327548 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark45(-348.4087314448974,-404.3690713737606,7.993777045840062 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark45(-348.4893335368433,-411.4650549069938,100.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark45(-348.55399023618827,-463.9032221222984,2.612948904431393 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark45(-348.6435017257395,-414.6137617542463,74.21348055083445 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark45(-348.7086331884816,-411.5042483120524,60.41773742187948 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark45(-348.7991204992212,-401.4763097361366,97.36551977967656 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark45(-348.81269901921115,-402.2127403318588,39.47627299114339 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark45(-348.8221498383551,-447.8661405946365,60.66258877252423 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark45(-349.0030897900727,-406.2282676465542,26.909623296567247 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark45(-349.0467942355218,-413.89877778968804,51.4597713612566 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark45(-349.07587371543167,-407.0836062414493,70.99345536814462 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark45(-349.23058563669815,-423.6703135771028,39.46414784657409 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark45(-349.2703976642938,-427.3663772721495,46.63827747903821 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark45(-349.3109967252998,-420.39983897604685,81.67342559870647 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark45(-349.42769469370023,-456.07686317749943,14.458110796814381 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark45(-349.4612376019369,-448.4812444972042,53.497187103776014 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark45(-349.5223424770067,-427.94535281858055,70.14383740264677 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark45(-349.58886781218484,-419.7109888040303,59.74507143023675 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark45(-349.7409308689942,-434.34933263120223,60.458815430880804 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark45(-349.7469224484641,-416.8111155805391,100.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark45(-349.8250266372955,-397.22093098335705,68.20887940120446 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark45(-349.85144136272663,-448.5840185264607,100.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark45(-349.9047386339868,-445.68069608509603,86.19359195398394 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark45(-350.6545282219792,-397.5260761331056,15.543037068340908 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark45(-350.753043795596,-397.92024204579747,100.0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark45(-350.808491782303,-406.5974793447429,73.32327944320511 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark45(-350.9110143525308,-425.2397224049666,15.072808497256602 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark45(-351.1291353782714,-413.57997248633797,97.64849142050987 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark45(-351.30687129794916,-417.6733995543393,3.8859790070153792 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark45(-351.40225205181076,-469.78317310246814,16.337997245968623 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark45(-351.4869526427418,-421.6652191338332,12.073185026341832 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark45(-351.5877979700967,-397.1678949088543,100.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark45(-351.64099626818097,-417.05975847451316,86.60494980207136 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark45(-351.6628878703609,-396.29205883267537,15.417691797315229 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark45(-351.68703401155136,-403.14649392254233,4.4900875451655935 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark45(-351.8159311523892,-417.5384627296989,100.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark45(-351.86380230241014,-407.2156311028034,24.860589987791087 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark45(-352.0107384839419,-397.7058191456507,73.5052010510654 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark45(-352.0765742634794,-399.4809906860667,61.68542774915707 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark45(-352.0961109937517,-409.51875802283763,49.99562759770791 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark45(-352.1385050969515,-407.6727760710467,24.371654249258313 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark45(-352.15034081230203,-407.10894364686203,34.24282602300394 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark45(-352.1773663616867,-446.54350722555756,34.32114502179607 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark45(-352.1938527307277,-447.2721789914945,17.283486083217454 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark45(-352.2457724757174,-446.9237175463334,100.0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark45(-352.26278279594504,-419.37818414549713,45.90794742444649 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark45(-352.4164764873298,-470.9624255440506,31.48884949900645 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark45(-352.481978322831,-429.1076775995801,5.002796016347059 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark45(-352.56604434657777,-406.7610822332005,100.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark45(-352.6728196825107,-411.4210953538072,48.20363060124282 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark45(-352.73314904649726,-407.68737510717716,2.5656485098564303 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark45(-352.7821840489152,-412.7828772819616,63.39266280400636 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark45(-352.8066052179135,-460.626912187362,92.5160236526745 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark45(-352.8512635645443,-404.3826801576455,77.24249796570928 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark45(-352.89159186257046,-424.0034095711767,59.56961570399975 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark45(-352.9577974264158,-429.69028833743624,100.0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark45(-352.9680763949685,-396.97183624152075,72.77707649795028 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark45(-353.01620219498557,-434.8977812375563,93.99601237727697 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark45(-353.10147349173536,-396.9849655933375,17.691844243363885 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark45(-353.19662753858023,-394.89765176973464,22.296777379397554 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark45(-353.3227433452756,-528.3417594602298,100.0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark45(-353.3421056290437,-396.9195312117661,74.98993834194735 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark45(-353.45337556902825,-429.07393906201986,79.8669929820627 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark45(-353.7133303420516,-401.85633731921746,50.20688495625697 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark45(-353.74778235594897,-432.6101241320145,5.202958686336075 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark45(-353.856437051415,-452.64862177015556,66.08854366793238 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark45(-353.9167339350889,-453.973525869657,35.45388913750617 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark45(-354.0102903358109,-407.7797971669793,59.0018240739096 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark45(-354.22653248346296,-398.7242556936785,0.05227232956987393 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark45(-354.2692779873625,-413.1313153105806,100.0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark45(-354.2801792485155,-430.05169141471464,12.696075481839685 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark45(-354.2983912393512,-430.3116591715135,32.25582432527773 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark45(-354.3354351994337,-428.8555046568988,100.0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark45(-354.4790589465912,-410.9703414742151,73.80645133246807 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark45(-354.66894202509883,-408.54751711084725,81.94558040232064 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark45(-354.76703932826706,-392.73121664986434,100.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark45(-354.8880259914885,-405.32556014475915,48.396850895704006 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark45(-354.92734145636155,-394.33580315065643,100.0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark45(-355.0185360141591,-412.4675909268636,76.4986308661033 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark45(-355.0586717148676,-439.58677354430364,18.339529074636232 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark45(-355.54146518485936,-390.82135808255424,26.29947339506586 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark45(-355.61377873897106,-433.33666382235157,45.45230986434581 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark45(-355.76034199501765,-404.78088634901496,92.21353379294436 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark45(-355.81044363542634,-398.79546888333806,38.12580820195234 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark45(-355.8187814674861,-432.74729129025536,46.19180369526728 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark45(-355.85343528232664,-415.8860915536226,72.81519650594437 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark45(-355.9201357519459,-398.51849643483433,3.035347985202691 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark45(-355.97246504882816,-481.77806748171946,100.0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark45(-356.12635600656085,-392.5285965397325,79.52524187240871 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark45(-356.18669094299014,-393.7737499993239,9.140472189234572 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark45(-356.28254272352007,-435.5284079254748,40.5920075954086 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark45(-356.3815597114771,-397.8127517630551,68.86153184003797 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark45(-356.4273418175535,-418.9628879812945,93.91325583389224 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark45(-356.4499819084442,-426.15070117867947,93.43566178593329 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark45(-356.51641970061314,-449.0738790969375,66.91416119132617 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark45(-356.56648452045886,-424.37605064893353,54.05318279999901 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark45(-356.63280744499133,-479.14021423331343,5.424981078616284 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark45(-356.6718248973083,-401.8044349779043,64.84400256491148 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark45(-356.78348829563475,-396.8775023816768,49.22246342764413 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark45(-357.1573655968024,-424.6005465099212,24.33903179872911 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark45(-357.1940098585775,-403.8121523717066,100.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark45(-357.2492596059029,-402.32476350756224,49.7521939343593 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark45(-357.27959606870877,-416.792559961091,43.210967099370095 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark45(-357.48923525456036,-393.8638823058372,13.195124522485898 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark45(-357.54328840020736,-446.1397622896939,53.70175526630803 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark45(-357.67336369045296,-451.557948819742,9.626702071404452 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark45(-357.69248150794454,-410.49425065092186,100.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark45(-357.7432126804832,-503.7506615817508,100.0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark45(-357.7773265428228,-418.8966345494863,72.53986445647956 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark45(-357.83837293375626,-458.7529687166619,63.22960601798886 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark45(-357.9519083085228,-390.50570597492606,82.46610103366478 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark45(-358.0054852033787,-411.0722898812223,94.55013019280386 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark45(-358.0634560993591,-437.00711181051196,52.958062984131516 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark45(-358.4068629843192,-404.69801227087873,80.42511770046366 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark45(-358.63383524000494,-439.17864401942023,80.36220547479346 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark45(-358.7144560523785,-396.10856018636593,83.83202689019072 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark45(-358.738941552088,-429.20839637782825,55.778723996484956 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark45(-358.75911925572336,-411.29937355927643,34.47582348372188 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark45(-358.7998763380169,-449.2603820569675,2.7983129812169523 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark45(-358.81166930704035,-422.3741262106059,100.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark45(-358.9015724586018,-400.42443845210454,50.02683543337389 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark45(-358.91514607386904,-387.35595893654965,76.24560521237862 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark45(-358.9407673471685,-394.6875411114362,25.52536913561532 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark45(-358.99413225636596,-395.8845238175886,4.11973981846468 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark45(-359.1739377483146,-400.5258459635936,100.0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark45(-359.213249195016,-417.61228948234145,24.230441536795382 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark45(-359.2626795842844,-390.9567312039959,27.684257109230217 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark45(-359.35282666721884,-416.15644483958266,84.27691918903119 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark45(-359.38483472004475,-391.29471468609194,32.76188196565258 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark45(-359.42805993572443,-465.69069193784236,99.76044461801445 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark45(-359.5414818664257,-392.3169283574176,77.38027599466324 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark45(-359.59290849374514,-394.3685603683476,51.996511250501385 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark45(-359.649615207186,-434.5648613799858,59.53907493439158 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark45(-359.6885390445628,-389.80908677475634,13.171205379002515 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark45(-359.7712700147799,-418.7212281677545,96.99383672650708 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark45(-359.7997406517748,-388.37061387897796,41.87428448107326 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark45(-359.81679300582425,-472.8874870169672,100.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark45(-359.89081081945903,-402.31282218139876,40.66965924809813 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark45(-360.08599311963775,-452.5845435452952,47.8709350838449 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark45(-360.2077296436267,-414.7870626852514,2.841338205163794 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark45(-360.23701400561566,-426.6431469652267,100.0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark45(-360.2870510818354,-397.54258369873196,20.266484079696482 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark45(-360.50617815363637,-386.2056814665079,20.074548851400536 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark45(-360.5140639041908,-398.23253388186015,92.36803017287653 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark45(-360.52331114848135,-419.17285801909924,76.83609340231268 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark45(-360.5415275696433,-394.6163595995495,100.0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark45(-360.553787507324,-532.9333629453797,65.17762676106759 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark45(-360.5640450247287,-415.63063163999715,36.194822957743185 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark45(-360.6417138646801,-385.4085050038275,49.68063076306203 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark45(-360.7554713144255,-415.054439572134,56.75630438780513 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark45(-360.78816717428043,-386.18008706921216,9.645019673104443 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark45(-360.797253767603,-394.3398498266937,77.26021986783596 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark45(-360.84044804074176,-396.33043645514164,57.45111430727968 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark45(-360.8632904178489,-435.2399654309658,93.51821158033064 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark45(-360.9646439732652,-425.858533599242,40.36195595727051 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark45(-360.97402195658094,-421.8344537936081,97.0984531881978 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark45(-360.97719088346,-391.5933923301976,18.86947841914464 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark45(-361.01225736243316,-409.60940805101035,81.48838963953628 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark45(-361.0917845095876,-451.82083127202884,70.13457035864639 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark45(-361.22741494267035,-430.3017692734899,6.9074423871189765 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark45(-361.236944893147,-385.1054707409102,100.0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark45(-361.2537069311868,-388.2837598377786,100.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark45(-361.2967594796989,-429.1194681505985,99.63590335607697 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark45(-361.51325033186714,-472.95317202559704,28.942890846629552 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark45(-361.7317022400162,-408.3330412128711,30.03743901443775 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark45(-361.75221631564557,-412.9611020162302,74.72777568190872 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark45(-361.7629803894518,-392.1375466243151,1.8019984924722223 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark45(-361.79758227475804,-407.49057638334057,83.14163326682822 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark45(-361.8657836416695,-405.14217722695037,18.781221560462342 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark45(-361.92868939532104,-403.42957342617365,34.743033261663044 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark45(-362.0701833956256,-418.3041773507661,100.0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark45(-362.28103864992374,-435.2489577344435,68.36859447367323 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark45(-362.3786761885619,-389.629760638892,36.064074473524016 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark45(-362.39124276316903,-449.95696537661144,2.6762394760933716 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark45(-362.5725301080595,-401.32472198002534,67.83809435867079 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark45(-362.6057481160832,-402.6126464067204,100.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark45(-362.6681591282166,-441.22963105222925,96.17030266807413 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark45(-362.6794531625559,-389.67543612159824,54.89467141892541 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark45(-362.70599387884215,-419.77445718525087,91.21399074661224 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark45(-362.826899563213,-385.8886806315245,19.382465947010104 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark45(-362.9549623075389,-403.8386462091361,27.643568338127025 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark45(-363.0399517448316,-397.8108471976981,13.862050487258244 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark45(-363.0851423094878,-396.44291511451655,100.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark45(-363.21371167992106,-389.0671795582843,43.351546696826375 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark45(-363.33285746249237,-435.7345806095521,44.50829423751287 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark45(-363.3638749812312,-418.6876848989591,23.37613393180898 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark45(-363.40073943249985,-421.6187754977742,33.181908160543145 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark45(-363.42698709395785,-401.15904892890745,100.0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark45(-363.55150671787214,-411.5558619321078,29.698914847939676 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark45(-363.55505098328155,-403.7613070537078,21.050974575116072 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark45(-363.5590724306446,-387.7313991700707,100.0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark45(-363.6651851794795,-397.5363009193703,6.646874697279333 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark45(-363.9176751633143,-403.5376898481008,31.482700924225327 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark45(-363.9867069992377,-416.56662313125105,41.049640948672106 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark45(-364.1515368888285,-393.41470781838416,27.55201749713511 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark45(-364.34000023535316,-383.0437053094986,88.42365032612872 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark45(-364.3659890723469,-406.69700425426095,99.93620423679249 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark45(-364.39951807579047,-387.50253687423236,36.102294178737054 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark45(-364.49542346988756,-444.85105760886836,99.1289464380012 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark45(-364.654819699567,-388.8053882568635,43.351688422863845 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark45(-364.6548871745184,-506.8483990618301,-3.605769941458885E-4 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark45(-364.6587794393405,-408.2696649944706,2.3550734057951956 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark45(-364.68262213070193,-442.6289453357946,16.9873725479909 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark45(-364.86604003956785,-386.6980901065089,77.01048114052799 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark45(-364.8910090994383,-421.5101642701119,47.685387591139374 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark45(-364.97320453708943,-461.1169662326879,7.551662523662756 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark45(-365.0173342006866,-383.79495620651494,97.10605810479461 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark45(-365.05264326299545,-405.3639156844149,100.0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark45(-365.15409614811136,-411.50366442728796,8.099625242996012 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark45(-365.1550699624385,-390.3412860484995,100.0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark45(-365.40458910543333,-424.40937038874813,100.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark45(-365.46999619481306,-471.4036084957295,51.65136872947363 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark45(-365.4818428792529,-409.14814675837727,98.85704387929232 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark45(-365.5765557333827,-415.45429569950875,2.4822378678821906 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark45(-365.6403591307083,-435.23470140605355,100.0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark45(-365.6836484707287,-391.10146085033637,100.0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark45(-366.0782252796044,-389.8951022066437,28.633667918222898 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark45(-366.20989557648943,-382.38003329617555,9.235319616396723 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark45(-366.2622556144564,-383.94620149382115,100.0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark45(-366.3638854699311,-399.4590272065326,4.5712669867415485 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark45(-366.4760674047067,-416.7149277055502,34.57897791167264 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark45(-366.67421098855783,-457.23118945088135,49.70923343610693 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark45(-366.76489683472266,-393.74220342121214,100.0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark45(-366.79104197841383,-389.0068959189967,52.33769269421664 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark45(-366.82819359262925,-392.9521884916642,43.19146502924613 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark45(-366.8687705699774,-392.55388831313127,72.51126289007755 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark45(-367.00790391301496,-385.9305429284061,52.56615433110014 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark45(-367.1838523012464,-382.1282377404134,99.64781596447506 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark45(-367.1994949199406,-402.1197195627932,24.52906396807026 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark45(-367.26204543044656,-393.62299519536487,100.0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark45(-367.34039922131956,-531.6867569198123,48.63824158170007 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark45(-367.3933496105904,-437.0335417844068,79.13724822692521 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark45(-367.4699474124013,-423.23663007051704,28.430730617076676 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark45(-367.57075322571467,-383.0147627381133,24.683657603414872 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark45(-367.733208199117,-396.5623605339402,90.44043660395208 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark45(-367.92401052971815,-403.78942912049587,11.66279462964323 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark45(-367.9742767170547,-395.9351974932989,40.64665569893066 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark45(-368.0124687006418,-386.37431609926347,100.0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark45(-368.04461630582733,-414.06822670325005,73.18410345038427 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark45(-368.06368356001997,-426.9807445647584,100.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark45(-368.10453725122903,-424.0444212329766,25.899860952940074 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark45(-368.49595326681055,-402.3345668445844,100.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark45(-368.53140371268915,-404.0003461874554,100.0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark45(-368.53278715106904,-406.9120594946235,30.12794407047477 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark45(-368.59970741295336,-387.3646838894807,53.16396090643667 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark45(-368.6550819320033,-453.95113809318923,100.0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark45(-368.6899467826084,-442.10414809300187,48.541005199423154 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark45(-368.6946606825641,-391.2376734000982,100.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark45(-368.74072939629093,-419.9912688883902,85.22205372650862 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark45(-368.75809117676977,-429.7010382358052,88.31650129841978 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark45(-368.80521384190916,-379.0756006592869,81.58738504910704 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark45(-368.8288278208754,-393.14717814895664,26.84567905628259 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark45(-369.0756063139409,-402.37606554391783,32.64298073388849 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark45(-369.16589643267343,-417.38883368561073,82.05052471509208 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark45(-369.2355164933449,-397.62457756169374,97.80211554938131 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark45(-369.2435593470988,-377.8345540482463,43.095691428471525 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark45(-369.40256771850983,-406.2733562979395,25.360135645764117 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark45(-369.43297041294716,-390.20105409822617,60.13603999536548 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark45(-369.4667593284023,-383.102714549445,10.446335270160304 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark45(-369.503611315494,-393.4993870959031,86.02421311833882 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark45(-369.50719168668877,-452.08215052141344,100.0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark45(-369.5768055992165,-400.21142261114375,95.65099184126362 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark45(-369.89467690376017,-383.6053574420714,64.98980318020295 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark45(-369.91149569491586,-381.358086648671,36.714385038168075 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark45(-370.00242774760517,-416.2631347594582,84.8294840416558 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark45(-370.2641860644486,-392.07029152836935,95.66504063255681 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark45(-370.3018108034863,-409.35989195800454,8.782271647838783 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark45(-370.4064256449251,-396.71987180340165,48.3599855078279 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark45(-370.5861268839426,-385.253412465946,39.51027479439989 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark45(-370.6985317731302,-387.76736796825173,53.16178750643181 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark45(-370.70084188712895,-401.1401765512622,63.872186907383934 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark45(-370.9299355349076,-375.28838938915504,96.77804224367065 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark45(-371.1701152929318,-386.71033326428665,46.63688411266995 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark45(-371.2123015859385,-379.2843808400447,74.18901317151182 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark45(-371.36063790043426,-390.03475599874486,27.490606185734975 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark45(-371.36360523102866,-423.51721660890985,39.08989507519169 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark45(-371.43988084117456,-383.21963617778465,29.696496056080093 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark45(-371.5773972026236,-384.49660206673633,21.138204731461286 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark45(-371.5877702436965,-410.7061190946491,5.31137354715608 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark45(-371.8506267669313,-402.84346718115506,100.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark45(-372.0307911992709,-388.9309175274833,100.0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark45(-372.1474408595572,-379.2447257118514,88.92424047476791 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark45(-372.1532330852384,-381.6258331363467,29.83688159690672 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark45(-372.185989609024,-407.69231968307247,2.623614173639808 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark45(-372.3638249160106,-373.9756675921912,65.3264034630667 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark45(-372.6084952108791,-374.4286075771389,54.08697242839705 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark45(-372.6882130449715,-380.74644309448024,88.25607483320192 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark45(-372.6987937004708,-402.2498120228622,91.02545421051812 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark45(-372.92526936960326,-394.27184482341175,95.87675379894694 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark45(-373.0322072908846,-380.01180599831054,19.610560986509583 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark45(-373.0448104710123,-406.2413368730864,35.325110431062825 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark45(-373.0809191074094,-382.2295471708467,70.9291989559114 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark45(-373.1842316404342,-396.0524305877452,49.149132431503006 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark45(-373.18787413213977,-410.42797429399855,51.157225029747366 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark45(-373.2452280182715,-379.2002475044178,100.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark45(-373.33663158098784,-427.0977500174712,13.062949848228754 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark45(-373.36656863520267,-388.6991848946568,91.5055301916106 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark45(-373.4054839759374,-398.00607404699974,7.922801852914517 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark45(-373.45616621468554,-422.69427590584155,27.647430308880885 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark45(-373.664821777936,-388.94094168548537,48.03085613709618 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark45(-373.7423352602615,-412.225455491135,100.0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark45(-373.82734168276284,-379.4022099683998,24.9293321484505 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark45(-373.87519107408167,-415.99082859301177,35.0229841398631 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark45(-374.0174404927323,-374.901740366461,30.754057459050813 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark45(-374.1792999704926,-381.9487803731385,58.50569730310872 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark45(-374.1947924692524,-385.4068790699082,20.245294231463077 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark45(-374.2751015427434,-376.1484115017323,100.0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark45(-374.27931050598113,-384.1867029320763,6.886067882448074 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark45(-374.38502372787616,-397.0601551993984,90.78342203315626 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark45(-374.42368439233974,-382.8702595832098,100.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark45(-374.48486783265173,-404.4287178946891,45.18497904883384 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark45(-374.5655012407423,-413.43341187594325,44.86449927171546 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark45(-374.6401434326278,-373.8118899417637,100.0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark45(-374.7083205996,-416.8027527539781,5.290525997855324 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark45(-374.8662393820357,-439.3406912418319,100.0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark45(-375.24072860467936,-381.20841992567466,61.058839584178344 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark45(-375.2486676715609,-397.72666370208117,68.05894564170873 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark45(-375.25663091897593,-396.68340068566937,51.936875561864184 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark45(-375.385706589496,-441.39443307358516,23.62287323341701 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark45(-375.4725581119227,-434.61310494739206,100.0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark45(-375.6075371766357,-371.8173744736592,38.40815345845675 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark45(-375.6371484836827,-377.61162096940933,100.0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark45(-375.70870119343857,-379.2731110067173,95.68594640201835 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark45(-375.91238453995464,-376.83980951354243,96.72815502973847 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark45(-375.9787772834614,-405.6644338623199,89.3455131451042 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark45(-376.2259782820146,-447.7981096203772,100.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark45(-376.38326509246247,-408.0487083189428,57.293103854751905 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark45(-376.54845164700833,-402.3298910226141,68.65429929535807 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark45(-376.5505835267479,-422.2199341627221,70.57805763710249 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark45(-376.5665055812746,-384.9450979571534,50.3068112435824 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark45(-376.57065651246324,-446.263592361842,92.90561539732445 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark45(-376.8341634795978,-438.93931803692885,100.0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark45(-376.86796590472284,-376.1291369684047,68.55721366318716 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark45(-377.24026585816983,-375.14310914478517,56.4986747993855 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark45(-377.46578121794835,-379.4407501869617,34.908243633211555 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark45(-377.4935084945556,-419.79783443623836,27.931427700388994 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark45(-377.5182585622248,-377.7286465926629,100.0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark45(-377.8035137375844,-424.56554427026117,62.6362368365551 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark45(-377.8291800455954,-372.18769930538093,49.229082394600454 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark45(-377.8948149577975,-371.18071524423374,9.606876164516294 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark45(-377.9304124435289,-424.3834837104331,50.61103953525645 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark45(-377.9457431322297,-383.03519955028196,34.55281638550704 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark45(-377.960911783046,-394.9822447251437,73.60415830100769 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark45(-377.9681580375081,-372.1642789461466,6.401614390142512 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark45(-377.9980458937983,-449.16378719402366,81.52094091515076 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark45(-378.0002623828722,-370.12827916623183,42.26306348596708 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark45(-378.05099943869135,-388.1501315346252,80.02218103572852 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark45(-378.15771417100655,-376.48147981898154,86.40467353786528 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark45(-378.3371602208938,-401.64103164863815,71.34686503262492 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark45(-378.3539118359963,-379.2428318796696,78.08581566638088 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark45(-378.3759226307503,-391.4010640394897,100.0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark45(-378.43020870382475,-487.99242054722225,23.839926508336106 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark45(-378.46624255927344,-372.45684934839136,0.8978261838725583 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark45(-378.4869046651288,-374.43759395391584,62.6559989609915 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark45(-378.559594689261,-376.75562789761295,91.73186972487716 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark45(-378.6977047925977,-420.41557881958715,92.2919007290854 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark45(-379.1473988034251,-381.90421001785336,96.9309132526939 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark45(-379.6462295990792,-409.6794656769012,70.52762460686154 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark45(-379.6490775627309,-423.07115544955184,6.7147810378475015 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark45(-379.67708708873835,-410.99064956545845,4.522922123373391 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark45(-379.7939696789115,-381.11418539396516,75.35379171016316 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark45(-379.81798604997886,-373.05131376665605,13.951653970620526 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark45(-379.8733914100639,-375.63341325539415,0.7661071083355642 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark45(-379.9323547390986,-391.4990326715642,62.301318373903484 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark45(-380.17319155455397,-405.50762274304407,100.0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark45(-380.66846176210396,-374.0506793829002,33.44600650944511 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark45(-380.70006072304153,-371.1864868421136,80.94887478399667 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark45(-380.7403213169525,-430.8824105713559,34.532104480010105 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark45(-380.7909733072752,-417.9183969178722,21.82134333815648 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark45(-380.9246406274764,-381.20068519774605,58.544373775444996 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark45(-380.9766538774652,-376.49614150860987,2.4242966049779113 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark45(-381.0816034682236,-397.99009692837313,22.754323573407504 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark45(-381.1779521453469,-382.74129540076655,73.75450715761227 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark45(-381.1982930484967,-416.61714516673567,100.0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark45(-381.2519361741804,-371.17668302629863,28.91838925389797 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark45(-381.2968054684692,-394.7998126316625,55.950329106453864 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark45(-381.4103439846508,-398.54208117956125,10.142349843064522 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark45(-381.56463946108636,-387.36177694783817,19.515947794471145 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark45(-381.58002476899804,-398.2113712199706,67.27990068182373 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark45(-381.6384001127896,-389.8899529388637,9.088526179653584 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark45(-381.6725959946764,-473.29944684406615,76.96144211102481 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark45(-381.6827868517044,-370.04960676319274,100.0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark45(-381.8728060469681,-369.4920970224835,74.35657485848637 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark45(-381.88377573010814,-386.95861134809564,100.0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark45(-381.971747674887,-369.6987004549632,74.71218187814739 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark45(-381.9730427857925,-405.0284045554803,3.4807385588791817 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark45(-381.9836912106344,-384.9859047361677,100.0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark45(-382.0461333101384,-369.8403768888124,7.568268115678563 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark45(-382.1220651331198,-494.41295807369335,100.0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark45(-382.23083752417745,-400.32381766369025,44.568640040801284 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark45(-382.57514320180445,-411.73448054416167,78.27209442766602 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark45(-382.716639556128,-370.7311665984998,77.55659213771662 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark45(-382.76004455140486,-390.005236366147,53.62291710482381 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark45(-382.79343278331015,-384.77526937391167,80.03177431419851 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark45(-382.8552319002031,-397.20618859118974,100.0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark45(-382.8893648652776,-372.4200637922099,29.306891383104528 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark45(-382.9502261769116,-374.03555267515054,100.0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark45(-383.0306935781566,-379.96033970942653,36.77802412382144 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark45(-383.04821057052,-431.0655139880373,29.74123139779533 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark45(-383.1557349012695,-408.38885864447906,16.155050956644914 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark45(-383.3289417055098,-373.64376049641464,100.0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark45(-383.3436593560855,-438.2669853789304,44.89179220367174 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark45(-383.4316939122739,-379.215891429566,100.0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark45(-383.472372912088,-363.90105891128985,61.5361658140321 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark45(-383.54370916301343,-421.3067346514394,100.0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark45(-383.76542005816185,-391.3100563894101,100.0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark45(-383.7836625410882,-380.3930016326013,26.048148125518026 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark45(-384.1108169629018,-409.9073809162562,32.62847370511295 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark45(-384.1116805503035,-388.22155934533373,49.576376814319275 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark45(-384.17947607177996,-416.6527199122113,81.8992118930457 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark45(-384.2834575382852,-397.10252453303667,100.0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark45(-384.31575077025906,-371.4896137846728,100.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark45(-384.4025507948593,-386.68017653509605,36.79691085094515 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark45(-384.7684605400171,-413.4336464832242,71.57718783958389 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark45(-384.99939409294313,-416.1637172828778,25.21381628284442 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark45(-385.0028072688421,-369.6900882643287,2.1304356237349396 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark45(-385.0474463068197,-431.86820321348904,33.201832566387 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark45(-385.0744597786894,-363.4124533570752,92.69343477103843 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark45(-385.079380185469,-425.28469784502477,45.40304467264579 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark45(-385.44983546325386,-362.8425436101844,20.863350618539585 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark45(-385.5640845154628,-367.57685369336025,100.0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark45(-385.9277899927164,-386.46856051865166,27.55052069885282 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark45(-385.9807232034321,-370.3229152791756,74.7598029546649 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark45(-386.0933465737327,-416.7645730004497,48.743030872074314 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark45(-386.20577950646503,-370.4447428126503,7.264917343596707 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark45(-386.23502074713247,-365.04239011902155,42.2686949668082 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark45(-386.2696146156734,-367.8122256671071,23.229424845546973 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark45(-386.2852230077167,-364.38169675096333,45.13682385201491 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark45(-386.3538560883993,-379.0637914481488,100.0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark45(-386.37899461847235,-500.9467876727292,28.602044294369108 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark45(-386.38733531578464,-423.6697098611781,73.190773186077 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark45(-386.67683990774805,-369.0278892095613,88.73519268453016 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark45(-386.7672574614116,-367.27215071668417,10.275498003344623 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark45(-386.7857516227079,-370.2372203234139,92.67838635436766 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark45(-386.7860804497925,-363.46231465495833,40.219454924364015 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark45(-387.04771688155665,-370.37099254493864,70.491744378579 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark45(-387.0581213054297,-427.6028073425541,28.471785472453917 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark45(-387.2923795320595,-397.56846586654103,35.012776591734394 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark45(-387.32219780198267,-463.5968588299181,67.36739259797102 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark45(-387.3504469735485,-390.49127799609687,59.60824142170725 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark45(-387.4169052755711,-412.00935488734353,100.0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark45(-387.5359785218054,-417.79523794206426,97.819645030083 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark45(-387.6323558138644,-373.38304476035574,75.27132941887933 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark45(-387.7321995506178,-380.70418558191903,46.05699051111938 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark45(-387.77647454310113,-372.78837428134256,100.0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark45(-387.81501215225154,-367.968994116061,37.031110091023436 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark45(-387.8645748380904,-387.71860293737956,5.681070303425713 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark45(-387.92184623001486,-384.44680375796986,27.295121760145946 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark45(-388.2980403168511,-359.7382479882712,24.771498321259244 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark45(-388.3924668471866,-400.98906560943044,86.25391014099972 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark45(-388.42621132564454,-358.9098007461328,100.0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark45(-388.6230493917956,-398.0191857451039,89.13192806048428 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark45(-388.73371619382795,-404.2354711129485,38.771630450366644 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark45(-388.7391659794792,-360.6127510068473,45.237211828420584 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark45(-388.7765572544499,-397.1090761606796,100.0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark45(-388.9609319375191,-421.949498087522,95.51471986551883 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark45(-388.97413933884775,-412.2483552188983,45.52879164246272 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark45(-389.05430364961563,-368.30332059224406,66.21528530682698 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark45(-389.1012323572521,-361.0182578908576,71.40237078360215 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark45(-389.14901822821474,-359.3369796098339,31.51111678121191 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark45(-389.3523554842416,-364.2925129408846,44.60322513852023 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark45(-389.3744499491645,-365.7890984064309,100.0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark45(-389.40843048359187,-366.4004363926485,68.88282834885064 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark45(-389.43351243031645,-405.35916651795185,32.897831866765614 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark45(-389.4993920446433,-370.80942581190345,74.58709074319054 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark45(-389.5616737014056,-376.1164616821331,46.61492454147441 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark45(-389.5907096220449,-368.4662657634267,2.4662806291883532 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark45(-389.7545834501886,-422.6687535141183,12.784866427173938 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark45(-389.7968268874172,-356.43146513671724,41.13853374992851 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark45(-389.7998893568297,-404.979666442437,70.17172355814145 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark45(-389.8297173819247,-369.26908213086006,97.8424581179726 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark45(-389.92855582639334,-375.91253188903806,100.0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark45(-390.05190184538515,-382.629019545696,62.69134144596197 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark45(-390.07013141570485,-408.11420302005376,12.347171370341954 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark45(-390.18065955064503,-380.96076148616237,34.96047334544167 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark45(-390.3209701535121,-355.9423552451463,93.84393153323114 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark45(-390.32422235310617,-415.3220700757021,80.11419100429177 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark45(-390.33425926849293,-362.69728336200427,4.877539621361507 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark45(-390.42442796036465,-365.1846362431974,40.76404783697126 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark45(-390.42817880351834,-369.29107672150894,61.163435914937 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark45(-390.45190060193744,-363.83634275050196,19.728813599380544 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark45(-390.54237487707985,-371.495340657479,92.67268280533105 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark45(-390.6004032705252,-358.6740873018579,52.39838078745623 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark45(-390.68343430381196,-401.7548986454502,96.07685203609259 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark45(-390.712873157217,-363.0099762742021,57.37869026127791 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark45(-391.0121456660695,-365.76104618208115,30.340367872438122 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark45(-391.11832828157213,-366.29979606724805,100.0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark45(-391.13263407506406,-388.698091010668,5.344071054905413 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark45(-391.25382225357964,-357.07670657963826,36.587765798409805 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark45(-391.3437714655066,-368.8351214820158,22.61956389929378 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark45(-391.5382989596213,-442.4094721136076,2.1627514246455917 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark45(-391.55464142875576,-365.0066420867302,47.46116950711078 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark45(-391.60340837706656,-382.86181328513493,100.0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark45(-391.6893225054359,-358.6566776550782,66.24886929845627 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark45(-391.8620450265846,-359.59929617599136,11.156088676731343 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark45(-391.93233027225455,-375.73646115110745,71.61934374871538 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark45(-392.01030839821277,-399.2829477365299,75.87097915998164 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark45(-392.07885113696915,-390.69578914339235,7.8297623736578 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark45(-392.1217598717971,-358.6768816165678,47.55237724772198 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark45(-392.1233680830214,-422.72402454734754,100.0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark45(-392.33985831199703,-391.29974583324525,22.14544046564029 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark45(-392.54455597443547,-371.3383423977772,100.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark45(-392.7464555991207,-387.28366293389854,78.00361817928993 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark45(-392.7996466743707,-401.0923212421674,72.53502631366274 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark45(-392.8797338273395,-365.08558857030965,41.92338320046599 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark45(-392.9550453835473,-369.18424476133225,62.201291389667006 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark45(-393.05827968344397,-397.553310184024,36.225109436855746 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark45(-393.13396428726696,-357.60210979094614,54.62117441677066 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark45(-393.2249444118868,-367.3445026813489,82.90466860561895 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark45(-393.2883441108521,-428.9348918820998,73.73149783941716 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark45(-393.4206524738776,-423.6826728460625,89.42738279556795 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark45(-393.45606282645406,-385.3827669978448,48.0848222459179 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark45(-393.4826385074933,-354.45649575738594,100.0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark45(-393.4951293068193,-377.8514046008124,98.1178510064386 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark45(-393.5073456269466,-431.3021918368135,21.91472889542257 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark45(-393.52877580200715,-384.677084673125,63.410518102851825 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark45(-393.82546127278755,-369.44494182386904,55.861219310939845 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark45(-394.0224044310605,-363.21786906693336,65.53252559870123 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark45(-394.041624694601,-400.31406499414965,47.59640350306489 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark45(-394.1089730860266,-361.064027898011,16.051927422859436 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark45(-394.25704957371613,-402.21372063186465,16.379245478359408 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark45(-394.30453904081446,-358.2653358259469,43.72350685580753 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark45(-394.37725465133747,-376.1934531360382,39.385325796138346 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark45(-394.44342456785637,-379.8089400650161,52.391703605251024 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark45(-394.45550915699795,-353.6090933051101,78.10306992792212 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark45(-394.4657519145815,-372.5404642179819,100.0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark45(-394.53821700575503,-352.8440978052224,100.0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark45(-394.5524993038587,-362.83976699906157,80.99673651258627 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark45(-394.64127428800174,-414.94481155109946,55.06817576401161 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark45(-394.68866116013976,-381.3654395800152,100.0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark45(-394.69196090255645,-360.08523444763546,6.851645400843481 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark45(-394.76975704556077,-362.6345059251307,45.551524141298955 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark45(-394.8007677626759,-382.9682497878814,60.81737054330026 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark45(-395.12211148439496,-351.6409860215838,34.12235174179878 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark45(-395.1968798011743,-379.61410251507664,54.02818312985596 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark45(-395.2177505523469,-369.9326568412181,41.68360794722676 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark45(-395.2976036769344,-369.1122456176627,15.304582204932998 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark45(-395.36769189777306,-377.2938565248934,62.567916657023545 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark45(-395.64641412678696,-353.4427964977589,84.15059080278093 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark45(-395.6634974882499,-372.0433952658858,95.97392033934872 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark45(-395.8265282618418,-394.0513572519125,33.49171280036609 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark45(-396.29771149001834,-362.2056589576332,13.672068659058937 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark45(-396.3543386048723,-352.6320053060879,10.603320946639798 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark45(-396.4036564146734,-394.2237236182214,74.49126478300991 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark45(-396.49599676636683,-351.7553061153712,42.48806201512275 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark45(-396.5837994022153,-410.0546912360166,69.06995725973195 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark45(-396.7355853440024,-357.8986453497585,83.00872837974507 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark45(-396.7910507033381,-388.6092897435276,100.0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark45(-397.11089302859943,-349.15845759758514,48.299703383118896 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark45(-397.11456582397363,-374.25385242842617,77.97315148335352 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark45(-397.1187122026384,-383.25102355672186,31.29176907046289 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark45(-397.2671354019704,-380.7353728043441,66.81442721767533 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark45(-397.29969470132596,-369.0032858236507,53.226971834517514 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark45(-397.3288355301814,-402.62999587576144,44.52165846792937 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark45(-397.6904319543822,-411.0928174333977,24.384135114767375 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark45(-397.7191004575725,-367.21981207368987,53.41181199675583 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark45(-397.7231160694423,-434.61009684248586,68.1910152340158 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark45(-397.79402992155866,-349.44480173817504,7.215322292446615 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark45(-397.99277138595477,-393.3650104533491,95.60679402348978 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark45(-398.0627673716192,-353.72595967628774,27.817268856098323 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark45(-398.121665281732,-374.38567679681745,79.69342137977883 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark45(-398.1637762739461,-396.84719554190224,21.406999174421372 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark45(-398.2608233780131,-406.3271686649321,96.19847259855521 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark45(-398.2923571874177,-359.05952624712637,85.2137036684505 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark45(-398.3126238536912,-414.0073663695704,75.93160696895293 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark45(-398.5120623557838,-378.89079822373566,72.96595409758135 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark45(-398.5704509218604,-367.5431226250506,52.88092029877083 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark45(-398.70262250997234,-369.69576473891067,19.95629534315168 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark45(-398.8291783694554,-371.70634590268935,38.147016755535674 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark45(-398.8343179284942,-400.7476270308375,51.28956421969442 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark45(-398.8921732993293,-359.5808792327582,88.88418123014051 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark45(-398.9778230425445,-354.5289134736463,62.138404925477175 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark45(-399.12521985228375,-384.79869573126643,29.440895620686504 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark45(-399.1361579814267,-423.1800010871206,79.8997854691286 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark45(-399.14882725508295,-352.79854056830123,29.641463304979766 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark45(-399.1804963918844,-374.4952782033484,31.63164847271679 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark45(-399.24092334180256,-369.7042426160433,86.34621509219821 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark45(-399.25988933536956,-348.9464033244471,44.85533781479708 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark45(-399.52201513014927,-402.10523152464106,72.9916661232742 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark45(-399.60575388152256,-348.6920011380928,34.45304115012519 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark45(-399.6140362067014,-364.0130774928968,46.06079131295303 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark45(-399.6479691712665,-380.15424195281525,90.75787681127946 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark45(-399.8506666341352,-367.9034184331027,100.0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark45(-399.9056740779404,-349.48933616964933,85.36224657661523 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark45(-400.0057702320738,-396.69259959585577,79.8001539431196 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark45(-400.00817325622796,-389.84715302676966,11.152160238721564 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark45(-400.0951908231863,-385.0212279944846,100.0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark45(-400.20574364688497,-349.8810102543073,51.648667899075235 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark45(-400.2534893178663,-390.44579474167574,67.90942419594387 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark45(-400.3746503779788,-394.90926938457534,100.0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark45(-400.5345317376329,-348.74486180722056,36.509891338679125 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark45(-400.6686923483325,-431.1953316250781,10.84968564662772 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark45(-401.11788510653645,-362.9103226590313,43.3890842337764 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark45(-401.16944507453456,-357.7051480242912,37.86241620876734 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark45(-401.24511330572597,-389.147348703815,74.79920229336798 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark45(-401.337247977812,-357.4969812090132,11.513717219795197 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark45(-401.4577218115361,-369.2291596925373,13.568655794329885 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark45(-401.48938066605734,-382.14203671835526,8.05365096960746 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark45(-401.54090900600306,-356.9257143380629,83.02014004020259 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark45(-401.69735210978524,-352.326947807419,53.45311928608183 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark45(-401.8271248057096,-351.55947705917066,36.882400828824814 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark45(-401.9920707360564,-374.5824828868461,100.0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark45(-402.07024410789325,-358.27771608460847,8.580129280952931 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark45(-402.11629555924117,-360.1416474554487,33.5973543350928 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark45(-402.12160390286647,-381.5390845879015,33.03147449669595 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark45(-402.1334513413366,-377.19072372226043,100.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark45(-402.13507450699416,-370.05641099765563,100.0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark45(-402.14206612244215,-402.2269772780726,20.383962161768387 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark45(-402.1549404330159,-391.56889992351245,57.1927426662553 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark45(-402.2301389974318,-359.0935345786686,19.636020854937215 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark45(-402.38710504879236,-354.4228880804016,41.032252781661896 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark45(-402.55966929243084,-352.81727909719257,72.28532104500579 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark45(-402.7007493228013,-361.24706725122525,42.79297664065351 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark45(-402.8183620726926,-368.5742991385516,84.57077713640626 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark45(-402.8552128386553,-461.0101843377815,7.606181948034106 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark45(-402.940221111352,-343.79350061373094,60.081015324852956 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark45(-403.0009656316642,-440.17173987773856,100.0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark45(-403.2730018385274,-343.65910976608615,23.06731769232036 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark45(-403.2968468097944,-363.98009151216087,100.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark45(-403.3001174575845,-379.3928114935755,39.07760668788487 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark45(-403.41640356063647,-355.3481488053411,26.085546303883802 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark45(-403.5368305329703,-402.21034898659184,24.87429828788406 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark45(-403.83121398597734,-347.0836653071426,47.748842772471846 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark45(-403.8504950912273,-394.8368322948566,54.896125362240724 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark45(-404.1741061843605,-389.20980622565224,0.4113758851227942 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark45(-404.23833759480453,-342.5694004291997,28.004143147374606 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark45(-404.32194766437993,-360.36004597517007,97.53314890574748 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark45(-404.40686003480204,-408.97410594761413,21.966042003527207 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark45(-404.41127712034313,-372.3710151540507,54.56456352036702 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark45(-404.53913874598084,-377.26574306481075,8.585179450425045 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark45(-404.6317034111374,-358.36771716153464,68.7901553966937 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark45(-404.7681828066439,-350.0672008295353,33.80777136811497 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark45(-404.7854435911942,-378.28903958869887,49.409267250235104 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark45(-404.79773274037433,-354.42897742056505,47.760200840772136 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark45(-404.92356486291055,-341.6484518914686,100.0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark45(-404.9385632915922,-343.1092856619298,79.96961321900466 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark45(-404.97946861405643,-400.0469767445281,24.170393170984568 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark45(-405.03898063546205,-346.7119573679622,100.0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark45(-405.0450703485694,-381.56757026335947,32.683204830320676 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark45(-405.2286265946557,-378.0654518778327,72.72547059914413 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark45(-405.27949286980856,-352.7166314503813,3.6537790436244677 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark45(-405.46350115490844,-355.2937226281125,62.829306527300616 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark45(-405.61251540817125,-396.3671934147406,100.0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark45(-405.6590215454336,-354.4258426593392,30.046249057756285 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark45(-405.70575385862344,-380.30852819528513,74.33230715097082 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark45(-405.8242097515657,-422.63253838394274,34.92882705109227 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark45(-405.84762869096494,-403.65350333156465,70.00621666666686 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark45(-405.9219675646726,-340.50185574898626,89.21571933244172 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark45(-406.0009034061204,-349.26824026696295,4.226614728032985 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark45(-406.2238346239683,-348.59484221849874,4.479713027531744 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark45(-406.2675904245841,-358.6617760011729,75.4604431438105 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark45(-406.36821431399846,-340.4861984302009,82.55893482559793 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark45(-406.4970686879074,-357.40606830299197,91.33200946339684 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark45(-406.5545339997752,-345.56736741495905,26.35165624874635 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark45(-406.56291950808424,-358.2681030630891,100.0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark45(-406.59362552158456,-366.22629574642446,63.04782414694657 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark45(-407.01336372984804,-350.84050666130884,30.779291471430383 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark45(-407.03098901800615,-385.88171276795055,15.71350042757787 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark45(-407.0483488701387,-353.6591933513328,19.745990915277602 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark45(-407.0576778202802,-404.2063344785353,96.20311296052492 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark45(-407.18064623467046,-381.2577188528557,15.603576717731443 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark45(-407.2189699309608,-358.0773267643862,20.9486304391952 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark45(-407.37929428837657,-379.6624960671241,35.90584352143506 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark45(-407.41260365886205,-357.3399844517425,47.552269234503484 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark45(-407.457082274399,-377.3769938962785,31.085293134625346 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark45(-407.55530078154226,-350.3019995847676,73.95346862319695 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark45(-407.61215335304144,-431.57441049095235,100.0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark45(-407.61854435411425,-394.5455088229319,4.93810441176808 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark45(-407.62015875264353,-345.5905288017515,46.86551247134224 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark45(-407.667600723364,-349.1187806580955,39.349939091746506 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark45(-407.70517324950123,-351.85407568549084,2.2001008139965705 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark45(-407.70881531680845,-366.58249538562876,91.43875475037945 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark45(-407.79663939607764,-373.68356713809436,79.53726715078074 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark45(-407.81486210074166,-343.4634788829975,24.986535642361375 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark45(-408.1646028570354,-390.06650421501445,13.428656286951508 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark45(-408.2182831627197,-351.53535286460675,27.716427503261002 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark45(-408.31789266395305,-357.2829451301121,21.63664184011766 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark45(-408.35987016757343,-355.9880921809082,75.79464364489112 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark45(-408.4113210649632,-390.926486558649,53.97784133712244 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark45(-408.4469356645953,-343.14781371777514,66.04070999318691 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark45(-408.5340204392473,-337.87859709106283,21.23422461823168 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark45(-408.5520322761454,-342.90837148768344,65.23545673350606 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark45(-408.6832348798368,-378.14750248867097,9.899320383349036 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark45(-408.70259901101605,-342.78553715992706,85.72944161964028 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark45(-408.90121342790826,-339.8726987010065,91.70806234192906 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark45(-408.98068674734435,-341.32050719249804,86.93964292954496 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark45(-409.08518304819336,-353.48712032464294,35.807783293047976 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark45(-409.172847119993,-347.4983041964592,39.66441583764663 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark45(-409.5578893621138,-359.875090444886,29.704966158659175 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark45(-410.043811509425,-337.967187568271,100.0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark45(-410.2594660297236,-387.59081793953203,78.25225832812998 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark45(-410.2865634022568,-390.56764668778777,76.4435355927972 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark45(-410.4386675956222,-389.3178402512504,63.29692608411409 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark45(-410.46074791021726,-370.62602004464753,49.07566232667634 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark45(-410.86140976134766,-340.09461603407334,59.42228273324105 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark45(-410.9634123656005,-404.3644666126578,3.5089866744701226 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark45(-411.34860290239635,-352.30856068773744,28.873180057548154 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark45(-411.45933521832586,-414.2345807916187,74.5740631173843 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark45(-411.47518048622385,-378.5531201561236,38.006578930284206 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark45(-411.5009721755751,-347.030548907062,69.97343146211858 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark45(-411.54191423203054,-340.0088425287142,21.63895203524693 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark45(-411.5829839286201,-376.5180655380811,39.671877679989166 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark45(-411.60751115965115,-396.9314819423798,52.26986059329541 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark45(-411.6930593199485,-340.2440373973154,75.73566810263094 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark45(-411.7980803794232,-337.5155693757995,74.51399927854686 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark45(-412.02313616076174,-338.66260180010636,44.08561944817245 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark45(-412.0853953334086,-376.23991366804614,17.484014014312436 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark45(-412.121581862352,-346.5024205346161,11.47351305356463 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark45(-412.1789263853883,-337.33724873694206,22.408969511009147 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark45(-412.28874288911277,-371.2358257489433,97.16307576394482 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark45(-412.4113818612857,-345.7855770378884,64.8511609649108 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark45(-412.6753716721107,-366.93489508947147,39.40471355024147 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark45(-412.74272627494673,-342.10329898723427,5.557046163952691 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark45(-412.80745705942303,-371.35414237863125,11.93498969130566 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark45(-412.92270684311194,-391.870683505947,59.54341163662755 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark45(-413.32769876752235,-364.3815074987781,18.854276325699487 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark45(-413.34586838651495,-367.768074288429,94.18812271846576 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark45(-413.4194861151518,-352.0024828880367,12.679629638153656 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark45(-413.4929348424418,-343.0858287389031,70.70280440691349 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark45(-413.6046131413458,-373.78274026607954,1.1285582863965686 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark45(-413.7106372140149,-349.07289039202794,77.48598258600245 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark45(-413.7550150221838,-333.3338957059963,41.427346861984745 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark45(-413.79689367895037,-332.9690385551694,38.613522624414045 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark45(-413.8370003515047,-333.3558947934527,0.8888148343340703 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark45(-413.9790967399539,-343.61191607746304,100.0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark45(-414.04128060631837,-334.63176605029656,100.0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark45(-414.19935697180244,-366.8264625083974,68.10345660261083 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark45(-414.2352990163037,-345.7562974199097,38.16649979735155 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark45(-414.3665562163349,-337.0220175465364,33.372620541377074 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark45(-414.58370489653066,-340.4361275627665,100.0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark45(-414.6394524647227,-347.0105221612877,12.906021036070172 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark45(-414.6764388675196,-342.8859382043691,68.3610410317815 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark45(-414.82329023767727,-411.874712697578,88.2718123047506 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark45(-415.00724320756666,-352.16942299693255,28.379626132986914 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark45(-415.17292088918623,-337.10622299186355,4.657505959664903 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark45(-415.1809493621708,-334.37518174272293,16.54292792356506 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark45(-415.19657633144675,-388.1222894442683,43.317996360527616 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark45(-415.2211757211212,-361.9196002784384,100.0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark45(-415.3358304242609,-334.825254556234,91.12926180470404 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark45(-415.33900703488,-345.1853317145244,30.176577501661438 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark45(-415.3494698300446,-367.0669806298438,64.4189068115094 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark45(-415.3510919833504,-341.43760458783356,15.528526228552053 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark45(-415.3794043948256,-337.3871615603649,7.629622861864192 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark45(-415.6804620516754,-372.78214430090907,7.534431652331648 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark45(-415.6833980809196,-354.31014498604276,9.155837459469993 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark45(-415.98666074009475,-362.51857352131265,81.01165545947177 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark45(-416.017561550552,-378.2522479043556,100.0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark45(-416.06539027710033,-346.92994321142874,73.9329143848262 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark45(-416.4239881234062,-425.4447290837024,-1.6055521693431352E-8 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark45(-416.54541953370756,-393.38643683601384,100.0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark45(-416.703366284142,-339.93009259649835,63.13396363592702 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark45(-416.7749678912737,-387.3342048806664,28.17859900080137 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark45(-416.9089727149682,-329.70683524264365,68.66113443509926 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark45(-416.96487560819236,-359.79404770587576,95.21892547343504 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark45(-417.0136294149443,-363.7901568928634,60.46658257528651 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark45(-417.0241433639178,-360.281284558848,83.59958166532641 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark45(-417.21484387882805,-338.005241157123,26.496959788812575 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark45(-417.2342588222405,-331.7218301806999,15.208870578449734 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark45(-417.5410445320557,-374.2749583666078,100.0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark45(-417.6528578300421,-347.86487259685384,14.215161213030711 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark45(-417.67869549017695,-330.2262235910449,5.902332069147704 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark45(-417.942313624334,-371.4535555454932,27.074855813379074 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark45(-418.06870575797984,-344.82089579894443,74.19171602674001 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark45(-418.1055341162269,-399.6775741383102,90.80736647125269 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark45(-418.272503107766,-349.762344992653,100.0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark45(-418.3337941626505,-329.74468010705215,40.91381465984017 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark45(-418.3424357015455,-338.9712131951821,67.34681147297835 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark45(-418.39216645419344,-371.87382612975307,85.76508541449257 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark45(-418.52871111084676,-415.27552092751966,35.99307163159796 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark45(-418.81810553567846,-357.99566207399675,32.36753715744828 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark45(-419.04604113389985,-338.2652058037292,46.65208717579105 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark45(-419.04707594733094,-363.39545379360266,40.154544905919835 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark45(-419.06120436770254,-352.31019430591084,100.0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark45(-419.2507670305524,-346.59403650001633,51.563419448382575 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark45(-419.3612833545233,-354.44963735875285,41.617147953664414 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark45(-419.70395092115774,-353.2572927019641,0.31543380786031605 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark45(-420.0230937462834,-340.18975643078045,67.8302882888843 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark45(-420.10187586472796,-357.5265404962003,21.977426624715307 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark45(-420.30236184433744,-332.02247770271657,19.627421432371932 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark45(-420.3091207124277,-338.5775438609738,52.78211505935994 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark45(-420.31029399347904,-362.9739614851392,94.23420329908424 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark45(-420.39750159175105,-332.32794192578956,97.52950113419712 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark45(-420.5734967641255,-325.53400413231816,28.98835607081668 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark45(-420.6230130118001,-338.330747722881,63.38853003805748 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark45(-420.6926803186206,-393.8319805349308,82.09727248623841 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark45(-420.73766964974766,-407.9805507322902,28.90552826796454 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark45(-420.7517102079159,-336.21307996298236,68.4342496065983 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark45(-420.92055598061506,-388.1843221664497,37.15997511428702 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark45(-420.92833011245676,-336.53786953837215,60.895025694217935 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark45(-420.95827297812224,-325.213412072761,58.45616809874571 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark45(-421.07005772942773,-344.45644994783464,31.672109708638203 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark45(-421.1131032853318,-335.5120556511283,41.21092112924103 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark45(-421.2805263092681,-337.41590175602505,68.78858859933808 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark45(-421.46537903665745,-345.9251432489386,100.0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark45(-421.5799160000486,-350.3382477663529,74.41490284042183 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark45(-421.6130824332135,-411.91739098221797,22.3918345535306 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark45(-421.62806470463926,-338.78112102129484,95.34710597337858 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark45(-421.7192445488454,-332.45659941141804,66.314537327511 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark45(-421.8464601153787,-332.9163985748902,42.6381096195004 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark45(-421.9218682523465,-357.97936843755787,100.0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark45(-421.9580936107248,-378.00425627957304,46.03041905086682 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark45(-422.0079356237454,-363.69906398340777,26.320408482444165 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark45(-422.0155633383568,-337.48163431820547,100.0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark45(-422.030431628084,-383.74948073358985,100.0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark45(-422.0380260166356,-330.07806759859307,65.53170295791432 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark45(-422.07268252941896,-339.17860873391305,51.75434207271957 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark45(-422.11158684728804,-355.92341404629775,61.61376873132437 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark45(-422.1348805246481,-335.7981359289362,36.52382812989103 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark45(-422.21788962491723,-327.95484690556464,73.61407234398197 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark45(-422.22762711077223,-329.6176122031704,39.231779217511644 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark45(-422.5084403787838,-363.66170660628774,77.0213054659257 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark45(-422.6076653379724,-349.32611212210793,70.24037584400321 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark45(-422.6619736961785,-342.99102480956157,89.8321546797169 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark45(-422.67066914116873,-344.51392309832283,77.02584030740297 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark45(-422.7683062579296,-326.76336688725087,0.6047546763212637 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark45(-422.83236241734966,-351.2712867544231,15.640331339756216 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark45(-422.94251915749413,-327.23457644065985,19.528989146484733 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark45(-423.048219767317,-323.7347264910839,21.845793894881837 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark45(-423.07081576068697,-403.52792821515004,15.285139342710181 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark45(-423.17987372839536,-383.6125788586427,87.1721290207272 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark45(-423.3212348673475,-365.49208468226357,100.0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark45(-423.3243649098794,-329.39539239418633,7.764333845494775 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark45(-423.33862112424436,-361.0499470119061,40.65906718610256 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark45(-423.37284267921956,-326.1385862411706,89.72275580566907 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark45(-423.42517880504795,-322.7687592663961,40.19715031132188 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark45(-423.49544060283074,-323.4769771318699,90.28227823524853 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark45(-423.5212389213935,-403.91651596146016,78.11449409334196 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark45(-423.57622422256753,-331.9568831048298,100.0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark45(-423.5863640206425,-330.954904353536,42.468486126906726 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark45(-423.70502502872785,-332.82846212096086,55.06464372322145 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark45(-423.79826064351744,-378.52923878891664,62.513581685715735 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark45(-423.7991173319283,-325.02447062151106,65.0295146532419 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark45(-423.89687362354977,-348.8231804724447,1.426520013507698 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark45(-423.9221367140727,-341.99122377394485,36.44525423761206 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark45(-42.39726725585177,-727.6816728725463,71.30052634349525 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark45(-423.99317994353726,-359.4803012899273,98.99110802382418 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark45(-424.1782144858776,-380.46800308401635,19.284193722128464 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark45(-424.201705967851,-387.2393210456552,85.70589615035661 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark45(-424.2043768379173,-323.01616412819186,74.6026839319675 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark45(-424.30144946969256,-369.507220308004,60.64712456776641 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark45(-424.4834081163521,-375.8036446703169,100.0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark45(-424.53770797757426,-334.5934795074544,76.36154301560113 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark45(-424.5733624394623,-376.1469266633153,36.41788752718017 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark45(-424.5763475062499,-394.95544260381627,0.8887892330820364 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark45(-424.69810782742735,-344.63247152293275,64.01668187537246 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark45(-424.82069711772465,-402.25709186572516,98.95432671331262 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark45(-425.08325549566877,-325.81523885462775,83.92721790811783 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark45(-425.0987614673056,-330.4296106725379,72.06438629036401 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark45(-425.31527444317356,-330.97293601020647,66.40517509528232 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark45(-425.35001407149775,-356.536729837766,8.875519700649079 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark45(-425.3537014113237,-414.77651194085365,20.462394516323066 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark45(-425.58012874015714,-356.9555695811596,100.0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark45(-425.601538934032,-336.527055740643,12.634570342969127 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark45(-425.8093095021673,-323.75556018484247,20.376096522094628 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark45(-425.871725001163,-357.5000432720348,41.388683865004225 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark45(-426.0017513552102,-386.8050899468541,7.012348613202392E-4 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark45(-426.00254609354323,-336.88191483027254,100.0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark45(-426.05006357878835,-360.01493203462695,33.23029771480728 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark45(-426.0798204899102,-335.3818548658295,100.0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark45(-426.13291259454036,-336.9725472216298,67.29893293911312 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark45(-426.47472101484044,-326.04660942305503,100.0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark45(-426.6741783363087,-322.2213324835807,100.0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark45(-426.7372886267165,-347.7895729649264,22.114318571913998 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark45(-426.7614987477342,-369.4538713957271,73.02706720801626 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark45(-426.8307962027742,-351.81209514372404,74.5771151165655 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark45(-426.91447091177014,-368.7487830243947,20.43024055539817 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark45(-426.95853316555406,-323.9062563962755,99.60261657782922 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark45(-427.0788815783818,-329.68366705944857,100.0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark45(-427.1805555983285,-371.351018536387,21.565481815795323 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark45(-427.330852368733,-320.0141956314171,100.0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark45(-427.37372271509327,-327.6835810777321,100.0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark45(-427.49841488917417,-336.7292526464648,57.41346593647421 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark45(-427.5452495828779,-319.3843854882742,75.04794138363195 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark45(-427.57151710667256,-386.6389560511166,86.41440481745158 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark45(-427.6263951864577,-331.73615495891255,69.27962312087453 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark45(-427.708647083609,-330.62655470992183,34.21302274543066 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark45(-427.9164793891201,-480.6572698429275,78.40670732354141 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark45(-427.94508384407584,-359.3767067100896,67.27507629990609 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark45(-427.98340867991243,-367.1223454640753,4.7061620251242005 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark45(-428.0112403255417,-362.0850224911789,80.48184631820138 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark45(-428.02221159920117,-387.7491585658454,11.416576279376997 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark45(-428.2546684171348,-370.04376464090484,46.13090665904477 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark45(-428.27581066521236,-317.7394861043591,72.2620145683083 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark45(-428.2826589358395,-356.88885228108796,82.09406635801767 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark45(-428.2920951157941,-324.1829499305535,38.51275926989376 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark45(-428.31986982601677,-360.8686080981602,54.58846786869188 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark45(-428.38313182364993,-348.5560583166443,88.94867693098644 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark45(-428.4916818204755,-344.59703624839494,15.578936619167138 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark45(-428.7158856460527,-334.742767416685,75.52480205967501 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark45(-428.8112106629662,-338.0079110581007,62.41422174450159 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark45(-428.87987337572594,-373.7055608123809,43.49885720517571 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark45(-428.93014853926974,-322.5124716514779,57.537628526022445 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark45(-429.00138796537084,-330.35539224227495,64.77645609236023 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark45(-429.039774334646,-382.3445943648986,100.0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark45(-429.1508751517103,-395.645717061976,92.28689626978175 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark45(-429.16844203438984,-321.21853075972734,57.90058078725173 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark45(-429.1836191104824,-363.2402102765281,14.753463998394054 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark45(-429.2307571008995,-318.7032935608021,63.84215550871426 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark45(-429.2561666818475,-332.5590720438481,25.747250803008683 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark45(-429.47409905808536,-329.6148830548873,5.228304922948368 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark45(-429.47959017597685,-362.6033167287371,55.251733997891165 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark45(-429.4961713709028,-342.8398731532857,21.91246592751817 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark45(-429.5258831446852,-335.64525037697206,61.79624308236362 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark45(-429.63091710322607,-329.4117528248082,77.68451712906479 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark45(-429.63607827371726,-319.87530965856075,56.492371925972975 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark45(-429.82516747946715,-353.63023266381344,53.5199822800987 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark45(-430.0254380154372,-328.1177816935177,37.67508075980098 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark45(-430.0756661095807,-320.71136146685205,0.6497685649384977 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark45(-430.0982870728884,-355.1388293523926,84.74094026923643 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark45(-430.11514999670214,-347.8991355606415,100.0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark45(-430.2173910964126,-365.29794757630435,68.89291879488181 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark45(-430.35152439904414,-326.22687769829986,54.25030819837352 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark45(-430.3903833754916,-366.1001680212571,85.64549900027939 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark45(-430.784686016547,-380.7387490867857,92.08520354004723 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark45(-430.79887637891443,-377.9299406992156,54.67828820503513 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark45(-430.8351188094848,-422.8285787569853,80.8199243443355 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark45(-430.89399774558564,-320.7001868663978,13.32454250047492 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark45(-430.97109259967164,-320.3551720857665,76.59033852895692 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark45(-431.19458228730997,-329.9993386589646,80.14134296157945 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark45(-431.5048458556379,-339.9152122412447,98.13661747617756 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark45(-431.53306789689583,-319.83521818002316,32.18128329260145 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark45(-431.6187456092397,-340.88278810023877,100.0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark45(-431.6434268337936,-368.7379721428833,27.19696137502072 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark45(-431.697268198451,-393.36012967431736,31.469250774393913 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark45(-431.9106064691176,-321.6508370470842,42.75372037684485 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark45(-432.1436005831345,-330.36260270668134,64.715247551168 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark45(-432.17025712288756,-367.27103108214783,87.34221870327355 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark45(-432.194349460579,-348.4089428800889,98.16311606902158 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark45(-432.2095649381263,-336.8400994597831,4.112056469462175 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark45(-432.26379019529037,-319.14624362213846,41.20218979044748 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark45(-432.3760274127435,-327.8429224049731,2.006074147105295 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark45(-432.3897273423278,-437.25238414540314,84.83452271396959 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark45(-432.7502540295584,-378.6537333856357,42.872802294213756 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark45(-433.07329974262467,-354.11901636056353,12.024956792026614 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark45(-433.0814001727306,-324.5625821136855,54.21178024838707 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark45(-433.1190071313505,-345.1055004920656,18.2249633431625 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark45(-433.14061532871983,-325.2574074610923,100.0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark45(-433.3461377804299,-346.4988410063971,90.75682319568222 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark45(-433.3768590334548,-339.2025562798481,70.16374054535493 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark45(-433.4058228311423,-345.6851114283625,14.983009352669228 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark45(-433.45103692142396,-371.03180348688863,89.53039951738806 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark45(-433.63198334691566,-331.15153489315765,35.34635996566038 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark45(-433.70716216379185,-325.7343284819077,32.28094978174309 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark45(-433.80772996918256,-322.0525750491925,1.057886434316572 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark45(-433.85057118546104,-338.93067605865383,100.0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark45(-433.90498744711704,-314.8447264412854,0.6276404647857419 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark45(-434.02191086691045,-320.0097076701883,65.92554632861265 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark45(-434.13460601028106,-315.7864490983586,48.75951028111669 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark45(-434.16084814415586,-421.30081651498875,37.9682994869395 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark45(-434.1865668689877,-383.9180452879797,84.27865559934082 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark45(-434.30030517498335,-346.3386501798108,23.856116308553794 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark45(-434.3142079581917,-339.21642502317064,65.08038186977805 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark45(-434.334944443219,-325.05634319439946,42.836690154959115 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark45(-434.3353447908602,-324.78476089598723,42.43983501575488 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark45(-434.45070067998705,-365.98645263361686,79.72061336099748 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark45(-434.56736686923557,-326.8958517897875,73.04494154758729 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark45(-434.63028781434383,-333.98135631908633,100.0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark45(-434.78323528211604,-336.8302991642266,32.78407328612582 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark45(-434.8017919226978,-311.85797868511145,59.20301790579563 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark45(-435.02443794535964,-374.9986411554624,100.0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark45(-435.1577770935596,-328.6016315628696,77.34308484151512 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark45(-435.2451046931228,-312.5190157178559,34.33686189943336 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark45(-435.30279383920777,-320.06856099461504,100.0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark45(-435.3489943965396,-346.4978998102398,96.49617603417175 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark45(-435.35837416592756,-369.44393330861425,91.5726850065407 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark45(-435.4041601436124,-320.9607270490279,74.2017036032928 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark45(-435.4515612910252,-317.67340193971256,95.4393528223163 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark45(-435.5422777007569,-340.8964080330028,79.0087944724309 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark45(-435.5530381100523,-397.84454967899586,7.5706001165529955 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark45(-435.56810826622643,-321.938483693169,100.0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark45(-435.6391385403835,-317.4625956008293,38.188624629388016 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark45(-435.75406630654527,-324.10709358354825,10.817870180779465 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark45(-435.89058518333445,-326.99298001549306,6.690482467464591 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark45(-435.95291289801366,-338.938483132316,1.0507263998592151 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark45(-435.95792756583256,-315.25529942868343,66.4500344299816 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark45(-435.9758782985257,-323.2023716522337,38.44137796271855 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark45(-436.13305296107694,-340.3654757705665,13.818724259980247 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark45(-436.2498454092652,-339.80065431654685,88.37634005403271 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark45(-436.3850035684378,-390.81984904798674,32.17294693309342 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark45(-436.4789627331518,-310.00844391459816,4.215141592662988 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark45(-436.4827253279874,-341.0996917201953,53.94928351996745 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark45(-436.55398260671257,-385.8994101774784,17.68668547743313 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark45(-436.55954373453847,-399.0988838140796,99.40435674065674 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark45(-436.59495530128567,-358.3125221822207,100.0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark45(-436.60587999413724,-310.239331981797,49.95090946322051 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark45(-436.60919665298303,-351.8545805827662,0.3912483303140135 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark45(-436.62166777504376,-322.90992133107875,24.67978839630767 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark45(-436.6967472690457,-312.68712400643096,70.60146042215501 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark45(-436.8331793630857,-393.0100179805564,92.62155770621092 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark45(-436.83635649637773,-327.65197083008707,19.87592777486485 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark45(-436.83646481718625,-318.20473989708114,100.0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark45(-436.8524288345541,-316.6038015253015,86.0418380234359 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark45(-436.8625227268095,-313.3857114818959,94.38373739492675 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark45(-436.9944887506828,-338.8124089580426,35.78437100427766 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark45(-437.0025896053518,-314.53541787377605,88.05077330755196 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark45(-437.0028390733115,-325.74941172640035,54.80181330796151 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark45(-437.06020929743255,-315.212846947457,66.02099821197629 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark45(-437.2448932347925,-323.60474605302835,39.05757293925208 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark45(-437.35933331175147,-324.1586727249976,12.769943028512255 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark45(-437.4785981890149,-316.1789768255727,60.55002707166784 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark45(-437.5372537365641,-344.7295950239119,81.3212026512364 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark45(-437.63145822718576,-382.6527414907876,26.066668816460805 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark45(-437.650535979211,-334.8763460673629,92.70209892746351 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark45(-437.74684803858446,-326.80633592521826,100.0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark45(-437.74752090827565,-378.88645097560817,37.649707386488814 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark45(-437.8740112857228,-309.5060054175696,12.898322466830066 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark45(-437.91131613222876,-338.3679843832844,41.440334531317205 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark45(-437.9892885329273,-384.43145310678085,89.7633351349632 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark45(-438.07146502012216,-315.1583679633188,100.0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark45(-438.0928943646846,-343.08103209910854,61.70522223500481 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark45(-438.11165272574704,-331.72115279841694,60.82925456422248 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark45(-438.22916934770365,-312.553026772291,100.0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark45(-438.52522051810183,-323.82673831325263,100.0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark45(-438.6228097228748,-323.76096647556164,4.992170775624032 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark45(-439.3220951700946,-312.26197744657725,57.70997017113007 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark45(-439.4602086900557,-316.45285070873905,79.42052052882536 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark45(-439.65813082676686,-318.9976279329066,19.780711322218906 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark45(-439.66507509332644,-318.03611136417726,1.006145135868877 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark45(-439.90263184197113,-348.418869893021,15.473447657773349 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark45(-439.93848004883546,-339.5881037913423,37.217610691850666 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark45(-439.969354663781,-317.4882130016623,100.0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark45(-440.09056439302776,-317.48351309901517,100.0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark45(-440.09271768710533,-314.4775753358613,90.64361488034262 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark45(-440.1213104967458,-389.7039414907253,100.0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark45(-440.6142165543173,-320.53457542377174,100.0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark45(-440.74497276234024,-315.45039328736345,22.760298193983004 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark45(-440.7694981460218,-370.0791395616721,31.666999721218303 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark45(-440.77895880523727,-366.72906462694385,99.77045765382695 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark45(-440.7887311478554,-325.37892253949735,72.36329396755522 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark45(-440.8493350907663,-306.5114145531943,49.294300831190895 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark45(-440.8864632177497,-366.554310910996,63.28953686791269 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark45(-441.00403130233,-335.26070639638033,61.753004695714935 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark45(-441.11955592200553,-363.99462944673496,40.13055512039517 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark45(-441.304023126198,-305.6163602935862,93.02127682832264 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark45(-441.4019826721403,-346.1775895022727,37.060568406766606 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark45(-441.5003954374475,-338.173697247666,100.0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark45(-441.5890058601834,-340.3409770407886,52.42493571998551 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark45(-441.690487166749,-352.0612265007111,86.49913829428638 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark45(-441.70350673333485,-310.9117563829084,92.29693096282082 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark45(-441.8328510900205,-324.13722880809087,2.4122052816351243 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark45(-441.9462047698525,-334.8032415762053,74.0234290974401 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark45(-442.03270407564304,-334.8875531352269,3.0646376353364246 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark45(-442.03541954331587,-382.8328109232761,66.18379007376288 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark45(-442.03918809775496,-414.32952689762516,20.942221522610254 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark45(-442.1288770621025,-312.86231885511154,77.24963213681951 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark45(-442.1575476137868,-323.4751825065885,76.71722802335097 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark45(-442.17277979163583,-362.22988929246196,12.055515804532362 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark45(-442.251445537653,-322.43683818974665,26.125242001274216 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark45(-442.3251793514934,-339.7805501767703,42.37068458082308 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark45(-442.36805812390946,-320.4386444259308,86.77737832480511 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark45(-442.5258935691584,-349.898610858939,10.120299035191167 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark45(-442.63595615889824,-304.02713330952895,70.43803045249354 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark45(-442.7933061624338,-348.21313328261255,57.86351889913507 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark45(-443.0588110255719,-318.469149537913,72.97093406802423 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark45(-443.27529193891746,-311.30075086809643,10.35114881439705 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark45(-443.3921126204213,-324.816563684531,84.70576331244251 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark45(-443.6977036134063,-329.6253077105938,1.91518915409614 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark45(-443.80743692722774,-307.2945091281637,99.98175280431064 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark45(-443.8573005201097,-305.69264973147614,100.0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark45(-443.86404938501835,-368.2063695490788,100.0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark45(-443.8676171076962,-303.5458700497941,16.469821182080967 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark45(-443.888317186835,-381.8272586590632,66.71570000094002 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark45(-443.99237596532583,-304.6705259939059,71.56935738160263 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark45(-444.0675780482681,-308.63875909021414,4.451249176490222 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark45(-444.07803721412614,-308.9676220493403,45.609627671547685 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark45(-444.1053075536259,-321.23620451498886,22.26040946654038 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark45(-444.2019093992742,-382.84880263349737,0.21071575027528766 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark45(-444.24128208370666,-318.5557006141559,41.70143985533531 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark45(-444.287065888068,-319.84733265336774,53.6875761227129 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark45(-444.3271472123266,-347.8881734534198,93.16691392757645 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark45(-444.36478473490564,-338.2346280401189,12.839546478629686 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark45(-444.43556320766095,-311.2692116161862,18.135007787567673 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark45(-444.50120934023687,-332.38961332365113,35.798919107420716 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark45(-444.5149080399829,-356.185694240001,1.8696346838759492 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark45(-444.59462003542893,-311.7607678033731,100.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark45(-444.67762376403533,-304.5661049777329,100.0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark45(-444.96803629931304,-301.3459949557158,100.0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark45(-445.0769113642692,-355.3688008961524,54.14904050793007 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark45(-445.1517857147267,-303.89156519345573,69.2364171464499 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark45(-445.29126666076866,-347.22977980669873,27.375595312789855 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark45(-445.34815472075843,-302.43483806991526,17.318485336454486 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark45(-445.48973703766524,-319.00444181916674,5.557956932609102 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark45(-445.5014489859925,-329.84347262044975,90.241124174839 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark45(-445.5573783031014,-372.1055989058514,91.45235518472074 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark45(-445.56473423873126,-352.13716678918547,45.59318364757553 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark45(-445.5701838986518,-326.48146765588535,41.87242640807068 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark45(-445.782159423423,-329.00283467788677,24.505023795499525 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark45(-445.85300766654024,-319.6457649758784,100.0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark45(-445.88739465690423,-368.8663823331134,87.91812267316419 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark45(-445.9284874367541,-354.10219175662473,73.70891478633291 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark45(-446.2155556183188,-356.7790632067131,5.887972966172455 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark45(-446.3369468720168,-320.17084432954704,100.0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark45(-446.4552180354787,-345.0989153199448,73.98466205924746 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark45(-446.5676503416497,-346.1844545096218,65.62220956760314 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark45(-446.58529835428305,-343.9481563035001,71.69920209977357 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark45(-446.6022430659906,-371.3385788979188,66.56680653305298 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark45(-446.65990262845304,-426.8640340090986,57.384464650624665 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark45(-446.80435085612305,-338.9619771024296,29.45229286880584 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark45(-446.805224966698,-332.13091840107984,82.90394558150354 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark45(-446.9648628908694,-328.4882002288924,10.354584635137726 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark45(-446.9714278115209,-316.67745094235477,30.072996233333015 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark45(-446.97693897850496,-337.9495088330088,54.17586454713933 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark45(-447.01604575976313,-365.49272152972895,75.1050313739521 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark45(-447.0313847518993,-415.43714234995673,24.585729466996526 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark45(-447.07642537016886,-314.3082885738884,49.66574654077297 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark45(-447.2553669847497,-306.7402492723627,98.10847018274978 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark45(-447.2736848643577,-307.25077112045085,100.0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark45(-447.3672237465254,-300.0076169471424,3.792774934133675 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark45(-447.3937242290919,-382.46840670800975,27.359979876569014 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark45(-447.5000971233059,-343.34817040821997,26.2893436151884 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark45(-447.529476487914,-333.153360231733,73.18032195978267 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark45(-447.6374530832587,-318.36403422439605,44.29205468464977 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark45(-447.6402354763337,-338.24520750055325,3.3328849347322773 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark45(-447.7410809253414,-355.6074344533639,61.76141848957357 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark45(-447.852969351739,-299.12609284510984,38.66776491199971 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark45(-448.09381856540574,-312.7148720313285,34.14622827802185 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark45(-448.1076598936278,-344.3834126711784,18.300680378665078 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark45(-448.25206277462536,-303.900834051284,13.194685812591729 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark45(-448.43110631232133,-371.5764267175185,64.79335003240686 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark45(-448.4570981408963,-351.21970475452093,65.98585639953626 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark45(-448.5358155167698,-327.39452595500643,100.0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark45(-448.61844451034614,-322.40967837756295,91.16883621966957 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark45(-448.78463892067094,-346.87538054670637,100.0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark45(-448.78895058109754,-316.64591412412125,84.17154967914527 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark45(-448.8648716222484,-304.59384560041013,63.466874494648664 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark45(-448.9146061235,-342.77075420598504,70.08036409816222 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark45(-448.916613233979,-299.6656768801586,100.0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark45(-449.3312840433585,-298.52296821078767,88.54431484814438 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark45(-449.3413613787005,-313.28110352028403,3.4602656580429567 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark45(-449.46408503451465,-355.63113998737543,13.061563372233053 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark45(-449.6222556419896,-361.7366655128539,26.48581236059151 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark45(-449.64379803628316,-379.3287115267736,16.109493241381756 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark45(-449.6511601933853,-359.19611274019616,57.54563619756553 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark45(-449.6974184612705,-335.36645126582016,60.18494943329554 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark45(-449.98121458959224,-326.0768419061095,39.462983053200304 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark45(-450.03849709070334,-317.986612964547,60.69810420997218 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark45(-450.22659999957193,-333.7471242954107,100.0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark45(-450.2706180951184,-348.5604205424251,27.393656534059673 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark45(-450.5342276673001,-328.24162024950755,34.588424810910226 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark45(-450.8328494528612,-339.81654940478126,100.0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark45(-450.8934867468501,-298.04964983885793,54.89979376364141 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark45(-450.8972801137547,-314.1512303277877,21.68119199808804 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark45(-450.89848412191964,-312.9720692808355,54.90435186843638 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark45(-450.90314612555983,-325.6829823204474,92.91004072443059 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark45(-451.4841681546382,-340.189009755129,81.46559272871932 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark45(-451.9406746119449,-303.33721000523235,28.97093581988048 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark45(-451.9672028089209,-296.3880855982525,14.384508127229992 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark45(-452.05029240075294,-295.8076451630387,98.66410592303586 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark45(-452.1033488455453,-346.71967790475037,73.28288815562573 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark45(-452.11235768947085,-310.1339239373983,8.066936141640468 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark45(-452.1140511530091,-320.03598297578935,49.21031050266242 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark45(-452.12504396762546,-321.01505735631105,88.82009941528517 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark45(-452.22099988627195,-306.4456724042299,76.05505930226954 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark45(-452.3889299956887,-349.64257679406126,17.649896578789797 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark45(-452.5218371864129,-331.1148122636167,27.453440280774657 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark45(-452.5407676184551,-319.1923733012051,43.232886727270625 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark45(-452.57981258779955,-335.38759966027305,32.80744064547349 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark45(-452.9199851318935,-329.3214514853987,22.927285417048935 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark45(-453.10386356243146,-343.3116955140553,100.0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark45(-453.1878155639059,-307.3444740485653,91.08193498317536 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark45(-453.3134585567214,-313.18359906252886,59.3163283725556 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark45(-453.4770400410107,-320.0594660961697,88.70087010825267 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark45(-453.66020205478543,-305.2891705337269,100.0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark45(-453.90171506221975,-330.48769244751935,5.213475848317614 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark45(-454.0137103248888,-313.5221601232952,67.22978813726382 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark45(-454.1372941184025,-335.03045790099486,100.0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark45(-454.177405047142,-319.50012017824025,79.22268538759951 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark45(-454.1890014467135,-330.5839633778851,40.7992030878801 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark45(-454.3497544279949,-353.7364750426097,100.0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark45(-454.3620111669787,-322.9246756068322,34.55524596970966 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark45(-454.38544193142246,-372.6205882035416,37.43670239754019 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark45(-454.47010481469215,-328.9938283992941,37.8613741678418 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark45(-454.6128093579224,-300.77744982092224,56.57157523687323 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark45(-454.7654450891078,-293.20958343705394,73.51932652497533 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark45(-455.00682562140787,-434.8845499959191,0.918543438313975 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark45(-455.02616598365546,-300.56662030247185,100.0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark45(-455.0813338506806,-323.244077882438,33.41268730494909 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark45(-455.19067947961094,-295.0440564157086,18.212335313955947 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark45(-455.3765592823798,-346.2442794227441,11.85309232689906 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark45(-455.5573962714549,-346.5555873314512,85.7800250139218 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark45(-455.6320448487167,-346.45222860463645,52.32295839570534 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark45(-455.65276437966196,-292.1601642127556,83.75017304153977 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark45(-455.6886020556141,-365.3223980307397,99.30782243140183 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark45(-455.823812368491,-292.79177596972704,54.58969433270099 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark45(-456.0374346906685,-301.4862831175623,43.02712996217616 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark45(-456.0460991987566,-373.8876959269154,51.105749735449734 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark45(-456.13214692747425,-331.6424226726376,90.12367121457726 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark45(-456.15493969771404,-316.53769599540306,42.74895906645435 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark45(-456.2120165054403,-295.451422366228,100.0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark45(-456.32003491081707,-302.50949683127254,88.2026089515791 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark45(-456.48689717778285,-315.09212235453697,70.15689731622189 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark45(-456.92776601305854,-326.029012910085,74.70619198433579 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark45(-457.0523000791399,-344.1908789298887,17.903667031554676 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark45(-457.2521247973587,-314.5769807095029,69.3302992190788 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark45(-457.25455978393853,-295.8392962854775,99.13777678270009 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark45(-457.32796578210355,-359.3455592310228,97.23890890488912 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark45(-457.37266925596276,-290.03467242970737,10.531205362277959 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark45(-457.45760370645183,-307.4246378133005,44.09096216119835 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark45(-457.6278294177106,-296.79451646657867,80.10556402509718 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark45(-457.691620608812,-323.13552178291155,85.40047982693716 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark45(-457.7561047465321,-300.8564884500268,43.62042893192293 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark45(-457.87989460697247,-310.46008757239207,42.17301034701947 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark45(-457.93592624537337,-341.68323716395037,100.0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark45(-458.1727820593277,-294.8087666664599,25.435874610031718 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark45(-458.30770443345295,-316.80843905448575,86.0306208716172 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark45(-458.40121742124546,-324.9742624597228,46.365137927122504 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark45(-458.4445637203274,-292.6970925690361,100.0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark45(-458.48037392973384,-301.1214629802635,58.45503102537626 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark45(-458.79911053652063,-426.834937672458,34.520686718013025 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark45(-458.8835664524348,-293.4845581318958,98.79159320992832 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark45(-458.92209185602275,-337.0587719570089,100.0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark45(-459.0764752879201,-292.33907047265353,9.560049485184294 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark45(-459.1290311911311,-298.49817829394004,97.8976412457414 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark45(-459.2689892225507,-292.47299505401486,100.0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark45(-459.2895614019197,-320.04401455364695,49.85645046996274 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark45(-459.3767817485509,-310.95080210929996,20.33934710614831 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark45(-459.4305965618625,-350.1945171610082,68.61604936314393 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark45(-459.5131223946663,-322.3874498316415,18.640980751366413 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark45(-459.52719414854306,-354.2475500411116,49.01992021680982 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark45(-459.54292092990374,-313.26174016963233,1.6837291873354587 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark45(-459.6099674329851,-309.7833583825722,35.39548521612184 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark45(-459.9830097745449,-309.5485509997685,22.328025393719713 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark45(-460.1074073140244,-288.8911914934676,0.32444390131848877 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark45(-460.1312510800431,-338.3881572548858,46.436284764222904 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark45(-460.24634005387355,-379.8937959560037,0.7353053344631242 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark45(-460.32791462380146,-288.11462228256926,10.225765186762729 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark45(-460.45193648818747,-302.16076890046577,26.021932435241652 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark45(-460.49327940006026,-287.62060755170893,61.0791427716851 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark45(-461.1084214980446,-323.7482315762458,100.0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark45(-461.1092442775706,-295.1176305497508,39.34250841254442 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark45(-461.15573315688977,-317.9957439781792,100.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark45(-461.2629091613387,-352.299169503089,95.91955118262015 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark45(-461.28666952400744,-309.8574813600874,35.90447211991719 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark45(-461.423884176236,-358.42672924604847,28.967531909429198 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark45(-461.49699547444806,-287.9860797175442,100.0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark45(-461.6636044654706,-312.48785241779467,74.66970613599909 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark45(-461.69967537817297,-288.7170369775267,58.90217156455773 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark45(-461.8098710300518,-335.1552413816987,3.878255448603511 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark45(-461.81350152911796,-393.52126130218255,100.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark45(-461.8407774161027,-289.60970940503887,100.0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark45(-461.91003190904337,-352.02109288272794,100.0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark45(-462.0407307108649,-309.4155066109826,82.93394637371134 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark45(-462.3418399257805,-337.7860918291202,99.34538493170169 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark45(-462.612671296609,-325.1110570648195,90.73351311768 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark45(-462.6307265841841,-313.9829394446226,26.617536219409914 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark45(-462.7352320474509,-307.79931826363656,62.006105088188804 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark45(-463.14842536439363,-312.1469371647667,65.34120446487418 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark45(-463.1795916295409,-290.6775572939936,29.7063061924444 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark45(-463.1919153942756,-287.23069299869707,98.62184470486693 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark45(-463.36227831715655,-345.91612018853755,100.0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark45(-463.42941732994154,-329.97113569907236,10.75150102709477 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark45(-463.4450910194672,-304.66640649092034,100.0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark45(-463.45901696371357,-287.15638823376383,36.087378155173354 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark45(-463.55826706163145,-343.7803708893494,54.05689913570092 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark45(-463.59157252397523,-362.18386062175153,100.0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark45(-463.63665976963017,-302.95744254727384,86.234761049393 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark45(-463.6447044019775,-285.811825924782,45.110385277089875 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark45(-463.6706703764487,-305.29362396031934,9.925922044353541 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark45(-463.73000181835744,-297.33428599946285,5.6676515091901365 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark45(-464.0599350969768,-282.9854003851852,46.73518283444568 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark45(-464.13462558638776,-316.3824253064836,35.02749885095639 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark45(-464.2429485812357,-287.19854927878316,100.0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark45(-464.30616464626223,-291.7416135590797,100.0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark45(-464.3971370988882,-339.69680246023603,71.52056174598877 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark45(-464.4855320071922,-283.3294493195154,22.650375553278337 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark45(-464.6685939622193,-281.5593295453839,51.22087711425581 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark45(-464.8406236558227,-342.9299645089372,63.49053653383265 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark45(-464.9948273932836,-328.64563042349033,35.3794410086156 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark45(-465.52416629390154,-292.8921166882909,81.9795798159538 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark45(-465.52490661958666,-300.03492359909984,52.903084031854746 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark45(-465.53518195265866,-350.28548863745397,100.0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark45(-465.57524550093683,-290.9934884672165,57.11707383619316 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark45(-465.5964369546745,-338.97380227702183,13.834847316326119 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark45(-465.62894235472794,-307.89868143800294,100.0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark45(-465.9153003318664,-281.45357498587913,22.514706177985474 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark45(-466.17913368414986,-339.5762386374887,89.43316744020794 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark45(-466.25043556904404,-321.27651986480936,2.2592263845168787 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark45(-466.3475863054452,-286.6725578652893,11.75763240001777 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark45(-466.5355617673796,-335.8015139765528,91.45105925779177 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark45(-466.6529959381599,-286.5151975571682,100.0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark45(-466.72612987480875,-300.60177192617766,19.315757942924435 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark45(-466.75888830559643,-317.9634811178398,11.846331045140616 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark45(-466.85595114338724,-344.69106967819005,100.0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark45(-467.0543225994717,-306.65509690881714,21.30489583516824 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark45(-467.17278027045904,-311.4053989343112,54.559566758052114 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark45(-467.1970294415797,-352.85086071533954,5.762841693350438 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark45(-467.2022737005289,-297.20677083940376,53.82741170393109 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark45(-467.2445653517138,-323.90044116856507,1.14196788087186 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark45(-467.3675639348062,-279.0570298382887,36.194579718593474 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark45(-467.3713927437689,-295.8680812804336,28.3503394197796 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark45(-467.403957164845,-287.0604920723624,47.16854034607522 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark45(-467.5184700300924,-289.11390212592937,96.7618529872519 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark45(-467.5350563936726,-323.0580789341756,100.0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark45(-467.5412380607665,-333.8725868088921,100.0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark45(-467.83246796054857,-291.24769492238374,100.0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark45(-467.99774507896325,-290.90469877131096,100.0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark45(-468.0034980449658,-316.8227433349829,0.12009605441110693 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark45(-468.0329710002447,-286.61635905675166,92.02748360239633 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark45(-468.08762727090294,-278.36784283497286,61.518824587881284 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark45(-468.2062164920315,-281.4457354989719,89.38987571982315 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark45(-468.2290103522442,-287.72556735442373,49.70627169440348 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark45(-468.268937732568,-294.3183453810272,41.98789153131372 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark45(-468.279187133425,-322.4342028139854,99.81517986360731 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark45(-468.3012352013747,-317.86690475007345,43.58002162538824 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark45(-468.31554385820283,-281.4760683507611,55.21394694745416 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark45(-468.5608265874626,-323.4670735644779,20.603809278609447 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark45(-468.5980013170157,-314.9505518591575,83.62109806629636 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark45(-469.0858296026465,-287.9156738918427,67.89344583723593 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark45(-469.27076774644684,-306.5056718571429,81.77310980290946 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark45(-469.2773978345976,-278.55994468138607,18.56985550498503 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark45(-469.2865303951248,-312.1852244944215,100.0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark45(-469.4841537421294,-356.31025685250717,64.11349982744417 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark45(-469.562200688663,-373.0636891813043,100.0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark45(-469.6154634116979,-371.40742192211644,97.82990094659723 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark45(-469.65682131211287,-289.4054680012343,100.0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark45(-469.6843568693163,-285.07162677545284,100.0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark45(-469.6955490848926,-283.75153297825125,24.795293775633652 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark45(-469.7281480057185,-369.38560231465794,39.31925026607536 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark45(-469.7504991183191,-292.07616064384234,100.0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark45(-469.9146481687951,-279.7213213642872,10.487463633380983 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark45(-469.9712287629812,-294.24546234397934,45.176372250863636 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark45(-470.3162262932887,-293.35259454308925,72.14561493046054 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark45(-470.3578759246059,-322.36506419944845,41.24366329881707 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark45(-470.3774706742515,-291.72932512808336,91.4990088297858 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark45(-470.3841544495983,-299.35049736403107,75.04610960678829 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark45(-470.45097580874113,-285.5095230743746,76.6678689834819 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark45(-470.4880124123264,-290.77685226082747,86.35888122733417 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark45(-470.6418228575046,-294.12015383161855,21.015932221159233 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark45(-470.95410393556057,-285.7132495675008,65.59569233572631 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark45(-471.0043552289459,-298.70031691731594,19.97336568819688 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark45(-471.3467205903072,-303.0973664310254,100.0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark45(-471.48024202157995,-291.0536209083161,12.448673278636676 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark45(-471.7130992182124,-275.61989932256216,20.971837862753432 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark45(-471.73276594914427,-336.34559428514433,100.0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark45(-471.7345786179484,-289.60344938457337,94.59608094149431 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark45(-471.7923119451807,-285.049288915884,100.0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark45(-471.8294958696769,-283.1684643696695,59.965500987126774 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark45(-471.89312908994634,-276.1665979548697,49.78471069004874 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark45(-471.9531549762889,-292.79727018637016,36.16759400181047 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark45(-472.1476639622926,-283.5917994105265,100.0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark45(-472.1606680671776,-274.6399600614264,72.06491677708519 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark45(-472.2055894148862,-299.01593033967765,66.77490573716071 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark45(-472.3792715005817,-292.4181761063305,32.65795384788882 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark45(-472.57965003587407,-282.68817677924517,78.69550436293977 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark45(-472.63092447045545,-319.10178683656716,26.30676412404081 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark45(-472.6600226078081,-286.4535235122345,45.18802760274849 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark45(-472.75442198593174,-350.8402554900214,7.364338941465192 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark45(-472.9676500896997,-280.31015089307164,65.5076285594591 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark45(-473.007875115431,-278.2171721788854,100.0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark45(-473.0423973839901,-285.17362210264633,10.085173758446814 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark45(-473.31949386832633,-284.29974982116414,92.150609155009 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark45(-473.3752342968025,-285.0386597226248,47.36529359672245 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark45(-473.5129842063101,-344.6837950889555,7.237407698515838 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark45(-473.6901937852541,-308.6862711488863,30.52979334183638 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark45(-473.8196193619018,-280.66126283743193,19.19859049588125 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark45(-473.9246140147687,-313.4124728293759,88.93642775030128 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark45(-473.971278125159,-281.79329932046386,75.76286960289232 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark45(-474.0555665094367,-310.9673181979014,85.04616894853251 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark45(-474.0965208774895,-302.15127751104166,92.46314693248604 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark45(-474.16193233207855,-289.1397693781182,4.837505714557594 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark45(-474.27629074213166,-278.9695260205999,99.19589719147302 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark45(-474.2818972058973,-272.7862080320198,51.71405415237737 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark45(-474.4710508530336,-278.20444819745484,91.54970419001324 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark45(-474.4873609610736,-271.56262469362304,22.181562262074834 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark45(-474.4916649362769,-301.24992909385423,0.5516554554456832 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark45(-474.5347412604282,-293.9051266907665,20.517454605764 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark45(-474.5551199115259,-274.9161410812875,8.439684593668858 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark45(-474.5741744732573,-280.1783456153021,100.0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark45(-474.75989512374707,-323.5621186162519,20.39846988776344 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark45(-474.76305029564503,-287.26583848254006,53.29553563693722 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark45(-474.81221624054746,-299.7706399013494,66.74476591466515 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark45(-474.83550578193507,-311.848845090213,31.513331037507847 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark45(-474.89034286125644,-293.2612555419412,4.12307128268894 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark45(-474.9760098136038,-319.31443969628157,89.07725447170338 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark45(-475.0048177160842,-307.33741248614217,39.04166267177516 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark45(-475.03848270426016,-287.84743367285034,77.14148413581029 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark45(-475.2974404303794,-282.46132099216385,53.00068177874144 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark45(-475.3866022054033,-286.46182487717226,95.55638858237594 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark45(-475.4464959623974,-278.2046261960492,26.25841713540966 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark45(-476.0752771792908,-294.1068401035935,58.428097477505304 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark45(-476.0844155973796,-271.0794780560043,100.0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark45(-476.15444934866696,-273.49504147871664,20.63499423011737 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark45(-476.3464108648611,-308.83488625653223,87.36572841414872 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark45(-476.3605461891789,-303.9248151092751,100.0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark45(-476.51654577017786,-291.6957569763936,55.163449036212455 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark45(-476.55995844172304,-270.0972296353965,16.361784968989966 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark45(-476.8674883190368,-294.9149361449739,83.75679498555037 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark45(-477.1700437188736,-322.4438687306958,0.9757076248506138 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark45(-477.18214954033624,-272.8762128684963,100.0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark45(-477.28582630324087,-274.08905762885075,90.0830104982104 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark45(-477.58397809969955,-316.3031113558162,100.0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark45(-477.65052886156735,-275.66971600055007,36.32594771689023 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark45(-477.6841809206531,-280.7780776509027,10.8790482213752 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark45(-477.75127658622625,-340.6443030138688,62.23083409153014 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark45(-477.92561280164006,-316.8310859008725,57.73004880007272 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark45(-478.3305417686492,-285.565850144951,36.1740047535983 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark45(-478.3538349603135,-293.2592659596349,19.719314915867386 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark45(-478.3660077081154,-293.38099237207524,70.21943203327353 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark45(-478.383477399574,-269.91266957014153,2.7412720994606357 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark45(-478.5031631671525,-275.7562773356084,49.22556980639493 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark45(-478.65486112537184,-298.40794083265797,46.417777235487875 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark45(-478.9690674302517,-375.879507991321,84.1246755450882 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark45(-479.23604354040714,-293.85798285042824,31.80840082718689 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark45(-479.3849681964399,-302.1240399341443,63.141890839406415 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark45(-479.39342105997684,-301.7617885523977,76.44489110320126 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark45(-479.43866331417996,-289.8706403652209,5.506587554561904 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark45(-479.43980387100424,-268.74628388247936,57.36000710466675 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark45(-479.80080015638026,-290.0126973478439,100.0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark45(-479.9007367596214,-333.9477399294891,57.44445987459267 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark45(-479.92895455041435,-279.1552813273647,22.40729155318084 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark45(-480.0085055864681,-277.30463888205713,5.199939433509286 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark45(-480.0410830078886,-338.07961178690647,100.0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark45(-480.2895323355006,-336.15223844737517,53.15688190726681 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark45(-480.34707660712553,-272.4193796879872,100.0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark45(-480.443727390425,-271.371709640989,1.6332164570105618 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark45(-480.72283825647935,-274.35965964702444,100.0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark45(-480.73954658191155,-348.03736139125556,36.918388889154244 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark45(-480.8777378785274,-316.42273409018696,100.0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark45(-480.8881041761115,-284.2190951218529,51.2851780120796 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark45(-481.406031263013,-266.4201076858463,49.88992180814458 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark45(-481.41359928950425,-315.52343141552404,93.16397550913322 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark45(-481.5573504803198,-266.4524898654855,65.99955274195017 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark45(-481.731506628677,-271.32198099256937,73.84160461701197 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark45(-481.7982343689718,-308.864287461515,100.0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark45(-481.9153603495713,-304.9860564761714,13.93573449818129 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark45(-482.26387481025995,-265.9103498458882,68.09299717109016 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark45(-482.62377884654904,-285.10278587392366,14.804259808081824 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark45(-482.7316374634313,-270.12775784152643,67.89623874378691 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark45(-482.73682493471887,-310.33566476016705,29.500949645791813 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark45(-483.01578119306214,-297.27536754114186,100.0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark45(-483.20882292434413,-265.48347284606103,100.0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark45(-483.2186679838064,-268.5338247527018,96.96643120685496 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark45(-483.27351692696845,-302.26592418019004,28.51487086204409 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark45(-483.37201884437894,-324.8647390170313,95.48142469876822 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark45(-483.5667914065641,-335.4665830071995,19.75492531377587 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark45(-483.8585681919481,-281.9351393148937,33.67286215466362 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark45(-484.182243622549,-262.0678760322123,69.84491349105716 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark45(-484.1914682061936,-287.1138415173306,93.41538360196395 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark45(-484.5887780900958,-300.8941548717269,20.22943252422371 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark45(-484.63915806131484,-328.9854921199215,95.0730109288742 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark45(-484.6839229951892,-302.79373170338573,21.20267087294836 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark45(-484.7192358056625,-277.20242248837405,66.8768939727241 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark45(-484.784549624302,-332.9157528147017,45.40639316582971 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark45(-484.86318062280776,-345.253141789254,81.2104367751096 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark45(-484.9570636658152,-261.31226595885676,16.107724650340828 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark45(-485.03061352282754,-267.8549654142444,100.0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark45(-485.0770918972668,-270.9235453081161,80.83775473142873 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark45(-485.1261492332367,-274.5003918161946,77.91663401003152 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark45(-485.1524699038922,-295.3567763372419,5.163847747912456 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark45(-485.35947516925995,-261.57146270430735,0.9548550345545692 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark45(-485.5844277681245,-271.06503952410463,18.478171807245687 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark45(-485.5914709668173,-266.0543409766813,85.72377960134827 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark45(-485.68209871418946,-324.3331601195366,38.82972091342805 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark45(-485.74788583991824,-280.5601900798221,98.66457137238159 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark45(-485.9837752133013,-261.6258878207674,79.47960211906087 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark45(-486.0241707303993,-263.4074024653168,83.72068203885539 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark45(-486.0249640847397,-260.4177478543666,45.63241052411678 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark45(-486.0384219978268,-300.3949100417672,39.25481633930454 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark45(-486.40366646242046,-283.9768949023527,23.259947211771966 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark45(-486.58324467740925,-275.33129687706185,75.3403881087778 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark45(-486.5884187694054,-271.5320289238692,66.85174536102664 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark45(-486.65270568701595,-320.2707646294014,23.404435083337958 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark45(-486.7321168343451,-262.35061046952336,8.509158200197845 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark45(-486.7920036890918,-343.85720779777023,32.93298020296652 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark45(-486.8507429628702,-270.97407774305367,41.45102710950391 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark45(-486.91429580442565,-329.7872644978396,11.631349262237919 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark45(-487.00872066681967,-290.44491115055547,70.84905480472185 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark45(-487.19205084361073,-264.2686268870028,17.463763853676852 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark45(-487.42883077608764,-294.7842042539287,84.61880361641765 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark45(-487.49962180009663,-309.4353442714571,36.83238024594746 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark45(-487.5278840980067,-320.33019596124456,18.103341363182054 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark45(-487.5400472077398,-318.9221977083081,50.62634791963845 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark45(-487.81826738943914,-259.0135383257849,49.81239330166403 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark45(-488.23435203778115,-271.821307931987,58.77678725311398 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark45(-488.4028761592193,-322.3756800149927,100.0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark45(-488.6414923588977,-313.12044351036616,19.44219526380158 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark45(-488.69846372239465,-293.687840860787,8.919923224354108 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark45(-488.7324299202202,-273.5571872699876,39.29127331602393 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark45(-488.84569654828664,-286.9425557912452,79.40759472607593 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark45(-488.93079709896404,-271.97826840369817,46.65362292083094 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark45(-488.9650563460131,-330.4889935623269,59.03691086239979 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark45(-489.09915516482715,-287.46372275292225,37.92982169893628 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark45(-489.2152022782652,-312.596631296112,17.253480040781483 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark45(-489.3061792498676,-258.0185224137927,77.72452204271934 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark45(-489.7244187468093,-297.7818446185181,80.92895295838974 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark45(-489.93403826617094,-294.86983131903474,76.24028084056641 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark45(-490.0583297695355,-258.60913272423727,49.03932615627809 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark45(-490.3123977530037,-275.65646377041367,100.0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark45(-490.39583994289313,-275.46052232256494,33.971585808869094 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark45(-490.4740572248741,-290.5944531811755,100.0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark45(-490.7760329470487,-291.95440537875265,100.0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark45(-490.7978900413698,-272.8435978543812,77.56815026796315 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark45(-491.0351216282404,-274.46763818496345,66.56684115991337 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark45(-491.10566026323954,-271.09183024992154,36.29240717363453 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark45(-491.1276812054361,-270.09750189586714,24.26432308037863 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark45(-491.467225791955,-350.317558542805,80.20714120705443 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark45(-491.6455716229985,-294.6893305409926,78.37739856134519 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark45(-491.76071847583825,-288.61606408865276,25.89743464478707 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark45(-491.9511912530394,-314.61627795738934,86.956642684039 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark45(-491.9582292605044,-281.22207609351995,27.76528978292778 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark45(-491.9904178410091,-284.8062320881313,84.91145337228494 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark45(-492.0183294633056,-286.6065966674118,10.665851597120335 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark45(-492.0374986502338,-285.6017751592048,17.92947019018753 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark45(-492.1033003639701,-261.9400206265495,24.44415375378044 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark45(-492.25912286210325,-319.8215250789625,71.0665213949367 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark45(-492.4068486603808,-254.8469315248344,68.64495780206767 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark45(-492.512160664442,-272.4830302689837,53.77031377013062 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark45(-492.5380873693808,-263.9248139691549,1.1537912929816656 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark45(-492.5819923894924,-260.02893376316354,98.32865660412884 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark45(-492.7038684775453,-273.1951299158666,55.15679109956696 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark45(-492.76108030709406,-260.1775683672569,26.802128095250467 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark45(-492.79713921022017,-316.0715840193721,82.07518743160577 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark45(-492.85475473691537,-276.6665826985031,63.56692789437801 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark45(-492.89799943974,-396.63103740881286,30.820852243084914 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark45(-492.91390377624316,-307.9486868444804,79.66419794883163 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark45(-492.91597475748137,-260.485919925834,97.32343510933649 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark45(-493.00400596591186,-309.7553658023219,100.0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark45(-493.2597652383736,-277.22357692741167,100.0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark45(-493.3429025406286,-313.96075660091907,100.0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark45(-493.4750147520884,-264.7538419928529,53.08782086080055 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark45(-493.9172913146896,-255.89767933461894,5.2870884678313246E-5 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark45(-494.01832037485036,-322.1605213236862,44.42640415179858 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark45(-494.0457387113874,-264.3668770966439,60.589638677316316 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark45(-494.20120103470873,-253.5630391796408,19.66954464517265 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark45(-494.2692353403093,-292.1955868703322,36.581973438746104 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark45(-494.2800782074519,-264.6694079144492,14.517504131560315 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark45(-494.349249031206,-275.32440619972897,18.671751120963293 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark45(-494.52854391895005,-290.4156860733077,43.36101474601722 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark45(-494.54316075081107,-252.6184743779725,94.8039117930484 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark45(-494.6676491184185,-276.035024968842,7.0954821034701325 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark45(-49.47559147857588,-707.7765311230106,73.13275092438082 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark45(-495.03688253611216,-278.6325948425473,70.61722044144938 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark45(-495.1815073167403,-260.79436718171127,12.1785694602018 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark45(-495.322958175356,-309.473494717599,62.99955002032186 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark45(-495.32888171206724,-278.1694033911886,46.791172069001334 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark45(-495.3507480221367,-259.9361522924231,67.55315933481756 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark45(-495.4632438889206,-324.5355473947461,71.27102438498795 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark45(-495.5721675588503,-251.03296905288806,51.56510678039808 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark45(-495.70168628010396,-259.3754547998428,36.482613521842865 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark45(-495.7483544684907,-341.3011575797112,18.285632961031894 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark45(-495.77598901563624,-262.8472283540903,38.00634727119461 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark45(-495.80270770894504,-254.60650763202133,10.031730549845417 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark45(-495.8102100154197,-255.14812352324677,91.83261971995748 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark45(-495.9724815092084,-293.0238767358774,24.407117585342604 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark45(-495.9838594427145,-317.146753937855,45.41841721249108 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark45(-496.0759416368347,-277.3842102649173,7.105427357601002E-15 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark45(-496.09481727490567,-261.85405797595297,72.07024230926197 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark45(-496.2497431903555,-326.5705053935675,1.0353050049180155 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark45(-496.36041511796225,-268.0972460463871,9.852502598349759 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark45(-496.6049243488848,-268.8655836034625,57.685634857131305 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark45(-496.9172228702101,-250.18416765880164,48.41615214942716 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark45(-496.94029481530083,-262.81328678673486,2.450531426975175 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark45(-497.1375502291866,-255.10558183896157,49.39223713594686 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark45(-497.26581866637855,-256.7680441235488,27.348883374484316 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark45(-497.27713173631605,-315.4478240631259,5.443222749644235 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark45(-497.3250962804273,-328.23532034446976,42.701103742880264 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark45(-497.50108675553156,-309.5093922633525,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark45(-497.51269848264525,-261.0335946487719,38.53412375654486 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark45(-497.55231707899065,-263.52497637945356,55.961650094670176 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark45(-497.6203732644205,-285.01654840228935,33.72852179147506 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark45(-497.7173733188914,-299.2957100394914,81.00087237755369 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark45(-497.718409056747,-257.11335996073524,100.0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark45(-497.7585642175556,-259.6168217923375,79.045309509448 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark45(-497.9790382636102,-271.6704443636482,33.05996725910529 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark45(-498.04556125526,-250.15972058784774,22.201617617860606 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark45(-498.25736632403846,-280.95614505695755,68.68050031192544 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark45(-498.31913504514404,-265.9721566804519,100.0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark45(-498.3293566818029,-267.78653190200896,76.02396923405331 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark45(-498.44631983861393,-283.5474088189952,14.109140793008606 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark45(-498.5076977480216,-255.87290319032434,61.100583493393486 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark45(-498.53337165138714,-250.36769667838186,1.7939767005861142 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark45(-498.6068766251409,-294.09555775010114,93.32000992502137 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark45(-498.7257018282235,-305.51577283074874,34.670754762448354 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark45(-498.7959821203461,-256.9870422055344,91.6915124998444 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark45(-498.88048151813064,-285.66364515434714,3.7087276623357894 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark45(-499.1351555688329,-251.6952392744943,57.264170783735864 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark45(-499.2299020698351,-308.1684331718644,12.482709407436914 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark45(-499.3285407582009,-295.49460450500237,63.917040223857526 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark45(-499.4901964726211,-277.4615942427844,34.23288221885656 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark45(-499.51439191466363,-256.4207152642661,21.500475972013135 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark45(-499.9196271780762,-254.0738941478824,43.21758221521736 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark45(-499.933187559259,-255.46565706490128,62.247209139190886 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark45(-500.0065731374275,-267.0457760981805,86.13224465244193 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark45(-500.0932052236443,-310.47880853570416,72.92694225637715 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark45(-500.3504780567095,-289.35420581354725,3.561364821421307 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark45(-500.3741970874473,-323.81161794732134,0.41171413282319236 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark45(-500.46881185094674,-265.7933596623865,77.07771825113588 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark45(-500.5774068541187,-272.09545490607275,84.7813083012395 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark45(-500.70215231600605,-262.26457340245065,17.559494981914597 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark45(-500.7344606641657,-286.70176482644877,4.874073609568114 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark45(-501.0203557761297,-259.2935316027006,35.562577221129146 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark45(-501.30705872034156,-283.3061252126502,75.62016761079516 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark45(-501.3119327342389,-298.0700768825936,58.800550138278425 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark45(-501.40294721954496,-291.1467645780125,21.175012416223225 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark45(-501.58271150975133,-246.8071992113142,66.77740042332167 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark45(-501.6067628227502,-273.2122352396744,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark45(-501.89648741209515,-246.55158691070508,81.27476371115253 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark45(-501.99017922825686,-286.84799832071025,27.843826438641003 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark45(-502.13909986275473,-283.8752353077724,55.95580526874173 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark45(-502.15543966049086,-251.8323125233263,51.98963330328482 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark45(-502.1968842123031,-244.55346991574,82.41735145459296 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark45(-502.2415176084332,-296.73744959132983,18.123861273420644 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark45(-502.30196028163397,-307.0048535642414,51.85267345793406 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark45(-502.3732202528926,-272.07601017606095,12.301287735078176 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark45(-502.54303855084873,-290.94441612368354,47.04236011117547 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark45(-502.6207654383761,-277.7965142949815,50.86747878557756 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark45(-502.89158971476223,-332.000861150332,46.09971255475779 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark45(-502.91844091166985,-265.29146438969383,80.75930432668636 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark45(-502.98792421881217,-258.86179998837275,63.8438415872929 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark45(-503.2355205917676,-272.32453095987216,100.0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark45(-503.2493162870016,-249.25142912593225,86.93324854325067 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark45(-503.2651879561727,-277.8774565724119,80.86348202341543 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark45(-503.3158062617267,-257.0560357340343,10.228333123298228 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark45(-503.62956048421665,-279.1156814239285,90.30564664801233 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark45(-503.8397354392912,-289.33316726523134,78.97449569576037 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark45(-503.9547352908058,-287.14673175589104,55.62333468521561 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark45(-503.9965366315738,-273.0140674735184,76.52455468539242 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark45(-504.0247806622447,-301.8241870666011,9.743439294971765 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark45(-504.10164671106344,-278.90676942287485,6.553904148358328 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark45(-504.1044640365721,-264.58884530795103,1.3474141384509863 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark45(-504.147919793133,-263.95391525278023,100.0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark45(-504.28584287937605,-292.5468924426511,1.652702593600793 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark45(-504.31571929485364,-273.5369834154161,74.43475561177232 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark45(-504.46558093948386,-281.75515812691646,20.957075717512154 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark45(-504.9418694069775,-268.24359061085397,21.45312482516006 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark45(-505.0015503707426,-333.06878608288855,5.237232117800048 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark45(-505.0984051961165,-243.283082655316,100.0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark45(-505.1104326410372,-292.49093049115254,100.0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark45(-505.12291838019075,-242.37472712416223,46.597447348358685 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark45(-505.14874300704844,-260.5080137883951,65.69699014089849 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark45(-505.45721240071435,-276.43686047228766,21.317164350421464 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark45(-505.54152973323284,-278.5081127594258,63.30744851755705 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark45(-505.56604777740057,-287.7733000169768,18.940020508613586 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark45(-505.81259953999654,-254.50121097933453,59.64175253665715 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark45(-505.88215831808685,-250.33519370253427,51.982137786151185 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark45(-506.21477099737575,-252.6901000836562,29.69193176781485 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark45(-506.373757588187,-245.75956137408588,70.77427206925361 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark45(-506.48981240038444,-284.049250288886,74.44015265750056 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark45(-506.5425688450512,-276.82822434909485,100.0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark45(-506.56467408255367,-250.12321030111565,63.55281740039905 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark45(-506.6923587484556,-297.22796804898985,20.024540489811542 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark45(-506.95325316512753,-286.0745084085339,18.83159750806682 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark45(-507.07025516577534,-290.27745832948244,14.417643135299272 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark45(-507.4009076722355,-288.4954352912973,35.10307644001452 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark45(-507.4345001761183,-274.202472270578,59.070810215356545 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark45(-507.58456168460555,-250.87690904675648,79.31190358129209 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark45(-507.858868325258,-273.0003471359278,99.25084548955942 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark45(-507.86670368444294,-283.3611433419089,38.119087419332146 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark45(-507.876402476177,-272.8684163929837,94.72696649839506 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark45(-508.1096356513505,-239.84816557609105,81.5278435982587 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark45(-508.1541283813585,-259.8270971052892,61.59925879300138 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark45(-508.2244508154495,-292.146027127674,43.870805976129816 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark45(-508.22966844555083,-251.08691922513268,67.139773099177 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark45(-508.5931052830157,-250.3217798991217,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark45(-508.6143496096105,-253.45151850321014,31.764244833985458 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark45(-508.6462348950161,-237.7934616587151,80.60082395544691 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark45(-508.64901502010764,-244.09094004935153,35.946522598711994 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark45(-508.8424130411794,-259.04541939028,96.24175421852686 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark45(-508.92657878648595,-318.55123347590734,29.332109258928853 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark45(-509.0049075330178,-239.462220272466,100.0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark45(-509.08356502100816,-267.28863022824453,43.01970037711558 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark45(-509.091998341529,-238.03226470140234,31.998614986418914 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark45(-509.0948788419501,-239.7816691453982,93.00359560418272 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark45(-509.12213631559143,-246.98022036603385,44.474211622335815 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark45(-509.34440541009207,-246.65650509624774,52.603862505025546 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark45(-509.4598368139045,-242.1571177729612,70.56546473044891 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark45(-509.5823193090511,-257.2159476729958,40.10369970278157 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark45(-509.7495520829688,-261.4742642268779,34.365877841813244 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark45(-509.9733263624886,-261.2224581417051,100.0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark45(-509.9909092627329,-264.78272474970225,87.67077417233494 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark45(-510.05723825232633,-285.69912544454735,100.0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark45(-510.0684097584249,-274.40745316552926,90.75985186074072 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark45(-510.1888560421788,-286.23098147742337,37.75134849450434 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark45(-510.23180219402497,-250.36095997392178,100.0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark45(-510.38795659702356,-357.0672130336055,2.9442526222473333 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark45(-510.59222626643844,-275.89060927230014,72.82969712667148 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark45(-510.7366575345981,-246.36601508794752,30.06968137809676 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark45(-510.75710636704974,-350.30675985668165,10.812705549248008 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark45(-510.9765519553025,-289.55487884724374,48.92804214596404 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark45(-510.9966386144704,-239.38950121567774,35.38196990397137 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark45(-511.0970085356136,-251.96785961283058,80.91372099548903 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark45(-511.2295791150283,-259.0177740149552,58.62819182124815 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark45(-511.26840179259057,-241.29704559271545,100.0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark45(-511.37179473139844,-238.51041567612486,87.39395218252221 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark45(-511.37657853599234,-265.74921683409946,96.59161536785868 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark45(-511.4307215225637,-244.21282048475518,84.51472873013844 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark45(-511.52953230166446,-258.2393585988689,0.5157326544932728 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark45(-511.67023803406903,-295.5517265753689,65.10410960171134 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark45(-511.704492383317,-250.89959407765826,63.33850083762164 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark45(-511.81825978478605,-322.5308253594795,8.501672895198226 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark45(-511.93100890601863,-286.63457773902394,54.68558120748267 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark45(-512.0119317237474,-261.11392263062453,32.51655337950953 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark45(-512.0150445220322,-234.5492792034614,15.231062575763787 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark45(-512.2496614204562,-312.0887472774365,2.9350205229671644 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark45(-512.5300951923299,-233.982918663896,100.0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark45(-512.58421086183,-236.03152507649,100.0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark45(-512.6671667883154,-293.14409427489306,100.0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark45(-512.7293738471678,-264.55827380159576,7.846448718602247 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark45(-512.8672311620967,-257.1137828510551,33.90070397052554 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark45(-512.9092890907984,-241.00713987588617,85.38871227037842 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark45(-513.022379259485,-251.23498415089955,68.62044268465013 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark45(-513.0579694667126,-247.4577182719963,50.837342278479014 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark45(-513.3915829847376,-251.98627659954857,100.0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark45(-513.4810245651685,-245.5842136582242,0.9657216648274982 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark45(-513.6114185089378,-258.5413996157331,100.0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark45(-513.6273038763795,-283.9402436049979,100.0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark45(-513.7157960688892,-249.11636490036344,64.77884581042176 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark45(-513.7206768082756,-248.48057698819267,32.126314137040225 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark45(-513.7521088840447,-290.5016365632531,100.0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark45(-513.9088034854981,-249.5337819013186,95.01771335043134 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark45(-513.9402903630424,-236.0207870647283,70.1719041321997 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark45(-514.1794152380613,-248.63054684162813,66.07909295587785 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark45(-514.5369667837161,-262.53310832566854,100.0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark45(-514.7801351199184,-237.3915596535135,27.32601057147035 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark45(-514.8578151976627,-247.53837500541346,100.0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark45(-515.0216367511919,-316.4124668786363,8.76849480928918 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark45(-515.3181077583233,-239.17278991591127,48.35964084865034 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark45(-515.5993318694798,-268.98338627429933,86.62667485563645 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark45(-515.8832828086078,-233.39211088325908,61.13734873671065 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark45(-515.957625434396,-304.06836206112456,53.039470589583004 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark45(-516.0465612440663,-262.0899639189387,79.32637473254997 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark45(-516.1007085608427,-253.28326726726345,73.98184731071998 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark45(-51.61095805970844,-727.0209389746549,33.56251582785262 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark45(-516.5032153301897,-257.9080144783278,81.72330620956586 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark45(-516.8678011755229,-261.3743340392709,38.43740242124372 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark45(-516.9248522241104,-247.0367156479518,85.11167365229338 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark45(-517.0685034118437,-244.1340306689432,60.8488890223509 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark45(-517.1472069836025,-255.90270846166803,100.0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark45(-517.3978057522651,-234.99113068214945,65.11276575578233 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark45(-517.454453129641,-302.25101738578394,10.340606974668995 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark45(-517.4738300623944,-236.35534837761952,72.28359693428777 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark45(-517.5138873815149,-230.62253873212558,20.183925249725768 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark45(-517.6472875729171,-253.7148519270608,9.946188490826799 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark45(-517.7935959081423,-231.761501917452,92.91072381328627 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark45(-517.8065073925204,-247.486776155533,19.3984832307452 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark45(-517.9455837041309,-255.60150255276645,100.0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark45(-518.3808778966152,-234.8698892537385,58.66577794199799 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark45(-518.4136364452522,-258.5786461973256,88.59357127505939 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark45(-518.5890141216174,-238.21555506743664,40.80079254278343 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark45(-518.5905131356953,-237.48667265745354,69.17624345979533 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark45(-518.6859009252568,-294.46722151931135,100.0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark45(-518.76641197979,-316.76643875511655,45.26979769463202 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark45(-518.7947474052395,-265.6697512132496,83.48693003391148 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark45(-518.8120477104305,-285.1227257723628,79.8324376225286 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark45(-518.9248194911961,-248.13293262750912,90.98723861924105 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark45(-518.930497352526,-271.69533740613565,23.342844040561644 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark45(-519.0994422250185,-292.65306675054114,81.07947585050076 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark45(-519.2251441084485,-228.74793228963802,22.197736356234742 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark45(-519.2259100978769,-245.5304457397009,73.4062841696348 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark45(-519.5162046487508,-248.77140160239418,13.745619536651901 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark45(-519.5233244489862,-254.93698358452934,8.831076662040545 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark45(-519.7958260887635,-235.2700899461728,89.90897639825545 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark45(-519.8267643252291,-246.0493023320628,51.6641366364467 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark45(-519.8672478511445,-261.122501491771,65.14279643175487 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark45(-520.0532785124485,-264.6975739340675,82.59692285375681 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark45(-520.0688678996058,-238.85770073757314,41.90412016594044 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark45(-520.1838705202317,-357.39192071411503,18.14775784550791 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark45(-520.4698004127139,-256.63289060396755,44.84998225545948 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark45(-520.5433691790887,-270.5814520927158,60.989819199260495 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark45(-520.6059599023665,-237.9383149756635,54.56283224867349 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark45(-520.6309688500337,-257.0676005369984,100.0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark45(-520.7426721732502,-266.78124308419274,25.613022752604373 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark45(-520.7600981262979,-263.7572385020322,0.8807305224646171 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark45(-520.7787950978612,-281.6509485179206,22.08786744478492 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark45(-520.8629944384011,-228.95651884478167,83.12705846549576 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark45(-520.9466543507612,-243.3323998500086,99.94531624067179 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark45(-520.9925725702147,-284.50560324961026,38.103700651434394 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark45(-521.8441962234805,-261.48018306715744,100.0 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark45(-521.9145839521498,-276.03466382151606,100.0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark45(-522.0560851066836,-265.4837727496007,42.65689482863533 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark45(-522.1380187098475,-252.610930105245,27.868902828112454 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark45(-522.2427786168026,-223.99698159452927,95.01636439741928 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark45(-522.2459845232308,-235.60603787649492,-56.70611794748901 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark45(-522.4996402715183,-309.08121151980697,84.24567686639381 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark45(-522.5580061587119,-239.18741914107702,79.1354385776961 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark45(-522.5665301199792,-294.78910960877056,100.0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark45(-522.611486468797,-237.0031512861633,56.65064491367002 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark45(-522.6433855176316,-245.49247735679472,99.70593296596081 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark45(-522.8238536514242,-234.21641517617928,55.710447165068445 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark45(-522.898648863557,-315.34575006540723,11.8174967651737 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark45(-522.901713522505,-251.56734660381517,35.15805848179687 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark45(-522.919528046674,-236.37420974896153,39.13164592263357 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark45(-522.9889170327701,-237.40860254006856,64.23337316357362 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark45(-523.1951633012652,-291.1064017281447,58.778158436738806 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark45(-523.3992434311109,-268.35631211484844,100.0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark45(-523.4881265542747,-233.11163586793546,44.68157322643194 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark45(-523.6202972192742,-239.0621316680714,18.801660037108974 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark45(-523.7930417436125,-268.26524058638324,50.64108349509752 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark45(-523.8866235423393,-293.8871815084783,52.34919391538126 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark45(-523.9031551920142,-225.34592521600464,92.0509606210579 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark45(-524.4280355873032,-224.4205385181982,0.9300492718100202 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark45(-524.5067264997099,-257.3914514586294,93.20478391369008 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark45(-524.9697117035931,-221.16902860676703,100.0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark45(-525.246157608997,-221.32394476244974,1.5353905266426864 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark45(-525.2970073353052,-244.7888397756914,31.339633010976662 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark45(-525.3369885330296,-261.3299306240582,100.0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark45(-525.3413447483648,-227.5641454757462,81.1686223730658 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark45(-525.4093764629406,-251.18499503282476,92.0358239397064 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark45(-525.4412884186844,-239.90171971093216,72.07359164204956 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark45(-525.5993751065555,-262.9791084182189,38.620299760743194 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark45(-525.6883864496953,-247.43230235729723,71.14135521678136 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark45(-525.9537264819995,-230.493478114117,93.72390598731525 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark45(-526.0006146778833,-276.8798832514362,100.0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark45(-526.0087222580948,-225.19688303676764,19.22878528370893 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark45(-526.053383351156,-226.78229842382612,12.99479005130894 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark45(-526.3947674395392,-241.1042335654311,66.51157228890804 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark45(-526.4492862612956,-227.28612449264625,75.04800250418441 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark45(-526.5965109414562,-257.8752731310544,89.92371832185717 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark45(-526.7904923959065,-243.28211970258877,75.61274594970939 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark45(-527.0138559219433,-224.18902932164133,94.33415273786943 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark45(-527.0418860258678,-222.9263190564492,98.73992849531962 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark45(-527.0658943380271,-225.60615455816185,62.34490565270909 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark45(-528.0715879039839,-223.35454507040942,58.13291991561388 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark45(-528.1140775160379,-230.49222425791461,64.13387974324024 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark45(-528.133548195307,-220.74033305856352,79.7293823439633 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark45(-528.2218885461293,-232.81142029768463,34.46208233248689 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark45(-528.4328229400554,-237.79573051396653,91.92228533077014 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark45(-528.5032475541182,-237.084877607212,41.57341090411768 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark45(-528.5543592098759,-278.77657118540105,10.763381569323165 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark45(-528.5814549092437,-225.96560485496227,64.05162136238803 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark45(-528.6673801226353,-267.57058122940396,26.445765766351983 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark45(-528.9957585787851,-224.47226125687718,3.7199245466252364 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark45(-529.1495266896566,-218.60974606959505,54.15787676149915 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark45(-529.1685189633885,-254.76845936508664,100.0 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark45(-529.2345134845189,-226.82808170898156,90.79722329072507 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark45(-529.5995281403159,-222.84611080290802,100.0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark45(-529.6571584979497,-256.51369373964724,22.773361027219337 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark45(-529.7209784507122,-281.1129289957886,59.49806202219992 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark45(-529.8076013205041,-231.49556216458183,95.94314874612678 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark45(-529.8413866946337,-246.16250685362064,23.845767338371004 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark45(-530.042188931654,-247.7609933305198,46.77524330524406 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark45(-530.052728760883,-253.7027842540092,73.42447754879603 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark45(-530.231410684517,-274.3204706369185,73.85140258951529 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark45(-530.3667273762408,-220.8115803420697,63.393761577595654 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark45(-530.5217285311741,-240.33345775054312,86.20287945643054 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark45(-530.6733691176977,-259.29997651917773,28.59448951792399 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark45(-530.706058894616,-236.62342741039203,2.325553334657393 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark45(-530.8180775227895,-219.7486199453056,100.0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark45(-530.9340439625572,-232.1603227205794,49.526715585410926 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark45(-531.020446672901,-247.75061977679596,69.25227608397705 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark45(-531.2028808738687,-229.8092328263841,83.83350444507795 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark45(-531.3150144134586,-257.07633773859743,100.0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark45(-531.673688635269,-239.5959732982592,97.1942535081262 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark45(-532.0146046164309,-252.7273337692975,100.0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark45(-532.033704348951,-230.86860460138004,100.0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark45(-532.1122552834913,-294.930243228482,81.36110476242695 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark45(-532.7788229758171,-354.7497644716248,27.704755688158514 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark45(-533.071108254412,-260.9154675559667,2.49353738277118 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark45(-533.0940885842274,-224.14622273462246,100.0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark45(-533.1180174921668,-229.20382495310784,75.15885616192409 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark45(-533.2804855584956,-223.0885081109176,79.50107506073039 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark45(-533.6066186657406,-245.20836708827906,100.0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark45(-533.615229940793,-214.95258532255275,100.0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark45(-533.7814313243621,-240.84540645734387,63.69305965788277 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark45(-533.8216876848892,-216.73352743534122,35.71922559446776 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark45(-533.905929094964,-224.10246004566537,64.42756932281847 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark45(-534.0377013010918,-285.8974918124372,96.809673476098 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark45(-534.1521791234856,-220.78560337036865,80.11088966110373 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark45(-534.1696341036592,-267.80081018426574,87.84221528074531 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark45(-534.6478703559967,-245.6080084988411,73.19785469281089 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark45(-534.7284271663374,-215.81490775047132,17.316076616805702 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark45(-534.8801453944669,-274.99095591340296,19.356175078758866 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark45(-535.1417918342798,-257.78339816382965,34.20226279396087 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark45(-535.4912102008467,-212.18728885551891,35.848263013891 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark45(-535.8341601937632,-231.4499398359654,39.42850724677862 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark45(-535.93558814249,-258.7578730678176,100.0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark45(-536.0630459128604,-279.6154356687549,100.0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark45(-536.498393443279,-296.4039736413893,38.49843893810652 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark45(-536.5692896742845,-218.17767168116637,100.0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark45(-536.5770971271875,-237.209601921734,49.106853629925126 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark45(-536.6569226757069,-234.28981850650743,88.34405971386991 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark45(-536.6584256654127,-226.78410534863696,35.05437453300331 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark45(-536.9467511893038,-236.25400103648263,96.17467245619969 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark45(-536.951834144081,-264.5842286242034,68.30089442504098 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark45(-537.0480349793578,-220.6918069589969,94.28726896901452 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark45(-537.0752973916378,-272.1471492526759,100.0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark45(-537.1040875415862,-221.8657206361331,65.51148176437144 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark45(-537.296888111352,-233.34590503846601,43.725837300880386 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark45(-537.3361094587721,-237.1805671254823,62.87369677060204 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark45(-537.5147147558146,-226.78700628716402,94.26976898564692 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark45(-537.6270330579401,-228.88379346077366,82.17916026379984 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark45(-537.683835603709,-256.06129995687047,16.023668881137837 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark45(-537.7711002182485,-231.7357642493885,71.22834759325417 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark45(-537.802503012475,-212.43417655618163,16.99084783781538 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark45(-537.9485679028566,-212.65132111354782,86.02871767559418 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark45(-538.186049337426,-268.1606477366215,76.50310300355235 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark45(-538.4747557914526,-225.7940571081678,100.0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark45(-538.5231521527775,-248.48052045709568,53.25943878738104 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark45(-538.605479609364,-221.274193957729,100.0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark45(-538.6102379305198,-247.22297466881116,100.0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark45(-538.7240696519951,-245.40764550837548,6.6263437424096026 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark45(-538.97477982027,-210.29523807039595,33.17577277219749 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark45(-539.2468258689478,-278.371156835053,14.710377159196824 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark45(-539.2675157877084,-208.53238093804157,82.74476072801943 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark45(-539.3946343207873,-246.45860207341104,4.371518806059754 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark45(-539.7122278952099,-270.7510968663813,67.94650413459732 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark45(-540.2718617969222,-210.38187936198685,5.419042275991146 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark45(-541.2717858746848,-209.46599270541648,50.41481865792804 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark45(-541.5714505835696,-209.28731776394895,28.62100310278916 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark45(-541.7642120676803,-236.12241473054388,11.168710717127396 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark45(-541.9401768600752,-233.17229230767867,49.25376420714039 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark45(-542.1718417892735,-210.82740244351683,33.93964395244859 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark45(-542.182847450874,-263.1324221438589,84.4503083476869 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark45(-542.2214732679469,-224.12184682651332,68.31756324467472 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark45(-542.3298790543241,-205.8506059414936,89.70806800253433 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark45(-542.5524044146476,-251.59924788886852,3.9157434225864876 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark45(-543.8953703631503,-205.68104903161998,99.67104113440146 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark45(-544.1575487487911,-207.50564201236574,100.0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark45(-544.179892867089,-211.264167504818,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark45(-544.3858746260969,-203.95230708962723,25.269887804506226 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark45(-544.4496765794228,-239.52246088121507,59.45996480440891 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark45(-545.22130704078,-228.9226448418578,37.4685575769044 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark45(-545.3508208937405,-250.3991165302201,27.253713506181327 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark45(-545.4479057453209,-240.69026459143458,99.18779708947437 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark45(-545.4929769385664,-204.80350128215736,89.2090920463026 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark45(-545.7041709420026,-202.43004378249074,100.0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark45(-545.7519191348109,-211.06286900057432,98.7310111539183 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark45(-545.8324469848624,-251.17970940130846,89.16428988943886 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark45(-545.8346091877253,-214.149518112377,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark45(-546.0081673479967,-243.62126848067984,83.02011211708594 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark45(-546.1549949364244,-227.4742860148604,73.89226416482333 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark45(-546.1873639204795,-218.90606090164357,13.942225287073663 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark45(-546.1937014547794,-314.2293801710311,64.98943382662773 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark45(-546.2397615312397,-272.9445103304137,61.531156525629825 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark45(-546.2404625193733,-250.30169088084563,71.54280924319181 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark45(-546.49218879206,-255.7962042960317,35.56941311274281 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark45(-546.5753925395844,-231.80337638362113,91.07863932285298 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark45(-546.9910915297191,-283.288006032471,3.041940615925199 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark45(-546.9920492132115,-251.38717388224978,84.19157419306097 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark45(-547.0415129033,-204.00202018421075,7.790735606582388 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark45(-54.74311872117569,-699.8878400148517,5.591362808317271 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark45(-547.5114507340385,-260.2261043245128,100.0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark45(-547.6842749349526,-214.33975641734386,0.7468950260737444 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark45(-547.9397148480907,-256.9621985194088,48.21532038305298 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark45(-548.0531699965605,-232.79853966343765,100.0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark45(-548.0575343217041,-214.83595819761112,2.376246841306127 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark45(-548.0790617875334,-248.2778534681898,100.0 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark45(-548.2746271388385,-236.50324298710896,33.74090600408604 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark45(-548.2997904835913,-199.95310218807288,97.38544034485409 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark45(-548.3808453464477,-260.053914521182,58.74111222702675 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark45(-548.4183050575824,-251.06864951896276,50.131118077283645 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark45(-548.7041530852911,-200.56813185609548,84.32690307654298 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark45(-548.7689796964777,-232.6399303454507,93.80474421524525 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark45(-548.8985410945093,-218.728505290488,100.0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark45(-548.9285075925989,-204.66719917904928,42.04750170180429 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark45(-549.024276089899,-201.12578328310946,14.100532821466416 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark45(-549.498575188891,-240.96347822481897,100.0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark45(-549.620343472817,-251.12628813082168,90.39063172119518 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark45(-549.8417994164821,-246.38346772274963,77.07433900019382 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark45(-550.1497609451908,-198.5143836234985,91.66433016122997 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark45(-550.3732097985918,-214.45689459717403,58.951083225897804 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark45(-550.443469731474,-203.54999039207127,23.86294885860842 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark45(-550.5384437413949,-211.61858054561793,97.94842952375913 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark45(-550.5445774328509,-214.08771789413373,5.40474292218984 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark45(-551.4535876043077,-205.03598822323562,14.88208467858854 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark45(-551.589846827572,-244.13204310607497,13.827458018861208 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark45(-551.659252862219,-214.63754094255987,45.67201253284759 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark45(-551.9685216051357,-196.77492581730485,1.9370683671061215 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark45(-552.3432084442926,-218.15480933142103,50.13163868856313 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark45(-552.4329225576433,-243.0885768552675,10.944909542439976 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark45(-552.549221412044,-201.86411427609306,40.31596932566248 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark45(-552.5627679761764,-222.03387305233866,40.424599991577 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark45(-552.5926685283897,-199.82610336235462,100.0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark45(-552.6118705800124,-195.47960369882477,4.299620614778107 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark45(-552.828167577592,-200.83965222529187,18.081808542488687 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark45(-552.9872469383831,-267.84624796286585,63.062760966004646 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark45(-553.0481831078646,-287.56020959923893,99.08525079436109 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark45(-553.3400935129667,-229.1704496065439,45.13716330095218 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark45(-553.5306844661649,-208.18106774451098,23.776022537073672 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark45(-553.6121562908621,-220.5731510881472,100.0 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark45(-553.7123772505324,-195.53918480834605,26.079515804687702 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark45(-553.8342172055877,-246.53546565209297,100.0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark45(-554.0010548983298,-301.15064962297186,63.52382518437514 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark45(-554.020060834496,-240.17346110743986,89.3959442887035 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark45(-554.2047549234377,-196.1522928775481,22.558430546763674 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark45(-554.23771567632,-242.7435321842486,54.87902293039092 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark45(-554.3510462844473,-199.6092861025896,73.52919863281613 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark45(-554.3578314722818,-195.9007665622915,45.17034823933875 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark45(-554.5739855126867,-196.4683930502605,100.0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark45(-554.7747176953069,-193.85786474419805,100.0 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark45(-554.9727969087056,-257.7169634136131,100.0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark45(-554.9890987859701,-272.6794617169068,83.58109202455864 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark45(-555.0080479459124,-203.37211662047486,68.19507315326624 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark45(-555.068282922686,-206.4715595100089,100.0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark45(-555.4326862605184,-260.5029508690431,61.08427942846322 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark45(-555.8001978599428,-329.63733553961293,16.70892845240685 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark45(-555.9643829312447,-200.46940796846354,77.66313924728877 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark45(-556.3946911439954,-193.21815139276143,34.77630233100541 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark45(-556.8608285563878,-232.58917364646643,42.95856926074333 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark45(-556.906242145029,-202.9977835003948,34.489972032468046 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark45(-557.1389084403833,-236.79374824483003,8.01902381364414 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark45(-557.2167612858196,-192.88233450981323,100.0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark45(-557.4573134070367,-210.17396541542394,42.244494543374856 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark45(-557.4745560508933,-207.9774996111609,100.0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark45(-557.7759086144318,-197.2449431340227,56.571069615476745 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark45(-557.7912321337723,-230.91147303217912,100.0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark45(-557.9705058525753,-222.53163926433098,100.0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark45(-558.214865363375,-231.57786667378852,4.238479541302681 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark45(-558.3715491605868,-242.93477594124926,82.33775608506457 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark45(-558.4857730057724,-214.07725454712718,11.821584184800528 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark45(-558.5618923698486,-193.82203498900697,21.273657922912065 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark45(-558.6556333265229,-199.72319152341024,53.72280333334578 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark45(-558.9070542529216,-197.29665600050552,83.8537289096522 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark45(-559.0702981771504,-187.2716757214031,30.229835969602618 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark45(-559.1439151068364,-188.3842245453652,77.15320393949347 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark45(-559.2232952785218,-197.36766691218344,50.23107178028641 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark45(-559.3437910252915,-198.83321246004934,8.589154490810188 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark45(-559.9065378500756,-191.7567258000214,4.630301655866859 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark45(-559.9278886878064,-192.4302885469724,59.494733379359275 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark45(-559.9900023965351,-186.76189184397333,63.560401627349734 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark45(-560.1231450720832,-234.20688280821423,40.56285808473396 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark45(-560.2566380853563,-203.49667542725044,96.97942934023146 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark45(-560.3679367325773,-190.49061757450465,46.08941103417666 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark45(-560.5606395693441,-201.70269734083908,21.359954054366497 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark45(-560.610768180316,-186.9381218988553,0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark45(-560.7073868642076,-197.02660475000437,6.358207863734734 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark45(-560.7079398527354,-224.05281038154206,46.89953801780368 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark45(-560.8215948586034,-197.76586297233132,17.07941639032684 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark45(-561.0118370395542,-207.00314915594691,46.74200312477123 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark45(-561.2874894386005,-198.76951163679908,100.0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark45(-561.443314744034,-239.18318011561985,37.36431887294293 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark45(-561.5289136096062,-192.9647385726335,71.46407591446041 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark45(-561.5596876143376,-193.61527119300294,76.81816579853779 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark45(-561.9190582531228,-208.22785371177582,12.204955306634858 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark45(-562.0727490036843,-221.56119426670105,52.181678644405025 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark45(-562.4063225231369,-189.96084722361485,11.292800819209162 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark45(-562.7053196108557,-215.96331980651235,10.118324804680853 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark45(-562.7860260090213,-183.6505768826492,89.51010454219337 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark45(-562.9225835353197,-214.33036223919413,35.45294907687952 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark45(-563.1818625516605,-195.6985533307266,100.0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark45(-563.3136643059731,-184.8914154118957,100.0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark45(-563.3539388805864,-187.8968075043827,42.855213866904734 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark45(-563.5196702746135,-182.58665587991973,83.85627464021528 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark45(-563.7218148260724,-216.51840462464432,53.83230655238688 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark45(-563.809007217329,-224.12435263072288,100.0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark45(-563.9472055827954,-188.01029356452983,100.0 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark45(-563.9796210862131,-224.11077000176715,100.0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark45(-564.3139278700207,-185.6697116344688,54.46118115719793 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark45(-564.353019912138,-255.13355935090686,7.946083470494941 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark45(-564.390002363139,-268.144365771073,97.91166501065368 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark45(-564.4978655170523,-183.50361161654493,100.0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark45(-564.5665471193774,-205.89076077609644,100.0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark45(-564.7496379983019,-220.24696803955825,74.10328809943738 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark45(-564.9162708530724,-208.32606466306504,98.72477241708012 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark45(-565.1536190464383,-196.7893786622289,44.23532957305963 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark45(-565.2121979133922,-210.06524803951547,62.758533368321444 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark45(-565.2487209322861,-223.4439341661545,65.11671695037086 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark45(-565.3417887226908,-191.61176243942987,100.0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark45(-565.5485443380529,-186.90863179080299,7.555220511873472 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark45(-565.7136557345333,-192.67649273975545,73.47250108410378 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark45(-566.0520909228569,-266.31177321182554,42.27598301646114 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark45(-566.1645116750835,-225.6479660444694,2.000520190675399 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark45(-566.3430185504336,-183.9005650854556,100.0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark45(-566.580708187916,-185.36610713191328,15.706674000989523 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark45(-567.2129788685204,-229.753796432096,12.104236556039723 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark45(-567.2576512431231,-199.3928110862412,93.63250365261945 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark45(-567.5488602323302,-197.19089437814674,100.0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark45(-567.6527195729985,-236.7804822007172,100.0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark45(-567.7522869237954,-186.35494696521803,100.0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark45(-568.0193460632909,-194.1032776167424,91.84909168239551 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark45(-568.0930446018957,-194.33087327204402,80.81293200430778 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark45(-568.2314748834548,-248.98482949727142,19.302161452445432 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark45(-568.2352509596227,-213.79628464796716,100.0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark45(-568.2632512411393,-181.35679560017795,48.7003518606484 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark45(-568.2981932020878,-241.98361377799773,23.221997629761404 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark45(-568.4765335997981,-241.53950600977174,100.0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark45(-568.5409237559866,-187.41596618996033,100.0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark45(-568.7030040401459,-198.68614094753173,49.75154220443105 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark45(-568.9705021401741,-215.7098364477058,24.441628529680415 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark45(-569.5569816063621,-258.03553821739195,1.6718320710558174 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark45(-569.6594380767466,-187.18911288991177,21.1524306145687 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark45(-569.7202525088782,-214.57459405803849,72.10464390519527 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark45(-569.8646104796604,-182.5865184374674,26.13338527586508 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark45(-569.8891228900254,-206.18521292622142,45.119005810129636 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark45(-569.9369102990022,-200.69127438349472,85.30728035954564 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark45(-570.0056773639319,-218.2033349252197,73.32398935271456 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark45(-570.0600804183944,-181.0409956109109,98.83165204386862 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark45(-570.1794686807945,-223.24023057919885,2.2416330827731485 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark45(-570.4002219625452,-189.1131205796631,47.20958388621909 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark45(-570.6035858990701,-251.6710566376861,66.44060614762469 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark45(-571.4145803186675,-195.45198573189367,7.9247540477269 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark45(-571.5171397925741,-195.7536176142835,81.611269948766 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark45(-571.6037050819327,-177.5946117116693,17.92920502126782 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark45(-571.8235985754692,-177.8402248459251,79.74391302599656 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark45(-571.9808473799841,-190.48213976853935,22.05259965903575 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark45(-572.0349059941408,-211.90548724400614,21.18043914215123 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark45(-572.1835990714287,-206.6954870560602,39.86216278859624 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark45(-572.306941348247,-200.56260676178192,98.90612114344069 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark45(-572.3611957953625,-273.6637365455196,75.42699132230095 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark45(-572.7717945816195,-173.50479771211354,40.18584207707414 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark45(-573.0058765826709,-174.21606743208127,100.0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark45(-573.0540927992932,-174.10350651260697,100.0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark45(-573.3159461941661,-184.70568824720624,73.21430792402307 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark45(-573.3673403531552,-177.85083811973612,78.56859768068617 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark45(-573.6870127941435,-189.57282054811827,71.1117113309225 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark45(-573.7166740055616,-252.5622434846094,74.90746200606071 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark45(-573.8224232400714,-220.68297098004425,40.632488088114 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark45(-573.8766875445992,-181.5611057978306,91.78160033097694 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark45(-573.9019374881411,-184.6841297676142,32.25588691261922 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark45(-574.0759220777279,-209.90065539297058,12.455693426468798 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark45(-574.2553361781843,-183.7249236941563,18.54365864235116 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark45(-574.3411857562647,-233.39943629583055,85.20306150538111 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark45(-574.4640978525255,-181.34620412658376,100.0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark45(-574.721002022009,-179.2162013376364,20.84305393281629 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark45(-574.7763502307038,-199.54145720798755,89.8016437214045 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark45(-574.8931945004872,-174.1748885269103,98.4263997841378 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark45(-574.936420316767,-267.28600859394146,19.16666497947554 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark45(-575.2369795239879,-226.66572571561662,94.7290115613265 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark45(-575.7275870661994,-197.88318773869182,100.0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark45(-576.3889585798718,-175.4073684205456,8.247472500123791 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark45(-576.4515106390731,-220.6916838161388,42.90919691320644 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark45(-576.7329331309559,-189.3021879907582,9.331385185978576 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark45(-576.8966389890693,-193.38720034714362,100.0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark45(-577.3391283883145,-187.29619347437068,81.91371901697343 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark45(-577.4104889222779,-173.70097578865992,17.589071654988686 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark45(-577.5088155656372,-198.99977999655414,54.75453970912628 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark45(-577.6120615053388,-306.94704777012106,76.65559098554883 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark45(-577.7507703986614,-190.47724796942757,100.0 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark45(-578.1564636912481,-204.9545873974575,79.13217770789089 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark45(-578.2193203439665,-189.97434240090942,100.0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark45(-578.4318875644178,-231.39191792051648,67.01042418595847 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark45(-578.5017636822726,-190.18801119870201,1.516784357206987 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark45(-578.577750868762,-192.93468216077363,15.086561461866111 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark45(-578.5995109352828,-176.3977109377799,0.1648282843127049 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark45(-578.6047706462227,-174.02165440587072,100.0 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark45(-578.7451831993412,-168.1033148918952,96.92519656343278 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark45(-578.8868690029113,-178.82264425381283,74.61097653332081 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark45(-579.3451210049212,-194.75689837656472,100.0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark45(-579.5367233588057,-181.9372679390987,92.33454084610551 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark45(-579.8520068989276,-193.81438492579022,70.85116988695782 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark45(-580.000759990093,-176.8931700571844,77.50848521470789 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark45(-580.2730808480011,-172.70670411669755,59.41671373023121 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark45(-580.5015618477618,-241.35835811359098,48.20565625078453 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark45(-580.5645978242547,-182.81780945873479,28.754298414194693 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark45(-580.5676129466134,-275.96930184728797,29.22373525580008 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark45(-580.5830875188209,-166.76897368835375,39.06248436872323 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark45(-580.6966858478289,-173.47361377325538,36.635758577183 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark45(-581.1261072161476,-166.20993806697115,100.0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark45(-581.2765630848072,-185.03663903348246,0.1549190458413534 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark45(-581.6431307726085,-190.8953206563271,70.58468902784568 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark45(-582.4447859303052,-168.65375440042158,38.030599635442 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark45(-582.810757625512,-172.4650493081523,42.34346235367792 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark45(-582.9038372698274,-195.45732487462817,98.52587566407294 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark45(-583.060178655343,-178.67076604742581,41.567019748844615 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark45(-583.0609987740079,-205.60170856256562,35.029356841534764 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark45(-583.0661072222916,-190.83983356505502,10.832038928150325 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark45(-583.1844592028153,-192.15726158328283,26.046826731316997 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark45(-583.3888615195937,-162.8345766905874,100.0 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark45(-583.4079315077752,-174.70048867718748,73.84708589817834 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark45(-583.8641795312154,-166.05163274070827,42.63357096314465 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark45(-583.9436912906724,-174.3913771276678,98.94725475652382 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark45(-584.8616508162247,-189.86767202832073,79.53341024127826 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark45(-585.0485731370784,-221.56532448409425,80.44235933869825 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark45(-585.2740792849712,-181.0199250980389,93.17900458701695 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark45(-585.2795450619967,-177.3070405891817,65.14534171178647 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark45(-585.324525769934,-192.04861985733254,36.98945023452356 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark45(-585.3739930968738,-192.45047380196846,42.2059521840919 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark45(-585.9501748920572,-201.32022047720432,13.657221470140584 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark45(-586.0230894194056,-171.7284634733594,58.621744005393424 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark45(-586.1224927682492,-180.75333440899465,50.684667036272174 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark45(-586.3431614586422,-169.1924689712015,97.70131689620706 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark45(-587.0208857890059,-188.53410484285058,88.16537217864527 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark45(-587.152623525896,-173.59807518565842,37.30478418503722 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark45(-587.3174408221774,-198.18872959880088,66.28152775390288 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark45(-587.4863395373396,-297.51679923741375,49.62424031571791 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark45(-587.885233800561,-180.21706526653182,32.36110108994592 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark45(-587.9237077172149,-164.41521156256505,5.903241430363555 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark45(-588.0622607477075,-173.38824530699023,83.11394166211878 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark45(-588.4850457803839,-166.65161658087573,100.0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark45(-588.7637432026419,-220.9839813403537,8.739807713193898 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark45(-588.8676987812755,-199.2083665138968,92.32545854251345 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark45(-589.7411491777063,-174.8301270216135,100.0 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark45(-590.0754128729498,-177.46880107632427,100.0 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark45(-590.0813925035185,-200.64093624628674,40.03837547022596 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark45(-590.3273995014692,-169.1671518912082,62.930322741155805 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark45(-590.5551495084848,-185.0554989907416,36.18544333349993 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark45(-590.5765117586627,-188.0986278092604,78.95300859713794 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark45(-590.8035412930535,-212.75526265102278,28.431942146081923 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark45(-591.1727048303051,-204.45562189803292,39.468768632383984 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark45(-591.2445116770342,-179.2502720608461,35.65628180998425 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark45(-592.1506095075023,-185.6824541724842,99.19373771656802 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark45(-592.5249756643079,-169.37041472895584,94.53522608294608 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark45(-592.5668446118758,-155.53121714540967,91.33633763949783 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark45(-592.7192658457138,-164.73463175848806,100.0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark45(-592.8986833184904,-155.08289449480822,58.18158536674741 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark45(-593.4032040840431,-173.5353295674187,54.002091935998834 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark45(-593.8699101310814,-190.78448453162179,31.582229972991883 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark45(-593.9116926337188,-228.978542597344,12.924278262209299 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark45(-594.009611869553,-162.77493398403521,87.9342903411744 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark45(-594.7198448091676,-152.06186663531267,12.81244530604593 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark45(-595.3893356980273,-231.83933184588875,44.896395491342616 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark45(-595.4530198613471,-159.2976457118786,8.673874687293022 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark45(-595.506856639294,-166.23587484709668,6.381172383035462 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark45(-595.5725443633432,-175.52081293526297,78.52530447217347 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark45(-596.0890943318254,-157.34654396902457,94.77682182713488 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark45(-596.612176054554,-151.10526542649137,84.7120153534365 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark45(-597.014723675002,-235.08321677598417,63.54645527803649 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark45(-597.0336426098255,-190.44979033106551,100.0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark45(-597.1764860175866,-189.5622998176662,7.804574728154883 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark45(-597.1901144157247,-166.501659002709,33.66426054573114 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark45(-597.3371866607051,-148.82704052879447,49.0940754946827 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark45(-597.7046012081731,-148.45041155028758,41.29324062250123 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark45(-597.977677995874,-157.71045283357367,100.0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark45(-597.9833971936109,-168.9463613467653,42.335562024439014 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark45(-597.9876741842113,-167.88504099975077,39.726246664121675 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark45(-597.9942319016557,-148.6993089091984,1.596054898822885 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark45(-598.5731770873494,-161.45928474480084,27.13102543315864 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark45(-598.8132923744495,-172.80340312277787,10.915437186088923 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark45(-598.8831715133367,-201.96434101656595,79.09859594699918 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark45(-598.9900102740863,-210.200510199136,29.862985723018483 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark45(-599.1585016288078,-168.24903268204017,9.119960455459449 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark45(-599.3070516844831,-175.82816926109297,23.283639434080314 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark45(-600.0169137583634,-190.88169043576863,15.421689403319633 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark45(-600.2832414778098,-146.0210555451631,49.33842569969832 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark45(-600.6643890531208,-186.48930528415983,89.14886096792515 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark45(-600.7014914172915,-148.23692114218684,34.136297417668146 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark45(-601.4020107348538,-162.8896989310084,91.38414848234001 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark45(-601.6097103206628,-240.94153941291296,14.136585216228895 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark45(-602.0493602794193,-203.6150456157832,27.264355025226777 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark45(-602.2997142000854,-144.5959175641401,49.63253651114039 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark45(-602.5526677057994,-167.67427307412274,54.041049578801704 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark45(-602.6061913940596,-176.21106083925216,76.43295362884274 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark45(-602.7702996964218,-161.6144623890438,28.692292271561143 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark45(-602.9434266505959,-198.50209111288962,100.0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark45(-603.2251437780369,-173.32817785002555,44.92805110878595 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark45(-603.2349300482512,-157.26099974235066,87.5898992928534 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark45(-603.3712389581146,-220.88533179596374,76.2904413856266 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark45(-603.4856835035133,-169.53026302078152,86.00562237681353 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark45(-603.9438898279658,-144.55053086560423,19.120596074929196 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark45(-604.0243990379904,-152.96958467802278,76.25401748121462 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark45(-604.0379772165485,-211.10114569859056,11.052084169160437 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark45(-604.2396904432564,-144.69344443762807,16.267719887157256 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark45(-604.2910784179907,-144.24308025792882,47.75762205932952 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark45(-604.3951408188279,-147.42286564503274,58.92301314169771 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark45(-604.4029944328297,-144.15046651595958,41.477685072077946 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark45(-604.6983416152558,-199.73373777436944,100.0 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark45(-604.9107681661382,-173.43322331392997,80.26490899979783 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark45(-605.1854151578101,-227.99841604565964,66.74001370455647 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark45(-605.2234793488434,-159.43006943791397,99.6348212783324 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark45(-605.2476309339885,-145.6225246243396,29.238019031526733 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark45(-605.3507562288669,-204.56831168058812,90.05424136065429 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark45(-605.5539106575004,-159.66077055370278,1.2778816598263916 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark45(-605.6383975628818,-162.24063782237243,34.26959294457538 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark45(-605.6910006419049,-172.438426860236,22.716697830457107 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark45(-606.4274443595692,-147.48599598760757,73.29987999911617 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark45(-606.4493565565587,-159.4000742489406,84.23393423096022 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark45(-607.0190583221454,-157.96676588844076,100.0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark45(-607.2462497786448,-237.0476453857355,33.631839050346144 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark45(-607.4009894414686,-163.1750813103341,52.39270159046072 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark45(-607.9729491208494,-171.39594004840706,56.99547874214582 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark45(-608.2379967359972,-171.23557569113404,38.88676478579626 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark45(-608.3462295091784,-155.51652652953655,82.59376120988935 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark45(-608.44393348365,-153.71060177087554,11.92199159976171 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark45(-608.5247630787867,-166.0185091745971,20.051421987759582 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark45(-608.5446762051872,-250.18148798312345,100.0 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark45(-608.6385813521723,-217.82992640856378,21.976166686737784 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark45(-608.9766000878266,-163.20362751196893,75.29911423817651 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark45(-608.9920175443515,-249.49756381114895,100.0 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark45(-609.113339069428,-165.53798936416084,48.77070839651407 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark45(-609.1518705483581,-202.48499391218158,16.17078840967639 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark45(-609.2049840342164,-140.67910276246778,73.78728861682873 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark45(-609.3702112679567,-210.57335385633695,92.03934017727008 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark45(-609.4855082124146,-142.86842720695776,100.0 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark45(-609.7565215910912,-155.55538562359203,100.0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark45(-610.0665436161985,-201.68144814984797,7.991095605717533 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark45(-610.0850113204757,-166.83957055381367,50.78624132335793 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark45(-610.1744930910988,-151.00773039265812,100.0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark45(-610.2701592657129,-163.30108085624005,96.38242681679301 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark45(-610.3470866953859,-139.11587194095475,100.0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark45(-610.4812813800175,-159.63181028159548,34.28893164915553 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark45(-610.6389726848057,-166.8162039406898,100.0 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark45(-611.1046123953672,-152.7302949935465,8.296877938254482 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark45(-611.6149756663846,-135.92578088315858,0.726799655657544 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark45(-612.4150146986985,-135.43968769412498,92.19425545232846 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark45(-612.4379041850879,-196.9008829669714,100.0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark45(-612.5207530723884,-153.96946950576313,100.0 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark45(-612.5950855704618,-138.8152364171258,83.37916873773034 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark45(-612.7097501072193,-147.51466350335477,10.184097233118507 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark45(-612.9594732419204,-134.143037566848,53.123673443028764 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark45(-613.4878421694017,-135.2187118790422,21.620147122249335 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark45(-613.7943734602939,-175.83466251656156,100.0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark45(-613.9961709110801,-204.62075373694955,97.99421687061303 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark45(-614.4988280646402,-138.1325237089494,69.51692582168977 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark45(-615.2074854250413,-164.16708043686853,63.70952118604268 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark45(-615.4134662591605,-166.6761229413642,78.92762790663352 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark45(-615.4185293138797,-155.06207474770943,76.52958976288494 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark45(-615.8421407496994,-180.640663463584,33.5701901010592 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark45(-615.9472663009631,-146.54825675238388,60.88296089090041 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark45(-616.0421230571087,-157.35688169190323,69.0769808822975 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark45(-616.154056379853,-140.20712194895415,77.53302889817311 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark45(-616.518252129893,-141.2125826679735,6.542256691263518 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark45(-616.8235395135359,-136.6286422227025,12.840510527092164 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark45(-617.1529046573415,-133.7964969157622,81.0495112504835 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark45(-617.4923380378356,-174.5221317711839,79.98778471374976 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark45(-618.1568330866871,-168.55199645297074,87.97317390107631 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark45(-618.3058293849816,-206.0373996930357,40.99529846077954 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark45(-618.8893346641146,-127.70365460486819,8.141342012746208 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark45(-619.1977507754094,-131.85512381826024,36.28410791895524 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark45(-619.7486339623462,-126.47672368056085,59.65947160708856 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark45(-619.7617703731468,-134.4579923519057,81.9500821928035 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark45(-619.7856693281792,-165.0582265257804,6.405429916699845 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark45(-620.2134079822373,-144.75280572008705,26.700435877453405 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark45(-620.7179966931075,-125.64782926841869,29.452239345632222 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark45(-620.7902180257131,-190.13061574042612,100.0 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark45(-620.8460416101867,-155.87683388487636,45.00120939472495 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark45(-621.1014273966265,-126.6650656810293,61.40766150069848 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark45(-621.2021081591389,-129.90164228757789,23.891701075814026 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark45(-621.2911388161122,-172.19136667292935,65.22748684784446 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark45(-621.3217618159887,-172.91410251179911,44.26462036707724 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark45(-621.4751942910339,-201.4775358517127,9.239103754220437 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark45(-621.745772434414,-155.938169102687,23.895784726831423 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark45(-621.9209709799072,-132.4460059233428,19.35617174769763 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark45(-622.0782905857307,-132.65283883764405,78.64987768455075 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark45(-622.1922696335756,-135.41256361270626,100.0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark45(-622.9319967055332,-174.77562586239128,34.96499092087339 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark45(-623.0415255274704,-139.1242861281352,15.453314271887052 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark45(-624.7434308254178,-141.52030908593824,100.0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark45(-625.0121234801236,-132.58050808582954,77.28880955225355 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark45(-625.1266075442646,-144.66483351838957,43.67830116153479 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark45(-625.6978503205752,-139.86497411270076,26.634596414444218 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark45(-626.625196425031,-132.85407858683783,39.752817278580125 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark45(-626.8350233132686,-163.37859110404617,6.9964651674150815 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark45(-627.1103687796592,-127.249339341495,75.75771468638433 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark45(-627.1480766048987,-130.40674669177494,12.327868903706161 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark45(-627.2291660925654,-124.8276545582783,88.99961533642104 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark45(-627.4802300935348,-132.7556730815464,100.0 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark45(-627.9078711522817,-130.87551341255556,100.0 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark45(-628.0814860887265,-170.23975184438999,92.2340380746144 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark45(-628.1715511840455,-144.00031211476318,28.688138260544605 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark45(-628.5342983910931,-151.17876231449884,33.013904160852775 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark45(-62.86735968896864,62.86735968896864,0 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark45(-629.202396999683,-198.226498212627,8.027306042721278 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark45(-629.2098230995166,-185.32641048182205,30.384948187069114 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark45(-629.4201622195322,-124.47991453190468,27.56859538190435 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark45(-630.0221729782244,-152.533690688526,33.19749550050594 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark45(-630.2022830319291,-165.5532546520903,100.0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark45(-630.3511561287017,-117.38477705202719,19.404481307159543 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark45(-630.442847223016,-157.8696965870684,27.00198769960744 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark45(-631.2186374929229,-198.42399907662784,2.1852879506838008 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark45(-631.3701797087,-159.5268402509543,87.53695751589026 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark45(-632.1061053483726,-154.95487249905645,100.0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark45(-632.5414199946373,-158.35023887625692,12.90805089144662 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark45(-633.6880252587898,-158.88593599999356,84.95636720537937 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark45(-634.4072474461559,-206.29542963161873,18.96411205847113 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark45(-634.5028508368416,-146.51430116422395,84.50048275729449 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark45(-634.5179612351992,-114.7261639427736,100.0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark45(-634.6252178056044,-122.85822688563923,49.70616324963635 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark45(-634.678424223136,-179.89152128777994,7.105427357601002E-15 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark45(-635.0868485596542,-180.97043032747996,96.74953996619274 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark45(-635.1852749232706,-195.59355098422654,26.105030809202617 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark45(-635.2965966472165,-120.58509607277287,74.8772220072304 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark45(-635.7544439996522,-171.95264692341271,100.0 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark45(-635.8743701155838,-187.46223595313933,100.0 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark45(-636.0943380014747,-142.51916384203392,79.23328169123272 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark45(-636.7179736908811,-125.80447724583232,45.80417766504459 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark45(-636.7297137465339,-127.67703234779123,46.54934111267107 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark45(-637.3499561823585,-143.8226385955612,62.39447464946065 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark45(-638.7677479463732,-117.45829602425005,34.012655867101145 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark45(-63.90715154671162,-703.2475274812208,3.6210772557652575 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark45(-639.0906211120777,-119.70869919685316,21.473965621033585 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark45(-639.1804171634161,-124.17348238917998,15.8457778055364 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark45(-639.2041489498321,-125.38318408737172,58.50022066318036 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark45(-639.2842012997892,-138.5492000765586,1.6236710303451076 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark45(-640.2452919458109,-119.27134920914249,65.7818902864444 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark45(-640.3331648788862,-146.73334291180473,9.392378715504307 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark45(-640.355744625997,-177.97926630811975,15.012316034326005 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark45(-640.3792402324183,-113.18549694035669,68.44481795646303 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark45(-640.69419877048,-135.7678422315451,30.190653037682324 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark45(-640.8554902636697,-125.68156021764656,50.48419313269426 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark45(-640.9910007621829,-125.23448998783039,70.1715169881054 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark45(-641.1160945547819,-110.73611786404538,38.98658605950234 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark45(-641.4799575268099,-149.08175107929225,94.13651565791426 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark45(-641.5808355730323,-125.6369405602043,3.336759154703344 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark45(-642.3230311356517,-149.63532798889247,65.40293488459054 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark45(-642.8242984196945,-166.75235204419715,100.0 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark45(-643.335969849183,-151.7732030448646,0 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark45(-643.3424242086517,-163.93376605839717,56.18932265614666 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark45(-643.7986262878778,-139.88135450112784,11.57673488743518 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark45(-644.6880536046594,-143.8377006545825,89.1977560517189 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark45(-646.0,-100.0,0 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark45(-646.2428794202267,-120.63937893173448,10.237776204072428 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark45(-646.3662251083753,-100.0,100.0 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark45(-646.3903413744393,-124.43501636285639,57.63647275477254 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark45(-646.6745182784127,-172.045351208024,80.5788137903723 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark45(-646.7306309969089,-100.0,100.0 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark45(-647.4658149426486,-139.76566773273595,25.618353008082522 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark45(-647.5008977846655,-165.76226984067952,69.36667810964684 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark45(-647.5044442365643,-135.90920351334165,19.240092481237127 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark45(-647.7659199248362,-100.0,98.24396501331586 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark45(-648.0614955197536,-100.0,100.0 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark45(-648.7535640339872,-112.6245501528877,14.946284552053996 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark45(-648.941649341646,-146.66171094810804,33.765304316183745 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark45(-648.9852206937594,-124.6609808526562,99.79390237221037 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark45(-649.9332707303377,-221.36305268929365,100.0 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark45(-650.003248466349,-100.0,82.08204146862215 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark45(-650.1883323272522,-116.80601568432498,100.0 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark45(-650.2001458935357,-99.9006133925063,67.76961300713106 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark45(-650.4452008110973,-100.0,88.95866017332636 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark45(-650.9789906611908,-124.3668839875143,49.60943266509983 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark45(-651.0580967541769,-100.0,100.0 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark45(-651.3643439409066,-95.67408623742398,34.84973729402151 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark45(65.14352713281406,68.64613931143523,-29.740260919996928 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark45(-651.608323317516,-101.8102918781675,48.51497380222992 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark45(-652.0491936560269,-133.76824430542285,50.89625102134491 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark45(-652.8072535680748,-172.3411510950967,42.60142209038986 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark45(-652.9784159942155,-100.0,53.954485177837654 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark45(-653.1207970884564,-100.0,100.0 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark45(-653.2630505405817,-100.0,39.8980068556115 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark45(-654.3715868184858,-158.18293752728397,25.83157656249122 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark45(-654.4083698057563,-125.62599398637792,26.90033699818906 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark45(-655.3839657424982,-99.72387302356901,56.32569647374868 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark45(-655.9901544611548,-100.0,100.0 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark45(-656.3117395249157,-166.93277103623504,11.039200076342894 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark45(-658.0038842798539,-163.8087719617467,17.98457069772958 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark45(-658.5357307312332,-101.50849861796198,58.24260218317724 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark45(-658.6109629129306,-90.52768389156833,13.24423869558369 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark45(-659.2757413020396,-95.26323960900369,16.816610408367467 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark45(-659.5258243189634,-100.0,-100.0 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark45(-660.3706616019925,-100.0,100.0 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark45(-660.4348642775433,-100.0,70.94171353243755 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark45(-660.4484159401311,-156.50532231726953,48.05135446418714 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark45(-660.8694370547169,-156.81079439487135,54.39057402213032 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark45(-661.4398336559615,-92.78073194687416,91.56149019047427 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark45(-662.295230516705,-101.18432789438751,3.308909926687022 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark45(-662.4997547640737,-113.76162813333634,100.0 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark45(-662.8633344572404,-100.0,96.90432552432654 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark45(-663.2828751068538,-100.0,60.704774841626886 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark45(-663.7543478882386,-117.28493618034298,60.23800249984265 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark45(-664.5737035529215,-100.0,100.0 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark45(-665.5425101270172,-96.79417136311699,0.005953174123973781 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark45(-665.9530133854824,-84.53298938821783,99.59763576984534 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark45(-665.9534501868848,-100.0,100.0 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark45(-666.1782779600312,-100.0,84.55550798969615 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark45(-666.2148766258242,-84.01767070873404,54.75455335338397 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark45(-666.3266064298713,-100.0,100.0 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark45(-667.8756454051775,-100.0,59.59141969498128 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark45(-668.4630848865163,-100.0,84.44549128841828 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark45(-668.8941479601414,-110.51136671500984,70.95175294844148 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark45(-669.0429613662657,-121.80718045474362,79.59748073865316 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark45(-669.4451389877751,-77.872666627829,17.140020491065215 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark45(-670.588941513678,-100.0,100.0 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark45(-670.8232496794286,-116.42745025815773,100.0 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark45(-671.2763370945106,-100.91336516492332,42.0684768610939 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark45(-67.18250503577096,-705.8421256649784,92.49149048915726 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark45(-671.964922802034,-108.39496348704179,28.947665218771846 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark45(-672.2935414781294,-100.0,100.0 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark45(-673.6345625941145,-100.0,100.0 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark45(-674.066109196461,-98.78353797663442,100.0 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark45(-674.1103916251627,-100.0,100.0 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark45(-674.7707803340924,-124.93207393849984,100.0 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark45(-675.3209073555655,-133.64107542332636,100.0 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark45(-676.0626136725698,-100.0,100.0 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark45(-676.1150161765959,-71.79603168881918,66.05545719312789 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark45(-677.1756885696022,-155.3300840898093,0.885658670650983 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark45(-677.6789589402805,-91.74772699387145,46.42155061654853 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark45(-678.6709827819266,-139.90623038139955,0.08554118368678942 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark45(-678.7220723611949,-142.49322981390847,98.04287798152859 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark45(-678.725988968518,-75.34329218241577,60.15122864761926 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark45(-679.9942322307314,-85.25456132326508,37.59745098267601 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark45(-680.6172503660557,-93.11942737790986,82.93046653052807 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark45(-680.7974101196281,-100.0,100.0 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark45(-680.9141818611694,-109.21140935493567,100.0 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark45(-681.394538520955,-165.12610289037278,80.97495133532416 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark45(-681.7825179477154,-100.0,27.22486635454122 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark45(-682.5411207788575,-131.29462884570074,64.34287082489004 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark45(-683.3010570813144,-81.64569862490151,13.222572859638262 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark45(-685.4861006852994,-77.20875018345039,11.355112390764106 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark45(-68.64509539691693,-686.4414341938738,84.2667416094807 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark45(-689.5042084856336,-123.46399124580141,43.858185015274444 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark45(-691.0187453233661,-100.0,75.98607130088729 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark45(-692.9598924383182,-55.89393733646311,38.49436673278578 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark45(-69.31654725642684,-679.7709193569124,92.82267442763842 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark45(-694.4127808207511,-87.9385939000425,57.906422832143676 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark45(-69.50218993771536,-696.5610721605464,11.076448223365333 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark45(-696.3184602629676,-103.77435060532167,79.02869258317838 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark45(-696.4060491558705,-94.10839299281524,99.06727001606475 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark45(-698.3279350531133,-60.50642792789538,92.49083871911017 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark45(-698.9399609206537,-49.24744766400924,36.387607222043016 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark45(-701.2123170851141,-65.09232793102632,98.3968649724572 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark45(-702.023508897412,-87.54273041168996,44.70611176614193 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark45(-702.5333585892646,-60.76336641472923,68.61387641179039 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark45(-70.4611716683872,-678.2601626462424,85.50184560867024 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark45(-705.6311085788707,-57.678754171277966,31.411608969493187 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark45(-705.8491712425764,-76.1486385989059,9.186821017591384 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark45(-706.7116718471198,-118.07500640427284,57.88225515758751 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark45(-707.8153373126601,-77.10693637792616,9.027226363422372 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark45(-710.8829659238957,-69.98410849749806,67.15127066887786 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark45(-711.3467902772883,-102.71123166823963,84.06974392150462 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark45(-711.5450932779239,-53.32510677206581,55.31021146241139 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark45(-713.7787009662928,-44.912864699632514,3.4556919616959334 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark45(-713.8741182020112,-89.65953094410538,11.792295587134305 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark45(-719.0520683645203,-40.74591084873931,37.738053613175225 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark45(-719.1891210134859,-71.58619476748089,24.855036367035098 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark45(71.92250204695137,-90.39695727381387,0 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark45(-720.2631427446638,-63.5831034643771,28.94443544962087 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark45(-722.1231776389337,-114.67266071830899,3.9453266847784647 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark45(-723.4429873945528,-68.01818436560539,69.91138195703545 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark45(-72.92291465426214,-678.4446403715685,0 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark45(-734.3419426973546,-47.18961794897238,64.14610422963528 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark45(-735.4533050080435,-71.52827995454473,69.69375750436691 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark45(-73.79707878717258,-687.7716298580146,53.81954748086355 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark45(-738.6274448356772,-32.31101801830023,58.74196562365407 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark45(-74.58374341344688,-693.0407776654808,87.9179062188555 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark45(-745.91637017481,-10.44176303477336,22.413546351975185 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark45(-746.1587162775546,-34.07750639611294,96.5102320367786 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark45(-76.10379996921779,-699.983007562125,77.9143622450151 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark45(-76.89020663487733,-685.2089743357622,28.29404155960853 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark45(-80.98427345108388,-686.9504420603566,29.471769164838634 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark45(-82.17202786028821,-706.2660788683578,50.380135168480365 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark45(-83.21055643886174,-666.6571503424433,86.5195682537387 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark45(-84.81555376750312,-681.8561464104313,7.045207634209277 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark45(-85.64770642774312,-672.7515660084875,52.552439887104725 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark45(-86.54752541007815,-662.6689117087989,35.70137614594046 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark45(-87.48823075681564,-717.9622270275496,58.899321732896794 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark45(-87.60061857075956,-663.0804154905811,5.630404796513957 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark45(-87.68461383391727,-678.9241151574963,54.45774588014023 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark45(-87.87895318994154,-664.4999853528898,19.70198996966981 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark45(-88.39069515986486,-699.3976662378032,86.70976287870192 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark45(-90.30685497621639,-700.7825858527723,65.36738469527532 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark45(-91.13674205542593,-660.9425720787464,80.04713112389962 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark45(-93.47822179534907,-671.3220513173536,68.17801171347608 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark45(-9.3513095130984,-740.9262163447636,13.146585952946026 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark45(-93.56136011820524,-656.0428418771525,72.75175443155982 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark45(-94.76922977195485,-697.1423711363275,37.06158877357228 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark45(-94.92100520883474,-660.2968165889667,22.330692860988435 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark45(-96.0376389185544,-717.3682220959857,75.97642700937988 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark45(-96.5253604052773,-680.4067923617911,47.10332405273675 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark45(-96.57894473491527,-665.1679389378427,70.28030956448319 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark45(-97.09095403443368,-673.6238704319318,47.74361236762752 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark45(-97.98505077067433,-654.4280590262655,100.0 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark45(-98.38502396939364,-647.7909760567652,9.093233585789278 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark45(-99.29415373899677,-662.5270254393898,66.98264433748017 ) ;
  }

  @Test
  public void test4232() {
//    sym_v1null;
  }

  @Test
  public void test4233() {
//    sym_v2_( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test4234() {
//    sym_v2( doubleToRawLongBits (x_4_SYMREAL) & CONST_0);
  }

  @Test
  public void test4235() {
//    sym_v2_( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test4236() {
//    sym_v2( doubleToRawLongBits (z_6_SYMREAL) & CONST_0);
  }

  @Test
  public void test4237() {
//    	UnSolved;
  }
}
