import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(0.0,-67.70881210219844 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(0.25841233241161987,3.8697843507407015E-4 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(0.5201850757534378,1.9223927148459552E-4 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-100.0,-1.0E-6 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-1.0057332563030772E-6,-99.42994265456113 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(10.819117105745434,9.24289837911374E-6 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark82(1.0856236505318861E-6,92.1129527263029 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark82(1.102787087647883E-6,90.67933522262074 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark82(11.705743220972536,8.542815105094803E-6 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark82(-1.2069699621828107,-8.285210331096354E-5 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark82(124.35063411328491,8.041776442321862E-7 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark82(1.2743411853533004E-6,78.47192035332033 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark82(13.117901671484077,7.623170420417294E-6 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark82(1.31822684784749E-7,758.6038000100657 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark82(1.3404949125229175E-7,745.9871374503882 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark82(1.3443637980614653E-6,74.384627244647 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark82(-1.3692015863065939E-5,-7.303526449289976 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark82(1.401679984430426E-7,713.42960648959 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark82(1.4094958997074766E-7,709.4734205103236 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark82(-14.12186425908996,-7.0812180434920435E-6 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark82(-16.424832285272718,-6.0883422285940014E-6 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark82(1.9910973668780048,5.022356096869222E-5 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark82(-2.3314075702564697E-7,-710.0400303394663 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark82(-23.601055959401336,0.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark82(2.388821616250425E-4,0.41861643966937717 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark82(-2.465190328815662E-32,23.146327741353772 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark82(-2.503665164425243,-3.994144321729085E-5 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark82(-2.5205593917332347E-6,-39.6737328741398 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark82(2.564399285231476,3.8995487393833634E-5 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark82(2.6630512983381484E-6,37.55091013920913 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark82(2.715421610233193E-6,36.82669373446294 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark82(-277.06035142383223,-3.609321921444941E-7 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark82(-2.860659044854062,6.647235822302222E-22 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark82(3.001138306182034E-7,333.2069028404144 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark82(-3.3532900762800466E-6,-29.8214582470403 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark82(-3.482973643557699,-2.871109879265532E-5 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark82(35.48157709984463,22.60640569205465 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark82(3.552713678800501E-15,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark82(3.6108703778126028E-6,27.69415413466554 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark82(3.8572947849147E-6,25.9249047781064 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark82(-4.109558037295102,-2.433351691166763E-5 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark82(4.1885549402296114E-5,0.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark82(4.2970546115489845E-7,232.71754501614865 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark82(46.25193939202197,2.1620715004493213E-6 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark82(4.713454303646799,2.121586283813763E-5 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark82(4.785712055872708E-6,20.895532124062214 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark82(-4.788207961834625E-7,-208.84640098565083 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark82(-4.807970842287034,-2.079879501774026E-5 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark82(4.930380657631324E-32,-0.0018640925392734153 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark82(51.88206036643248,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark82(55.096393348463266,-81.6161204781913 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark82(-5.752649377781266E-7,-173.83294796294183 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark82(-5.80904925598702E-4,-0.17214520929898525 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark82(-5.903027349852082,-1.6940460220382647E-5 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark82(5.907009081163949,1.6929041180446802E-5 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark82(6.745520759388654,1.4824652325273746E-5 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark82(-67.70163556063429,-1.4770691900115021E-6 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark82(7.029092912360532,-2.3074412456187644E-22 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark82(709.4138161815948,1.40961449813055E-7 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark82(710.0004790140085,1.4084497539896398E-7 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark82(7.272946783484737E-7,137.49585000382007 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark82(-7.278404158661544E-5,-1.3739275508766116 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark82(745.9832395513672,1.3405126867691578E-7 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark82(-74.95701338842679,-1.3340979780210906E-6 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark82(-75.01430793388963,-1.3330790240573265E-6 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark82(750.7044913806704,1.3320823150906206E-7 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark82(-7.763164273261154,-1.2881345334392336E-5 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark82(-785.1736836884223,-1.273603561574306E-7 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark82(-7.888609052210118E-31,29.024119335557877 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark82(81.05675580243695,1.2337034588916218E-6 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark82(8.877506225799096E-5,1.126442465445848 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark82(-9.663332422471655,-1.0348396941139981E-5 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark82(-99.16425385838178,-1.0084278972422034E-6 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark82(9.999999997905725E-7,100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark82(-9.999999999999993E-7,-100.00000000000007 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark82(9.999999999999997E-7,100.00000000000003 ) ;
  }
}
