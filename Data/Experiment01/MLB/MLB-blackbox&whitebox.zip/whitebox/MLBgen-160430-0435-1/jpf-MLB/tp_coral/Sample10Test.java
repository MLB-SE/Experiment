import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(0,0.0,-0.5063149714353159 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-0.0020714863984694354,-72.98958771844995,3.140872859000757 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(0,0,0.271519814156008 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-0.8692265408492679 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark10(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark10(0,0,18.987006908065922 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-20.54198465432249 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-22.504963250004906 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-23.906748284421894 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2619.9196724175986 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-2630.2670588579886 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-46.19550122524119 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-53.65801621044422 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark10(0,0,5.486523311517374 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark10(0,0,55.521313372790814 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark10(0.0,7.094003283119587E-10,-0.9582955550154926 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-89.31334117856431 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-9.843002078677458 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark10(0,0,-99.33476270740866 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark10(0,100.0,-0.0018727003754828997 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark10(0,100.0,-1.5707963267948948 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark10(0,11.767322197630435,-1.401825897112957 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark10(0,16.244970344363075,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark10(-0.17312349761549228,0.2653909556718714,-1.1693176681581487 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark10(0,18.304806472461777,29.737426106447572 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark10(0,2.0668280381474773,-1.4665116199383537 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark10(0,2442.3800624144887,-0.9783522661479083 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark10(0,2525.572830026089,-1.5707963267948963 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark10(-0.2858759870294991,1.6716783063940548,-0.003159029229268251 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark10(0.33223562740124757,0.0250019396439134,-0.5128621119860881 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark10(-0.3354664538371528,0.08457078763453596,-0.8539591507692782 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark10(-0.37018114141257286,4.440892098500626E-16,-0.15505431163476913 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark10(0,45.13665505526059,-0.08342614746761379 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark10(-0.4706057241806718,0.168570779172698,-1.5707963267948948 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark10(0,4.818941485853756,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark10(0,5.914833584468269,-1.4710692252154702 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark10(0,-65.70634590860753,-1.3473368897595255 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark10(0,67.54715600431551,-0.023256907199181897 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark10(0,-69.24309992175164,89.88629967356113 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark10(0,80.95316203209855,-0.5060343969717125 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark10(0,84.70219911104495,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark10(-0.8735514581826749,0.5784184924388486,-1.0482084024636453 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark10(0,88.67210306565423,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,-0.3103725679530167,-4.761359393553187E-16 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,-1.4534626676223385E-10,7.060687723439677 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,2.3019595385420644E-7,-1.5704220013252599 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark10(100.0,6.125308438531964E-17,-1.5707859343885735 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark10(-100.0,-65.78971879435534,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark10(1.1091771335263019,1.0059621367375304,-0.5534081907286854 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark10(124.5456105776627,-3.0000185309313077,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark10(-1.252233483199916E-4,0.11327563221415342,-1.561632505243326 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark10(-1.2654762269010347,1.5843182134464282E-6,-1.5707963263172353 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark10(-1.2758009537404886E-203,100.0,-9.444718066089236E-13 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark10(-13.749067893742392,152.42204807145987,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark10(-1.4027578952513977,1.3248206152816049E-11,-0.44606550368712805 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,1.290722948593361,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,1.615514107633015,-0.23583664748710076 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark10(-1.4210854715202004E-14,97.47983156089501,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907933933782,2.25808030318575E-6,-0.004783033736004 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935257,1.5707907939855659,-1.0767923608801451E-9 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935257,99.99999999999999,-3.9821668214325856E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935328,22.355348368423876,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940935346,1.4210854715202004E-13,-1.1585682376876671 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907940936003,70.93210523033461,-2.3754700734669038E-11 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark10(-1.570790794093888,81.17645246844512,-1.1662520538737251E-10 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707907969363815,25.766895462781026,-1.5674251239161663E-6 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark10(-1.5707908752887771,0.8368513387820675,-8.075393940375946E-13 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark10(-1571.4292502180651,1.0206132500019125,-0.5731276606577254 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark10(-1.5728170756495796,1.571611374587721,-0.032294135719212136 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark10(-1.5739580991465019,0.06343033255987081,-1.5707963267948963 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark10(1.5777218104420236E-30,1.570791341441191,-8.106163764971699E-4 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark10(-1.5794318121729134,58.579937711750006,-0.0017861708373281236 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark10(-1.5903335159595855,0.9231225119470083,-0.17081335036217948 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark10(-1.6059446874138694,0.40069041134914585,-0.5534657355257702 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark10(-1.6091458180696843,0.2189993217147586,-1.5247989381037867 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark10(-1.660179326473022,0.4053020559652145,-1.2472010581714477 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark10(-1.7763568394002505E-15,24.107198033808615,-0.011240638223399742 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark10(-1.8207235547748652,0.5313876214778617,-1.50246585246677 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark10(-1.8490869419464537E-14,1.5707907940937673,-1.8395187070344346E-8 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark10(-19.433373814926533,0.19023003864940158,-0.6396150755210215 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark10(-2.1521744690971425,0.9973570434588486,-0.608874770915884 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark10(-2385.9659493999065,0.643549224711867,-0.04230736234673316 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark10(-24.279888894007858,1.0450344432327637E-5,-0.1251793037550802 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark10(24.38846595085812,0.0867285588230593,-1.3548013157600094 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark10(-2473.188690952959,68.18981827619177,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark10(-25.974012171224672,98.42497627055792,-6.225824002139031E-19 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark10(27.72254169964306,41.24738031313103,52.34518453358464 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark10(33.998588936236814,16.703387278331334,81.91746066253847 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark10(37.843656632230825,1.9045530013650897E-11,-0.25794642943845836 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark10(46.569968874148316,66.26795148182319,19.33557426402119 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark10(49.19345560585401,-12.547421869019828,3.949786865848097 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark10(-49.93844959845367,99.99995653458424,-1.6400328845389296E-6 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark10(-50.786647351698136,59.60333896425146,-9.794954938763766 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark10(-50.84536940502425,0.257531182912443,-1.5707963267948961 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark10(-53.684561924629605,-1.0464051274559076,-1.8666520469318013E-11 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark10(-59.24179422085116,0.4245003565258969,-0.3910759015671337 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark10(59.51314628952423,-73.45684039720459,-95.58966282281267 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark10(-61.04653585484513,7.782882240010451,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark10(62.344135116074675,2.206196529796072E-4,-1.5707963267948963 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark10(-6.379004768702443E-204,0.626725958528823,-2.6186420705649548E-8 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark10(66.57266617868605,4.164546865807544E-9,14.440014376775146 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark10(-7.428667458952987E-9,56.84712053692678,-3.1331875191054795E-7 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark10(-7.888609052210118E-31,27.418245158628938,-1.3615302694790956E-11 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark10(-8.178439138457077E-12,8.012078345502997E-13,-1.5707960066131073 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark10(-84.2555158462252,1.1434891302740233,-0.04081543496533808 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark10(-84.95458942260495,67.03483615886168,-4.163398349886771E-4 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark10(-90.22230696147508,0.224329103850061,-1.570796326189022 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark10(93.43000754886364,-52.021291879699035,81.0224498472507 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark10(-99.21497477415613,94.90577082035202,-39.38761930510384 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark10(-99.92410898657047,71.29013152364084,-1.3877787807814457E-17 ) ;
  }
}
