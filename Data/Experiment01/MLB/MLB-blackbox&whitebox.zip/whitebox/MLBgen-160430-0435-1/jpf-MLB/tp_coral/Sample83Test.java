import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(0.5780533278537334,0.33414565341722413 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(0.9999167718341414,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(0.999999994260118,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark83(0.999999999670042,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark83(0.9999999999999982,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark83(1.000000000000001,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark83(1.0000000032811631,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark83(10.000331595831515,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark83(-10.618680537008451,112.75637634643024 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark83(-1.5872187324571732,2.618634219355531 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark83(-17.460895220306554,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark83(46.915733988406174,-23.219037224306604 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark83(-4.816337038675884,23.19710247012117 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark83(-5.468820374360572,29.907996287021273 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark83(-59.9140553563698,-49.52260658723353 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark83(60.86541201439613,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark83(75.33012098131499,56.19885966254441 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark83(-7.849236527601893,61.610602085085844 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark83(8.134685420326099,66.17424869884104 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark83(8.49334514452454,-28.226722617905267 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark83(-88.45465736168494,0 ) ;
  }
}
