import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.007215849446031264,-111.28129682089582,33.18175437571975 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.013934275153876071,-4.311307401392916E-20,91.74472481512646 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.02348328257300114,-69.39848687594896,58.75089012526166 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.05324669182316377,6.329013199108428,-94.83945896307348 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(0,0.0,-0.05832898239898163,50.47143584219739,-0.031122481470630348 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.007866285496384684,-74.93647339402969,57.80976922225071 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.009654665249378289,-0.08034967619111953,19.5495041331418 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.01392683112168199,47.82537953173277,-72.46598137777953 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.019384471271524095,13.176793190349962,-0.119209302605225 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.02003878436349149,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.02371923889151624,-84.64720853244393,44.2291330327717 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.025209476866565467,-35.56358506225885,90.73254348786978 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.03662639927960046,10.21261613954917,-86.0976534787954 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.037308321945342726,50.06383584024513,-53.498713202644566 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.038870288691839075,38.587803292958725,-89.33641259459813 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05586903119296142,21.98986143042316,-100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.055869134442781646,0.3069797283841988,-8.574312943995049E-19 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.057674292749382794,238.397731875795,-94.61219138683686 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.059948993488076315,-0.020828131428429205,75.41705467879129 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.05995902247738401,-37.5303679873923,69.05911357257145 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark56(0.0037008104693576484,-35.80054670612432,-0.019906513837026782,0.3561693354274471,-31.902412116243237 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.7309878535604204,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.86317874844118,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9572240531200578,1335.8565759087994,-1141.0130973974703 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-0.9664603086402255,1248.1267501447542,-1148.1958410261277 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark56(0,0.10239451250432191,-0.005495012716669745,-81.64738406254618,0.019238783273100107 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,-21.931902175399934,69.60464439686086 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,29.888735907863364,-61.071035581935085 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,-35.98908266320218,23.528681193957908 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,-44.802505257026496,-11.497420121925472 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.1102230246251565E-16,-63.03636828383999,51.73831620308867 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.232595164407831E-32,-2.7516420536594796E-135,6.387689798944413E-33 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-1.3877787807814457E-17,-10.995861198557915,6.029743212292701 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-17.386154024716703,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark56(-0.017442322966606773,100.0,-1.1102230246251565E-16,23.925723364068027,-53.250241390063024 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-21.07517442961135,89.48331357127134,1.4954930503477755 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.220446049250313E-16,-35.81493242776142,72.01520323933605 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.220446049250313E-16,-91.64022869195765,50.44059435491312 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2239.996711892424,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark56(0.024191155364547967,-30.928519004082176,-0.01939500992362478,-64.81616783217484,7.629185106467851 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark56(0.02916161073842,-12.135178379927249,-9.017725511131367E-8,-3.8840100898055843,0.40442642796366246 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-29.168113209282453,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark56(0.03732868325163593,-37.57081625005557,-1.1102230246251565E-16,88.59505346447568,-67.5549498758796 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark56(0,0.4090894710050641,-0.06678825722207449,-26.353534072059237,27.413350836171492 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark56(0,0.4334708830847611,-1.1102230246251565E-16,-11.702920551930724,13.273716878725619 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-4.440892098500626E-16,-7.63453624602805E-15,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark56(-0.045174502924793636,-21.64116373924425,-0.043356396446148845,-9.80467617235653,8.184752951360819E-25 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark56(0,0.4718308364024024,-0.05780259711372131,-21.221934688249362,22.72193468824935 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark56(0,0,49.36514488513748,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-5.551115123125783E-17,68.6298336228534,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark56(0,0,58.569527322344385,-10.84691846822534,38.91636693014286 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark56(0.06381913536023529,-16.408664776953035,-0.03236709565267282,78.03250545188487,-6.582453833286465 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-65.20442025632244,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-76.23239102849755,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-7.747112062252498,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-81.98547665944255,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark56(0,0.8932160841036363,-0.043444424340132404,-10.434803648450622,8.864007321655727 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-952.6909220172482,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark56(0,0,-9.722472824859878,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0010187275316285854,-12.458755917380794,10.958755917380794 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0013261581327981276,0.4901828751978634,-3.204510818866993 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.001809410263822964,-49.1935219001742,47.6227255733793 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.0025555200655029142,-25.01012989743029,26.51012989743029 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0037271793427905153,-87.73555055118578,48.465622175827235 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.004198763967176389,-81.1636634005751,0.019353442919923275 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.004882882282836981,39.91725409654736,-39.91725409654736 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.005069654399968672,61.495564907114236,-62.936888092083315 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.005075842922611845,-56.780407360075394,33.7413155062531 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.005722927493705898,86.27671994418154,-86.20131151340001 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.006152639373121861,93.29772512375104,-94.86852145054593 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.006309871242057077,19.0733229230362,-79.9302793999685 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.007370614854490698,7.745621714315018,-7.745621714315017 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.007663625357435064,-100.0,98.50000000000001 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.00793676656799296,-12.730449924243173,89.70371939253421 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.00926467061114239,-29.285042349020472,-0.48929153328766845 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.009691908396886939,12.200983430097967,-12.200983430097963 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.009917169403705017,-60.082114641504454,23.725634529078505 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.01113610797797518,-98.49999999999979,100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.01128307724714556,-94.08342804290244,25.03918599072163 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.011511738712896593,-13.34170631477326,14.837657073582108 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.015385494925995686,68.66775466677035,-70.23855099356525 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.015583316544420779,69.65447311162615,-36.58237310500219 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.015752856278289748,-18.295470707924604,19.77671189781591 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.015973027904833875,-165.73445241386247,87.45002425818966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.016794510683518976,88.66546127715355,-93.45566849871251 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.017595488401488946,-0.002250132606016475,12.7206840095697 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.020778357952481286,8.588106029730191,-7.017309702935294 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02083536308911646,-28.92122673338834,27.350430406593443 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.021021676948998338,70.81203252337694,-70.85954907123437 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.024136085026990467,0.8166316590978226,-67.6065807835025 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02422381754412903,-71.61364109970073,87.34539807729494 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.02441302524808612,47.12603375660411,-48.62603375660411 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.024836857198183626,-51.409490715397084,88.06732764229548 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.02552187141255992,-99.6843320259887,98.24587739574066 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.025633085227601424,21.87587225537866,-20.30507592858376 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.02586612690205825,-12.275782864972257,0.1279589533370625 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.026601982613501718,1.7763568394002505E-15,-5.412966865542515 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.02737961729799946,0.06515324483985463,-24.109257039398152 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.027495199131450654,-82.04215072588394,0.01914621097688163 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.030348028256098725,8.41954027823941,-23.529865689918083 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.031368955312561175,-10.082710992098475,10.082785913207461 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.032229823596120394,-95.1084622283142,54.14878976673898 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03261501821919221,1.2109284315683153,0.3598682016441552 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03352395308564449,-42.97588859890389,44.54668492569879 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03474081203662582,-96.91019521718798,96.91019521718798 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03583594740395859,-105.88985997953581,60.332679343605946 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03666831024380099,5.665782544336025,-0.27724260761917024 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03669870552709678,15.405623261984843,-13.835972563006097 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.038779820217230136,-47.184546043890066,27.94048920737113 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03904306031418331,-0.097126224620232,16.172731236458354 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.039715226278573865,90.9895724112532,-90.9793285013706 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.03978263843050315,0.06910965057850774,-22.729044549436054 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.03985095265311497,-1.2998778862855083,1.299877886458084 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.04147464422027358,44.67071283915914,-49.312305492748926 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04149818681105749,-54.65723856706253,56.1723702757954 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04172318772358148,-19.882045489504215,63.72706505000244 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.0422802894077875,9.024732554194925,-10.524732554194925 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.042371053230225386,36.452258159407734,-75.8242604493052 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.043600479050605094,-7.086959371180975,8.586959371180974 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.043638845628698686,-51.640756552082316,31.241773883161528 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04367692464922663,100.0,-99.99999996004559 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.044295478858386986,-100.0,98.75416234862311 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.044459400285908154,-72.82521237761108,71.32521237761108 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04525717534901291,-97.25637181701579,54.04413172058247 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.04544733496598252,12.02264842661219,0.48110301368663777 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.04620189316190443,70.87076501977478,-37.467739242547225 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.046294766848481106,-7.792862434421095,6.292862434421095 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.048137139069616204,-4.417887113619448,0.3555537492011624 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.048758623062069295,63.62656625090881,-63.88531196448386 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05041119186186286,32.968602035033946,-0.047645220902169175 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.050589474764937,3.8034834911632287,-75.98931819693365 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.052169928569577396,0.7242444637992711,10.844911735173543 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05249115159229545,-34.12121726167673,26.267234880394398 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.053060877170990395,-76.21675003612019,33.87604553945288 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05339099978717508,-99.99962941313504,99.99962941279487 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.053884776290590394,-0.04176835815425268,37.60732756106586 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.054735367121034766,-24.469442200310766,38.15370258982256 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05525311896065671,-58.73807051686729,57.19089875295013 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05618242746068347,11.687177948640102,-13.187177948640102 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05642448854179814,-0.8648652331971256,-3.6330500793427514 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.056697964806179064,-100.0,99.31671580655518 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.05721118242052414,76.14434725403818,-112.18596911211043 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.057493464133994726,-73.3786595265005,57.28273699549939 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05871751939980813,66.41466109757279,-61.845005141262774 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.05936032605389363,-0.024617505831735942,63.80810215021407 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06001091067333019,32.27074136945925,-32.270736239958126 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06030284991879875,-61.41256957013762,59.91256957013762 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06063326472133737,-1.2478540891171863,1.2478540891171863 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06104145960588482,-96.67589326810906,70.04315203939072 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06114871940441775,-0.17203344581928123,9.13076128490152 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-0.06179214398032118,-49.88907609350594,51.45987242030077 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.14817988386064976,81.08108133886206,-0.014341035896203162 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.19078740133322963,-44.43133122827817,42.93133122827817 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-0.28756937451192804,-6.011491152038263,18.563717819257157 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-100.0,98.5 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-21.864691422074593,0.0718416874252803 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,-41.96072524084264,40.38992891404774 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,-4.578484140562356,4.57848414048817 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,50.8746765620405,-52.44547288883537 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.1102230246251565E-16,51.99558650549872,-22.064234016800434 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,-64.00459697478487,65.5283803112185 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,65.54205951916362,-65.54205951945247 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,9.348244912202532,0.00573672177195103 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.1102230246251565E-16,97.13193392194371,-98.63193392194371 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.2688933347900476E-7,-42.55805613553944,0.03690949421637597 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-1.3877787807814457E-17,77.41641081001819,-78.95967857649961 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.734723475976807E-18,-89.0426321017746,87.64016846007141 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-1.9439401060616023E-16,58.1828770530305,-1.7050949100086115 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-2.7755575615628914E-17,-22.187015483881936,23.687015483881936 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7755575615628914E-17,-27.71000458898849,26.21000458898849 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-2.7755575615628914E-17,64.12187261078438,-44.34094216102147 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-3.255827882591889E-11,-75.62743986567902,74.16406074849483 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-4.011757394406956E-5,98.5,-100.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-4.049356510947462E-4,6.36870242460719,-4.798208865090274 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-4.184694216630567E-16,-0.12381452263048202,12.686688874800707 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-4.440892098500626E-16,7.450790389657137,-6.381142528887945 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-4.634147338458811E-4,-100.0,82.41254728522291 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,32.349570985663995,-33.920367312458886 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,55.25179893908295,-55.236184145581966 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.551115123125783E-17,-8.590164112195374,7.019367785400479 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-5.666187400710232E-5,98.5,-100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-6.358229431238513E-12,31.46094560018988,-29.890149273394986 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark56(0,100.0,-7.725442619702719E-4,87.8998761920671,-87.98633550416032 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.0,-7.95679133641806E-16,-88.01469581129057,86.51469581129057 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.12192764753945,-0.6042584023741819,94.23526594885514,1.583254557962079 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.001814192424122,-0.01983277206945383,24.47007235693508,-0.9081345782339368 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.24944925464534,-0.017237235543561182,100.0,-99.30696692650093 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.67583700669405,-0.06094154821556262,53.92890170217215,-86.79447784044754 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark56(0,100.77178690452598,-1.1102230246251565E-16,50.97089175897696,-80.81629299801622 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark56(0,-100.88428962138978,-0.3533167767670614,-3.8467509185977784,14.833568994089642 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.041243189590677,-0.03780640611462183,-44.814974567715204,42.74940714211387 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark56(0,-105.51480991464531,-0.5458570054943075,-1.334182500809687,1.1293574001670996 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark56(0,10.56932902878443,-2.5852566714784175E-4,30.96040358153026,-100.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark56(0,-10.632382699422124,-1.0575744497454131E-4,45.04383301929,-100.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark56(0,10.823821894324098,82.30894469064535,-44.68352916727787,61.86522653742159 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark56(0,-10.829713215608994,-0.04572110219579705,60.22855551323294,-61.72855551340609 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark56(0,110.3298687117823,-1.1102230246251565E-16,1.5952918222656398,4.923658768272592 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark56(0.11212501738690145,-1.4825654303841067,-0.05435387099957825,20.514969465893987,-0.07656829952422478 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark56(0,114.94907379585153,-0.03067596862754196,83.86698327032101,-6.4982285589093 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark56(0,-11.588697668579282,-4.440892098500626E-16,-1.6633341725475301,0.944366052667033 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.1655546954820566,-1.1102230246251565E-16,-100.0,98.42920367320511 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark56(0,11.768961808361666,63.69738182037216,-12.668790397524404,-70.48585531195151 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark56(0,120.7699659442626,-7.392938951052421E-4,-2.1230695852419394,7.805084452833129 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark56(0,121.59079217382671,-4.440892098500626E-16,-7.394339590291727,625.8862420243962 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark56(0.12286847406926431,6.1168527754274855,-0.03014801527529827,3.1419729636205265,-15.061204060072313 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark56(0,12.34245684611015,-0.05398370604892039,34.00484611592137,-32.43404978912647 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark56(0,12.406807759181753,-0.04955921233119587,-51.48599015107461,51.48599010598814 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark56(0,-12.479127216362993,-1.1102230246251565E-16,31.019591757540752,-2.3418998483621003 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark56(0,-124.82715889525257,-0.048228598171830145,13.588994897492881,-15.088994897493006 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark56(0,12.578281194085669,-0.028408764796584357,7.227748699346125,-5.727748699346125 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark56(0,12.710394490693872,-0.058725227746376035,-10.44743970995515,0.09252727151476847 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark56(0,-12.910499107912642,-0.016868939717528716,-29.221777576715105,29.22177625414045 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark56(0,12.951731536290339,-0.014907841168586677,-73.59946258905332,62.639149993895295 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark56(0,13.00457716356451,-0.04606169324073704,-84.35446683360189,85.92526316039678 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark56(0,-130.8206990531494,-0.014263418799446995,22.268526531220058,-36.319420897979214 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.388706322442665,-0.0338117488341834,31.186158586045224,-29.398633055220458 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.70062814689297,-0.05986629556401757,98.5,-100.0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark56(0,-13.96420265011194,-0.033002305178367275,-37.497388208814186,7.8005151882605475 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark56(0,14.075411933341343,-0.0027129467931514273,45.536267498723156,-58.07271537512195 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.08194221598821,-0.0053230204103160705,-35.77291272714049,2.7863888819735814 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark56(-0.14104118807245233,100.0,-0.041013820461407044,-100.0,98.5 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.117799596090606,-0.049576983814067443,-1.3449785096883962,1.1678969704570357 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.4210854715202004E-14,-0.006040507128040856,-73.02142564156642,39.91791420562106 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark56(0,1.4210854715202004E-14,-0.03774786888887499,-29.626958957818836,100.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark56(0,14.340941331958998,-0.1874366377317071,-82.18350428004439,80.62342448681973 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark56(0,-14.358489818113187,-0.051438659454837096,-49.36095472937565,47.86095472937565 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark56(0,14.38655006481438,-0.06086460136301412,-9.253381232027676,10.824177558822573 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark56(0,14.549655827525068,-0.05954565302701237,40.64319838101213,-42.14319838093849 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark56(0,14.628533972868802,-0.026764625247442386,0.08572245319158167,-18.324211082530518 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark56(0,14.72764222261736,-0.055867231863740215,24.77782258448024,-23.207026257685346 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark56(0.1476557790777493,-16.313550863273715,-0.05129025959706343,0.0926133310700923,-16.96080152441543 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark56(0,-148.45785798297206,-0.053138227489142764,24.485706558728175,-51.82208570490889 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark56(0,14.880568763884199,82.94114775684224,-82.69415760708112,-67.56358527256927 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.012607706635649,-0.05567797819407371,-54.2868352419231,0.9174230719071527 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.186463814440957,-0.027158796038705718,49.11768507216294,-0.03198025974732129 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark56(0,15.274988610682009,-0.00956507456049796,-22.81302768059274,10.428503083444847 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark56(0,154.66027967393018,-0.025290599036167066,-1662.3801790952434,5.551115123125783E-17 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark56(0,15.588454991443507,-0.04913106636353056,-40.147033738346835,40.14703406881751 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark56(0,15.628075519670968,-0.018724989593691278,-0.49613281135691784,6.724478599580765 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark56(-0.15629044739195264,90.34485257627847,-0.045580574722412504,34.31455236515488,-35.81455236511798 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark56(0,15.67471744736457,-0.010205557879508595,-6.293275611514504,4.722479284719606 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark56(0,-157.51060991112044,-0.9999999999999996,-7.166952169449726,7.17581910556213 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.75402112301491,-0.014814539473116464,-24.436978671126777,24.436978648178822 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark56(0,15.852044718420434,-0.03467387516611486,-11.17169008419376,4.956909978178951 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark56(0,-15.9810790502492,-5.551115123125783E-17,-20.831445276108724,34.897815890467896 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark56(0,16.016565638660186,-0.0062292219763556145,23.428364681906054,-0.0670467763380872 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark56(0,164.85947233048802,-0.04939875603209909,11.00214349814135,-70.14738924332913 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark56(0,16.648458461092076,-0.02435275535521188,59.260498461181086,-60.71139318295995 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark56(0,16.883473262973954,-0.025641784982644023,1.636017441064256,-67.97997544336818 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.690969790931437,-0.007427592094866181,-2.684248001678582,4.067523288253227 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.70772723213119,-0.011563239781585506,-15.379897433392124,38.21853268425633 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark56(0,-17.833935967974696,-0.061248701173770626,-38.960904371064764,37.390108044269866 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark56(0,17.869564592676383,-1.2266485907920376E-27,-47.732170438591695,49.302966765386586 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.7874645704979928,-1.3877787807814457E-17,0.8358231812544432,-2.4066195080493396 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark56(0,17.971869871340147,-0.04019354764694661,7.800287217784167,-7.800287217784164 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark56(0,18.116071222811915,-0.025770177046954314,-7.270250488247584,0.21605807521131107 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark56(0,18.466542232427184,-9.071658572929777E-21,0.0429076540335078,-70.72874235980386 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark56(0,18.54025866304022,-2.7755575615628914E-17,-54.44214450873312,52.9421445087373 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark56(0,18.569892415830935,-75.60374741090146,-93.54538793690548,40.908793507912975 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark56(0,-18.690240477451294,-0.039647977344661044,82.33575479334837,-83.90656053600543 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark56(0,18.789272175147843,-0.016062750086404315,0.04129835119122088,-38.035327839645404 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark56(0,18.809277823693378,-0.01761068730188231,-18.218734046005054,92.33432360096526 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark56(0.19299319710425222,7.030959254381031,-1.456450805703612E-16,46.121740623761006,-95.46131826741653 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark56(0,19.6158297375502,-50.32975697928115,18.578874222621096,45.91513996271027 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark56(0,196.38960820419032,-0.010154873833369663,4.089061846326164,-81.04697083528451 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark56(0,19.686578821786327,-0.05315923155302833,-154.3536795284796,100.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark56(0,-1.9780419895239492,-0.05432053690158978,24.729810598016982,-177.521800978996 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark56(0,20.20343533247759,-0.060781221405728836,-42.86326643081755,44.36326643081755 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark56(0,-20.4638899848799,-0.02229480093390452,-93.51952800316563,91.94873167637074 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark56(0,-20.495227406609377,-0.051252811955360966,-78.58591259731739,80.15670892411228 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark56(0,-20.55021072399407,-0.05503395955671078,-80.11742222146074,5.3983809563458856 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark56(0,20.914748644003005,-0.012101867539472622,26.856884411313644,-80.1952787028231 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.021353922377273,-0.04404712023556942,27.589425677970087,-29.089425677970087 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark56(0,21.10847812059585,-1.530391328906738E-4,1.2204964440390527,-1.2870142592112586 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark56(0,21.2770051240131,-0.004879469521721969,-93.00622956703666,8.296860877465617 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark56(0,21.337562293475237,-2.7755575615628914E-17,-0.01879718075233683,0.01879718075232845 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark56(0,21.421251077524108,-0.03078960208267549,-93.08087037159804,71.12199529449761 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark56(0,21.422788963588705,-0.004917335274557932,53.25242592865947,-54.82322225545436 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.593485836863664,-0.03157028858360649,36.49566576269829,-37.99566576198621 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark56(0,-21.67913319726881,-19.537431683293605,-61.373120349234476,70.48365535235018 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark56(0,21.877867355286742,-0.04975148206180591,-99.9999999988011,100.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.050009972734394,-0.030232826985280462,-92.92532633068132,91.53437765399026 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.250231316588433,-0.032723923233410446,11.770641773755173,-22.729952206931475 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.333862268669712,-0.03755955977519915,-9.017281342892112,7.517281342892112 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.47004049302255,51.9908889589764,42.96738006421165,-75.50299790195459 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark56(0,22.662770625016208,-0.021781115414790844,4.255874093642433,-5.755874093642433 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark56(0,-22.904343068553526,-1.1102230246251565E-16,80.31468687336354,-81.88548320015843 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark56(0,23.04408038444169,-0.010317112401858564,-192.2643713544892,100.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark56(0,-23.252324771211114,-0.057178357661456514,3.4093383289705783,-3.4095328427895826 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark56(0,23.349771920076847,-0.057875022172104024,81.17570981435496,-100.0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark56(0,237.26853158046097,-0.031443983530630715,-85.59564868607848,134.15944118058405 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark56(0,238.46099279548196,-1.1102230246251565E-16,-601.8814273836928,1.4718836939035498 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark56(0,23.851541014893513,-0.033912186937026974,-0.1390688857834825,7.922254192963068 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark56(0,23.885911218338833,-0.04278523429911411,-49.219253554243934,44.50684911889674 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark56(0,24.185625785718017,-0.04174698207012575,42.8492905224343,-24.04804751100601 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.187176961871558,-0.009735230492203853,6.938893903907228E-18,-46.11985815987416 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark56(0,24.297807749446932,-0.05356774338249082,-57.10361148893497,58.60361148893497 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark56(0,24.35839878570199,-0.056199232313618064,-25.398859294507403,25.3988592945074 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.41551765815416,-0.05917897174139188,-70.8752265396062,69.3752265396062 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.4487954389839097,-0.050483541637522764,2.2503824338370153,-0.6980130591032964 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark56(0,-24.682767701139046,-1.1102230246251565E-16,14.640559721555046,-13.140559721380228 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark56(0,24.863225179993407,-0.05430273387977748,-16.91767875617081,16.9176787587921 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.21047838644226,-2.1846570936615264E-13,-62.65687132072254,0.025069817462707977 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark56(0,25.24742542359171,-2.7755575615628914E-17,8.773953982138224,-0.17902946949490287 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark56(0,-25.377082628144343,-0.03362140151640107,-2.454376662141164,3.954376662141164 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark56(0,25.40530115143653,-0.04762765745449282,20.512198402536256,-20.51219840253626 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark56(0,25.456270426369482,-1.1102230246251565E-16,38.29891640599119,-69.86745196663027 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark56(0,25.556453080861715,-0.014277823198406054,-53.83254655176006,55.406036984391484 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark56(0,25.723805355808615,-0.03295045650079209,-62.06285105215403,91.06658522526402 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark56(0,25.9615241313597,-0.05018450418351472,-17.44257362509239,31.577246409115578 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark56(0,-26.103970141238335,-0.01387121035271588,-85.06418875937256,26.792838867247532 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark56(0,2.6644505035446673,-0.021909308395017632,36.18996358386698,-34.67944405422916 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark56(0,26.769385255320888,-0.007332507685028911,-90.22314057380537,90.22314057380537 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.04015066059876,-5.551115123125783E-17,0.0347342286411223,-9.82537952427436 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark56(0,27.11332457095626,-0.002512674763104794,-8.358890257436116,8.358890257436114 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.178813809745506,-5.551115123125783E-17,-15.769287360909289,14.260018967432083 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark56(0,27.480677550356504,-2.7755575615628914E-17,-35.86401180079541,34.29321547400051 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.611879677273667,-0.03972419872728733,86.79133414556352,-88.36213047235842 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark56(0,2.772372204612556,-1.1102230246251565E-16,-1.7889510563686686,-7.902520444341468 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark56(0,-27.937967110489698,-0.004593792029070524,49.67248553194572,-82.4103674561611 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark56(0,28.311530483239935,-0.045519421681576064,36.023358971907214,-34.629849196540924 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark56(0,-28.35280318810975,-0.052285021143417154,-0.03251457211873321,48.310533537357706 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark56(0,28.842246572853696,-1.1102230246251565E-16,-98.8675766773017,100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark56(0,28.873815509404004,-0.04852235960138046,-22.28401999077649,0.07048980962344586 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark56(0,28.978406325565604,-0.013520527856433361,98.14070029657488,-100.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark56(0,-2.917003369067359,-0.020277851371242717,12.82868291078998,-82.60385470970371 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.67044233013695,-1.1102230246251565E-16,-14.5309510648259,37.90558905095843 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark56(0,-29.953893915636066,-0.010631253589914347,2.871915026077498,-787.2006768338342 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.055466659178663,-2.7755575615628914E-17,-48.03837062336268,46.53837062336268 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark56(0,30.11399242479567,13.950685605743601,47.97846759335141,80.02704320004486 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.454344092698644,-3.218979845966974E-4,26.472897456172888,-0.05933601825774541 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark56(0,30.46493579930607,-0.012874499785947761,100.0,-100.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark56(0,30.686757560079926,-0.021511503670933567,6.174089329173199,-22.95038748595598 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark56(0,30.790089513848326,-0.03953848279926492,-54.836305714837174,53.26550938804228 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.823970528173646,-0.030602066947702865,-71.37314839922043,69.87314839922043 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark56(0,30.839983918125156,-0.05150408703526273,0.11209859010550273,-14.249265531259573 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark56(0,-30.904319761358042,-2.842871439271668E-16,3.251191597252148,-3.251191597252148 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark56(0,3.091649360662441,-0.007434955333758495,47.631681905075666,-59.49135215129475 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark56(0,30.925455278927082,-2.514530985795451E-10,67.90450972581965,-66.4045097314727 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark56(0,31.077782586460753,-0.057259621014416076,30.721531062882207,-26.74098833393986 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.12505891664271,-0.030528502787260103,94.63386615616278,-94.5798970832834 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark56(0,-31.305713590817753,-0.04551354428357132,26.00513484078995,-137.41698205085927 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark56(0,31.745846013395948,-0.05430890820573195,-24.362162220080958,22.862162040740806 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark56(0,-32.232045506267596,-2.5632936532512146E-5,-4.909890305799202,3.4098903057992023 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark56(0,-32.29922318495271,-0.02130971256982221,-3.1202956966798894,3.1202956966798894 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark56(0,32.483014106725115,-0.05391256323024307,56.61323529655259,-96.50478260181825 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark56(0.3347031589874744,10.01204500465563,-0.045236502516488974,-52.92768815406464,47.922827690091694 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark56(0,33.5845104693147,-0.15289509224768572,0.19907503825105888,-7.89047356511831 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark56(0,33.75432621711812,-1.0276194901031282E-15,72.09910626703216,-73.59910626703216 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark56(0,33.77433954014694,-4.122586885739936E-6,-25.400770429668206,23.900770429641245 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark56(0,3.3823773738693745,-40.66594586542076,71.32315714639836,-59.309397373757065 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.826781484765434,4.880009723407966,-43.1298434953556,5.496357314117944 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark56(0,-33.8317042315035,-1.8863195366765394E-6,98.49999686399592,-100.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.407456449480759,-0.00864076600302588,-12.926256670967605,14.426256670967604 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark56(0,3.413159878685904,-0.03174142494748769,1.8143147220609586,1.731906246868747 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.23041660438129,-0.060521978650537885,-3.4673014359074755E-15,49.482224274088125 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.27417885955772,-68.99377903678727,49.182178104960116,-38.14814594837743 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark56(0,34.30974232408847,-0.04166842890504007,-73.59463194437481,2.90879723860446 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark56(0,34.31086342715605,-0.060590946545864055,-97.86202340035952,96.36202340035952 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.35490561342119,-0.8953884626512862,12.774048467249207,-14.344844794044104 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark56(0,34.38344825002413,-0.012338988905417347,-18.804022135427992,9.868327644549195 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark56(0,34.46912698458033,-3.552713678800501E-15,9.816781096214363,-54.72555426782385 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark56(0,34.552205421341476,-0.014434074850241008,8.322188800315566,-679.2705859697388 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark56(0,34.62038237265936,-0.0030962870968450234,94.88134982227788,-96.45214614907279 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark56(0,34.75607467894872,-0.023665978497153628,-80.79411296982977,75.41457163193569 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark56(0,-34.94981144946268,-0.013043347727206889,-95.02019786071551,18.17596055826689 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark56(0,35.16447865516634,-0.02225056331488562,-79.2134767809124,57.47265434194429 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark56(0,35.3255851861301,-0.03277146531149608,-5.656798596682969,4.0860022698880725 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark56(0,35.48183485495073,-0.5493457333826919,-49.02710771168257,47.491678242698896 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark56(0,35.549061445475445,-0.1793026591092756,-6.674823681046926,-1.1796339154170141 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark56(0,35.74733083041101,-0.001397255203777315,46.21047014365637,-47.71047014365637 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.82766043270989,-0.018169262240258555,7.393566817204967,-4.761853975125234 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark56(0,-35.934024098855375,-1.7300103021947736E-16,0.07768875549642923,-20.219094986881224 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.18050407887029,-0.024649427358592692,57.512824136712055,-88.60035343665677 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark56(0,36.20490293321241,-0.024641865566399607,-86.932952761747,86.06067560125196 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark56(0,36.282332700863336,-0.027198490301428874,-17.29069505826403,-65.98349989971406 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.40009883369591,-1.1102230246251565E-16,-36.39304898378089,12.871851827513424 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.642879470527106,-0.04758077914177167,-18.00772074300741,18.00772074300741 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.52828342625662,-0.05578267840761814,-12.195789341341774,13.766104493587532 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.58632577809785,-1.04115017681494E-15,-2.790896316280571,1.2200999894856748 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark56(0.3681851517513472,1.6815978627319201,-0.050815371524353614,-15.291505562123422,0.019644027715081856 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark56(0,-36.859184115874335,-0.010475445440601083,-0.07089184028837536,5.049050499061224 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.02092782093076,-8.180488619075207E-17,-68.71039724632739,9.026505080875367 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark56(0,37.23888710620136,-0.010670023150599065,0.25985262084952565,-6.044950871226758 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.275808607891705,-1.1102230246251565E-16,-95.56472618250307,4.440892098500626E-16 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.35322488998014,-0.2547169532477408,2.0080205217343017,-305.33963504271054 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.38016894475246,-0.050146431681396916,77.59533112528749,-83.86905951152664 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark56(0,37.55369361544441,-0.04693329325598053,-92.39815421208053,48.39197556085162 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark56(0,-37.66266317056894,-2.132709273364315E-11,-14.955555269887071,13.431587941371681 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark56(0,37.76618171147937,-0.016102923907291074,-39.14059767029058,38.94810264869041 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.04232763726826,-0.044249619164257195,42.98098933430262,-44.55178566109752 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.13146600343308,-0.019293873802457777,-43.23676034534599,13.462979586971016 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.34161200585442,-15.949056239374727,-53.81624907946898,-67.30863976057834 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark56(0,3.8534530310533253,-0.04417990683501949,-0.14450557980093137,10.870143069622648 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark56(0,38.6816212378443,-0.008367707989659311,90.90699568401651,-89.40699568401651 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark56(0,-38.74944328907141,-3.552713678800501E-15,-88.13202586172733,30.083358097111052 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark56(0,39.15197454970879,-0.03710818713486161,45.13476454360774,-2.5044868773856366 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.16230213063789,-3.552713678800501E-15,89.02269460580331,-90.5934909325982 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.17818204518075,-1.7763568394002505E-15,-64.58212780815595,68.93747791285446 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark56(0,39.26319276734441,-0.02328549745729136,-27.88044374819225,27.189259847491584 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark56(0,39.43950062249547,-0.024494293851578128,-130.40121998010449,3.552713678800501E-15 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark56(0,39.4994596575807,-0.022262713903559828,0.026232605105466263,-54.716986691435196 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark56(0,-39.6270073507935,-0.035909683131069965,-0.034430908106029334,45.621693216968275 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark56(0,39.81965260547108,-0.0020425908086497816,0.8784783715427027,-46.43151348266205 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark56(0,-3.996603871948736,-0.006932064812717964,-26.459937270147467,11.391567475812764 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark56(0,40.368536688182104,-5.551115123125783E-17,2.828644885286442,-4.328644885286442 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.075530269581328,-0.01509874384480428,36.496319245813595,-71.74607801643934 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark56(0,-40.95310663295171,-0.0160248019580038,-8.555617570438425,7.055617570438425 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark56(0,4.142004559370889,-0.039342016243572614,66.46394703677626,-100.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark56(0,41.97840333162188,-0.002659945579808032,-36.978485888623304,36.97848588843556 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark56(0,-42.25873551151084,-0.057177479873888035,-26.428016896569158,30.096069958321912 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark56(0,42.63178965325788,-0.001587734429442782,-1.3307797724290928,1.180357831805406 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.07697882360516,-0.16086519252107737,10.719400538748356,-12.290196827519175 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark56(0,4.3125370500769264,-0.010357377411556365,95.5422385628901,-1.2943421827404626 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark56(0,4.313862384349193,-0.06255123750241745,65.3767835656389,-63.87678356563891 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.321498772067137,-0.07198394679762662,-588.7981550097942,2.791550998315458 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark56(-0.4321631094136881,7.1589870893359,-0.058715122064129315,-40.03599295089687,4.230326765143502 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.2682617542264,-0.013432538413356926,-24.16131869463878,46.46336946074258 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark56(0,-43.56220320918848,-0.0049353537594810145,-67.34920487492235,28.15009303184483 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark56(0,4.369212218860838,-0.060848219338037704,17.819536541867024,-19.219629012717355 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.20759013287878,-0.9999999999999999,-50.70043829185365,61.21651696788228 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark56(0,44.466584738109134,-0.05030040568881067,-69.24126607933408,20.019469121285695 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark56(0,4.450896630732249,-0.04939276982398731,540.7216398671347,-2.9818154585672616 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark56(0,44.64952244451095,-0.030675869269170746,57.1812189075022,-58.750008555139814 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark56(0,-44.672566259326,-2.902090108534089E-4,-12.888290194898147,14.457116441281634 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark56(0,44.816571081417266,-0.03665031063483978,10.519007292432624,-10.519007292432619 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark56(0,44.922464309985045,-1.232595164407831E-32,48.471943680183664,-49.98077741296611 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark56(0,45.02041131704167,-0.061251651979812666,0.18830050770688816,-1.8196571418001415 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark56(0,45.09583702140887,-0.033653359383221115,9.3617775285237,-7.861897443364637 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark56(0,45.30333409187433,-0.04690764659189536,-25.936427007624502,4.440892098500626E-16 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.562524065295236,-8.881784197001252E-16,12.892201149104366,-14.462997475899265 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark56(0,-45.717552711783604,-0.002530410065182397,19.380256176696832,-0.08105137065647514 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark56(0,-45.73722920660741,-0.03701693822931007,47.88885479986371,-43.89561078836023 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark56(0,45.977463337938936,-0.013791669492427272,95.40159032832322,-98.37954916532775 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.02368039966911,-0.008029371666413182,100.0,-100.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.113058028528314,-7.105427357601002E-15,48.984427808171816,-47.41363148137692 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark56(0,46.198745784335685,-1.1102230246251565E-16,71.5052502823138,-6.821138123385012 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.32695206211067,-0.0133494310146169,22.099677523376783,-0.17677985813910457 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark56(0,46.36985462168313,-0.062310164236811016,19.04374584193576,-19.04374584193576 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.71725846312964,72.55203352384507,-3.0816861901201236,-61.62333663890522 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark56(0,-46.90461927331181,-0.015240882537414041,-100.0,191.48530999531266 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark56(0,46.99252288184477,-0.01546316627096811,26.78764015535519,-88.37960604557415 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.006736314888286,-0.053199646837428644,-15.495835035244426,13.995835035244426 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark56(0,47.07610401036667,-0.0023651231014099753,-3.121887999882219,3.121887999882219 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark56(0,47.24932458204264,-0.03747244587983389,-100.0,98.42920367320511 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark56(0,47.541348576115084,-5.551115123125783E-17,-23.4899781753833,22.42409422773883 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.579807386495595,-0.015699088880620812,3.0407727310866672,-0.5165780101670236 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark56(0,47.64160676769805,-0.05608041265061803,22.414295803203657,-20.914295803203657 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.749117422678914,-5.551115123125783E-17,36.22871829429249,-37.72873343230078 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark56(0,47.900783627633984,-0.0013800479464814996,-16.47197184143934,54.06217721349213 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark56(0,47.94104676247892,-0.042752147487687076,-71.0216038433164,44.121312635226985 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark56(0,-47.96989765465673,-0.03270959614129363,-98.03381764049374,74.5257379306193 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark56(0,48.11403060979958,-0.03823781074440405,-5.64674550409633,4.075949177301434 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark56(0,48.118326809427536,-0.05651589204788521,19.568523664175476,-23.352734049229227 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.14396147378849,-2.7755575615628914E-17,13.146182212276385,-13.149228316362624 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.19603163577042,-2.7755575615628914E-17,4.078270840118595,-2.5782708401185945 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark56(0,-4.824811222744445,-0.008524535648481914,-76.10379113496556,89.55166103961925 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark56(0,48.29366143518679,-0.06109314568004692,49.52547204137313,-56.77742720784686 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.49861141848896,-0.03552211395955088,-21.09767486654527,660.4278869091625 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark56(0,-48.51049772365096,-0.04004102119465952,1.5115107250043236,-3.08230705179922 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark56(0,48.85625721997865,-0.05386492196191073,-29.384961621024555,100.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark56(0,48.927219837250306,-0.05479965314540969,-58.24776046415418,60.03009266468774 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.040746898448695,-0.0056559937722722164,6.591224772441265,-100.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.0624529503953,-0.01263401110939294,-58.67457668717393,0.026771327813231032 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark56(0,49.074012530642506,-5.245900531012666,4.591672295880159,-1.8087957871338176 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark56(0,49.11860525414032,-0.057971747119389905,55.76158664421715,-57.33238297101204 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark56(0,4.9190636503843,-1.90691278704412E-4,100.0,-98.5 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.247665728962595,-0.012033807772721006,19.72663613643884,-54.68988550506475 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.448461915661106,-0.014833779369465283,-56.08323336013535,33.448823088930155 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark56(0,-49.4568864515248,-1.1102230246251565E-16,56.410682023765816,-57.91079358532392 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark56(0,49.92961834467604,-0.02415846991207171,0.016239785674467554,-18.121852482284247 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark56(0,49.98952249937115,-0.02705218635836742,9.19151090870842,-10.69151090870842 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark56(0,50.041444240662166,-0.001062234065355269,57.57509077702008,-57.699758408417864 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.22393017508035,-1.8743335798984837E-9,-53.676351876876105,53.676351882879956 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.33801391158614,-0.019935137405271426,-70.27568066656319,27.870268109167462 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.45854839905378,-0.04250138883801757,-100.0,98.5 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark56(0,-50.656430356344224,-2.7755575615628914E-17,64.41401799008426,-27.186577751409814 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark56(0,50.665837965635795,-0.0038504350784180352,-2.138948251149942,0.5681519243550445 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark56(0,50.69289841503778,-0.04555006737311884,-17.35774241389723,15.786946087102336 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark56(0,51.09360869015249,-0.044866359468072936,-33.75584741897325,32.361112714127366 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.10876614974152,-0.030013549287643604,-15.626913695951771,17.12691369595177 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.14915119927222,-0.038336886462571315,63.24180708227112,-64.17966443443228 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.22421119322598,-1.3877787807814457E-17,71.27530230586531,-69.70450597907042 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark56(0,51.25449433790567,-0.04102123225325793,-4.492788287172578,-15.856767634366179 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.35466876009873,36.227794264278145,-55.3268890112393,93.39141577250976 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark56(0,51.450477423998024,-2.7755575615628914E-17,-792.8364573385348,1.0408340855860843E-17 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark56(0,51.45708235948109,-0.018506069371902314,76.15001176151019,-79.29046778797542 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark56(0,51.5415338956581,-0.04134446947126724,31.13683436486124,-29.566038038066345 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark56(0,-51.62344559980485,-1.1102230246251565E-16,30.316029780627023,-28.745233453832128 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark56(0,5.187053427324583,-0.01007391093177643,-66.48122209410757,-12.057890269223549 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark56(0,52.07633836502636,-0.050121084140848475,100.0,-109.29770145492601 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark56(0,52.734667312892526,17.082480972369154,25.90963441234213,-25.24192338208941 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark56(0,53.38212024950742,-0.4960027413454432,-39.36452679125184,28.363520401295045 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark56(0,53.38481328558751,-8.881784197001252E-16,0.03543565661062652,-39.95443660915112 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark56(0,53.52069664978321,-0.03597394156995687,0.19296879764774544,-8.140157092455455 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark56(0,53.56618903289444,-0.040772976499821756,9.021896971105157,-7.451100644310259 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.68047909210171,-0.040836618074337125,23.32593417021785,-0.06734119694123386 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark56(0,-53.846257596062294,-2.7755575615628914E-17,-43.11339560689391,-16.54399601324966 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.14854426104085,-0.06098574249733202,2.5970241858346412,-0.6048447047057701 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.30472981530423,-1.3877787807814457E-17,-38.235099141569115,38.23504411296892 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.3208243128411,-0.051264551149740684,-61.65413033165619,60.08341292700201 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark56(-0.5449116558599982,25.921712092919382,-0.028506387616470924,-58.060178447818494,56.560178447818494 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.57085622048148,-0.002007050943647404,34.10746914481156,-32.53667281801666 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark56(0,-54.585648613616875,-0.0018328125890279302,-64.74413617378691,64.99669744030304 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark56(0,54.675218824161604,-1.1102230246251565E-16,-37.56343942837223,28.191925155874195 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark56(0,55.06764616765025,-0.03837578312427649,-119.4880677898241,50.88983591687351 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark56(0,55.06849134424313,-0.005033012299076794,-17.109176662305583,17.10917666230558 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark56(0,55.20758071369154,-0.01829966499807513,100.0,-98.5 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.524019058860871,-0.02924556135533565,63.71261958304329,-74.7205946769977 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark56(0,-55.54075514459052,-0.013909206665948533,0.04800116842474722,-32.724126898234594 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark56(0,55.71608553305337,-1.1102230246251565E-16,-100.0,42.15998285540029 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.5816009062794745,-0.05345920864204601,-21.745125365580073,23.31592169237497 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.55320011303677,-0.03384521155686415,-41.053743325655596,42.62453965245049 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.652267888554434,-0.01242645142505458,3.5170196382208365,-5.017019638220837 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark56(0,-56.818917287038005,-0.021972778236648803,77.78360495142601,-79.37057629963218 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.053859555364824,-0.0028228020089095703,-94.21109585907999,93.0079543554055 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.11193474675849,-2.7755575615628914E-17,25.014166503885075,-25.01416650371347 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.12835210560572,-0.0624976215966071,86.3470646022066,-86.3470646022066 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.15077460291724,-8.649672226274663E-4,-279.4282052038132,3.9074577301593925 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark56(0,57.357572654664395,-0.02492892227511964,58.35002058279173,-60.50992457096643 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark56(0,-57.38909145902298,-2.7755575615628914E-17,0.09539086073356356,-16.466947826189465 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark56(0,57.421002861777694,-0.05705920930430253,-57.19421355427042,-7.208435844320315 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark56(0,-5.769912081814184,41.85278548309611,65.89234234571128,-91.41723140585054 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark56(0,57.98042767506098,-0.04407804945475829,-43.61845089969698,45.18924722649188 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark56(0,58.62313090524567,-0.055068503101829924,53.63515523917468,-89.12020378123027 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark56(0,5.865410961283644,-7.525119428638249E-5,4.030245989935085,-87.30055650082264 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark56(0,-58.916375089295755,-4.349925235450833E-16,-0.04598841069266791,34.156351635898865 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.33667465905439,-0.057528394685218975,-86.97067750711633,88.54147383391123 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark56(0,59.350770677712006,-1.4856696735763585E-10,-36.310171102126276,37.810171102126276 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark56(0,-59.383678395811465,-28.401783019129653,-31.91709851269451,56.58264281907128 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark56(0,60.16268120443857,-0.03907029156392615,66.55754882573282,-68.12834515252771 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark56(0,60.72689952528532,-0.04199577772960665,33.09222006308559,-125.64269168932152 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark56(0,-60.92643833464933,-1.1102230246251565E-16,28.26863458696843,-42.16681296883055 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark56(0,-61.05838806445206,-0.05451679599004699,0.03631580508662849,-43.253793301508416 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark56(0,61.07501713037837,-6.244505235715479E-15,11.39917753352941,-45.58206913874518 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark56(0.6124571171317104,23.062342240178204,-0.0013325065180315589,99.9994228778856,-98.4994228778856 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark56(0,61.39240374309245,-2.7755575615628914E-17,-24.277037252658108,25.784970295298876 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark56(0,61.706551761237066,-2.990903388519608E-4,-18.98871143803562,17.48871143803562 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark56(0,61.916047046530124,-0.0432187249532619,-25.296584739422144,0.040543091852087265 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.17147872022045,-0.02431793314669279,-1.9016917649028773,0.3308954381079806 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.220625141566934,-1.1689737987854435E-4,34.11799128002791,-32.54719495323302 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark56(-0.6243860286101395,1.4012889462626992,-0.011727925733505819,6.1774239637225214,-9.717977082591078 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.60654619251873,-2.4513376438388876E-21,-0.17430164120619304,-79.93630231382112 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.65780766682413,-0.029987268446960563,0.47536165245606976,-3.30442373439044 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark56(0,62.89698309010849,-0.016282269854279607,-23.828355332358143,2.2576645358095537 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark56(0,-62.97030577361991,-0.05556994643694521,0.014498417788546023,1.556295231094977 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark56(0,-63.5217603394992,-0.04917836641620693,43.88259662726608,-0.035795427971983214 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark56(0,-64.45327785210758,-0.006653060550529166,-73.83636723468634,72.71505434521109 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark56(0,64.45841183587353,-0.051383988423403436,11.605045069907128,-10.03424874311223 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.31823854846738,-0.03037240539632521,1.7612400984214203,-1.7612400768095509 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.32209779088302,-0.0010629031658216208,45.88753985113632,-44.31674352434142 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark56(0,65.4777260019218,-0.0031852676743615426,1.5288426572797953,-15.595213271638968 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.5893171509954,-0.006543739496188515,-100.0,63.872516630569805 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.60323249603066,-0.0029863761170435543,32.91143813026225,-95.58809398348002 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.86250190406403,-68.81362251585152,31.38348935627758,-3.847806351513114 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark56(0,-65.93204140004146,-0.051933206576499524,-52.72946732729035,65.61632677629571 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.14682644092258,-4.3368086899420177E-19,-94.92964653906256,93.35885021226765 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.28364481001917,-0.05873459168972836,99.38230157327438,-100.95306331314633 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.6594282898627,-0.02699193850492124,-75.53618151588086,0.16558770936346434 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark56(0,-66.66082438974881,-0.1442912307421409,-18.041908214645844,104.3485883784708 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.04896343931546,-0.5560358956985131,-5.798466394613689,5.787105281888848 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark56(0,67.08871223790571,-0.018443696107129787,-36.29319834352222,58.80184328366778 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark56(0,-67.70368581423392,-1.3877787807814457E-17,-70.22678921271435,71.72678921271435 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.03280194287542,-2.7755575615628914E-17,-75.39387420680136,76.96467053359626 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.21811517414599,-0.054269660729737684,-45.12530936253013,43.55519381543549 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark56(0,68.267318517045,-0.04858424886812357,-46.51892968309727,44.94813335630237 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark56(0,68.28583738124858,-0.0392246248920021,-74.1075384227795,44.5939703623625 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.40930559535938,-7.670988282167945E-4,24.22678819853064,-22.72678606082449 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.49065506493329,-1.3877787807814457E-17,0.06055236836432496,-25.941121201798392 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark56(0,-68.89666347004739,-0.05420004420727404,4.182601571098471,-2.6118052443035737 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark56(0,-69.05887522651675,-4.440892098500626E-16,0.020646816121205752,-76.07934887266113 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark56(0,-69.16622079318421,-7.140146194921133E-4,44.04050078975166,-45.61129711654655 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark56(0,69.20017955054116,-5.551115123125783E-17,-77.3843443699517,75.06637724873626 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark56(0,69.2499112282998,-5.551115123125783E-17,-7.391140067254685,81.53450000402333 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark56(0,69.51716629098696,-0.02648308607963476,19.184650314912346,-27.803679352024517 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark56(0,-69.56982789045085,-7.425123140667092E-16,35.93661842052035,-34.36582209372545 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.08741416323052,-0.05812883333037219,-75.02513616028386,76.51897240348372 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.10476611849504,-0.052583916609041124,-52.39350326552692,14.845455937835196 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.14515515011333,-1.7763568394002505E-15,-77.99429076751643,20.3573608892887 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.041771210918569,-0.21603106183621745,-3.2431210593444817,0.8925128332164927 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark56(0,70.48698768363434,-0.008099860011784026,-36.220842753357246,56.64117003988435 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark56(0,-70.6263673537423,-0.058073660131488535,-85.24084077236014,86.81161032174617 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.073579386407772,-3.552713678800501E-15,21.942266183922086,-23.43291517279703 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark56(0,70.99043121616583,-0.052466653805005814,46.88061930404817,-48.451415630843066 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark56(0,-71.15529642770025,-0.03747068673455933,0.11903081549622158,-13.13011523262126 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.15100090656729,-0.06021666724649585,-75.02824911386963,76.37148275704422 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark56(0,71.57065884736159,-0.049808611573125265,72.19464689346827,-73.69463236858834 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark56(0,71.61517792378801,-0.05203185883123138,0.0012162762508090659,-11.912631536760756 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark56(0,72.12036324481768,-0.036073555332555185,35.458057913513706,-1.7198813023330217 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.42031007358374,-0.09120405014249541,101.4611126503921,-98.44096990109995 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark56(0,72.43909943439556,-0.037446008294922006,-82.61809540639626,70.10960095310469 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark56(0,72.74253129017615,-0.14995562875478746,64.97168706601195,-31.977290822274398 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark56(0,-72.90422104441788,-0.018337230427457638,49.01701843336972,-38.021444461005245 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark56(0,73.37532928297605,-7.123747571623947E-4,-93.21225305310506,8.463934882077865 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark56(0,73.39119531036475,-0.29001080047311234,-51.563244127006236,51.48625810032096 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark56(0,-73.46603664100695,-0.03863340254596396,-100.0,67.606217480006 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark56(0,73.97833901411508,-0.04826409568632828,-11.219330954633094,12.719330954633094 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark56(0,-74.21713397896278,-0.028072926738300197,14.219300599752252,-93.95067100202962 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark56(0,74.68599986535098,-0.032728727190302564,1.665661241940218,-0.9430466935552757 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark56(0,75.1202198804841,-0.034230386258432,84.65719698649569,-116.07529080305795 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.513601998214028,77.16710733323484,-40.320535528997794,-17.46794287564417 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark56(0,-7.519898921537064,-0.06215526625047003,0.040872829567280895,-38.43130860830674 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark56(0,-75.64616124815544,-0.05233885442586467,-99.06388034763378,100.4397036961682 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark56(0,76.42585799835531,-0.060395527355663475,-9.413109361001105,5.858179261337492 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark56(0,76.46556042907268,-0.03567128607494341,-16.35935644620118,14.788560119406284 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark56(0,76.48178478324482,-0.06183510450315952,-0.3378008275248092,-74.98962653183533 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark56(0,-76.96932853408849,-0.014375039856836188,-5.779592039897223,2.6513567496299593 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark56(0,77.02376077334527,-2.9191113147772856E-4,32.34744915646493,-33.914203648685536 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark56(0,77.25198199738004,-0.015594646082730389,-27.853956319620117,26.283159992825222 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark56(0,7.727753298276038,-4.440892098500626E-16,15.77628038890768,-0.09956696306555762 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark56(0,77.36311332329328,-0.02158765169520075,95.33240178119439,-69.23910569448664 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark56(0,-77.85447129347422,-0.018793483263029848,-77.52649884473743,23.483937516874825 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark56(0,78.34767607817855,-0.04778001421717719,88.19222968345116,-73.9918930616357 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark56(0,7.838770134258171,-0.05130955898998946,61.62727134832213,-63.19565236900974 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.61729328809369,-0.03880643727505121,-70.1325006399036,70.1325006399036 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark56(0,78.70766327462223,-0.001514756421447265,0.7852739467340027,-142.02732645751337 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark56(0,-78.76330584698088,-0.051718534998983934,72.71545586083926,-13.699248904398198 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark56(0,79.15680133867767,-5.86265005738662E-5,-9.373088546606303,7.802292219811405 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark56(0,-79.49335149146293,-0.04934409813153057,-0.028775159200283618,54.58862332825724 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark56(0,-79.57790614112861,-0.00888851519995958,23.427423689283476,-24.927413989117195 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark56(0,-79.58931748786432,-0.018589857669934956,91.74580832419967,-91.74580831152768 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark56(0,79.71321704098955,-0.04840990302018835,100.0,-117.17351473046227 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark56(0,-79.98129597830848,-0.03705542963157446,-12.181105681945422,10.681105681945422 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark56(0,79.99232628448122,-0.018142270797279057,7.920710231930145,-6.420819683065851 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.00827709094384,-0.009442440453953939,100.0,-99.99999999960984 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.08871374112772,-1.1102230246251565E-16,-0.9032345297440715,0.9032345297440711 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark56(0,80.26889672897894,-1.1102230246251565E-16,-1.8403817812132266,0.8535165598951906 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark56(0,80.37793584622767,-1.6925508475539276E-16,-100.0615425813716,98.5 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark56(0,80.40856912190503,-0.023497162167517682,100.0,-81.90147465229393 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.62828948028768,-0.03596995008677879,-8.041582832397934,8.04158285645868 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark56(0,80.71743522627588,-0.03704888393604433,44.558862489807325,-46.058862489804554 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark56(0,-80.95105399086394,-7.130202387829577E-15,-4.089407370665816,89.04420240275635 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark56(0,80.96915318782894,-0.043100515728135,-27.67924653001646,29.17924653001646 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark56(0.8098122803707299,-98.30795364158135,-4.622344503486335E-32,-1.1707999408559824,1.3416436677016512 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.51415610524441,-0.014976251298642957,10.35442681330116,-19.196813289390732 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark56(0,81.56532070649493,-2.7755575615628914E-17,-6.279076410112214,24.601611503650293 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.170395948025451,-0.04321973143584728,-59.45276591005325,57.88196958325835 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark56(0,-81.77532535567529,-0.043482242391790105,-64.70580975554886,42.027768916855464 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.04441000096803,-0.01789564456222148,3.015400211069024,-3.0154001566922792 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark56(0,8.222289453601007E-4,-1.3877787807814457E-17,-0.2127910782764852,0.21279107827648522 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.23021095275062,-2.7755575615628914E-17,18.056118987526396,-16.556118987526396 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.38253220893738,-0.032134537801166395,-78.85793594687973,80.3579359468797 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.7149889945486,-0.06063058426222439,-100.0,98.490229860353 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.74567156380658,-0.05815112164925762,-14.800449610302742,14.80044961028883 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.81021443907775,-0.01902154429272418,-2.724928164434793,-2.882750523954729 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.84306896107366,-5.551115123125783E-17,-46.82306046533874,25.191945115383568 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark56(0,-82.96064712418607,-1.1102230246251565E-16,9.226224395347659,-9.226224395347659 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.01372148519346,-0.01820818367771425,88.51084153301153,-96.82034466554829 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark56(0,83.56009133680234,-0.01976715035370863,89.71620895234778,-91.2997144879556 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark56(0,83.58348117138824,-0.05302265259700889,-98.40155290537528,32.937051157071984 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark56(0,83.60809554633636,-0.033655063771412363,-84.02077184662416,85.52077184662416 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark56(0,83.77003020859436,-1.1102230246251565E-16,-98.21109932417262,99.78189565096751 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark56(0,-83.85223166925059,-3.267147458857899E-14,0.016912747140185758,-92.87647439974936 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark56(0,8.401329411764046,-0.004809625582227139,-80.60997180425962,55.496516926174586 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.08132547482597,-6.1854486104977924E-12,-16.38158832186907,17.88158832220668 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark56(0,84.43992783850722,-0.027138968921349038,41.114859509031064,-18.440963492104586 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.62410584147923,-0.05641675799903313,-16.140536490069813,67.19955454789732 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark56(0,-84.86202035019741,-1.1102230246251565E-16,36.66791724394748,-45.91948309177885 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.59894955287155,-0.0389957780567204,2.4371539612474598,-4.007950288042356 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark56(0,-85.96604074803189,-0.005783313060886419,-0.023325355140057184,67.34286862356625 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark56(0,8.602170063335791,-0.038749363899692066,-22.9144256581396,22.68157015145607 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark56(0,-86.31372923396971,-0.12771576521117411,-2.022952846762218,588.8602166057859 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark56(0,86.99568327013839,-0.020460170771032613,54.91743020037586,-96.6692762979096 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark56(0,87.01544698280134,-0.013674561580488541,12.45938055820747,-12.45938055820747 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark56(0,-87.10346652710857,-0.017071689951540344,11.172050581147795,-12.742846907942692 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark56(0,87.43713447887691,-0.026491294246048076,-100.0,16.752128686197807 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark56(0,87.57880258410637,-0.02761565897564844,-40.038900244267,39.070449326852284 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark56(0,87.92406126305346,-5.375747622021859E-15,0.18258726847063972,-8.602989353814024 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark56(0,8.795790082174548,-0.06111117447290318,72.57827760921668,-31.65286543537636 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark56(0,88.05381021472351,-0.2097893782644925,67.19248956956243,-68.7168917375581 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark56(0,88.26033440631194,-2.7755575615628914E-17,51.68097027287601,-50.18064182068617 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark56(0,88.29649127457326,-8.881784197001252E-16,6.1706317011596346,-7.6706317011596346 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.44383100114507,-1.3877787807814457E-17,99.76331423309796,-78.38661760855261 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark56(0,-88.53281777845805,-0.03963199125164664,-4.088449557317233,5.588449557317233 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark56(0,88.60923496756783,-0.022395193071920328,7.51044303693655,-63.443587674600344 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark56(0,88.68213312916684,-0.01393918331560194,-2.364913831450096,0.856592283105822 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark56(0,-8.880476060744883,-0.01666149218566932,-10.416281037412972,8.916281037407446 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark56(0,-89.14963184970689,-0.029860825853518236,63.047837337923994,-82.87341356887333 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark56(0,-89.67364300456346,-0.05650970974762176,58.92334163901782,-2.4454702011964407 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark56(0,89.67577861503419,-0.05081270069757421,-28.29339788458259,-17.188899265674518 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark56(0,89.81243957156816,-0.015591537515746906,7.79649379689977,-43.97446573443228 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark56(0,8.982423160503695,-0.050586236608915536,47.91762896255457,-2.4353318122974668 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark56(0,89.88926488962991,-1.1102230246251565E-16,-34.78598685939468,8.071586001445235 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark56(0,90.24953057024499,-0.023958720390401894,-69.52456363714599,70.45647277511219 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark56(0,-90.63018717723973,-0.060200890832522065,-32.6561109317435,32.656096485813094 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark56(0,90.85017593215463,-0.022857260990344463,40.472916793537536,-42.043713120332434 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.101208119338454,-4.899954634554746E-9,-60.321773153199985,61.82177315370081 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark56(0,91.20893243758621,-0.12610509623390592,96.20345482987292,-96.20345482987292 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark56(0,91.50150959686272,-0.013939112827602535,-100.0,45.04940971746807 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.66209379898062,-0.061183677774639345,-43.516030198378346,42.24416374796884 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark56(0,-91.77976720150166,-0.0402866187720043,-100.0,99.99974593291317 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark56(0,91.78783243598562,-0.011705626165729812,98.05093426489277,-96.55093426489277 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark56(0,91.87544154209033,-0.02314570221766668,-12.460193304359954,10.961030277480514 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark56(0,-92.02076535111536,-7.618798882041422E-4,-55.84792835181833,21.82412929552504 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark56(0,92.02353931734193,-0.01941766204247808,-17.303565348997367,15.803565348997367 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark56(0,92.41843504796785,-0.012697345747561317,5.8918193722015255,-7.462615698996422 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.115179494893,-0.05159451283414084,1.0135904573125165,-1.5497347231936092 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark56(0,9.332624804699364,-0.004895845282649377,9.000429788591404,-0.11104306192567392 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.36866079268867,-0.021292611320615093,56.64874335163686,-110.2095382047176 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark56(0,-93.74221049197745,-0.058669081227062055,7.502319402033526,-43.63864236814732 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark56(0,9.377727883981265,-0.013685171890964923,-31.575784280819448,1.1125181950469205 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark56(0,94.36023332617775,-0.06060902492704656,-104.72785384900094,34.53695176582326 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.54334294042856,-0.05012839468490865,27.970613296221643,-62.81565481884912 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark56(0,94.56141525561047,-0.021093227123770555,-100.0,86.2446300028819 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.57434151197631,-0.03724216942442106,73.98198358941387,-72.49996113840389 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark56(0,-94.68156087317892,-0.1556626538140313,0.9370575089836608,3.3567430117817456 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark56(0,-95.83502502254149,-0.021162615122439332,-97.85869399470403,99.42949032149893 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.00919157467129,-0.06236633441486704,33.06013988504489,-34.56013988502851 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.655420793508243,-0.011472862474027049,5.149341873828707,-2.0442163680123002 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.60258566925765,-0.06204676004043286,-110.37765986105916,17.860039717303763 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark56(0,-96.81126286960999,-0.003400388335048854,98.46502856402721,-16.888176446707647 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.26034920951493,-0.04632990883545671,8.73090499641884,22.669850352797972 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.32692939811115,-0.03558592230539047,-3.5109011751558725,3.5109011751558685 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.41246005984178,-0.04282792540361199,-67.58218346974549,20.068956711759803 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.43984797313828,-0.021538442367914128,-14.222015265625146,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark56(0,97.528165276238,-0.04041890475444995,-78.2755372089438,79.8463335357387 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark56(0,97.70534052761022,-0.01532463692974817,100.0,-93.0316163388652 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.78362250753159,-0.01566881294281038,0.10990691452455437,-271.547850795096 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark56(0,-97.95395440800911,-0.03836476193453227,28.959807303346253,-30.53060363014115 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark56(0,98.1668464810363,-0.05214219734980964,82.33467339110655,-67.80581805736924 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.2415185517188,-0.0015642928722556793,0.005192690768825054,-100.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.834348667919617,-0.04946041271697734,9.620776212594839,-9.620776212659608 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.34867615470284,-0.009900492043801723,-1.3461305176782241,2.725753204931666 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark56(0,98.50680048906486,-1.1102230246251565E-16,98.884258959803,-97.31346263300811 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark56(0,-98.6521598458858,-0.047741626473610604,56.0818561870317,-100.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark56(0,98.70534564362998,-0.01159349830148404,24.144919974983615,-22.57412364818872 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark56(0,99.01592282463778,-6.314038974485367E-5,100.0,-98.5 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.23473014295732,-0.05476037475006794,79.90601676358523,-79.24159304470227 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark56(0,99.37773062278045,-0.03662995476051685,-13.062285171231057,11.491488844436162 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.44902304087056,-0.05154957423083072,-43.55510574831497,44.22112020442559 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.5012280945744,-0.06106425854346537,-11.602515664698966,10.031719337904065 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.5744915549048,-0.005602578284431505,-99.62046220521896,98.04966587842407 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark56(0,99.72880672230703,-0.1561557821215877,-82.68472660770824,-0.5675787558980315 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.73872971216143,-2.7755575615628914E-17,49.91435639465631,-49.91435639458028 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark56(0,99.82494415491924,-1.1102230246251565E-16,91.86186164224257,-93.36186164224257 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.82778288294321,-0.5291747276056333,26.292655430061117,-57.83100248466678 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark56(0,99.93841540287004,-0.012316827473247203,100.0,-98.5 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.94385810659561,-1.1102230246251565E-16,-4.130537963128263,0.3802885582499897 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark56(0,99.95568588618009,-0.041187074598277376,16.699614772619956,-81.49392616839852 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99269961353174,-0.11446229286875285,0.0016273628423961622,-29.84678662013422 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99452642712478,-0.01845031005388319,52.63132723791749,-52.63132723791749 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99795912574923,-0.30062460209512976,-2.5789609832420513,2.578860913242703 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99995523768484,-5.095380521721067E-7,40.71613053659963,-42.216135734625865 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999933560052,-0.05724208131989991,-95.7316794576018,97.30247578439669 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark56(0,-99.99999966740873,-0.021907807285159994,100.0,-98.50000000000057 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark56(0,99.99999969284003,-0.033684443956864984,48.15189313126418,-46.65189293066498 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark56(0,99.9999999994376,-0.04938111650338334,-13.749447250917452,12.178651367524477 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,0.041844731508092536,-0.046995642318933356,-7.582985954567752,-27.60735713853117 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-0.06036377223350797,-0.026008868680150732,-80.38920637019204,26.780130529200637 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark56(100.0,100.0,-0.016945419493232233,-82.78966825908287,84.28966825908287 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark56(100.0,100.0,-0.9999999999905267,-1.658612374268383,2.927886102371649 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark56(100.0,10.17591767439742,-0.09882960749152256,74.44097038132882,-75.94107130248689 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark56(100.0,1.4210854715202004E-14,-0.031744288070077675,66.7947524625195,-66.74090294070703 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,31.674644103678197,-0.010490963142691621,83.46090444802529,-84.96090444802529 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-42.66102882254236,-0.03565207659000377,20.136451994386686,-21.70724832118158 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-44.925570314882805,-0.06043648090230576,-27.116406511687256,26.124641041965965 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-51.90041649585387,-2.896147097125982E-14,-97.89152304322872,38.9594261270401 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,52.216122748678956,-0.054776379979252825,-0.7816867767895918,-18.085968821747212 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark56(100.0,59.47420007310983,-2.7755575615628914E-17,-41.76244942852986,41.76244942852986 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark56(100.0,-81.13223772958082,-0.03365932903591335,-8.889612017328659,90.24702316193913 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-86.87253527567663,-0.06058405639433236,98.5,-100.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark56(100.0,99.9221050218149,-0.019343641426034175,0.00950130151202881,-2.091211539561365 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark56(-100.0,-99.9999259342016,-0.022348540738816487,2.4669036327685543,-1.8961547992218688 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark56(-105.77932050809824,16.21334144816433,-0.03072201842637412,8.947743534549176,-10.518539861344081 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark56(-1.0681543548180417,13.274134524439601,-6.163960772967079E-16,-13.050790557149949,11.550790557149949 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark56(11.156437058920687,0.9819471813863874,-0.03608988332821458,-28.834109213991045,0.17555394494072374 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark56(-1.11730073379097,-2.5570243029771538,-0.04489081261268955,-47.80725614305679,27.293038538625453 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark56(-11.336172805052833,-43.74931614685737,-0.016712862079745983,12.294908417788406,-29.6200757556366 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark56(-1.138455345870795,-0.7413498881608547,-0.04893585173563669,-76.76827909903395,75.26827909903395 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark56(-1.1393420606917886,-100.0,-0.06159544143569207,9.598797501864919,-11.098797501867239 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark56(11.79113390298669,100.0,-0.035165923863238024,91.14792485891496,-32.93132760007657 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark56(-118.06700463278656,1.0233080705599844,-1.7763568394002505E-15,85.94860295634722,-87.33764971368532 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark56(-1.2564163836706883,-0.5285422574629758,-0.05245896019120464,63.311155538587094,-7.795548824625046 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark56(-128.80141281244505,178.9835853491369,-0.03636110042369417,-101.47696811531856,72.06304824682653 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark56(-14.2088179568253,116.07598792860081,-0.0056869508963088514,-6.66441651099818,-15.566561265201667 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark56(1.4494747534854469E-4,-86.29888454725777,-0.05946582151962282,23.200933200375886,-23.21466411601817 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark56(1.571152271651787,1.550455310800034,-0.014002749461402073,-8.897822345363657,0.17653716446849305 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark56(-15.902107975606059,-1.0365837734479548,-0.015849869792351447,-45.76493753869467,12.060663110497138 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark56(18.062645933620686,-3.633185688533327,-0.03790439357448716,76.767330416142,-95.31458811193198 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark56(18.52307504703072,-44.57648659338376,-0.027397931437209685,-2.432738601226319,6.784597267678862 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark56(18.779577953226955,-84.74815898426225,-0.023654596738124464,-11.35795915573749,3.221352638396823 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark56(-19.055581571920232,78.11589252526099,-0.020330401577851404,-49.93843264535287,48.43843264534571 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark56(19.362293144751845,110.26124955220837,-0.1792859355066727,-50.711038886117755,43.34483973066932 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark56(20.561924656401967,73.00353861113027,-0.04693046289445446,98.45276988086134,-52.57079892228545 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark56(-20.70955070224155,-4.722295351559347,-3.3716268368874965E-18,31.67141951181952,-31.67141951181952 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark56(20.86691569117082,-12.411008936040645,-0.013852063067108317,42.79334934202586,-62.388394405798216 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark56(-21.762056218485014,-27.912843457102028,-0.05052914844892692,0.3594654737597931,-4.014800900735137 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark56(-22.786416400478803,-7.504035614614793,-0.03578078954997037,13.451647347447535,-11.951647347447535 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark56(-25.26087294625465,-100.00158183027301,-1.1237114754626688E-6,71.90307820088837,-48.19776530560356 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark56(-25.2856939480712,-0.12620574515863936,-0.02068090312029057,0.07238372220923367,-21.700960918455188 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark56(-2.5490770489173774E-10,2.486899192247329,-1.4674001450489568E-15,-87.51236528485899,87.51236528432756 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark56(2.6381887153783776E-13,0.9999889969040866,-1.2822647496503945E-17,16.358925069700476,-16.358925069700476 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark56(-2.6656292264430186,-2.3688925263404883,-0.04486155004500606,-20.683507568795022,0.07594438813485763 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark56(26.714121490804253,-11.993344685770422,-0.03438066438103684,0.03847318271562017,-40.82834369032462 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark56(-28.887382527144197,-25.804389945356522,-0.06208882972823215,-0.5844098095153072,39.27167861040545 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark56(29.49990422214526,0.01958204702556543,-0.012908242965693262,-100.0,100.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark56(-30.111137644696967,3.9094011383107556,-0.010828842596814318,90.93231499417396,-92.4940214901897 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark56(-30.542940719793105,0.4247088819178604,-0.46101171031198446,-77.13188354658253,62.695996624811315 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark56(-3.1391506797150686,0.9515678680813173,-0.019098865765981042,60.02230089417524,-106.83198103149135 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark56(-32.5392332322754,-18.491339215419366,-4.440892098500626E-16,97.63054559842652,-85.8853124665337 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark56(-33.84750829106012,1.746643114366563,-0.056351839422676075,0.07714839103071469,-20.360714018902858 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark56(34.74078844818542,-0.1749868728074162,-0.04470906359485194,38.90427137087033,-55.48659644784084 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark56(-35.332350645650756,8.212638215717364,-0.05376389059193685,-4.01031483786972,5.51031483786972 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark56(-3.610513818918627,-4.145888259936666,-5.344510319281986E-4,-96.0921583149074,97.5921583149074 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark56(-38.34185154355457,-22.18468605088107,-0.013439669603273086,35.7896276571363,-69.3023495844781 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark56(39.39306975435627,-55.44239459619502,-4.440892098500626E-16,14.079721766620494,-14.079707006755456 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark56(-40.04700015424745,11.588076990977788,-0.03334977001668846,19.641037638417885,-44.7517665100525 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark56(40.08802403532383,-85.8317563891152,-0.02163514041394421,0.011444860409286451,-33.14655679627886 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark56(-41.73904810578642,27.402422132784878,-0.008458745035977988,-9.285678775697203,10.57796497303708 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark56(-4.2019305411107375,1.2000758471902695,-0.002365854951733159,-58.0554748519041,97.9012587236948 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark56(-42.24456897354085,-34.94251470381495,-0.04219251337728039,-39.090958238179255,14.26229695845333 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark56(4.236212367742661,3.601918272342417,-0.06106579940038488,-56.94177966928253,58.44177966884119 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark56(-42.44328713518363,-100.0,-3.7525140878756445E-25,-0.04971766083793612,31.594332885354294 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark56(42.76883507664536,55.117982385016205,-0.05983834216236204,5.570944658221961,-4.088640130566105 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark56(-43.06899244560413,-50.471367153595786,-5.551115123125783E-17,57.8817988057781,-57.9456862632984 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark56(47.71955408759898,-44.091985077526125,-1.1102230246251565E-16,-54.17752877133135,15.873132929388035 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark56(-48.048764734144996,60.394670544807354,-0.0467305999964841,59.77200824428529,-61.27200824428529 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark56(-4.855385455766774E-5,100.0,-0.006991598075062003,-100.0,100.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark56(49.02448356281559,34.26337094851539,-0.006034096414764489,-73.02881477803393,56.004438402978934 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark56(-49.2187740713684,-99.99999931496784,-0.23492326849126927,-26.41940867436545,27.951973285790096 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark56(49.913490310914895,40.451119975716836,-0.041957336181732766,80.55488099151961,-79.38101750532593 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark56(-51.924613107786534,-29.847116303353495,-0.013849707868821792,-4.830673177958051,0.001494261302901629 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark56(-52.11924458062615,3.2331700868029216,-0.058347370839472834,-91.32623930679968,89.8251869286786 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark56(-52.32621824035093,-35.77395327968107,-0.011088604496729382,-28.447773436944956,29.947773436973332 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark56(5.267513387467987,-64.668736080603,-0.04878450848826797,78.05215877873057,-76.43461987500541 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark56(52.70453116501409,1.5504679525652847,-0.022993737701166195,-87.17713360720467,7.032317662526079 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark56(-5.381904899891701,100.0,-0.21752848772585623,1.8893264359113482,-1.3896182653559344 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark56(56.542741624356815,12.753022165685557,-1.1102230246251565E-16,20.334082333764705,-18.764681373404617 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark56(-5.714302393502059,43.92681689325696,-0.05122533857775043,-100.0,99.11986499721883 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark56(64.20445966420783,-26.363094638370825,-0.04508027522562157,-82.27734759720457,94.4276135084053 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark56(65.06471817741487,-81.03693316755705,-0.04170071933240515,-79.4505676710441,9.139085594420477 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark56(-7.0237561650039355,7.507839804549221,-0.020067219538023356,99.99986790443577,-98.49985604502842 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark56(-70.35707191507062,-15.107736539965433,-2.5887208471187315E-15,-7.5874597785265685,0.20702532502912777 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark56(-70.52631652902437,-1.0003635918197837,-0.013346818419347291,61.051585692095486,-61.00006893091854 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark56(71.37485864831496,93.10570039904866,-0.055301487755462175,15.759472329337067,-14.222205334857572 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark56(-7.263211236454848,-24.114937822112665,-3.725497869193166E-5,58.988585255677066,-60.55797536845225 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark56(73.8217326881757,-21.805570317832473,-2.7755575615628914E-17,46.927759829419855,-48.427760264747604 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark56(-73.82864545263092,-52.96617475308842,-8.097189191905458E-4,37.501752400990476,-35.95572381540976 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark56(-7.788933580651094,100.0,-0.059569700687315014,87.28096481220587,-28.416946161056206 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark56(78.01321467518687,-0.026268434420825493,-0.9986766966020086,-85.18274715044218,99.62394710160456 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark56(-79.13441609163527,-100.0,-1.0860491783603042E-4,-0.05118198250058235,30.693823141081765 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark56(8.358289998447702,2.6282911524097496,-0.038530172249458434,-84.75242940610057,4.588683666114065 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark56(-84.73189074020635,35.88538519378079,-0.05818357397901006,18.750555623461025,-61.19283136465181 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark56(85.03399353761613,-38.89400871750937,-0.017183239609668943,1.7022110302178408,-1.849984376541471 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark56(8.522971123576374,-0.9853792535579393,-0.046064904455199146,-0.36929914882222253,44.61082904338437 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark56(-86.07183330597678,-28.480112861171122,-1.1116727080139819E-16,90.24264683253541,-88.67225895075312 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark56(-91.85851669642557,0.17731705431447153,-0.02596226829832187,92.43212685995874,-93.93212685995874 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark56(9.427672490885127,0.04756259351462287,-0.05969024607495067,-1.114595597963937,-2.0397495920373676 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark56(-94.55371164307192,90.36823344242706,-0.00455531122034716,-57.61121520941889,56.04053592923545 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark56(-94.58396424950068,3.6722336392946673,-0.03458787781514239,66.09814916765104,-54.81603110906099 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark56(9.689828292511978,-22.96822099484222,-1.3832591758122607E-13,22.560703534599874,-23.849734170675255 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark56(-97.2579650205072,83.62756121079352,-5.551115123125783E-17,-39.90109269937394,25.465176267458432 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark56(98.22870003478069,23.4593646597492,-3.754532467739986E-14,16.711629671538926,-16.745714136191317 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark56(99.3088599118143,3.6290620086547847,-0.060393597868081766,100.0,-104.90251202164384 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark56(-99.99087508117648,-100.0,-0.034264331318138254,8.789645628595583,-16.932475679349807 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark56(-99.99999999779097,100.0,-0.059612012836846896,-21.673789052144407,21.673789049471726 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark56(99.99999999999997,38.90930932920157,-0.001101281474623128,-11.852466273280369,10.352466243890794 ) ;
  }
}
