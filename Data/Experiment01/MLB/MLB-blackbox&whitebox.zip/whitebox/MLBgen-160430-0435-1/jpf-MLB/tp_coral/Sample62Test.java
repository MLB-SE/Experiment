import org.junit.Test;

public class Sample62Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,-1.5052573234464575 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark62(0,0,0,70.09351510047378 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark62(0.43492000555244986,-2.220446049250313E-16,55.64798382755514,-35.88328198776443 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark62(0.9109288149262714,-6.077163357286271E-64,95.50810172586182,-65.79756838540251 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark62(0.9292470272949523,26.762563486163415,25.79843140170117,-2.5257917322241792E-17 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark62(100.0,0.004955323285201815,-66.32616875663862,-95.60005962877561 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-100.0,139.759475851223,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark62(100.0,-1.0010415475915505E-146,100.0,100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark62(100.0,1.0440487148797639E-53,-87.33524778260907,-100.0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark62(100.0,2.1684043449710089E-19,-100.0,28.436905649180883 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark62(11.048580990611967,8.456579229266453,28.109166882443535,44.67805704930902 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark62(1.1284129623772143,18.405045818559735,19.534609560592497,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark62(13.997682883885481,1.0691058840368783E-50,-99.9235933151669,33.95446717334983 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark62(15.373479718200661,1.6867516709168837E-80,-58.362002270850326,-79.69414195858542 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark62(17.078196446897486,-2.483743188651985,87.48614466533756,-20.605897496603937 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark62(19.32795855755245,-1.734723475976807E-18,48.58428601378697,20.98559168421916 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark62(-1.9968376725926618,97.45709320579456,-2.977628411807686,-68.41855673104406 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark62(20.60103766661838,68.32570841324016,-91.74952239022211,-19.869348756599052 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark62(30.27079883482357,-5.421010862427522E-20,12.933272451896576,-99.99943770504206 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark62(35.60072721414994,62.87822605675507,73.89504883801516,28.119581630998255 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark62(35.733992183449516,-31.028725932354106,83.2782697435556,60.15105657010747 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark62(35.79749006364545,1.038413688496149,-59.84574486034937,-43.21238586059752 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark62(36.718078611700406,33.562509397834305,-36.7031004971496,80.16237643640497 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark62(3.8654115256343573,7.105427357601002E-15,89.84645222668777,-92.78671535810568 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark62(39.243089331893884,88.0823085544898,6.306396622447409,-90.58299696833608 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark62(40.03793457018179,13.05789021303218,72.56811049794445,-5.018687793593486 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark62(47.40368065999701,4.3368086899420177E-19,-62.94929097811961,94.09352840172984 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark62(48.847371074000414,8.552847072295026E-50,-100.0,99.48795950647893 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark62(54.972975188917786,2.3843926933954265,-96.36142756086589,85.08138541915139 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark62(57.66883500743674,95.42453272031278,-10.201723035743399,-35.303592610596766 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark62(60.28080429610256,-10.808970308206682,38.34460778750065,-40.676859982308414 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark62(61.324937424015445,-56.78681853569587,0.8329293085794944,67.10491694337043 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark62(63.86422165120209,-18.537143768800448,-41.08732478356585,0.4977080461196124 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark62(-65.59848470876085,31.1574865754865,-33.586932425117936,57.88085084898444 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark62(66.96538227370087,-29.01983486727282,-6.7059505455829225,89.09970499004442 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark62(68.33748572274851,72.85302324778968,73.88344488447837,33.49658542650013 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark62(74.43228004957513,-37.901593053635374,89.05071258672695,-52.52002559078719 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark62(76.41345783924326,-2.0880974297595278E-53,100.0,-79.34410947768302 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark62(82.67354776075092,0.0,79.16880966454934,-97.17572220008176 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark62(8.607916577293338,48.14102042768657,31.27654883720021,25.472388167779698 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark62(95.07353737731455,-96.84298906279824,13.009368013774871,-7.352203013228192 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark62(97.78114146038342,-12.384772103117768,81.1378530878813,79.3913828592176 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark62(99.24113521711226,1.4225655996704496E-160,-100.0,21.17119762541138 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark62(99.34074744297338,-96.10843423933939,35.03709274939582,-1.0336319411424864 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark62(99.91821512496885,-5.551115123125783E-17,34.86046392380132,-32.19215613041881 ) ;
  }
}
