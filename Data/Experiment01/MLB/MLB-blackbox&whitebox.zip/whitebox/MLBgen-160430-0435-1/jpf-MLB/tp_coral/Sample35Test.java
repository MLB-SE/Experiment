import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(0.0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(-0.749658983352326,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,0.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.07555031388738 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.191406249999964 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-40.19140625 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.2393871720953 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.3052622907009 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.4499088270562 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.5173287861012 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.55738904642 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.6850667668787 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.743988438096 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.8737724745959 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.9562658399748 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-709.9774220278008 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,710.4552971537718 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-712.6695087273342 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-715.9721714849097 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-716.2737655415409 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-732.0753031880528 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-740.734247551435 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-742.2980504529714 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-743.322382824028 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-744.166683772926 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-745.9372957133528 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-746.0000000006598 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,756.9206840971736 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark35(-100.0,-80.38281249999994 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark35(-100.32956097813124,-746.0000001652804 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark35(-100.34132583636246,-709.9484733809271 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark35(-10.121658566271748,-709.3176563786403 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark35(-10.125098323710063,-80.87919174795444 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark35(-10.22455360099741,0.0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark35(-10.253000303397869,0.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark35(-10.350931985866012,-12.984551839884688 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark35(-104.16208011069665,-746.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark35(-10.474421185866536,-746.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark35(-104.93088823904327,-724.883512931797 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark35(-105.24412787878619,-760.5382999417959 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark35(-10.528814671134896,-741.241410215814 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark35(-105.5629214849523,-746.382813218937 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark35(-10.637857370525458,94.81932601978315 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark35(-10.93445757498452,65.3926945636706 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark35(-10.992670616409248,-745.9998644812582 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark35(-10.993089264397689,-749.3909883043012 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark35(-10.99328605391547,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark35(-10.996565100208988,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark35(-11.008576657350687,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark35(-11.036596620034047,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark35(-111.52581860152823,51.930167551088715 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark35(-111.77685351845639,0.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark35(-112.00296451456258,-746.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark35(-11.251908223147808,731.9881747055991 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark35(-11.549395818598057,-746.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark35(-11.622810561884833,-746.0000110494537 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark35(-11.666941870724216,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark35(-118.13798142058272,-40.19140624999996 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark35(-11.948565648633448,-746.0000012238932 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark35(-12.037555931817167,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark35(-12.058603762741598,57.77303580006475 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark35(-12.211738604085014,-55.97644828603767 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark35(-122.71751742446688,-741.6319766284241 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark35(-123.56168343226597,-709.9999998299178 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark35(-123.60800787189822,-80.38281249999997 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark35(-123.98397066395403,-747.3828125001446 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark35(12.566370614360094,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark35(-13.142815592358062,94.95233459565014 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark35(-142.94175772381004,-709.3366982158681 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark35(15.70796326566369,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark35(-15.803029265519992,-709.7085382364494 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark35(-15.869466421686049,-732.8744872612032 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark35(-15.959501953243242,-745.6833791363789 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark35(-16.0217431731311,21.45461745252905 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark35(-16.042923365661288,0.0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark35(-161.1975825818734,-709.9393412159442 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark35(-16.13568645447046,-746.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark35(-16.145831591732698,-746.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark35(-16.340446100270114,-1.494140625 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark35(-16.48963005321096,-746.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark35(-16.494666561734846,-739.4872975913894 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark35(-16.533529229165396,-31.123130992282057 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark35(-16.65898738818035,-743.6148194417768 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark35(-16.71184251441727,-35.675950025042226 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark35(-168.04898424869975,62.103900688923375 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark35(-168.07619063405787,-768.2498060596423 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark35(-168.0774394825147,0.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark35(-16.83939244569988,-709.6685052364915 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark35(-168.95865029131673,-745.9986453457379 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark35(-169.44326018363952,-746.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark35(-17.080818151176018,0.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark35(-17.159327895758537,-745.9999960985374 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark35(-17.215788598272013,-716.5193476064859 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark35(-17.275030322234926,-745.9998527441693 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark35(-17.27614108383616,-756.115575234206 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark35(-173.97447785614403,-745.9999997543307 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark35(-17.623121823049573,-775.6725858321131 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark35(-17.76813618092561,-727.7385267207292 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark35(-17.958299945633854,11.77401380779213 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark35(-18.090100732648878,-709.1207196828634 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark35(-180.99350037714424,-6.412178067066831E-30 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark35(-181.0250534699923,-746.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark35(-18.111698402019627,-5.4554948689213205 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark35(-18.26172126050676,71.02050077117028 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark35(-18.50190794005141,-709.1951760927718 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark35(-186.12098072614722,725.7675101954242 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark35(-18.736608437369156,0.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark35(-18.761733905923876,86.30868810227511 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark35(-18.818446482950108,3.552713678800501E-15 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark35(-18.818726843682114,-717.6468617391089 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark35(-188.39487922824043,-709.9447514932721 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark35(-2.039644032203512,-8.63984693434459 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark35(20.606835461579237,-47.59535013401035 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark35(-20.64899291588182,13.49029871159992 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark35(-21.05353982878124,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark35(-21.13679055329723,-65.81743219490124 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark35(-22.205514087454034,83.254024140881 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark35(-22.36876098337062,63.26555976180876 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark35(-22.44929585507049,-711.6010940888622 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark35(-22.53775130573412,-721.0430203505709 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark35(-22.666401649415818,-711.3056471485337 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark35(-22.690926920968053,-28.848827109976 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark35(-22.73399847443917,-746.0000043324386 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark35(-22.847597948635304,0.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark35(-22.91080391921487,99.45587468216272 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark35(-22.923336668769153,0.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark35(-23.4692571249673,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark35(-23.482786219366062,-746.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark35(-23.50146118182397,-41.98421191525672 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark35(-23.564195446851812,120.443249659652 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark35(-24.069475785257424,-709.9134415493953 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark35(-24.22793553155016,74.86819201185887 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark35(-24.242775535313328,-725.5263171424901 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark35(-243.47715992571807,-709.4240283952395 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark35(-24.370126055965695,-746.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark35(-24.465845546102784,-709.795358060611 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark35(-24.737424434270622,-745.2171765177686 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark35(-24.87960546401895,-71.96451878136854 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark35(-25.376338042009337,25.750715664479927 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark35(-25.463178983797434,-58.87460328823095 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark35(-26.116067171237006,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark35(-2633.7294921946977,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark35(-2639.370088834459,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark35(-26.713546571978156,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark35(27.13586187163611,786.9122191192881 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark35(-28.333728691428718,-709.1427318344442 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark35(-28.349467390555816,-746.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark35(-28.36841131907326,-746.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark35(-28.52842054370581,-40.19140625 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark35(-28.538008264209154,-56.390844411086015 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark35(-28.54946681501424,-84.21326092693724 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark35(-28.563987974047542,-100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark35(-28.565263452377224,-746.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark35(-28.62231535888371,-40.19140625 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark35(-28.809185049657614,-746.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark35(-28.852056056152733,-24.048819229535724 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark35(-28.889042261272735,0.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark35(-28.951783569109494,0.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark35(-29.140283302911712,-709.0989471252949 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark35(-29.222935010542695,-735.9617747592183 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark35(-29.254067117472786,39.511951126049354 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark35(-29.29435605790938,-80.3828125 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark35(-29.337247418253067,-709.2101590678094 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark35(-29.46544248662035,-709.1146414811144 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark35(-29.47859775276271,-746.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark35(-29.570403277475933,734.1322786926763 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark35(-29.62987903303143,-747.1914063553522 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark35(-29.632075613259644,-709.8246541973779 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark35(-29.646516432696274,-726.5795215082985 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark35(-29.692040501387872,-40.02775156552494 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark35(-29.69217497782492,-745.999999999997 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark35(-29.746673421480722,-746.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark35(-29.797733154688302,-709.0526563307058 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark35(-29.845837663333313,-710.3406867116494 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark35(-29.84704249774314,-9.29143751980375 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark35(-30.451944067516436,0.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark35(-30.514098248806704,-746.0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark35(-30.523120810199273,-709.8704068521348 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark35(-30.655059614835263,100.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark35(-30.754942260134598,-725.3422202414737 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark35(-31.019199246661515,-726.9402299608222 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark35(-31.020204523364896,-62.42434979522 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark35(-31.12744841958093,-746.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark35(-31.147016422165947,0.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark35(-31.283445052678452,0.0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark35(-31.415926535897928,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark35(-32.07593101904382,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark35(-3.263229167908136,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark35(-3.3238531475156208,8.729886047811021 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark35(-3.4441998321362917,-746.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark35(-34.556610824435595,-45.76920084775076 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark35(-34.557522255188275,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark35(-34.61550174618438,-709.316729898643 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark35(-34.63588420107064,-708.0316322939709 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark35(-34.75858030546728,-750.0901695735257 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark35(-34.81832984345991,0.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark35(-35.110287487993546,0.0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark35(-35.1207317493772,-84.80419521680832 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark35(-35.219517217363645,-744.6833951618893 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark35(-35.30463609800512,-709.3152405458438 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark35(-3.5330559580970515,82.46586243205192 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark35(-35.43712550727601,-8.55556819959395 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark35(-35.45015107158321,-734.2004294574357 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark35(-35.530675541352835,0.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark35(-35.56987563618112,-709.0424049599615 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark35(-35.58172975174543,-8.188604703308329 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark35(-35.58718137785273,-709.6218638143517 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark35(-35.63633015822194,-738.1578396263629 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark35(-35.77848773714278,736.4724073840532 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark35(-35.82933886390633,-709.4670399604719 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark35(-35.88398309708434,-716.7363804301003 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark35(-3.5971908907619365,-709.8939825162677 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark35(-36.12458624377353,-99.9042920540165 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark35(-36.13204478879175,13.753688019167782 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark35(-36.41773172012191,-746.0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark35(-36.6279883318557,-78.17951873026543 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark35(-36.64646392075011,-746.0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark35(-36.84330598790206,-709.326968844475 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark35(-36.911230865167525,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark35(-36.97553940558649,4.440892098500626E-16 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark35(-36.98811909290032,53.074297965807375 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark35(-37.291445931469866,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark35(-37.329053934977765,-746.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark35(-3.75048933564797,-746.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark35(3.944304526105059E-31,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark35(-3.977190419905668,-709.4637688273928 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark35(-40.84070452646964,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark35(-40.86445321153165,-738.5435202153806 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark35(-41.03413344860567,-741.2354106371822 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark35(-41.33292707265079,-746.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark35(-41.569765561643536,-45.76868802307794 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark35(-41.58341080834662,-745.9999856885593 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark35(-41.654341307549664,-747.1914062510299 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark35(-41.674548562694945,-745.5222893223216 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark35(-4.167834582875599,-736.3268446418648 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark35(-41.68410076981388,-728.3938565945626 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark35(-41.689428061805685,-709.0453603370732 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark35(-41.69027351108543,0.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark35(-41.708781524369456,-709.8690590068638 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark35(-41.71190042255193,-746.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark35(-41.766843272627476,-100.0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark35(-41.98075100954103,7.336036647308833 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark35(-42.00294004912091,-716.9870506052754 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark35(-42.058344847603,-709.9827597546507 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark35(-42.17483256937663,0.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark35(-42.18616594500628,-746.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark35(-42.1902059203684,-746.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark35(-42.296029885892025,-709.8849595656607 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark35(-42.34296138519716,-712.0102765233938 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark35(-42.3444199686822,-709.737824173759 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark35(-42.346509499019945,39.22436530568481 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark35(-42.36900442535929,-40.19140625 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark35(-42.40849258541887,0.0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark35(-42.41523009597124,0.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark35(-42.42363518162209,-46.49455077201596 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark35(-42.55865513755731,-746.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark35(-42.565540033145076,751.8665810301292 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark35(-42.57163253417102,-77.95753232540505 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark35(-42.580024792605485,712.2235146835849 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark35(-42.63189422332523,-747.1914131936244 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark35(-42.637962875858676,-709.7373770425022 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark35(-42.68225751337663,-746.0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark35(-42.68564880330538,-746.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark35(-42.70099549286065,-709.9102019792186 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark35(-42.725897255005414,-53.064875383499555 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark35(-42.74104897773408,-746.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark35(-42.74772517540946,97.65355316697489 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark35(-42.747786295224614,-726.5895780245869 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark35(-42.7493684173546,-727.3541274015816 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark35(-42.75380208841882,-709.3084579105273 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark35(-42.75467487828575,0.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark35(-42.75572251998552,-730.283859263725 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark35(-42.76007841789766,0.0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark35(-42.769534301962246,-728.8499256771661 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark35(-42.811795651845586,-708.1314196297014 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark35(-42.846162526361994,-780.1771221849224 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark35(-42.86277110571462,-746.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark35(-42.86313260204632,753.2359326740198 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark35(-42.8751269515093,6.161600865212733 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark35(-42.90084191667197,-709.60248327739 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark35(-42.91626101362399,-14.098653025891567 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark35(-42.94872044823584,-746.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark35(-42.954660900169905,-746.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark35(-43.16533242225682,-32.252620187948565 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark35(-43.46918318010751,-81.10040486936903 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark35(-4.351557543715543,-746.413534353034 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark35(-43.622348273671264,16.663819104172546 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark35(-44.29742374976986,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark35(-4.48489554029581,-725.733036473386 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark35(-4.597472458885221,-746.0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark35(-4.609472621528842,86.58909258396085 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark35(46.11686532247796,18.792253890349244 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark35(-4.613695281613502,-25.547070409893877 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark35(-4.699576787271155,-746.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark35(-4.708659707875603,-709.6783514898317 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark35(-47.18751755179085,-100.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark35(-47.234599240555085,-59.675698793491264 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark35(-47.407884117990726,85.5816148033081 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark35(-47.517925140014825,-729.9630874995021 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark35(-47.644790153034535,-746.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark35(-47.67479598148863,47.71855927847341 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark35(-47.77534803557675,-746.0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark35(-4.7810572896995325,-30.67799482017854 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark35(-47.85794858555252,-24.394838275490358 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark35(-47.86729046032252,-714.0815080737187 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark35(-48.100096565160875,-745.5011650412507 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark35(-48.155971307163114,-98.49875952321206 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark35(-48.1662730867342,-746.0000002249399 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark35(-48.22211208552376,25.268816212453913 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark35(-48.23028945093384,26.584877248356804 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark35(-48.612410027242944,0.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark35(-48.66070838311221,-18.840465586116736 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark35(-48.69095685807763,-715.2814965516574 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark35(-48.696114072929355,0.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark35(-48.71960724768221,-746.0022535627938 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark35(-48.722351691820116,-709.5601530942487 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark35(-48.751038444939134,-746.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark35(-48.75333358115243,10.476249003950699 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark35(-48.76776000158345,-710.1380288162998 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark35(-48.77172850562657,-713.4172418372574 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark35(-48.86378225818853,82.5002863673412 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark35(-48.95416776758603,52.11663421096898 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark35(-4.924452594027358,-712.2794278148257 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark35(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark35(-49.33606887219817,-1.3217405738973111 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark35(-49.4062551749904,14.41365728344546 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark35(-49.70408010436622,-733.6496499044207 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark35(-49.70829601362085,-769.2169771778359 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark35(-49.70893107651282,-70.61594915100393 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark35(-49.75324002983884,-709.6979729737023 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark35(-49.77096070187021,-746.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark35(-49.772176225278386,-746.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark35(-49.79899201517315,-17.927953282111204 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark35(-49.82516824434143,-746.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark35(-49.84910354277345,-736.1766719737044 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark35(-49.884991420091396,-745.9994948752403 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark35(-49.885296667525544,-724.7945956147397 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark35(-49.89119004232971,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark35(-49.940375578314956,-7.278424421814394 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark35(-50.02554383665429,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark35(-50.081231266417106,-47.89528660835541 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark35(-50.10598571044282,-32.15640707707115 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark35(-50.117396564975046,73.00627316282711 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark35(-50.12415332645179,-709.1818110064332 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark35(-50.126069492331695,-100.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark35(-50.13108197662491,-100.0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark35(-50.14021824267891,-97.5949753654808 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark35(-50.14555683434337,0.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark35(-50.15664513314307,0.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark35(-50.16507912398318,-6.144446842667378 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark35(-50.20539122797085,0.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark35(-50.21175983136343,-63.58472975621914 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark35(-50.21819508451362,-40.03210886673729 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark35(-50.24599548718456,-746.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark35(-5.025376767546902,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark35(-50.80239721071966,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark35(-51.860661767438486,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark35(-53.23578281577552,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark35(-53.6203111736933,-41.46835833218214 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark35(-53.7060413174846,0.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark35(-53.836198582322005,-28.7741267113514 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark35(-53.8663492806575,43.18945129672156 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark35(-53.90556060222003,-709.4521042858358 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark35(-53.9154156977815,-745.9932869872874 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark35(-53.96823625649871,-709.9721534264551 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark35(-54.252508755684104,-746.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark35(-54.31231936652547,-33.3815859400987 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark35(-54.408839296243606,-709.7272602395824 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark35(-54.500101037074984,0.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark35(-54.60981952327888,-719.941869449774 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark35(-54.74559513778039,-738.2524873659087 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark35(-54.75464848051279,42.85371818990603 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark35(-54.761194811064094,-78.4421773143436 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark35(-54.80523727574991,0.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark35(-54.81976374197433,-21.67343123336427 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark35(-54.850303705207516,34.50447973835594 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark35(-54.90164632388328,-37.24158500942922 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark35(-54.9752415971828,-768.987898133873 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark35(-54.97540407585907,-763.8986340099315 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark35(-54.97831202636698,-711.8988730310957 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark35(-54.9800061678588,-69.64345967595763 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark35(-54.98050127846017,-809.7985091190687 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark35(-54.9807519072342,-745.9999996906996 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160041550047,-746.0000001750644 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160071033043,0.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160071033044,-717.3053403690301 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark35(-54.98160071033044,-72.13318265214636 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark35(-54.98182326726823,-63.974708760411396 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark35(-55.016092638006796,0.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark35(-55.020040960608796,0.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark35(-55.029451948271706,-720.7450725100771 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark35(-55.035700296614195,-51.9042173953365 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark35(-55.05151222908449,-712.1169786983208 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark35(-55.05620821346473,-746.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark35(-55.09409009984254,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark35(-55.13704248942817,-87.6311533904074 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark35(-55.14238997332738,12.350095501717806 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark35(-55.14584886038388,-741.272073887942 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark35(-55.14747900454762,-167.4717362325749 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark35(-55.14841274641697,-746.0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark35(-55.175008607462374,0.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark35(-55.19447556724148,-746.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark35(-55.213538557294186,-62.71666618489151 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark35(-55.22197714516346,-724.8333996630171 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark35(-55.24623131704912,-40.19140625 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark35(-55.25066148151085,-746.0000092304547 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark35(-55.261627013317515,0.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark35(-55.26932930366005,-723.5850710547553 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark35(-55.30523492713304,-738.1996652553391 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark35(-55.34729443255733,-709.3983109306811 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark35(-55.44363804005325,-7.286413550865091E-16 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark35(-55.44780252207172,-709.9902308493431 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark35(-55.48138605157021,-65.15716150734481 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark35(-5.551393259986021,0.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark35(-55.53816947713773,86.07708367699624 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark35(-55.64840836656006,-726.5107819611408 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark35(-5.5815375105660365,0.0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark35(-55.99796855174454,-709.4820035697347 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark35(-55.99991657224922,-1.2909638180754337 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark35(-56.00913412760018,-709.0363137298122 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark35(-56.036931758169715,-746.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark35(-56.06430198744874,-709.6786335904163 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark35(-56.10372306106514,-739.7355942797208 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark35(-56.174437697151134,0.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark35(-56.192576961228575,0.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark35(-56.19835292956654,-721.0689451858277 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark35(-56.21441189833354,-741.6652164904888 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark35(-56.216928002278536,96.2652283291176 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark35(-56.22758719482394,0.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark35(-56.23017339600173,0.0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark35(-56.233023860683026,-68.68117446942881 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark35(-56.23641549046409,-749.1914079720359 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark35(-56.25374894564197,0.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark35(-56.25750010498274,0.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark35(-56.3424181309791,-737.8795769106656 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark35(-56.34329147131025,-100.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark35(-56.36277851486955,-746.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark35(-56.40036241713691,-721.4386203816596 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark35(-56.40932199875057,-716.8986168937954 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark35(-56.431594358677714,-1.494140625 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark35(-56.47855118374066,-746.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark35(-56.514641711699475,-40.19140625 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark35(-56.53658420924401,-734.4629926517952 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark35(-5.795270777009506,-746.0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark35(-57.98929612904749,-94.67947704327173 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark35(-5.892926336975307,41.989651266069615 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark35(-5.925333920113519,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark35(-59.69943886731257,-723.2758044798771 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark35(-59.73034544984741,-746.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark35(-60.11858996577042,-16.943338480481728 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark35(-60.2639324756477,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark35(-60.3227157313146,-746.0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark35(-60.35737914468962,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark35(-60.47534709822797,39.731267117637515 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark35(-60.49214252168562,-709.1000051648053 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark35(-60.55686809130047,0.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark35(-60.589376060956425,42.75392126876383 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark35(-60.70549065464632,-40.19140624999604 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark35(-60.72502515515683,11.0828023880146 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark35(-60.864429298696706,21.054362775828935 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark35(-60.94542679389665,-709.6729422914254 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark35(-61.128428439279304,-34.15496297623997 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark35(-61.3547940421886,-709.8001274167959 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark35(-61.359994968858715,-709.1897642844663 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark35(-61.39617150574266,-709.0618397797725 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark35(-61.6074984751086,-746.0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark35(-6.166647779688162,-718.5692598254653 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark35(-61.685125761775936,-7.152748063281194 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark35(-61.73389335394087,-100.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark35(-61.87776928565896,12.499159464252173 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark35(-61.933146790061414,17.745742224307136 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark35(-61.933537725011945,-709.991898992522 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark35(-61.9646648531839,-746.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark35(-62.13978304415655,-746.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark35(-62.2105515791048,-755.5521057961356 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark35(-62.224935846373654,53.13904730131867 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark35(-62.63749411758326,44.516651564096975 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark35(-62.73866062836129,7.801069230252338 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark35(-62.77939982556422,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark35(-62.81435706391678,-746.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark35(6.283185307179591,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark35(6.28318530812525,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark35(6.2831891223581575,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark35(-66.00465686783787,-733.5296670993182 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark35(-66.09530518323395,92.67583692471163 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark35(-66.18766862798016,-90.67139213705477 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark35(-66.1931109199692,-746.0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark35(-66.20387486379475,0.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark35(-66.33932398208597,-731.1890028098886 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark35(-66.39071758366445,-1.2735908591952778 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark35(-66.39695880737582,33.10539035784922 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark35(-66.46667121708276,-753.6496430263423 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark35(-66.65108346763351,-731.5257472521757 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark35(-66.66467736385397,-709.5358295089668 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark35(-6.6707016927044265,37.66986857813936 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark35(-67.2150256177221,-100.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark35(-67.26164979113587,0.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark35(-67.2704124292961,76.19842734548268 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark35(-67.33038250503591,-762.4412783567061 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark35(-67.36961311042916,-717.361000747232 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark35(-67.49237530517243,-13.572323891570363 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark35(-67.53209976066614,-746.0000000057831 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark35(-67.54522204360211,-709.9130183791773 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark35(-67.57249385164776,0.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark35(-67.63905748876965,-745.9999989140338 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark35(-67.68979416579526,0.0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark35(-6.782262427581088,-87.3288078499487 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark35(-67.88915788863847,-9.893966429772803 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark35(-68.23565163966683,-22.332236781989394 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark35(-68.43312924411555,0.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark35(-68.4733025346056,50.76935371844061 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark35(-68.55750420411945,0.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark35(68.71232514136517,85.92999914945307 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark35(-68.83296922724323,0.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark35(-69.05130844483223,-746.1914062748743 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark35(-69.05647341138234,715.1994599803174 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark35(71.84082180649929,54.143129450885255 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark35(-72.3192996891781,-40.191406249997414 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark35(-72.39656782500685,-92.41557640390828 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark35(-72.45196584453446,0.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark35(-72.5571974071248,7.903195347957208 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark35(-72.56355766220173,-746.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark35(-72.58534604216564,-710.7487711232476 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark35(-72.5924248275777,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark35(-72.64473401061274,-732.2255875853326 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark35(-72.66682911639643,0.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark35(-72.69221076521495,-726.8703634521851 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark35(-72.94125585129478,-746.9749403743771 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark35(-72.9628463248571,-731.8938542499742 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark35(-73.10553264528141,0.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark35(-73.14894835331958,6.37126817986244 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark35(-73.15645251238647,0.0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark35(-73.28056673573778,-709.5014296248671 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark35(-73.52399747504421,-77.04303939405652 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark35(-73.54903430716567,-746.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark35(-73.59489486970054,-746.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark35(-73.67837707542941,-11.86500035803779 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark35(-73.75786608497894,-709.7739814347246 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark35(-73.82369808683391,-710.1789874617554 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark35(-73.82369808685101,-43.60073229985422 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark35(-73.82369808685107,0.0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark35(-73.82369808685108,100.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark35(-73.82678281984674,0.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark35(-73.82683763740332,-3.5922707327168553 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark35(-73.83115663186925,-732.1730712652842 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark35(-73.84853046105933,0.0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark35(-73.99939638270905,-745.2577597683116 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark35(-74.23096469546397,98.91727583451112 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark35(-74.40550499752459,-746.0000001241381 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark35(-74.55588427460947,-746.3828125034395 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark35(-74.72764313689908,-709.3575804205552 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark35(-74.73481118273362,-746.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark35(-74.83392094784853,25.733387728749733 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark35(7.486786080996936,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark35(-75.01339769967672,-724.7449858260363 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark35(-75.31647121155174,75.7807016257477 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark35(-75.33073383546821,-716.5258288587141 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark35(-76.24186487935667,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark35(-76.36867903556839,-45.85131375060525 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark35(77.87950107245433,62.41213494592827 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark35(-78.43428195541205,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark35(7.853981633974867,96.04608403501132 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark35(7.8539816353850425,-746.0012430649574 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark35(7.853981644102831,-745.9892136394602 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark35(7.854301268082654,-744.3021860342934 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark35(7.857769695774405,-746.000000111053 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark35(-78.62950863347031,-746.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark35(-78.69592443737557,-16.873224948206484 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark35(-78.75601953256239,-715.0114007046448 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark35(-78.77589128685268,0.0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark35(-79.04786022265809,-95.42871021445069 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark35(-79.07274358031266,-9.181902990375107 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark35(-79.19373066194247,-746.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark35(-79.30025159234309,-709.9368316776074 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark35(-79.33864802990904,86.86638879326489 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark35(-79.34069482722973,-709.4982460575154 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark35(-79.42164467082273,-12.876905569217229 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark35(-79.48580570154678,0.0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark35(-79.54640754394799,-740.1014188868136 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark35(-79.71630747852514,-709.3737072022509 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark35(-79.75434566784713,-36.305800945310395 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark35(-79.789977899909,51.5588104330121 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark35(-79.96528059883354,40.0358476969661 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark35(-79.99778048870542,767.4226501738713 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark35(-80.01687656995857,-709.1430868983524 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark35(-80.0231248219086,-746.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark35(-80.10187897516843,0.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark35(-80.2403171079909,-82.70485885453832 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark35(-80.4053574581631,-99.35875425912539 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark35(-80.54488278831292,-719.7458941522708 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark35(-80.76142890301125,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark35(80.88357098852029,1.4796161517136568 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark35(-80.9358058263446,88.3669827524327 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark35(-80.99230356203016,92.57857739869817 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark35(-81.04596543847416,-709.0590779952763 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark35(-81.35706551113009,-709.7345543350152 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark35(-81.45861752438678,0.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark35(-81.50858884787652,0.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark35(-81.61846287356332,3.552713678800501E-15 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark35(-81.67108833744032,-78.73508767881606 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark35(-81.78951637118215,43.315429202624046 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark35(-81.81909404248108,-68.63998638813035 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark35(-82.03993403167729,76.49349753379454 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark35(-84.89706084516799,-718.0266263831364 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark35(-84.9389345188597,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark35(-84.95159047787925,0.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark35(-85.08255724706272,-709.7436966806637 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark35(-85.1670339627863,-92.10342992380984 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark35(-85.46206932317165,86.24993001875501 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark35(-85.63154113126262,-1.1660684112585427 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark35(-85.70509485894758,-724.1006748168713 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark35(-85.7560637339426,-744.7448335664606 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark35(-85.97649176566988,-709.8787923769902 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark35(-86.07901986988887,-746.0000028632592 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark35(-86.09510096581637,-709.9044348330006 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark35(-86.26173398742378,0.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark35(-86.27798399286364,0.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark35(-86.34865896288204,-708.6266779652979 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark35(-86.35012624463701,19.110884853665794 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark35(-86.3913241642896,100.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark35(-86.39166370851487,-711.8433519292149 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark35(-86.39752724622845,-44.65914322655258 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark35(-86.70464684070592,-744.388071703952 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark35(-86.73086772898196,0.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark35(-86.81770394205532,25.462609978773003 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark35(-87.2369518595738,-746.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark35(-87.67902173740754,-709.8275278048147 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark35(-87.76387936978273,-746.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark35(-87.78356636128906,-70.66081096822721 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark35(-87.78580883486238,-72.2839029054287 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark35(88.43972141630437,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark35(8.853981636614876,-745.6632143492388 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark35(-89.05887165501343,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark35(-89.67124024146342,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark35(-91.106186954104,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark35(-91.17094235714185,0.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark35(-91.22900445144799,-709.1241242204908 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark35(-91.26758712107585,-734.4833864348033 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark35(-91.27813573769978,-709.9192770160244 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark35(-91.39188199705642,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark35(-91.3963564414409,0.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark35(-91.39713312583453,-740.2719186210429 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark35(-91.46816786813889,-709.3607021839847 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark35(-91.47517963775974,-75.85629162758964 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark35(-91.61542854171323,-709.3550294423662 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark35(-91.75601505790563,-75.56057638584343 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark35(-91.7859871812541,-730.08211415776 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark35(-91.79705813304489,-745.9728210626286 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark35(-91.88381013806328,725.2981928227262 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark35(-91.91383656558938,-709.0649886972235 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark35(-91.9432558715645,0.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark35(-92.02285041122302,-746.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark35(-92.02785028286141,-746.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark35(-92.13940245327103,-709.5738906253073 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark35(-92.20772594882601,16.142541091760634 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark35(-92.40521532924575,93.90838504688485 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark35(-92.66844317641319,-746.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark35(-92.67961312153827,-757.0979731033348 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark35(-92.6980140281304,-746.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark35(-92.84047743295152,0.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark35(-92.97660100957646,-79.0382776092962 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark35(-93.05477262834762,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark35(-93.2217547632708,-746.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark35(-93.2382051603728,-1.494140625 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark35(-93.53516903024706,-80.3828125 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark35(-93.60406221434118,-733.056728783564 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark35(-94.03607545172665,-76.18213866125265 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark35(-9.424900031081881,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark35(-9.446961888524452,-746.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark35(-95.23161308655948,-83.68384852445259 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark35(-9.530293103430537,80.19568461305076 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark35(-9.566049675557608,-40.19140625 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark35(95.78949194271073,-65.85014751382758 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark35(-9.589221547222238,55.77920355934759 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark35(-9.627813488515827,-748.1914064718204 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark35(-9.705639360090032,75.68738787502531 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark35(-97.43389771561444,54.247749563448934 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark35(-9.762387585925623,100.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark35(-97.70584048269417,-36.484497642649046 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark35(-97.76040099507695,0.0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark35(-97.78883942741783,-37.820810249561276 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark35(-9.780579425664769,751.507775976393 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark35(-97.82056193324391,-746.0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark35(-97.82191654415074,-1.494140625 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark35(-97.87356114308592,2.925838328452272 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark35(-97.88571457901874,-745.9999999999998 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark35(-98.01182238337452,-709.5326711637516 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark35(-98.15338872897131,728.1024245097788 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark35(-98.22098570327931,-709.6364299707669 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark35(-98.26298058955842,24.874358026377877 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark35(-98.26809356087756,-23.62641371975384 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark35(-98.30275025426539,-709.9991930235158 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark35(-98.31661364441766,0.0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark35(-98.37781776779164,-709.8920065636067 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark35(-98.480336827106,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark35(-9.850319223127826,81.65486829682814 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark35(-98.52340576172813,-709.833271985847 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark35(-98.53187661771388,742.8644190330756 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark35(-98.54754561647448,-39.01002485012926 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark35(9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark35(-98.67620758541071,-709.1273707678919 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark35(-98.78768386804309,-746.0000002285798 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark35(-98.86409739321364,0.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark35(-98.93289727868236,-709.9365967176662 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark35(-98.95643931556938,0.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark35(-98.9566291553992,-740.0581382931874 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark35(-98.957966818032,-100.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark35(-98.96379333907737,-745.9999999999999 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark35(-98.96389786058762,-745.9997389908834 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark35(-99.07996039246949,-15.440878379780706 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark35(-99.22602964573565,-709.3056372546504 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark35(-9.9259705063848,0.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark35(-99.30873496174024,-89.50586533258233 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark35(-99.35833627428985,-69.73355377275163 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark35(-99.48357372099905,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark35(99.51784713421694,91.27104109201335 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark35(99.98738477621339,-53.3855913408797 ) ;
  }
}
