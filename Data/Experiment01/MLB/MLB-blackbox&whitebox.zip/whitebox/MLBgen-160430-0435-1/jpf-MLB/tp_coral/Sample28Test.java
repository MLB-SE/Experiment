import org.junit.Test;

public class Sample28Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark28(-0.0166215578542932 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark28(-0.038771981020573776 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark28(-0.10164673368137755 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark28(-0.12235572148726703 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark28(-0.1395913585141102 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark28(-0.1479621462620031 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark28(-0.1656522167333918 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark28(-0.22348385146958094 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark28(-0.24639336230110587 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark28(-0.26510952478622585 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark28(-0.337532202976206 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark28(-0.3420041377219576 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark28(-0.37797422525581226 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark28(-0.4098152502050709 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark28(-0.45691517290535444 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark28(-0.4591863094965305 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark28(-0.4628342940924455 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark28(-0.5276654887191796 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark28(-0.5374865073881381 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark28(-0.5655251520227296 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark28(-0.5758462001909379 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark28(-0.6251475534073165 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark28(-0.6418078427470846 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark28(-0.6913473320829553 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark28(-0.709345159597703 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark28(-0.7099748548024394 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark28(-0.7128875606164229 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark28(-0.7544504167129134 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark28(-0.8013325435129843 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark28(-0.8264604416888517 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark28(-0.8491005334244619 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark28(-0.8493201491657913 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark28(-0.8555838505048428 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark28(-0.8576588674874728 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark28(-0.8647167664831272 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark28(-0.912407655745767 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark28(-0.9650574408439354 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark28(-10.010947755568637 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark28(-10.031344287656665 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark28(-10.111414528948785 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark28(-10.121457153052859 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark28(-10.171127556685633 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark28(-10.175687470245151 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark28(-10.20679466481154 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark28(-10.252581314873055 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark28(-10.252959181975456 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark28(-10.2689898479301 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark28(-10.288504166723271 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark28(-10.297206188265818 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark28(-10.314609777079099 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark28(-10.319748991508135 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark28(-10.33112659736895 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark28(-10.342568164868737 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark28(-10.362087897859794 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark28(-10.372137233548912 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark28(-10.403741577333221 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark28(-10.431755009525176 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark28(-10.522434924367957 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark28(-10.683677283413132 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark28(-10.687494794886376 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark28(-10.703022338755176 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark28(-10.706783280665988 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark28(-10.709800912564077 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark28(-10.749928026576555 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark28(-10.756981769150698 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark28(-10.7708061409014 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark28(-10.785548358874664 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark28(-10.790625090771357 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark28(-1.0870990077674918 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark28(-10.914581389315032 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark28(-10.915304693120405 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark28(-10.92012731995824 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark28(-10.969483902472078 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark28(-11.000032857481685 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark28(-11.00935469693249 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark28(-11.02286227898648 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark28(-11.060570735730678 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark28(-11.08223293917294 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark28(-11.099645177769574 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark28(-1.1151419568946181 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark28(-11.201360401862502 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark28(-1.1212787126366806 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark28(-11.234608044274893 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark28(-11.314556784216663 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark28(-11.330963558236022 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark28(-11.353177653820069 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark28(-11.37998924437818 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark28(-11.400688090005787 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark28(-1.1404460497219588 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark28(-11.428700176945327 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark28(-1.1451346506950557 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark28(-11.511688823350113 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark28(-11.549534949373992 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark28(-11.555013117273404 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark28(-11.617300847674315 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark28(-11.637033925655942 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark28(-11.703802232282527 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark28(-11.704481765836988 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark28(-11.706153178107527 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark28(-11.751982888599429 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark28(-11.762528293543312 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark28(-11.810610945129895 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark28(-11.810913455103233 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark28(-11.838582708237212 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark28(-1.1895805886388047 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark28(-11.912822992574306 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark28(-11.966677589848558 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark28(-11.975803369164325 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark28(-11.985785009208726 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark28(-12.034694011263497 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark28(-12.04201735983186 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark28(-12.042082602603315 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark28(-12.055432792090869 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark28(-12.062620743486917 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark28(-12.06821061504533 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark28(-12.10010856335802 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark28(-12.101487986482738 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark28(-12.156835490496576 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark28(-12.159800937320313 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark28(-12.166095605736245 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark28(-12.173373934062099 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark28(-12.219394960541763 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark28(-12.228201994743301 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark28(-12.242306659762363 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark28(-12.249366216936465 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark28(-12.25511196510783 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark28(-12.263197251972088 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark28(-12.304488754077084 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark28(-12.364131142302242 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark28(-12.374523570378514 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark28(-12.394385740402882 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark28(-12.40058685670293 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark28(-12.412532011903792 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark28(-12.415877262806646 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark28(-12.451292601506609 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark28(-12.474107361535829 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark28(-12.490023320721917 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark28(-12.49139955581964 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark28(-12.49547871935961 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark28(-12.513112674670992 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark28(-12.53530604001871 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark28(-12.550596287439703 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark28(-12.567537106230958 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark28(-12.599004346927558 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark28(-12.599341692422257 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark28(-12.631168261446305 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark28(-12.647514409401822 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark28(-12.73011014908289 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark28(-12.735543846616793 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark28(-12.77353537578405 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark28(-12.789155018684227 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark28(-12.81066911347834 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark28(-12.817922656636767 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark28(-12.859179468560143 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark28(-12.865100301290994 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark28(-12.870964971627757 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark28(-12.8888196880049 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark28(-12.921434275046309 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark28(-1.2950410449295617 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark28(-12.961234577485044 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark28(-12.968415345777757 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark28(-12.971801528334751 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark28(-12.989037953273112 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark28(-13.08681959988742 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark28(-13.155320350350323 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark28(-13.165219434206946 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark28(-13.187623140837147 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark28(-13.195759229864535 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark28(-13.214251234797132 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark28(-13.216651204885594 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark28(-13.221862272075427 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark28(-13.239641446723894 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark28(-13.247083123817504 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark28(-13.247594297492142 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark28(-13.248253590534745 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark28(-13.269736163205991 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark28(-13.29712168006165 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark28(-13.3056643108836 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark28(-13.401087392690812 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark28(-13.430616616453747 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark28(-13.451850280189092 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark28(-13.456400666940468 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark28(-13.464739425644964 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark28(-13.483744890381914 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark28(-13.494564520802584 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark28(-13.504665558987128 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark28(-13.523798747940518 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark28(-13.535944574577414 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark28(-13.539208019605198 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark28(-13.543265019392024 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark28(-13.590536788422796 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark28(-13.59507334639514 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark28(-1.3613767343226897 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark28(-13.61386488466026 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark28(-13.68111596445793 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark28(-13.716997312013575 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark28(-13.718241632387702 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark28(-13.71898944614378 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark28(-13.76254799624705 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark28(-13.822629151124573 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark28(-13.844680204418452 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark28(-13.862088889766895 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark28(-13.865211444801034 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark28(-13.89290835076089 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark28(-13.971373429873651 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark28(-14.032645844575981 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark28(-14.04746193300646 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark28(-14.068199141648876 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark28(-14.098690760826088 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark28(-14.123447642577602 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark28(-14.137754696474914 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark28(-14.184474814909294 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark28(-14.213172470944983 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark28(-14.229030951164944 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark28(-14.23950374344092 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark28(-14.244033076515493 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark28(-14.261653503357337 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark28(-14.26994550470377 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark28(-14.289572509312308 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark28(-14.290283296943642 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark28(-14.33907325446286 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark28(-14.34497700222444 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark28(-14.370833024495354 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark28(-14.376615884086604 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark28(-14.393081742411454 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark28(-14.414590167399254 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark28(-1.4429764817154478 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark28(-14.493416897996056 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark28(-14.496507151635015 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark28(-14.501630862910815 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark28(-1.4504449380880402 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark28(-14.515566325819478 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark28(-14.518932979481917 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark28(-14.537526664230853 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark28(-14.54600119174006 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark28(-14.568608447039978 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark28(-14.59750721143888 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark28(-1.4609178715943187 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark28(-14.62937061707514 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark28(-14.732215575912562 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark28(-14.755490557524027 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark28(-14.77662269788631 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark28(-14.800067821387941 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark28(-14.8026187230127 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark28(-14.887112609377382 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark28(-14.89022998641083 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark28(-14.896784916015676 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark28(-14.922058220559876 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark28(-14.9293347292151 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark28(-15.001386281769655 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark28(-15.029026533097962 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark28(-15.089194716440659 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark28(-1.5094623364705626 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark28(-15.112927278778926 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark28(-15.204398732597298 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark28(-1.520622209537521 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark28(-15.241417844156913 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark28(-15.255264131684882 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark28(-15.260352634660833 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark28(-1.5289396583681736 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark28(-15.300917684655133 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark28(-15.302028308813647 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark28(-15.308080908838178 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark28(-15.337425978757935 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark28(-15.38047647633438 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark28(-15.38827683967807 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark28(-15.391453004753856 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark28(-15.435572019131087 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark28(-15.438405167143031 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark28(-15.450012930170274 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark28(-15.458977697408073 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark28(-15.460074570271672 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark28(-15.493573339864426 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark28(-15.53228591750117 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark28(-15.556247665850137 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark28(-15.558625122161885 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark28(-15.583156441410125 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark28(-15.610844726188816 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark28(-15.63209582872787 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark28(-15.674506239798163 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark28(-15.6806171628308 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark28(-15.68227096819453 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark28(-15.695280160904957 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark28(-15.774742972671191 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark28(-15.775997942981107 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark28(-15.804703694622319 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark28(-15.820434458958161 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark28(-15.885440021918058 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark28(-15.89223812508645 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark28(-15.959324024128946 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark28(-15.962031407553454 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark28(-16.02694237662479 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark28(-16.100529725826718 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark28(-16.106973763491766 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark28(-16.11571058197518 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark28(-16.118826393780566 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark28(-16.15488188554626 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark28(-16.179291461325306 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark28(-16.212084656877266 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark28(-16.29088235380634 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark28(-16.31143487189874 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark28(-16.354078068097948 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark28(-16.391493233952886 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark28(-16.393279237128695 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark28(-16.3989708449688 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark28(-16.40112709469807 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark28(-1.6407708618723262 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark28(-16.443837879981686 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark28(-1.6446281741549171 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark28(-1.6471163969506932 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark28(-16.483301488339492 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark28(-16.540451583146364 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark28(-16.591389750451555 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark28(-16.603671164444364 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark28(-16.620297738828953 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark28(-16.620697640634745 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark28(-16.642099810942796 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark28(-16.709304565623427 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark28(-1.6741043277977496 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark28(-16.782937738212084 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark28(-16.78329943058816 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark28(-16.799484614793954 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark28(-1.6820781390793513 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark28(-16.8254236603471 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark28(-16.842101841916218 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark28(-16.88266962046376 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark28(-16.974403353202277 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark28(-16.976051912624683 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark28(-16.996024560861315 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark28(-17.009744307383514 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark28(-17.044076869273624 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark28(-17.048773505223892 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark28(-17.048917566606406 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark28(-17.05976997053868 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark28(-17.14527453902417 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark28(-17.15804254504279 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark28(-17.19223358635776 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark28(-17.229277231023005 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark28(-17.22941299241927 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark28(-17.25460843660575 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark28(-1.7282910271078578 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark28(-17.284940149028657 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark28(-17.301797098537634 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark28(-17.313847835337512 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark28(-17.316618219452067 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark28(-17.341991873326506 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark28(-17.34432080332084 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark28(-17.386850551683025 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark28(-17.391708034884417 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark28(-17.39349644070758 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark28(-17.432793919409235 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark28(-17.435954111473123 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark28(-17.46935368779259 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark28(-17.488754840722237 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark28(-17.54063748719119 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark28(-17.599052603445358 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark28(-17.687522205384013 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark28(-17.688814677130082 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark28(-17.720414790261387 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark28(-1.7722346430601164 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark28(-1.7781181675335915 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark28(-17.829059361169513 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark28(-17.869485024567894 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark28(-17.888106707740434 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark28(-17.907108742108164 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark28(-17.95861836809675 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark28(-17.96481943923503 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark28(-17.99108462198653 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark28(-18.0012577464518 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark28(-18.047618692760096 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark28(-18.048626069512892 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark28(-18.057389963110055 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark28(-18.05813942580994 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark28(-18.070379797317045 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark28(-18.076161092707892 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark28(-18.085498798499458 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark28(-18.14178375703881 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark28(-18.156420280512677 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark28(-18.158435591323084 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark28(-18.17315355057613 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark28(-18.174139976720483 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark28(-18.265731621716213 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark28(-1.828411848158055 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark28(-18.308937831124723 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark28(-18.311237829187448 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark28(-18.377863826354712 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark28(-1.8473150259968492 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark28(-18.505780229201847 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark28(-18.51076689055411 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark28(-1.8528161631375042 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark28(-18.530636019727794 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark28(-18.557339970807547 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark28(-18.56925692007904 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark28(-18.577703316262472 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark28(-18.65850344326934 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark28(-1.867167780091279 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark28(-18.69370784188537 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark28(-18.724350610527623 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark28(-18.837778740815295 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark28(-18.87039952542571 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark28(-18.884682173394978 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark28(-18.928156837360618 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark28(-18.968831833593214 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark28(-18.97933819485725 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark28(-19.022178779029502 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark28(-19.035954757505408 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark28(-19.051912597495743 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark28(-19.06384294387837 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark28(-19.068771208688332 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark28(-1.9086534301174822 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark28(-19.105459643041556 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark28(-19.147400703724145 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark28(-19.15069555827749 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark28(-19.174265670602736 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark28(-19.215675973746272 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark28(-19.216320313779704 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark28(-19.22195249844296 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark28(-19.247901407543992 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark28(-19.260245595710217 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark28(-19.34094594535847 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark28(-19.372630268116865 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark28(-19.40260274424365 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark28(-19.41634340518972 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark28(-19.44102720333494 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark28(-19.444483071750327 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark28(-19.473421753035765 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark28(-19.500509279529112 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark28(-19.50623168021059 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark28(-19.527467381026156 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark28(-19.57871422617849 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark28(-1.9631620714469307 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark28(-19.64847247499361 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark28(-19.67224333082666 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark28(-19.676930775930444 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark28(-1.974523052683793 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark28(-19.75960384963902 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark28(-19.768612195039225 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark28(-19.78185399134091 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark28(-19.790915106105132 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark28(-19.832682591320918 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark28(-19.838549952878353 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark28(-19.868756096038354 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark28(-19.885544483042978 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark28(-19.887084004574646 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark28(-19.904533244752784 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark28(-1.993270709690691 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark28(-19.937431846130565 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark28(-19.96859742460532 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark28(-19.988471676051446 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark28(-20.004943818537612 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark28(-20.018947985520114 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark28(-20.030879424987404 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark28(-20.038050061026553 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark28(-20.053658583114768 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark28(-20.123979518219755 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark28(-20.1414993572252 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark28(-20.1875465782978 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark28(-20.189586995518425 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark28(-2.035393031735211 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark28(-20.372782272080528 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark28(-20.383420809844296 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark28(-20.400689420331616 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark28(-20.456518634580107 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark28(-20.549657509781127 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark28(-20.574943359188964 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark28(-20.577254351516842 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark28(-20.580644448194292 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark28(-20.610201709382082 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark28(-20.620743051477547 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark28(-20.68065648138908 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark28(-20.75216378108111 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark28(-20.761741410275476 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark28(-2.079285163214095 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark28(-20.81424386216611 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark28(-20.84328098218262 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark28(-20.850108443508518 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark28(-20.853251903014154 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark28(-20.88870822670033 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark28(-20.896636604956313 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark28(-20.90417125906758 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark28(-20.955318830030606 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark28(-20.95846392539407 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark28(-20.995174179215923 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark28(-20.995267657539358 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark28(-21.019741629961857 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark28(-21.02657745631518 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark28(-21.026808939345273 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark28(-21.028056053365447 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark28(-21.02881321511765 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark28(-21.11096457620718 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark28(-21.119207496260103 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark28(-21.1259817842316 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark28(-21.141842755354617 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark28(-21.164929470480033 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark28(-21.173056613169265 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark28(-21.217159378521117 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark28(-21.23430380843449 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark28(-21.23872685432886 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark28(-21.24161633530035 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark28(-21.252102469891128 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark28(-21.289455556365695 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark28(-21.291135083374655 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark28(-2.1371102801718536 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark28(-21.412106367646416 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark28(-21.45132112106755 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark28(-21.486719005199916 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark28(-21.5265260646877 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark28(-21.53785352924504 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark28(-21.58094945665752 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark28(-21.584279853298156 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark28(-21.58782556878019 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark28(-21.690853415310272 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark28(-2.169772810940856 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark28(-21.698361660115424 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark28(-21.707053450773543 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark28(-21.724691778431932 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark28(-21.744065635935712 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark28(-21.74437195416303 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark28(-21.758516532006595 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark28(-21.763746664232954 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark28(-21.797079623151248 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark28(-21.83451235115494 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark28(-21.89074480343109 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark28(-21.895942426248354 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark28(-21.979961600956074 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark28(-21.99912038274941 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark28(-21.999194794174755 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark28(-2.200101464838113 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark28(-22.061742489235996 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark28(-22.06344633291242 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark28(-22.115053797430036 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark28(-22.13171529511358 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark28(-2.2167950103219454 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark28(-22.18811519205208 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark28(-22.227226630370225 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark28(-22.230627086816284 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark28(-22.242208683448396 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark28(-22.25083441987485 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark28(-22.260150170314105 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark28(-2.227487107454479 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark28(-22.286093766411113 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark28(-22.288766194270153 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark28(-22.33639723229537 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark28(-22.385482496330084 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark28(-22.388423560807553 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark28(-22.398260471444843 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark28(-22.40113060804427 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark28(-22.40877060458186 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark28(-22.41086778407096 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark28(-22.410977217542666 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark28(-22.428541025169267 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark28(-22.44782505161986 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark28(-22.45981675311846 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark28(-22.46819566790525 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark28(-22.498630658444156 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark28(-22.508142818216342 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark28(-22.513839357150985 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark28(-22.51779063516159 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark28(-22.550309121027198 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark28(-22.561072556832727 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark28(-22.6094246617087 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark28(-22.6803561866344 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark28(-2.2719848185956266 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark28(-22.72421727363924 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark28(-22.748232715610285 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark28(-22.766178045382517 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark28(-22.789355726334975 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark28(-22.814320630661356 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark28(-22.833252818997437 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark28(-22.86659415220595 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark28(-22.889541575028645 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark28(-22.913892673876873 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark28(-22.94200346016231 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark28(-22.96749225194992 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark28(-23.02340563174343 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark28(-23.033173651195142 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark28(-23.046016756054087 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark28(-2.3054340266203326 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark28(-23.068045017723946 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark28(-23.11663974354836 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark28(-23.125139317280286 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark28(-23.146803375365835 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark28(-23.153962510622208 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark28(-23.176806202516943 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark28(-23.178456790393213 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark28(-23.189053662414636 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark28(-23.225906440223724 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark28(-23.289823390739855 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark28(-23.311160789443505 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark28(-23.370028741122766 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark28(-23.38896158421761 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark28(-23.391719689804134 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark28(-23.39587552830487 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark28(-23.409931659666427 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark28(-23.416481515521497 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark28(-23.441870948876996 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark28(-23.448575997319537 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark28(-23.509085401648647 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark28(-23.55360260287715 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark28(-23.569162331564627 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark28(-23.60223198089095 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark28(-23.62139046674318 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark28(-23.64743039376404 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark28(-2.3650248489256427 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark28(-23.674324537120214 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark28(-23.70790017793884 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark28(-23.7129100605338 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark28(-23.764532279450037 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark28(-23.826387777948682 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark28(-23.840811333712566 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark28(-23.853781918644245 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark28(-23.859167959402612 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark28(-23.870892076423345 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark28(-23.87531349544159 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark28(-23.909214797699434 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark28(-23.926792827999122 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark28(-23.970377611609223 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark28(-24.041509396105326 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark28(-24.058481169983637 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark28(-24.070245754737414 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark28(-24.103277983431923 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark28(-24.10368575033901 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark28(-24.1204074025176 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark28(-24.1554446515579 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark28(-24.18677439012889 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark28(-24.2380510112028 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark28(-2.427521555504171 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark28(-24.327137910520975 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark28(-24.35677699546794 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark28(-2.440671172019478 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark28(-24.427333615657943 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark28(-24.486253679604246 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark28(-24.55980701938259 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark28(-24.59198362309077 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark28(-24.63735332669883 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark28(-24.643828416403608 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark28(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark28(2.465190328815662E-32 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark28(-24.65358468324355 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark28(-24.669741556797334 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark28(-2.4675764244798586 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark28(-24.704144346610832 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark28(-24.71393779843369 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark28(-24.74731480485626 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark28(-24.760867365983913 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark28(-24.76663995275625 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark28(-24.82382299214609 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark28(-24.843050939704042 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark28(-24.84613998295646 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark28(-24.87715217230992 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark28(-24.88321942948339 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark28(-24.905564001986306 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark28(-2.4917574408601695 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark28(-24.931872339179193 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark28(-24.973787260936405 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark28(-25.01257596867923 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark28(-25.063438478029724 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark28(-25.096871997948426 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark28(-25.133354688987765 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark28(-2.5161038984335278 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark28(-25.178604469067253 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark28(-2.517958176917759 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark28(-25.251349277240465 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark28(-25.287082704567638 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark28(-25.30929830602207 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark28(-25.345828446902672 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark28(-25.35715265670602 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark28(-25.38240430561727 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark28(-25.43138116576631 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark28(-25.4379464554455 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark28(-25.438390133434098 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark28(-25.4396182508507 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark28(-25.44190499415481 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark28(-25.458346623969533 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark28(-25.46393714890627 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark28(-25.483201224161206 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark28(-25.502882951884118 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark28(-25.554202888543756 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark28(-2.5577656804594397 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark28(-25.59718217540788 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark28(-25.600622011673167 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark28(-25.67606705572929 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark28(-25.731365809957737 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark28(-25.733477936821814 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark28(-25.82981696187514 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark28(-25.835590555312947 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark28(-25.862393278538008 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark28(-25.90478525246081 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark28(-25.97044204491317 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark28(-26.036217121817756 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark28(-26.049158699759616 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark28(-26.088971327496083 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark28(-2.6172194351601803 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark28(-26.20195385156478 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark28(-26.251244167877786 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark28(-26.269762919654994 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark28(-26.272419581418887 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark28(-2.634947191413289 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark28(-26.360370460503148 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark28(-26.369502295374133 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark28(-26.411448840230477 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark28(-26.4530977905804 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark28(-26.525919922003837 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark28(-26.587384300236067 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark28(-2.659143693460237 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark28(-26.59845253397171 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark28(-26.598944846061627 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark28(-26.627004080543742 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark28(-26.627766004359273 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark28(-26.66060786899247 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark28(-26.684645208571794 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark28(-26.68503637948143 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark28(-26.69544198025335 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark28(-26.697811658192478 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark28(-26.70553856277664 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark28(-26.745767549651703 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark28(-26.74827135466957 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark28(-26.769695066015657 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark28(-26.80000285077304 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark28(-2.6805218923013 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark28(-26.840818950725946 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark28(-26.86194520405121 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark28(-26.864080005122347 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark28(-26.92354396472905 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark28(-26.965894599608745 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark28(-26.96727582394611 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark28(-2.699027833790396 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark28(-27.013033968971428 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark28(-27.01597634924731 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark28(-27.016692494713283 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark28(-27.041629230319458 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark28(-27.118604766658464 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark28(-27.123413766733577 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark28(-27.13493993987241 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark28(-27.27868312742953 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark28(-27.285477364719867 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark28(-27.294727633564804 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark28(-27.330795088224463 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark28(-27.346840869226227 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark28(-2.737192256472426 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark28(-27.381381572657943 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark28(-27.397023608076495 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark28(-27.484028319704933 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark28(-27.50933151572339 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark28(-27.525891522272318 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark28(-27.568644129445687 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark28(-27.570395289885056 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark28(-27.654440295055196 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark28(-27.66072733980087 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark28(-27.68289343536314 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark28(-27.703411629771168 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark28(-27.705356869500648 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark28(-2.772676945889856 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark28(-2.777697324544178 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark28(-2.783537841358381 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark28(-27.84315868069909 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark28(-27.885666273531868 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark28(-27.91783271890928 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark28(-27.94349391369302 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark28(-27.96770780217402 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark28(-27.970390956699177 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark28(-28.005284887430307 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark28(-28.014232233354022 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark28(-28.038920997941702 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark28(-28.050562610016797 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark28(-28.087433855661615 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark28(-28.11811496620163 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark28(-28.119114103713144 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark28(-28.126775989128276 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark28(-28.139527117278945 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark28(-28.166247715427374 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark28(-28.16684968641124 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark28(-28.1673705483622 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark28(-28.215430230330014 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark28(-28.225353616651745 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark28(-28.225658527300368 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark28(-28.237325922559677 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark28(-28.241931236735113 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark28(-28.261934638272606 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark28(-28.270906214189367 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark28(-28.279418058227137 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark28(-28.3670375502537 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark28(-28.36836101915692 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark28(-28.37931234418467 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark28(-28.40485787622393 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark28(-28.4253782335321 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark28(-2.8487787394705606 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark28(-28.492288090422164 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark28(-28.50907169784469 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark28(-28.56649576363681 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark28(-28.56816515698746 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark28(-28.610911218011452 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark28(-28.664225597550043 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark28(-28.70196014964108 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark28(-28.703980688708825 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark28(-28.741603590336908 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark28(-28.771909417204114 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark28(-28.783577742036343 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark28(-28.800282275474444 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark28(-28.845772746922364 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark28(-28.866656080800794 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark28(-28.88595336792936 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark28(-28.898063181431468 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark28(-28.927147793706894 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark28(-28.92848706881017 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark28(-28.93750227237699 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark28(-28.946687991398505 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark28(-28.953721699080702 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark28(-28.966818957857242 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark28(-28.975619776436616 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark28(-28.98318234554371 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark28(-29.07964218222878 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark28(-29.07979739954294 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark28(-29.09178035413882 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark28(-29.09446047011383 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark28(-29.1113343851423 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark28(-29.1699459661197 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark28(-29.17953098594863 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark28(-29.19060572544592 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark28(-29.190886706636917 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark28(-29.20303135743616 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark28(-29.217333838422334 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark28(-29.267533508243247 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark28(-29.292374287934678 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark28(-29.318639714340406 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark28(-29.32897707861946 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark28(-29.33239111967157 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark28(-29.338020601203255 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark28(-29.355765313499276 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark28(-29.35617292735671 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark28(-29.370928321003362 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark28(-29.406399858113062 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark28(-29.4165151663355 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark28(-29.431223469136242 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark28(-29.449761956250867 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark28(-29.47300218736339 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark28(-29.484133174936872 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark28(-29.48948151784427 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark28(-29.4966619700825 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark28(-29.528194314731678 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark28(-2.9538814930207167 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark28(-2.9601033858459544 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark28(-29.623449652170123 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark28(-29.63623423573813 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark28(-29.66804093159861 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark28(-29.73814482405281 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark28(-29.764563104263303 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark28(-29.91850714186117 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark28(-29.933189287775264 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark28(-29.936653198223823 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark28(-29.985700391508715 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark28(-29.987069702028066 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark28(-29.991794370668728 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark28(-30.026129989754196 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark28(-3.003434161220369 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark28(-30.038995080564845 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark28(-30.097370855725686 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark28(-30.161416872099963 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark28(-30.186246862737846 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark28(-30.190813454928474 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark28(-30.200007549044187 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark28(-30.243744665946394 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark28(-30.254869586354573 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark28(-30.26825839482352 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark28(-3.0300325793399736 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark28(-30.342588388987423 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark28(-30.372090282969992 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark28(-30.429801131711784 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark28(-30.433384713940853 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark28(-3.045718838434425 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark28(-30.488275390768166 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark28(-30.500968521514338 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark28(-3.051856877002379 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark28(-30.53188227380572 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark28(-30.553415075733525 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark28(-3.064268295536692 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark28(-30.64392506862994 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark28(-30.70608415001324 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark28(-30.71126955410631 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark28(-30.71274205813546 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark28(-30.71503579951076 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark28(-30.744382476601857 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark28(-30.751656221425392 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark28(-30.76113422769015 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark28(-30.81154057495084 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark28(-30.818381693261358 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark28(-30.826247553622338 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark28(-30.841691042081848 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark28(-30.84627134880526 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark28(-30.848132840770816 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark28(-30.87559277592821 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark28(-30.904044205827503 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark28(-30.920222418032424 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark28(-30.937507493152737 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark28(-30.941418586993777 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark28(-30.964198845725093 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark28(-3.1012491267520232 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark28(-31.027166083087195 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark28(-31.056194797705245 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark28(-31.06315254945082 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark28(-31.06393331188451 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark28(-31.131496205773118 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark28(-31.153617622971552 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark28(-31.19409135876535 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark28(-31.216927226739827 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark28(-31.231920790544862 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark28(-31.26019741014359 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark28(-31.264639661449138 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark28(-3.1273489771356253 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark28(-31.275388409031237 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark28(-31.383049732498165 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark28(-31.415882448912825 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark28(-31.42288883236833 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark28(-31.428197429016635 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark28(-3.1431917743448707 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark28(-31.44278917895778 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark28(-3.148674236290276 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark28(-31.504710312856886 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark28(-31.534659102304147 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark28(-31.562706635968453 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark28(-31.616973355096547 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark28(-31.674408770176115 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark28(-3.172211188116634 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark28(-31.73701203782396 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark28(-3.174615200015765 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark28(-31.79836383678969 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark28(-31.81978306378457 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark28(-31.840937674395533 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark28(-31.861220364201515 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark28(-31.902079428902837 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark28(-31.911396273911635 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark28(-31.922343773831187 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark28(-31.92348377665857 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark28(-31.924795344598778 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark28(-31.95596564067158 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark28(-31.96074784489602 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark28(-32.01774619947517 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark28(-32.0484901646644 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark28(-32.05148642342178 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark28(-32.076095668068575 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark28(-32.08507433346162 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark28(-32.126846281164916 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark28(-32.139285459950884 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark28(-32.16470997966063 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark28(-32.17928430636718 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark28(-32.18177934923179 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark28(-32.18984712340114 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark28(-32.22365269594346 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark28(-32.24310503152013 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark28(-32.27039722939435 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark28(-32.283526863627785 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark28(-32.29590536387812 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark28(-32.301010068836746 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark28(-32.34877540778123 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark28(-32.37173460341225 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark28(-32.3821407543867 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark28(-32.38462483315219 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark28(-32.4048351559352 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark28(-32.40869935715655 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark28(-32.43236545971119 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark28(-32.46729178990819 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark28(-32.53928741140601 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark28(-32.556759935436446 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark28(-32.570719040777334 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark28(-32.5796335930103 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark28(-32.6066152080291 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark28(-32.62547195806222 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark28(-32.62912385327181 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark28(-32.64429687667206 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark28(-32.67063911667694 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark28(-32.678532427959865 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark28(-32.6985667274928 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark28(-32.71177154987306 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark28(-32.72022751700061 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark28(-3.286710170672393 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark28(-32.877897899976816 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark28(-32.884005902253705 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark28(-32.91192785636888 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark28(-32.93624937647665 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark28(-32.9728333309274 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark28(-32.986178063730364 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark28(-33.05483819022119 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark28(-33.07016602969503 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark28(-33.078687417768876 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark28(-33.08075752292534 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark28(-33.10765416238732 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark28(-3.3152846734640207 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark28(-3.3273977981775857 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark28(-3.328914205933671 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark28(-3.3293029695332024 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark28(-33.31990860012071 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark28(-33.34922285752393 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark28(-33.361362199701944 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark28(-33.389642171237426 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark28(-33.44606619036388 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark28(-33.45023111895095 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark28(-33.45231210759427 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark28(-33.46093453209879 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark28(-33.46402509109882 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark28(-33.480157802360594 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark28(-33.48721402825703 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark28(-33.511857603480166 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark28(-33.53384172419791 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark28(-33.550217806639225 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark28(-33.55531240508347 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark28(-33.56844386527864 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark28(-33.602366566756345 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark28(-3.3603867975137405 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark28(-33.687909210833226 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark28(-33.70750274318388 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark28(-33.72082396925332 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark28(-33.768419714216805 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark28(-33.79179938136157 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark28(-33.82479764528996 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark28(-33.86718390482804 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark28(-33.87204900730384 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark28(-3.3878116358533106 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark28(-33.894593834554556 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark28(-33.89912191539541 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark28(-33.9486752565479 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark28(-33.96163269424352 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark28(-33.963783857338825 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark28(-33.985925210086364 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark28(-34.063561978865266 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark28(-34.08157376095431 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark28(-3.4095761544776337 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark28(-34.139806213121645 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark28(-34.160090078570036 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark28(-34.186653524777654 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark28(-34.20429335904775 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark28(-34.21699016510205 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark28(-34.26489581752965 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark28(-34.266105045201755 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark28(-34.28636396604887 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark28(-3.430248411062678 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark28(-34.310922985262565 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark28(-34.3196960665622 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark28(-34.34648113652882 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark28(-34.36976199201402 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark28(-34.37327294888878 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark28(-34.407283160469504 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark28(-34.42742698277874 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark28(-34.43325807763769 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark28(-34.45576132074906 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark28(-34.47181594099662 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark28(-34.50810563712136 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark28(-34.52301700890794 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark28(-34.5351411877904 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark28(-34.621982644281516 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark28(-34.662913070473905 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark28(-34.663313828120906 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark28(-34.66456370125957 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark28(-34.7068018197444 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark28(-34.71756338046515 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark28(-34.751360048579926 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark28(-34.79527056403873 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark28(-34.79824149048818 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark28(-3.480973589350512 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark28(-3.480983608544193 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark28(-34.84177100627852 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark28(-34.843683573776005 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark28(-34.86978749679905 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark28(-34.87021118273785 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark28(-34.88889651288214 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark28(-34.92772399458404 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark28(-34.95306165370387 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark28(-34.95673555989758 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark28(-34.97253501493465 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark28(-34.98014858884741 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark28(-35.00586660949618 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark28(-35.022657101048125 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark28(-35.02407849716529 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark28(-35.05766012216161 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark28(-35.08842482408643 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark28(-35.09705720518981 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark28(-35.12424522356221 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark28(-35.16517680514201 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark28(-35.170888302124936 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark28(-35.19659431982005 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark28(-35.209990031043176 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark28(-35.22821699124722 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark28(-35.23054206570413 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark28(-35.28137918644762 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark28(-3.5296130040391773 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark28(-35.32823835807626 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark28(-35.33262042087111 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark28(-35.33908562972141 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark28(-35.34846035402737 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark28(-35.437074266393836 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark28(-35.4833745537144 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark28(-35.50287522735296 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark28(-35.56404732239706 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark28(-35.582387816113666 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark28(-35.591463910379304 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark28(-35.65195378753678 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark28(-35.741769524196016 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark28(-35.87668624291976 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark28(-35.879138739070754 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark28(-35.8868735495937 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark28(-35.948086917685 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark28(-35.95121649334901 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark28(-35.96876132571769 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark28(-35.98410130486582 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark28(-36.02302790840386 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark28(-36.0234355381126 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark28(-36.03227213793985 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark28(-36.049785047284175 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark28(-36.052559290970045 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark28(-36.06924215685026 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark28(-36.070117142601156 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark28(-36.10891190454382 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark28(-36.1502598276211 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark28(-36.15622824122961 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark28(-36.184376730323464 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark28(-36.185790639221004 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark28(-36.19484313580457 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark28(-36.32319875848058 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark28(-36.36633251187591 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark28(-36.367682294564396 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark28(-36.36962107696373 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark28(-36.37223867645911 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark28(-36.37713870840391 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark28(-36.50555248777356 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark28(-36.522093338687924 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark28(-36.52411654340657 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark28(-36.55001616159801 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark28(-36.57509120218383 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark28(-36.58473186497844 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark28(-36.61245756565441 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark28(-36.66054606191431 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark28(-36.67882896190777 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark28(-3.6685387903395537 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark28(-36.756236934044885 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark28(-36.76855100947225 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark28(-36.77992653455209 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark28(-36.837653469839694 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark28(-36.84073684008284 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark28(-36.86641835333497 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark28(-36.88772890555603 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark28(-36.89771473753094 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark28(-36.90367854093601 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark28(-36.942712179061864 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark28(-36.95856320473092 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark28(-36.96140742937397 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark28(-36.98223897145765 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark28(-37.00658377788426 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark28(-37.03493273005807 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark28(-37.07213733549344 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark28(-37.1097749088587 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark28(-3.7134262430413827 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark28(-37.13434357269128 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark28(-3.7152958037989663 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark28(-37.18705353205074 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark28(-37.206057855198594 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark28(-37.24096614029617 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark28(-37.245080583745604 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark28(-37.24515504887511 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark28(-37.2623594875845 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark28(-37.29294006270565 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark28(-37.364841669975604 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark28(-37.39024689946739 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark28(-37.41136605977624 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark28(-37.43861030458675 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark28(-37.48193292635027 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark28(-37.50981088631589 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark28(-3.7520144606044 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark28(-37.55246320640673 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark28(-37.55559222027789 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark28(-3.763802765641742 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark28(-37.641219986860804 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark28(-37.64883298962798 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark28(-37.66933805683512 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark28(-37.71559781124092 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark28(-37.77479230441656 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark28(-37.785028817285315 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark28(-37.796106993900544 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark28(-37.83448729632286 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark28(-37.86589347664302 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark28(-37.87192836825739 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark28(-37.892062056254794 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark28(-37.893136722346064 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark28(-37.89427162935497 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark28(-3.7923325432562223 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark28(-37.92664195278592 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark28(-37.95591926647512 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark28(-37.993812160992846 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark28(-3.800527164436531 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark28(-38.04089384296843 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark28(-38.04388401231093 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark28(-38.093081327107 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark28(-38.14571973211671 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark28(-38.14868155097242 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark28(-38.18774983001021 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark28(-38.19980713839293 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark28(-38.20470574541983 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark28(-38.20776934000543 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark28(-38.266445486414824 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark28(-38.28512352306972 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark28(-38.31642197597442 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark28(-38.36006214235048 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark28(-38.37488977511114 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark28(-38.39575986081072 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark28(-38.40397477089979 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark28(-38.406345007292074 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark28(-38.498324453637814 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark28(-38.50679017419234 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark28(-38.5267939129724 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark28(-38.547913932764 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark28(-38.55158530082319 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark28(-38.58850427516296 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark28(-38.59170585952978 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark28(-3.8626334178553776 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark28(-3.866579552193514 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark28(-38.69650049265792 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark28(-38.7497164287518 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark28(-38.76478670312067 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark28(-38.772083527781874 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark28(-38.78714276142927 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark28(-38.80938267389382 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark28(-38.85459776823268 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark28(-38.85488579655869 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark28(-38.945913767755826 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark28(-3.8973238290430174 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark28(-3.9036815510302034 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark28(-3.9107028712805203 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark28(-39.10877101795245 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark28(-39.15061266853586 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark28(-39.18407466212579 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark28(-39.185364026849 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark28(-39.20571058253446 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark28(-39.22872778724804 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark28(-39.237076496678384 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark28(-39.244945363419404 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark28(-39.25093672921138 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark28(-39.273621449141906 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark28(-39.2739352695165 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark28(-39.31336826891973 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark28(-3.934876766037249 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark28(-39.360913140282115 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark28(-39.378146523995674 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark28(-39.43574827149507 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark28(-39.43816618957605 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark28(-39.57396231876247 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark28(-39.59778590825456 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark28(-39.60609033725273 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark28(-39.65011008054369 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark28(-39.72444492845513 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark28(-39.737884327300385 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark28(-39.744376020554206 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark28(-39.77012755638396 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark28(-39.77676861134558 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark28(-39.784441469717 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark28(-39.84645059150205 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark28(-39.85390533166557 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark28(-39.884918157854884 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark28(-39.89425854628681 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark28(-39.93079816986462 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark28(-39.95281407933133 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark28(-39.98321624261458 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark28(-39.99157407895417 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark28(-40.00141950292644 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark28(-40.090686813188725 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark28(-40.097599855360436 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark28(-40.133863560010276 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark28(-40.13552205989961 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark28(-40.183453984458154 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark28(-40.18800455635147 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark28(-40.18891917161178 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark28(-40.2118077762994 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark28(-40.24557983646832 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark28(-40.253450673250036 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark28(-40.27330240421247 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark28(-40.340145600880106 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark28(-40.375893322461096 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark28(-40.3800218691323 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark28(-40.39394151188884 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark28(-40.41764182287291 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark28(-40.43146838681444 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark28(-40.45230125457033 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark28(-40.576384215414826 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark28(-40.61658595951998 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark28(-40.6334527338164 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark28(-40.648743498367445 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark28(-40.668486395387646 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark28(-40.67383191283926 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark28(-4.067433009647274 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark28(-40.69984633481685 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark28(-40.70088506229575 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark28(-4.070726129520509 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark28(-40.762954370812295 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark28(-40.76346135801396 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark28(-40.76671515530921 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark28(-40.8063560033229 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark28(-4.0938477848218895 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark28(-40.94837043143957 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark28(-40.94986354199508 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark28(-4.0993372051324 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark28(-4.099743291235214 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark28(-40.998253596454944 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark28(-41.02536996296629 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark28(-4.102541252689875 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark28(-41.03696800439223 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark28(-41.049126122279574 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark28(-41.09656351815267 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark28(-41.09864351392653 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark28(-41.107538785489986 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark28(-41.142713050598736 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark28(-41.160551663689795 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark28(-41.25039773040968 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark28(-41.27565871954402 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark28(-41.306968858975736 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark28(-41.36277054747761 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark28(-41.37214873979291 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark28(-41.396544804925824 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark28(-41.43800965108579 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark28(-41.44454869775498 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark28(-41.53757312611641 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark28(-41.58738376099009 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark28(-41.628541351483484 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark28(-41.690784052276506 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark28(-41.69588290903681 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark28(-41.72366866657422 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark28(-41.73496423018588 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark28(-41.74189061425007 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark28(-41.74717546754421 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark28(-41.76480816649764 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark28(-41.78908841301707 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark28(-41.798469062325296 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark28(-41.82110641097565 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark28(-41.92981205039246 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark28(-41.930327155400946 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark28(-41.96792387289783 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark28(-41.98171031473292 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark28(-42.0226324440649 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark28(-42.02285718564009 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark28(-42.02535776242164 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark28(-42.03457685046716 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark28(-42.06180042640719 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark28(-42.06994891854532 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark28(-42.09834753061643 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark28(-4.210390200461035 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark28(-42.11421749841102 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark28(-42.11667064679649 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark28(-42.14418468052947 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark28(-42.180090182258944 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark28(-42.19371698481842 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark28(-42.21975423835846 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark28(-42.227275445392465 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark28(-42.2689772430523 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark28(-42.306871165660944 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark28(-42.32244309814601 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark28(-42.32557007300741 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark28(-42.330692621460074 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark28(-42.34491147717674 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark28(-42.357649116105556 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark28(-42.36627523717657 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark28(-42.39797462333319 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark28(-42.40577852658065 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark28(-42.418843450484744 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark28(-42.51251199493922 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark28(-42.53767824142744 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark28(-42.58343727706393 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark28(-42.59177850201918 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark28(-42.604575879108395 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark28(-42.608085596955725 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark28(-42.62430449482659 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark28(-42.62859022784629 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark28(-42.66122747741743 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark28(-42.66408331870999 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark28(-42.76524313300993 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark28(-42.80836225068061 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark28(-42.84416639198256 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark28(-4.286705299920129 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark28(-42.87311895828265 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark28(-42.877382494174476 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark28(-42.89956199228266 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark28(-4.291323642350406 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark28(-4.295234469106219 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark28(-43.02297442905629 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark28(-43.0292881773134 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark28(-43.0451575883261 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark28(-43.058168369975405 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark28(-4.308935102212445 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark28(-4.312718524153496 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark28(-43.1323389460428 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark28(-43.13908364980455 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark28(-43.15895679443224 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark28(-43.1967762910068 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark28(-43.21695549946145 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark28(-43.239285719612155 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark28(-43.26058214433588 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark28(-43.30479914498013 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark28(-43.312747963099405 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark28(-43.31339334910149 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark28(-43.35879020151936 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark28(-43.37979810253256 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark28(-43.38590197573613 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark28(-43.38772521051686 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark28(-4.338795348849004 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark28(-43.400946039862085 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark28(-43.417469182054916 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark28(-43.4730608563753 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark28(-43.48710879020188 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark28(-43.500998377543645 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark28(-43.52271892007049 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark28(-43.558647292952315 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark28(-43.57936568451484 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark28(-43.62218625267617 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark28(-43.63190899623477 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark28(-43.64171153122358 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark28(-4.366504834430614 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark28(-43.690909937651725 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark28(-43.744004111293556 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark28(-43.74498349778308 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark28(-43.782966660498836 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark28(-43.79153805499965 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark28(-43.80791476995509 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark28(-4.381262340562046 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark28(-43.840377468932125 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark28(-43.86986931600103 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark28(-43.886096898984995 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark28(-43.93101607356831 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark28(-4.395164706195402 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark28(-4.396828022762094 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark28(-43.973181917290496 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark28(-4.400485358361422 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark28(-4.401294701507339 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark28(-4.411956746989347 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark28(-4.41628710960525 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark28(-44.16861582206473 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark28(-44.19436734043218 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark28(-4.420199607585033 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark28(-44.213109204009385 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark28(-44.21753252861347 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark28(-44.228585909529315 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark28(-44.23612259210778 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark28(-44.25867278659228 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark28(-44.278490733410614 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark28(-44.294565030278555 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark28(-44.3109703283475 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark28(-44.32044559763777 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark28(-44.336742081780976 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark28(-44.339714542999275 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark28(-44.36734531359869 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark28(-44.3852148923976 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark28(-4.441274529963678 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark28(-44.419851988751404 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark28(-44.46655513901972 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark28(-44.469143047920134 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark28(-44.47660470650157 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark28(-44.482166552181404 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark28(-44.48685901437699 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark28(-44.48710296207501 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark28(-44.52401273434674 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark28(-4.459934880250586 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark28(-44.67449762297031 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark28(-44.6844442120236 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark28(-44.68795456923107 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark28(-44.69843505925755 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark28(-44.86319513323376 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark28(-44.9523873372416 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark28(-44.96165833741124 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark28(-44.973048682035355 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark28(-44.97349427531046 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark28(-4.498078428304055 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark28(-44.98239156448476 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark28(-45.04995210358638 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark28(-45.15480819038762 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark28(-45.218907006459034 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark28(-45.26131460685312 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark28(-45.31043116034643 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark28(-45.315123408081305 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark28(-45.317267506677304 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark28(-45.338057193493086 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark28(-45.35401106044774 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark28(-45.35560760044941 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark28(-45.442174800693124 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark28(-45.46229837060285 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark28(-45.463335649457946 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark28(-45.50277398449985 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark28(-45.50732835765263 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark28(-45.53759893686973 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark28(-45.58147286815375 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark28(-4.560816232256059 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark28(-45.61180623861149 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark28(-45.62808725503451 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark28(-45.63136630653337 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark28(-45.64113802026084 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark28(-45.67745249923916 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark28(-4.577145811723753 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark28(-45.82190007768175 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark28(-45.82696155166954 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark28(-4.58547957146402 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark28(-45.90797890170764 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark28(-45.93581754919429 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark28(-45.94159751813742 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark28(-45.97247192230609 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark28(-46.00710271640662 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark28(-46.00906865617216 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark28(-46.01290429944997 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark28(-46.01483902969959 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark28(-46.016063371431045 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark28(-46.05915221129111 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark28(-46.09938311197348 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark28(-46.10523184271966 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark28(-46.12441609703912 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark28(-46.148252840287384 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark28(-46.181015819616356 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark28(-46.18913607381494 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark28(-46.19943318800901 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark28(-46.20562273979147 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark28(-46.23506362213901 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark28(-46.2555350821354 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark28(46.334259833760456 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark28(-46.34414291776998 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark28(-46.37122546777916 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark28(-46.412968381550776 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark28(-46.42372660303287 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark28(-4.643360421094229 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark28(-46.44494305950167 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark28(-46.45229077631079 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark28(-46.46766932463595 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark28(-46.53457925289408 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark28(-46.55958795858724 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark28(-46.572741433898756 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark28(-46.71468349805827 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark28(-46.731941754411885 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark28(-46.77079539612286 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark28(-46.77311959765946 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark28(-46.79076410070646 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark28(-46.905338247085226 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark28(-46.90683658030685 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark28(-46.943456596326904 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark28(-46.95092959304936 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark28(-46.953803147450124 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark28(-46.97620374570626 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark28(-47.00143399494612 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark28(-47.0162813419339 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark28(-47.03647240237054 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark28(-47.09004494677107 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark28(-47.104156010752554 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark28(-47.11809756681185 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark28(-4.714902363464859 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark28(-47.15712395577651 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark28(-47.1659820683658 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark28(-47.18078365620937 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark28(-47.19043818199435 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark28(-47.19157700950633 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark28(-47.22025996487189 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark28(-47.227569962908134 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark28(-47.33468846478228 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark28(-47.374556909581344 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark28(-47.452752268014976 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark28(-47.48246765413286 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark28(-47.48565610103308 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark28(-47.55847236300246 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark28(-47.59284452767356 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark28(-47.679550325831464 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark28(-47.694958542425695 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark28(-47.74975185023145 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark28(-47.80046700759695 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark28(-47.81980945187214 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark28(-47.84927544459274 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark28(-47.85947395640533 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark28(-47.88826408196509 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark28(-47.89636788006013 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark28(-47.93964037226621 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark28(-47.95165786259228 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark28(-47.95975957296727 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark28(-47.96629184337671 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark28(-47.98041510874167 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark28(-47.98824482587787 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark28(-48.00338493771024 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark28(-48.02940968279377 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark28(-4.804848295426865 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark28(-48.057212810430094 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark28(-48.07363468238863 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark28(-4.80957470832027 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark28(-4.814880969006367 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark28(-48.16378592089108 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark28(-48.19465834448331 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark28(-4.822177474565905 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark28(-48.25199383126613 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark28(-48.299726610543004 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark28(-48.34908548050052 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark28(-48.34935602859638 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark28(-48.357775644341785 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark28(-48.36078770734113 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark28(-4.836593722790354 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark28(-48.41806294900994 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark28(-48.418550068479036 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark28(-48.43249594672856 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark28(-48.43729841619797 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark28(-48.467177581880726 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark28(-48.51313901890446 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark28(-48.52201140132652 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark28(-48.52467305387604 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark28(-48.52586105028407 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark28(-48.539648524504095 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark28(-48.556516090710566 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark28(-48.648384143731334 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark28(-48.64919887690631 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark28(-48.689685750574974 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark28(-48.69366748444679 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark28(-48.70483168415096 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark28(-48.79869712729261 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark28(-48.82001657860713 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark28(-48.83117636086634 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark28(-48.837821605909035 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark28(-48.86468809074247 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark28(-48.87601593015407 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark28(-48.89428103388913 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark28(-48.91783369247844 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark28(-49.003214523985065 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark28(-49.023947873959294 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark28(-49.037864282402936 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark28(-49.04073381925074 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark28(-49.09220212695704 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark28(-49.10467878057456 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark28(-49.11376668402101 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark28(-49.13210378552133 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark28(-49.15674187071135 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark28(-49.16759915252662 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark28(-49.168268566272324 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark28(-49.232007355574204 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark28(-49.23447953743594 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark28(-49.26101226532111 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark28(-49.27347007475085 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark28(-49.28193507442349 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark28(-49.37798399760693 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark28(-49.45844626344233 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark28(-49.47601997202802 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark28(-49.477703913606774 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark28(-49.482624434011946 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark28(-49.49069917462472 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark28(-49.516199773876224 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark28(-49.55241231459831 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark28(-49.57139246872586 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark28(-49.599863772954535 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark28(-49.692342994432146 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark28(-4.97246987669746 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark28(-49.738487242144046 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark28(-49.75379210495567 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark28(-4.976017255870929 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark28(-49.771156268029216 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark28(-4.979032726953832 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark28(-49.79286102492506 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark28(-49.8095322640856 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark28(-49.81706184103989 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark28(-49.8470392132228 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark28(-49.87535793829609 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark28(-49.8893580828597 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark28(-4.989666064441906 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark28(-49.9049320743798 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark28(-49.98127482783408 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark28(-49.99733207740291 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark28(-50.03443752904477 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark28(-50.0814651845146 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark28(-50.08484118932135 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark28(-50.19825942475502 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark28(-50.19845400256913 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark28(-5.02310379747199 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark28(-50.28592727884747 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark28(-50.294297974215475 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark28(-50.34447897332115 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark28(-50.377614049974476 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark28(-50.38814855746458 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark28(-50.39961344550778 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark28(-50.42912454847659 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark28(-50.44901480563602 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark28(-50.450857230966676 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark28(-50.46490235999388 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark28(-50.53793071496582 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark28(-50.6246839117449 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark28(-50.6543626934227 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark28(-50.68648089935086 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark28(-50.69714561765366 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark28(-50.74602375926547 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark28(-50.85501395173673 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark28(-50.90241414183294 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark28(-50.910755031171796 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark28(-50.99557080519772 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark28(-51.0063905446148 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark28(-51.03636978559596 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark28(-51.03922598193438 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark28(-51.097117013805146 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark28(-51.1011166101903 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark28(-51.21341892400086 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark28(-51.22261328813165 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark28(-51.23241497858895 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark28(-51.23259495776378 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark28(-51.23427792670449 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark28(-51.293728776236506 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark28(-51.30528204089979 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark28(-51.305874045781216 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark28(-51.31431652755107 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark28(-51.332819480754274 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark28(-51.379649055545265 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark28(-51.422908077995764 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark28(-51.4730770978781 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark28(-51.497444730051534 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark28(-51.53077915548998 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark28(-51.54530109362669 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark28(-5.154989512130825 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark28(-51.58445228958237 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark28(-51.59073795883062 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark28(-51.64488454719167 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark28(-51.70765978035203 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark28(-51.73805206229702 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark28(-51.73946473611741 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark28(-51.742499289343556 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark28(-51.74882484431116 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark28(-51.755729227939455 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark28(-51.75852130223439 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark28(-5.177509115146492 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark28(-51.84404038174415 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark28(-51.86583680725438 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark28(-51.87263448626849 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark28(-51.87591141945666 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark28(-51.93286708408258 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark28(-51.94378523397152 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark28(-5.196025015941402 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark28(-51.966487979302364 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark28(-51.98300753218275 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark28(-51.98792388428251 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark28(-52.13559358541817 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark28(-52.13810693041432 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark28(-52.179162159878345 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark28(-52.1906545538324 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark28(-52.20289195275987 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark28(-52.31736850201904 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark28(-52.32645643941556 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark28(-52.340721544639266 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark28(-52.34844419298324 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark28(-52.41069377205396 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark28(-52.436468044513894 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark28(-52.43682803629852 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark28(-52.4469143692873 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark28(-52.467794925182545 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark28(-52.47172538826517 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark28(-52.48787238484456 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark28(-52.499262922331134 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark28(-52.50199650835587 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark28(-52.51798142162194 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark28(-5.259210146406275 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark28(-52.60014646807956 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark28(-52.61521968046936 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark28(-5.268361853470864 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark28(-52.73676439752675 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark28(-52.74900583641396 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark28(-52.76663057779154 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark28(-52.77734273553012 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark28(-52.780763178792455 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark28(-52.781560048889766 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark28(-52.78506382005794 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark28(-52.78948170411353 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark28(-52.79512436627189 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark28(-52.825061380191364 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark28(-52.896798382267264 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark28(-52.918981349111284 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark28(-52.9333443022245 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark28(-5.294243265182729 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark28(-52.970779451984875 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark28(-52.979018080489816 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark28(-5.298401121883728 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark28(-52.99135436519178 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark28(-53.01294148871576 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark28(-53.01634385271752 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark28(-53.047045035046445 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark28(-53.050382207331246 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark28(-53.05456590845703 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark28(-53.07377850573789 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark28(-5.307773913402585 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark28(-53.079881324445985 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark28(-53.08217014528036 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark28(-53.08376667200403 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark28(-53.10215777495713 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark28(-53.131515051962076 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark28(-53.21375609283767 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark28(-53.2296053691625 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark28(-5.325924121235474 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark28(-53.26845862338525 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark28(-53.2839294299307 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark28(-53.291690303630055 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark28(-53.30249881337359 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark28(-5.330672843275323 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark28(-53.327944719625165 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark28(-53.35161511432203 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark28(-53.36724693386981 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark28(-53.38226635596281 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark28(-53.39620766409894 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark28(-53.4282944765716 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark28(-53.434021225380015 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark28(-53.43765741791362 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark28(-53.4566401273725 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark28(-53.467914077467626 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark28(-53.47887619804628 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark28(-53.484561101260496 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark28(-53.48614136221044 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark28(-53.51591289703048 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark28(-53.52898094189362 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark28(-53.626143538286165 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark28(-53.635818392830316 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark28(-53.638142975121575 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark28(-53.680594921255945 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark28(-53.721469463498515 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark28(-53.734588430330454 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark28(-5.373716959282831 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark28(-53.75450410998192 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark28(-53.76350017517135 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark28(-53.79819548775417 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark28(-53.8071561109849 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark28(-53.85412471939524 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark28(-53.871423104012806 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark28(-53.912540605953254 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark28(-53.92916469253439 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark28(-53.95143776938782 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark28(-53.96822549983362 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark28(-54.01577596118683 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark28(-54.03682391815905 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark28(-54.06195149307636 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark28(-5.406725760494254 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark28(-5.409969937082764 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark28(-54.1302410629823 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark28(-5.414483090916434 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark28(-54.146581701161224 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark28(-54.220212591357054 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark28(-5.422476191853519 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark28(-54.228060844945226 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark28(-54.23878416950896 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark28(-54.23885699778794 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark28(-54.3198532019409 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark28(-54.32246577862598 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark28(-54.325751682452996 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark28(-54.332101718282246 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark28(-54.35430872560752 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark28(-54.405500957845 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark28(-54.408640429119146 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark28(-54.42488123413449 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark28(-54.43373164308274 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark28(-5.455907999226994 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark28(-54.589625555230484 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark28(-54.60134774027379 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark28(-54.66745753392486 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark28(-54.66770778596257 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark28(-54.71564641530728 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark28(-54.72624424820503 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark28(-54.73358932755459 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark28(-54.749584996489965 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark28(-54.752421115359695 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark28(-54.77428231561008 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark28(-54.86091561333779 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark28(-54.86163881434673 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark28(-54.92933397492421 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark28(-54.93824503019926 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark28(-54.95714325310048 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark28(-55.042634210769805 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark28(-55.05319918950191 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark28(-55.065557098046526 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark28(-55.08992806544188 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark28(-55.090416738836545 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark28(-55.15195551611387 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark28(-55.16189185280833 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark28(-55.2425183559055 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark28(-55.26012795688074 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark28(-55.28262249228844 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark28(-55.287520433904234 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark28(-55.288844669311786 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark28(-55.29098099028897 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark28(-55.324966717513036 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark28(-55.326730543199275 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark28(-55.392981007230645 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark28(-5.539498719713222 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark28(-55.408067179187206 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark28(-55.42883982263858 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark28(-55.46314369488039 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark28(-55.485770990501784 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark28(-55.58326188130849 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark28(-55.59916781764493 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark28(-55.60159433678125 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark28(-55.61916407199441 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark28(-55.63240162194412 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark28(-55.66075795165484 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark28(-55.66137607510861 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark28(-55.71583152371766 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark28(-55.7405662877577 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark28(-55.74101691893827 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark28(-55.76052125887128 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark28(-55.76995783079677 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark28(-55.78537559262329 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark28(-55.836417696936195 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark28(-55.84831287796979 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark28(-55.86269878359573 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark28(-55.86878982337946 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark28(-55.89342845203005 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark28(-55.99329653003691 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark28(-56.001477237367524 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark28(-56.02313941928787 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark28(-56.02369141687076 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark28(-56.03562190410587 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark28(-56.038193991164945 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark28(-5.608692550931835 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark28(-56.147293695284375 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark28(-56.249076817833135 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark28(-56.24939126502393 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark28(-56.28128194694941 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark28(-56.31234446429356 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark28(-56.31999761516953 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark28(-56.36665306795214 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark28(-56.38286445868903 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark28(-56.4005535186878 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark28(-56.434819244113356 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark28(-56.46181602133511 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark28(-56.47468690521011 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark28(-56.482873013066424 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark28(-56.51138114544128 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark28(-56.51913229553451 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark28(-56.52092555458115 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark28(-56.52618766726827 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark28(-56.58010578880801 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark28(-56.59435949651061 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark28(-56.60818522144284 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark28(-56.60928210278959 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark28(-56.61519480775359 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark28(-56.62341121967047 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark28(-5.665632161031667 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark28(-56.67232266646132 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark28(-56.71647950399223 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark28(-56.718698537631184 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark28(-56.74066982839064 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark28(-56.7682065544598 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark28(-56.81439107474624 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark28(-56.82443604666902 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark28(-56.8314079315116 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark28(-56.85772653369951 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark28(-56.88962058072586 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark28(-56.88995626003639 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark28(-56.932906540252446 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark28(-56.94371981546767 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark28(-56.94394913569973 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark28(-56.94428844797106 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark28(-56.98549132003914 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark28(-57.040655478011004 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark28(-57.06613783039518 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark28(-5.710293700223133 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark28(-57.1129432838436 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark28(-57.13394657581814 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark28(-57.19651101502454 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark28(-57.24965412924568 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark28(-57.27587670290071 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark28(-57.3529988167518 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark28(-57.37473476439001 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark28(-57.44127514399866 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark28(-57.46167613546738 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark28(-57.48800879641711 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark28(-5.749401094915328 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark28(-57.518766983793014 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark28(-57.53983664231037 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark28(-57.5526992160857 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark28(-57.601169385563566 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark28(-57.60829460840717 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark28(-57.624149381653986 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark28(-57.65274549047324 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark28(-57.678110254275474 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark28(-5.7704522643671226 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark28(-57.712959553773224 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark28(-57.71399481112904 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark28(-57.7594430590817 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark28(-57.7834291224742 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark28(-57.803310923856955 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark28(-57.84052193076998 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark28(-57.96751888247178 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark28(-57.99302935252124 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark28(-58.05992679678147 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark28(-58.061843673791216 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark28(-58.08788592915817 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark28(-58.11081766340851 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark28(-58.122894207751344 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark28(-58.16381631316663 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark28(-58.17670192647731 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark28(-58.20065217535024 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark28(-58.20733419919917 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark28(-58.20983136576552 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark28(-58.278551916611136 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark28(-58.284661019804496 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark28(-58.286210374037026 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark28(-58.32219125719356 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark28(-58.32556340755885 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark28(-58.34788535393645 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark28(-58.356742856044264 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark28(-58.36623969315193 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark28(-58.37652163223146 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark28(-58.38830104909469 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark28(-58.41300458929719 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark28(-58.424647837621336 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark28(-58.42572135800459 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark28(-5.8438122494217595 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark28(-58.444991684177225 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark28(-58.49325744996936 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark28(-58.51220643772168 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark28(-58.51455089741195 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark28(-5.854566051111917 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark28(-58.58653207037854 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark28(-58.60089873328347 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark28(-58.65778588137527 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark28(-58.712847213222055 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark28(-58.72836376189032 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark28(-58.779042613581154 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark28(-58.84701462947166 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark28(-58.8791820922026 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark28(-58.88030217073788 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark28(-5.88885196743702 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark28(-58.96733284176645 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark28(-5.897930648903696 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark28(-59.07260243979555 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark28(-59.07525484112162 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark28(-59.07771245722388 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark28(-59.099182789142105 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark28(-59.106662117779884 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark28(-59.111902337283006 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark28(-59.11356870215629 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark28(-59.12330398943237 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark28(-59.2294466594677 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark28(-59.23097089223355 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark28(-59.26197405605657 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark28(-59.26453348735106 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark28(-59.28091704194183 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark28(-5.93064097017826 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark28(-59.31955153631916 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark28(-5.932570685812124 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark28(-5.934189882398712 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark28(-5.9349318482341005 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark28(-59.412609322651576 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark28(-59.416032998348875 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark28(-59.42562700088128 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark28(-59.44366170044923 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark28(-59.45119732002209 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark28(-59.45889300828049 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark28(-59.460876054329525 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark28(-59.53185582826006 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark28(-59.53997513362379 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark28(-59.557198704009615 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark28(-59.55905532157202 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark28(-59.572429692635566 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark28(-59.5777396568056 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark28(-59.59117237121845 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark28(-59.60586248701196 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark28(-59.642423355377176 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark28(-59.669873014295895 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark28(-59.672079279947 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark28(-59.67432837393114 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark28(-59.67570257838377 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark28(-59.68083310404562 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark28(-59.73033677636419 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark28(-59.746805731625784 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark28(-59.773841219908874 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark28(-59.777236604574256 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark28(-59.87449340270974 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark28(-59.90333126745957 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark28(-59.94584250256989 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark28(-60.03509781701051 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark28(-60.09528724352702 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark28(-60.182950651504655 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark28(-60.2430713456068 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark28(-6.031214079709429 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark28(-6.0328053282334935 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark28(-60.399403969397866 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark28(-60.43664448043171 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark28(-60.458507841652654 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark28(-6.049853577198078 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark28(-60.501703202232584 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark28(-60.53323569194053 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark28(-60.54076822239751 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark28(-60.56133246539537 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark28(-60.5716705337499 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark28(-60.57253273761627 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark28(-60.578639098818535 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark28(-60.611269800354364 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark28(-60.665947646811034 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark28(-60.68508590500827 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark28(-60.7582768776991 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark28(-60.758911697218586 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark28(-60.76397308082593 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark28(-60.76536945959974 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark28(-60.76981639931098 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark28(-60.78945220485912 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark28(-60.80471444851019 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark28(-60.82398291513407 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark28(-60.84446650590123 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark28(-60.95020640254785 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark28(-60.95335897075043 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark28(-60.95603152123714 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark28(-60.956112560191244 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark28(-60.96138515537377 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark28(-60.96145111956901 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark28(-61.000845681628356 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark28(-61.01086625842471 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark28(-61.03893165869958 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark28(-61.03925247284836 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark28(-61.04011796364184 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark28(-61.062011737562095 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark28(-61.07374949861111 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark28(-61.09241767594944 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark28(-61.115850753446765 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark28(-6.112305318835112 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark28(-61.2131152653113 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark28(-61.238122923077 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark28(-61.246719970773775 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark28(-61.25393499455687 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark28(-61.283279022323086 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark28(-61.289719815611534 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark28(-61.32078769322311 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark28(-61.347168885927374 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark28(-61.35889143411495 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark28(-61.36806509053656 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark28(-61.370716560990935 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark28(-61.38133641088106 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark28(-61.49375434203053 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark28(-6.150761275487753 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark28(-61.548544463347675 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark28(-61.60952800348429 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark28(-61.615032962291785 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark28(-61.62183646411097 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark28(-6.1653890317601565 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark28(-6.165765139058507 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark28(-61.749736643117046 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark28(-61.808905742818695 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark28(-61.86604660119619 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark28(-61.87145772789402 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark28(-61.889271879788254 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark28(-61.92151509553187 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark28(-6.19360633291943 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark28(-61.95378507354836 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark28(-61.96450699679834 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark28(-62.00069682854041 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark28(-6.200428628401596 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark28(-62.07735094219089 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark28(-62.078388391059306 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark28(-62.16387419430129 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark28(-62.1926859382754 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark28(-62.19520494535917 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark28(-6.219750435305755 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark28(-62.19876485163931 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark28(-62.20615318690781 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark28(-62.236724649352816 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark28(-62.23901643684104 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark28(-62.24134021416068 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark28(-62.28921028597667 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark28(-62.35750561071398 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark28(-62.37325533992466 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark28(-62.382203245032585 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark28(-62.390526473520836 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark28(-62.39926231195676 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark28(-62.417255780085746 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark28(-62.43635889813199 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark28(-62.4619686858521 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark28(-62.5062848651218 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark28(-62.52849780669318 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark28(-62.55036125240674 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark28(-62.56808326208487 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark28(-62.57894888460069 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark28(-62.69154067837721 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark28(-62.702061198728764 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark28(-62.76867200757521 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark28(-62.78225307214782 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark28(-62.79471846450877 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark28(-62.79972130368849 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark28(-62.805453274692894 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark28(-62.821345377324356 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark28(-62.830910585427006 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark28(-62.883734428589875 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark28(-62.959586644584256 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark28(-62.96177162843237 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark28(-63.0168702893475 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark28(-63.04522301901145 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark28(-63.04926949238332 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark28(-63.051769438819136 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark28(-63.06015997898964 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark28(-63.087282982201366 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark28(-63.10931544209859 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark28(-63.10986865106869 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark28(-63.11676262773685 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark28(-63.13980623099111 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark28(-63.14277832903015 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark28(-63.14714911179258 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark28(-63.1772124925009 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark28(-63.19013238801643 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark28(-63.21851903226421 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark28(-63.22725834882519 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark28(-6.323620603827294 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark28(-63.24641375693005 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark28(-63.26964247241984 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark28(-6.332734539728136 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark28(-63.340035488205196 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark28(-63.451233469062004 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark28(-63.48063269213535 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark28(-63.49983620253739 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark28(-63.50211093159865 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark28(-63.50928413361543 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark28(-63.526088772303765 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark28(-63.56644262507483 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark28(-63.57091113529867 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark28(-63.580199670502346 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark28(-63.62900876141309 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark28(-63.64251017839211 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark28(-63.651377512030805 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark28(-6.368168117267686 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark28(-63.68256695204111 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark28(-63.68457279741986 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark28(-6.374380858592517 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark28(-63.7772457522602 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark28(-63.80782813733761 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark28(-63.81574234720717 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark28(-63.81888703096108 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark28(-63.8417118836023 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark28(-63.85042063391335 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark28(-63.87702529279278 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark28(-63.87997169724922 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark28(-6.390563934160582 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark28(-63.94140838664952 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark28(-63.94183689688222 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark28(-63.965468237543874 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark28(-63.967514780116666 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark28(-63.979639518927314 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark28(-64.01917355329078 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark28(-64.04564209181612 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark28(-64.04600288190221 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark28(-64.11411628991009 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark28(-64.13268489877038 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark28(-64.15112055661467 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark28(-64.18175486400864 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark28(-64.19970211716205 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark28(-64.22035801608261 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark28(-64.2222137955516 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark28(-64.2357403454946 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark28(-64.25079183297815 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark28(-64.29969028062487 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark28(-64.30144610390012 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark28(-64.32406682373846 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark28(-64.35588996854659 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark28(-64.36369596579495 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark28(-6.438251881003836 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark28(-64.39922285950422 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark28(-64.47039324614263 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark28(-64.50427664868596 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark28(-64.50497897349831 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark28(-6.451388366113207 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark28(-64.52358183473754 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark28(-64.56129595230973 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark28(-64.56133054795812 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark28(-6.457965528582747 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark28(-64.61521311384996 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark28(-64.62242032116112 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark28(-64.65860855002313 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark28(-64.69463106472247 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark28(-64.71239297658991 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark28(-64.73333798666224 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark28(-64.7375444710762 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark28(-64.7409696614027 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark28(-64.742079318494 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark28(-64.78770240746925 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark28(-64.79219784279104 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark28(-64.79291007100167 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark28(-64.80350644163983 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark28(-64.84236559619323 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark28(-64.84747901711916 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark28(-64.86439473735102 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark28(-64.86729669135138 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark28(-64.89007887069462 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark28(-64.90739556803643 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark28(-64.90796846552266 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark28(-64.90828012065815 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark28(-6.50090202008586 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark28(-65.01597860468053 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark28(-65.02380927007776 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark28(-65.05647328152146 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark28(-65.07554449004243 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark28(-65.09232279563615 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark28(-65.10383556235209 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark28(-65.1465020902472 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark28(-65.17193345852428 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark28(-65.18060710289598 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark28(-65.19846837788936 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark28(-65.27882587225761 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark28(-65.30309992865674 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark28(-65.32601447729081 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark28(-65.3396008422825 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark28(-65.35418136195531 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark28(-65.3659869963495 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark28(-65.412426815191 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark28(-65.44211759007277 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark28(-65.4625855991795 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark28(-65.46503748847533 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark28(-6.5476261870906995 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark28(-65.47772900221662 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark28(-65.48115481758964 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark28(-65.51690804855832 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark28(-65.55221616266081 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark28(-6.55684647924339 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark28(-65.67634245710923 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark28(-65.73396400881526 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark28(-65.75238780526742 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark28(-65.76668814449712 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark28(-65.78702407583481 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark28(-65.8611304334662 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark28(-65.87073886462841 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark28(-65.8786084676826 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark28(-65.90243154482845 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark28(-65.92756953891801 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark28(-65.93493032524474 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark28(-65.94636801540827 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark28(-66.02236384630116 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark28(-66.06005481885964 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark28(-66.1199762458883 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark28(-66.12714070657685 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark28(-66.21968550060956 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark28(-66.29441796541457 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark28(-66.31185755967167 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark28(-66.41515363182995 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark28(-66.42836231092377 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark28(-66.42910472820626 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark28(-66.51714355649152 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark28(-66.52223536337836 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark28(-66.54752857637976 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark28(-66.55878567618029 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark28(-66.58160575211649 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark28(-66.59481658972038 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark28(-66.59932617026266 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark28(-66.62162885443476 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark28(-66.62580924095252 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark28(-66.68770930849344 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark28(-66.74102016978578 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark28(-6.676884076274405 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark28(-66.8084143407053 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark28(-66.85756460864872 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark28(-66.87219890609941 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark28(-6.689210179119726 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark28(-66.89722839959296 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark28(-66.9001181422183 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark28(-66.90137696773608 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark28(-66.90708160385 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark28(-66.96751136296285 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark28(-66.97981693396902 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark28(-67.00902890826224 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark28(-67.04652918576087 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark28(-67.05304578082622 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark28(-67.07687692672843 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark28(-67.08039436965743 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark28(-67.09116226054701 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark28(-67.0922596840278 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark28(-67.10093060808899 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark28(-67.12127770347043 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark28(-67.18822542157932 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark28(-67.26035882820761 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark28(-67.26947903152451 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark28(-67.30136944501663 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark28(-67.3361157168162 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark28(-67.35455855263666 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark28(-67.40628848335903 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark28(-67.42642588981589 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark28(-67.4437633209167 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark28(-67.45361601060856 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark28(-67.47214325908223 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark28(-67.5057298374291 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark28(-6.756497098247706 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark28(-67.61970583920828 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark28(-67.64094204644269 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark28(-67.66783174744788 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark28(-6.7716377490085335 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark28(-67.74235904658883 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark28(-67.74853359043473 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark28(-67.8052861466403 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark28(-67.84873839126371 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark28(-67.86800487342508 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark28(-67.88911139588086 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark28(-6.7976583016451 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark28(-68.0220496838664 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark28(-68.0259995451126 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark28(-68.04398590195521 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark28(-68.0588644280999 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark28(-68.10607605543935 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark28(-68.10769359855698 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark28(-68.11751739687779 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark28(-6.814696184751938 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark28(-68.23860201852872 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark28(-68.25207669287703 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark28(-6.838034973586986 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark28(-68.4662349615632 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark28(-6.847367706170999 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark28(-68.55793421976534 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark28(-68.56042585419699 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark28(-68.56414881465535 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark28(-68.58477414066463 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark28(-68.59606071821531 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark28(-6.860528617399979 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark28(-68.62761081557021 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark28(-68.63720673860094 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark28(-68.72306996584436 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark28(-68.72667305663629 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark28(-68.74202573710761 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark28(-68.74897933973867 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark28(-68.88676882135378 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark28(-68.90281176284773 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark28(-68.90789971957834 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark28(-68.91033003572568 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark28(-69.04603448478213 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark28(-69.04839069425802 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark28(-69.05170680837801 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark28(-6.917455547682906 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark28(-69.17639539505168 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark28(-69.20004369193967 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark28(-69.28461512042892 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark28(-69.30405634232329 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark28(-69.3330822998675 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark28(-69.35309122776621 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark28(-6.935675993269669 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark28(-69.42752591364332 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark28(-69.43328609918815 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark28(-69.45561030579337 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark28(-69.49794230191601 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark28(-69.54192222999589 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark28(-6.957788300853622 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark28(-69.63638795571691 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark28(-69.63987022828321 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark28(-69.65017714622928 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark28(-69.72162464784195 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark28(-69.75949863217977 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark28(-6.978193487971865 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark28(-69.78464820215626 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark28(-69.7962632243446 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark28(-69.87657386653261 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark28(-69.88200204966364 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark28(-69.90712659583289 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark28(-69.91472760671151 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark28(-69.91613288700202 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark28(-69.92631475224182 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark28(-69.94884098259185 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark28(-69.95017446045486 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark28(-69.97499180377298 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark28(-70.02887648515687 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark28(-70.07743541427062 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark28(-70.17723333569032 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark28(-70.20830730694846 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark28(-70.2276340210046 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark28(-7.0337451080995095 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark28(-70.34608267326301 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark28(-70.40108659221289 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark28(-70.4093935475844 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark28(-70.45422442122972 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark28(-70.46932169921598 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark28(-70.46974512784054 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark28(-70.47575783521694 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark28(-70.48801458812409 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark28(-70.48818673569792 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark28(-70.54132963061369 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark28(-70.55764074517705 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark28(-70.56623093239334 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark28(-70.59206631187061 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark28(-70.60151824983596 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark28(-7.0615969850142335 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark28(-7.065728619457374 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark28(-70.71599758847424 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark28(-70.75317917573325 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark28(-70.81113677369358 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark28(-70.81435773900134 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark28(-70.82343165500544 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark28(-70.89365062765111 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark28(-70.95121095141687 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark28(-70.95430668047642 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark28(-70.96438607701012 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark28(-70.99430413560887 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark28(-70.99559401827298 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark28(-71.00038953434003 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark28(-71.0017390097944 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark28(-71.05536993354191 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark28(-71.0726903260535 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark28(-71.08177249969496 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark28(-71.08211020138391 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark28(-71.10155851701097 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark28(-71.13844505924125 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark28(-71.14343617510939 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark28(-71.15585112157017 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark28(-71.17987189415409 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark28(-71.19497917470947 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark28(-71.22797158808314 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark28(-71.31083481552412 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark28(-71.31874004248668 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark28(-71.35707528769233 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark28(-71.44938901653042 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark28(-71.45436317996038 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark28(-71.56111318067242 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark28(-71.56192344097943 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark28(-71.59060375430089 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark28(-7.162271152042294 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark28(-71.64942594944227 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark28(-71.73239742386957 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark28(-71.73713398706019 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark28(-71.79716730360184 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark28(-71.8181164571724 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark28(-71.8262399209723 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark28(-71.87188547178218 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark28(-71.87806320752262 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark28(-71.87911147124561 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark28(-71.8806100585752 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark28(-71.88768467385249 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark28(-71.90978269368797 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark28(-71.90990736698657 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark28(-71.94800398162933 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark28(-72.03451371939622 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark28(-72.03680570107194 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark28(-72.04688579451617 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark28(-72.05142598533348 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark28(-72.05241782116225 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark28(-72.06676115863397 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark28(-72.08430131776771 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark28(-7.208945848844309 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark28(-72.0984005186474 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark28(-72.21474048184852 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark28(-72.2631699400265 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark28(-72.26690583637001 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark28(-72.38430826425585 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark28(-72.4066387190805 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark28(-72.41802876456858 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark28(-7.2433143880465565 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark28(-72.48506729494595 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark28(-72.48980354634642 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark28(-72.49450619788152 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark28(-72.56783387892133 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark28(-7.260912765505665 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark28(-72.7009135232575 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark28(-7.270414953549988 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark28(-72.71730336754317 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark28(-72.7183048742856 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark28(-72.74735132839017 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark28(-72.79075579244112 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark28(-72.80633143955646 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark28(-72.81619276074804 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark28(-72.82177961838963 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark28(-72.8687904724897 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark28(-72.88121392095834 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark28(-72.88798900971986 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark28(-72.88846230245534 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark28(-72.91092523895517 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark28(-72.9185369644888 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark28(-72.9420344292069 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark28(-72.95057948693922 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark28(-72.95419180533486 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark28(-72.98438061166696 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark28(-73.03191783107363 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark28(-73.09087966541918 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark28(-73.13620630572287 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark28(-73.15621129103832 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark28(-73.16451484204983 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark28(-7.317480086793012 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark28(-73.2396550360105 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark28(-73.23992836194526 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark28(-73.26103191392642 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark28(-73.2701248226461 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark28(-73.27463060893437 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark28(-73.30280141940422 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark28(-73.36210183602071 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark28(-73.4305793240199 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark28(-73.46042248032074 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark28(-7.3462869708738765 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark28(-73.47866837142949 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark28(-73.47883737972683 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark28(-7.349286457178621 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark28(-73.51192158289524 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark28(-73.54529329390552 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark28(-73.58089103603544 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark28(-73.59226140711365 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark28(-73.60811152870026 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark28(-73.65307265897934 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark28(-73.65674852537825 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark28(-73.66731341659975 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark28(-73.67362585614707 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark28(-7.381392490620641 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark28(-73.81611646546105 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark28(-73.85830503871482 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark28(-73.86519878243652 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark28(-73.90281345580112 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark28(-73.91236270821278 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark28(-73.92119536752875 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark28(-73.92568550980604 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark28(-73.93627846041446 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark28(-73.96810114031788 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark28(-73.97452797958269 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark28(-74.02232760595223 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark28(-74.09704340566272 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark28(-74.10730238968664 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark28(-74.112811349868 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark28(-74.12672996631699 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark28(-74.12880734879859 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark28(-74.21051560215798 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark28(-74.21053238985209 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark28(-74.21357702190299 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark28(-74.22976980082097 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark28(-74.24579284926433 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark28(-74.39430292096141 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark28(-74.39581034445015 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark28(-74.4174108878285 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark28(-74.43165226192265 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark28(-7.4449613478364824 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark28(-74.4713151369571 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark28(-74.4880752783316 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark28(-74.57061612564075 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark28(-74.5777162920418 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark28(-74.58517487829394 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark28(-74.60170187064408 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark28(-74.62339085032946 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark28(-74.63410223167246 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark28(-7.471445894153177 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark28(-74.73826290979952 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark28(-74.74061605566547 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark28(-7.475621091592544 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark28(-74.79143353077913 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark28(-74.81970634040549 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark28(-74.8512157713746 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark28(-74.88468486504868 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark28(-74.8978230839628 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark28(-74.91203779182838 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark28(-74.92918401098996 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark28(-74.93180438382285 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark28(-7.494772467002946 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark28(-7.494859498219867 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark28(-74.97109839323804 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark28(-74.98365274534014 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark28(-75.08028679053595 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark28(-75.1157779985434 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark28(-75.18375297000246 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark28(-75.20612545904146 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark28(-75.23191080403409 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark28(-75.26785490262338 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark28(-75.28083768826323 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark28(-75.36938049216886 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark28(-75.38121258333274 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark28(-75.39095882648837 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark28(-75.40599926130338 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark28(-7.540637005389385 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark28(-75.41732212130437 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark28(-75.48013177444975 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark28(-75.51187109304756 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark28(-75.56558146807109 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark28(-75.59120957937249 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark28(-75.59526335619947 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark28(-75.6278165336024 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark28(-75.65454767441472 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark28(-75.66205534530796 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark28(-75.66286335515264 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark28(-75.69730457018946 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark28(-75.74445977447365 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark28(-75.74873864260113 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark28(-75.7816606961371 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark28(-75.7870819833432 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark28(-7.579358354799169 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark28(-75.80568809045005 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark28(-75.84249445707682 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark28(-75.88771083474248 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark28(-75.91116567571434 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark28(-75.94420693246437 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark28(-75.95757180919595 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark28(-75.97739993947769 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark28(-76.0218424994128 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark28(-76.04156326296818 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark28(-76.11880438800256 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark28(-76.14426178663503 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark28(-76.1496339872435 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark28(-76.16818215514786 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark28(-76.17694288479572 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark28(-76.20885040757675 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark28(-76.21806987075988 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark28(-76.23636652414261 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark28(-76.24693007504786 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark28(-76.25760263779517 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark28(-76.28045757302549 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark28(-76.40844929860695 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark28(-76.4133436112293 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark28(-76.41842393651174 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark28(-76.43141902788513 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark28(-76.44268340865392 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark28(-76.4463090944393 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark28(-76.47892933332352 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark28(-76.50266176745541 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark28(-76.50476147112389 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark28(-7.6527307359218355 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark28(-76.53293730724198 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark28(-76.53983142749647 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark28(-76.54067648384776 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark28(-76.56832970134502 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark28(-76.5829882666257 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark28(-76.59540751371418 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark28(-76.63839922097544 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark28(-7.666392033868945 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark28(-76.67919649451538 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark28(-76.68476215634561 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark28(-76.69580983588129 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark28(-76.73177433915606 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark28(-76.74152395018783 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark28(-76.75474460702283 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark28(-76.81507240092316 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark28(-76.82743754268992 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark28(-76.86810720433846 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark28(-76.94239283371545 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark28(-76.98352470798247 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark28(-76.98519911603128 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark28(-77.08840071726668 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark28(-77.09089099023726 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark28(-77.10494972432376 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark28(-77.13052617960318 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark28(-77.14059819922963 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark28(-77.14515675824167 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark28(-77.18456103542017 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark28(-77.19298188625564 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark28(-77.19890009780849 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark28(-77.24586026229494 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark28(-77.25039511404476 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark28(-77.27450454288362 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark28(-77.28939924255116 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark28(-77.29345599560351 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark28(-77.30732688719803 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark28(-77.3433582256565 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark28(-7.7387476597291 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark28(-77.39310081632752 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark28(-77.4013203924679 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark28(-77.41802070371526 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark28(-77.43111169726652 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark28(-77.44474836601776 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark28(-77.48354051421018 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark28(-77.52699440198137 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark28(-77.55002528252648 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark28(-77.61688999835859 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark28(-77.62836349098619 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark28(-77.63175162846821 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark28(-77.65927624893199 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark28(-77.68876135632823 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark28(-77.7425441224893 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark28(-77.74413775009035 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark28(-77.75288271980506 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark28(-7.77537068482215 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark28(-77.77170616290158 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark28(-7.780369909769064 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark28(-7.780533364428351 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark28(-77.83457719843287 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark28(-77.84281260141455 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark28(-77.8437577705335 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark28(-77.84402560246815 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark28(-77.85227906085983 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark28(-77.90658822697736 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark28(-7.7906994172734585 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark28(-77.94612991135976 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark28(-77.95241090174838 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark28(-77.9846994160782 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark28(-77.98908898052287 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark28(-78.02970482240505 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark28(-78.03437886799799 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark28(-78.03752751641562 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark28(-78.10995043135264 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark28(-78.15797147850566 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark28(-78.16607898941497 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark28(-78.17112592894074 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark28(-78.20971157393002 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark28(-78.24600135617055 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark28(-78.25103103742151 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark28(-78.255433068065 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark28(-78.3322654745684 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark28(-78.34621297738389 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark28(-78.34931157795725 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark28(-78.4376869599445 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark28(-78.44629573006685 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark28(-78.45635650495528 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark28(-78.45854360431377 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark28(-78.52049707902897 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark28(-78.54809967281547 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark28(-78.56520073155494 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark28(-78.67024095511917 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark28(-78.73845208895244 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark28(-78.77038034534966 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark28(-78.79143069020071 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark28(-78.85543207089492 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark28(-78.86302563350509 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark28(-7.8875515961008205 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark28(-78.94642493070046 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark28(-78.9763670883683 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark28(-79.00457343067646 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark28(-79.01150935391425 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark28(-79.04088340961972 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark28(-7.907299445834298 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark28(-79.09964921368191 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark28(-79.10725584367955 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark28(-79.12694619465677 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark28(-79.19873677289868 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark28(-79.24393181850667 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark28(-79.27052100037535 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark28(-79.29310743459592 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark28(-79.31028365299963 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark28(-79.32348441099799 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark28(-79.32359725662778 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark28(-79.33389519237275 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark28(-79.37601817741842 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark28(-79.38574851002392 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark28(-7.9405956619516616 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark28(-79.41895449264216 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark28(-79.43466514287401 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark28(-7.944503396222686 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark28(-7.945000012399177 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark28(-79.4564561209165 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark28(-79.48473307643506 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark28(-79.5285917167325 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark28(-79.5706899444405 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark28(-79.59366497751425 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark28(-79.6356336352371 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark28(-79.64017830104106 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark28(-79.66160053211313 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark28(-79.72898229965878 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark28(-79.77398391590256 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark28(-79.81310135661708 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark28(-79.83132384279988 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark28(-7.984148780207946 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark28(-79.8508118478781 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark28(-79.86688443878363 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark28(-79.8792269083667 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark28(-79.88956685285004 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark28(-79.93097535106838 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark28(-79.96440196528754 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark28(-79.98418911960206 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark28(-79.9908613128741 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark28(-80.02242247418363 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark28(-80.0244428785978 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark28(-80.04670641338838 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark28(-80.14161919933001 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark28(-8.015253452941877 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark28(-80.1652458898607 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark28(-80.1656871685484 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark28(-80.20221793071399 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark28(-80.26267551487585 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark28(-80.30932008422407 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark28(-80.32536312634298 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark28(-80.34242905570754 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark28(-8.034747257855244 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark28(-80.41134927269079 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark28(-80.48214514191538 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark28(-80.5030584175592 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark28(-80.51245196626803 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark28(-80.51573512043987 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark28(-80.55675293362953 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark28(-8.055776402641214 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark28(-80.56450631594593 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark28(-80.56771584830716 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark28(-80.57556366259536 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark28(-80.5879348797079 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark28(-80.60655493462579 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark28(-80.63284460095429 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark28(-80.67292799086678 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark28(-80.68891728261984 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark28(-80.74216770781895 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark28(-80.74645946003727 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark28(-80.77219361635717 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark28(-80.84977066537826 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark28(-80.90598467268038 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark28(-80.93770719663596 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark28(-8.097267540333092 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark28(-80.99903590352807 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark28(-80.99908455977862 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark28(-81.06146064150445 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark28(-81.07044738412364 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark28(-81.07815654339119 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark28(-81.08736919815169 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark28(-81.0897078764929 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark28(-81.11156205281668 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark28(-81.11394461152753 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark28(-81.1371431000808 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark28(-81.14461882340225 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark28(-81.14818637866725 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark28(-81.16775134705657 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark28(-81.20640911187714 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark28(-81.22610437405842 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark28(-81.25870591238076 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark28(-81.29210929114686 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark28(-81.30704127162929 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark28(-81.33950642688532 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark28(-81.36107603725755 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark28(-81.372222163908 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark28(-81.39494657405943 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark28(-81.41827261606245 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark28(-81.43002975523761 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark28(-81.453471505756 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark28(-81.46406440031183 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark28(-81.55606534998361 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark28(-81.60101004895839 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark28(-81.6199067682583 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark28(-81.65404974872186 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark28(-8.169400981770039 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark28(-81.69664359317797 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark28(-81.70805385528391 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark28(-81.72244826530184 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark28(-81.73601754670543 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark28(-81.75061432028093 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark28(-8.176967880323517 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark28(-81.81934148414109 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark28(-81.86534747693557 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark28(-81.87841400272583 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark28(-81.95332880800254 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark28(-82.03134494226879 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark28(-82.05556688615479 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark28(-82.08327199293379 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark28(-82.08963200061355 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark28(-82.09428566762057 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark28(-82.1160980461771 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark28(-82.14102097629998 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark28(-82.1554680076876 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark28(-82.1781226742894 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark28(-82.1991408120528 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark28(-82.31056600673014 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark28(-82.31891353293761 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark28(-82.34271276116175 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark28(-8.234868414372528 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark28(-82.35480933227907 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark28(-82.37256931714967 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark28(-82.38201008355878 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark28(-82.3850046744052 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark28(-82.38750249415202 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark28(-82.47173719799324 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark28(-82.48886031308331 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark28(-82.54531578187616 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark28(-8.255648969435953 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark28(-82.57211346502274 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark28(-82.6095103797031 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark28(-82.62692068369475 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark28(-82.68067954524419 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark28(-82.68852099565653 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark28(-82.71404990634272 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark28(-82.75152666236964 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark28(-82.76773192203592 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark28(-82.77002287738054 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark28(-82.78773648635288 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark28(-82.79745023850197 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark28(-82.79843182490063 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark28(-82.84956533319941 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark28(-82.85652727896073 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark28(-82.86437550481638 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark28(-82.97874606075608 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark28(-82.993201423861 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark28(-82.9954923332 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark28(-83.03413566479028 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark28(-83.0503890267324 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark28(-83.05732709286937 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark28(-8.306438295051862 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark28(-83.10135973925375 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark28(-83.14155125137094 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark28(-83.17118808685879 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark28(-83.17265261221596 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark28(-8.321522896198957 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark28(-83.2233534356736 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark28(-83.23952727001922 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark28(-83.26404323376451 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark28(-83.30442892997453 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark28(-83.36297207560315 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark28(-83.36736711212308 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark28(-83.38188954767527 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark28(-83.38746443448694 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark28(-83.40686042874432 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark28(-83.40873081334274 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark28(-83.44431189682646 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark28(-83.45063691255876 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark28(-83.45429837062389 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark28(-83.45695876995191 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark28(-83.52418036960741 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark28(-83.52456282991125 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark28(-83.5276780049214 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark28(-83.5768514479713 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark28(-83.5788031485034 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark28(-83.58319711895044 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark28(-83.60433519567863 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark28(-83.64677323466424 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark28(-83.65902228112697 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark28(-83.67183323052627 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark28(-83.69626444091769 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark28(-83.69859994452014 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark28(-83.71628525423802 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark28(-83.77541204863779 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark28(-83.79795462805326 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark28(-83.83296484009853 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark28(-83.83578828203574 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark28(-83.85477431454703 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark28(-83.92661815626144 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark28(-84.04509377416699 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark28(-84.057513736559 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark28(-84.15107028811772 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark28(-84.20648482887616 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark28(-84.21619768568527 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark28(-84.23197714061706 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark28(-84.35683827331391 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark28(-84.37329605369332 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark28(-84.38334600880044 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark28(-84.44209181693736 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark28(-84.49816835633695 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark28(-84.51489553867282 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark28(-84.52176220994971 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark28(-8.45228044699104 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark28(-84.55006095180875 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark28(-84.59769423124546 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark28(-84.64966080202848 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark28(-84.66311764223286 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark28(-84.6775024104 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark28(-84.72679434457886 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark28(-84.74535048506955 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark28(-84.77609159609221 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark28(-84.78898637586516 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark28(-84.81136402971876 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark28(-8.481961851145286 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark28(-8.482607845296315 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark28(-84.83168730877388 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark28(-84.83496408822273 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark28(-84.83734408667777 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark28(-84.84060170212098 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark28(-84.85829488313598 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark28(-84.86342554232547 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark28(-84.90689308661076 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark28(-84.91748102691336 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark28(-84.93081454464308 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark28(-84.94696508523982 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark28(-84.97136662710882 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark28(-84.97562004796704 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark28(-85.05356772212546 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark28(-85.06544587951157 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark28(-85.10061718753118 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark28(-85.1470348489619 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark28(-85.1489365734549 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark28(-85.18773178647207 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark28(-8.520291553428677 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark28(-85.22414728615814 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark28(-85.23229393673918 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark28(-85.24419854944007 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark28(-85.2589804011936 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark28(-85.28896321542318 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark28(-85.33084317814806 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark28(-85.35692341437158 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark28(-8.537210688137023 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark28(-85.3838984328765 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark28(-85.41928305339796 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark28(-85.42189397455728 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark28(-85.42284297621146 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark28(-85.45588175351848 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark28(-85.47846432809601 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark28(-85.48531588041615 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark28(-8.549892815469946 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark28(-85.51145402888048 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark28(-85.52183655722354 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark28(-85.52357641899782 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark28(-85.52634457703377 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark28(-85.54221918037143 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark28(-85.57300481375403 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark28(-85.58199022600218 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark28(-85.59578423344789 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark28(-85.59642612806888 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark28(-85.67212713358134 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark28(-85.6730236686309 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark28(-85.70705774218878 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark28(-8.57341330417627 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark28(-85.74840919712645 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark28(-85.7872090463122 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark28(-85.80695074076556 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark28(-85.8185942055062 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark28(-85.82995448818436 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark28(-85.87397967443191 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark28(-85.8795056502668 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark28(-85.90555792918744 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark28(-8.59159558673693 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark28(-85.9522373227279 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark28(-85.96815535094548 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark28(-85.98969860553909 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark28(-86.0201766797058 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark28(-86.08451575382043 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark28(-86.15947139914766 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark28(-86.16035344003026 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark28(-86.16247652184113 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark28(-86.19171524760367 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark28(-86.21221893634173 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark28(-86.2133687579996 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark28(-86.25875674295484 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark28(-86.31066389423596 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark28(-86.31653083912914 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark28(-86.34353507641333 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark28(-86.37199872930188 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark28(-86.37658759171637 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark28(-86.39275161518304 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark28(-8.64048193903298 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark28(-86.43220464780951 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark28(-86.43334002054648 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark28(-86.52128557033299 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark28(-86.52258095076897 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark28(-86.54986829451134 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark28(-86.55536344286215 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark28(-86.56768972775848 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark28(-86.5716197378617 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark28(-86.57748762953253 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark28(-86.5916741855519 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark28(-86.59782442393258 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark28(-86.64224420689416 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark28(-86.73812656272597 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark28(-86.75030157234033 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark28(-86.76334175327096 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark28(-86.78415169500748 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark28(-86.81225478892136 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark28(-86.8230784080839 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark28(-86.89047886507765 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark28(-86.9261888560049 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark28(-86.93037201197293 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark28(-86.93893046217953 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark28(-86.95387262591694 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark28(-86.95844324332147 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark28(-86.96554017736582 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark28(-8.699463733252927 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark28(-87.01369723632872 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark28(-8.705317066138264 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark28(-87.07293789742437 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark28(-87.08590085406256 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark28(-87.10579651036836 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark28(-8.712211696210545 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark28(-87.18612491321922 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark28(-87.21920522970626 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark28(-87.23591943580263 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark28(-87.26162732328599 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark28(-8.72708887093279 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark28(-87.34623410545925 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark28(-87.36134029117545 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark28(-87.36815108600244 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark28(-87.38546997256427 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark28(-87.40082545875664 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark28(-87.40134584813283 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark28(-87.41867686821561 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark28(-87.45325931236472 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark28(-87.49197637731065 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark28(-8.750874612288868 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark28(-87.51808517798689 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark28(-87.54680709827518 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark28(-87.55626781172579 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark28(-87.59590250765541 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark28(-87.6283051941983 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark28(-87.6342064241806 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark28(-87.64153013776472 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark28(-87.65207159474335 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark28(-87.65410837436855 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark28(-8.767451903852418 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark28(-87.70543000236479 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark28(-8.773251940348217 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark28(-87.73290060253083 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark28(-87.73859289938046 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark28(-87.74030561088708 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark28(-87.76082603800057 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark28(-87.81560652471659 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark28(-8.782717252707698 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark28(-8.790969237067529 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark28(-87.94164765068584 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark28(-87.94201979678273 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark28(-87.99417107404909 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark28(-88.02191556275537 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark28(-88.06478137096632 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark28(-88.0711367847975 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark28(-88.09294908066755 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark28(-88.13318681510009 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark28(-88.13956843616117 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark28(-8.815432082064873 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark28(-88.18131217696939 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark28(-88.2020129558421 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark28(-88.22011933583262 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark28(-88.22461464664431 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark28(-88.27017251976075 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark28(-88.29888454677106 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark28(-88.3137417355072 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark28(-88.3218904239838 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark28(-88.3383187384461 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark28(-88.34400455800342 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark28(-88.34434732910262 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark28(-88.34712088921637 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark28(-88.38581701950501 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark28(-88.3906193547887 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark28(-88.39981258772451 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark28(-88.40042550197136 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark28(-88.43585873210284 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark28(-88.44911303802543 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark28(-88.44969397436545 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark28(-88.55036135745111 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark28(-88.55473505824637 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark28(-8.855901416327242 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark28(-88.6217729016296 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark28(-88.64828977929302 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark28(-88.65786797260513 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark28(-88.66618029623348 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark28(-8.869348863365815 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark28(-88.7349595948806 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark28(-88.75264659958955 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark28(-8.877053179066507 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark28(-88.79401697737559 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark28(-88.83216952446236 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark28(-88.864907563345 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark28(-88.89087858000954 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark28(-88.89221511061561 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark28(-88.9983559292219 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark28(-89.00845778558397 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark28(-89.0152593574058 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark28(-89.01802282389353 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark28(-8.909802989240717 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark28(-89.10915548289952 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark28(-89.10988344237545 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark28(-89.14024146315332 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark28(-89.1643424940215 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark28(-89.18984567431356 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark28(-89.19308493486247 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark28(-89.25229312412732 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark28(-89.2532946177421 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark28(-89.2804374971847 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark28(-89.28243149608653 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark28(-89.29516454654309 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark28(-89.3113391223264 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark28(-89.32538680121488 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark28(-89.32726268243152 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark28(-89.34288171391829 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark28(-89.35324652659125 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark28(-89.38740149330266 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark28(-89.39561645801417 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark28(-89.4316592283919 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark28(-89.44116929483077 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark28(-89.46325101004967 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark28(-89.46344371495046 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark28(-89.49889796717005 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark28(-89.51676412341718 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark28(-89.54954063290069 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark28(-89.59095222681172 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark28(-89.61980679233028 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark28(-89.62801226753392 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark28(-89.6302926597078 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark28(-89.63149121652754 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark28(-89.6359556116119 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark28(-89.64709128959699 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark28(-89.66607028044868 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark28(-89.66751529116029 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark28(-89.68500688839553 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark28(-89.69109475650443 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark28(-89.69154572740783 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark28(-89.69350318511823 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark28(-89.72908956927401 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark28(-89.73732025591885 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark28(-89.74273859939741 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark28(-89.79623472998179 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark28(-89.81642305228108 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark28(-89.90631287793043 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark28(-89.94421519090085 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark28(-89.97750295574065 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark28(-90.00851131166412 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark28(-90.01650217600246 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark28(-90.03421313154736 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark28(-90.0390071068818 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark28(-90.04302973370015 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark28(-90.04674957816263 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark28(-90.09408563579697 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark28(-90.1121959017189 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark28(-90.12659247142875 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark28(-90.14626602331441 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark28(-90.15453549807555 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark28(-90.16035302108996 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark28(-90.16485489854979 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark28(-90.19251819304517 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark28(-90.20733337846522 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark28(-9.022134779220863 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark28(-9.022218374617495 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark28(-90.26495663371 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark28(-90.27195100515262 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark28(-9.028789732070749 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark28(-90.28943657823748 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark28(-90.32416550419242 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark28(-90.35291226559556 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark28(-90.42727720855379 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark28(-90.4276958333787 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark28(-9.048790122438248 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark28(-90.49285573499044 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark28(-90.49718069791956 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark28(-90.5008031741796 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark28(-90.50383455077538 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark28(-90.5088156085212 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark28(-90.52128170735435 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark28(-90.52167576981749 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark28(-90.55165503482507 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark28(-90.5696269609385 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark28(-90.60016464914287 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark28(-90.61531046110747 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark28(-90.62532374204517 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark28(-90.6404024773046 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark28(-90.69962037458819 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark28(-90.70973259348736 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark28(-90.75713172733401 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark28(-90.80456711542865 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark28(-90.85798660599316 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark28(-90.8989543980905 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark28(-90.93478936892996 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark28(-90.99686521806238 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark28(-91.04850835433882 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark28(-91.07886897957988 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark28(-91.10194073161908 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark28(-91.13777856284602 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark28(-91.14429032292529 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark28(-9.11461073072735 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark28(-9.115692284767391 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark28(-91.15693228287832 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark28(91.16129561481071 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark28(-91.17077665522004 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark28(-91.1780132994325 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark28(-91.1798076032219 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark28(-91.21158543783756 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark28(-91.23541194130091 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark28(-9.12450481105273 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark28(-9.125764485197323 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark28(-91.28360563998842 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark28(-9.13248037692425 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark28(-91.36262031311848 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark28(-91.39692301440874 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark28(-91.42009301077888 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark28(-91.42864949378054 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark28(-91.45545977444061 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark28(-91.55919197454337 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark28(-91.58493338115652 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark28(-91.58933481402426 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark28(-91.59446593735967 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark28(-91.61040101605234 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark28(-91.61811936745798 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark28(-91.70682438022426 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark28(-91.70970582084155 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark28(-91.77943159744723 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark28(-91.780765688782 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark28(-9.180126534889794 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark28(-91.85425506120714 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark28(-91.89525464092634 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark28(-91.90362598811753 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark28(-91.9855234101451 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark28(-92.02692582154278 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark28(-92.06161555356091 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark28(-92.09037691297826 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark28(-92.11463316452951 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark28(-92.1474742007001 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark28(-92.1875764633259 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark28(-9.219412123051043 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark28(-92.20281097195947 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark28(-92.20772170004199 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark28(-92.23055680773003 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark28(-92.23136651445773 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark28(-92.24845398656055 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark28(-9.225871925368565 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark28(-92.26045428342289 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark28(-92.28497468658132 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark28(-92.41336297822372 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark28(-92.54188890181167 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark28(-92.55126288784258 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark28(-92.57329699323414 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark28(-92.57918558907062 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark28(-9.258291833237237 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark28(-92.64922710110919 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark28(-92.65698599448771 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark28(-92.66306243889844 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark28(-92.67789025110073 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark28(-9.27109510146073 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark28(-92.75174082224879 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark28(-92.75616461948395 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark28(-92.76170467278473 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark28(-92.78495286921454 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark28(-92.83753287537111 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark28(-92.88752784476463 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark28(-92.89483708592698 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark28(-92.92361957018416 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark28(-92.95566082616202 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark28(-92.97445415218513 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark28(-92.99337731477999 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark28(-93.03540864125365 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark28(-93.04612108276957 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark28(-93.08981802123246 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark28(-93.11706934297983 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark28(-93.12369779101815 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark28(-93.16342025952721 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark28(-93.17929836518732 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark28(-9.322687640890834 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark28(-93.26355551063207 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark28(-93.28959921188324 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark28(-93.3442431216785 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark28(93.36142523125673 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark28(-93.39886571504448 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark28(-93.39891675649841 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark28(-93.40430688131111 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark28(-93.4185159928146 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark28(-93.471084907723 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark28(-9.351322310444218 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark28(-93.54487053706993 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark28(-93.55116016445952 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark28(-9.35787794435241 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark28(-93.58312905493878 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark28(-93.58936823770416 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark28(-93.5897709076144 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark28(-93.59441835297275 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark28(-93.61100406496506 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark28(-93.61171927321692 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark28(-93.61534215147019 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark28(-93.67393606229622 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark28(-93.68790839679018 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark28(-93.71233285105687 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark28(-93.72970622610231 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark28(-93.7451805228873 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark28(-93.7729290402318 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark28(-93.79476178954134 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark28(-93.80469039880374 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark28(-93.80589948815525 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark28(-93.8348114012986 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark28(-93.87827796762127 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark28(-93.9282343436264 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark28(-93.93213826537492 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark28(-93.93992949699737 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark28(-93.95055423058767 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark28(-93.96694791572004 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark28(-93.96833245542686 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark28(-93.97818751563437 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark28(-94.00491912867514 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark28(-94.05537426653692 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark28(-94.05823186563711 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark28(-94.06290081362474 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark28(-94.0804424462849 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark28(-9.415135981415276 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark28(-94.16284536451296 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark28(-94.1713196456272 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark28(-94.17831238447181 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark28(-94.17885078524844 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark28(-94.21355156592854 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark28(-94.21586808882883 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark28(-94.23952771231382 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark28(-94.25708744133527 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark28(-94.25908460329164 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark28(-94.26854967222592 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark28(-9.427433208811479 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark28(-94.30009949253895 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark28(-94.37811785935455 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark28(-94.3857411401878 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark28(-94.41287842594835 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark28(-94.41952421686915 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark28(-9.446432627701057 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark28(-94.52582842598329 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark28(-9.455315229067423 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark28(-94.57374875576367 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark28(-94.57508489113813 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark28(-94.58444114274589 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark28(-94.6140642731833 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark28(-9.461700154727865 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark28(-9.46417508669785 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark28(-94.69159889505947 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark28(-94.70495424295994 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark28(-94.72567637943239 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark28(-94.7497816678142 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark28(-94.86897335695465 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark28(-94.87914015798052 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark28(-94.91651874779481 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark28(-94.96351268654514 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark28(-94.97674544702177 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark28(-94.99505856165914 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark28(-95.00147538872443 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark28(-95.00601893765234 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark28(-95.06536885130646 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark28(-95.07114884388903 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark28(-9.511904236330366 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark28(-95.12594980077421 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark28(-95.12888430109581 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark28(-95.15483530895392 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark28(-95.23883974042127 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark28(-9.529137937994562 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark28(-95.32429584818118 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark28(-95.36042545017216 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark28(-95.36746877822195 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark28(-95.39106502056988 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark28(-9.542728063942647 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark28(-95.44263419137022 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark28(-95.46900733694453 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark28(-95.49113219392382 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark28(-9.5493780082287 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark28(-95.49461334473833 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark28(-9.550168371396992 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark28(-95.52482809612654 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark28(-95.53128125646802 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark28(-95.53590763381965 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark28(-95.55378938120039 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark28(-95.56816011913803 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark28(-95.57757004166487 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark28(-95.60488393978544 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark28(-95.63339946532783 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark28(-95.64010274357678 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark28(-95.66436685993726 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark28(-95.66540313492233 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark28(-95.6673354801433 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark28(-95.72573819906938 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark28(-95.7273528165885 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark28(-95.74482356154385 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark28(-95.75766893920508 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark28(-95.79435489631487 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark28(-95.80523116093167 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark28(-95.83482046113812 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark28(-95.86372685032228 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark28(-9.594044799035586 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark28(-95.95156124168989 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark28(-95.99203249277757 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark28(-9.601182432193639 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark28(-96.09072864440517 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark28(-96.14734748482108 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark28(-96.16375420710763 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark28(-9.616546486096595 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark28(-96.17596050576402 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark28(-96.17786732139268 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark28(-96.1936980182475 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark28(-96.21872534242557 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark28(-96.22549900403317 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark28(-96.28080136166892 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark28(-96.31445414556885 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark28(-96.32313740541983 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark28(-96.33564375615093 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark28(-96.35698599383122 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark28(-96.36482870423737 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark28(-96.40127358281335 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark28(-9.64279214476204 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark28(-96.43717775401683 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark28(-96.48624737553418 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark28(-96.5060184533647 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark28(-96.5364585690588 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark28(-96.57011268072837 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark28(-96.57391886577133 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark28(-96.60601345716695 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark28(-96.65180959970414 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark28(-96.66076637196936 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark28(-96.6703110743468 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark28(-9.67020718518583 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark28(-96.7299148345549 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark28(-96.78371109155218 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark28(-96.81497457542156 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark28(-96.85109844491006 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark28(-96.87544871732969 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark28(-96.8807703941259 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark28(-96.91639371219094 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark28(-96.92004476088627 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark28(-96.92071496254124 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark28(-9.694883541514713 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark28(-9.696628425963667 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark28(-96.97720468323767 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark28(-9.702383486693591 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark28(-97.041072544655 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark28(-97.06839470343924 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark28(-9.712168006499894 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark28(-97.13672181230952 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark28(-97.14177291702097 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark28(-97.15200092705287 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark28(-97.17681042610377 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark28(-97.23305268789932 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark28(-97.23305302884306 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark28(-97.27621713014038 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark28(-97.30646430985072 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark28(-97.31173033197653 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark28(-97.32767118204306 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark28(-97.32778600918348 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark28(-97.33100454077395 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark28(-97.33400364768477 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark28(-9.735877865847797 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark28(-9.737539091606223 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark28(-97.39369900198642 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark28(-97.4927248188478 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark28(-97.50450325812399 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark28(-97.51626556061063 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark28(-97.5340332881068 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark28(-97.5343267411376 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark28(-97.54824589152568 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark28(-97.58228457674191 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark28(-97.64743688756592 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark28(-9.765550792088632 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark28(-97.69626893396254 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark28(-97.71608175958468 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark28(-97.72351116896057 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark28(-97.82537301264138 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark28(-97.82578315911157 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark28(-97.84391607575986 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark28(-97.85898504877122 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark28(-97.91554386800779 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark28(-97.93969816709966 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark28(-9.800231589297411 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark28(-98.01589521207981 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark28(-9.80465622031521 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark28(-98.05118485136848 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark28(-98.07517961030045 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark28(-98.19355150679489 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark28(-98.2559522021041 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark28(-98.26817575469953 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark28(-98.2744575626026 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark28(-98.29305939105436 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark28(-98.30017238743577 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark28(-98.32563058423602 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark28(-98.3682353270201 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark28(-98.39167158867012 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark28(-98.39379896565532 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark28(-98.39817617695957 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark28(-98.40718977434165 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark28(-98.44385354469789 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark28(-98.4593580265779 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark28(-98.46442958600441 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark28(-98.50007289874488 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark28(-98.5362202395943 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark28(-98.57523386621168 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark28(-98.59785482808002 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark28(-98.63716696795046 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark28(-98.68170086173987 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark28(-98.69727939133885 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark28(-98.72350214494597 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark28(-98.76322392492357 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark28(-98.76679944135962 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark28(-98.78770582696148 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark28(-98.79720024007914 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark28(-98.80385191977363 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark28(-98.88708973150959 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark28(-98.92420243034886 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark28(-98.95468134412646 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark28(-98.99762105593419 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark28(-99.01112679716444 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark28(-99.02755607905401 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark28(-99.08922481963181 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark28(-99.10231840622639 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark28(-9.910997555516815 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark28(-99.13168352397925 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark28(-99.1330231580555 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark28(-99.1584045030289 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark28(-99.18992247849336 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark28(-99.26123109673142 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark28(-99.27958062184507 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark28(-99.3812785693146 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark28(-99.38378889249029 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark28(-99.40064585151384 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark28(-99.41135535873622 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark28(-99.4378191001154 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark28(-99.44784998574663 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark28(-99.45684253381577 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark28(-99.48064032239292 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark28(-99.49490267678915 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark28(-99.49536914170145 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark28(-99.49968373789746 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark28(-99.52008769810794 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark28(-99.57980719854919 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark28(-99.70391344746967 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark28(-99.74617518836635 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark28(-99.76609760658044 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark28(-9.981136059763188 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark28(-99.82613120211663 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark28(-99.83182376722573 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark28(-99.83234420602346 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark28(-99.8325566023698 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark28(-99.83282503028393 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark28(-99.84605254938961 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark28(-99.86033227567313 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark28(-99.91218654385283 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark28(-99.91985462650013 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark28(-99.92260523523551 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark28(-99.92564768197421 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark28(-99.94393608894538 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark28(-99.95487189304208 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark28(-99.9874586472349 ) ;
  }
}
