import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(-21.638492492642044,-65.82792765972621,67.19645925155422 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(59.40179755582611,-20.946995807606328,38.45480174821978 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(85.38960853401917,-47.77712587196774,-90.35390585043439 ) ;
  }
}
