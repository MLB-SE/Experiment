import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(0.003123975980021241,1.5759430595951571,0.3233142852308596,-46.340722318186536 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-0.003156307171149564,-0.006312613507307496,27.80973687792887,0.003156306753653748 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(-0.0036832269141901376,1.734559922427029E-18,0.7859980579513993,-50.099585441888266 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-0.0037099552965063447,0.001854977597684715,97.16838493001802,43.90360452776245 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(-0.004392602728267719,-0.0012486839401277365,-66.7519503116966,6.243419700637798E-4 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(-0.00506886806735327,-0.005590910781621605,98.25139653130549,41.90329267355938 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-0.007824289390072625,-0.015648578780144667,-0.7809578239645883,1754.0386465587044 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(0.00912586652633782,1.5890417623066213,-298.4790517299127,69.1059156612196 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-0.011160872267427365,-0.022321744152758775,0.790978599531162,-0.7742372913210689 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-0.011705148182842894,-0.023406036971631263,33.052065434978424,-11.696223674060686 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(-0.018919675444527786,0.009459837721998097,166.2373599164231,-0.0047299188609990495 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(-0.019294242809178463,-0.015616315987493315,0.7950452848020375,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(-0.019640382219677028,0.009820190928141459,-0.6267398197120091,10.247134183719153 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark23(-0.019669803089679583,0.0,0.009834901544839791,-0.7853981633974527 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark23(-0.02129358492173372,-0.04258716984346608,79.65467250719567,100.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark23(-0.02408126434496308,-0.048162528689925876,-0.7733575312249666,-0.7613168990524853 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark23(-0.02573695669539649,-0.051473913371419044,0.7982666417451463,-0.7596612067117388 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark23(-0.025821680360516994,-0.006312788500900603,0.7312118542466113,0.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark23(-0.026198102353602308,0.012889869837059146,-0.7722991122206471,-100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark23(-0.02757274416079022,-0.014850805638466276,-0.765566893500399,23.363462083633394 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark23(-0.029941895112095954,-0.05977822596227254,0.014970947556047977,-2.327620297530639 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark23(-0.0308867117955417,-0.06177342359108336,73.99391405265393,79.62643196258334 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark23(-0.03199005056306492,0.01599502528150318,-91.83474744397391,-0.007997512640751592 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark23(-0.03216058452440555,-0.04463700706673798,-64.22917078207927,0.02231850353336899 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark23(-0.032358062544587445,0.009446549566923755,11.880428323320249,-100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark23(0.03247254014642098,1.1996154797232312,21.067991993831086,100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark23(-0.03270793724402346,-0.06541587448804567,56.29801816986936,50.42228012482201 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark23(-0.03322613170436421,0.016613065852182085,0.8020112292496304,-100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark23(-0.0333166390229377,-0.06662486289029362,100.0,-0.6085700270446647 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark23(-0.03467290272570031,-0.06934580545140061,0.48779761859993104,-0.7507252606717479 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark23(-0.03504869314131147,-0.07009738628262291,0.017524346570655713,-53.58077618746846 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark23(-0.03517097256616934,-0.06669576275783529,18.818306791072203,-7.130988289376172 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark23(-0.035196543044942324,-0.011016375253764754,85.05908700766342,0.7909063510243306 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark23(-0.03521026106768714,0.00778721921828672,-62.98136520939104,0.7815045537883051 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark23(-0.03557785688170661,-0.058453058323606366,36.29868981208367,0.029226529161803183 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark23(-0.035634168276080534,0.01781708319282782,24.91025060787642,0.7764896218010344 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark23(-0.036129449242812244,-0.07225889848400499,0.10421965753968641,42.30211841834336 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark23(-0.03767248894027064,-0.07534497788054126,0.01883624447013532,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark23(-0.0381063927910755,-0.07621278558215072,52.580930527453305,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark23(-0.039063970859418595,-0.07812794171883691,55.326770964655985,-100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark23(-0.03907262518023508,-0.041842379011055586,-3.870197694779763,-0.08368475802211073 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark23(-0.039323200328840915,-0.07864640065768169,0.8050597635618687,-0.7460749630686074 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark23(-0.041860951484208875,0.011090640981960213,0.020930475742104437,0.7798528429064646 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark23(-0.04271518212225189,-0.07902760007350379,0.8050111838657164,-4.418080065782399E-47 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark23(-0.04334349104220632,-0.05194061593745167,0.1346422566542029,-67.36121964820701 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark23(-0.04463961064512412,0.02231980532256188,0.02231980532256206,-0.2040536935185835 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark23(-0.04480029134841519,-0.08960041758983533,82.97135358925544,0.04480020879491768 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark23(-0.04484637975234168,-0.08969275950468325,100.0,-63.376598386599404 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark23(-0.047547936454495884,-0.04122545398226856,0.7821282466364925,77.78938282935177 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark23(-0.04830094160498,-0.096601883209956,14.515038080608349,85.90765778521018 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark23(-0.04842744062517623,-0.09685488125035235,-0.7611844430848601,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark23(-0.048848970017431714,-0.09769794003486332,68.35418790605588,0.8342471334148799 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark23(-0.05013475431196229,-0.10026950862392454,0.8104655405534295,-1695.7657574938607 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark23(-0.050995356666322045,-0.05590220817367553,70.18233754964065,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark23(-0.05207701041083159,1.4666281002606532,-91.24008406322692,55.029964691655145 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark23(-0.052085150997748915,-0.10417030199549782,-2291.15034342981,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark23(-0.05222567441403748,0.026112837207018316,0.02611283720701874,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark23(-0.053248659318398214,-0.05830221269608511,-35.30601467400342,0.1058554019135174 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark23(-0.054030128725864386,-0.035668677043098146,-3.2604350378764115,-13.770643038876434 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark23(-0.054252145569347945,0.3785407969295296,31.770318135040306,-15.822118830117898 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark23(-0.05461765846681133,0.8350621558194634,0.027308829233405885,72.6244982647644 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark23(-0.05503242402811922,0.02751621201405957,0.02751621201405961,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark23(-0.055789423867497634,-0.11157884773499516,0.044677008180691924,67.19327760256732 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark23(-0.05719773387302113,0.02859886693651048,0.028598866936510592,-20.11459282716128 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark23(-0.057225844285834104,-0.11445168857166815,0.005510303901429148,-1742.1369459257523 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark23(-0.05779371691087176,-0.11557083698227169,98.81588079847042,-6.25896366455642 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark23(-0.05840102802712312,0.029200514013561496,0.37502694295343075,-100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark23(-0.06169396512536006,-0.12338793025072001,100.0,-0.7237041982720882 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark23(-0.06260708179573753,-1.7763568394002505E-15,0.7983842170083161,-97.17594136060767 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark23(-0.06357396238223778,-0.11968287727940298,63.291302646348974,0.8489721257796865 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark23(-0.06427972125553377,1.4170100603881366,0.8175237046589424,-32.155633032294254 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark23(-0.0644128559063573,-6.938893903907228E-18,44.737003234503455,-0.6285634832214998 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark23(-0.0656038629339224,-0.04823276278296172,0.8182000948644095,41.76756670485338 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark23(-0.06630673608032066,-0.1325113066852922,-79.27011935345385,5.726484930890852 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark23(-0.06709838006737612,-0.07919036081321837,31.13512311701819,20.878713958534757 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark23(-0.06740989338060777,-0.12258787480526841,0.03370494669030388,-0.724104225994814 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark23(-0.06744299661853859,66.52591116482606,-10.3175408036019,-40.92523128772301 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark23(-0.06759470882253202,-0.05274322749433483,81.82918953179575,0.026371613747167413 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark23(-0.06917734756383122,-0.13726070539405352,-0.7508094896155326,96.61288727273558 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark23(-0.06949049520712869,-0.01732427288309568,0.034745247603564317,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark23(-0.06962871478337229,-0.1240411364781395,0.3202122800484975,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark23(-0.06996719239079896,-0.1399343847815978,100.0,-0.7154309710066493 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark23(-0.07005598371119279,-0.02985429654263641,41.206703639087166,-27.598243932797683 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark23(-0.07070436458749246,-0.14140872917498487,9.031372401792376,100.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark23(-0.07150111036124773,0.030753447526467914,-63.93365645631095,-0.01537672376323396 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark23(-0.07393580813621603,0.02550526528317015,43.25514471676742,23.555434036221378 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark23(-0.07521964356733246,-0.12565792807752052,0.8230079851811145,-0.722569199358688 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark23(-0.07625827283760245,-0.10551561558519795,77.8062229787789,38.62389639642963 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark23(-0.0767843539005396,-0.10020897879530138,78.84135473117269,0.050104489397650664 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark23(-0.07775848012307468,0.03295082451838532,100.0,-0.016475412259192662 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark23(-0.07819005324468276,0.025696374178212404,0.4409405237600882,-0.7982463504865545 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark23(-0.07885825362432564,0.0394291268121576,-6.572993372146806,35.36325959232798 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark23(-0.07928711272450766,1.4122177202187558,-0.41671693554166644,-99.66626238645892 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark23(-0.07938734733591024,-0.15877469467182026,100.0,0.07938734733590813 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark23(-0.07946744568657188,-0.15893489137314365,0.6158652646139671,-11.707107527019602 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark23(-0.07994737964409909,-0.12611466953458383,-27.70892708404932,-0.7223408286301591 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark23(-0.0802553800430154,-0.16051073037265298,-100.0,-86.17551709782465 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark23(-0.08061051228655858,-0.16122102457311702,0.028520158223037998,0.08061051228655851 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark23(-0.08110396242179832,0.02278236539795002,99.92034579132272,-1977.3274742275012 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark23(-0.08195374256366483,-0.12190981332364222,0.8263750346792805,100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark23(-0.08217922587516124,-0.16435845175032243,46.90137471295596,-59.07462830319642 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark23(0.0825208897462801,1.6805964058957525,-0.8266586082705882,-42.18044999460584 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark23(-0.08256689660868782,-0.16513379321737554,58.943146129012035,-16.52189887944258 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark23(-0.08266276081946522,-0.1653255216389304,74.1782370189655,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark23(-0.08473292892401196,0.04236646446200529,0.04236646446200598,109.10670223299854 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark23(-0.08474343454226248,0.04237171727113115,0.8085546333716289,0.33584886146506343 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark23(0.08481056407090738,1.720384214784335,0.7429329499740692,-1.645590270789616 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark23(-0.08530332043812905,-0.17060664087624589,0.04265166021906455,0.08530845018852423 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark23(-0.0854111092461649,0.04270555462308245,-100.0,-73.55482466882016 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark23(-0.08596170207065851,-0.1719234041413169,-0.7424173123621189,63.03610187982201 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark23(-0.0859688359942315,-0.17193767198846288,100.0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark23(-0.086160415671931,-0.07680691742463425,28.942664150304974,-0.021540103917983 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark23(-0.08637858792646291,-0.12447344663934862,20.90744531414728,-16.035344745215674 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark23(-0.0885304160990148,-0.13784470968759724,62.55992857572464,0.8543205182412469 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark23(-0.08928928702451078,-0.048556643535069215,-0.7407535198851929,-55.227138817848484 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark23(-0.08954789480082387,-0.16244033921000245,2.090708683001612,-0.704177993792447 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark23(-0.08989366756326966,0.03189999990809772,34.613129303046286,0.7694481634433998 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark23(-0.089935859157727,-0.1798717183154539,3.6813990281431224,56.16956554930996 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark23(-0.09215403533858502,-0.16109814006325518,3.190432727578669,1641.5997066346977 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark23(-0.0924736252825892,-0.18494725056517836,45.624241237357715,37.16151993670503 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark23(-0.09249627090804861,-0.1849925418160941,0.8316462988514717,0.037263727663972894 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark23(-0.09279456022115566,-0.1850773882894149,49.55301593013734,77.99948422491254 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark23(-0.09339673844385654,-0.12807604428921873,-47.001955740100755,21.844701696469524 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark23(-0.09421637233833313,1.382363582115896,100.0,-0.691181791056588 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark23(-0.0942704610362679,-0.18854092207253567,100.0,100.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark23(-0.09444000052375401,-0.18888000104750446,2428.2414763246393,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark23(-0.09657744331141785,-0.018646787046495472,69.32029432601655,-0.058877104105875364 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark23(-0.09785305198286887,-0.1957061039657373,98.42451616040317,797.8324891360069 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark23(-0.09828786162319633,0.04914393081159574,0.04914393081160906,-0.5694465604615243 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark23(-0.09898748142096192,-0.19797496284192384,2.0091442829369797,7.566078928656385 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark23(-0.09937357806994918,-0.07757632659172822,29.22335469997737,100.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark23(-0.10088184349048776,-0.20176368104879083,-9.837811376540921,0.8862800039218435 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark23(-0.10156682106071191,0.05078341053035551,5.087024259259429,71.21892153281101 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark23(-0.1017926199684265,-0.20358523993685296,-2.220446049250313E-16,0.061649861797835215 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark23(-0.10270346276685142,-0.16332183535506323,97.40588661427545,0.86705908107498 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark23(-0.10375777007621956,-0.20589466117871333,-0.7335192783593385,-15.46398226203202 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark23(-0.10382173779077941,-0.1448643997023653,0.051910868895389706,78.6769542239833 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark23(-0.104236442564837,-0.13763343270263362,0.8375163846798668,34.237148822910385 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark23(-0.10443882468256892,-0.20887764936470343,-76.33207399341575,4.509769527687752 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark23(-0.10540001701204973,0.05261134811667773,0.1032453026616645,-0.02649947055652567 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark23(-0.10970801586219103,0.01669719717363874,-18.736948869624086,-0.008348598586820799 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark23(-0.11027751239384015,-0.15419806904920108,0.6312000943482445,37.07566317308729 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark23(-0.11063503685564857,-0.19551516764403257,-0.7232197379301012,0.0977575838220163 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark23(-0.11250746385079685,-0.09381215338498314,-0.7106963331692251,57.981850155170235 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark23(-0.11255962575739592,-0.07422582326824335,-9.26924960161215,0.03711291163412167 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark23(-0.11338413069580999,0.002949951767825068,-0.6139018690686473,-0.7289323001760807 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark23(-0.11354721169810125,-0.17971340612243766,0.056773605849050626,0.8752548664586683 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark23(-0.1142075340613076,-0.2284150681160069,74.83972895604488,-3.6798094634845375 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark23(-0.11448133272298812,-0.01622056662933035,0.05724066636149406,11.968143966155552 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark23(-0.11450043199154436,0.05725021599577129,-13.736236412963772,79.1866818703263 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark23(-0.11487819543732317,0.05743909771866157,-38.4182052392532,0.5162487575663448 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark23(-0.11564439173307972,-0.23128878346615933,61.698934312462015,-27.63017579734068 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark23(-0.11748712051642599,-0.2349742410328517,-0.7266546031392352,-3.3614079688320935 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark23(-0.11821177821520557,-0.23642355643041102,100.0,43.06034064672408 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark23(-0.11894179139827088,-0.23788358279653998,-0.725927267698312,72.19994076030285 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark23(0.11896879820333098,-0.07678750953638507,-28.333817899517857,-32.47556062167483 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark23(-0.11907103306304698,-0.024447005867946323,-0.7258626468659248,-74.31984692229443 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark23(-0.11982861046948551,-0.23965722093897018,-0.7254838581627054,-75.08411918520967 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark23(-0.12018940108729759,-0.21824717100450383,0.060094700543648794,20.033181678986214 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark23(-0.12042606413117674,-0.15371921917375464,-54.85563976202296,-84.48722707155527 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark23(-0.12278490414896837,0.05854492424061887,0.06139245207448418,-100.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark23(-0.12284905172480803,0.06142452576591099,-0.5116512163525225,0.7546859005144928 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark23(-0.12317515918721157,2.0260741950997824E-20,0.7239853286127632,-0.857382361664873 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark23(-0.1244374326002837,-0.13431232300434504,100.0,0.8525543248996208 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark23(-0.12544100392198818,-0.003918581690227886,53.98707107276957,-0.3746936606452086 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark23(-0.1264237802733198,-0.1961413860111606,-100.0,0.0980706930055803 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark23(-0.12892183760622405,0.038554579953786694,95.0976368199688,0.7661208734205549 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark23(-0.12939486994701654,-0.09055551038185516,0.06469743497350827,-0.7401204082065207 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark23(-0.13007035113956353,0.06294855858953985,76.0025731202447,0.7479734797027431 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark23(-0.13019177039002297,0.06509569655142886,-3.687564344075865,-0.03254784827571444 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark23(-0.13081301465172504,0.0654065073258625,72.03774361846267,-67.57941032466229 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark23(-0.13114512711469137,-0.2622902542293827,80.21154947835468,-100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark23(-0.1314619534799737,-0.07297713676517109,-83.0998386800892,0.036488568382585546 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark23(-0.13182719021490405,-0.1881782632744899,100.0,0.09408914470272957 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark23(-0.13231825435564937,-0.2646365087112987,24.413502150229622,-0.6530798441318622 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark23(-0.13249659657638424,-0.11274842858585998,-0.7191498651092562,11.97212315356336 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark23(-0.13498919144001476,-0.17371441615825323,0.8251996330429114,0.8722553714765748 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark23(0.1362177371379177,1.8431894027565354,85.22440551222185,8.565711474574968 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark23(-0.13719682434526487,-0.2743936486905296,-67.26881637780933,41.795849278294476 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark23(-0.1374803742534467,-0.27496074716093416,0.8130709998472379,-28.594748559492952 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark23(-0.13786669208611646,-0.27573338417223286,-98.50658749651892,100.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark23(-0.13961204147143944,-0.2792240829428785,-100.0,0.13961204147143924 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark23(0.13978898977132048,0.45084494500876826,91.35711505743791,-1.020158968910361 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark23(-0.1404894792416317,-0.280978958483252,-0.7151534237766325,29.13128934614791 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark23(-0.1411831154998654,-0.23210402244317885,-0.6877475492406222,100.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark23(-0.14156723638100505,0.0707836181905025,0.07078361819050252,-62.5464629021768 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark23(-0.14167480100332797,-0.2833496020066557,3.2515257077015507,0.14167480100332785 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark23(-0.14209974552302274,-0.047421949022932786,2302.3628616661767,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark23(-0.14271219417809206,-0.2854243883528869,50.908022638637505,68.30034476629825 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark23(-0.14309778847760324,-0.2823287320254362,0.8569470576362499,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark23(-0.14439304200977776,0.072196520994815,-22.28877317323917,94.2543356243134 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark23(-0.14454693457729817,0.07227346725607106,-37.77854878840877,-1999.066175418771 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark23(-0.14600751842295434,-0.09589500645899807,-0.6931667777055682,-0.7374506601679514 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark23(-0.14694082160219013,0.07347041080109504,-9.152922382994944,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark23(-0.14728461251736524,1.154698204969959,-0.7117558571387654,-91.68353089961725 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark23(-0.14788031034890137,0.07394015517445043,-0.7114580082229975,-0.8223682409846735 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark23(-0.14836177169624165,-0.29672354339248325,54.00138166947108,67.64728604695165 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark23(-0.14869077692240643,-6.612349992817924E-13,65.47653045646388,3.30596661157756E-13 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark23(-0.14911164846529032,-0.08312628894257822,-72.91863340602768,0.09602366812733965 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark23(-0.14939475849338693,0.07469737924669345,22.13850745222694,100.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark23(-0.15045330244941035,-0.3009066048988204,0.8606248146221535,-1.1923110380625834 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark23(-0.15065157867995552,0.07532578456420325,100.0,99.99999999996167 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark23(-0.1506904227152139,0.07514751239260821,0.4878875136882198,-0.03757375619630411 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark23(-0.15071811167648197,-0.30143622335296394,-59.21616233747198,-0.5635548482563499 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark23(-0.15116772403483936,-0.3023354480696785,-0.30233544806968027,0.9365658874322875 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark23(-0.1522596142853324,0.0750277377464815,0.07612980714266626,-32.632268801148456 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark23(-0.15261436691168528,-0.14284991317923745,-100.0,-0.7139732068078324 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark23(-0.1544605224227119,0.07052329227015157,140.66349640629946,0.7501365172623725 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark23(-0.15459332745629667,-0.30132690274623397,0.8626948271255966,0.9360616147705653 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark23(-0.1547351638861647,0.05790692224871965,52.83767830169623,-0.028953461124359824 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark23(-0.15583342411944615,0.07320481778942278,-0.707396806995829,0.7350646728557042 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark23(-0.15710788549873822,-0.29986255644941395,74.65064472169506,0.2578461576925679 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark23(-0.1572370650969206,-0.3144741301938404,22.434128432653353,71.05274263511456 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark23(-0.1580318904921323,0.07901594524606592,53.966015439949636,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark23(-0.15817371183647563,-0.31611558454860056,0.8644850193156861,0.9434559556717487 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark23(-0.15900103504175755,0.03621744750215192,-0.7058976458765696,-26.593270889684927 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark23(-0.1593061129770023,0.03294389607930915,-100.0,-0.016471948039654793 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark23(-0.1594017555086076,-0.2258056048889615,-30.601966989398942,-0.6724953609529676 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark23(-0.16002417594468657,-0.17534317321758439,0.08001208797234327,23.38458084992402 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark23(-0.16039595808567775,-0.18865118616079596,12.454019437552681,-1716.2753321190319 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark23(-0.1606167592622123,-0.06679422385792311,49.02981780162284,-100.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark23(-0.16113679664163888,0.08056839832081941,0.8659665614752237,0.7437990439176129 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark23(-0.1617930759207014,0.015391383854090161,-0.6206202948331098,-0.007695691927045027 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark23(-0.1626829636197763,0.08134148145858515,20.71208230838791,-1387.5884704282375 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark23(-0.16329219359592706,-0.2796875136041204,-0.7037520665994847,100.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark23(-0.16371340488343478,-0.32742597691207787,34.1630299622862,76.47303596351392 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark23(-0.16386437430369283,-0.3084863696435835,46.42775695032404,0.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark23(-0.1640631343049883,-0.3281262686099765,0.4830303797629448,55.996448778297484 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark23(-0.16492072518469547,-0.3298414503693909,41.17650218623876,39.035800609378946 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark23(0.16663322491492247,0.3444475839572485,-0.08331661446613266,-136.78597967226398 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark23(-0.16703938942370264,-0.17667851678216892,-79.65209056682198,0.08833925839108446 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark23(-0.16970924157435663,-0.2883678254417777,0.8677896008867959,-100.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark23(-0.1715652174687603,-0.24335233496237213,0.0857826087343802,-1778.9340003963491 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark23(-0.17198721550870555,-0.2838192836440907,0.08599360775435277,1.4188534849060266 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark23(-0.17201904209028082,0.08600270370461728,87.49472512808272,-83.12936508346895 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark23(-0.17309452702746525,-0.33365021556288904,96.69045329955004,-0.6185730556160037 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark23(-0.17354770371630052,0.08677385185815023,100.0,-100.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark23(-0.17357834621480805,-0.34715669242961605,-38.04778601269194,19.12387410975365 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark23(-0.17614098951643464,-0.019645530271378053,-28.948712519760505,-1.2149958688437639 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark23(-0.17700062684590262,-0.3539520677358928,-0.4262759914877672,-53.311060282080874 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark23(-0.18063285467241547,-0.3519661845753723,-56.88547907501294,-21.79278281068119 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark23(-0.18181498277308572,-0.23176323621570485,-76.6131010773711,0.11588162730426599 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark23(-0.18314219192543324,-0.3648950237025562,0.09157109596271662,0.9678456752487263 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark23(-0.1837496353650468,-0.3674992707300896,-0.6935233457149249,-0.6016485280324034 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark23(0.18397090133868077,1.7768241065106605,-0.8773836140667888,-60.53132290348872 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark23(-0.18438260617928226,-0.36876521235838816,0.8775894664870895,100.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark23(0.18455265917982047,-0.8762229877568606,285.91876890475,14.573875799430589 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark23(-0.18481148034451847,-0.369572819851882,3.2940677793403985,0.184786409925941 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark23(-0.18520740708642608,-0.36322531391122365,58.301174191199294,-0.33842291259992563 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark23(-0.1858421056935562,0.09292105266397144,51.143801637285605,0.7389376370654626 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark23(-0.18592264902550504,0.09296132451275249,75.8518505545409,81.63669062810507 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark23(-0.186146470635984,-0.27323602963365934,0.8216647350533857,-0.6222010612410749 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark23(-0.18688773655681423,-0.37377547311362835,28.5593109942804,98.33326409237903 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark23(-0.18790697974988954,0.08326703021274715,-95.4262104657802,0.7437646482910747 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark23(-0.19017325865668372,-0.37780019448550295,0.88048479272579,0.9742982606401998 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark23(-0.19072796406975812,-0.38145592813950735,0,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark23(-0.19158718455397783,-0.38317436910795555,-34.273590838138084,-97.76708335083458 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark23(-0.19169771595193785,-0.38339543190387526,54.984301360908816,-39.980657603381204 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark23(-0.19236424037795166,-0.36533091523025757,-28.06130716320685,0.1816461874168045 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark23(-0.1923947690651884,0.08777743776399466,0.8815955479300425,-0.8276185041624852 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark23(-0.19263501693982404,-0.2441154389714229,-21.22236970940702,-48.7199837984825 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark23(-0.19323274813140315,-0.3514152400317828,-0.6887817893317467,15.06167014815587 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark23(-0.19591758382108626,0.09795879191054312,46.72676053405128,-100.0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark23(-0.19620618548794422,0.09810309274378565,0.8835012561414204,10.241712288306914 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark23(-0.1981182683749751,-0.39623653674994996,37.52655177690602,12.433160846934015 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark23(-0.19975010088572656,-0.313841024296701,0.8852732138403115,-56.683496787390936 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark23(-0.19976544593785417,0.09988272296892703,12.57315608670966,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark23(-0.2006890329067002,-0.3563769549869883,-26.185790387595844,0.1781884774934941 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark23(-0.2019504127886307,0.04079449947713959,-19.31723807223406,99.89062277534285 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark23(-0.20279048139664058,0.10139524069832007,0.47650725923088944,-57.84573213996153 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark23(-0.20356578776908596,1.1404181673518952,0.08014807345230937,-45.33344749986101 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark23(-0.2045427924023159,-0.27424989791497417,0.12200186342637274,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark23(-0.20520657525332198,-0.41041315050664384,-100.0,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark23(-0.20601884993854241,0.10300942496868083,-71.84694741773683,-19.51572990198286 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark23(-0.2066227200508478,-0.19034674705321772,-0.6820868033720242,82.2894732108835 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark23(-0.2068008501348553,-0.41319669368651724,85.11408693596384,0.20659869983262805 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark23(-0.20699446928972814,0.10276645196315971,0.1034968637929694,-0.836781375875419 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark23(-0.20801622168925338,0.10400811084462624,-37.10203975294556,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark23(-0.20888095273352275,0.10397040155017259,0.8893270444720853,-69.3427337741555 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark23(-0.20929738154043567,0.08883500295167002,0.7090920434148537,-34.83268783744832 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark23(-0.209440436587542,-0.404746573199957,-73.62295634153357,4.073262108515848 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark23(-0.20961745036944174,1.1515614260560127,-100.0,-1.3611788764254547 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark23(-0.2116341807253324,-0.4232683614506645,23.67791846735698,43.1991116900928 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark23(-0.212374603995774,-0.4247492079915479,-51.20717352460635,100.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark23(-0.21312487138191338,-0.4262497427638266,44.42610760548504,-100.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark23(-0.21493618456276897,-0.36584861344457054,0.805491015516848,-10.034906945352759 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark23(-0.21598997987685492,0.07337098917346538,100.0,0.747397748491289 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark23(-0.21635511861521395,-0.43271023723042745,74.7445794496634,-81.22634481178676 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark23(-0.2180603295816388,-0.11647118542914514,0.8944283281882676,0.05823559271457259 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark23(-0.21956695043700242,0.048644515999417104,0.8951816386159495,1.928455492020305 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark23(-0.22001883386689247,0.10288008362410289,-12.71584002289439,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark23(-0.22247569126416686,-0.28198393204487426,100.0,49.38205081740581 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark23(-0.2225554021470666,-0.44511080429413297,-0.17457472582858014,0.42822684102593844 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark23(-0.22290821866179727,-0.4458164373226993,65.31172164644612,-31.84759346663675 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark23(-0.2229717285248985,0.11148586250702061,0.11148586426244925,-0.055742930578427004 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark23(-0.2241885451297052,0.040639789347157285,-100.0,100.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark23(0.22474766313194383,-0.11243352877178094,-15.034938164784005,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark23(-0.22476811909977812,0.024867714686475417,24.89257909706158,-75.15064952236877 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark23(-0.22503689016637315,0.08450590222789199,-0.6728797183142617,-27.772905452146524 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark23(-0.22504873791017696,-0.36989868822164307,90.43216841433802,0.2071291104522278 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark23(-0.2260046617987568,-0.24634854843572612,-19.406405356350476,100.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark23(-0.2261313235630581,-0.4522626471261161,88.10756859328941,-97.50956570771712 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark23(-0.22654054114508076,-0.33341931452153756,-0.6721278928249079,0.9521078206582171 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark23(-0.22793664001504443,-0.45587328003007294,0.11396832000752222,26.182598001259123 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark23(-0.2289274614757688,-0.4578549229514653,-53.88249672665607,0.22892746147573265 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark23(-0.22901237333215896,-0.4580247295369777,-0.6708919767313688,-5.261076534646689 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark23(-0.22923712382143452,-0.4454983251350381,-0.670779601486731,99.8583220491466 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark23(-0.22967690675650942,0.1148384533782546,0.11483845337825471,61.2036359305531 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark23(-0.22999655584334944,-3.3881317890172014E-21,0.11499827792167472,-0.7836394829414216 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark23(-0.2310426400810869,0.08215002474340134,0.9009194834379918,90.5885588577532 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark23(-0.23106507303816945,-0.03150644333522515,0.11553253651908472,-68.50355619182342 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark23(-0.23173334266545473,-0.4634666853307554,0.11527619831621556,-0.5536648207320622 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark23(-0.2323913130748939,0.11619565653744553,-6.692344431274822,100.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark23(-0.23391306794335906,-0.22328607696138575,13.39468276180618,-0.6737551249167554 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark23(-0.2339351893040328,-0.3445461856656884,0.18838221224010798,-2018.7255091224158 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark23(-0.2355846816140947,-0.17555769357990347,-0.5104517951279353,100.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark23(-0.23558842159345916,0.060509265991788214,0.11779421079672958,45.692563205836976 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark23(-0.23963672800522218,-0.10405316110993024,-62.17146235661956,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark23(-0.24023639132264055,-0.48047278264528104,-0.665279967736128,-1.262637561333861 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark23(-0.2428127138871714,-0.4856254277743427,0.0068206347493596775,-72.70531254513705 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark23(-0.24335020846438127,-0.30630243828901005,100.0,100.0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark23(-0.24464017735243396,-0.4892803545536521,0.9077182520736653,0.24464017727683288 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark23(-0.2456740622468084,-0.2969545010028938,0.2610554529853216,58.63276380684164 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark23(-0.24609161564569115,0.12304580782284556,-0.6620868386744966,-0.06152290391142279 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark23(-0.246168118528382,0.020024115218461702,-63.92689858730963,2066.753032398538 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark23(-0.24656748568925657,0.1107444565611394,0.12328374284462917,2070.563927129618 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark23(-0.24657411996855494,-0.16445128401773168,5.635315662525775,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark23(-0.2473724696680648,-0.3808160786652529,11.105113750466248,42.061676159091846 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark23(-0.2474090800704678,0.7935332309816603,24.542305087828087,-67.4380759074543 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark23(-0.24844831963434885,0.12422415966783433,0.7106870778551708,-0.2311050904811794 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark23(-0.25022284215613855,-0.16006713488163798,0.9105095844755176,0.08003356744081898 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark23(-0.25047491728608196,-0.3040959562826609,58.08336806808965,0.1520479781413305 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark23(-0.25203140820114905,-0.504062816402298,32.28330530041387,-43.1979518332345 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark23(-0.25229410925511475,-0.45662815579296684,58.91815219027722,-194.54299576889545 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark23(-0.2530130204440578,-0.5060260407019249,0.1265065102220289,-0.5323851430464859 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark23(-0.25427305445033727,-0.39389217301501167,0.12713652722516863,92.00769538755885 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark23(-0.2546124008727096,-0.5092248016447561,6.40706352282705,-27.355563901359645 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark23(-0.2553901046007312,-0.18761023965670626,0.12769505230036593,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark23(-0.2554602287957141,-0.46307025948503355,-0.6576680489995912,-77.31279626275678 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark23(-0.2558231756259926,-0.47915786012153677,40.68192203612372,-81.62982004947426 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark23(0.2559426654799031,1.5759572216641005,-0.9133694961373529,-1.7151151353649396 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark23(-0.25648758909335173,0.12728449394458607,0.9136419579441241,0.7217559164251552 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark23(-0.25788139936056753,-0.4682919214557466,0.8880157583376183,-0.037214286133779764 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark23(0.25788990825081115,2.0865761432965173,99.99999789564332,29.58724399525245 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark23(-0.2586394391666842,1.0535174484615275,0.9102853136241005,100.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark23(0.2592952685238053,2.079890516631812,15.804424506993072,86.63989915908961 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark23(-0.2597380085954351,-0.37978487031487873,-0.6300082371495177,7.477958800487333 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark23(-0.2613279801443096,-0.522655960288619,0.31126974066804175,80.77453027534781 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark23(-0.26224722095437214,-0.516466164515031,37.54387597784958,0.2582316436961888 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark23(-0.2645695797738117,0.1322847898869058,-26.093517084191475,99.99992344120922 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark23(-0.26576962582266783,-0.5315392516453352,66.836737049362,59.63943845420792 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark23(-0.26588866068384426,-0.12113394108250952,0.7398243390243714,-0.28692585162715023 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark23(-0.2664420229320354,-0.06007753256776958,100.0,58.157200298774164 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark23(-0.26669736512841097,-0.5296932053748054,-0.6520494808332428,51.073356264830664 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark23(-0.2668931668363541,-0.5337863336726976,-0.6519515799792712,28.83285407642512 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark23(-0.2669161585779174,-0.5338323171558347,-29.574320427110518,1367.1732307299292 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark23(-0.26724860778448356,-0.5344972155689669,0.4077701677703802,0.26724860778448345 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark23(-0.2674947276675783,-0.27091186757568747,0.9191455272312374,-59.38690731050719 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark23(-0.2683609597112313,-0.35402621999183265,-0.5456457564289762,46.837640302984596 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark23(-0.26897023023829464,-0.5379404601037695,33.90648921323685,81.17571456335045 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark23(-0.26990657408211893,0.0033410132622474498,0.13495328704105958,1867.3540428628476 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark23(-0.27017605253983334,-0.4977722427472689,0.895100417275245,-0.04249795289863747 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark23(-0.2702623151877219,-0.021137952471588006,16.371119512231417,-4.858998727800074 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark23(-0.2708257017722728,8.935902256778368E-14,88.07216355507782,-2.7947113617523427 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark23(-0.2713151552619042,-0.5426303105238082,82.35346148416915,882.6174864729792 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark23(-0.27244137717581984,-0.0930759319855231,-0.47794949979915113,-0.19179255360695024 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark23(-0.2728769949245845,1.0226857563566403,0.9218366608597405,-68.84086893134733 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark23(-0.27427368825600595,-0.5485473765120117,0.09986923840950418,-0.5111244751414424 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark23(-0.27490176542486966,-0.029413060866118612,-100.0,-90.58465948120889 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark23(-0.2762168683624277,-0.552433736723897,28.176229711728052,-44.93762743396243 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark23(-0.2763702455239897,-0.09441669715664922,-0.6472130406354533,1896.6536442362476 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark23(-0.2769084466563885,-0.3803870995918146,100.0,-4.197273644206312 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark23(-0.27692125998095096,-0.5536601786156586,0.13846062999047548,-32.83317633720885 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark23(-0.27735511756679315,0.026596522351959723,-72.23951395091876,-26.28623114891544 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark23(-0.27868155802234407,-0.5573631160446878,-73.33421703120408,21.445533418803326 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark23(-0.2791361553936136,-0.558272310787227,0.9249662410942551,-6.005119324212803 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark23(-0.2792749671106285,-0.5015342183699742,0.9250356469527625,55.93322645891405 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark23(-0.280336437097264,-0.4855601046470161,0.12139002616175398,-83.01034647527717 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark23(-0.2807497888822452,-0.23121505299340817,0.1403748944411225,-25.171402786650702 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark23(-0.28473218119618604,-0.5694643623923716,-0.5694643623923703,94.14719342813393 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark23(-0.2849322229745285,0.3494581744448726,100.0,-70.85980889806807 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark23(-0.28567073380744124,-0.5713414676148824,-0.6425627964937276,-0.49972742959000704 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark23(-0.2857004088094548,-0.4122894414173901,0.1428502044047274,-20.159245830918024 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark23(-0.28593060089304045,0.14294650955073673,69.13851536329675,31.48669417822235 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark23(-0.28692890408741123,-0.5738578081748223,-0.21585579467248447,-0.362307974313957 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark23(-0.28919741503960894,0.13261725575335848,-89.08543134671218,-0.06630862787667924 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark23(-0.28968306019633705,0.3743367831219409,83.4027837319232,-62.23247059108141 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark23(-0.2905342777215827,-0.46849705373572803,1.0330662503585621,-75.61034638156103 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark23(-0.29191562681972777,-0.5765483270423862,0.10899347688543239,-0.49712399987625516 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark23(-0.2929696854531814,-0.5841471054790599,13.209527634032172,0.29207355273952995 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark23(-0.29403613627489283,0.9827240542451104,0.14701806813744642,30.922307793983297 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark23(-0.29524704529756673,-0.5904940905951321,0.14762352264878337,48.13872588614443 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark23(-0.295542889105653,-0.5910857782113059,-0.6376267188446217,100.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark23(-0.2961980785023916,-0.5865030954341317,0.14685605468689467,100.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark23(-0.29699036379534804,0.14822517861197979,-0.005784488792198374,-7.910735276461425 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark23(-0.29733100547472624,-0.5946620109494489,0.1486655027507581,1833.6835435767885 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark23(-0.29779445641672875,-0.3850523931069983,100.0,0.1925261965637575 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark23(-0.29800644469293824,-0.1551616498174423,113.7633878133918,22.742001618456538 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark23(-0.2987969908602176,-0.5975939817203568,0.9347966588275571,-5.743158040851327 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark23(-0.29887931555987945,0.12927793361257647,100.0,-196.04369883534218 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark23(-0.2994772911676251,-0.5989545823352498,0.1214811643324818,2107.5926698701305 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark23(-0.2995728110103802,0.004914996494862156,58.7155286600937,-0.8994576137829426 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark23(-0.30010905837263513,-0.09578369807871633,-35.066320671991974,100.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark23(-0.30056768134707845,-0.2821684238278008,-16.4447937335729,31.866512497140743 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark23(-0.301351688785245,-0.6027033775704898,94.84478967547021,1.0867498521826933 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark23(-0.3014484743440757,0.14306977436263235,6.8419373776165,24.748502265555295 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark23(-0.3019419779433009,-0.5955318516068907,0.9363691523690988,1.0831640892008936 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark23(-0.30251714744823377,0.14070791154899767,0.15125857372411688,-5.568735677317512 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark23(-0.30284941429693296,0.15142470714846645,-30.480994353656108,-28.240759835365132 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark23(-0.3031048281628058,-0.6014738586990105,-0.6338457493160453,1.0861350927469535 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark23(-0.30368565098187517,-0.5481708525401058,0.1370854353032695,0.2740845045388567 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark23(-0.30370822143926257,0.13334969011025843,0.24492870608377212,-1.2708992137214254 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark23(-0.3046542897016825,-0.04243585923906106,-0.07382837371607565,21.74561129133651 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark23(-0.30531021054979285,0.15265510527489634,-53.00975808540913,-0.8617257160348964 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark23(-0.30581886303403516,-0.4522267272134314,18.060832846915513,1.011511527004164 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark23(-0.3061898305201438,-0.5108303030337227,-0.6323032481373764,49.735499480556484 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark23(-0.3065827926114464,-0.6131655852228926,0,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark23(-0.30678045787123875,-0.6135609157424766,1.397782240301741,75.19682660879079 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark23(-0.3072563885098795,-0.32875316757346357,0.8128455432219958,-0.036125518847397245 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark23(-0.3074531835604223,-0.5540609828191521,0.8863609973567126,-0.5083676719878722 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark23(-0.3079067743305505,0.12484352555497069,83.81868685017348,-44.765756517368764 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark23(-0.30917695777137083,-0.5950308358667178,0.9399866422831337,-0.48788274546406096 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark23(-0.30962940928372973,-0.6049240616573227,60.47693347924517,64.63962491150376 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark23(-0.31004519824005927,-0.5312025345246058,1.4961619744754673,0.2656014022716332 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark23(-0.3103568312799194,-0.4022362456638371,0.940576579037408,0.20110347221457747 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark23(-0.3108243938613908,-0.5540414349657585,100.0,100.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark23(-0.31087989699493473,-0.3213252338998277,66.78967747057817,0.0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark23(-0.3113579021750144,-0.06606071800829023,-0.6297192123099411,0.03303035900414512 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark23(-0.31174120313982123,-0.4982804793902396,-0.6295275618275374,81.88133047950197 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark23(-0.31174596600199184,-0.623456758931305,-0.6295251803964523,-98.74915369081836 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark23(-0.3118793003852151,-0.4001589282526538,-79.04221445634927,0.20007946412632693 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark23(-0.31308092650717256,-0.6288577001438619,-100.0,-88.04129461389245 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark23(-0.3131508742474357,-0.02208537789043397,0.15657543712371785,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark23(-0.31354915395667504,-0.5835180596556567,0.15677457697833663,38.77525731800292 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653252534,-0.23678332860349272,100.0,0.47307049340446383 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653585441,-0.6181485574468905,0.9424777960767203,100.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589793,-0.5978036682369814,100.0,100.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535898053,-0.628318530717958,-100.0,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589811,-0.6283185307179565,100.0,2086.9375641405027 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589833,-0.34135792269764326,-0.6283185307179566,100.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535898653,-0.6094989752037693,0.15707963267949326,-0.48064867579556375 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589882,-0.1512727032291023,-8.676729350284091,100.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653589936,-0.6283185307179515,-99.999999999999,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark23(-0.31415926535900596,-0.6283185307179453,-100.0,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark23(-0.3141592653591116,-0.6283185307178923,0.1570796326795558,99.9999999999998 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark23(-0.3142663190886694,-0.31857884688167476,0.1571331595443347,-57.36757659019754 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark23(-0.3144802389680357,-0.6272460484019345,0.9426382828814661,-100.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark23(-0.3147718184377446,-0.4673886542669318,50.70536490181533,0.2336943271334659 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark23(-0.31482533684839076,-0.022068503449382548,0.15741266842419538,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark23(-0.3158385622567199,-0.6189347663921443,-0.6207637884496224,44.25574021235385 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark23(-0.3158601072667029,-0.6256044690864578,4.083620160195114,-36.120623359102105 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark23(-0.3159187060632518,0.1579593530316258,2.0343786579603904,-10.374231947343603 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark23(-0.31677888095210904,-0.6262874136868503,0.15838944047605452,14.435076156471727 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark23(-0.3183543385424297,0.15917716927121478,100.0,22.08209757034791 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark23(-0.31838285540078703,0.14420920294727377,-0.6262067356970548,-0.0721046014736369 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark23(-0.31890686580720984,-0.48054215458970984,-83.82606809421303,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark23(-0.3192530290941818,-0.5749302534071012,104.56302604005913,-191.89616771849433 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark23(-0.3193929516869931,-0.3104661701132469,-0.5757302533068822,-50.007081345123204 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark23(-0.3201211403322973,0.003681321890703304,0.16006057016614866,-1.1265859202610073 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark23(-0.32026296175645164,-0.6252666825192225,-51.60884560333479,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark23(-0.3213441678299475,-0.6247260794824745,-0.6113906836096756,-0.470644309611392 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark23(-0.3214840635894485,-0.5139301465653404,0.7962704991123192,0.25696507328267015 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark23(-0.3219170115611433,-0.6244396576168766,1.284894975253834E-5,-0.48028579014877537 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark23(-0.32235803930559315,-0.6190611896670557,-91.97797969735979,-100.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark23(-0.3228165544521697,-0.012999584691503724,0.8883682865015986,-0.7788983710516963 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark23(-0.32337085735196924,-0.35394505450105507,0.16168542867598462,0.9623706906479755 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark23(-0.323566532777547,-0.6236148689143257,-0.6236148970086748,-34.26892188102439 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark23(-0.3249769055732965,-0.011078486854035216,109.34511508435918,-130.95477132767044 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark23(0.32505961460877403,1.3451679452168586,93.33458110307335,100.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark23(-0.32559758371489633,-0.19687136459003307,0.6859897472971493,-0.6669044099534707 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark23(-0.3268972178662597,-0.30853757003530513,53.64142749690738,-26.499942930658733 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark23(-0.3273872851499764,-0.6217045208224597,-74.75434236777905,0.31085226041122915 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark23(-0.3277917886144195,-0.6215022690902381,59.71672718062598,-8.114982666052825 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark23(-0.3279034271110756,0.16394512367139857,47.34576078346542,-0.2563315539920342 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark23(-0.3280332973108137,-0.08623084510023472,0.9494111373342222,0.043115422550117355 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark23(-0.32868057531491757,0.0,0.8178688039218843,-125.57851944572303 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark23(-0.3289480107211057,-0.48469652660966744,39.838431107034346,84.81109479776079 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark23(-0.3293351206995898,-0.620639443052048,-100.0,-16.22883934166967 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark23(-0.329503549651844,-0.6206463885715263,-0.5056748331935765,-1831.652653037726 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark23(-0.32962592508410093,-0.27298240164906984,22.299045897406767,100.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark23(-0.3303753387059847,-0.12762114558244309,85.18353912495296,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark23(-0.33229181342450004,-0.6192522566851986,-2320.0707184710013,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark23(-0.33281333531035556,0.16640666765517764,-43.98015895823117,34.41602813389461 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark23(-0.3328732635231977,-0.4624827911506738,0.16643663176159884,93.69361630645555 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark23(-0.3329534059740875,0.06794939648415778,0.06381968232282986,90.79626935808659 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark23(-0.33335626315436606,-0.11722851249498592,-0.10906519201505871,100.0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark23(0.3333868472757956,2.2325574280676848,-0.5581393570169206,18.508157999058746 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark23(-0.3335975009713263,-0.038246195815355696,36.56426248262348,0.8045212613051262 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark23(-0.3338531987225999,-0.6184715640361482,-0.6184715640361483,149.56397766449794 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark23(-0.3339705518890843,-0.5934828071038212,74.47101431759484,100.0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark23(-0.3339714850086716,-0.6156006909654527,-0.10638241669866914,73.04731512614485 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark23(-0.33401308438371835,0.019076260001982627,0.7043180600703058,-0.00953813000099131 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark23(-0.33411119327129835,-0.42673533582237155,-0.7208905410252323,0.570071611431533 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark23(-0.33483151206736045,-0.5603098626436811,0.925475629058365,36.4012414326059 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark23(-0.3350488882845895,0.16257109521787017,0.952922607539743,18.323803719932734 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark23(0.335181217696083,2.241018368526278,-0.2627719725529363,93.91392821184526 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark23(-0.3357501173806551,-0.25514646797429796,14.749160510089657,0.9129713973845972 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark23(-0.33800133617190165,-0.542302571937459,239.27124840141937,1.0565494491747336 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark23(-0.33815580130037176,-0.6119003167880188,76.56465133640224,18.467656190591054 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark23(-0.33877127701320386,-0.022455859252763943,71.76804211251961,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark23(-0.3389276440504325,-0.5295850111015521,0.16946382202521626,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark23(-0.33946576026506736,0.1697321048431521,82.51666244104935,-0.08486605242951935 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark23(-0.33947584474664655,-0.405258436234435,-63.71432463508083,54.17156268693344 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark23(-0.3402291326727096,-0.6804582051791114,74.58077510690082,-0.4451690608078959 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark23(-0.3411931328865109,-0.6816927610728031,-1.2930808954993438,0.3408463805364015 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark23(-0.3416980337023933,0.17084901685119658,0.17084901685119666,0.6999736549718499 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark23(-0.34252215050406026,0.1712610752520301,-0.21668146417164455,-0.08563053762601505 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark23(-0.3425532604543209,0.1193326877277271,0.16758951910142272,-50.29488657609802 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark23(-0.34446764214777525,-0.6039848646767183,60.58153018828789,-26.228408576573003 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark23(-0.3447862691028856,-0.5325586063534938,15.225620176524153,0.2662793031767471 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark23(-0.344899582668892,-0.6129483720630022,-0.5912160063053651,-100.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark23(-0.3458076773812082,-0.2528005770342949,0.1729038386906041,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark23(-0.3460348550236227,-0.5995428223476121,0.9584155909092597,0.299771411173806 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark23(-0.34787545715701773,-2.8302995848336534E-5,-0.6114604348189394,1.4151497924164147E-5 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark23(-0.34883676557164683,-0.6109759314916512,0.9597968506154677,-0.4764988416983636 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark23(-0.34970405233857643,-0.5683866945415037,-0.61054613722816,1.0695915106682001 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark23(-0.35006013808760944,-0.5381038405461419,6.638782099994032,1.01581642726383 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark23(-0.35174466816825395,-0.09184364498742859,0.17587233408412697,0.045921822493714286 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark23(-0.3530879923829242,-0.24941566908504817,0.6888239554977362,-0.5075860918928984 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark23(-0.3531451232884091,-0.5531548528868699,136.0834585091023,0.27605161000088285 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark23(-0.35353666705850895,-0.3384015160938275,-0.36259852295753636,100.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark23(-0.3536626603947758,-0.17640702744617714,-0.6085668332000604,0.08820351372308854 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark23(-0.3541646530729352,-0.6082581433635099,-0.6083158368609807,25.571326179541515 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark23(-0.3551746559132222,0.17758732786893458,15.978936887382822,49.34033973215603 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark23(-0.3554962934658058,-0.12011899454566721,-0.6076500166645454,-89.53255099493312 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark23(-0.3562034492237167,0.17810172458611806,35.04820723704297,100.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark23(-0.35688683273844873,0.12268323918765817,0.1784434163692244,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark23(-0.3569558791012235,-0.4448383571783939,0.17847793955061175,0.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark23(-0.3573199292199085,-0.20283189090905385,0.582566272488394,49.78554278581804 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark23(-0.35732422510287004,0.15195861189897175,-0.035372304063013615,-38.16497320743256 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark23(-0.3575234474335007,0.17876172371675025,22.216293556631157,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark23(-0.3622765469651328,0.17893021113942775,0.1811382734825664,90.67400300240628 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark23(-0.36250163108864525,-0.3265758482582176,-0.6041473478531256,44.59047744906621 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark23(-0.3627761960661063,-0.1224780654203433,147.0303923778174,-44.74167484485568 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark23(-0.36438828549695623,-0.372388057867914,0.18219414274847812,75.14169211345073 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark23(-0.36443242518322994,-0.46106473378834767,100.0,-96.30136684013881 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark23(-0.36490888961609913,-0.6029355155854287,-0.6029437185893987,0.3014677577938627 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark23(-0.3649971457157672,-1.7754985451864757E-12,-0.4713274450444872,0.12405595277728684 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark23(-0.36509375838532754,-0.6028512842047845,-0.5995923751103815,0.30142555032160917 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark23(-0.36682934160028635,-0.5968538914608338,0.5054034288420718,26.187054250723087 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark23(-0.36701772192332294,-0.6018893024357866,78.8666671978566,-43.40475451418384 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark23(-0.3671417488746742,-0.5339641439344349,51.70785535629291,0.8651659897895694 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark23(-0.3677308844424731,-0.2549502548063916,0.9692636056186849,-0.6579230359942525 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark23(-0.36785760661206346,0.008511389123827009,-98.44679908545713,-0.004255694561913492 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark23(-0.3691522468817751,-0.21237004696168793,0.18457612344088753,8.456656847977868 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark23(-0.3712476394541023,0.1856238197270511,5.697190383860388,-0.09281190986352561 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark23(-0.372066420738906,-0.03815779054827656,0.21396312200966952,-0.5561288487624427 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark23(-0.37282573827943,0.07031557339218994,73.99316852034109,78.39079027872043 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark23(-0.3728272108361193,0.18641360541805962,0.9718117688155079,-58.96223281264774 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark23(-0.3728468815983778,-0.5449878052603248,-0.5452258955631758,0.4803445356685428 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark23(-0.3729052690856421,0.18574176818298407,-0.4150967953282052,0.6912123589822121 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark23(0.37328102914346334,2.3173583725339193,48.579805790431315,58.531565750768245 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark23(-0.3733546814408037,0.18667734072040176,25.37332538003062,-78.65815539047944 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark23(-0.37448868476747865,0.18672547515959437,0.9726425057811876,-0.09336273757979717 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark23(-0.3757946423287617,-0.39690686896191174,0.09922671724047771,81.19671883316883 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark23(-0.3770718261615357,0.034241404909990364,-0.5893535607453416,0.6239930365195259 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark23(-0.37719569810254133,-0.4696886218046405,0.16440651050895916,142.64135397882234 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark23(-0.37731264086127325,-0.5810337916037766,0.18865632043063663,56.84041578784073 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark23(-0.3774368179556058,-0.5966797544196423,0.1887184089778029,1.0837380406072694 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark23(-0.37748350927501284,0.016592231750725772,0.18874175463750642,-1.3565555295486775 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark23(-0.37765137139517047,-0.5921435916671516,19.611009644077594,100.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark23(-0.37893303208223883,0.1894665160411193,-0.8120930945158955,32.78932745316227 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark23(-0.37914268980787874,0.06071445837887122,0.18957134490393937,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark23(-0.38016441949342883,0.15512161916452402,69.1056745623453,25.062262293232607 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark23(-0.3806287040836496,-0.5888844397366753,-0.5950838113556235,0.29444221986833763 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark23(-0.3808013629835476,-0.35725224931628174,-0.5949974819056745,-0.17411357718223897 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark23(-0.3810159694980515,0.1905079847482829,-37.69296076428026,28.590396424908995 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark23(0.3810227506406305,-0.9759095387177634,15.892714516905233,-0.29744339403856657 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark23(-0.3821251358990002,-0.4989502571281196,-0.49909122125041055,0.32018838310478526 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark23(-0.38317407027806566,-0.5921480573236574,76.95730061570137,47.10595744295781 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark23(-0.3833120134050325,-0.5654227272004411,19.908970847158812,0.28271136360022053 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark23(-0.38367727185147893,-0.2601268015820726,100.0,-16.584144045022587 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark23(-0.38461771123164035,-0.1983234667789893,0.6027553117130049,-0.26328241086695636 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark23(-0.38485422805964353,-0.592784447143226,0.9757978316044545,100.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark23(-0.3851524298383012,-0.7693360512666605,-0.2834122169003655,-8.255015177011405 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark23(-0.3852107249356793,-0.10338483338486226,-23.174251710602892,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark23(-0.38556547977922084,-0.41245505274395505,0.9781809032870588,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark23(-0.385764493711086,-0.49737061548452344,-1.1529740658212837,33.31577821656526 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark23(-0.38596407923245046,-0.42681127939987035,4.0247631857931765,0.1450786256406892 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark23(-0.38624547811255266,-0.08129959629655437,11.432538722726008,44.81439571969757 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark23(-0.3871806347826624,-0.7707387578522829,-100.0,-20.03655630243803 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark23(-0.38730029740974103,-0.14285857456812778,-0.540527760109982,-3.549914913491782 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark23(-0.3874014266300044,-0.5916974500824461,0.19370071331500216,0.29584760317313186 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark23(-0.38768418765447166,-0.5915560695702098,-13.199957855077486,2279.6100093516297 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark23(-0.38789919783381865,-0.20032007620130365,0.8354781824477744,-97.47522404718364 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark23(0.38802470968185027,-0.1942876664041228,-7.71003281538745,-67.11257213319982 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark23(-0.3890020652944637,-0.5462089654109975,-264.29354606464557,0.3621374932758563 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark23(-0.3899923867311655,-0.36079658460014996,98.45919689347926,-48.55799032363167 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark23(-0.39041027852863375,-0.5901930241331313,-0.27609693900511,-38.25591294168266 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark23(-0.3904640951702356,0.1952320376044041,-0.10208600183971736,-0.8830141818550563 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark23(-0.39152269756958674,0.19576134878479334,0.19576134878473775,100.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark23(-0.3926335925790915,0.7776888569872518,0.9812843354061621,-99.84888351774484 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark23(-0.3946787609494864,-0.5652334185772504,-0.5880587829227051,68.30316466788588 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark23(-0.3956201835174483,0.06401300781187265,0.6622564025386278,-0.32819600966135276 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark23(-0.3964499636603507,-0.2304169239839724,-100.0,-100.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark23(-0.39682502079559034,0.15266153815985217,-52.92239552764117,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark23(-0.39750230758667865,0.7005571343725113,-0.5866470063368564,-88.31484607868852 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark23(-0.39754747009110486,-0.13718420783450327,0.9841718984430008,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark23(-0.39777792475985496,-0.7918096976049971,0.1990893576589493,-45.157457425296066 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark23(-0.39855087927971816,-0.5759917479237997,50.86526052206937,0.28799587396189985 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark23(-0.3992787055944785,-0.5814145683428947,56.15731961222889,0.2907072841714474 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark23(-0.39941032850203284,0.19970516425101636,0.6403781869205206,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark23(-0.3994405716196668,-0.7811513434069132,0.9851184492072816,12.956768918540163 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark23(0.39964859740749503,1.7572211297716276,-0.497865102260714,-100.0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark23(-0.3998457908966222,0.0,0.5856683509836569,-0.5845510795869291 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark23(-0.40007062874249866,0.20003531437124902,0.9854334777686976,0.6840655858923912 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark23(-0.4001651544460488,0.18744830548322908,134.88356914997664,-0.4485873582622787 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark23(-0.40143244303239617,0.1536875972533579,113.47779779757829,96.46477660169256 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark23(-0.40148757281721176,0.20074378640860585,56.972849511838,-99.30230550491406 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark23(-0.401525323823174,-0.5846355014858612,58.89123873549935,-27.257495138474873 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark23(-0.40316011339358104,-0.5838181067006576,-0.5838181067006577,0.10331509859804791 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark23(-0.4060746450505917,-0.5813682959046017,-0.5823608408721523,0.2891936338881463 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark23(-0.40684650150051344,-0.8118415837630133,-0.15172619351910538,14.550499471958164 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark23(-0.4078191622714627,-0.5814885822617168,0.20390958113573135,0.2907441346441923 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark23(-0.4079200492692428,0.04473094433927967,87.41544218961032,65.95180229029137 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark23(-0.4080338407058275,-0.2702458827820596,0.9894150837503618,133.17698375145892 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark23(0.4100644129593619,-0.3362717748543086,35.37678595451387,0.1681358874271543 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark23(-0.4104958638752798,0.03612778644628034,77.41023693193455,81.71877894000112 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark23(-0.4112502953653779,0.2056251476826889,47.98589295555569,-73.35142083919655 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark23(-0.4118991490644053,-0.5553456904104683,-91.41338839424945,1.0630710086026824 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark23(-0.412407504854327,-0.1826328255194653,-0.5791944109702848,-3.2476699594272276 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark23(-0.41246841447440485,0.09093144904823003,-0.5791639561602459,-60.33600137600131 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark23(-0.412732148578517,-0.5790320891081898,0.20636607428925846,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark23(-0.41285797410314706,0.20642898705157342,-100.0,57.30861982841589 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark23(-0.4129331362168729,-0.034479530227278815,0.6168005816299007,-9.877611417835547 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark23(-0.4130087390707774,0.0,0.7731510552654377,-0.05211561525545701 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark23(-0.4142360559701096,-0.6922255133170712,0.028306818958428705,-0.439285406738918 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark23(-0.41588359093595784,-0.5774563679294694,0.18731352456411215,-57.72812877254302 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark23(-0.4181794247373296,0.20908971236866458,19.141619091014043,-100.0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark23(-0.41855535423475976,-0.455074998176959,25.51476090853306,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark23(-0.418751613302498,-0.1646378091417069,0.9947739700486977,15.720765403341858 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark23(-0.41910831189971504,-0.24269478749070572,0.8340554789207364,-28.824770800704062 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark23(-0.41997363971181495,0.20998681985590717,14.19490346504021,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark23(-0.42059976612680955,-0.19430361200548885,0.21029988306340486,12.234621722291262 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark23(-0.4208240872321357,-0.2635393309547339,-0.3258401446528967,0.13176966722027175 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark23(-0.42088724486704576,-0.4009085164520385,-0.19153963646846522,88.39474721933456 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark23(-0.42111681535127593,-0.5748397557218102,0.21055840767563797,100.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark23(-0.42142009974620026,0.21060189043055183,100.0,0.6800972181821724 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark23(-0.42216736837705954,-0.23434742757633853,-79.10934235515448,0.11717371378816932 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark23(-0.42339726374545916,-0.034443502317224234,0.22783693299179247,0.8026199145560604 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark23(-0.4241032370393259,0.04422540828173226,-3.2974818289724244,100.0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark23(-0.42463557953498177,0.19756582167168116,-81.46088318627119,1370.6034640953146 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark23(-0.42618030032028953,0.10929013193604063,0.998488313557593,-0.05464506596802031 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark23(-0.42682221438143114,0.12865721580454897,74.81323604726163,0.7210695554951737 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark23(-0.42867746810298324,0.20609148557565385,69.853388488468,-0.6232810898583678 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark23(-0.42976347060540615,-0.5705164280947452,0.04133742672460983,90.11862425455415 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark23(-0.4300392947367456,0.20746223879831976,71.35685864393886,-0.10373111943683373 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark23(-0.4304748451799584,0.7090349342859043,76.9870354718345,68.76049309708057 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark23(-0.4306701576111651,-0.26154240243078863,1.0007332422030308,11.992822144647516 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark23(-0.43104814414292203,-0.38448474251759557,0.10909029195796427,1.2034315350070308 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark23(-0.4312666253900812,-0.5697648507023809,93.73032458452433,9.25588952456097 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark23(-0.43283907648260206,0.21231744403130415,0.9977156074287525,40.86350854791261 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark23(-0.4331020350463784,-0.568847145874259,-72.47410412573106,63.11068665391976 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark23(-0.4331672574249008,0.031398995593569165,69.86065557447397,-0.12262100889486463 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark23(-0.43333617279621217,0.21582057377281583,0.21666808639810609,-43.845130922693954 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark23(-0.4344721517110912,-0.5599727528393337,29.338083235052352,-88.46961922040958 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark23(-0.4353053283350422,-0.25422743784523916,-128.68547412324847,0.5740725149709556 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark23(-0.4360524693836093,-0.23448690346790435,-91.44992757623342,21.696491936288368 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark23(-0.43623283915620065,-0.5672530743801747,27.644281354164868,-100.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark23(-0.43645530613620415,-0.4990516559428205,-0.5671705103293462,100.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark23(-0.438011372635673,-0.5663924770796114,1.0044038497152847,-0.028607294823010793 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark23(-0.4386727899242951,-0.14057336321232095,0.21933639496214755,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark23(0.4397430821824708,-0.8403505875634006,-0.8975488643290322,0.0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark23(-0.43993682851562355,-0.5561131187703013,0.3958566391304208,-0.5073416040122976 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark23(0.44009130295743926,-0.23134392246376115,14.963773375774437,-100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark23(-0.4402056959645926,-0.5652953154151519,99.99999999062878,72.2923330975009 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark23(-0.44028736570095184,0.2201436828504713,63.71734565560598,-92.95135519689546 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark23(-0.440373882945777,-0.5652112219245597,-0.3527132515844708,-82.94756960360368 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark23(-0.44061870338682707,-0.5650888117040346,0.22030935169341354,37.07213634871759 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark23(-0.4411994771499901,-0.5647980369666825,-40.64364476219271,5.983945507889487 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark23(-0.441772387390564,-0.5399472392011662,0.22088619362335976,-10.41982259688096 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark23(-0.4417805106174718,0.2014150890996884,0.22089025530873596,141.42574170698148 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark23(-0.4418276499579037,0.11448156532644482,0.44529704953741867,-0.8426389460606707 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark23(-0.4444374751228948,0.22037547253449383,0.7800949075539247,-0.11018773626724691 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark23(-0.4445755621803689,-0.7707062140477994,-0.5573401440620762,-82.08892361326596 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark23(-0.444748357866054,-0.09103009424449142,0.222374178933027,0.04551504712224571 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark23(-0.444765338451115,-0.5630154941718908,1.5379728699711126,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark23(-0.44528387034914996,-0.5627562282228733,-39.69531974488601,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark23(-0.4457919196450195,-0.09164753483116042,100.0,0.5454573904700761 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark23(-0.44598241944711114,-0.28652988064942675,-22.326751844816258,-100.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark23(-0.44683260939135805,-0.20444181725108002,-0.31868972792176553,-126.46986968059534 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark23(-0.4481194629077554,-0.5613384319435706,0.1074756002266195,-0.4044296505050359 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark23(-0.44897226263702417,-0.560912032078936,-0.5609120320789363,100.0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark23(-0.4490781433638252,-0.15515121804781362,85.15556953165196,31.100829766224596 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark23(0.449233278874508,-0.22489420037599508,-31.640434015697632,0.11357623548740338 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark23(-0.44978275933070155,-0.5587022151293007,-0.5605067837320972,1.0647492709620987 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark23(-0.4501165415100501,-0.5603014550998852,0.22505827075502505,-59.72206922554793 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark23(-0.4504888430156182,0.11348246697178363,0,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark23(-0.45068210455088775,-0.03691546790507696,-0.004499814684460729,0.01845773395253847 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark23(-0.45093155966322773,-0.3052242982203133,-0.5599323835658344,-37.36698869426869 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark23(-0.4516355996317856,0.5309187987495347,-0.2738508158771032,64.68252853369592 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark23(-0.4529854234634132,-0.3845460481032057,-100.0,0.1923353210139766 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark23(-0.4530235675689456,-0.3441259151523276,260.5715899448927,34.30902768353354 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark23(-0.45307765010766515,-0.9061553002153302,-0.43225222939095287,-0.3323205132897832 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark23(-0.45363476162939786,-0.1670774897581095,-0.4286485974619638,-0.7018594185183935 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark23(-0.45396438248191234,-0.5578911482577724,99.97254845860058,-0.1183008721670391 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark23(-0.454283400480067,-0.07289490553554599,97.92748876491848,-0.7489303643075339 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark23(-0.4544753516913216,-0.48431601373599015,-0.5486257717472174,86.01422089393643 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark23(-0.45512789302996215,-0.6639427069013708,61.38168362619146,0.3319713534506854 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark23(-0.4562131740638184,0.22810658604873368,100.0,79.48258342832052 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark23(-0.4564297813689606,-0.5571832726822264,0.956377108222658,-0.5067152519727752 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark23(0.4568926158032123,-0.4478418159849391,-0.22844630790160614,0.2239209079924689 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark23(-0.45750195269056776,-0.38911778108213707,-0.36410954729986394,0.19738234844532354 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark23(-0.4576971781367398,0.2038969816650212,0.2288485890683699,83.85780445101213 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark23(-0.4579327990792947,-0.0899045779096388,-91.23159999042933,30.854768344600274 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark23(-0.4587035468226873,0.22935177341104812,-0.5560463899861047,-0.9000740501029725 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark23(-0.4594885686957862,0.6162187443407902,-22.519268461066062,49.957942481116326 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark23(-0.46256184689320373,0.16776152387554646,-22.353033116905884,0.701517401459675 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark23(-0.4634176122079161,-0.5531133521639342,0.08912650231505462,15.221800588530925 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark23(-0.46422798551578026,-0.5532533923072451,-100.10231255923388,-90.72769281172918 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark23(-0.4649885532975696,-0.195599415524107,0.2324942766487848,-98.8083176209409 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark23(-0.4689344481266966,-0.37148058067344036,59.51548994824096,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark23(-0.469537521351338,-0.9357787316498245,75.94071571472736,1.2532875292223613 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark23(-0.4697933706233705,0.22971123709093172,-0.13248560146216973,-0.44423942086911694 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark23(-0.4708485865307242,0.18335497108979745,0,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark23(-0.4721416862908665,-0.12487661247120836,32.6479801347393,0.06243830623560419 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark23(-0.47265806985156505,-0.08294354550462923,87.4329071204797,0.8268699361497629 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark23(-0.47297749252037363,0.23648874626018057,-0.5489094171372608,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark23(-0.4733475169265878,-0.4901639258001013,0.7376316864793304,34.721160669554585 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark23(-0.4736967461202175,-0.06654749868840948,0.7625105489077457,-0.05334419668087596 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark23(-0.47391172309996377,-0.27723240187240134,60.437988425920246,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark23(-0.47391321983117723,-0.5484415534818594,-0.5484415534818596,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark23(-0.4742011800871469,-0.5482975733538749,-0.40313636356382343,-0.5112493767205109 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark23(-0.4750102262904472,-0.4788527291268595,0.2375051131452235,-0.006370609472682531 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark23(-0.4760139065478326,0.010075597756844523,0.17587347659864555,-0.7904359622758705 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark23(-0.4762765361720045,-0.5431540279947462,0.58881986858038,-0.27543368336437135 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark23(-0.4768402572450828,-0.04880977738263003,1.0238182920199896,7.851440647964146 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark23(-0.4770234683271646,-0.5468864292338658,1.0239098975610306,-68.2359919142773 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark23(-0.47731443442393484,-0.7278534072415606,-100.0,-44.40511935415617 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark23(-0.4774809525550636,-0.5466576871199165,0.06190280211907628,-49.342285341340585 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark23(-0.47768645804644877,-0.5363616081652259,0.7867947399294645,0.19453891920711205 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark23(-0.47856575229936926,-0.5461152872455431,-0.2652480122705999,-24.195507013683255 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark23(-0.4787446592436897,-0.5438495211732017,0.5152933126107899,-0.5134734028108473 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark23(0.48041483718010003,0.9608296743601993,96.8119370042485,99.9999999984857 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark23(0.4815076008059322,2.53381152840676,-0.6758957020346523,-2.0523039276008284 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark23(-0.48183789403121313,-0.5268892548156301,93.70351884631845,70.3370961724304 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark23(-0.482507312046598,0.24125365602278362,99.99999999999946,0.4540084623843751 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark23(-0.4831333543944111,-0.05999774141544213,0.6549355542491974,-0.27259418045936695 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark23(-0.48352598639310596,0.5975667756651166,0.2417629863481069,45.25463688521218 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark23(0.4838530683702167,2.5381025349236355,42.51086534628652,-16.192841997464214 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark23(-0.48396195580266005,0.2419809775905759,0.24198097790133002,64.33740631306964 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark23(-0.4849689631124321,-0.10291317578960887,1.0278826449048912,-100.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark23(-0.48509113560997486,-0.5428525955924609,-0.5031598316223945,-4.703398596754397 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark23(-0.48528038784350414,0.05554508246923928,-0.5427579694756943,12.430095871533624 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark23(-0.48734928475187056,0.24367464237570374,0.24367464237593528,97.61016007496553 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark23(-0.487961158151719,-0.5414175843215888,-0.43480821585658685,-100.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark23(-0.4881544938339055,0.19980310309020452,100.0,0.6854966118523461 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark23(-0.4888931376596378,-0.24818771648002103,-0.09597820147190284,-20.655477375462738 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark23(-0.48917380724079873,0.24458690362039937,64.11066771169835,-100.0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark23(-0.4902236615433255,0.1321956707576104,1.030509994169111,-57.41373070162158 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark23(-0.4903884979093807,0.5721567577914306,0.24541732963816182,-2.6422728690880604 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark23(0.49108493861054914,2.5366174191287647,79.69911527423464,81.19570054546175 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark23(-0.49193160981104156,-0.04460394424906382,1.031363968302969,96.50305448840528 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark23(-0.4921452251042498,-0.5331790785502879,-100.0,-88.63376166468309 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark23(-0.4922450418406834,0.22286528875124645,65.10722104573739,-0.11143264437562325 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark23(-0.4931781513410236,-0.21682502086090005,33.66751519807551,6.690308648341983E-4 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark23(0.49389392600666526,-1.037044067706936,30.84363343071858,-97.97163570735162 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark23(0.4942378628534131,-0.24711942556143404,-99.99366222429728,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark23(-0.49529483818576114,0.23267313510200882,94.91979343787402,-96.49820476156079 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark23(-0.4953370541427861,-0.5377296363260552,-0.31763680362780494,-93.88498033700745 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark23(-0.49538014232114425,7.869291785550956E-4,-0.0019978782355749344,-0.6686539580840327 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark23(-0.49555568873925876,0.24626722901898945,-0.5376203190278189,94.49190807922277 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark23(-0.49627707309594254,0.24813221904546567,0.2481385365479713,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark23(-0.49637775545462015,0.20504447518365282,-9.224634302298218,-0.1025201698225896 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark23(-0.4966144290335853,-0.5370909488806549,0.24830721451679283,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark23(-0.49784061909404553,-0.9956812381880908,-0.5364778538504255,-0.28755754430340286 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark23(-0.4989452172204385,-0.3466736399908372,1.0348707720076675,100.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark23(-0.49935712179875247,0.07814906323902937,-97.14204328274941,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark23(-0.5002760505386186,0.1159434812513247,0.2501380252693093,-11.039061965208584 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark23(-0.5003620947680314,-0.5352171160134325,-72.01253901770505,-0.285284544632463 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark23(-0.5005895962357272,-0.1665062765469867,-76.57536568486461,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark23(-0.501521751976744,-0.31819388200213483,9.825150567797877,-7.68150639777185 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark23(-0.5024661940417984,0.16252194988511154,-0.534165066376549,10.127600228902985 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark23(-0.5030469032152122,-0.12452109624659263,56.74567017824805,99.99999999997128 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark23(-0.5049501183242568,7.740036969896946E-25,0.2524750591621284,2.355892142307055 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark23(-0.5050706441193363,-0.47494671157683294,0.31099958843257286,0.2374733557884165 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark23(-0.5060121082699617,0.5119817495156999,25.46570514790286,-100.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark23(-0.5060308027396755,-0.5281410345522956,-0.29173449931827733,3.403940618223551 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark23(-0.5068402085801127,-0.48768696081370294,100.0,-100.28786763283757 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark23(-0.5078175204976887,-0.19324684499486033,0.01347379473664545,-16.840340709935866 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark23(-0.5088678802422117,-0.31657903877147764,100.0,99.9038561250706 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark23(-0.5089447819910388,-0.5200141821220194,-0.5309257724019283,-0.5094275739605315 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark23(-0.5089855425245426,-0.13622294921717026,100.0,5.683340419894031 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark23(-0.5096096925931699,0.12115222430461545,66.52584104369828,-75.90731990526027 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark23(-0.5096247836051386,-0.2632911620600532,13.76866240340216,-75.24094236790002 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark23(-0.5096336708401628,-0.5305813279773668,-59.30104594111787,0.2652906639886834 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark23(-0.5096876201798421,0.11049314060602611,-16.986609852444285,-0.055246570303013054 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark23(-0.5098024574012932,-0.21021694449435135,100.0,68.43360703506539 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark23(-0.5103793760175446,-0.12680163787329907,-0.530208475388676,-100.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark23(-0.5108503153616257,-0.3406909692200683,63.54257134355588,0.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark23(-0.5109820908793564,-0.4312941885645455,-0.5285972556035654,-26.484988290345196 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark23(-0.5111528963167951,0.2507916665705479,84.47179274583692,-0.12539583328527382 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark23(-0.5112863933908647,-0.12091269756610412,-0.5297549667020159,9.351265232784257 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark23(-0.5117301984827677,-0.11808382751714984,1.041263262638832,100.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark23(-0.5122126194227108,-0.5292918536860929,0.0,-10.556454080585855 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark23(-0.5125143295464154,-0.6918260624401473,71.01997041679128,23.121986330179247 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark23(-0.5125986239753215,-0.0849761835708951,-0.02843538431301885,-0.46723957584458997 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark23(-0.5127241999143546,-0.5290360634402709,-0.529036063440271,43.5664737441748 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark23(-0.5130877585843331,-0.27159236655457497,100.0,-100.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark23(-0.5133299840051094,-0.30959307154199006,0.3888042750555886,0.9401946991684433 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark23(-0.5134422679800328,0.24704830914339151,0.5325050846770523,-0.5717856872903373 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark23(-0.5135527958256456,-0.5286217654846253,9.466134883601091,-20.28078214030855 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark23(-0.5138310758836367,0.23090221700402777,-3.685653403745899,-74.36468867784224 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark23(-0.5144738475958737,-0.3936535855558434,0.25723692379793683,-61.055483497338045 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark23(-0.5146073728081254,-0.5055540920028714,22.779677486246367,-1863.4380150906602 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark23(-0.5148552258429078,-0.5279705504759935,-0.5279705504759944,-50.57937550070942 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark23(-0.515154788129676,0.25750712071760967,-0.5277982258136122,0.6553185767889305 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark23(-0.5158118055788699,-0.049875837528640665,-0.5274922606080099,0.02493791876423117 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark23(-0.5176250583360362,-0.512447992207055,-40.381446685095746,0.2562239961035274 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark23(-0.5185483066470586,0.01237195445296324,4.21704523699658,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark23(-0.5188498122422978,-0.18733222133309635,83.2481591914445,-70.58782972724276 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark23(-0.518887711579863,0.2585844812355647,0.25944385578993157,-63.534930264738485 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark23(-0.5191550361605889,-0.07476424327610484,0.2595775180802944,-0.2050098069047303 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark23(-0.5193881544449601,0.25969407722247995,0.2595882240715355,100.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark23(-0.5198195227483747,-0.5005991993024425,77.18683967956419,0.2502995996512213 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark23(-0.520120196163212,0.2592789447726033,0.26006009808160596,-21.838533026138023 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark23(-0.5204889621224638,-0.5251536823362155,9.911634749336201,-0.25569400200902104 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark23(-0.5229372215256414,-0.5025633339592341,35.46780913749116,3.3936808841993837 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark23(-0.5232306234984332,0.2531021603280075,-87.98052747435582,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark23(-0.5233239428744612,0.17489561933776582,-122.89572002512382,-0.016205468287922464 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark23(-0.5237174614301803,0.030628767519792672,-0.45726156696489684,-76.96405840946066 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark23(-0.5240455069168679,-0.9558969917727885,-0.3160868223995177,-35.668862845905 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark23(-0.5244757974301971,1.491862189340054E-16,0.45129584011567936,-0.7853981633974483 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark23(-0.5254148739134115,0.2627074369563215,-0.4965951983667467,100.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark23(-0.5254292048018213,-0.5226835609965372,50.90210916071366,43.27875530885347 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark23(-0.525505597043536,-0.5226453648756801,41.222129126261734,24.711958608143036 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark23(-0.5266486785109452,-1.05329735702189,-0.5220738241419757,0.526648678510945 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark23(-0.526860800537033,0.13925763224915144,0.9815124474220305,85.94028051891306 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark23(-0.5268639924410295,0.08442904033589975,1.048830159617963,-0.8276126835653982 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark23(-0.5275757289281063,0.1259168376727419,-0.3045034393386662,20.303500827742063 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark23(-0.5282474281353237,-0.04568709379492575,-13.833258260204957,98.5037599471935 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark23(-0.5288935858535874,-0.5209513704706545,0.0,-7.2467588963748355 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark23(-0.528909679820651,-0.016346937175516704,16.42798480679707,-1927.7053068506036 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark23(-0.5290318590412304,0.22590886385375197,-0.5208822338768331,-0.11295443192687599 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark23(-0.5292686857123111,-0.2107153531819393,1.0500325062536038,-78.23845930692234 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark23(-0.5293376011820116,-0.4862442277190931,-18.711501173175495,62.50283442903975 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark23(-0.5295882451597856,0.26479412257862317,0.9733335703826451,44.80418481625843 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark23(-0.5298200245393899,-0.1048184634401147,-100.0,-249.29587524558298 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark23(-0.5333280855311768,0.2647343710853147,-59.592925708362856,11.681053068698134 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark23(-0.5333769773738273,-0.5187096747105346,0.2666884886869135,-14.459438935103869 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark23(-0.5336669319265223,0.2572406329095243,0.26683372082674484,-0.9140184798522104 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark23(-0.5343777136097736,0.10974330371263458,-0.08451829563729774,-85.31195600144957 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark23(-0.5347459149971631,0.4998457569006323,1.0522224902601924,-96.85473565463236 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark23(-0.5352794165843646,-0.03574224343544505,0.340875500194763,78.13572282097425 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark23(-0.5364730138295697,-0.5123353676031628,-10.275127682243584,100.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark23(-0.5365891125760325,-0.5171036071094319,0,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark23(-0.536745968402395,-0.9326147370471691,0.26837298420119743,-46.65777438095567 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark23(-0.5371483884675783,-0.7116085238176301,0.2697590106528062,-49.90985678555983 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark23(-0.5373570083897076,0.23951989333446866,1.0540766675923021,-0.11975994666723433 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark23(-0.5380070046692227,-1.065578632136168,-0.516394661062837,99.99274378732585 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark23(-0.5381619741363164,-0.3194965543239867,24.555914796448675,0.15974827716199336 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark23(-0.5383423007493722,-0.032034422926021766,-0.5162270130227622,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark23(-0.5383577836427229,0.49404105614030436,0.26881321856716467,0.5383776353273007 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark23(-0.5388254980332275,0.2694127490166136,100.01490602824903,-0.9201045379057551 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark23(-0.5395528147139906,0.49140124882042435,0.9499146678873978,89.29102623721515 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark23(-0.5398911916769316,-0.4841631811069459,91.23221489254439,-1.878402105298346 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark23(-0.5400181662263872,0.27000908311270744,15.522068537469924,-38.211917397147026 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark23(-0.5400680217776941,-0.23015916078199095,-55.90040670239926,-0.11346472272024077 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark23(-0.5402847128979198,-0.1007697928573513,0.41904010911322126,-0.735011977670995 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark23(-0.5403798959129564,-1.0797463597388235,52.09186249312978,100.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark23(-0.5414437554761777,-0.5146762856593594,-0.22830795248357028,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark23(-0.5423600295642258,-0.5142181486153354,-0.42337103160517797,-31.81101126339104 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark23(-0.5428548176669956,-0.4447507150849104,88.85742329781162,4.933958595343782 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark23(-0.5433805040601114,0.1643858809466815,90.1600458260274,0.6503762092377572 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark23(-0.5437161458109506,0.2718580729054749,97.92232684260082,87.21713229436885 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark23(-0.5442374572944962,0.27211858998922583,-0.36927556285011615,-29.10678042820483 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark23(-0.5446473534567309,0.27232347379944943,0.605190105109788,-0.40282215936931554 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark23(-0.5447012114624846,0.27235060573124215,-0.32543473661181593,37.470955383920774 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark23(-0.5448546782958931,-0.04082106088431351,0.41860292312458364,-0.7487261963106159 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark23(-0.5453426284074251,0.4737083436978696,0.40064337051725907,27.2522254799417 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark23(-0.5456332616389659,-0.5125815325779652,-27.27583979815804,0.2562907662889984 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark23(-0.5464011485835578,0.04016063831052552,-24.892623686174502,-77.77380760462157 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark23(-0.5470290321330166,0.04993966081766303,-0.51188364733094,-147.81774170500952 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark23(-0.5471851287516356,0.2735925643758177,0.17217581191047734,-0.9221944424404227 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark23(0.5472020104207991,1.456782213622894,46.8590926923558,-0.7283911068114471 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark23(-0.5478439593205825,0.27365308712328285,30.3047296337147,0.6485716198358069 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark23(-0.5485384272799773,0.27333665729412204,1.059667377037437,-63.60576831284809 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark23(-0.5485567018166578,-0.5111198124891193,0.2742618791245982,-0.5298382571528887 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark23(-0.549013555009652,-0.20622924537231638,-2.973388878665666E-10,-0.3013284460016637 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark23(-0.5501014096328726,0.2702294779556831,67.89597052053166,-0.9205129023752898 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark23(-0.5501888092429296,-1.0996180332333814,100.0,-100.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark23(-0.5503841803878352,-0.45862230917608926,0.397930006006034,-21.374400850413224 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark23(0.551203259469858,1.6497449565863054,-0.36800025243771767,-2.4098846501674487E-8 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark23(0.5518466425200578,-1.061321484657477,21.956743216457607,-1.040090004259599 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark23(-0.5533178885377222,-0.3871732270131152,-0.11095033623808737,-1804.3657545173044 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark23(-0.553785234436004,-0.1491408269604162,120.17692367324696,75.45895801063818 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark23(-0.5538291664767339,-0.5084835801590812,4.3368086899420177E-19,0.2542417900795407 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark23(-0.5543681692451456,-0.3862886389759997,1.1102230246251565E-16,34.43121712413944 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark23(-0.5547664446622562,-0.47072827288886165,1.0627813857285764,-93.2120960265982 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark23(-0.5551306333643726,0.15310376514134164,1.0629634800796346,57.14682136814823 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark23(-0.5553906317086534,-0.3810961152082587,1.063093479251775,-0.5194071083425552 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark23(-0.5558109260212609,5.4683105651156775E-48,0.7359598921923742,-0.12959282284633505 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark23(-0.5558429794844989,-0.07701202448623107,-15.925119489625502,100.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark23(-0.556683292242435,-0.4150444492182776,0.2783416461212175,83.95836024496651 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark23(-0.5584174838561631,-0.06915117887337564,0.27920874192808154,0.034575589436687815 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark23(-0.5591242522565795,0.06633355195283878,0.04475570212906321,100.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark23(-0.5596187740282501,-0.34814359133689443,-32.58015345428163,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark23(-0.5600402030291792,1.2547452149412648E-14,0.1574770909375785,18.131861147357313 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark23(-0.5608325405320613,0.28041627026603044,79.02447389436558,35.65704522965911 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark23(-0.560836112348592,-0.23770442987484974,1.0658162195717442,0.9042503783348731 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark23(-0.5610446694353303,-0.5048758286797831,0,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark23(-0.5621946715554719,0.2810970001128103,0.2810973413715123,-15.539497369011732 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark23(-0.562316295045585,-0.16579965958466109,-0.5042400158746558,100.0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark23(-0.5624063596330596,-0.44582941736679893,-100.0,-0.5624834547140488 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark23(-0.5630901637075666,-0.31415926535897576,0.2815450818537833,-4.015466899193315 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark23(-0.5635602384709892,-0.37467077770853713,-0.5036180441619537,0.9727335522517169 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark23(-0.5642032755419895,0.2672483994476519,0.28210163777099473,-2.2201879614193345 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark23(-0.5642212596738689,0.1366251646570218,-11.223451985781068,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark23(-0.5646352285136422,0.28231761425682045,0.5515747431270492,-7.019296615884534 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark23(-0.5649721553139679,-0.4913689524031751,1.0678842410544322,1.0310826395990358 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark23(-0.5655106818125789,-0.30117139203348675,0.28275534090628945,-26.007773178565255 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark23(-0.5665394778918769,-0.31256461699437743,42.79939431835599,-31.126624544649403 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark23(-0.5667389751967935,0.26761508832228764,8.750827385827986E-4,100.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark23(-0.5669012724933157,-0.477955479132549,-0.4935590239284053,232.69734082837573 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark23(-0.5671889863150154,0.20415775471648667,-0.5018036702399407,0.41775963628975366 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark23(-0.570678371380709,-0.05736281080031469,55.57434772536966,25.75745041575441 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark23(-0.5720391313970605,-0.4993785976989089,100.0,40.9065223222275 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark23(-0.5734491138865729,-0.4986736064541617,0.28672455694328647,40.43247810394634 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark23(-0.5747220688434722,0.42130565311098467,0.1429816489879089,84.61234089371057 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark23(-0.5750907329229751,0.25343987847311095,-100.0,-99.8737067702838 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark23(-0.5762863171285726,-0.4972013587543172,-0.4022958640382964,-80.6665127999357 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark23(-0.5764900542547464,-0.05836988586167821,43.809382759804684,-100.0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark23(-0.5781500392744571,0.2444349268895007,-78.18993867377893,-0.9076156268421987 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark23(-0.5784308426460824,-0.46847735148643627,0.5243267388488849,0.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark23(-0.5794511829818327,0.1979497841738774,-0.4956725719065318,0.627832551331466 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark23(-0.5802862673501495,0.03238513711911395,-0.49525502972237345,2058.138579649908 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark23(-0.5812653212919355,-0.5772419485611922,0.26777224995559334,-20.15385036184529 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark23(-0.5813981557892218,-1.1991010212614952E-51,85.11953796166486,-0.7735224284409353 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark23(-0.5823868001312993,0.2911934000656375,6.162975822039155E-33,100.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark23(0.584999855243046,-0.29445203895643823,131.93581414078471,25.163596009912958 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark23(-0.5854490441399853,0.0038100890020995593,0.21107754306627347,49.61014839772045 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark23(-0.5858598642004178,-0.43175856160589177,0.29287575466152327,-0.14636390959071455 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark23(-0.5860250998075238,-0.47923405199323643,-0.17592989302267867,0.2644080834729571 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark23(-0.5860757401122402,-0.49236029334132797,66.8317701011867,-0.5392180167267843 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark23(-0.5863602754830394,-0.4492073820375189,-37.4993208009948,1.0100018544162077 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark23(-0.5864955943283953,-0.3938197633946332,67.79670244648355,-818.8767478112221 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark23(-0.5866305311066005,-0.4517082016513939,43.39301718740622,0.20121522912100417 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark23(-0.5873684964657555,-0.3532686474045539,-0.4917139151645705,-0.6087638396951713 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark23(-0.5876057636891152,-1.0931854537627974,0.2938028818445576,-100.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark23(-0.5879167538157732,-0.47163010627138463,100.0,-0.549653293996883 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark23(-0.5880048467474268,-0.19767259580351831,160.54293948735318,-0.6865623320512916 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark23(-0.5881562395348732,-0.4569895637346843,-0.49132004297099013,0.22849531319273433 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark23(-0.5891300810103824,0.19463710690798844,-0.4908331228922571,215.35611823772422 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark23(-0.5901615378659361,0.19140860221931436,-81.9653240108299,1.025114402967721E-9 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark23(-0.5912881891325793,-0.40237184960519645,-19.064550478324733,100.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark23(-0.5917839443233534,-0.3813866698089141,18.970695025696536,-48.57817488602239 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark23(-0.592523223977448,-0.48913655140872425,-0.047675559992432094,-23.214072187990595 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark23(-0.5928636964874955,-0.08337301896880861,0.29643184824374774,0.8270846728818526 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark23(-0.5930030204680686,0.3726810188530702,-100.0,-95.21951063257978 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark23(-0.5933923629901551,-0.4887019819023708,0.2674122615343361,-44.8803501848796 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark23(-0.5941232131802607,0.29706160659013037,0.29706160659013037,20.60016094132247 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark23(-0.5947533794817055,0.22330571672722577,-31.40813769783999,81.86389671792614 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark23(-0.5975329545985865,-0.4866315446725318,1.0840528214098237,-0.5420823910611823 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark23(-0.5975660148531481,-0.0010709658002376154,-129.024682724552,5.354829001188444E-4 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark23(0.5976164725406492,-0.9970485997564473,8.447535019981231,12.988524393961827 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark23(-0.5977076340622337,-0.48654434636633126,0.356983396117377,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark23(-0.5978130136586937,-1.195626027317387,0.29890650682934683,-112.47333005110364 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark23(-0.5980536783515942,-0.4863713242216505,13.492063646935618,-36.66385064563067 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark23(-0.599015457325262,0.14058526508702757,0.592224939046816,0.715105530853935 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark23(-0.5997289087382773,-0.24017202356414064,-100.0,-76.66898685407493 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark23(-0.5998929052087257,-0.48545171079308425,1.0772751289401958,-0.536673374871385 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark23(-0.6010025678094418,0.2676554823947388,0.3005012839047209,0.6515704222000789 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark23(-0.6011552115112728,-0.05631153118767104,1.084001492546387,94.68934650553967 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark23(-0.6011598846634255,0.30057984330365334,100.0,-0.1502899216518267 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark23(-0.6012976826498242,-0.33843476463715194,0.3006488413249121,0.9546155457160242 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark23(-0.6018645524985136,-0.38141542466752754,-44.38890283937561,0.9761058757312119 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark23(-0.601996452182376,-2.3879121762372034E-12,0.331412880941649,-0.6275025372976267 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark23(-0.6028970452650713,0.3009107488334047,25.757847587557386,4.556564337544654 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark23(-0.603103434403134,0.07825085375888423,-56.57404676993842,100.0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark23(-0.6043100616887193,0.29760605490906417,0.47178008439996116,-0.6973744173468595 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark23(-0.6043203614422189,-0.48323361653852853,-0.4828240169332054,0.24157086485553927 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark23(-0.6043833377784066,-0.09861565905766612,-34.501449936722096,45.6003683609668 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark23(-0.6047888327211554,-0.2847016530288596,0.19363974893433744,-0.24193732922022992 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark23(-0.6049015950829949,-0.38881644875110477,0.3216524914112496,-0.14060207858978283 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark23(-0.6053607628597373,0.13533788804757296,-0.48271778196757964,-93.1717973995701 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark23(-0.6053984766659926,-0.9261179831715268,100.0,-23.098835940671307 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark23(-0.6054898200453375,-1.2089997656907807,0.1470746973205407,60.35503618625669 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark23(-0.6057333987769621,0.24742380913081685,-78.19698022355588,-26.04189959447166 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark23(-0.6057892693184805,-0.0714651633471371,81.6633995097475,-48.607326995950906 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark23(-0.6058829498899705,-0.38479725996167846,28.567396198575153,-92.3493603453531 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark23(-0.6059161624133931,0.2850889272535763,92.4278659881866,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark23(-0.6068181742199327,-0.27412182886947345,0.30466171145588644,-0.27874708457469793 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark23(-0.6071074685555188,-0.4818444291196889,-0.3299551976155261,-100.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark23(-0.6076568122861514,0.30382840606226,-5.169878828456423E-26,32.82853019049072 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark23(-0.607750817145088,0.3030132881439822,0.4713334161402376,0.03565882998508807 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark23(-0.6081626086304716,-1.0074762603789504,-84.51895460922348,14.638610569105891 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark23(-0.6096691588229401,0.29108551456496035,1.0780531417351058,-0.9258594101611095 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark23(-0.6126967752889269,0.07908155355639579,-0.4790497757529849,-0.03954077677819789 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark23(-0.6138599124335499,-0.3944769881210324,30.851251875495052,0.9813217371385216 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark23(-0.6142892697124219,-0.21578005944484457,1.0925427982536589,-2.2407642784566146 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark23(-0.6143686447265175,-0.8188487033058687,-0.47821384103418946,-9.807347362051182 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark23(-0.6147619043295176,-0.4780172112326895,0.004258459761420689,-16.46969751718573 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark23(-0.6149682735258983,0.30748413676294917,0,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark23(-0.6162146306485828,0.16359656948794526,-37.72937766411821,0.7022849583340625 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark23(-0.6178101200666068,0.30148427277331535,-0.4764931033641449,-0.936140299784106 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark23(-0.6180131585408217,0.30900657927041064,-0.08511281204546917,0.38732438535745456 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark23(-0.6186103869820283,-0.4760929699064341,0,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark23(-0.6196613174657013,0.30983065873281235,-6.458904781977095,100.0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark23(-0.6198600780777177,-0.34359122076151616,42.738197345829605,19.40353223375797 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark23(-0.6200010992611633,0.3092068612650107,0.31000054963058166,-0.1546034306325053 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark23(-0.6202156477703205,0.218714219291404,0.754149321227831,-5.0190390904875954 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark23(-0.6204431640495978,-0.22094903308556738,66.60356126698494,0.11047451654282958 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark23(-0.6209109226213858,-0.47494270208675515,98.75744048642281,85.73760523952092 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark23(-0.6227573653276143,0.26665077124586234,-100.0,-67.9051153010474 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark23(-0.6236100094403364,-0.015925059566078037,-0.47359315867728013,-76.37520295163907 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark23(-0.6237250547327831,0.30235573180957653,16.299490334767114,81.95632059736991 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark23(-0.6244143714434388,-0.47319097767572893,0.024865254100373005,-100.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark23(0.6248415070777649,1.751328551516578,0.020925857971423698,44.695262611604804 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark23(-0.6268374259506426,-0.4708827140376513,-0.4708827140376519,0.23544135701882563 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark23(-0.6275506340431907,-0.2575344640606403,-0.29088900233966797,-61.79448853531668 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark23(-0.6278603764019992,0.0011212366571187278,114.46778413019882,-98.13953958280835 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark23(-0.6280857909822872,0.3115820923085573,49.8686384775365,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark23(-0.6281659101861448,0.31408278114841576,-0.4713152083153946,46.963773170211894 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark23(-0.62820744666914,0.049086611907067035,-0.3352421292623813,0.7608548574439148 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark23(-0.6282873313619579,-0.21175714988419403,-93.93363759074843,0.10587857494209696 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark23(-0.628318530717273,0.18936281000941582,72.90829808119874,-100.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307178146,0.31415899789815466,100.0,-0.1570794989447579 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307178378,0.31415926534774685,0.3141592653589189,100.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307179584,0.31415926072654865,100.0,1888.9414852826833 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark23(-0.6283185307181989,0.20614192525713887,1.0995574287565477,100.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark23(-0.6284703353291813,0.30306530622092126,-7.975083625215695E-21,-0.4844686108070384 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark23(-0.6289994767028706,-0.4705703568052015,98.35791223949276,-53.494926364875525 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark23(-0.6290824301311442,-0.4708569483318761,-0.4708569483294547,-76.50687460946055 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark23(-0.6293036280444126,-0.470746349375242,-0.18937679229197035,-64.63982688803821 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark23(-0.6297809422851793,-0.47050769225485856,0.29788430289600976,-39.58471705880006 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark23(-0.6299588815847644,0.30027254030169664,31.927856742225742,-0.1501362701508484 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark23(-0.6309266391719028,-0.1875810955472703,0.7189239455390345,-0.010851258112221054 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark23(-0.6345100220138103,0.24541762542858073,-0.44330385395554517,-6.868638051993702 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark23(-0.6351885526380318,0.30041922151880807,1.1029924397164637,-77.26418502325646 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark23(-0.6352744876882379,0.3002473514184185,0.31763724384411895,0.635274487688239 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark23(-0.6353035392430133,-0.4623250008114973,1.103049933018955,-99.73567402811021 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark23(-0.6359053793080857,-0.46511135228487144,0.3179526896540429,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark23(-0.636405628424892,0.29798506994511237,-0.06694623843827632,-0.14725989733413836 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark23(-0.6378718261707165,0.04069245320880962,41.520094785555465,-0.805744390001853 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark23(-0.6382306932307219,-0.3419024789811646,-0.11633800537214724,0.17195597802388973 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark23(-0.6383077293067918,-0.11500343193481377,151.35226883758145,1225.9479540826949 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark23(-0.6383147397645672,0.1884188568259907,-0.4662407935151647,-1.6258520857917413 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark23(-0.6392915889630219,-0.13955936685350334,-100.0,-60.143885667241406 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark23(-0.6395418999649859,-0.17039085646202523,1.1051691133799413,0.08519542823101278 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark23(-0.6409632166355629,0.28872252813509824,-0.46491655507966667,54.04849349705491 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark23(-0.6412978492197424,0.005033175051353814,-0.46474923878757707,-49.64130977018534 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark23(-0.6417887471087669,-0.08250302642155694,150.52865441786136,-71.64023181056723 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark23(0.642020274899611,2.8547621002614023,-0.167513374466189,-43.83878057955123 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark23(-0.6437296808229321,0.21585546080259022,1.1072630038089144,0.6774704329961532 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark23(-0.6439238724846494,0.06556955980094059,-0.46343622715512356,-80.85453640127761 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark23(-0.6441263246698752,-0.43424555970570067,1.3684555315672042E-48,34.71334084367109 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark23(-0.6452706309088719,0.2802550649771525,-0.46276284794301237,-11.917428156893514 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark23(-0.6453579216416225,0.27989590508637074,1.1080771242182594,-0.9176895960531574 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark23(-0.6458636592868522,0.27906898787350537,0.32293182964342604,-100.0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark23(-0.6467325283492104,0.2773312700964757,0.46778579135528925,-79.67388367833001 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark23(-0.6471782559563867,0.2522394284105599,-42.987940294949205,-58.649194610433085 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark23(-0.6476352970362312,0.007893030594490985,0.3238176485181156,-1.0434212777598353 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark23(-0.6483889912878915,-0.4612036677535025,-25.44412138042337,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark23(-0.6486652168548188,0.27346523530960254,-0.4610655526634373,-0.9221304397118681 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark23(-0.650024579281129,0.06223106725634196,-42.60490905426264,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark23(-0.6501311698463068,0.014379025144890534,-78.37077452511559,1837.8449788126723 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark23(-0.6501806087002167,-0.16412599182658238,-0.4603078590473399,87.12693151445478 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark23(-0.6510838363082248,0.1790648842002034,0.2265546209685843,-100.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark23(-0.6513519763074456,-0.45972217524372483,1.111074151551171,0.044525792734420255 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark23(-0.6516581858458697,0.2674799551031571,57.6324711462657,-0.9191381409490271 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark23(-0.6528805321132722,0.032481223833966455,-6.640082849852448,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark23(-0.652933866889727,-0.45893122995258473,2.2970927883448296E-14,-6.053718629824327 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark23(-0.6533852835261809,-0.004032812551653664,-0.4587055216343574,41.89084472920736 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark23(-0.6561901538840961,0.2584160190267042,0.32809507694204804,46.11881004833512 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark23(-0.6565281591624645,0.25774000846996714,0.32979585204681483,-0.47847646322187987 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark23(-0.6567619285301769,0.11697600107816397,46.71520078836398,12.51251920347131 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark23(0.6570125611109713,0.9907165366067643,87.45208244713464,0.29003989509406614 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark23(-0.657089851358525,-0.0065335205399839405,-0.4568532377181858,-99.99999999982703 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark23(-0.6585668486146418,0.2536626295533663,17.376743518363444,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark23(-0.6594309160061189,-0.45427856119428883,74.4290272217982,0.2271392805971444 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark23(-0.6606828789314251,0.0764358777656406,-3.3431459580555476,0.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark23(-0.6607246397025125,0.2493470473898708,-0.4550358435461921,-0.12467352369493545 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark23(-0.6629370813087108,0.2243498299653438,16.217833740769592,65.09010869103285 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark23(-0.6641228431132726,-0.05817796347352891,51.3829420423765,0.8144871451342127 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark23(-0.6648990319192226,0.12553498814322336,72.54531392843028,0.7176368356221625 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark23(-0.6686683760738894,-0.4510639753605036,0.2586209279211628,-39.48834235044171 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark23(-0.6690377323419305,0.23272086211103532,0.3345188661709653,-0.11636043105551774 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark23(-0.6694802197825491,0.14140025170963427,-0.2717617278234736,82.61046644285561 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark23(-0.6696621544629928,-0.4505670861659512,-40.68459367890107,84.0437367262339 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark23(-0.6701585536855961,0.23047921942370422,13.713205802593244,-0.11523982534935402 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark23(-0.6702200775774434,-0.4293968738818532,0.3351100387887217,-0.5706997264565217 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark23(-0.6707063681114952,-0.44653982315830887,1.1207513474531823,-88.71517101220729 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark23(-0.6736577175455445,-0.44856930462467604,0.17191271460010812,-57.85559170394711 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark23(-0.6738302811011954,-0.028889648920102925,0.3369151405505977,33.76466280394409 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark23(-0.6742014422232101,-0.10374229461702728,100.0,100.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark23(-0.6745019287172787,-0.44814719903880673,0.32898255863092285,-0.5424841966673233 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark23(-0.6749225018310252,-0.0942551282817059,-0.4479369124819357,0.7890177572151869 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark23(-0.6753070280243908,0.07642726967756289,44.82198908348869,0.7471845285586668 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark23(-0.6755826200628161,0.2134326974266297,52.91073607693074,-0.10671634871331487 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark23(-0.6756889397761526,-0.06620383955247611,0.3378444698880763,0.03310191977623807 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark23(-0.6757230210672222,0.18375873437364118,1.1232596739310594,0.6935187962106277 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark23(-0.6769901562467282,-0.4469030852740842,0.33849507717738897,-0.5619466207604061 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark23(-0.6774736273021076,0.07295963604566696,0.3387368136510538,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark23(-0.6791322695775943,0.1262159506615556,0.33956613478879716,-1.0530576772187736 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark23(-0.6791660840632756,6.178395520553548E-4,1.0182372248027898,1163.6428549844077 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark23(-0.6793500633150334,0.2120962001370548,-0.44572313173993156,-8.746746342253543 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark23(-0.6794285265557821,0.21193927368333199,0,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark23(-0.679889096936228,0.04290116973684854,-94.2575951217858,-0.02145058486842455 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark23(-0.6799942013917077,0.20955322831445722,97.1835700887883,20.334190012437254 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark23(-0.6808871325883635,-0.2959546544839124,-100.0,-0.637420836155492 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark23(-0.6809880303505653,-1.338415580825966,75.92067564137187,-42.51743054241576 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark23(-0.6830307626748997,-0.29826517464087,-0.4438827820599984,-94.93217589212972 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark23(-0.6844552442823091,-0.44317054125629374,-0.2720559930101963,-100.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark23(-0.6844576855552418,0.20188095257032712,0.18478655885838355,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark23(-0.6852425198246406,-0.17859213404299878,20.620526452571404,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark23(-0.6853004979122282,-1.335744342331055,0.10750430236086832,-100.0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark23(-0.6853163739112768,-0.3447548906886997,-27.498275039709995,-20.241226380331412 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark23(0.6854939195974842,-0.4102373426655414,-23.11924668810976,100.0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark23(-0.6858276111551335,0.16189593534380287,39.72847193308447,53.534594325301 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark23(-0.6863495355130466,-0.16282956019910513,-66.40861572350484,0.08141478009955257 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark23(-0.6871136187235347,0.0734526938637714,27.240941760241064,-43.23810572379648 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark23(-0.6871157742046092,-0.10573928845309855,-0.1280547093951248,55.02978283971908 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark23(-0.6871568121667124,-0.43916110494100075,49.507713563016,5.344646098756972 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark23(-0.6890744618552761,0.19082481489692021,0.34453723092763805,82.59870742633022 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark23(-0.691087730181632,0.04676663178440593,-0.4398542983066322,12.270257589245654 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark23(-0.6913314738493813,0.12403336901202924,99.99880113550087,-0.06201668450601462 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark23(-0.6921437378202611,0.18650885115437396,-0.4393262944873177,-0.09325442557718695 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark23(0.6944473310207385,-1.0502223846650076,72.40419673549701,-0.2602869710649445 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark23(-0.6947625298831658,-1.3889708871314128,22.144512586826096,25.827217860642225 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark23(-0.6961758484875604,0.08457025604895148,0.3451211310749936,-0.04228511881241061 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark23(-0.6962393276331902,0.14731377947474122,0.3481196638165951,-91.96576028637307 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark23(-0.6962875011171838,-0.23620547143649798,-149.75050981245383,-100.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark23(-0.6972691254068706,0.1730340561711139,-40.31517297595089,-0.3742882991970511 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark23(-0.6983994181275294,0.1623290919694162,0.3538297136697118,-2044.0443764221968 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark23(-0.6990279239528479,-0.38477877482183687,0.3495139619759143,-0.33015548940210254 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark23(-0.7008218905240655,0.16915254574676528,0.3330891637036568,533.2670947590934 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark23(-0.7009997078893877,-7.517802575112145E-6,53.2686343837119,0.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark23(-0.7014706338732969,0.16785505904129136,12.896745332412813,8.13940854975041 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark23(-0.7018274037424344,-0.43448446152623105,-21.78654912203417,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark23(-0.7030556920584626,-0.4338703173682175,-0.4338696339883886,-100.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark23(-0.7036309824204001,-1.2362073520871841,172.71379503801387,79.6579028002813 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark23(-0.7038549436545509,-0.4334706915701727,0.35192747182727546,0.21673534578508633 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark23(-0.7046864640494118,0.1597820020699364,0.3523432320247059,-0.0798910010349682 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark23(-0.7057465756794757,0.07539945336581966,1.138271451237186,0.7476984367145384 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark23(-0.7058404944951164,0.15896623623741166,0.3529202472475582,7.006004110045713 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark23(-0.707471314763532,-0.17217941428628586,44.21248414281653,11.701336614273032 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark23(-0.7076719666791544,-0.314159265358958,0.4712388980385449,100.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark23(-0.7076968876664855,0.044720945519364154,3.469446951953614E-18,-0.22134850142980605 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark23(-0.7080023343764925,0.15479165804191125,55.719290056272285,-29.913422535717768 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark23(-0.7084511744639076,0.1402949198030259,1.139623750629402,13.418795491628362 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark23(-0.7088127669689277,-0.4309917799129843,-0.43099177991298443,14.630352226696303 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark23(-0.7092445741114977,-1.4184840258661862,-188.2239317877624,0.7092420129330931 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark23(-0.7098304852418895,-0.4304829207765035,2.1175823681357508E-22,-29.48652679841898 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark23(-0.7111902959257321,-0.4298030154345822,0.3555951479628652,-96.43784966703264 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark23(-0.711498577682834,0.1477991714257886,18.715027451704135,-55.546341894081124 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark23(-0.7123231248600792,0.07120699188379892,0,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark23(0.7128777786588283,2.9965172058495986,-15.718963077919147,-25.060201276766932 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark23(-0.7133642758833822,-0.34927420715551627,100.0,29.411619513997312 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark23(-0.7136771849016073,0.10246209014149088,0.37301566425886623,-0.5828622797583598 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark23(-0.7140000021224138,-0.42562084174611314,-0.4283981623362414,0.2856079416967354 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark23(-0.7144506718073758,-0.09997513746884847,1.1426234993011362,-86.40635247518446 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark23(-0.7145393593498115,0.14171760809527326,50.40254269016252,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark23(-0.7150394965657788,-0.11601053432335301,-59.58462438842766,0.05800526716167651 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark23(-0.7152652339891641,-0.10257692685382658,-21.77216810958382,-954.7084730210627 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark23(-0.7155725832121599,0.13240545158750205,1.1431844550035282,1677.6061043538205 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark23(-0.715819201685131,0.0,-2.801060315328271,78.09991337008391 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark23(-0.7165719722638507,-0.1628321985704573,95.1388343627377,0.8668142626826769 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark23(-0.716658731877236,0.13747886304042412,1.1437275293360663,-72.36327105374683 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark23(-0.7176828404707282,0.017712700408071595,22.603688630661978,-0.008856350204035798 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark23(-0.7183622949939746,0.0668331142014001,60.671575440811225,-61.92781437166392 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark23(-0.7186489903132519,-0.1976872438847754,0.7878142114626862,0.01615724737650305 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark23(-0.7196062231074651,0.021102893267036238,-85.50039018264562,-24.74254007883527 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark23(-0.7206625506842002,-0.046006044751019846,32.986549018249306,100.0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark23(-0.7213742942027767,0.07433679957196644,0.8516630654445727,-86.41913760824208 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark23(-0.7216083999285139,0.053218297907631995,0.36080419996425694,19.578824185885217 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark23(-0.7231668985407763,0.12446252971334375,1.1469816126678365,46.462201385003596 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark23(-0.724716147139877,0.12136403251514233,61.954878905605995,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark23(-0.7249357579737261,0.11246787900944508,0,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark23(-0.725866705314509,0.07241603015247307,-31.077097227574285,100.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark23(-0.7273269983210734,-0.3968772965322813,-0.4016062406262352,100.0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark23(-0.7280380102829994,-0.1854455679139965,-0.07154809819691732,-0.69267537944045 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark23(-0.7282852356748386,-0.39467863116964597,69.31857511149488,-48.97371714317404 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark23(-0.7283846473180374,0.3449473510331562,177.79289923176196,-0.21419274004093564 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark23(-0.7308148615031482,-0.41999073264587405,70.04699588214294,-2002.3340802873042 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark23(-0.7313480725004253,-0.3193273127971812,-122.38298646876669,82.25634033018758 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark23(-0.7329388459840294,0.10491863482683583,-0.4189287404054336,0.7316239256645788 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark23(-0.7331777064175038,-0.2236398769608505,1.1519870166062,-53.42432737666611 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark23(-0.7335020770012324,0.10379217279243158,-35.251076727781545,29.775291512310268 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark23(-0.7339352706125638,-0.31479473966437865,0.35190159526525605,-180.32257703129653 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark23(-0.7349544476478512,-0.0032337711946790193,1.152875387221374,-7.139341434071998 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark23(-0.7363662820944168,0.0912708217520088,0.6071955126687079,0.7397627525214439 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark23(-0.7375824739070932,-0.15079252721726277,-0.4166069264439016,100.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark23(-0.7378819546220841,-0.23224692683198603,126.34409181679086,0.11612346788568387 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark23(-0.7378844402240342,-0.015385163381422373,-28.071520709016973,-0.7777055817067372 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark23(-0.7385425290821438,-0.41338470988663595,5.961667077909363,0.206692354943318 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark23(-0.7386785162541556,-0.41605890527037026,0.3693392581270778,0.19136021537170267 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark23(-0.7389223993748733,0.09295152804396836,4.096458246193264,24.542471873132826 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark23(-0.7395685129357743,-0.06673283483611593,-54.132484675617924,0.03336641741805796 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark23(-0.7399792153030288,-0.2790253945074266,-0.2084755754210761,-67.49100208973212 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark23(-0.7408484865937204,-0.9522603277499029,0.3704242432968602,-118.12101309781559 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark23(-0.7408930406399243,0.08901024551504699,1.0554411905811687,-2120.319545171 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark23(-0.7435266198910511,-0.41363485345192263,27.718662594704526,45.99317343601475 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark23(-0.744563269021512,-0.012765827362420254,1.1576797979082043,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark23(-0.7457523484786585,-0.39491213663180924,0.37287617423932923,-0.5879420950815436 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark23(-0.7468197537792285,-0.4119882865078338,1.0981108361761005,0.2059941432539169 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark23(-0.7471673801107288,0.04985421022755934,100.0,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark23(-0.748988155045427,-0.3639551379644275,-0.41090408587473476,0.967375732379662 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark23(-0.7503377297246074,-0.4078520248530043,0.3751688648623037,-100.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark23(-0.7504020564301098,0.0699922139346767,-53.998810124089324,29.887950410466416 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark23(-0.7516978650791905,-0.4095462175071768,0.3758489325395952,85.02812289691194 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark23(-0.7521544387261676,-0.1726611264968187,0.3760772193630838,-0.3969210638270214 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark23(-0.752201771812979,-0.4092972774907724,-100.0,0.20464863874538616 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark23(0.7548979383496812,3.080347586293931,-4.2302673530161945,55.79430230710099 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark23(-0.7566824668001295,-0.4070569299973834,-0.1948974322175497,88.41994156166248 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark23(-0.7569533999042709,0.05688951358759454,55.524442869900774,-1408.329318833388 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark23(-0.7583749779679535,0.054004971494873766,0.37918748898397675,-0.02700248574743688 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark23(-0.7597347578589195,-0.40553078446798846,0.06278388356217335,-59.43621661582642 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark23(-0.7598743011997866,7.264037527126542E-17,-0.09672098952378311,-3.1226336901866795E-17 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark23(-0.7612830734044109,-0.32019794260693624,-0.4047566266952428,47.049470488236764 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark23(0.7614577956344537,2.431193875557152,-0.3683142101234709,-6.713048853943758 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark23(-0.7620455273102017,-0.23696436896769071,-72.12239528081575,0.9038803478812937 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark23(-0.7620839995205125,-1.5223778376976629,0.012448992180894791,-16.517594631625983 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark23(-0.7622234503784395,-1.0762884007880695,-27.42890516005562,-70.1389847771111 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark23(-0.7626611285543385,-0.4040641457357966,-0.05881823466211387,0.20203207286789826 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark23(-0.7635459349180245,0.038354208732857366,85.45237917556832,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark23(-0.7641751897894125,0.04244594721607142,-63.91704941169851,-1.2294093612854358 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark23(-0.7648677289367746,0.015284998817738555,77.218254992704,100.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark23(-0.7654633263602144,-0.035516596402600964,0.7505422099817294,-229.44113690993348 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark23(-0.7656899292705139,-0.34543847931420624,1.1682431280327052,-20.08979404040685 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark23(-0.7665143723178047,-0.1945518200385038,73.20947732287411,94.21296661189217 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark23(-0.7668295335740822,-0.20917654597080618,2.0543359060089585,0.10458827298540309 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark23(-0.7671125597721965,-0.4018418835113501,0.3198098796030153,-42.940776613546845 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark23(-0.7674733406630576,-0.1534401148308561,50.334646139275705,0.8621182208128815 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark23(-0.7680238237408883,-1.4941455915634783,1.1707224634763262,-88.78836769392177 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark23(-0.7685192854422436,-0.4011385206763265,0.12389083407492052,-89.28864785761226 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark23(-0.7706441107517543,-0.3913626770618615,0.15650542667893944,0.19568133853093073 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark23(-0.7716408880008139,-0.3995777193970411,-0.39957771939704134,-36.78203718847495 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark23(-0.7728056490242822,-0.18812274214202723,0.3856790022583633,0.09406137107101364 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark23(-0.7728993963856083,-0.38387811612767503,-96.42632248696584,0.1919384163745298 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark23(-0.7736128227886002,0.02357068121769587,-53.632147552034354,-0.7971835040062961 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark23(-0.7750939677626376,-0.3762717746271109,27.599689816444858,34.066465442873124 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark23(-0.7757567991200762,-0.11080151014080379,5.0280278886015905E-8,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark23(-0.7759241862027019,0.018947954389141933,-99.99999999999964,-26.951868662087904 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark23(-0.7766256864484276,-0.38993534814770014,0.3883128432242138,61.57049651105203 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark23(-0.776901381507777,-0.003481067638089271,23.84923354928121,0.7871384919774197 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark23(-0.7774892219138723,0.015817882967151583,-0.39665355244051215,-0.007908941483575793 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark23(-0.778405183805524,-0.39619557149468626,0.38920259190276196,-35.81607269874439 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark23(-0.7786517336720296,-0.3960722965614335,-0.05781143028981317,-1038.0522922116738 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark23(-0.7792241147476661,0.012293517758748906,0.389612057373833,420.7566709715106 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark23(0.7809613637114095,-1.1758788452531528,-0.7104481532372949,1.3733375860240247 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark23(-0.7815157533062407,-4.219167203424331E-13,0.6163140065842257,-0.28452960910140535 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark23(-0.7817366296331565,0.007323067528582916,92.90483241182699,-0.003661533764291458 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark23(-0.7819708853739741,-0.2799041183728851,1.1067585320566131,-64.07916674992558 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark23(-0.7827586565736163,0.005279013647663658,-17.777477155307864,-96.70448904221628 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark23(-0.7838405817160153,-0.33746805364419513,1.177318454255456,-31.28425244225097 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark23(-0.7838843164121421,-0.39345600519137724,0.3917835038351732,0.18683279017255014 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark23(-0.7843941891814572,0.3921970945907285,-0.049185438193847686,100.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark23(-0.784833266766427,-0.3320493445586181,-0.39298153001423475,-51.375777334659276 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark23(-0.7853981633970806,7.351896869067787E-13,-99.70866846214216,-0.7853981633949109 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark23(0.7854002021830997,-0.9147684094614816,-0.39137744488642523,-112.89207657147993 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark23(-0.7854491801293477,-0.38328811487273684,0.39272459006467386,0.19164405743638613 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark23(-0.7859730160170963,-0.3736806686692876,-0.3126197830419002,0.1868403343346438 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark23(-0.7867598070597553,-0.002723287324615789,1.1787767495771764,-0.7840365197313758 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark23(-0.7869804345828454,-0.04036730584727714,0.1263024329683767,-7.833363518636354 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark23(-0.7870437746160901,-0.1656636992200822,34.927817293379924,-0.15320543626820893 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark23(-0.7879010955227871,-0.005005864250677861,26.123049530389544,-0.5739088951508643 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark23(-0.7888084314394957,-0.007064648346860798,-97.77244202259038,0.7889304875708787 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark23(-0.7898780795125331,-0.008959832230169829,-0.3904591236411818,22.510569100126887 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark23(-0.7937196436068218,-0.016643103214999712,0.0,0.008321551607499922 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark23(-0.7944571310936582,-1.5673714520553172,-81.36784572908921,1.569083889425107 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark23(-0.7946128290380247,-0.019988171268418904,223.4538390526418,-0.35712622793500165 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark23(-0.7961060478593327,-0.021415769811858353,-91.90040250694223,13.34548076284755 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark23(-0.7968945712208009,-0.02302461417834486,100.0,100.0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark23(-0.798020646944476,-0.2518730100601867,0.5378978458779464,-7.213413577588698E-14 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark23(-0.7991323474861414,-0.37931691590753447,0.3995661737430707,58.92671500814686 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark23(-0.7994366109247022,-0.38567985793509707,82.74457887058838,5.988902048945381 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark23(-0.7997694321282276,-0.09473260842412934,-85.04717971524572,17.065556510092946 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark23(-0.8012896688682767,-0.03200824996232737,-25.958332368556285,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark23(-0.8034874576717205,-0.21425655533455873,0.758052363844439,0.09496413123009387 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark23(-0.8042603386115488,-0.26543846485298317,25.542088134245684,-48.87640535365728 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark23(-0.8049129463129396,-0.15889707561565766,92.75952034415744,63.39569245538809 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark23(-0.8052768005268035,-0.3827597631340465,0.0,-43.657214954604946 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark23(-0.8065572909931831,-0.04231825519180732,100.0,36.68486057354241 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark23(-0.8065872507598479,-0.3821045380175243,-0.38210453801752436,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark23(-0.8087453672170808,-0.04669440763961537,-21.694749906191202,90.44354091113172 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark23(-0.8097216676352099,-0.3115793428580106,65.41482243951967,1635.9170287228112 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark23(-0.8098226860758129,-0.22121085222718306,78.59094578912536,31.21589067983354 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark23(-0.8125759182895949,-0.05435551069513813,1.4095675870846378,15.788364867606916 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark23(-0.8131955254424299,-0.055594724090236136,71.82369580006156,-0.7576008013523302 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark23(-0.8155783329399721,-0.17870563666179,0.15106336408252077,-0.020021966360120432 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark23(-0.8167735357032987,-1.5896033454428824,0.40838676785164935,-1.553129619666422 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark23(-0.8176830433224629,-1.57310333316656,73.44845311453192,-30.63839247128103 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark23(-0.8183652988123035,-0.06593427082988286,-24.72636547674637,0.03296713541494143 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark23(-0.818880700962135,-0.37595781291638053,0.4286312894946207,0.12318837947092298 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark23(-0.8189767827185113,-0.37396872194723674,0.5668129434591811,17.921067250148482 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark23(-0.8190461574939901,-0.06729598819308394,1.1949212421444433,40.056647590829336 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark23(-0.8193966290169917,-0.18725968539926913,-0.05542522536083569,7.222281283447414 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark23(-0.819411380419043,-0.06802643404318992,-51.42158943514519,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark23(-0.8202393258563223,-0.3752785004692867,-2058.767678717936,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark23(-0.8215521646525559,-0.2540257819275591,83.37895078107874,67.98964869066718 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark23(-0.8217070141900152,-0.21841645881573518,0.4108535070950076,0.3528129901420644 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark23(-0.8225335562573161,-0.36300366361520986,1.1966649415261064,-45.36515130137953 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark23(0.8238995074571115,-1.2056404905897478,-0.39653710573796874,5.315209225679563 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark23(-0.8251311267094731,-0.13133238668574773,0.7187396027589463,-0.7197319700545743 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark23(-0.8258765211809092,-0.24404380358040156,-100.0,-53.830394304680375 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark23(-0.8276211101224672,-0.3444561099324395,24.4350620976916,0.1722280549662198 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark23(-0.8277047704286595,-0.3715457781831185,0.22527741363977327,-0.599625274305889 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark23(-0.8280095608606453,-0.08522279492639412,-41.01903611450092,-31.65818645371041 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark23(-0.8287504595834257,-0.25173495493537057,0.4556328449888973,0.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark23(-0.8288423912766559,-0.14903285048833717,-0.37097696775912026,-100.0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark23(-0.8315142677276437,-0.21579066764316493,34.11877658778042,-100.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark23(-0.8317874176852555,-0.36575600783380663,-0.36950445455482045,-1622.4517483821303 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark23(-0.8322402007767483,-0.09368408454852596,6.919258048260182,-152.49776667257862 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark23(-0.8323979077925671,-0.3063130487928613,1.2015971172937319,0.15315652439643065 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark23(-0.8327681496309942,-0.09473997246709222,-0.3690140885819512,-99.96383831527122 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark23(-0.8328731958257412,-0.36849659435272425,0.41037555821480654,0.9538266570252643 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark23(-0.8336657996244665,-0.31613764540879297,50.80943687536983,-95.9005269011558 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark23(-0.8343540800792296,-0.09791183336356288,-47.86464323273763,56.04295492318761 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark23(-0.8343559113556347,-0.36042511235434826,-12.31372160581146,75.63349390506869 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark23(-0.8345678991398253,-0.09833947148475429,0.02160146846356359,0.8345678991398254 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark23(-0.834919602742559,-1.6698392054643736,47.41736264696641,0.8349196027321868 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark23(-0.8355317127167197,-0.10026709863854366,-1.2415759011788623,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark23(-0.8355374197425924,-0.14179324689443448,1.2031668732687444,-1.2712572713648707 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark23(-0.8369687944563708,-0.36691376616926197,-100.0,0.18345688308463096 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark23(-0.8372733735752926,-0.14332084262197142,0.4186366867876463,0.07166042131098571 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark23(-0.8372775280902514,-1.6745547702848587,-0.3667593993523226,-4.370036563080992 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark23(-0.8381912326038975,-0.10558613841289907,41.25882943795719,0.05279306920644953 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark23(-0.8394427619397807,-0.10808919708477802,-0.08745344140072152,-99.80432444336674 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark23(-0.8399278752681134,-0.109059423741367,1.205362101031505,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark23(-0.8401527675935353,-0.36532177960068063,0.025155011445492835,-0.6027372735971079 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark23(-0.8405252839727184,-0.11025424115054074,-0.36513552141108907,-0.7302710428221779 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark23(-0.8409352314680847,-0.11147919627137048,-0.36493054766340594,-1242.825855833694 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark23(-0.841758092001403,-0.1282216017743627,0.4208790460007015,-62.475344915828266 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark23(-0.8418170637523894,-0.3644896315212536,-0.11980501038672889,0.1822448157606268 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark23(-0.8435516929765869,-0.11630705915828021,0.19419308104771882,11.925767528667736 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark23(-0.8438037144575272,-0.11681110212015966,1.207300020626212,0.05840555106007983 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark23(-0.8438438198439853,-0.3012252446935467,5.925773011256027,-0.6347855410506824 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark23(-0.8444102731484753,-0.36319302682321064,-0.07245148938542294,-74.99227221563396 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark23(-0.8450092187436473,-0.3628935540256242,-0.3628935540256246,-11.26751381757328 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark23(-0.8451734371871313,-0.14032986341828355,1.1191945667901682,0.07016493170914177 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark23(-0.8458780226163845,-0.12095971850745454,44.75491504991485,-1.63943548479241E-10 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark23(-0.8482206373693838,-0.36128784471275627,-1.017631758164594,0.18064392235637816 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark23(-0.8484509661936048,-0.12610560559231482,1.2096236464942507,0.06305280279615744 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark23(-0.8487201810257724,-0.12666105968501973,1.2097582539103344,-50.572288645420095 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark23(-0.8496603393824951,-0.12852438807264843,29.104137991182355,54.2480363057049 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark23(-0.849691829929526,-0.2352443769779996,20.759396947084017,-99.75444755231584 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark23(-0.8498449370409088,-0.27183464806910657,79.02719340639838,0.13591732683622892 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark23(-0.8504341181469715,-0.13007190949904648,16.3478771666008,-814.3255621207206 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark23(-0.8514860431573203,-0.3587058758135922,0.4257430215786602,0.9634361809848163 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark23(-0.85247162502248,-1.6901999359752722,100.0,96.6779370266893 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark23(-0.8530689777833937,-0.13558499410930827,9.633015860343368,0.8531906604521025 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark23(-0.8531795490590768,-0.3141592653589698,-49.2808630393385,0.15707963267948494 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark23(-0.8533573760118732,-0.3578391716553996,0.4266786880059366,-16.459909194901385 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark23(-0.8536563357509044,-0.35856999552199587,22.237739296235283,100.0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark23(-0.8538336216857627,-0.13688553841374568,52.97547571651944,74.14783272291793 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark23(-0.8551905885134816,-0.1681539028327199,0.043027872902604763,78.6314267792469 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark23(-0.8574986518778547,-0.356648837458521,0.42874932593892723,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark23(-0.8588671241938877,-0.31641401026001614,87.00461410833861,59.04759127085853 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark23(-0.8596349798416071,-0.3555806734766447,-0.1439734891960988,-100.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark23(-0.8598210531166695,-0.15760900868309013,-100.0,-83.71835742554681 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark23(-0.8600918706514444,-0.14938741450799248,47.583522991874965,0.8600918706514445 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark23(-0.8605044857168934,-0.3551459205390016,0.12822783308534705,-88.96562563079883 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark23(0.8628352964667663,-0.8932151822947155,108.89090604354908,-0.33879057224813464 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark23(-0.8632407792449692,-0.15568523169516119,-100.0,-100.0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark23(-0.8636178549976925,-0.15643938320048867,0.6105001823895829,-43.810286281311335 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark23(-0.8638803633599843,-0.1569643999250723,69.02041992001458,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark23(-0.865229552641847,-0.15966277848879756,0.3609963058489885,0.8589250330705819 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark23(-0.8652765781330887,-0.1944850763191229,-0.3527598743309037,0.13431588368854408 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark23(-0.8653800255317909,-0.15996372426868555,1.2180881761633437,86.5477657893257 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark23(0.8655184732511856,-96.87742960363481,-98.86926965020324,-28.97708204220453 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark23(-0.8659384118937331,-0.16108049699294114,-87.06120759717545,-297.46801989860506 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark23(-0.8673944058758728,-0.3231757849362325,16.923849667791863,0.9469860558655645 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark23(-0.8675649355303627,-0.16433354426582913,-0.04918838150337279,79.83317700088517 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark23(0.8695414677405608,-16.461920282776703,-0.4347707338702822,-97.01239375362678 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark23(-0.8704497425045905,-0.17010315821428487,72.2848463464036,0.07232455023251465 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark23(-0.8705750956187632,-0.17035386444263012,49.149572606917566,49.763335061189906 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark23(-0.8715888171276358,-0.17238130746037816,0,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark23(-0.872012011749479,-0.2187644367180912,73.28753887508874,79.69225228142317 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark23(-0.8723661235127762,-0.3409860123559093,100.0,0.9558911695754029 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark23(-0.8734580685089971,-0.17611981022310275,-0.3486691291429498,28.335621526741612 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark23(-0.8751186921821742,-0.18854613409611476,0.332685215218135,20.51426467328905 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark23(-0.8771175546147179,-0.34683938609008935,5.5316862201948425E-12,-45.31337009125889 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark23(-0.8776785329467123,-0.18456073909852835,0.43883926647335614,-0.06971778827629979 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark23(-0.8783889914228834,-0.32228382778768405,50.82294568976329,0.9465400772912903 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark23(-0.8810600457939773,-0.19132376479305835,1.225928186294437,-0.6897362810009191 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark23(-0.8811466019263599,-0.34478986264260875,-0.34482486243426835,2.0088209269544723 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark23(-0.8812205949829011,-0.19941390659058572,0.44061029749145053,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark23(-0.8817449399841144,-0.23294244440680487,3.8840031005545583,100.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark23(-0.8818940238962115,-0.20064999165551886,-74.77852257394619,1981.1440974830987 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark23(-0.8832196243755861,-0.2663485529477676,1.2270079755852412,1635.0530773071707 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark23(-0.8832295492697558,-0.19566277174461533,-2433.8632803580203,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark23(0.8840062439187091,-3.0303333092524802,77.3163678119447,36.85791817539511 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark23(-0.8858911724585206,-0.3424525771681879,2.7755575615628914E-17,-0.6141718748133544 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark23(-0.8862971867638288,-0.32429956417805095,-47.88585959046831,90.81718117075718 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark23(-0.8882457936551957,-0.20570423398278825,-0.3412752665698504,0.8882502803888424 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark23(-0.8893957269216907,-0.20799512704892667,0.44469786346084533,0.10399756352424272 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark23(-0.8894289267848354,-0.20806152677477519,16.247727368505345,-88.40786415115346 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark23(-0.8899052665054895,-0.2090301382720245,-36.483368153637585,-100.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark23(-0.8906719047789894,-0.2365978921208419,0.15994829468368277,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark23(-0.891405103690993,-0.25238545260567014,-0.3396956115519518,80.25651740670756 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark23(-0.8934775198183514,-0.2383315665861699,51.40879218788415,50.282911732528774 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark23(-0.8943956090231169,-0.23193878331052728,65.16291776983594,34.67350016880687 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark23(-0.8972813005279665,-0.23218433496611426,84.50523279951162,-45.46441262708443 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark23(-0.8982028191778854,-0.2402224646686049,-0.33629675380850566,-76.05051198624928 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark23(-0.8997051956412903,-0.3355455251771632,0.4415865287830389,-0.6176253806090464 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark23(-0.9001881766269094,-0.3326669068332446,-6.397044428877294,100.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark23(-0.9011359508385007,-0.33483018797819797,0.38699736542086727,0.16737645258102657 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark23(-0.9017350147477723,-1.8018385318485377,-54.03395123873249,0.9009192659242689 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark23(-0.9047912034573522,-0.33300256166877207,52.81319727559954,-24.22531573915609 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark23(-0.9050958666873506,-0.33285023005377296,-0.3328502300537728,-53.03668309154696 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark23(-0.9054200473424765,-0.2504102655879181,0.18416422868522284,0.12520513279395917 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark23(-0.905493050480598,-0.24018977416629972,1.2381446886377474,-0.8664704724961111 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark23(-0.905527967284873,-0.24026434879536596,-99.99999197657907,-12.332182030595519 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark23(-0.9060498239927489,-0.33237325140107377,0.4530249119963744,-99.99999999999662 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark23(-0.9069642511101386,-0.243132179441714,0.4534821255550693,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark23(-0.9080148967717427,-0.2740884812034743,31.32392465026928,-98.55302439509444 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark23(-0.9080681472352887,-0.3074221471013576,-0.33136408977980386,0.9391092369481271 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark23(-0.9086057423783436,-0.3310952922082758,27.863927414074634,-89.68656988776799 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark23(-0.9092023955459443,-0.3307969654939842,100.0,0.9507966461444404 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark23(-0.9094840514232041,-0.24823700275300098,1.2400002868790605,-0.6612796620209469 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark23(-0.9097064019647924,-0.31892643024137113,100.0,-100.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark23(-0.9107373760341175,-0.2660588276987094,50.44823442125414,715.9393707891113 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark23(-0.9111709490472091,-0.32981268887384374,1.1249848279353923E-39,-59.32758839162735 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark23(-0.9112120162440578,-0.25672346999903783,100.0,-0.6570364283979294 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark23(0.9113759207729556,2.635243749140749,128.37301781978172,100.0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark23(-0.9114474761855547,-0.329674425304671,-0.32796729820637094,0.14061016869962423 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark23(-0.9123196493038227,-0.32087944894005127,-100.0,-92.38829941158413 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark23(-0.9124220716067746,-0.25404781641865276,0.19819591930975147,0.1270239082093264 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark23(-0.9131972136734423,-0.25559810055262905,52.479601624475656,90.95084449648552 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark23(-0.9141357603415581,-0.3204023653607268,94.98639091684099,-26.923855947623554 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark23(-0.9163228882213739,-0.26184978827633587,1.1547868999685558,-93.65291044515428 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark23(-0.9173047986305685,-0.3265032248960733,-96.23834808507175,0.16325160132987435 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark23(-0.9198051825056553,-0.2858649245361348,-0.32549557214462055,-0.25316426360901984 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark23(-0.9204439248403747,-0.32517620097726074,1.2456201258176356,0.5412844966985827 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark23(-0.920450551010899,-0.27010477522690174,0.8060575945357136,0.9197604211931533 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark23(-0.9206035178071281,-0.3250964044938842,0.30146664937427636,-42.68391931736319 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark23(-0.921220585235748,-0.27391876970940304,34.91771012719177,-46.60243930492946 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark23(-0.9214228609069802,-0.27329942422621106,-82.09363538052574,24.75302543626836 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark23(-0.922781778041998,-0.32400727437644816,1.2467890524184344,-0.6232869146411972 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark23(-0.9232810718890923,-0.2935694628325295,100.0,0.14678473143697054 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark23(-0.924623988545102,-0.323086169124897,1.2477101576699992,-0.6238550788349997 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark23(-0.9256254175764844,-0.3184318288936316,-0.32258545460920596,0.15921591444707217 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark23(-0.9259328645232274,-0.28106940225155863,0.7218442852966852,56.113383130313 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark23(-0.9261828725331573,-0.2967686215586177,0.9266316797926664,0.8394076644426834 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark23(-0.9275700383418952,-0.28434374988889344,0.30212297628170637,-96.8238964558642 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark23(-0.9285001033597611,-0.296201696338341,74.24407964992213,90.76866696563204 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark23(-0.93103552942144,-0.31988039868672835,0,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark23(-0.9310492714743802,-0.30214606911184577,0.4655246357371901,0.13331498243891945 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark23(-0.9313883289465067,-0.319703998924195,0.08954903299446326,-0.3058538985927074 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark23(-0.9317930607336214,-0.3080880048753524,0.4614698215609962,0.9099113292758869 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark23(-0.9318943744660082,-0.29299242213712,99.06420150870683,50.99823031318249 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark23(-0.9320080063631356,-0.29321968593137493,-0.15553519482060066,88.56508864647992 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark23(-0.9331861716388763,-1.8440284810632572,80.249430394813,7.990507118443521 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark23(-0.9344498094258644,-0.2981032920568325,6.14811727198823,0.9344498094258645 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark23(-0.935370563460955,-0.29994480012701386,78.57026698910614,99.81043023608929 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark23(-0.9370860312319262,-0.30337573566933984,0.7893816045610766,100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark23(-0.9372449597669145,-0.30383057175650596,17.703854296297905,0.15191594830065297 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark23(-0.9376960900682003,-0.3165501183633479,-27.135611468002782,-0.6271231042157743 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark23(-0.9379095473279518,0.3463711348833399,-53.63733867789722,42.2383307528474 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark23(-0.9389504430860307,-0.3071045593771674,-0.315922941854433,-81.80731517226174 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark23(-0.9398619955192696,-0.31346866699002685,0.22369995947923008,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark23(-0.9399254069970346,-0.313224690699435,97.84104014529008,100.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark23(-0.9407909277114044,-0.3120945405273561,0.4703954638557022,-43.786022287076506 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark23(-0.942398978120703,-0.3141592404148241,0.4711994890603515,100.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960769335,-0.3141592653589814,-12.312648756545487,1500.5519679933193 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960769372,-0.3141592653589779,-0.3114073902829048,-76.72682340905273 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark23(-0.9424777960769376,-0.3141592653589795,0.4712388980384688,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark23(0.9457082461420914,2.2905276816533604,100.0,-30.980370454786502 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark23(-0.962036906015884,-1.9240599899859951,-40.50143688900357,0.9620299949929976 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark23(0.9632890413582369,-0.48164458726293313,85.13083597920534,-78.93734561564312 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark23(0.9936644800864891,3.147945013690156,0.2885659233542037,242.6848682716971 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark23(1.0001513921934757,-0.5035543214244881,108.69084729156307,100.0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark23(1.002665015205133,-1.2466174009941955,-0.5012763071057996,-26.08031993752793 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark23(1.0157696711218092,-0.5197925075434069,81.9745506414125,94.73167644887769 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark23(1.0161550280190785,2.7056066030009034,-0.5080775140095393,100.0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark23(-1.0167891038287749,-2.0137802419723614,66.02188813609538,106.24952795153774 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark23(-1.035716548132896,-1.4410355342777563,-27.9370390265409,26.638396376189814 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark23(-10.387487005637965,12.90926784349331,-55.98301537494406,47.73595661475048 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark23(10.465214339196109,-5.232607446725233,44.24747715249325,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark23(-1.0535360475927096,-1.052423104722898,0.5267680237963547,0.5262111308866971 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark23(-1.061959697005547,-0.9026757232122248,-99.99999997266995,0.45133651642824973 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark23(-1.062532387453182,-0.2365148929594036,-100.0,-57.81083976656975 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark23(1.0625547351782556,2.1251143699317825,100.0,6.1496256188762715 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark23(-10.657093040083279,-21.30705383286386,86.90758135428966,9.082866532603996 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark23(1.0696676287654758,-0.8372989670622398,100.0,-59.30684618360624 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark23(-10.769308636512648,77.31883868906266,-40.93350801266497,-81.53914971901571 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark23(-1.078052045860229,-2.155713179459126,144.32314747043742,1.8548200772848866 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark23(-1.0787266007109717,-2.0870832258812535,59.55532976069887,7.326089606134772 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark23(1.081454540379745,3.7336994236661885,-0.2870493282447063,54.68181804610418 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark23(1.0822600585087265,3.734688810069802,-19.821258877323025,35.8340795109627 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark23(10.863952442234279,-6.141516924452029,10.789920775284516,99.6747258572931 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark23(-1.0949662971385326,-2.1054376638600103,-0.23791501488663158,85.35394552431647 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark23(1.0959508151549824,-0.560419038841043,100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark23(-1.0976731274577596,-2.1948622125145145,-94.26681475665227,7.629835261015919 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark23(11.046270518368685,23.662456657045944,-4.949851689716258,-11.060898060422401 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark23(-1.111700690758018,-0.7066587548233241,27.704882614398,-21.963581324988365 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark23(-11.163394212378213,-22.326775916849915,6.270333121556797,11.163387958424957 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark23(-11.182608358183586,22.907440380998807,0,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark23(-1.1190992853196295,-0.726239653150867,1.3450101415960103,16.630441407444938 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark23(-11.217380092246477,-22.397566916273135,4.8232918827257905,-79.12205244915548 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark23(1.1249017338381087,2.461182075801673,100.0,-100.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark23(-1.133325851909591,0.5666629259547954,0.3682160540792434,-100.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark23(-1.1346276054284108,-0.7430173382870597,0.2680152605231428,-59.74459322471424 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark23(11.374424250477555,-5.687837642899682,61.85722507511376,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark23(-11.415293482714457,-22.828747886971097,6.49337798006054,11.414373943485549 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark23(1.1589479321093838,3.6329700614955005,99.99999878971902,42.49837442397382 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark23(-1.161062609933261,-0.20486685843081764,53.70200038417027,-44.80407775903346 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark23(-1.164895251513903,-0.8501419914484473,-65.01418898348248,0.4250709957242236 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark23(1.1715212237757955,3.61059292213601,52.04399229044776,-47.358380700630065 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark23(-1.1730357437242547,-0.775275160653613,35.14061401220707,1.0680544674328933 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark23(-1.1758283830662946,-0.19748397186430092,-0.1974839718643011,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark23(1.178112588042328,-0.7667883555781804,96.98180910828279,-78.68085854155592 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark23(-1.1818968238854595,-0.151431665105062,129.43294865870524,-0.2141855921016237 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark23(1.1939303693005774,-0.6172724377376999,18.85169741277951,91.40782894501845 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark23(11.993701552374736,-5.996913384776477,-60.18932300384678,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark23(1.2024260371000275,-0.6721961517698459,42.84599248575472,-204.0044541457744 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark23(1.2069352020128163,2.637388517679706,-97.33240484288152,-1.3183954804387172 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark23(12.12956624150037,-51.13660109448801,-73.41998399628457,12.546769288733401 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark23(-12.198532290795397,-11.59728788777142,85.4226955677083,5.79864394388571 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark23(-1.229659347372212,0.6148296736861059,-52.51034733862599,-34.80016488256918 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark23(1.2338057834189613,4.038116698153061,-0.6169028917094806,71.02302043475832 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark23(1.2353467981293371,-0.6399695489335316,-19.458461208630563,-1484.5489405503604 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark23(-1.2412221115803634,-0.16440559594555237,25.751030220578972,1462.569804794312 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark23(-1.2556838559114962,-2.5113677118229925,41.32620922547447,-41.85740721325661 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark23(-1.255863535274413,-0.9510806891029399,0.627891786008548,-0.30856488846987185 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark23(-1.2570682701271263,-2.5097363059579965,0.14950972685125968,57.0181092100455 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark23(1.265045171901202,-1.1643011914916181,100.0,-6.189530020633305 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark23(12.745359425567068,27.059305929594196,41.18460166259132,-15.885009485914091 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark23(-1.2876936253142133,-2.533942161331715,1.429244976054555,-39.57511370890991 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark23(-1.293328525604997,-1.0167296359736313,22.63781193809873,174.837593850814 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark23(-12.968058399048358,6.482983758534618,6.482983758534637,-4.026890042664758 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark23(-1.300030435168605,-2.4818613224710977,0.6485451950058903,-23.106432886244594 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark23(-1.3163797294085968,-2.6327565533945245,100.0,-100.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark23(-1.316743462349325,-2.216465476112269,-0.1270264322227858,47.44489810915979 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark23(-1.3276077322854942,-1.8540269195943737,0.6637625675340177,4.852536810732934 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark23(-1.3402099542952763,-2.632628637312655,0.6701049771476382,-156.73905966001757 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark23(-1.342927450653536,-1.6950663794313379,41.51167432074453,0.062135023441485804 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark23(-13.480073391841733,-26.960146783683463,0,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark23(-1.3516923885288392,-1.2290758229516712,4.688780700541581,0.6190816400684224 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark23(-1.3603921338185387,-1.154362327225925,1.4636704157111544,1.3296664132748743 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark23(13.628335730214085,-6.822079344676405,100.0,55.0290514774064 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark23(-13.633008597117458,6.031331361092308,-99.99999999999994,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark23(-1.3688758223193958,32.49804672800013,-55.48956689930411,-39.78106319178474 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark23(-1.37828546223849,-2.7565608672676922,0.2317664651434535,75.20570254791052 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark23(1.3789570229138757,-1.4519006276720103,17.43806891255525,43.92275377113134 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark23(13.857549821091721,-6.928774910558852,-7.714173073943364,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark23(-13.932417681545289,6.8684051051172945,57.51609341874424,-3.4339836428982515 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark23(-1.4079027068648888,0.40083741872692513,19.26799405186085,0.5849794540339859 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark23(-14.260363736602256,6.345424138056022,-36.13037466083062,100.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark23(14.346866081761881,30.264528490318657,83.74106128378939,-8.849078956201206 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark23(14.403895071455496,65.17386070268435,43.848288953672046,-32.586930351342176 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark23(-1.4495412494616495,-1.3287104603233464,44.706043580999435,1.4497533935591214 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark23(-1.4558720606687335E-9,-1.3134988565723863E-11,7.279360303343668E-10,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark23(-1.460272694917255,0.34712438391914613,-146.65855832608509,27.111796915814907 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark23(-1.466691758882478,-0.0520291321477581,22.43893306855311,0.0016983856399162387 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark23(-14.830860978120917,15.04775475196951,62.41830669522183,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark23(-1.4971085394534667,0.7483708562214271,1.5339524330735903,-2.4431844480418086 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark23(-1.4997223625684712,-0.03457816912501805,1.535259344681684,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark23(15.00169811528269,55.71527837458243,-7.500849057641345,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark23(-15.013236543725327,6.549508561840625,58.62225090941183,-70.9337076261519 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark23(1.5068180897170482,-0.753409044858524,88.02905937291108,100.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark23(1.5134559623180044,4.438401681041091,0.02867018184614387,-1.4337327025596647 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark23(-1.5138530081332056,0.2756791024463583,176.39921523936505,30.29854655352559 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark23(-1.5247132599563133,0.552028502401141,0.022516121765208785,-1.8035269454798546 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark23(-15.271892156202648,-28.972987985610402,0,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark23(-1.5294747562955957,-0.020660785249650176,62.02571293694665,-0.00487315824533141 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark23(-1.52978610812738E-16,-5.905106252561084E-17,-63.62302097617346,2.9525531262805425E-17 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark23(1.5471974377444004,-0.9248707857441889,-1.5588173050997411,1.2719845504610419 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark23(15.630950519926333,32.83257358291181,-7.912608359490974,39.34700885861857 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark23(-1.5695434041923786,-3.063264024599927,0.6654242515498631,-100.0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark23(1.5863962670836977,-0.8094945023021547,100.0,-100.0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark23(15.941628073314513,33.45405247342392,-100.0,-16.72702623671196 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark23(-1.6026623624952505,0.801331181247624,1.5867293446450734,-94.64814203467995 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark23(-1.627821609980191,-3.209758619992091,0.5516360009710418,-52.73659014063518 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark23(-1.632110145042776,0.8106126595791184,112.30865393920625,527.8858264414082 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark23(-1.6338401490185752,-3.2676665203802253,32.68088822775217,62.896834415380255 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark23(-16.4409188700021,8.195497374050657,7.490468713821817,-4.866888307744797 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark23(-16.59862341184041,-33.19617133123426,83.49421908527295,14.267782275425894 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark23(16.670508687382736,-90.03894351303623,83.15289291004581,-16.26517960674117 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark23(-1.676974000259592,-3.2598144060524703,0.8384870001306031,92.73609415711447 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark23(1.7250572635513892,5.020910844818006,-99.5193171538044,-2.5104554200111893 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark23(1.731414205766496,-1.4089111064268036,59.74805362273631,1.017933245965407 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark23(-1.7383319976247396,0.8691659733773012,102.08102427146534,0.3508151767087977 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark23(-17.38970656007411,-33.61938054705351,-91.1417387042424,16.024292110129306 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark23(17.437627812981276,36.44605195275744,62.07816926956955,-46.49735891196516 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark23(1.756295849208193,4.931523915177132,121.12051959196064,-85.72581325500411 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark23(17.563962668894906,35.47205587179136,7.007998944094481,-16.917211837977117 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark23(1.7571423581875654,-1.6590300228541968,-98.2144763959154,0.8295150114270982 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark23(-1.7661707870343664,0.7806796735546403,54.88917029794035,-0.3903398367773201 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark23(-1.7681671763653208,-3.4034538994358603,0.8839837864933258,-11.652254297514048 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark23(-1.7770817314733733,-50.41455038889487,-2.418687740702424,-39.08865512117363 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark23(-1.7814821113003625,0.10534289225274064,0.10534289225273241,-0.05267144612636798 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark23(18.217261066454682,38.005318459704256,-43.03059862958703,-19.002659229852128 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark23(-1.8266815139980963,-2.082566701201287,100.0,-72.05516793055375 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark23(-1.8508192879511733E-13,9.254096439755864E-14,100.0,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark23(-18.672828704484875,-36.193955713293974,-35.45996558228958,18.096977856646987 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark23(1.8711066338237112,5.3122314219251345,-1.7209514803093038,-85.91143827945318 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark23(18.770747509546965,-64.97510239927442,87.85650492871719,83.67764161693378 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark23(-1.89153952411167,0.1611378281952927,99.6203933237908,0.27034849151258517 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark23(-19.169266782855413,-38.33847433408886,49.63890364654632,17.10071953967298 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark23(1.9308032909478783,60.72165890627775,21.4119280695801,-5.675314628660914 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark23(-1.9339916429760027,-3.867417487245341,99.99990122911966,2.7191069070201186 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark23(-1.941946160364063,-3.8796983322862744,23.43113455195997,2.7265309318984876 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark23(-1.9462662818507361,-2.997494757248724,68.20910042690406,67.31476394265586 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark23(19.530503497865226,33.41219696975037,49.75162722969199,-40.67667773041295 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark23(1.9624275332369705,-1.7131472394481022,20.8248815304552,156.37321006603213 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark23(-19.881714199360047,83.66824384486262,14.517605362121117,-87.00920572225736 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark23(1.9901390828388625,5.54580361322307,-1.077769451919491,-58.53795895814882 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark23(-20.012249751996322,-38.45370317719775,0,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark23(2.007929078235575,5.206324109010496,49.76226196890819,-2.6030538807784107 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark23(-20.14160886363416,35.46274719576431,-17.09091240105964,94.68260134998033 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark23(20.16334524946486,-10.86707078812988,-9.193655721293108,100.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark23(20.194443422281807,51.432095638780225,-2.0939733179718587,14.86676510672092 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark23(-2.0226129144219107,-4.013206246025314,1.2988225799031,-184.91815792652105 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark23(-2.0323328738686164,-4.064651689939229,1.0157359615636616,-43.52077699130632 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark23(-2.037017590767647,-4.005301314980284,75.48637421687472,88.5667628980504 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark23(2.0432052758089454,4.417246611928413,-1.807000801301921,75.54579487038318 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark23(20.64097049429576,42.84410901286775,-194.06978777092968,-21.4220528656301 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark23(-2.079935082405512,0.25457032688622017,100.0,100.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark23(-2.142168538147747,0.7916005697968109,92.67682789913161,5.088073570650728 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark23(-2.1595186792283676,1.0797132043704571,0.2943611762167354,-100.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark23(21.685069470413897,44.94018982549237,-11.588043920995378,-22.470094912746184 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark23(2.2128466769057638,-1.3829433824866457,-0.3149822987468653,219.02752443440858 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark23(2.2130834108083057,5.941374483431445,-1.1065417054041529,75.03373093869654 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark23(2.224380740324338,-1.7143959635204096,-92.61861185957356,82.51636014960552 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark23(2.254134530538326,-1.1270935900494803,153.84679515900638,-65.13775425522195 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark23(-2.2676227227944747,-4.509073986775035,58.45239141787818,2.2545023629377487 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark23(-23.083690590403165,70.04228626862451,-92.22701276622756,95.03278743010645 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark23(-23.091270183968422,10.760236928586764,-51.668983361261475,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark23(-2.3161588746003265,1.1580760498416445,-100.0,-1.3644361883182705 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark23(-2.3522639633363376,-4.683109567892271,70.51545351468857,9.406945996454873 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark23(2.3552232054733895,6.281242623799876,77.45189636707877,-2.3552231485024873 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark23(-2.355677162510093,-3.1831550143434706,0.95299176305858,0.806179343774275 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark23(-2.361195203936547,-3.2258328126113396,1.1805976019682736,-14.095051854389794 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark23(-2.3618209104375,-4.706839116549402,50.17612224541698,10.204633722728174 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark23(-2.382134660444261,-3.193472994093625,0,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark23(-23.824400130897132,-46.07800393499937,0,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark23(-2.389428641895576,0.4177679613044861,-21.582962895179776,-0.12423730213517514 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark23(-2.3960534069024217,0.49083762222817484,0.7679206421016158,-23.72248121256456 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark23(24.211740392552755,-42.96262535636761,-82.62278842312125,-31.294372718785496 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark23(2.4383403759039983,-1.2368341484751681,-37.05805483331006,1637.8564290896231 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark23(-24.467991101557455,-48.93598215742389,-16.877513587543373,24.467991078711943 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark23(24.527375025385844,-5.049085634124538,0,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark23(-2.4860038389073265,2.0648362309791612,1.2408659005885145,269.9189469080346 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark23(-2.4887309034545706,0.45896728832983713,8.67778422763329,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark23(25.22443380940898,4.157462902456103,70.61906786588898,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark23(-2.5281178913102855,0.478660782257695,42.87947476578844,64.72570392351933 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark23(-2.5326470199837305,1.263262404357844,80.43302151280761,-0.6316312021789221 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark23(2.5408076172811245,6.642913851135551,-0.4850056452431139,23.382230641067178 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark23(2.5535700906279963,-1.708724831693968,23.24907799919922,0.06818142332452952 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark23(-2.602901132979341,0.5160527960318654,32.717373112134034,-164.63912489812338 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark23(-2.6324421823874076,77.99099393513498,0,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark23(-2.6329234550397214,0.5310786132141324,-100.0,-0.3316229828306953 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark23(-26.39594382329338,-33.89446747950606,9.690252238839008,-81.79929040104285 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark23(2.6537686174725046,6.059460748242538,-1.3268843087362523,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark23(-26.579541493173462,12.50470077934527,12.500355297586674,-6.60434920672927 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark23(-2.6645352591003757E-15,8.881784197001252E-16,-12.189636859905896,0.39969596742046676 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark23(2.675590042035604,6.9072610325811015,-1.8493079634822243,-68.35554678222502 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark23(2.677607679333517,6.118656852037708,-0.553406718679836,-3.059305936464528 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark23(-2.681612491238433,-2.5144589442200336,100.0,59.40490167815122 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark23(-2692.512275920749,81.74332987857227,0,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark23(-2693.7862699654193,95.08688180144222,0,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark23(-2.6944844292369834,0.5866410171230443,17.518915676878514,-27.743899221924664 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark23(-2.701426038792711,-4.140441632743667,1.0966479822433952,78.49928519880439 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark23(-2.709683823850971,-5.418210203160154,200.95185098862385,1.9237069381826286 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark23(-2.7203096258869958E-5,-1.2929210829850493E-6,0.7853855110653766,-0.6784276087843459 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark23(27.285081374055636,-68.25917709443054,50.259582426557046,37.67777893063305 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark23(-2.7724558116706466,0.6008297424378752,100.0,67.08406518404504 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark23(-28.017112254379924,24.018801654351577,-99.06363296053826,-55.76309011597069 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark23(28.141215774649908,-19.071861777927197,-68.90000452690805,0.14076104920519583 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark23(-2.8165011309188177,0.6642376377575846,-6.166066555608702,0.45327909394877103 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark23(2.847371101864134,5.705563953737194,-35.43684455561467,-2.8761230991092406 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark23(2.855111700904088,7.281010834472057,-1.4275659970887111,-3.6405054172360285 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark23(-28.769252286194074,87.44735368797913,16.97157719141937,-18.58175678312672 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark23(-2.91350785946775,1.0421680879717004,2.242152093131323,48.298680365764746 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark23(2.9238984020912446,7.41441254635293,70.87986179793691,80.33075415725465 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark23(-3.02689035932186,0.7280473675333381,23.504591992313134,52.24090598364077 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark23(3.028097065325752,7.560061990451021,-1.8900097348471587,132.66527631542144 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark23(3.029724626989186,7.361013925996361,-1.5145259243712628,100.0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark23(-30.41790031542118,-60.99256223272338,-2.356914649527255,93.04036762133464 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark23(-30.652046678023154,89.59371794072567,45.273231449779274,-25.258475154534835 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark23(-3.066809656381872,-5.961530190913454,69.91034434880046,73.36020750790576 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark23(30.799892686315303,88.70481928283067,-75.18919946128044,-94.71945260663057 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark23(3.0811853814814043,7.630771979838824,-1.5640952740573386,-3.029925775576734 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark23(-3.110003751335825,-6.219922309874889,83.0716350347679,-81.71517927819527 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark23(-31.326884653405273,-26.130298503359356,-84.28788387018417,59.533665029407814 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark23(31.41510666696665,64.11946668092743,-14.922155170085876,-31.28833528007732 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark23(3.1625600842914543,6.544047198695367,-102.81947427619899,-2.9817310856300137 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark23(31.644712535169845,91.99727131794171,-52.343452378080535,-92.6807121762083 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark23(-31.72716574865531,-61.88353517051575,0,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark23(31.848215602446118,23.94567111172907,7.893250636287078,-87.91325611121474 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark23(31.895269229882103,86.87605718511026,0,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark23(-3.206002322950168,-6.357300989885924,7.668758087399206,80.14803330780813 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark23(3.206916542375095,6.413836883924048,113.8532579904042,124.12011090249726 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark23(3.2200595533455565,-2.3943907394999178,-1.570434485211004,92.29882028479184 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark23(-3.2310107495863587,-6.46193916809519,190.32429178826226,19.720304107619082 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark23(-3.265396693085692,0.8473001831453978,5.344279706454448,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark23(32.93094639953108,-71.61978610322224,27.41410290267949,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark23(-32.9346271461003,-61.713605332420585,73.83500792870947,18.564539458089683 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark23(33.88225630591174,46.354747689101714,90.28624604998097,42.84600006863846 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark23(-3.453879297671191,1.7046452316383325,0.9734864743001328,-62.898752359151466 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark23(3.46491365790982,8.467219048131575,-1.73245682895491,-95.33953377427437 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark23(-3.473814625774467,1.5135792276666542,45.183596479663706,75.2745687270519 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark23(-34.97145932011823,-99.4734848601684,-49.30760329833961,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark23(-3.519276666372271,-7.03827455717271,2.205511197913793,-32.60857896891279 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark23(-35.58036963835401,-71.160739276708,0,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark23(-36.25447919507192,77.95506571245804,0,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark23(-3.6505281274789483,-7.047274143411431,100.0,3.5235432496627346 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark23(3.6706989571924247,7.351661921414215,-100.0,-2.885802521046055 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark23(36.94019400517897,55.35761496576788,-25.863439194311994,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark23(-37.226402214827786,17.827802944016447,17.56875655101449,9.427631826053663 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark23(3.7316350706311123,7.786136365072164,45.36761565125841,-3.639822348455307 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark23(3.731708337438046,7.463416718974639,-2.651252331490415,-38.9346780573664 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark23(3.734780978730591,9.040358284256078,-1.8681000276084863,37.05570280181068 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark23(-37.61643705429074,-16.437405593482282,0,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark23(-37.68056420334456,36.27280385749302,1.7903912167401188,-48.244891992428116 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark23(-3.7720951736404826,-5.9735558579982415,2.6714457502176896,-21.374248767762413 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark23(-38.30194415639332,37.29850446280119,-85.90709660940566,-66.22133979185654 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark23(3.861797068241586,99.55175772849003,-95.51780918672831,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark23(3.9170704652201183,6.692028722629753,195.97051654813657,-3.346290244537083 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark23(-39.286804585690824,73.08517020920885,-1.3955246940157195,91.67713294993888 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark23(39.4472987611297,82.48687210054874,-10.538666063664095,-89.61857971885516 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark23(3.9986181942195818,9.56803271523406,-1.7877156584224743,-3.9986181942195813 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark23(-4.026626431978044,1.306835615198097,-5.058691368814222,-0.6534178075990487 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark23(4.059044289095709,-24.603421681280068,57.63924424579517,-77.26265302880097 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark23(-42.34670935854121,-83.12262239028753,0,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark23(-4.239911238071215,1.3459707179745806,190.5984009304156,-0.9608185392523643 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark23(-4.276370619042467,79.78822879951178,0,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark23(-42.83743109435633,-84.10406586191777,0,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark23(-42.84374563339078,-84.11669493998667,0,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark23(-4.287594374759298,-8.174321634575689,45.24928368178303,18.224269562796756 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark23(-4.3071147862791435,9.932449972379615,-60.457325310443544,34.00658632941909 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark23(43.16689430022106,95.21597262380237,-16.52373733297891,6.901379901544999 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark23(43.75712059851921,-64.38062307568345,9.123989441700871,-7.276784908045954 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark23(4.39142091192374,9.291206842589505,-2.981505802184043,26.78512988204895 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark23(-4.4525731483539985,-8.896198991844573,1.4408884107615116,8.373778818079792 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark23(-45.005934277767444,44.627651608831684,-9.425270860955635,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark23(45.060729098495756,90.74807827791332,0,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark23(-4.547451102443939,2.2654546998993568,1.4883273878245213,-47.47252887094182 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark23(-4.5605888359459215,-49.57492001240973,6.682143933930178,-61.41775710167761 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark23(4.576695933480806,10.57397144640507,-2.288118925409115,-96.3931252553286 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark23(-4.58085956948148,1.9847395776229984,25.06607837478477,-0.9921965089750661 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark23(4.581951781485571,10.131094190515604,-1.5055588253602992,39.70216738711921 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark23(-45.96518613853206,22.31752302990362,22.19719490586858,-10.37336335155436 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark23(4.62102866146624,9.242072888778717,12.61239392085519,-3.835641408455893 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark23(-46.587312565152956,-91.60382880351102,0,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark23(-4.664802059682949,-9.329599812471185,-80.10202111519443,-0.04748734930773191 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark23(-46.69988913055831,60.80988095174882,-13.626623521286206,7.615063426135251 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark23(4.679113769265482,-1.124950579836076,-2.339592388424661,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark23(-4.7189361456307015,-9.437786475248934,2.3594680728153508,3.933495074227019 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark23(-47.339131820031064,30.37044730461588,55.08548022028063,8.993627908163631 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark23(47.810780591528356,8.265533403908194,-58.0123368223203,-5.2221160934685145 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark23(4.827869273614091,11.226534874023077,-3.199332800204494,-4.82786927361409 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark23(-4.834298199752597,-9.655945550078181,17.26562278058338,95.93068620116094 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark23(-48.38676989437694,-96.77353978875388,0,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark23(4.863437877561466,-15.91535456639852,-44.59143618893828,70.23452537858037 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark23(-4.9155017872658044,-8.862824570584229,1.6739136215075787,-163.35891493565532 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark23(-4.9389509361794355,-9.841442273988207,2.7822453577542396,36.335689716509854 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark23(4.9415040380289526,11.45380440285279,-2.3807871674166132,-2.585319051244212 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark23(4.951580210863882,11.47395673014797,92.81091150827943,-4.951580201676537 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark23(49.82880035420768,100.0,0,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark23(-4.996003610813204E-16,2.220446049250313E-16,-0.25810353559933297,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark23(50.82280350857354,68.08100133371676,-0.9394888070034568,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark23(-51.03797400133598,26.1248904599249,-32.68226670887793,-68.00523311952665 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark23(51.14747626872015,-25.887422766323386,-24.788339970962625,-100.0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark23(-51.33516945771841,-69.34480607618792,-83.77067816163195,17.138416527316352 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark23(5.143711300158013,10.288617694638601,-3.357156088697871,-50.56590889979966 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark23(-51.525727964399984,10.653329297994958,-61.57386354403349,50.8812039362989 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark23(51.541188452152795,-2.541659029755607,0,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark23(5.1574725610657435,11.881118906673938,-56.676814748412724,84.38039057731419 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark23(-52.01901777014122,-35.18375538882064,3.6980918092642128,-40.44277067153139 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark23(-52.09534447384412,-102.61992343610356,0,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark23(5.217634908932283,10.913961957772157,-49.7026418672148,-96.52909527274738 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark23(-5.22239807366887,1.8484135258267849,100.0,1355.488292704784 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark23(-5.244322772614938,-8.984101170092629,3.407559549704917,3.706652421648866 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark23(-5.265191966101516,-10.382614439778663,3.417994146448206,76.66229988764171 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark23(53.27788389043425,80.31524698279597,-10.424798449874828,85.59967405899872 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark23(-5.331770136540024,-8.278452757728715,4.3271437066818725,3.823428013343255 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark23(5.350586831430382,9.295509475637786,12.61994922872023,-214.29133457727596 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark23(-53.891839395722904,-34.75099730915248,-48.5443857092994,-94.85625366290094 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark23(5.422430551442967,12.143965151959154,-2.3278204132244658,38.80226495863173 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark23(-5.423721131670305,85.88823037861593,73.99308146400924,-24.726562887688644 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark23(-5.437731771921193,10.891333418367395,32.8385811720116,10.42565247161697 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark23(-54.630963153164736,73.36534249509398,0,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark23(-54.85500634447702,26.906833866713086,-1.1445760526722637,96.19350690240756 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark23(-5.551115123125783E-17,-6.938893903907228E-17,0.2546249256748073,3.036004790419689 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark23(55.52944348384926,18.319971725547205,76.13842337912544,78.10795636640287 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark23(5.554049573744281,16.412609043184453,207.70748639555953,75.83153107070471 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark23(-5.567017005699671,2.783508502849836,2.7835085028498354,-5.175764467595313 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark23(5.576188983051933,12.723174286297,100.0,-5.576188979751052 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark23(-5.585084848517273,-11.160662144648395,48.6764148547229,-84.74531048161411 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark23(-56.568919629056104,-35.74618682194128,-79.50540033372931,3.4366086656109758 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark23(-56.74942164292478,36.256941711512866,-61.79225617809585,52.85820509580515 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark23(-5.77438827989504,2.8852160423632096,2.107861477141081,36.258640612663044 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark23(-5.788916180677102,2.1090599269411174,3.6798562537360553,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark23(-5.826559499610092E-15,0.0,99.99999999999991,0.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark23(-58.58665800847758,-4.096299875823036,-34.24336801346364,-29.38351684065846 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark23(5.874059029868039,13.17755722954035,-2.835151391450363,-66.25880144592206 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark23(-5.906386491005833E-13,-1.9695356456850277E-13,0.7853981633977436,-1322.7554020246114 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark23(-59.13491704117333,4.331797920165442,-96.85786971781903,-78.24058252015041 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark23(-61.1999055336159,-70.5017174400391,-51.320016456206254,76.43398381916793 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark23(61.26622975830631,-52.65059546364566,-91.4676459472333,69.44919492597145 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark23(-6.133233830748185,-12.266465446927832,86.95830865751927,6.133232723463916 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark23(-6.1505153799598995,2.290411030871232,39.98793546700522,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark23(-6.1507333377554465,-12.343797576524004,4.432061781909747E-12,7.072088923376937 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark23(61.65806107707283,47.51580944673154,1.0189961267020493,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark23(-6.242061619817851,-11.766755521890953,2.331714553325803,5.883375159130362 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark23(-6.285547165534178,2.9875012305578994,25.910064719402925,29.283228506120185 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark23(63.512550415503256,35.76354212888509,17.459302626794766,90.50340649878558 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark23(-6.388630804024752,-12.772637437898707,2.4089257358788974,-80.79293354444022 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark23(6.433507949029811,-3.216753974514906,-2.368800150246228,1.288553178154979 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark23(6.43782650209733,14.446145956427635,0.016700239407370532,-7.223072978213818 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark23(6.454719813146507,12.909439626293016,0,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark23(6.462958461338218,38.9251772039151,0,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark23(-6.5029796180824215,3.221753741144191,4.416428911924061,54.21224889442439 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark23(6.6771228956095445,14.759922861266412,-4.1066908549838566,-98.47618391007344 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark23(-6.677755979568893,-13.355511959137782,2.553479826386998,-32.59201776343924 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark23(6.764280034449287,15.0993563948826,100.0,-8.335076360838748 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark23(6.814151286318804,-4.192473806556849,13.05029627308948,100.0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark23(6.854834728362622,15.255850572203219,178.0735596619114,23.009304213887347 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark23(-6.880794268809268,-13.488671075512222,61.02441317753098,7.52973370115356 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark23(69.2532755062472,-57.26203064733482,65.84180520604613,-35.53592687195544 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark23(-69.37483578367896,-16.322212278873465,46.205234693496834,87.9418579654673 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark23(6.947073747278505,15.464943821351897,100.0,-7.732471910675948 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark23(70.16930744630488,62.66806022737012,-25.1989307504265,-32.28033341218162 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark23(70.59764605221636,10.816105028272219,0,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark23(7.136124842900855,14.272708521810854,3.582778575072684,-7.068711321229025 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark23(-71.58957415863966,-39.896766705612976,0,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark23(72.74272034647916,-42.96517825514812,-35.783564567073725,-70.66333316686183 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark23(-72.83465141801568,-11.954714708337775,88.43314215847053,75.31680530059904 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark23(-7.305907919577317E-4,2.6906783244456644E-5,-79.28532763368176,-4.628723546924034 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark23(-73.79472658043514,14.56062603115042,85.55275636290321,81.60022203693856 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark23(-7.475068677819829,-14.741279697168169,100.0,1.8842259887519703 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark23(-7.522431960561358,-15.040024687757711,80.54070238649886,7.5199671483185115 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark23(75.33795140967229,85.63296424973908,58.243962108399415,-22.112056606379554 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark23(-7.643915681898531,-15.28783050138685,8.485126473719628,7.643915250693425 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark23(-77.54314612198816,94.05639424477667,-45.21609072413688,-47.947761765804955 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark23(78.95840000062384,52.54035784023765,-36.99330801128673,84.97518691013661 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark23(-7.967761348974305,3.7003418336861365,54.889252898311064,406.4316301218852 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark23(8.078254859780756,7.585296921172031,12.46689844649292,-41.70154434328801 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark23(80.8723464008965,6.854016765574599,14.910946879567149,69.64704494269125 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark23(-8.214678151430778,3.995775876578771,3.318597608867001,88.346201095351 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark23(-83.11844047963955,-11.968095096809009,82.11818372472769,2.126368024985183 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark23(-84.36963586155615,69.33088090918281,-78.55738336452826,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark23(87.44058899991211,5.639366751625616,77.75626814315834,-48.736160149832955 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark23(-88.61872450964307,-81.32481813894134,-30.776435542500764,-75.70143763999933 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark23(-88.98095377172477,-18.058957783979793,16.175583373212234,-32.576107254145995 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark23(-90.50528771101696,-60.121827463805275,66.8847591903673,-7.374260487728407 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark23(91.17307873203205,75.63452896366238,35.84035236881178,-88.21533031325862 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark23(-9.173088929268697,4.293523167581756,3.8011463012369,100.0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark23(92.27087571874756,-51.12582229982161,21.56777053599788,-78.68101865173549 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark23(-92.78240801355373,-22.434522977670284,0,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark23(-92.96295193926922,5.191138889224561,13.392262612030308,-57.32993644451232 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark23(-93.53481423430094,-32.9332583817484,20.644402629953788,22.476169759281575 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark23(-9.382790856006098,-18.76185938947592,4.691395428003049,25.10451334070978 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark23(-9.419055282015032,-18.73392099680006,69.89756290781435,-35.400748900671644 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark23(-9.461166812793383,7.418943580535376,4.723202816563766,-6.9540648286982325 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark23(9.699336757196086,-5.4094275124209625,39.23325737058903,2.710864302302852 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark23(-97.3568178217219,77.72317865344846,-85.75422120358587,-27.023442975102512 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark23(9.919542237855499,21.409880802505892,0.8437387098087927,-9.919542237855497 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark23(99.4473712195034,14.518139155614307,31.37954395609742,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark23(99.91800095723727,-97.7050892295066,6.132540993087645,54.79280053134232 ) ;
  }
}
