import org.junit.Test;

public class Sample68Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-1.0089256641272932 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-10.957532676483666 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-1.5 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-1.5076247280779285 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-19.177934500214462 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,26.131114731872344 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-2630.743230225337 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-2736.9559352775027 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,43.45803974864438 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-5.649476447338458 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-56.623524799476876 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-62.38110182032901 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-72.89106868375583 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-74.14253714011043 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,74.61299803447292 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-85.51170857850477 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,9.568184159695093 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,0,0,-96.00485709281075 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark68(0,0,0,76.39117431312725,-76.90463749870484,-1.5 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark68(0.06297844421016441,-31.32289623141375,11.213383147353504,24.992187466217455,-40.493861797745126,-1.5 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark68(0.06775878726438123,-60.26658643319104,-30.09988185444307,26.092261763481392,-75.54849430703824,-1.5 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark68(0.19843955690961113,-47.12504700100169,-47.614536055119224,40.14267664198269,-78.83307721122799,-1.5 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark68(0.2047923965111096,-54.93171435766494,17.939193092506937,24.08296049781294,-24.266957103775905,-1.5 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark68(0.25130310010936574,-20.92516133850207,-100.0,-17.618071443115433,-69.58163209477998,-1.5 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark68(0.3496193898061296,-31.339753547295764,-16.407517556917917,72.7588344202949,-42.767688587470786,-1.5 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark68(-0.5624048233722938,67.61258880130482,-115.30084885846102,100.0,-98.0374702412701,-1.5 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark68(10.000803664059543,-36.563798415919194,-1.4643553784836865,21.76074637348231,-40.496543374889285,-1.5 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,100.0,100.0,-1.5 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,-100.0,-1.5000000000000036 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,100.0,-18.441335192750685,-1.4999999999999982 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,-23.902810468140515,-1.5 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,52.935866592848654,-1.5 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,100.0,-56.44339161621778,-1.5 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,89.16594857177964,-1.5 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-100.0,-90.14259615932112,-1.5 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,16.43384670394611,-73.23225258062918,-1.5 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,30.619466747123756,100.0,-1.5 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,39.35691458797742,-100.0,-1.5 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,49.87797065239292,4.810793912385343,-1.5 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,60.0487590688791,-100.0,-1.5 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-100.0,-67.66809527708014,7.066445708912916,-1.5 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,100.0,86.00213579993314,-100.0,-1.5 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-33.94478024137061,-100.0,10.907010552911636,-1.5 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-48.28895355060777,-100.0,46.833468436754025,-1.5 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,59.289864558259495,3.327216723842265,-3.5111846688199932,-1.5 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,-5.945352133491539,100.0,78.76361228676646,-1.5000000000000009 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-100.0,88.53996089304486,-69.8198888223774,80.78299544271944,-1.5 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-11.688076148298894,-51.20173772683504,13.570083947715753,16.522784919375116,-1.5 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-13.358451001315949,-70.78137300414119,-100.0,64.52012020264567,-1.5 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-16.44609229670253,-59.48509428924471,-100.0,-69.34270351439555,-1.5 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-20.10665646065246,100.0,100.0,100.0,-1.5 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-30.07609457498839,-62.17077248918443,100.0,15.963974550687269,-1.5 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-32.99690665101811,86.08736540633586,-45.11853357700468,34.7732794435006,-1.5 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-34.50641597972762,100.0,20.552227109012435,-52.328640321191976,-1.5 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-36.65965577990514,100.0,100.0,85.2943670886674,-1.5 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-38.58408916905319,-28.940862694419415,-100.0,-4.121620048035361,-1.5 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-38.72765431611544,-77.13692603196006,85.08883897795461,36.701915326721945,-1.4999999999999991 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-40.37088487709164,38.09282990470447,43.846348497209334,-100.0,-1.4999999999999991 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-44.7697823230544,30.801074519096126,24.23015384112472,-20.827234908903492,-1.5 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-49.38186789285693,-76.04038411496036,100.0,-95.75733237565736,-1.5 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-53.541402465256084,-4.83184400397108,-100.0,-40.8073913214436,-1.5 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-61.19464639015095,-56.720517617673686,-100.0,-42.854016294330876,-1.5 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-65.8011109727042,-100.0,-78.40192118125266,-100.0,-1.5 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-72.25579998956376,19.92770262681813,-18.04788456355247,1.9044994989117328,-1.5 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-74.36929483010961,100.0,-29.24752643954431,62.21053567343828,-1.5 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-75.37845638440174,-74.96231144148271,-100.0,-74.11530968330779,-1.5 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-77.48249585930205,-100.0,-100.0,-30.590244170141794,-1.5 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-79.39548779787214,-14.628197474813943,76.45692082726333,-51.7989767320614,-1.5 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark68(100.0,-90.49732553395899,100.0,-52.92709961084071,8.53327703604463,-1.5 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark68(10.374604229840607,-10.240121079827603,-19.8194230541092,-7.645867147167408,-53.68964377218056,-1.5 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark68(104.13631102598748,-38.03195621116722,-3.5037778066123977,8.225348945803304,-4.306003678049528,-1.4999999999999991 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark68(10.586591396903316,-86.39242499939056,-49.29927208992041,-111.37688784794047,-19.068411587358423,-1.5 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark68(10.642682258837084,-80.34521508927264,15.004916307742313,75.4884488593531,-48.42619447865235,-1.5 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark68(10.690452999158044,-21.471907965395147,17.8002335986337,37.45219898945667,-79.8293431010171,-1.5 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark68(10.70673950451252,-59.53016921658667,16.624558035207013,-19.590786110492733,-0.12193731611284697,-1.5 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark68(10.815083636754999,-61.24393217185306,27.65314208509797,38.387889018037896,-71.2626687515009,-1.4999999999999998 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark68(11.020400536251994,-95.83533266957083,-24.028687963096466,40.84556273347066,-15.193314668349764,-1.5 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark68(1.11330927772606,-74.79792720748421,7.651414330606187,-100.0,-11.685424871364546,-1.5 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark68(11.218432055667861,-74.01855895457794,100.0,-97.03997628384784,-35.51155521806243,-1.5 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark68(11.32082191260153,-71.76398327443898,-13.000669025860713,-52.40556012803911,-40.434095002302755,-1.5 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark68(11.35588128319949,-67.32662911452228,-94.3234292116527,-83.89148775841163,-93.06326717628313,-1.5 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark68(-11.473194543051195,77.94185801530068,41.49811322520682,32.69289221422122,-32.692892214221224,-1.5 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark68(11.504463449919768,-8.27631082160882,-35.862546579302574,-77.97549933139729,-60.09178268647011,-1.5 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark68(11.50667802004837,-57.56188817468454,90.79560241903732,-11.274905807237936,11.255322920402122,-1.5 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark68(11.517231241968346,-70.13690068540417,-8.038120764896249,-66.9198580856732,-28.928658450200203,-1.5 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark68(11.542368415907823,-18.203932057290707,-34.51751284263848,-25.442222990040342,3.5990921908910174,-1.5 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark68(117.0264866161715,-8.99930896209898,-19.688179411761702,50.85197273978707,-33.2519357412329,-1.5 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark68(11.811898682623573,-9.495775191832927,-58.720430974868655,36.37762993071648,-99.06305976779606,-1.5 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark68(120.60581147202171,-38.38339404803513,-87.5669877461394,-100.0,57.888091556739475,-1.5 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark68(12.176285394562903,-78.92028140546974,23.321045101751462,-44.326683234779665,-10.447094592639392,-1.4999999999999998 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark68(-12.371758329991085,61.484042076327356,21.812708633368008,66.32716845858828,15.252635813456578,-1.5 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark68(12.378582895983673,-8.00530092600583,28.933447484151237,-48.87055576405193,-82.22699384119531,-1.4999999999999998 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark68(12.711500565678298,-28.586774947823486,-5.102870120637187,39.50439550556555,-12.478207065484828,-1.5 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark68(13.02480872294482,-100.0,-38.01246631016113,-58.3972188800493,12.66832792146677,-1.5 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark68(13.08553227270676,-38.158557333336645,33.80595394495187,49.131080702825415,-11.281762206446444,-1.5 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark68(13.126368161392381,-9.870870088371932,-35.45210919604294,-30.73743743619165,-76.50348452608121,-1.5 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark68(13.310696984680323,-53.47933245780093,35.540318434333464,-70.28759109316509,-9.255136037901257,-1.5 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark68(13.377862453422578,-32.455914893912365,-11.544145057678858,-79.83402478034488,-23.166005225092412,-1.5 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark68(13.540260849993164,-54.227325150414195,-1.858550104906314,-61.659178677751356,-79.74516318733927,-1.5 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark68(14.031002179162197,-20.662856121644474,97.31862229305696,-60.33511788540646,-97.3938030424217,-1.5 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark68(141.14397763607275,-24.39466579303905,-100.0,67.5544959119545,100.0,-1.5000000000000009 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark68(14.317594723096601,-17.698371087986665,48.76473029123382,37.0804840326861,-62.83515223675802,-1.5 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark68(14.614140056826173,-88.19538369278682,5.904283771055816,9.520905184379377,-73.25635089878213,-1.5 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark68(1.485568868048571,-77.67653826328586,-58.51135045703119,55.017697502652986,-75.30028826587746,-1.5 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark68(14.866263604365297,-65.21108021188346,-88.10312108570636,-69.78119253683555,-41.6866961024487,-1.5 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark68(14.946538458016086,-2.8644898246269053,40.59160249102376,-78.16889772648526,-28.00950261789215,-1.5 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark68(15.101147698399235,2.3763644578689498E-212,-100.0,-100.0,-73.18751856869658,-1.5 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark68(15.175740460754554,-23.28820821760044,88.58514108264458,100.0,-74.73725469814295,-1.5000000000000009 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark68(153.5599526826253,-80.56775483495029,-100.0,-100.0,7.025049691857937,-1.4999999999999996 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark68(15.387546257048012,-57.04387547262474,22.133769593621704,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark68(15.436144898895776,-72.93251876579119,14.941340636880467,-30.894480299060245,-58.27330838203522,-1.5 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark68(15.521738941945358,-99.66695040613578,-39.80791504421533,36.495946711712065,-80.32471629516225,-1.5 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark68(15.534122113479278,-19.21023583422404,21.91694573110568,76.54337160955183,-93.72029659028372,-1.5 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark68(15.537105976825316,-14.33966980082971,-88.52429806841546,50.7255717028281,-50.5033727124888,-1.5 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark68(15.664830667485695,-10.80806269329127,51.99763480238537,-96.44637135556398,-35.221059048762825,-1.5000000000000002 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark68(15.87468695428656,-88.35699969700153,32.64684686524248,27.248680676947743,-48.48942209985697,-1.5 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark68(16.00319706578685,-52.460480389960985,54.21389443915854,-93.5249106948062,12.700352963160725,-1.5 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark68(16.02276389901119,-46.93255172882713,-40.223644141776646,96.57931794317366,-4.989888057607946,-1.5 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark68(16.58806692765421,-34.77363588995091,-14.654168843828284,-12.291433090906821,6.461103944527251,-1.5000000000000009 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark68(16.6019553111162,-9.730343186448465,17.468228257411994,-16.43635375350782,-69.93744887370084,-1.5 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark68(1.6622962087192574,-12.839123153614484,22.947491162365694,-55.1737483174514,-75.6965444108441,-1.5 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark68(16.77783665072981,-71.94623165838723,10.142460801344669,41.590912951102524,-79.48403844767537,-1.5 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark68(16.998937282174044,-65.13047288943575,-100.0,13.056696690999892,-65.00166584227253,-1.5 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark68(17.00137696004623,-26.6151062555173,-21.090619530512697,-25.711657350741376,-62.4791396897234,-1.5 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark68(17.07949333537798,-51.42413713093547,-41.22102563714245,-32.10612715367577,-49.963138275384146,-1.5 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark68(17.458034990269937,-9.59407746150653,67.67645160958742,77.55641647254251,-27.608911619764996,-1.5 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark68(17.59764902838468,-35.110345814369225,71.11206050524237,25.43840776975863,-17.450561206045872,-1.5 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark68(17.868706286491324,-15.88682970029749,-59.88531822286405,9.709807573983019,-24.912422331429067,-1.5 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark68(1.7874728481455628,-100.0,-5.981192814104908,-100.0,-92.84649460449153,-1.5 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark68(-17.948813721025466,-40.77286170829948,-99.97301098406412,23.96087164774096,-23.960871647740955,-1.5 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark68(17.968531586245312,-2.961768222949531,19.15852458278979,-92.3220799165748,-38.82381500005832,-1.5 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark68(18.113354971783416,-17.67688859401361,-79.33022548490868,-37.722698154713115,-63.29303937379156,-1.5 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark68(18.31690255590311,-82.32303513756291,67.40500246932133,-41.93383106373152,12.727079406766562,-1.5 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark68(18.427925036906146,-17.106471878107776,100.0,13.475556503189445,-68.19628919065153,-1.5 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark68(18.720062948927662,-18.39959096134762,-30.13679127126748,81.24520750248611,-66.97755651209306,-1.5 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark68(19.101275697679938,-106.81132953222136,18.14356384705128,-71.94530949016334,-37.37092439180267,-1.5 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark68(19.29079766590582,-90.98848092814788,-82.68188783176291,-42.291532817500794,6.8812547807756514,-1.5 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark68(19.33057356500163,-54.95887900618071,60.70341614213923,35.86324751576397,-72.83933908866614,-1.5 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark68(19.409943316607404,-3.0419949797419354,8.530835830785291,12.46463625908763,-33.41165964697243,-1.5 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark68(19.524685223588392,-90.92666714164878,-9.63722477043589,-90.41885639833177,14.46680454244747,-1.5 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark68(19.819056900950073,-11.256920540969631,-50.3020001261403,83.62758939569807,-17.335624040854185,-1.5 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark68(19.83398728942933,-2.9214380444339696,8.468070758014747,84.84541827608777,-42.23506413734346,-1.5 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark68(19.888645077945537,-36.17237894198535,52.419148194610074,1.0038614332270726,-55.08196354048974,-1.5 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark68(19.890015385210198,-27.41386810808041,-51.15554188019162,-16.21431749613714,-74.38836152638008,-1.5 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark68(199.27627124560962,-71.90560639372859,-100.0,-47.239824817013215,100.0,-1.5 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark68(19.9463512574784,-44.03220218808612,-47.53345539962007,47.847908333630436,-81.69648915157579,-1.4999999999999996 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark68(20.098834165942534,-93.35428011457347,85.9338425389794,-29.27292313572329,-37.82247212254204,-1.5 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark68(20.14164743468072,-16.514399493237036,35.690828383020744,64.87572396946976,-72.83189104353916,-1.5 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark68(20.248645618120946,-42.248454570428116,-78.5569061253937,-49.99467041661636,-13.330412872320977,-1.5 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark68(20.370190417834507,-85.20355398984687,-11.59756279250499,62.44982897755409,-53.29566665345777,-1.5 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark68(20.442005410494772,-97.48263399683825,88.01592464265741,-94.53463900789427,14.089040830886418,-1.5 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark68(20.592600696141126,-35.96094418352414,-100.0,-83.85988402910401,-100.0,-1.5 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark68(20.749165039635344,-6.18369550014387,-6.932640817929286,62.55103448452063,-10.378427098058772,-1.4999999999999996 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark68(20.825020786390077,-23.821601253325802,57.96157234858801,-60.34648336693553,4.763921070211667,-1.5 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark68(20.84087769983712,-70.6217704729002,35.905064828197744,-71.42081845944779,-44.47651997315607,-1.5 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark68(20.937848081936437,-22.539204599720378,-56.45434765984669,78.27029468610723,-100.0,-1.5 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark68(20.98097237987337,-56.49237515572904,67.46837862026133,-56.640827121897345,-36.20058651515911,-1.5 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark68(2.0985982388474325,-40.358242767585665,-10.952255672533767,55.845306626828545,-55.49752466261478,-1.5 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark68(21.262842017684555,-49.486415015333485,100.0,26.599361467765682,-5.35086476294232,-1.5 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark68(22.080140422178562,-25.23805404632191,40.93745421742341,29.349134962773363,2.1238487580742706,-1.5 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark68(-22.104213994218398,41.82348856039911,-11.129002500003523,96.86853752139777,-95.83678844590075,-1.5 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark68(22.119502732745275,-36.49010636263754,-85.2015654966352,-80.73517067332072,-53.96638989270066,-1.5 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark68(22.158466036549743,-54.61187844219455,-47.936104392626774,-46.82074098592979,-33.36348001312177,-1.5 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark68(22.16111590935256,-69.83437751195373,-66.36422884303197,47.08404651077614,-67.15014330045156,-1.5 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark68(22.2115767504649,-79.44843356300495,95.52775776513434,83.52627733774099,-11.350833468411082,-1.5 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark68(22.223067762814047,-86.83541043749311,31.743396756013812,-31.35014923169809,5.34473557680093,-1.5 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark68(22.451867708333864,-4.066403154134413,31.844098025930574,-0.05872117798479204,-49.813889550020534,-1.5 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark68(22.52258887628307,-54.87341390521164,54.72184975128563,-102.67962100319062,-25.419698068549437,-1.5 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark68(22.782544700763648,-18.759676084428914,57.074264499227795,2.4540322226793734,-28.45676511457723,-1.5 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark68(22.830604004054603,-63.296562983379616,-59.0998161060249,47.657272430800404,-82.31477657004646,-1.5 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark68(22.853008862052867,-9.702774008722873,63.02325966245644,43.36263396781249,-85.17804915887251,-1.5 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark68(22.992208634573004,-39.921167390039855,73.99716807787833,56.52142274428752,0.5415004280437969,-1.5 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark68(23.05088091055987,-6.774497011742863,44.34212181233849,-32.45818910179479,-13.144867866268891,-1.5 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark68(23.20806655148699,-100.0,93.1115578079618,11.202670915969742,-100.0,-1.5 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark68(23.26550360818924,-14.406875958843955,-0.3317198873628495,46.20581619722333,-26.80420320842273,-1.4999999999999991 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark68(23.43503715225561,-62.53017641287025,-0.17873736347018365,-34.27167548636517,-29.976100917568097,-1.5 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark68(23.568497163998202,-52.396898234087466,-23.51333358028196,-26.533686235172055,-72.64338606668139,-1.5 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark68(23.702854587888027,-37.32531911958457,-62.033718285596066,59.22967485081947,-11.397987014474882,-1.5 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark68(2.373240643714465,-91.70087822349643,-52.935920908607685,67.87120602270035,-71.26897576611081,-1.5 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark68(24.07356177031391,-69.02963135173832,-3.61979265870427,43.43487937976325,-50.142903186336056,-1.5 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark68(24.39006639742596,-69.92806739950767,-19.24914593602962,-55.066743091581486,-21.993915086785364,-1.5 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark68(24.50524103920874,-51.44234576265717,-47.96365356255399,8.455808153127146,-83.12306334164779,-1.5 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark68(24.545078975396915,-92.05278181421964,-47.49823196928922,77.00752742159548,-89.97521738810946,-1.4999999999999998 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark68(24.570775351596907,-70.16902195890232,-72.97774427014978,3.0320720357247097,17.4747515618827,-1.5 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark68(24.64440878586922,-16.466912148825458,100.0,-100.0,-43.14753902609257,-1.5 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark68(24.658443083592587,-20.82611422428662,2.83870046641818,33.38051972591321,-81.18751189925322,-1.5 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark68(24.80266769511207,-39.99635136937071,-19.09538941972657,-38.85891615367406,9.866872627754098,-1.5 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark68(24.818306008901956,-16.14106177609339,-59.88226976895145,16.09550301897526,-67.93498349051049,-1.5 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark68(24.963129434728216,-69.05582902000883,-76.89447849504121,-8.521382813039224,7.32741761475536,-1.5 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark68(25.640279730666286,-29.334654135120825,-100.0,100.0,-74.3580168040876,-1.5 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark68(25.695774638994088,-86.99049854297051,-91.07026300869715,-23.407420542203425,21.472486742983147,-1.5 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark68(25.70119552486141,-25.521952825711736,21.418402177099196,-55.48762983506454,4.897798286871662,-1.5000000000000002 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark68(25.723765294759914,-29.841735908283226,-100.0,-52.59894626532002,-13.698867670871834,-1.5 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark68(25.73968950284811,-41.36559688577155,57.995174613586876,-33.68028771476919,-83.52354413688617,-1.5 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark68(25.885645206613212,-49.00335881253852,80.49971734469631,-13.092894518570612,-28.899116228015274,-1.5 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark68(26.02316921150361,-82.78146922740733,42.2621732155112,100.0,18.63208028536286,-1.5 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark68(26.15894037379856,-31.834096164117483,-7.025407124905316,-49.78091601951419,0.25985393358087805,-1.5 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark68(26.25202169749332,-14.75979254428917,71.12696079929884,76.45997124594444,9.568443872404117,-1.5 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark68(26.355205387404503,-16.035215641445788,81.89594177785635,-57.921039362784036,-91.46494404527093,-1.5 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark68(26.461878793199503,-68.47475668139602,-86.81677489755833,95.90760617319839,-44.44365110450842,-1.5 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark68(26.515456146111116,-74.33850312395751,-17.240203214486726,-80.8147414464803,9.080681454623816,-1.5 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark68(26.60641606202625,-100.0,11.44212715488168,-95.1902333649347,-100.0,-1.5 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark68(26.624155966861675,-15.639020586651739,-76.54115822022007,70.49208063226364,-28.159059396009848,-1.5 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark68(26.683036384683803,-83.86874632876585,-30.78433368577263,-43.69250185296521,-77.1052685482316,-1.5000000000000004 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark68(2.6742511039749672,-75.83538361653552,-34.882486977832635,100.0,-11.812210408309504,-1.5 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark68(27.47224863976324,-69.0292091451455,11.711940234063732,6.829651762536901,-77.56346315125161,-1.5 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark68(27.685347373917143,-81.38713453213377,14.661306587934645,83.15717941927261,-37.991720602979015,-1.5 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark68(27.844620201397618,-22.193646387860525,-30.970264025373325,-17.816231856367096,-54.86175593209046,-1.5 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark68(27.9335503227949,-36.58981758249067,35.46795559161214,-58.643831660760306,-7.376827379526588,-1.5 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark68(27.95129318888253,-12.23609401592637,63.192559693019064,-19.417493624212817,-28.072017867021295,-1.5 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark68(-2.802353157142221,32.44406502213333,-75.51128775580108,60.15798994184307,-58.011573629183985,-1.5 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark68(28.084570318012496,-47.198413397304186,12.315673834559618,-17.77217699190099,-61.88017927844464,-1.5 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark68(28.15738730545988,-100.0,67.39661238391079,65.62552105955825,26.913731730955426,-1.5 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark68(28.486758543275368,-16.570482316550912,50.443350454437365,-21.034850133835704,-70.04714369149528,-1.5 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark68(28.963173205573273,-18.093874537416383,-43.936784890497776,86.41350134326274,-38.66719160095899,-1.5 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark68(29.04420606134748,-100.0,100.0,100.0,28.105420471476023,-1.5 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark68(29.279898780472372,-85.99425928680061,47.835798864963124,-2.3165720233170504,-0.7033629192250075,-1.5 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark68(29.43130492775384,-60.33885880916928,-47.14335577194499,66.31438886832032,1.952800260832948,-1.4999999999999996 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark68(29.439453627651993,-38.35122945082873,-3.945144399341771,-25.90420199971132,-52.719850698166404,-1.5 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark68(29.501984220024017,-78.24673045539487,42.711724540501585,15.85742805350607,-21.229044215392786,-1.5 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark68(30.080075947565618,-95.32642970459085,68.3630868640927,-20.382699716781143,-78.01963588583908,-1.5 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark68(30.19265150582926,-14.787984853847691,-36.76421154117727,3.577927942795487,-13.807729024676918,-1.5 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark68(30.52525184414211,-56.12784247451286,-28.922740946995056,92.23696802776487,-28.374889817568345,-1.5 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark68(30.785935532411095,-71.19718177388644,47.69806908585489,21.81320872469586,-81.9785850637646,-1.5 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark68(-30.922529022039893,-45.81219568739208,40.9317551627882,69.1600023854268,66.10460714154279,-1.5 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark68(31.06973998770519,-77.36663442726262,62.23207591387818,-44.5429598106468,-14.371859570662748,-1.5 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark68(31.236237224662347,-89.23894001960812,34.54106334386884,-12.406153820339537,-14.006798993402072,-1.5 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark68(31.336120254790846,-21.036512324842157,100.0,-41.89512471152722,-24.726369957250196,-1.5 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark68(31.572617172417768,-21.07063163981842,-17.019108116633507,30.157453270580202,-57.81705895758074,-1.5 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark68(31.61772301991858,-35.63915941429099,-3.336633571433648,-59.308923621921096,-11.412916916135991,-1.5 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark68(31.895943750716484,-21.59890112327014,-64.05702696215455,81.07187528530054,-43.67034198318302,-1.5 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark68(3.207134607273291,-47.49520057884221,-1.2139916709702518,23.506097799533492,-75.15212865845558,-1.5 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark68(32.223965913783026,-20.023385542956483,-29.32721707521611,48.87751292216287,-66.27716647664762,-1.5 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark68(32.246645930781995,-3.168245326258102,65.811258198015,14.069252561433657,-32.23764708466402,-1.5 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark68(32.25147219180991,-50.79504355862372,-58.771571592696084,-57.61501891713136,-59.31492932053058,-1.5 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark68(32.32595390445522,-64.80692048801096,80.46061716957476,-28.442909150972152,-35.09867783762704,-1.5 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark68(32.66140594975417,-53.06717081445977,35.43860953784617,-39.83556170267099,-17.69902743786939,-1.4999999999999996 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark68(32.68702670454767,-69.35235262092475,-17.465754927428883,100.0,-76.28140550094123,-1.5 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark68(32.94875487095037,-46.73323702994379,-16.227777765772416,-13.42239275875238,-85.80595120185878,-1.5 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark68(33.04983424490508,-74.05143407161029,-70.76959661335763,11.766186592942983,-29.176104999713697,-1.5 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark68(33.086250175930616,-30.45471117061103,66.49126413079618,-47.91111700290513,-68.68820861583055,-1.5 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark68(33.28040152688954,-19.238432280446276,-36.22602635629326,14.626423963010847,-52.51994587867214,-1.5 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark68(33.44006679759194,-1.6301596431244778,70.75601736143214,-91.78673533162345,2.408779343936766,-1.5 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark68(3.3761197328874966,-22.59511555378858,-26.582258727719907,20.16256176597132,-47.76499537318867,-1.5 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark68(33.86224620895496,-16.249860981710356,-44.5701400754039,-93.88523793411522,-82.74696636990609,-1.5000000000000004 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark68(34.0278191329604,-18.561662737570863,53.289375329659606,76.72579190419415,-57.28571334309214,-1.5 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark68(34.08142605390674,-43.41698483256333,-11.283991447620544,21.039138966146897,-48.72804741728241,-1.5 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark68(34.15686718908077,-11.369066969675671,9.163854731305172,80.51657151396434,-58.47075175008004,-1.5 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark68(34.523870018517044,-21.38689581542704,-7.7503676150330705,-80.98035149996612,-58.38228933640606,-1.5 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark68(3.4572532043912925,-25.03319876221456,-12.952052301203068,-72.94402498851926,-83.04095781856513,-1.5 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark68(34.57615932440693,-64.19942771579764,30.891348150632574,-58.985369335565885,-5.486461105919929,-1.5 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark68(34.806101970431484,-49.35746509184871,-61.89448644844684,72.95380242343111,18.121117929079105,-1.5 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark68(34.82355729735548,-5.260681860436343,100.0,100.0,-76.52594670837962,-1.5 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark68(34.95279175434241,-73.54458090934556,-80.03579043215912,55.23418820753149,30.060383796237797,-1.5 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark68(35.1048615682083,-57.08304834266274,-53.755619085502424,-48.224305671316614,-58.73014601665809,-1.5 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark68(35.149888324872684,-58.10060655510435,-98.37675428009089,-34.8579745944374,-55.81178137125923,-1.5 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark68(35.48631283313286,-45.9401810282613,31.771433014529077,-56.496422064902326,1.5217736142507974,-1.5 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark68(35.52704014437072,-21.335664718293927,-38.61772838239689,-52.03486425242933,-12.482511034152314,-1.5 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark68(35.63963834152649,-13.483972551278555,106.9673165670354,-52.40371231167207,-78.56503447067313,-1.5 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark68(35.8281780260873,-60.28708988186604,-52.90714937226624,82.8076470530061,-36.2660811080256,-1.5 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark68(35.99585135551641,-63.781185648877454,-14.7426658844362,-43.285553752151316,-85.67371716854512,-1.5 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark68(36.09626607406947,-3.0288666251776153,78.11861143502564,5.693789115359972,32.60807676090718,-1.5 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark68(36.13951786429238,-43.04286099425373,10.84316833268359,48.04567680169767,-14.01466090226814,-1.5 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark68(36.29843076515474,-15.807135706738599,-40.80666426716833,-56.00495260981006,11.727151068517887,-1.5 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark68(36.63332716324456,-13.557774165420582,13.811300717462188,2.6901085377640754,-28.07124722004113,-1.5 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark68(36.840134807922546,-29.160662774821276,-49.675432825248954,-55.20101811379379,10.931779557006287,-1.5 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark68(37.102113543617705,-24.556063925748965,-2.233726449042173,-27.87863026753733,-41.19115310703967,-1.4999999999999996 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark68(37.24553337819812,-8.979741137255814,24.527963499826672,5.164685644084301,-38.85129207663508,-1.5 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark68(37.394075613006265,-23.316148071363173,-73.31755978323511,-42.26007135224238,12.056075257447088,-1.5 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark68(37.51193065139063,-18.640504894896416,-39.904694454478474,29.21605815329639,-18.71123108474328,-1.5 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark68(37.788593574486185,-34.538806913244755,-31.7278440669905,-0.4177541427437266,12.032647842716894,-1.5 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark68(37.83565709648773,-13.939941577106847,-31.642069684156617,-18.056536693012767,16.78135838527708,-1.5 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark68(37.9052288243206,-1.8314030518641786,48.11499936696647,33.20179905106758,-22.53908597024861,-1.5 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark68(37.92952245721938,-29.769769041593833,7.4177774554616605,53.414065618682656,-75.10382795073767,-1.5 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark68(38.26051269096583,-59.71847647896056,-52.865726176910115,-74.24575686778634,-91.06685557193455,-1.5 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark68(38.28452609471536,-5.095469045673788,-6.494331086682436,-1.2150941240213322,-42.354432403032426,-1.5 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark68(38.29634080086751,-52.64835620065512,51.78918703886313,46.098065752511005,-16.072071037813174,-1.5 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark68(38.39004444371807,-78.49046248178871,-66.69114773407577,9.227504516513166,-68.63575648572501,-1.5 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark68(3.8480529461071944,-32.467808010857794,-34.0067280792837,95.13548680589362,-19.187044520663683,-1.5 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark68(38.5909141330437,-99.28468313899386,133.16153368603128,-77.02144423074756,-80.5588553989619,-1.5000000000000018 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark68(38.74750395538999,-52.05429364735399,-27.984536067310213,-55.337593289821356,-99.96284948977627,-1.5 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark68(38.829941040401856,-57.65803149010807,29.93990405557681,-18.07168272693096,-57.8152851929915,-1.5 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark68(38.933536003335945,-29.75251459169526,-93.16506431074816,-34.694865639820776,22.56997064635351,-1.5 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark68(39.09923013020092,-0.023905185904420923,7.585911171077892,-13.145344536341502,-47.637410769877675,-1.5 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark68(39.13129696981879,-35.19941192475299,-78.94432525105444,26.56996904386692,-1.5072803603645064,-1.5000000000000004 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark68(39.1806941771209,-100.0,-100.0,-100.0,-31.955504799994706,-1.5 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark68(39.19930055823942,-74.79006202193793,146.31763920301364,-51.52328480073102,-65.3670621588727,-1.5 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark68(39.39151602534029,-69.98192289525076,-19.507842071996954,40.85460170806908,-51.90600047826816,-1.5 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark68(39.607308544209985,-93.45562721748888,49.707618878101826,-36.96466536355696,23.247891903845183,-1.5 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark68(39.64261549180468,-41.177275062942144,60.854486087943755,17.113540405198428,-81.85083613792384,-1.5 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark68(3.982736406678723,-39.156895282623445,14.545227104958443,37.90359015162853,-88.42270387701289,-1.5 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark68(40.03446416947534,-51.01249003536494,29.47363473099621,-10.829226580624375,-18.96978909469194,-1.5 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark68(40.135933235556244,-52.95626835747154,-100.0,-49.77658517479929,5.44954711656858,-1.5 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark68(40.14973507064012,-47.32639066823942,24.01134674580895,-49.839499857405684,-7.475170243243639,-1.5 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark68(40.18961622678698,-23.143235303825424,15.33795469335213,-17.813355256058003,-62.438214238608566,-1.5 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark68(40.322966910469646,-7.478370959654571,-12.736222003737405,24.446414619128575,-79.76877031955253,-1.5 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark68(40.41040593054623,-71.38503866632409,27.071246909855894,-38.44540781687474,-83.30519955252282,-1.5 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark68(40.57247497772281,-10.79085628317124,-95.56262692789666,82.4074837337977,-93.44807933458462,-1.5 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark68(4.100389609612248E-8,-8.352389719038111E-53,69.13395773062206,34.241539264670855,-35.35875139546993,-1.5 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark68(41.04784734776038,-37.02756012883023,-89.4477244677939,-45.20614359461683,-63.26527298443724,-1.5 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark68(41.06518984574223,-67.25840584230636,-8.479642843240192,-7.609315124761578,19.23406037964988,-1.5 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark68(41.23231102176116,-23.628410894879327,8.882672369592132,-63.50909078873528,34.92647512663366,-1.4999999999999998 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark68(41.367349240959015,-34.35161338256779,-45.469908524693835,-12.807805441792866,-4.062882554452731,-1.5 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark68(41.39786758739808,-62.70880605457596,-76.08321049230986,75.3385999472047,-11.372081680597873,-1.5 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark68(41.67356803627774,-27.99721323102962,89.48389768940075,46.59744672264458,-12.476190623327454,-1.5 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark68(41.75513435104306,-48.40503158653735,-7.637497584739998,-82.29374867706022,37.23536494629365,-1.5 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark68(41.78757009869203,-100.0,-68.08831876953536,61.318231140358826,-87.41343816561456,-1.5 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark68(41.83068068317493,-42.7193403643086,-17.4835090381985,-20.930632523020137,-46.25071517409896,-1.5 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark68(42.03436285886057,-17.212361101186215,100.0,69.65901272152605,-82.13449496073947,-1.5 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark68(42.08076276561273,-97.93469098867332,37.44982242044195,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark68(4.218908131434609,-31.21930693016644,-67.3763231928584,91.02891763135872,-85.70415339179982,-1.4999999999999998 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark68(4.2243654207407175,-36.6249299958771,31.704599149362494,21.3998932402431,-65.08779746972886,-1.5 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark68(4.228267190434238,-29.674794886538706,7.1081760551856945,43.77573407952536,0.7412460462398229,-1.5 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark68(42.58849123406054,-5.947240306021624,-24.358373716915835,31.800741364427296,-37.192841109079424,-1.5 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark68(4.263256414560601E-14,-79.14416931301218,100.0,100.0,-4.305174908833961,-1.5 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark68(42.77154864209842,-24.044085476310443,-30.724068658113115,-9.911573375209995,-29.640932679101315,-1.5 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark68(42.927781087821515,-39.430258582984486,100.0,100.0,-94.13046001147451,-1.4999999999999982 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark68(43.074179181765956,-85.28293083907825,-21.027230701729433,77.11581558929038,36.489241447575424,-1.5 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark68(43.357193159180724,-51.120418064756706,3.740882034943759,-44.72800367906696,-37.57767678347951,-1.5 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark68(43.40025933766078,-13.256841587791062,75.84172914882869,50.48678334143034,-56.12290467850721,-1.5 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark68(43.406578261490985,-13.686635953842565,-53.519024059333596,-83.48251922773329,3.677667855548974,-1.5 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark68(43.42249350895706,-43.82535694322643,2.892092413709533,60.08432673446772,-45.302437994029326,-1.5 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark68(43.49382833841361,81.54466486476977,-50.94115122698844,-56.88809698255677,-70.0155533674332,-71.16636041675324 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark68(43.50843589695745,-40.595263611639936,-73.70103140543593,-94.16532562619335,28.76338840898829,-1.4999999999999991 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark68(43.53831664421441,-72.15439826692884,-35.66394386897221,-9.343533102020873,-92.67317652681422,-1.4999999999999996 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark68(44.13383244467235,-59.94095607267749,3.537473604379045,-24.104973942995315,-9.913977070368603,-1.5 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark68(44.200762992021815,-17.738825115341594,37.804475279146345,-65.67108332960419,-2.790186213399334,-1.5 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark68(44.367179684000405,-66.0734689498139,-74.12523547899707,79.40646918716473,-24.19011277780399,-1.5 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark68(44.39088089084607,-31.96563656669089,-28.13459412933256,3.5416991342209965,-8.346470687109719,-1.5 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark68(44.56043085077363,-40.094535909831144,35.48587686121738,-97.52158023686184,-71.09161921160245,-1.5 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark68(44.60899937320296,-15.251443173887562,-100.0,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark68(45.04878504532018,-100.0,33.688656705583114,29.22018012458942,-36.756715667719035,-1.5 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark68(45.10153609576544,-30.20874965614253,43.43945211738714,28.946913006586513,-73.76101064290668,-1.5 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark68(45.21282884605897,-7.608774537736043,71.8079577106054,23.790739222547575,-4.395180461765513,-1.5 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark68(45.22162444198587,-22.977800052258726,91.22617051931314,97.89374900494184,38.62350038782612,-1.5 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark68(4.533120115640996,-38.103433462154996,-30.215269198766077,-47.65628032324318,-39.263070838554555,-1.5 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark68(45.348405506757786,-26.40505095749259,-10.706162640037519,22.290288199500623,-90.37290499258896,-1.5 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark68(45.59144635463302,-6.528742451954165,100.0,-5.1798896500099065,-44.538814236718956,-1.5 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark68(45.736665231983864,-32.085799664736896,-26.886162754748042,-53.489603437417,-31.12547992274817,-1.5 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark68(45.78655385251669,-63.777459839076144,-7.69102818168767,-87.62585899343965,-22.446215882122562,-1.5 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark68(4.580862993033387,-100.0,100.0,-100.0,-100.0,-1.5 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark68(45.91518190951736,-60.076477178994146,-4.27393278302059,33.29358406153096,40.2118741535277,-1.5 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark68(-46.05258229640827,-63.256917605528834,-36.48509342841881,59.623969648021394,37.24842546471223,-1.5 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark68(46.22453758927472,-56.43614041655653,-74.32395589575032,94.21913631900341,-42.87527667051911,-1.5 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark68(46.34226218359456,-24.135786450482286,44.30599019860345,-93.7856822175277,38.9796472013692,-1.5 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark68(46.39434606851297,-92.40565425907874,-97.49653827800074,23.093793777111355,-84.44977484421452,-1.5 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark68(46.462533169658144,-65.91489230078653,63.72718299942955,-3.4967567342383727,-39.28556239509774,-1.5 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark68(4.654598819029559,-99.35795603730145,75.52228568249396,47.5868068286907,-27.40668010736296,-1.5 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark68(46.69597388079322,-32.50754415217768,29.532861382306127,67.86596151206555,-66.75210037361578,-1.5 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark68(46.705194714427876,-41.00953046412492,-29.487938139277418,-51.95876291423291,-9.42993712963262,-1.5 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark68(46.76453656691936,-70.17693049635267,-24.010331997071546,7.743993570711751,-35.932735438964905,-1.5 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark68(46.92796261318745,-18.038079652831783,-78.32926347451658,-33.32773644654962,1.8582634232534758,-1.5 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark68(47.38155237231234,-97.40519338097306,59.75374279196538,43.71758167035273,30.449434540668562,-1.5 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark68(47.69035579384733,-93.9468433637286,23.70679254137169,-45.09690183381902,-39.041319555665325,-1.5 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark68(47.89913636198268,-77.08603404049042,-74.78134604428249,-39.01295990410201,24.131699144370447,-1.5 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark68(47.89936915858033,-18.594789392413375,96.24389027852013,-100.0,-87.23488045065588,-1.5 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark68(48.07879447436726,-93.47509794227626,9.846118792711973,78.23956987181079,-58.26716578036862,-1.5 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark68(48.19996105290136,-85.41469432795212,70.79392838586637,1.286052782956105,-78.33308682760776,-1.5 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark68(48.35621060033759,-62.16645353604652,-12.667792987868822,-5.929276987447638,-37.61566460223129,-1.5 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark68(48.40887854342421,-38.78665234327692,-30.82893244063255,36.5800371494179,8.542860516749997,-1.5 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark68(48.47606258391431,-38.46811453431892,-52.49113723603755,-47.04470083154864,-58.32289450155339,-1.5 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark68(48.576831014199996,-78.78596094331148,-41.719763167888146,25.286042605972114,2.138379933948115,-1.5 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark68(48.8773972693366,-54.41819702492854,-55.24126234634758,80.4104492870276,38.77853518605855,-1.5 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark68(49.28589455315754,-86.28169706969496,8.025712140695493,-23.536092832776653,-25.39082957744221,-1.5 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark68(49.32552250553884,-54.48392611622342,26.058242537294568,-47.20060108534095,-23.33617502624947,-1.5 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark68(49.368785488187186,-52.31078169762329,-75.61576648084952,44.28136340577586,5.042221892191643,-1.5 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark68(49.3824577881452,-90.2805581161533,52.02956981187289,-14.559311664867625,4.661645306056109,-1.5 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark68(49.540506116110095,-35.88379187655748,26.703267283449776,-19.62106944449897,-78.57451082313302,-1.5 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark68(50.14620151181291,-83.82203733465373,73.21490304884261,30.970401954889333,9.76277663585582,-1.5 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark68(5.021798438127547,-64.69998198623315,67.60740596083767,37.787855243925534,-33.7900319136821,-1.5 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark68(50.24334643031803,-22.440130722889947,26.761007315964328,-50.34614155026747,-58.938298240443075,-1.5 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark68(50.323512156072006,-57.808044190796835,-0.4736816790435796,21.33684915547815,-54.61908109566212,-1.5 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark68(50.64099626297717,-52.20974209643287,-68.80532094014954,-70.91451458878308,-16.41808512649651,-1.5 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark68(51.250782790745575,-53.90187018294747,45.63730245075836,28.446167300934377,-18.077681204077578,-1.5 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark68(51.29324714058077,-8.859631840416569,-28.096858938311595,-23.68294376381138,-17.93294693824386,-1.5 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark68(51.46035439527472,-100.0,14.978123389006555,52.78534941503062,22.419072136345108,-1.5 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark68(51.55926979500427,-26.336773263007597,-23.533364832024066,-70.77521523384749,3.2528819526026647,-1.5 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark68(51.76517758982956,-84.66755731028366,-13.864363964816706,10.161991143263933,-33.383470804829855,-1.5 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark68(51.82116385747187,-24.130004280102227,-4.649346365296342,54.27186865322665,-41.568392449482644,-1.5 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark68(52.02038175107644,-8.780627366729167,16.55923551151913,-70.32086257663174,-34.68823465081712,-1.5 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark68(5.220328315126676,-26.1773225465778,80.72601136648971,-35.18467978434666,-38.89990964825192,-1.5 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark68(52.44989218553607,-7.570980521300498,-65.4716715417911,-72.7404629820957,-43.35185894952007,-1.4999999999999996 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark68(52.72175175374781,-28.665162468523995,17.211383838703366,36.51247728169628,-0.15958487252589748,-1.5 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark68(52.7306410684489,-30.79009999029112,-62.68019733395233,18.431226218700875,-26.11286690521443,-1.5 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark68(52.86988399592772,-100.0,-8.325487121251223,54.880634454950155,-54.88063445495015,-1.5 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark68(52.98424104864125,-91.0218469509608,-55.169904865563225,64.04020817648166,-45.997555139983376,-1.5 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark68(53.83880496808583,-25.367658115683565,29.473171911625904,78.28334995070892,29.541308266945233,-1.5 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark68(53.90554503840877,-11.989370976065945,73.27871917793345,36.73710540901999,-24.118257742575093,-1.5 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark68(54.15188615599405,-48.383234932362576,72.98265644919988,-71.67009080422847,-62.77930857938448,-1.5 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark68(-5.421010862427522E-20,-14.1657368446613,93.10540577239786,-39.68123700932249,-99.99728360985092,-1.5 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark68(54.425400273912295,-34.962728491547075,22.05609085293446,83.84991075453304,2.294049595489277,-1.4999999999999982 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark68(54.45476622243399,-89.40541144883073,-24.87360186892241,-100.0,-100.0,-1.4999999999999996 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark68(54.65429798465655,-65.03423168645935,15.813503966026968,-79.60272623935822,1.879945368307915,-1.5 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark68(54.820221714095595,-59.98609402808051,41.32130459171478,-63.8198320485019,-29.645736010540986,-1.5 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark68(54.87754448677021,-6.912791952556023,-14.525577944466741,-44.68678359721597,-79.04352018252014,-1.5 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark68(55.02047002590296,-42.09274810431719,-6.332393823622632,88.883929557626,-21.10060374824762,-1.5 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark68(55.33098443529697,-48.471123269156,61.69050871166803,-32.480675361294786,15.525651327681922,-1.5 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark68(55.404201387467026,-83.87270446616274,-65.32415913952603,-29.484254482079784,33.59685697002583,-1.5 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark68(55.444483752173426,-64.21711290155164,17.340411172062275,15.001258400251341,-28.906596226826125,-1.5 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark68(55.44595139832909,-46.51039160409064,47.26695316418725,-65.51064260510483,-36.063638133151926,-1.5 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark68(55.73039483946896,-38.76329945724624,-81.19819066201029,43.84113320275798,-2.2706796812284162,-1.5 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark68(55.83820794316881,-47.866994324556075,83.98186553049453,62.92695039727178,7.096496986457652,-1.5 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark68(56.04984660095424,-64.94230848496142,-66.23654518310524,-70.63095502788309,20.046898190654147,-1.5 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark68(56.125007338765506,-59.66582449616296,-17.501954951918208,-9.147633967967856,-52.545270989961985,-1.5 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark68(56.16073354232978,-29.151928314105277,36.040227667828574,55.289119976043445,-39.48562756659845,-1.5 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark68(5.616083864156664,-36.515659883450965,-44.16109184991781,73.86278611502269,-11.036742078114333,-1.5 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark68(56.20497177942233,-23.156168242519357,-0.5440590307656024,32.88061290900981,-44.45881931929929,-1.5 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark68(56.339647986740566,-70.33313666425703,16.638316013144028,-7.11935718854874,-7.920459878397729,-1.5000000000000009 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark68(56.49333692883698,-89.59406787125332,79.8074184553709,66.99546771736607,-37.73580290437628,-1.5 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark68(-56.52860246664644,19.3516960574116,-58.429618155153875,67.00919992131128,-66.49187918513164,-1.5 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark68(56.55721697080904,-6.909604345260259,93.79909394186895,-91.00656649160923,-35.692001268879054,-1.5 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark68(56.59219013295001,-7.941775827809153,-35.20224662084803,94.55586261540608,-31.16036193261253,-1.5 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark68(5.660777846228843,-75.06587871300974,-20.745175733789434,4.306701821520062,-25.852841415109747,-1.5 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark68(56.93616851606643,-73.41721681399913,-61.51783073782418,-27.90540860652851,-13.541879137645225,-1.5 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark68(56.95264777145826,-23.35512785518668,5.403907598757899,91.59774056683018,-61.29330697617333,-1.5 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark68(56.96087423102463,-20.423077393001883,100.0,58.297241360731896,-100.0,-1.5 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark68(57.08455211304266,-45.80390712495601,85.69369942134938,53.138900607858574,-82.02274465601604,-1.5 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark68(5.718483030384974,-81.52952595688146,44.05987589426098,73.72190249397056,-62.120574824343436,-1.5 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark68(57.33195383699271,-1.170585376560723,71.29842393246125,-25.071923140396876,56.98605935579823,-1.5 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark68(57.33649791142375,-64.80813084892989,-72.75161174151947,-0.4281880206221018,-36.23789579910051,-1.5 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark68(57.821514436691004,-59.11430922282082,25.315045016664882,29.228511732837827,26.345028243680332,-1.5 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark68(57.853288223212736,-53.68284207576818,49.258020678093764,78.48006042858509,-89.2329169693587,-1.5 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark68(57.86639371980663,-38.120790142399386,12.358517736800403,97.10224598598599,-98.90452636657432,-1.5 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark68(57.94859577737671,-40.599243569064825,-43.111326085999835,100.0,-12.7167228820635,-1.5 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark68(58.29176971829154,-55.845701815305205,21.706580656735742,-45.51589310326665,-36.945512925572515,-1.5 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark68(58.33795584079265,-27.52513225383404,9.202141711376788,-47.43842725251566,5.967343524811913,-1.5000000000000018 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark68(5.858016889949441,-92.26916575878965,20.753770899385092,-82.55247040835756,-64.37475321660281,-1.5 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark68(58.598628101573865,-46.29400764890739,-39.145428456761366,-46.8914655082983,-72.00161584387902,-1.5 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark68(58.84176380292746,-14.177723295729274,72.62905468562649,-8.397712089171499,-34.717893353855466,-1.5 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark68(58.868265633401535,-30.20893483263599,84.41412793998387,68.57280118989453,-32.060819759930254,-1.5 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark68(58.91610413260877,-1.3480455756618177,51.92119232767907,-61.990929168269865,-71.50305295815133,-1.5 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark68(58.9831731493025,-81.03824132604545,-98.6871978035958,-0.24793786035354826,-96.78117533969542,-1.5 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark68(58.99911230963373,-27.72792799269654,12.910293329199476,-21.68144957477464,0.4039102473488221,-1.5 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark68(59.12398012004118,-25.90459880123626,26.52969077987021,-33.61175056070826,-57.37782331464801,-1.5 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark68(59.13082560230194,-40.77888992581823,-100.0,-72.05256306550119,-36.01313778949047,-1.5 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark68(59.18490516769442,-32.41744613579923,2.1204669220454577,-52.19377923125634,-17.29067189766687,-1.5 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark68(59.29852374221074,-9.347047371896156,61.18225971154511,-75.2542492088239,-37.58519982637856,-1.5 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark68(59.726191405655186,-1.5715704046497052,74.06699427201008,-44.035718459888805,17.1795683436917,-1.5 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark68(59.801491870930995,-24.581594801481295,37.68118385802152,58.5763075894114,-41.70643911943038,-1.5 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark68(60.027062198651585,-63.80529739505695,7.312202713664973,63.76689068764205,-4.291200898077925,-1.5 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark68(60.462085617054356,-38.49178993955347,-5.316629417088123,64.54598583676346,-46.10269638845676,-1.5 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark68(60.70923105414992,-41.71308712857221,-38.87095301534307,76.75740277682787,-15.083529667765355,-1.5 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark68(60.750047053750436,-45.38537408569117,-24.512907970744944,18.690126789995816,-37.671112192694494,-1.5 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark68(60.92894425825636,-42.31204929281709,-37.88284313539137,-4.42113944182781,-16.49949989162226,-1.5 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark68(61.506646670967285,-58.95409724551322,-12.394475218984624,-82.91508115970441,45.60777559381188,-1.5 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark68(61.51576779817993,-9.978479753347663,80.19173617054264,75.9371641981513,-62.80891396411941,-1.5 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark68(61.7044624437213,-85.43339357441182,-45.84977334903586,78.70505770648458,40.26864812957527,-1.5 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark68(61.75654742199177,-77.84747932085297,-60.172233099147036,-98.6853805673079,-100.0,-1.5 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark68(61.961324296064646,-5.647688180205719,54.23697943992346,62.71447399760643,-61.193343043481654,-1.5 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark68(62.027735137007014,-39.41288651897214,-2.6795450523212967,77.53758053939887,19.2882622547341,-1.5 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark68(62.205575790488446,-29.60816289008659,-10.149624773785073,24.07564943336989,-28.99578961824426,-1.5 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark68(62.265853379441744,-30.407061303176334,-33.28018224568349,-3.776880291228263,-34.35099023909024,-1.5 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark68(62.57173732908209,-46.812699844230956,36.74627169612593,2.421207804126709,-76.03137706831187,-1.5 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark68(62.66934710525217,-18.383721011685765,-14.634721414473418,42.09625193954338,-28.08133987003238,-1.5 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark68(62.86532202073477,-67.65211889652292,-34.2311853855487,-34.562013935672425,-45.19357386443751,-1.5 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark68(62.95843843542423,-71.13254736259054,53.64373633218992,25.255262765317866,27.625455757051213,-1.5000000000000004 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark68(63.03732629927791,-95.53559253955079,-6.072070320005977,-1.7243447269401582,-50.534479985601266,-1.5 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark68(63.205848903350514,-40.89038892746027,-7.190009384721571,51.85734066779991,-90.76766274261536,-1.5 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark68(63.277479839505666,-35.48234298245138,-52.115887738796765,100.0,20.75752023119356,-1.5 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark68(63.371337840975464,-59.16116497563408,-15.802329201331922,39.55748851186735,-57.42495546801514,-1.5 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark68(63.689495815940816,-100.0,100.0,-54.172154403378954,-28.82577360638129,-1.5 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark68(63.76760160570793,-100.0,100.0,-15.873805936088797,-100.0,-1.5 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark68(64.25075512771924,-6.448801515962597,56.30554954646561,57.05859833871074,37.114277963153555,-1.5 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark68(64.30397835803404,-4.150143579373697,100.0,-7.4911874905274285,-61.1869450098391,-1.5 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark68(6.440922366751453,-54.443702204595624,-71.90517437282256,-52.04702463618251,-38.33575066273738,-1.5 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark68(64.5340145418545,-31.12528532787164,59.5265265317513,-37.790501293036385,-2.532872021750273,-1.5 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark68(64.68759025034298,-54.22324637593288,-8.614881200231412,-91.59795272588417,-14.524185892266669,-1.5 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark68(64.70841864157855,-7.506708273765749,41.432659035058506,-90.51648229519452,43.482609255962274,-1.5 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark68(64.76073249722832,-57.0151572109169,39.30208919868276,-16.14019107994526,-33.57726243738277,-1.5 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark68(64.82888125433693,-30.037219363198236,-10.562451785402493,80.42588607114808,-72.86904794683262,-1.5 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark68(64.94792975629159,-15.400813149274569,81.98243247762994,48.61773335036398,-13.437255873023247,-1.5 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark68(65.0249519196446,-45.941763735788335,21.35026180103724,58.17227448419236,56.6048186778616,-1.5 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark68(65.10071624251486,-89.09898632013396,49.04407940580947,81.13177808189477,-36.339659655249704,-1.5 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark68(65.446082046946,-9.023794404445027,84.9498893520259,44.64569505772559,-10.38319422357381,-1.5 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark68(65.56045448590537,-49.71516448525732,-37.811788334506645,-71.19039374667852,-36.42342872269557,-1.5 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark68(66.00588416187736,-94.74199723643659,-37.53220183596478,42.246416186401916,-1.7533046777605534,-1.5 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark68(66.01884718507799,-59.54049497386876,41.32940634931521,-60.7549114519899,-68.92490747218223,-1.5 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark68(66.05167388740128,-48.37237553803274,73.43554563096443,80.32624548832294,-30.781559655214444,-1.5 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark68(-6.607663795844546,0.3573281367857106,-93.39082352803374,51.761783793551416,-47.86308581584338,-1.5 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark68(66.09188944132035,-15.470278879056792,43.990057318834744,54.494484497474105,-86.8633060024796,-1.5 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark68(66.27490330686172,-18.218787276645898,-51.664498987751784,13.917851803165803,19.870567353238528,-1.4999999999999996 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark68(66.29725244402849,-51.29516685491484,19.827738761916432,20.936134696936975,3.6892642267226283,-1.5 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark68(66.29836773186977,-85.18471334578942,-57.923323686618865,19.56182926453741,51.797680604896335,-1.5 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark68(66.40586069016281,-100.0,-100.0,-43.92555010275051,-56.02238331930701,-1.5 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark68(66.90318498943276,-46.145975764794976,-27.840826713644034,54.76776949501456,-80.78697171679947,-1.4999999999999996 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark68(67.16878614978737,-84.66176741293624,-27.137806501494396,30.921769074945303,2.8814266464231917,-1.5 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark68(67.23934111748048,-50.655857296125895,-47.722604113794276,15.489320323346377,65.30027490465997,-1.5 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark68(67.44311446351509,-82.09836637361579,43.49970047923762,-12.527321979517026,-54.851052349416584,-1.5 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark68(67.56668160316616,-79.7096894641764,2.619100548261134,81.35058445341757,59.862157692547264,-1.5 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark68(67.65047309631933,-23.314578713787284,-84.19781406113975,54.033775883895714,-29.048848978662136,-1.5 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark68(67.66589579852014,-55.93656596978432,-28.485274048274718,36.58958061281002,41.029183996954636,-1.5 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark68(-6.768905402075049,84.52382146119015,-72.61484422259332,13.55745488263834,-13.55745488263831,-1.5 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark68(67.73844382086642,-40.680973850329366,-17.147640940702217,10.080957690995799,-3.1443707126444025,-1.5 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark68(67.83372694591473,-9.238809039616513,16.436659559771208,53.903846807788156,43.59556648077586,-1.5 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark68(68.10092275455908,-55.04694701445084,-26.42780410800822,80.90586368148789,-26.68439936351237,-1.5 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark68(68.59441467534754,-33.610675512323596,-45.35173405478802,72.35601533802135,-65.20485226894769,-1.5 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark68(68.72231841224492,-33.15283676633379,87.17771963666212,31.88478388115653,-56.75639388490913,-1.5 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark68(68.84437493821603,-56.16490627085122,44.842316093317734,-71.05684571315886,26.64749720131717,-1.5 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark68(69.02063527632322,-98.4366603134325,10.204544364758732,-32.117267033704806,-26.315010726946284,-1.5 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark68(69.07513522753344,-77.62703575071015,-45.47148639289471,-36.74764270475128,-37.42165361962985,-1.5 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark68(69.15514505067472,-100.0,100.0,-64.14006384387416,66.28809790207552,-1.5 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark68(69.22299508976472,-34.640692709066194,50.64600544582621,-50.768123343943145,2.2260178878431294,-1.4999999999999982 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark68(69.3761939369181,-40.046670211016135,-76.14610502731132,-14.46570151444135,-76.02738227174275,-1.5 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark68(69.42072586064806,-60.32516956833444,-7.702522137295304,61.10480665391702,21.87594401641319,-1.5 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark68(69.44658971630906,-21.628608699318526,-63.49742017301119,-72.88871970409565,-81.06280323094943,-1.5 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark68(69.70915950877881,-20.460216783049255,-43.36714520698862,58.75146258392916,-66.50466449409075,-1.5 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark68(69.7228176382896,-23.440538235640886,-76.8028713974412,32.28099454329342,-41.12982395897619,-1.5 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark68(69.83870409307163,-17.084317547321177,48.91405214086562,-27.844640963407457,-0.6303491073242142,-1.5 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark68(69.87622861483786,-16.633818002439924,81.04539922468851,-29.775623789284353,45.95166756964855,-1.5 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark68(69.94143905246143,-16.45206883402724,-9.760146242493608,61.12938967144272,-31.654016626575533,-1.5 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark68(70.34476939841704,-61.74925435682219,-2.8142516019507013,9.954503232910938,-4.72505055314609,-1.5 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark68(70.3892403820851,-30.717403000148003,17.57860190528389,2.585149440779473,-10.982700272641575,-1.5 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark68(7.06698823088081,-57.13221154056454,-63.341957458943995,-71.96446435015271,-87.50252766597623,-1.5 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark68(70.84842709693446,-59.53140772932473,89.17763607197467,32.51485717295358,-10.384410911848125,-1.5 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark68(71.09701030586822,-100.0,100.0,-98.29617408788823,-86.50424940405762,-1.5 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark68(71.25559062380182,-36.6316423569469,-85.22081246483079,67.06332474141998,-85.92338022385717,-1.5 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark68(71.40628060807802,-56.10283851215237,-18.594816829954112,79.2075589424779,-19.543958671248603,-1.5 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark68(71.43827943459242,-85.62640334262116,-95.27004825781265,75.66544917716749,65.93830266130475,-1.5 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark68(71.65263719688619,-67.07850839927991,72.61842823961902,-21.768523792379042,-71.05328700201,-1.5 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark68(71.68845953328706,-49.77171740105845,24.012360449924845,-86.93916993623661,-8.951463754979184,-1.5 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark68(71.6929242079847,-82.15864021054908,-78.94366429348585,-41.87972748332778,-79.04022761927743,-1.5 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark68(71.90306337168668,-42.73320782872889,-24.690416426162127,-75.56954525497925,50.358323073029595,-1.5 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark68(72.04702393258182,-0.5827746781874749,45.364894412960595,-35.103839644175764,40.245996703943,-1.4999999999999996 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark68(72.21056119759228,-81.51895255246168,66.25496187439049,-44.2411655701707,-13.280263138976355,-1.5 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark68(72.21268307139525,-67.58626481193716,100.0,20.894038408979267,-17.679484609661202,-1.5 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark68(72.2169314128042,-88.95030011627804,23.64173666530658,13.331008836808849,13.440930721748472,-1.5 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark68(72.31544421541292,-9.468669734601434,14.013088653939505,34.95999524303167,21.529043162810297,-1.5 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark68(72.38779310072701,-92.726749361598,-50.78834158605421,-43.61261787495783,45.974226733505674,-1.5 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark68(72.71800808359458,-21.826344748252094,67.89619633913156,12.711440743904408,-37.37298286098344,-1.5 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark68(72.95396143080826,-72.71227910498563,15.854703493692721,-8.066653872298073,-60.931752203386594,-1.5 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark68(73.50096576242342,-54.48453296255469,-98.12516728281867,50.280203755199636,-68.16194900688843,-1.4999999999999991 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark68(73.64694523750045,-27.428125156667857,7.971770256780754,2.60989450712332,64.91886956881692,-1.5 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark68(73.77248503428572,-90.12491638941836,20.1948428117215,-5.036919114863409,54.1478129878881,-1.5 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark68(73.88479240296331,-86.28963782232987,-9.90343894905878,-48.72257879028584,11.574374671197313,-1.5 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark68(73.98206493088995,-65.37640204553287,-17.667532649870196,-2.1398733860319936,50.477123633862305,-1.5 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark68(74.34788964399706,-17.214431641320303,-77.27763451326047,-17.522758731870084,-38.9427491843948,-1.5 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark68(74.57796486773726,-74.52199727127561,55.06797323759005,57.933277174664596,33.03061726434394,-1.5 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark68(7.472489356192597,-54.39537166042353,49.259564422004274,26.489805720626293,-35.94164834924733,-1.5 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark68(74.74789819935762,-86.31341721657547,25.665354651445146,-100.0,1.7103817789052038,-1.5 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark68(75.09810340113573,-97.0229583017511,-58.87668629752126,-3.8136737794154105,-93.93567770562105,-1.5 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark68(75.2999525217092,-57.43702638531871,23.25480716065742,-8.592944940097876,22.61066665456427,-1.5 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark68(75.43431034094642,13.586580364465135,27.088209950466016,85.15981916572963,-36.48159114910175,-1.5 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark68(75.7343575344575,-100.0,100.0,7.407067928215556,61.443833001898085,-1.5 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark68(75.74165298809963,-50.06778623823259,-24.477258287315674,72.31700517725452,-18.52263099709242,-1.5 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark68(7.575584454532471,-38.559785677924985,-66.85262475251677,-82.5914613002905,-51.42648547342867,-1.5 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark68(75.80144036439268,-27.860735603539133,-49.66033177203656,15.258518491996071,-34.004840188260445,-1.5 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark68(75.84156781603511,-61.36343335837085,-100.0,100.0,59.84716964665917,-1.5 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark68(76.16179500359547,-100.0,-100.0,-100.0,-100.0,-1.4999999999999998 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark68(76.46156650718214,-39.31318275126592,42.13387900326816,36.99346504220475,-59.54983685976201,-1.5 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark68(7.646419513188874,-25.928532648548355,71.11913152510112,64.02624701845176,-78.94157690123706,-1.5 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark68(76.57171290414854,-18.551929321870073,3.626057778778735,-59.0790715529981,-64.77460420054115,-1.5 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark68(76.74029204055412,-63.8927364280711,-64.41877753044899,-81.97656857335093,13.257759742689267,-1.5 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark68(76.77631401644881,-25.01730774932056,94.96101664772068,-93.15829170371563,-63.432146649351424,-1.5 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark68(77.07227847921334,-9.587088977215288,74.92743862842158,-57.24618063554429,13.883143852767947,-1.5 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark68(7.719616190850111,-50.967815851572766,-9.879971503564938,45.6518308759115,-62.85131815731356,-1.5 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark68(77.28299832415651,-87.32130245569466,-71.61281380817678,-18.91449598397384,-37.78841001073499,-1.5 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark68(77.53255626414663,-100.0,-100.0,-10.539383361554059,39.22486571769141,-1.5 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark68(77.67894963493897,-88.91174535359434,-75.60365199887227,-29.218391197309106,-86.0126333076899,-1.5 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark68(77.75073986252116,-50.493304748967674,-13.36831700797238,80.67307708363535,-99.86008008005507,-1.5 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark68(77.79277935715291,-3.9403079616059387,9.381798231638939,25.91811122971184,-41.520108421900595,-1.5 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark68(77.8104058630945,-72.80079389743537,100.0,-29.43760447999054,-42.23422703507398,-1.5 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark68(77.84162203699097,-22.32207249550087,11.58478413671849,-63.384865166862184,-37.8124298470794,-1.5 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark68(77.87821651791543,-6.7408864091282705,54.67615600587317,-40.746632139945184,54.08606255886916,-1.5 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark68(78.05799324628721,-38.96186809425539,-64.2431106557422,30.147492861494527,34.03563179573044,-1.5 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark68(78.50517133237761,-34.04717480824047,63.039736849655725,22.283645621125842,22.9541431611257,-1.5 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark68(78.51031515516264,-39.031144085383644,-25.69134848792268,-42.66141003305962,72.22793890540017,-1.5 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark68(78.75119349437495,-39.94989241024494,34.115693762007574,44.62790935295984,1.938552807484136,-1.5 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark68(79.10241297424643,-79.48782125366513,29.27441131025855,53.91446064201713,52.89764688962088,-1.5 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark68(7.917691559596771,-12.36942162463644,10.899982083793821,-62.26258924541135,7.204394317184277,-1.5 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark68(79.20398002612475,-2.017176018081757,39.57108282984652,-52.85210716134836,7.023390729413119,-1.5 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark68(79.26835503558644,-79.4109206838547,70.14533843452043,17.265053553917745,21.8976694217028,-1.5 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark68(79.30912305207615,-94.13190220144479,-56.91324029188625,82.3832133407467,29.654070031838803,-1.5 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark68(79.36286686054409,-22.937067785755666,35.13500535243561,29.655817153954906,-45.13602474175951,-1.5 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark68(79.38356628919175,-48.32399104949837,73.10357512226516,91.45223220130529,-79.84620653532131,-1.5 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark68(79.59216793237039,-78.30336219712933,-62.52738908837521,27.24079581033079,5.719771730435243,-1.5 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark68(79.60046268476555,-40.22591806939224,-39.575946613293155,48.44859375090533,-57.138501743354375,-1.5 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark68(8.000048650483652,-68.85660323565679,-42.06819855876854,29.651336764740446,-45.50765469082476,-1.5 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark68(80.06805813589668,-16.851155967975686,71.68259065633143,72.99282329096278,31.152393520084217,-1.5 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark68(80.1253885291145,-4.867025363336916,38.805212677439336,116.36529775151067,29.940522948048265,-1.5 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark68(80.16946515828977,-94.06109015676687,-28.059228243352027,6.009688737592669,69.12934625440303,-1.5 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark68(80.30637783554573,-48.48315225776417,73.05537391234672,100.0,-61.01405535182056,-1.5 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark68(8.07427072684369,-13.804465154522276,21.263508614272443,12.731589468332004,-77.516180473043,-1.5 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark68(80.77001966190059,-31.016217144463784,36.41353536143856,-44.80649136803351,51.24537147166859,-1.5 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark68(80.78268237260441,-35.38007054829207,-73.03749985829046,-79.55194650750818,-89.3600881950028,-1.5 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark68(81.01570175051309,-83.46507492700857,82.60679172296703,-56.28373833711072,54.19416566651839,-1.5 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark68(8.109691185707224,-21.876986225819856,9.6979504101855,-54.661396287965296,-0.6417587785786036,-1.5 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark68(81.10896051772323,-62.68468659865884,-62.93402916174341,-91.38445666437872,-53.01655953492131,-1.5 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark68(81.18946752869681,-48.74408560776693,80.55881239135707,87.08613309024557,-84.06462472700036,-1.5 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark68(81.27826127619872,-49.37212125279277,38.16055482187224,-96.50234839529689,-26.007255850422357,-1.5 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark68(81.28174862788461,-2.017750321541129,17.82672863791288,33.493194520518415,-26.352690686290586,-1.5 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark68(81.36533593840701,-47.909079706495305,-46.890622447433294,-69.65543186764111,-18.663908971530063,-1.5 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark68(81.60366691092324,-55.61046025390921,-35.839610834551294,-83.3551530291196,-88.43259085949988,-1.5 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark68(8.162680074713593,-84.20363018514398,-17.76459879677244,33.68114506617117,-71.57524463986861,-1.5000000000000018 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark68(81.66902534198012,-51.40156818719934,43.15891121300519,89.51926596175079,-49.91702790577951,-1.5 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark68(81.75092074888624,-37.81619050981122,39.438647575566335,-42.670286517407696,-39.21917847868923,-1.5 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark68(81.92804081806528,-52.01298243963006,-57.02555765671595,0.05805337398776089,-62.3235342110108,-1.5 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark68(82.09188097914844,-17.210101580419554,20.441102497266254,-23.65392689766722,-85.89371639895076,-1.5 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark68(82.12700510467431,-95.5585266648479,-14.402440123789574,24.657453524274615,81.22988010347785,-1.5 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark68(82.60753291874363,-43.54746869456092,34.4041491286983,33.79323525909127,-5.555536608602541,-1.5000000000000002 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark68(82.74633184284079,-92.17182909616194,-22.79026828780399,47.098599095238725,-32.39729930490348,-1.5 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark68(82.75344723433764,-67.85772474391196,-21.827429208202034,9.810659693569661,-4.277110732141267,-1.5 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark68(82.84318217399502,-58.830504373382254,-34.30062085209751,-8.14787395429683,-100.0,-1.5 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark68(82.90517090590623,-65.36682963049833,46.01546377587778,93.28908294752407,38.10188152578897,-1.5 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark68(83.25810242556051,-61.41000638556693,-89.4071697298527,-56.10217379831612,5.815511968665859,-1.5 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark68(83.28667453170551,15.624558315267087,46.61070418900712,-33.806579087111444,75.07990607273408,-1.5 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark68(83.42501673907503,-65.0588308176273,-4.67368821158631,51.21022176701354,59.09561434551703,-1.5 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark68(83.43658585052836,-28.316717455670954,-40.45099699321257,23.648482997840574,-18.54286609405426,-1.5 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark68(83.66469921530393,-84.776807460631,58.93915311207713,12.507119185221065,-17.554431277932476,-1.5 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark68(83.9324393540421,-61.759686896414586,-33.555520003562386,-53.5994435770572,-20.72299074084113,-1.5 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark68(8.394753505088302,-24.95562674337142,25.60644779509857,22.466121204978798,-16.73071925571728,-1.5 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark68(84.03541377599566,-2.128103397448158,68.84335496893961,-9.267220674693974,-27.84018922725074,-1.5 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark68(84.2043112936272,-81.50206162279687,19.981307179657207,60.47476669684488,-18.18768072535002,-1.5 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark68(84.24070616478002,-62.870240791196984,-80.16120506566267,-6.5593717127372315,46.724989509634895,-1.5 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark68(84.64103903249878,-73.0387545228359,7.190602324204647,-40.83865718539088,61.99414272279239,-1.5 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark68(84.7333732720433,-15.937147987810855,41.89884400028189,-16.792449087792438,83.79581349697733,-1.5 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark68(84.75142631024187,-3.9591742440342728,51.963834587999855,-63.39455576734303,-92.12950334980042,-1.5 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark68(84.88207207952294,-28.523635171333552,14.193420688312738,-48.439951629930526,54.9429235821078,-1.5 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark68(85.77711221961343,-75.04536403515199,-87.55224718714716,48.03465836649038,3.7017842330115402,-1.5 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark68(85.79107825353555,-62.12154745320662,17.536599687069724,-35.89282198047866,-55.07947699788911,-1.5 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark68(85.86122134229687,-13.76974393059971,-77.54849855540857,-100.0,-0.24305893263301392,-1.5 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark68(85.90436883874989,-63.567036160501345,-40.77019429681028,-73.12211692436784,-89.20483423299994,-1.5000000000000009 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark68(86.0294499843206,-43.13927262808921,21.08667299877697,88.70437752413218,7.126856038747354,-1.5 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark68(8.60348921554953,-47.877697955726234,-69.40380309511131,26.37564655583637,-69.17903684558635,-1.5 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark68(86.15202007263017,-61.54720005758823,9.535339954578504,19.437548548952137,-13.158903594335518,-1.5 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark68(86.22693075531288,-72.59301778169367,-38.386295716130164,-17.714955626666562,14.306920537350493,-1.5 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark68(86.39334504129866,-18.58327999542235,41.19158499216073,-89.28527036252099,18.8824349680351,-1.5000000000000009 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark68(86.44181054336885,-88.86523619247286,-77.27803612674575,72.10772475875815,-58.69051457101957,-1.5 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark68(86.44290554841382,-53.317317834259505,50.69432563570675,76.96101453214075,-1.6024014270058302,-1.5 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark68(86.70367962656036,-64.26610580424854,42.82721185954088,-74.8086602097226,-86.86471630115278,-1.5 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark68(87.12377408631819,-46.98722679993729,-10.448456698158251,26.970411822182406,-55.39086904837685,-1.5 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark68(87.39004977665677,-100.0,31.883927776739792,-49.344868338245206,12.484326782885033,-1.5 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark68(87.49531582733573,-60.63144532876993,22.933940682525314,18.993892716452283,-28.836369293563717,-1.5 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark68(87.72269939879433,-100.0,-39.74025383105854,28.50490963601788,2.586845232631635,-1.4999999999999982 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark68(87.97461227664229,-6.080758793175036,16.277303000494538,-54.14368074747498,-0.2563091747767934,-1.5 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark68(88.05503456664947,-47.79466991492375,37.726764061411885,31.091989610087808,-68.28520028773902,-1.5 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark68(88.09671614102342,-0.2978541131803496,17.916056125820106,-61.65738962776731,-71.0914437083789,-1.5 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark68(88.1580253203298,-65.7082249760283,15.322085720684145,15.380489500226904,-67.81242450936915,-1.5 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark68(88.5444855832531,-73.39164618537487,70.55765440594301,-70.84176849720984,74.0735253733921,-1.5 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark68(88.61167394366889,-14.418374098128917,-37.659533653587566,-97.02740859216355,4.046522759428105,-1.5 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark68(88.64116412550024,-93.67377196264488,79.04453289650117,-38.43237305539741,-21.040030274157544,-1.5 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark68(89.02829829764693,-23.194920055155603,22.521344669182145,47.13630736630838,-56.13040148224707,-1.5 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark68(89.60136578004972,-21.089624066032727,-60.84163666524614,45.6576343080481,-53.30649207348519,-1.5 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark68(89.90744493301537,-82.21111414444704,-93.14448636815902,-80.96043799490822,-14.356235146490832,-1.5 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark68(9.011344895361106,-82.44531241321144,-44.038388650069436,41.13662263878567,-87.32162672860846,-1.5 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark68(90.11367025912563,-94.69346533885215,-65.0310151722204,-4.891696529446193,53.84092834814865,-1.5 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark68(90.19406486141352,-98.4494355280259,-82.144109010251,-91.21184085341571,-11.35049788587817,-1.5 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark68(90.47255353936256,-83.3226514433038,-37.56383930841061,-36.76158450772055,21.834622146527995,-1.5 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark68(90.76964741173916,-20.583170555840137,36.30793467844425,47.131093247919694,29.60492570596609,-1.5 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark68(90.82241399669874,-4.903227547932985,12.10266911993596,-42.4549445363172,-1.6209018034880387,-1.5 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark68(90.8604199730654,-45.65556725290134,-7.164420443341682,-58.60050465577195,37.69944723226098,-1.5 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark68(90.90751335824811,-38.832959416945066,52.306735833368265,75.53354790011838,-49.46410488443229,-1.5 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark68(91.04260262152116,-50.81361002933882,-52.573969801896034,79.87953572786571,25.589669526608944,-1.5 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark68(91.22785492717352,-91.93823869975775,-88.43120660379881,34.58612219069475,-11.844222305911797,-1.5 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark68(91.23110764445279,-75.75712001882385,-11.700237098742583,100.0,55.53861870825427,-1.5 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark68(91.3061610556039,-23.00929887819663,12.359822914448628,72.05245389674073,85.7284714917092,-1.5 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark68(91.44888397176899,-66.57624282645637,-71.43818292743606,-9.195899875388967,6.164759151477718,-1.5 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark68(9.15946026915182,-64.575680051903,7.941172808271851,100.0,-1.8146686101342402,-1.5 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark68(91.6506312541114,-31.04679032833195,14.946088535980934,-40.23739688103931,-76.43260828425088,-1.5 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark68(91.67319180322406,-99.12929052404257,-19.08229023356236,-74.31712190638898,12.92654380331335,-1.5 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark68(91.70330187246756,-75.94424102544181,-52.87289697105687,81.56334529735577,66.90272593594459,-1.5 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark68(91.94790960351048,-23.493510912284577,100.0,-79.56849346653684,89.30337138846066,-1.5 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark68(92.49280326085918,-9.963963164275407,-14.648515091303945,-100.0,50.47901496087163,-1.5 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark68(92.9458257513099,-48.109923086870936,56.18371037152383,54.41740092360635,-24.866519154135723,-1.5 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark68(93.13208271528642,-33.792399695593716,96.9749618118903,-60.251274275381164,-86.13273582499605,-1.5 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark68(9.315831737302089,-91.04670717065473,71.38680603227354,-64.8141706633631,-6.158545103591475,-1.5 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark68(93.3400380948872,-0.6748710768780057,24.149771451239594,100.0,69.24140523365296,-1.4999999999999998 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark68(93.36029680927021,-39.54749175650751,97.39714318705,96.42986690980999,-74.08561133372194,-1.5 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark68(93.4014274658824,-99.90388152158896,99.98461138634256,-72.55114147430842,-63.26789625953811,-1.5 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark68(93.46705857923826,-55.18152655554646,28.48747184048971,12.442146362967694,-7.28859914696819,-1.4999999999999996 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark68(93.57487707505446,-47.064979083251735,56.22174408805161,7.052564594765489,-24.158152052753522,-1.5000000000000004 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark68(93.90408786274172,-18.334320096584847,-46.09448480223883,93.66813209380716,-35.96259001441743,-1.5 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark68(94.18347246475946,-32.71929856418263,-100.0,-56.65316124498917,-100.0,-1.5 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark68(9.422065985121236,-25.164516613960444,49.65890858655413,54.26480509607393,-10.627957893426213,-1.5 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark68(94.45242189695512,41.76437990455682,26.421178929796568,-70.6752738636174,68.71399126848081,-9.90600982759456 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark68(94.47904870505496,-49.0603422513507,44.86009218396913,43.94924913555043,29.252061468830103,-1.5 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark68(94.5274233522242,-58.449187254564805,-24.020105970280078,100.0,73.62670435294253,-1.5 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark68(9.456053499937738,-69.14634127189403,-24.79930758453328,-28.60570740763005,-43.48677280625941,-1.4999999999999982 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark68(94.60076205293475,-40.02998730964553,81.5893987613757,15.656612611134651,-33.151221715887786,-1.5 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark68(94.98037517418945,-32.14589887664067,78.94179885650956,71.3326143779376,35.71236333029529,-1.5 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark68(95.27007082883625,-44.73621396457854,-84.10153153955352,-65.87463101745624,82.45821556497523,-1.5 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark68(95.27029368885627,-31.030237591917523,7.284222957861891,59.06468363367232,54.168541626743966,-1.5 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark68(9.585146396182413,-27.933907313520624,-8.870005243478449,39.73225291158266,-62.02661021076677,-1.5 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark68(95.96284659424244,-100.0,-79.75108657107957,-57.89918188620798,65.37640955834165,-1.5 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark68(96.00340843019399,-27.024702380095828,-18.457840654575943,57.80875863872569,-87.25011448199304,-1.5 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark68(96.25113611957451,-78.19279414546224,-96.9517707357759,31.012936314350906,-47.67310045081152,-1.5 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark68(96.54421082060311,-35.84286836470199,-50.73553751723834,-79.26061396730614,-41.88475594585567,-1.5 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark68(97.26879006784796,-96.39597367915493,71.29058195841058,4.387678023917179,90.11557929271055,-1.4999999999999998 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark68(97.32210303800474,-41.30826177600726,-11.924357945160807,45.5109554227802,60.98618523492229,-1.5 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark68(97.49430522185477,-5.284262202452084,-47.36701955680071,96.07067039529099,-24.107725809671848,-1.5 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark68(97.91342412277001,-98.25421435777442,22.150618342246005,-38.29527743650789,-49.876944052401015,-1.5 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark68(9.793547645047685,-33.802349555548,56.61022599470384,84.24227822213993,-82.12417188305615,-1.5 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark68(98.93958710198966,-83.25784976060554,-95.43630292365876,-66.5510472756005,92.44778837422899,-1.5 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark68(99.5795841506363,-48.26201262777712,40.71081196430677,-94.24688504473133,59.551427795019805,-1.5 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark68(9.963626367171738,-12.506994761080763,29.914361797215218,-60.35215066195381,4.4317199642352465,-1.5 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark68(99.95224108326082,-46.71045148068475,57.61505693195809,-100.0,-14.974416571244586,-1.5 ) ;
  }
}
