import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.06418788767834371 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.11675908327293882 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.17438947038502306 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2078546282834708 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2164361493896223 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.2670939771143992 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.30241241534024255 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.3042562975655869 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.43977330102384826 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4570464694330525 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.45836232590394843 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4671959148091531 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4893453885592294 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.4922032108888459 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.519124605510541 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5195355685693244 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5535197350624799 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5691102679075328 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5718849992189377 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.5910908163395447 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.604285950709226 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6605845409505235 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6663139611331985 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6764777501178969 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.6975115553904914 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.7537070507900268 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8041349650716967 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8146011020404416 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.8473560371408269 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9026147016277122 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9069334817924926 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9301356238885887 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9547294863605771 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-0.9732030850697839 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.006697435679897 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.012993586074217 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.043794985748349 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.049424016401076 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.078474679507593 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.140770832157472 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.161953779377924 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.190543628570794 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.209730726997691 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.220503215895363 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.283368177016229 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.346588567707045 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.373047775290274 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.43411362888591 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.46653660683603 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.546698975829699 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.559542430407177 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.566091176578112 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.630183961264692 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.654360994242595 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.674687081196694 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.714664617314568 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.751789958567485 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.757577408685862 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.761781062587872 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.761963323279033 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.766363622532296 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.768512739259137 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.79449816861677 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.799039582029238 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0806142249048634 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.806471456391293 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.836399073701244 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.0852349461204938 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.858743874123647 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.898648050150513 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.914696439395158 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.923196523356495 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.98118516618662 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.988970352152364 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-10.999071463293504 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.023382883774332 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.042989992075448 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.055349329681178 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark36(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1103313340167915 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.163253033652424 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.206789668496796 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.215314652357208 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.245178102795748 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.252631603678907 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.26156872897485 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.292764677196644 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.298619849176276 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.38846037531593 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.45906128946595 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.48013044172356 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.540236228171196 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.547485254198818 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.573642444969295 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.57810909582706 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.590398984354948 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.594885926161552 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.59610946439183 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.605468558153916 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.613490734220107 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.635306826203134 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.66082859133158 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.16897032324907 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.691904019711473 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.719932719346659 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.736567457357623 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.750343481072818 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.752958678414856 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.781650699908624 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.839213826007565 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.848459361642057 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.863274646931728 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.1890694614049977 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.93958860549482 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.951011124094578 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-11.998453517461073 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.02835877000794 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2067447670946763 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.079755955158092 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.083848366947578 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.159136741059996 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.179237204974001 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.188325588587887 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.202470017278898 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.228992638126002 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2272571109190835 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.279157918613294 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.302077198183838 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.305193509559075 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.310135918200757 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.327726505425332 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.34326316225318 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.351526603562775 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2433313691594776 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.460932624476698 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.509997317529681 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.522491356111914 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.533695316764465 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.565114803029957 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.609393272989749 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.610804959435427 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.612338437482592 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.681459948441855 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.692468973699889 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.693733754901729 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.710284433270559 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.717990177934027 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.730072790064952 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.76535612664955 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.806493914135999 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.851240300339597 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.2853971135397444 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.906852448350278 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.909508977072264 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.983266286895969 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.984426029678303 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-12.995898475996981 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.047527243133487 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.06936703748282 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.08006749456689 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.08301123909699 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.12153363090988 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.131335143199237 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.1550865797049 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.15867347450721 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.183939598990762 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3184876637031664 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.192826345962942 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.22775581434999 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.248346150023082 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.26328730421828 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.297386216585295 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.324919975893152 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.363472506590384 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.368810095501289 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.37068670243417 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.389182952906523 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.40068144384638 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.449462919447598 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.451124774268536 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.476111349105068 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.508408220755058 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.623219194554181 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.650437395991005 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.669858915403935 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.676257535018195 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.697579890594966 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.796582923165573 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.82539786841923 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.826774007326122 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3849937256743772 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.3867973474582413 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.923463393447548 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-13.989588002860813 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.004413777423537 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.053420002709743 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.07904570151463 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.087150292765799 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.090185408590642 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.213162739907716 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.215179740294886 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.283816863309596 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.366040641952921 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.370723254748683 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.431244755753838 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.439998970834878 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.461237334402213 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.46359589455075 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.467231145321449 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.484435905991006 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.494044019744152 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.583335789649581 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.4700507711160213 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.727161163630882 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.753962729646418 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.776208740715674 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.814452999245347 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.82125696454743 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.83273205154228 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.859428682794615 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.88183872594972 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.887617755042058 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.901123139681218 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.963358312088019 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-14.991127791324857 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.01306543072684 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.043167300907271 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.054322440331177 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5088645723077008 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.093268226731652 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.111396808546203 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.263128386585706 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.305152929864008 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.31874216428497 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.322521424208688 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.32964093760745 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.347641431951885 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.371373714679649 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.380638042365362 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.539937223353462 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.401331101256986 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.468707899104444 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.476913188789453 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.507173104334697 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.522009800905494 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.548418806532553 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.551276712822045 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.565909349144363 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.566888851566318 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.582211006196431 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.5624856989681462 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.700044901726898 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.726570966935924 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.782353073652857 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.812278534132872 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.812578119242175 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.82330631223165 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.84334142711434 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.845541182751589 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.905912306336333 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-15.984309800629816 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.015670570950192 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.044064546039664 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.0727109797173 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.076927820052475 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.080150873304746 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.12406582904326 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.126562704771416 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.153412570733153 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.16977920392941 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.192648261644237 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.22662705020757 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.235603686400466 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.282311256949853 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.291879023048978 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.296468749193878 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.335666698615086 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6365172213817658 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.3748585089792 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.378231934600947 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.390476395938265 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.414066441984815 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.423915900646463 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.425566068973055 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.43860828500148 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.438644007446854 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.443335312557124 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.45262907251754 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.453500236717076 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.459261125402463 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.467238243481503 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.469879957544876 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.513423428819024 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.543305743845423 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.6555547454702122 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.649277757022872 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.671718421099683 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.690570413516113 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.69433893989695 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.730755010331407 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.742745710747812 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.768712095185705 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.777870958755088 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.811283635245417 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.83472905799131 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.84265791534645 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.8445153343866 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.874509845583233 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.95038871497357 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-16.957279742229446 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.012535644350507 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.03204391256338 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.039010659146243 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.04375327968266 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.079575015971415 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.09123527744714 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.7095064146447072 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.097027613676858 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.168877194964153 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.218175522744744 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.229015890837076 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.242400771258588 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.243756809289337 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.247725829215057 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.27052063256332 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.290982470306133 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.297031033897454 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.302849695053084 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.31121004686034 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.331267533061975 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.40914765096457 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.438794007855023 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.45266847595333 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.490764918981668 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.513373696034094 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.542695560326592 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.563671068621574 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.567546350308902 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.606512024918345 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.63207293918714 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.65870867375483 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.65961076095148 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.659724896277808 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.665854878442744 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.711347020372628 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.747277528847377 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.76239813103227 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.766384412897082 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.77783957422126 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.783609392117498 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.84654903599619 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.865461276187645 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.87157704987156 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.886877942814408 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.95286437481711 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-17.992700430887723 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.000016908781618 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.02718218457528 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.04599474257742 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.100468706181488 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.102856092910514 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.117526666969283 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.13740718734293 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.14313202162738 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.216533836699853 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.273644982639524 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.323600122132362 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.337995657278967 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.37150980382596 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.37439053677747 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.393237720079924 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.40912021772114 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.432636715682364 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.532867903349953 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.547840748975773 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.565916652678766 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.57956637642168 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.587637746238258 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.67322511653859 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.67508107218599 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.686853915142194 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.69404950223634 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.8696661028273525 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.72590436492858 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.740620268352174 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.754238670903874 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.811849897747138 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.824647167420068 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.851859107261035 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.859169930907143 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.87362419371796 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.880647778691213 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.889553855678216 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.912916688790233 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-18.933217697090598 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.014230078161148 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.033060101183906 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.059064596587035 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.062534538398452 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.083604229777066 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.908520035875199 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.08743948049188 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.117971061160958 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.154164728911937 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.177302442542015 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.181175254944264 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.19064109389828 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.204534163998275 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.22355192279781 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.30036410276925 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.319769416630137 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.343475608122375 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.38816368143968 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9406453354141178 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.453068042631187 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.45521118788494 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.476898575891767 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.527601537713863 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.95965625448531 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.61659961523128 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.74999493790304 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.803686798023847 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.84633048589268 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.94196743001764 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.94457598618915 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.952646583819416 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-1.9966913036242318 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.977909540500534 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-19.986353688989283 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.006373277975925 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.0283148320338 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.087769619232617 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.0880075938709 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.088070825413396 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.13704508862581 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.191649864901137 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.199115092431313 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.486740828537364 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.499762196687726 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.523828048343205 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.52687581833426 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.58680787980063 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.588919636758746 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.64708970593867 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.652669931901485 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0659453182666994 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0678540413894666 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.70252790738833 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.772307531739003 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.0796238723106057 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.796524029206893 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.79824668868342 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.846877136450743 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.88359328666398 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.88463658404703 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.893347762118395 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.923771567275807 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.933324971197536 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-20.961033907951006 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.002425945015375 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.02360233183815 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.06981080754997 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.085378440854626 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.08561649879084 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.11017875817413 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.16480059426631 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.18653534374289 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.198996646326847 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.235786421456766 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.27542940782577 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.314783090947984 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1323108384745098 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.349533087350792 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.391806301020495 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.399289498683032 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.477037090739074 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.478809478020565 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.48070763707075 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.486089861244324 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.492881177552235 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.516155129355823 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.532362646392755 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.539669378322785 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.565964711050327 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.566904083807458 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.568198178117044 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.607072722129487 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.611011535853763 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.611457515728787 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.64037329289161 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.649943192167243 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.65612217005679 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.695605787505485 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.713243936954157 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.177461516273411 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.1807823942841367 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.815235575530025 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.826689583308266 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.861792509284882 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.88605079774048 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.977727546113186 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.97924089412797 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.991274341594576 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-21.994550484389833 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.005376957966575 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.007403682373067 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.034983882493478 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.038601724683858 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.042434259375312 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.06147133956371 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.08297807218686 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2197668811470948 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.21259138296587 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.21554034187298 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.220612286754474 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.227484909536173 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.233163125307627 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.257790320695747 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.261550576151294 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.26293052845905 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2264117594141766 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.29524178246551 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.317953859012277 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.325554300304233 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.353512561379958 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2379801419876344 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.384057298819002 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.385123774762477 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.417270926929007 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.420585774572686 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.437402067918327 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.4728055878428 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.485614161395347 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.49115296069155 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.491989792693218 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.51995837189851 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.54956741487692 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.578598115451157 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.58763640965455 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.63397029395398 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.635417053407124 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.265521246505074 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.67546201016988 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.72426412544199 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.73355834507933 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.75115948308067 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.751543300082616 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.810438685248215 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.83263929358783 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.2836273545555628 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.83636072157647 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.857063247582033 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.907779439151938 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.96630305769058 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-22.984396510843425 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.012698063782764 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.048025200233695 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.052212753891126 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.08410115820456 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.09400486711752 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.10407296908113 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.125135028253197 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.163985602662933 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.259905669632445 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.266889103983573 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.32093629345762 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.340126184510595 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.350358466280156 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.385811557192994 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.39983866924942 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.42849371615941 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.343574076456605 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.46375804865339 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.49511684308129 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3540485744143496 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.3544370279186637 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.624111379877192 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.636532769146683 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.69363370360638 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.694537765665146 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.742924370260326 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.74825802444944 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.779143477276293 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.82153788951686 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.830253791698482 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.843497609147036 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.872609093839372 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.8774374808781 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.899400349498734 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.920584392206607 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.946502091640227 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.967185571567825 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.988664412974444 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-23.997923730980915 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.010627639325463 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.049367746746512 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.07074202024404 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.086853424297928 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.10825453431798 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.11596979045288 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.138068303764555 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4212641090972937 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.215238193742252 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.231750704870763 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.23417704486917 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.236306076525267 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.249201989944225 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.4249258588832276 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.255191083365318 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.28536303829472 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.35310149300207 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.3951131103902 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.41880778832555 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.435136248285843 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.452133072939475 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.512257768460728 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.59344062429065 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.615079639068128 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.646199239994516 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.651962977880743 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.663037748294897 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.69843999261046 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.712381661771005 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.732781332517305 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.7537341801483 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.790459621807884 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.796798282407323 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.807906279708675 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.927024453153336 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.92885454497997 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-24.963437804826725 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.058003428313853 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.115925253787893 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.116724759507505 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.13063002822777 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.13661372320273 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.183315366388086 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.202918371288632 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.230279692982677 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.262967261117268 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.275591084046283 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.283709483819507 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.284943433952648 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.28556020979569 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.30792947377813 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.31331187564004 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.33697842023726 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.339795209792527 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.534470305833352 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.366001824248656 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.409193008777905 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.4202819962466 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.461409134428337 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.482361460854406 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.521400579714125 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.524098592063993 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.538021794233828 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.649169973369084 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.672074385148775 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.686499773904984 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.694392509825008 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.703637174927124 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.728939839568696 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.736736870344984 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.76881740618515 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.783663079775906 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.794309879916113 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.86105818240314 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.87021546020307 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-25.87167152998863 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.025961496877017 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.03561236633894 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.052746674006272 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.055873528528068 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.074186877663237 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.098516677806046 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.142301956441287 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.190706579953925 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.21067887957183 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.22723236428564 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.235181580303603 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.242331392266678 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.252744669739656 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.625437360996912 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.260371918584298 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.33269469605925 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.36940932812321 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.410259496799227 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.457993057076706 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.470878907541604 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.6498377627769116 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.589662005206804 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.679301162585574 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.69175119761691 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.70270044945815 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.71611651042913 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.73275184819326 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.761677286635077 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.678784219010666 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.79583675654422 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.835017595127027 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.93709503341242 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.945841347177208 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-26.959769458397503 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.009827083342472 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.014842266224747 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.701508036299714 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.031083425153525 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.047774648220184 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.704953589589863 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.081380158175023 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.09616295727126 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.09873176017514 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.10454663827977 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.108832979385 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.114489632610912 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.115544487411512 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.128487992905832 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.133655193086128 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.140121156534832 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.16112042049052 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7185468724780293 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.192710362695863 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7212680088570522 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.236963195721884 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.274132043394687 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.28577388788267 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.291241294525264 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.324088511786954 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.345974015048895 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.35200486921454 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.398831270148236 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.411725238944015 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.489794632358013 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.50911294679912 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.752368897050175 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.535677838202048 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.53801190045391 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.552057836359893 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.554136767726888 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.599462641027614 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7615085202945124 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.637234489871872 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.653576759387576 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.68175737516796 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.739589632260376 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.758753373270096 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.776169562101188 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.763750710207688 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.78017404545119 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.784320818373203 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.850306174910756 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.872043892807113 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.8787989670749 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.7895733139018404 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.910061690306947 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.91808070812523 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-27.941086333917582 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.0855546775924 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.808879872099851 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.117091192933103 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.126850444079395 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.16197712287915 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.1731834052368 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.817528889232662 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.250645575794394 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.263033569763408 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.3077017586196 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.310756980527103 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.33733659490825 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.340024425554546 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.346012269732142 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.456058667285205 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8457349865771704 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.46621030504511 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.475550248182117 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.510220539703 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.558439509163563 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.630423954425325 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.660013831728293 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.867966479550631 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.70977299143094 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.71708735529222 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.80120428579849 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.828444399269998 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.857735647319885 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.8912582990771227 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.9218095366449 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.92528496858739 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-28.947885969966094 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.012273640249006 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.126979904158418 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.17470656064613 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.199275786253324 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.21817437598024 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.22086234343908 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.269625372624745 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.279391390000512 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.344772188093415 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.37667521940537 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.386493984156075 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.43497588201383 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.463802279215827 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.49317135299063 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9535127872412517 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.690110565254884 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-2.9713976523541703 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.7208994136398 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.75948990211279 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.77646335045678 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.823974634045783 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.83351453807208 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.847255523590732 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.87601409720142 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.882717964870892 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.883994383000797 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.885286816151236 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.9119592716892 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.91302070999184 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.91970450627801 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.922571936540706 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.934964485663087 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-29.990376210837667 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.009818564617106 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.01827226224627 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.023360605729522 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.004187544433165 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.07173727106462 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.095969267554267 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.149155031835733 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.164682430953803 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.24208452327312 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.24648032660228 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.319778973508022 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.035443506009969 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.368709582936646 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.377179251562353 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.395071487017233 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.39685894423836 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.41398352697115 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.424849697461795 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.427453255285414 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.44048758184121 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.453412424903334 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.456961773095202 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.525817120257855 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.55661102935909 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.561086829238576 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.607536417794634 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.64655157912013 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.652801527426803 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.658052614850234 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.666631206546242 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.740455105291645 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.759074957343685 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.78475682283519 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.814226377656667 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.815378024778454 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.86601424895545 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.881839284601043 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.88687187612021 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.888401134898146 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.88998639839727 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.914238942195738 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.930813176036025 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.0936735046910684 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.93679254428376 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-30.938306696541005 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.004501186280436 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.008696602874892 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.022366216944675 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.04112095619449 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.111141800376174 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.119757118259272 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.152926577457947 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.184573775902734 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.248123139339484 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.282998809469518 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1300766882928173 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.30718224554741 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.309593234878335 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.31099181996717 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.31672190765005 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.364111838630322 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.1410510620784464 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.426860856455164 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.453173851932448 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.466230679684543 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.467108309156202 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.479671287195615 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.51621571619043 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.519718070104716 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.618359835153427 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.65139560996917 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.67528756972135 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.74950155842015 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.790904804801315 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.793043228657154 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.842644278591365 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.854970673637496 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.894490527097204 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.897414486874794 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.910705969258487 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.914050872209003 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.98421721482532 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-31.99857359225497 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2030952094029175 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.03682106629317 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.06070854366287 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.18875461898776 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.2231033608194366 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.27962548591037 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.284677041225834 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.23430826022026 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.34550741612155 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.4045160365489 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.47419373886112 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.506729699180255 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.517779257529654 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.552525969505325 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.567461003125004 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.573864571111116 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.57401429812141 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.6032147919894 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.60598274642017 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.715397780366516 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.728004610845545 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.73767749831873 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.754594151519 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.78880402927982 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.79130993574499 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.793070718440504 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.8290455381693 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.83211959498544 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-32.85666351683946 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.02499208259144 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.04752148936707 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.11016907728488 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3112039092257533 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.115705134790076 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.13849973434017 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.169040644243196 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.1709844836186 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.18805513121768 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.20120071408532 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.20711791760742 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.2287985228936 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.323258161929516 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.273943878783 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3319633708607057 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.33400385816725 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.374447878875955 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.40583269734951 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.410670672780185 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.43065753167156 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.437430399458506 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.44551258061537 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.4511742566759 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3458371393377178 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.467607841169084 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.4980815093228 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.50928897146761 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.521276802853464 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.529015740621176 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.53585178905365 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.54553026434543 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.637264538312664 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.65012592412377 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.67825254687105 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.73869496384023 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.75268581365927 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.76242674366648 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.80075761598019 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.3806460814117116 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.822968580186725 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.83667917173369 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.8672447132558 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.870011618011816 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.90924380473315 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.9134766873475 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.91841489678811 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-33.94958802180106 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.017818211710264 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.02563731049287 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.046804426069556 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.06922274081228 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.10495634760693 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.13372933460184 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.195339968222356 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.206152637271686 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.22678335110356 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.28960706607313 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4339895284822575 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.371066127655496 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.391675147468774 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.436581001098915 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.46433258033727 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.4760372790647 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.50337242909325 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4517664256398746 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.52989842722785 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.554138716087905 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.558925600924155 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.57475694869491 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.57765081214174 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.580198886220884 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.58442295068744 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.59014568457086 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.610262516547635 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.61843862331777 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.696384776286166 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.73015817333564 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.741570401095245 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4751132562039118 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.753287342634124 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.75518898989853 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.4777921070875806 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.84421960099881 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.85345009607134 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-34.924394921295644 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.498544717963199 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.02041099168966 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.027001282369866 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.12403857005131 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.13155743223062 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.13450897144723 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.16846583147178 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.17082836032628 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.23697064114569 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.25632559263255 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.26307511067837 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.303071147834615 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.303517571170715 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.34069445642058 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.36275446733843 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.47974139378351 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.56187535995964 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.59243412018674 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.6235607756702 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.66548618856129 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.667174973342284 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.681907288520335 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.69925660123529 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.70697258372371 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.71017235257641 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.73419976297569 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.5783296958008037 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.78903372499809 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.79172229535456 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.85569932716264 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.937023934720955 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.94459059619311 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-35.946144549398326 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.02425048237903 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.035543775672394 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.0553821385311 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.073433727242566 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.1017177951527 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.125469165348335 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.14285962602051 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.15254635985157 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.169591845641456 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.17674906976631 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.20470510432139 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.22175437530599 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.2217740982149 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.26796166458979 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.27003890325526 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.272540956868646 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.31163825907488 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.34605668437898 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6378333750372747 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.6384871908204985 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.456545492032745 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.496914650454194 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.52242011343112 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.62132560922375 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.66438787863105 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.67253886872104 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.71517486744398 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.75066278187467 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.78026972994153 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.80580682265886 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.83637961764219 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.8671172170481 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-36.867335130934876 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.10587097188092 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.119712709354545 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.18315739598228 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7202785664142652 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.22756180334235 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.23268564047268 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.23330243206713 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.2628947665582 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.727474174074416 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7320688648150053 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.325620857967955 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.33108879702911 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.33711250018177 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.385551014283315 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.42079673238394 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.432402074182036 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.44247115194366 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.444710994640616 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.47537257643108 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.494843981795434 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7502271181984383 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7525277308330516 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.52806646153542 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.759715382748638 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.61009666705042 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.627858177012705 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.6597150004107 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7666072067333687 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.666338548414856 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.71525139434686 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.721928360240355 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.76766570884167 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.77610333446275 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7779771385739025 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.79001906611119 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.80369562686303 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.83261060502181 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.7834428098718007 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.923294360824535 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.9524790032236 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.96377906224362 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.96420877912339 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-37.97213519663411 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.005043745095435 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.06004419703057 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.06193007647454 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.807523874754864 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.07726448462114 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.807778052115225 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.07868610872769 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.092169392404784 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8093272947567556 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.123738606555136 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.812852520922803 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.814574608745545 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.17481585382476 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.19458781983709 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.202182830755135 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.220785086608956 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.227188559695776 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.227698693367444 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.25583370926433 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.29059376758599 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.339396467430255 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.35757915172058 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.42225977490736 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.424557777897725 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.42510844246492 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,3.843596621405922 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.43700563730796 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.43844962285854 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.44996139461367 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.45025035743546 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.48429259178437 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.48614018056511 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.49006662076029 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8508785659966804 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.529309776944466 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.55847665408787 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.57074501924234 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.605180987020816 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.620141940282934 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.62757306906177 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.65035029748876 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.66081544148698 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.66451455010289 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.698869354847346 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.70027028731822 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.703997581133784 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.708571983314584 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.73756289717549 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.766002849140776 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.771846851252235 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8775660503706604 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.7783977341589 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.87530587493251 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.92359726127126 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.8929633765002905 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.93570562268383 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-38.937493680539184 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.007683721957356 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.02355128260666 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.0699190981995 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.20470441262498 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.27271338055463 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.286657790796475 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.28861032693263 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.339883141264394 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.34122452888165 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.34921985740274 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.36135964149581 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.40087540843153 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.49470897109486 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.49569854431794 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.55542156924725 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9568461291500796 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.59687177968556 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.61016590996624 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.63676183905274 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.63817257237983 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.64317414907188 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.66406839317662 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.676363387445846 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.69098410465017 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.72436040925687 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-3.9728380881114447 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.784030798617124 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.807100641621496 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.862054864109766 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.87845313155616 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.938864092366444 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.962145417449065 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.971188581674014 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.99821357949615 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-39.99984139263309 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.00353848868059 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.002850875757019 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.07526255891083 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.151633014139776 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.20030912515473 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.284805676264156 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.284925251823786 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.28708937180247 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.306109437401474 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.33787140398524 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.365135404702215 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.39785185794749 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.41489769419566 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.44074813281098 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.45840752360945 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.468934396551816 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.47790868731202 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.48534939748156 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.49993390043869 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.51018875973411 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.55576118402679 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.57389674897001 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.581741917780654 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.586864481386996 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.60233745056752 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.7523381264417 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.8001877602264 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.826989589422034 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.828175151952514 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.889126034702095 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.89201468237287 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.89418981523038 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.96108413117556 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.974340371695206 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-40.98285179280303 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.000377095453764 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.016747021570566 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.108231975443616 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.142875348262734 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.16017041852253 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.17397341464424 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.213675341740675 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.24822974001332 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.27465850172041 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.29105636291261 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.32827080483929 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.32966367650528 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.3456392072062 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.346325383541036 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.137300132393634 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.38365037806253 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.40173826003919 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.49056763796648 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.150993021112555 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.51568180498171 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.55391697915374 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.55524222720768 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.157403502116708 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.61041897263165 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.613562183589025 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.6144635354158 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.161744076149958 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.65931995138088 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.68017115733284 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.681319120772685 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.68319687159416 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.698597062078726 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.74612319523068 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.77860522639507 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.783861555017054 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.9153153017356 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.91767104250683 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.1923975755977665 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.9302463777498 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.94551814122516 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.947471985586084 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.95800084131736 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.195810490293056 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.97071166883926 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-41.98938691663459 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.00266088313831 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.202877575685918 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.2090658317131044 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.09486906893092 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.0973701861858 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.11164206040938 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.12115902398801 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.12726023416786 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.20660792238511 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.26244394810878 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.29611996104185 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.30316857633678 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.366488213370815 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.248116800682553 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.249152655864236 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.52316288984497 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.568043571581306 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.5801588635341 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.622441527798486 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.69974390814528 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.711959547795345 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.83712947881677 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.85883200268894 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.86479532422531 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.86731470248344 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.2872844888435395 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.8923156457969 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.917342224987244 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-42.99405826137137 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.303510251111803 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.08164709130462 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.19549904922062 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.3208778241745875 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.20924887757312 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.22135666256435 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.22862524634055 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.23196141002388 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.25143900525108 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.329466164089851 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.30598520225788 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.31293071262907 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.370582660504844 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.40879950038323 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.45376888506636 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.458774215527775 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.460749162511256 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.49356905333299 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.49541328045352 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.52355188485013 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.78570559823116 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.801576914894284 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.80932915770346 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.81446407231022 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.84659999469574 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.85141640142418 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.87542016993624 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.908347793848264 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.919037648831385 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.393547385257207 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.395622571944415 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.96953187707475 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.98526003522869 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.98955225173575 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-43.99016179371029 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.04610608488282 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.05715890819195 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.07357580776814 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.139506822725984 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.15447974154194 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.16688190208282 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.16984641278508 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.198080726503534 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.235833890011335 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.24061278661464 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.25345072861096 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.29728865522855 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.378595048789094 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.40821457539694 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.4475489822447685 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.483258266663995 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.45244746036046 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.546577115802435 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.55199897301683 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.60216286855094 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.603123856191694 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.67302207859092 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.703434190496516 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.757674890666244 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.812220169205894 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.832134826765135 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.92231641418807 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.9765987313618 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.9847230847513 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.986174123597735 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-44.990213353867524 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.01408658347663 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.06421375974141 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.15797416986802 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.19232409310243 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.211845720022545 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.246839400149575 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.26773494185336 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.272940057473846 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.275262084708714 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.285636387451575 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.30592119758854 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.360704847489394 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.37976753593571 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.540295615313667 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.410516136787635 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.43275942245118 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.46272512205045 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.51778744672379 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.53658248511705 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.55577104243014 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.56451045551313 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.57107116260373 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.598804146475146 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.62408344922093 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.6361573659309 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.64586776135358 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.655960783094926 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.68344554132082 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.69809677270846 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.73733826221098 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.742996921972015 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.781824418169116 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.581000454706711 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.81807078036293 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.82105266378558 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.841959857371386 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.845449504708434 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.8607277493573 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.92818160290266 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.93579075926335 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.97117194324183 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.98207436498678 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-45.990746167692784 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.028810121777084 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.06491211704198 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.096885732366324 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.60986412233791 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.10671783844329 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.611933157100509 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.621552686430235 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.275894131456006 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.628867247498093 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.31342575224271 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.63155906582557 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.33484222619575 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.34825758155166 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.40510839738845 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.46342543505795 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.489145549314934 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.50824425028266 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.523111792862395 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.52807470020057 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.59211064018931 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.599059605125895 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.62743469676738 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.68855763802089 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.70518745234267 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.773227734600795 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.78179660734396 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.688876237021432 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.954664951669066 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.96011193307869 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-46.992502292970386 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.01462282193651 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.0800834964908 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.10189615985341 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.10539962008935 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.10598954317922 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.11690548057139 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.16345392499983 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.21429570348165 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.24768383628999 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.25277564652481 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.26579346541862 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.73018665863178 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.38854504672459 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.39456274998648 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.405448987076596 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.740665568548835 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.7420203600677695 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.431558810786846 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.45518077759736 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.455496400988494 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.51025435224485 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.52443946978311 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.60435490372175 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.60512212548376 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.6181969179714 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.65694254223831 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.658429039060344 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.68708272696516 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.69413713791104 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.715152413254835 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.75465435825525 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.8279120794588 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.87399589818624 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.87970195777764 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.91272250326956 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.95761514846462 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-47.978876671053186 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.030466764047056 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.032981496067606 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.044946186468266 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.06305661206143 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.07269997097228 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.073679486076436 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.1252066478149 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.12765578667977 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.13858493198375 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.182609084014395 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.196485431632354 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.20243487216056 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.262879403623415 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.33608167251842 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.35504041172294 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.38750403402538 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.844510713546796 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.45351058963643 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.46081829404343 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.576761645232345 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.59073654533177 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.61042969817204 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.628102582683795 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.663088370764164 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.70942596166303 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.71990317131183 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.82422064518583 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.88410397114329 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.89597356383146 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.89749539244341 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.903800306097665 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.95941693116392 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.97010383919831 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-48.99218324002745 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.0069807959441 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.9011604093415 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.089739618045236 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.10079365344602 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.11408321904427 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.13085175687348 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.14718707142867 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.16756893906032 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.18876842274551 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.93010536653982 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.325500756025306 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.34966494660726 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.35670033491832 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.36195964299974 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.46454090793366 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.488880252267094 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.489304055085135 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.51153080679072 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.559087128553145 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.56171429998686 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.5826280563302 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.61198199544121 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.656120288662464 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.968638466750747 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.690976608159666 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.70013026411788 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.970449809601462 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.70683561590232 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.731484079008716 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.741053492683626 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.743065672980215 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.79992327895668 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.80754484696519 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.80793383028217 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-4.982299465720928 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.838247189388696 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.850977461966515 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.90272764034969 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.91762099149242 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.94684290633078 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.96144146681094 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.987576125515034 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-49.98931018603421 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.01193835163076 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.02448355143005 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.03554108447421 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.041085580352316 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.0462677918521 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.05240162469735 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.055389201950476 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.067431411071304 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.087445772119565 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.146148780706355 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.17498227705799 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.180636268560534 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.246001568981356 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.283448769983316 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.28977703206656 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.30012968015469 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.3072743888054 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.338888526929246 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.34253285321173 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.35324567120236 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.036880258758885 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.3874195695533 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.3994089282783 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.040542351578807 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.41736283150237 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.51296542982937 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.52285490872534 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.52455364017368 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.53101632312313 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.53572066695682 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.55202358094366 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.60247366482196 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.63158547381761 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.66728606283804 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.070664503649169 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.745867535594954 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.75553751983506 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.79366323923866 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.81199904950209 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.81713568318378 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.84472694648068 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.88005598821708 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.911610633065926 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.913204220432306 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.920076036372805 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.92996303506894 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.97232218595795 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.97648161944053 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-50.98380761014607 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.023542692105 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.07499456606668 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.128677318379914 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.170552805523826 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.18679231350258 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.190546512739886 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.20075767646928 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.21250233518631 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.23972659214226 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.250217012969216 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.334440914846894 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.37672618627753 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.39420322707 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.394484051627146 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.4073376905996 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.41805943476561 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.44054749673597 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.50529183700661 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.552772143773986 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.66797376331884 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.167085717804397 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.678468048696914 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.68487737864673 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.68845241652669 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.70677393713488 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.780032877483386 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.82172939505316 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.182921432543225 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.83235356495446 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.84249275770936 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.880400838336136 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.909459805397454 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.192543994880808 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.932306763957435 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.93520048907114 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.96672469706969 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-51.97790204595276 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.043403426134475 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.05150375019216 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.08301250972072 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.11759227493103 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.2122720943507375 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.14459271428926 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.150475634083705 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.15768347868075 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.167823296768454 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.19812001230009 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.2092059882896 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.212082927634974 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.21798098713377 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.25348239679337 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.258581481035726 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.26041093771454 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.272268960041316 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.30940832598372 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.34823142876264 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.368615770542284 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.38419088530853 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.4223967840654 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.4278315102648 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.43379322313733 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.44549203596591 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.45707489953995 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.248080192896268 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.2505330054511035 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.51953459947967 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.582000601178194 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.59380808248868 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.264278034491639 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.664385820299174 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.76821038222155 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.83584421092793 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.8544235317252 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.85757989509132 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.8914527411235 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.89612689286998 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.90401145653318 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.2933885100724325 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.93927113549093 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.96763236198385 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.978761176025 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.99784565399983 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-52.9998301616522 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.012173561065666 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.02227891962295 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.02515440935676 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.02914082350731 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.03839239927217 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.051599999585484 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.072969049555255 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.312010690509325 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.1215303312488 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.12865857978035 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.134349365787024 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.14808089955609 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.16207426554038 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.185174913549595 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.21454525724856 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.220028642593455 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.221878092048904 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.2546226748837 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.26275778695781 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.26571297508569 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.26697128652924 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.282007710794566 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.28431326352523 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.38591281573017 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.392554192794385 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.39765797483695 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.443485499883735 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.45026950395759 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.45281659459182 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.47501338231395 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.3569181948388405 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.592382937526395 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.59638204386534 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.61610064898545 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.366324633524428 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.68867562440334 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.68928038962459 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.76132108965281 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.377386585288818 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.788606671803585 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.8145027048748 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.82154720650265 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.83315247293381 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.874913772562124 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-53.90752029857426 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.396086196266452 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.03318295067299 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.071077535055004 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.10013929730122 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.11168475224626 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.4112243817904755 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.169879831710865 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.24980810779589 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.25182751353326 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.25840805053927 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.3454299780169 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.40271207278818 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.41693065965752 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.42808071594891 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.429994146312445 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.463281273973394 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.46905701961422 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.470384432914834 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.48742215030349 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.520730369012924 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.52414441086175 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.556038093041394 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.57493844939136 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.638068351437205 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.65792365834212 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.664733361358195 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.67516016841951 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.69306538900598 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.69863000387332 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.47059194348995 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.471796120912771 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.720593012596794 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.473457211987977 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.80537749935608 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.810911189584985 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.82019103853555 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.872481622988275 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.88606028772072 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.896104641457065 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.492953088311353 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.97224260258666 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-54.999295836794815 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.00143693244266 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.005547707630086 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.051942817151 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.057978139774775 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.09172689650288 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.09298352314707 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.116228665911834 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.1381492641938 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.13847450595004 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.141179121483994 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.514768427878479 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.17941042385333 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.22483045065536 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.226255472308196 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.532818601578853 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.329642661335065 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.33458342508277 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.36563924285682 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.39476602567686 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.40240459800025 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.49052870528188 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.54783303014443 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.554038410958654 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.58491751791919 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.63432866194389 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.64765550141084 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.66041439635172 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.69076187282784 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.69367314836931 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.70372179184555 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.710272322000854 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.7384234868644 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.73915508814915 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.74840211581167 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.765611367506395 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.77036083529612 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.83077835545336 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.84619737486942 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.852156663529364 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.89835592952546 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.905745408494155 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.9245328458017 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.97547544742392 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.98321516133582 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-55.992247556425 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.011272606253826 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.03139997129028 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.047207694606804 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.051772964254454 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.6122770840400165 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.612509662074075 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.13516437964612 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.13990738071652 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.180185146151175 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.20443844075187 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.2426021617304 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.264096958191104 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.26878946773777 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.29345446803384 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.32196944491561 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.349353910316566 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.4562300949188 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.456488986100474 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.47518987102438 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.48477761307249 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.49006869627016 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.506450009011935 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.507731926349614 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.608160530804795 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.63479053910496 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.64284161464557 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.67518195861086 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.67654506129129 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.6722715164989665 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.76366851329191 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.79462963771338 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.806334592658004 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.86557042124323 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.93389673460594 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-56.96645747758191 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.70334490166853 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.033994429554994 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.70368121223126 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.06008517285446 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.08889235732839 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.1600180155609 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.18719674400295 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.18946053914071 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.19215742018584 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.23498919960572 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.25210477339267 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.279974856332785 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.728396876371079 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.310128303158315 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.3883689905831 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.38908923560078 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.450266129016555 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.7478276541029345 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.53073769027903 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.538723914735066 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.539161332610036 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.544886281298815 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.557588577848364 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.56780837252151 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.62504617169215 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.62561183233821 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.692610116125586 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.702096895717744 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.73200312789024 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.777388719666504 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.778876399333569 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.79016677217144 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.801916447167926 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.807662952765384 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.83072845071062 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.84929618693007 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.8557221241244 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.87780310296826 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.928472668977115 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.94331411535587 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-57.94979865127363 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.805818103618037 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.08138462680845 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.093444710066365 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.809532080397702 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.12101574618569 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.81255405273366 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.13463275846411 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.15805718127416 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.311172574998274 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.314302041231755 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.34081980523172 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.34585976326743 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.35027855154602 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.3615451147651 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.4000126838496 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.43798706575094 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.45778583207086 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.50057734305032 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.500685790704 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.51453578748635 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.538090961155184 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.54213907222183 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.55233152642696 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.5656840148882 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.57517342037046 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.5804630843968 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.62235320718412 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.67448143393199 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.67934187708022 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.690541684109654 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.7246031781022 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.76707190884169 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.77361625680422 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.78500755174154 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.79299357239947 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.803978117254196 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.83111907969572 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.885102677832116 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.9231237231997 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.92590438094856 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.97377138790824 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-58.99479615389649 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.903581316140858 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.03718127902222 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.06004559351257 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.08803315851077 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.11044627490774 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.12566873013847 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.912865431148546 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.14702859741902 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.14731020107982 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.20583694135717 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.23388069567921 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.234725117617515 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.27968634077707 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.29555273719238 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.33334626040596 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.36338075190528 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.383983909895456 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.390431857581035 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.45076343896834 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.46421681318641 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.46817202123247 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.472001400338506 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.519698198458926 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.550263252675606 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.56235725306753 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.61592107983134 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.63351790569551 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.63763226753429 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.66225515273456 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.67730532152324 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.67933254742883 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.68836802138298 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.696447790900045 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.71859625651872 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.75716817525618 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.779560900181906 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.791991258855994 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-5.979343347482313 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.90634944003765 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.91885118901352 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.95428181652749 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-59.993489271269816 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.001750312707415 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.05754288765892 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.1148401777037 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.139020168027436 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.1513296377417 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.15229656349532 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.261090399816354 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.29622340127134 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.3789037447497 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.401861883589206 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.41393216157127 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.48518947142971 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.48599974138271 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.515650496340776 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.51749555860848 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.53939390227183 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.558339338877886 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.58466082764254 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.61262255483717 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.63234357854404 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.67744877020749 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.68785939168735 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.687989085298156 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.722014930466116 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.72845020906996 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.74368226905622 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.746246421519665 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.758273574722075 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.80208888988121 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.08336107608207 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.86022883280127 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.09584594721197 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-60.98279165063065 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.01527932609687 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.02571786316424 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.052055447100216 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.06020378715669 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.07262502548192 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.125225395660145 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.129484585854414 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.14304627393041 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.18854043812936 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.19627096457849 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.229950157686595 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.23762787839313 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.124684476694313 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.30140439002434 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.305322527073635 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.31315024584192 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.33934804286769 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.38776414208205 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.39989853155057 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.41669308714071 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.50319889268354 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.53397142376591 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.54909957197323 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.59158047419022 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.59338545493065 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.595892397237705 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.63354677176498 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.70138698435797 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.7408216037264 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.178950829195685 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.79326205952238 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.80745939747394 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.816330046798825 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.84174277282506 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.85400874331175 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.85465539012562 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.186341941063105 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.88142286858371 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.91139855782277 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.919790593110655 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.944074278887975 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.96051038360573 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.963583788450926 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-61.980913619083886 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.06728011884699 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.136468910564766 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.1848604606851 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.230774621653026 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.261869269055595 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.26427193775643 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.28926552156333 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.30163061009459 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.36140365390443 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.37607468402704 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.40853038196696 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.41808869327503 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.24355414832354 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.45435535250912 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.4617084184723 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.46459342034056 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.471279806217254 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.47975477337426 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.2483807909663085 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.48408880809882 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.49642292124964 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.51253116727129 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.51264236012328 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.514300596699556 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.51487298097062 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.252653240376432 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.539736580182684 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.5435920130941 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.605997103013536 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.63165279055221 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.63216799213054 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.64268148704366 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.66574774754059 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.66920558584821 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.271761456266816 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.728020791990225 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.73099968831528 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.7336559685167 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.78102288753358 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.79353870713393 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.81102969634742 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.874972971565434 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.89630511772473 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.90937498052791 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.90989903961757 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.913787555660775 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.931679526242505 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.96831525918798 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.98652374737097 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-62.987347733422496 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.30826776400373 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.127685947307775 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.15910253183947 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.16081520822865 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.16618045601847 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.20017968761007 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.203722782111925 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.22000222004216 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.23653967406493 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.28006800268133 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.28100444565041 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.31385474719862 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.31525092898988 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.328967760075706 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.349390010632156 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.378290525905044 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.40216088003141 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.402413654494794 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.4220613197793 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.485034495485884 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.54742247769283 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.355278071561912 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.55424844695157 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.5576671589152 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.583680124785324 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.6615200917453 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.702193943228444 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.747432233900604 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.749396315807715 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.3750619314508725 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.79738601613063 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.80167999042294 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.81870931987841 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.822674603182875 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.82933215855875 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.8653252964789 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.87064797356321 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.871547104317436 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.877961520229064 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.957098164546224 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.98041849933742 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.981652401562705 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-63.99653654487629 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.404335069335104 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.0784923780291 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.0952751990352 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.10306785358522 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.12809265473149 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.13668150324514 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.14127128718383 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.16500164867685 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.17073636274031 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.428210590213212 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.30772222578173 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.312480864583 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.43368462435987 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.39212170510338 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.43419306808427 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.45153639002618 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.48383891327666 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.50178730790866 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.50506318531133 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.52446183421367 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.57638891414811 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.6037597123796 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.464952579618455 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.70388553621251 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.74652371113032 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.74725072825925 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.784441418905 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.79951546960842 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.83216507595999 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.83581892946268 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.8593327601723 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.489456334884025 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.95010531652187 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.97991660561442 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.9835176095909 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-64.99701687083746 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.00566845873857 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.05007637608733 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.10391827934087 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.11832980490013 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.14511838581024 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.1590712781102 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.161492959002 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.17626937271075 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.23697007556046 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.24179057528784 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.24582537327646 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.27659463051305 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.2816704543227 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.31257610985443 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.32069033388382 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.3357339551533 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.36285444833636 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.39245558346967 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.47038768960536 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.50045211738899 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.50149283650073 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.51977245736096 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.54638989226018 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.56362149127625 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.5776625904652 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.58072381412123 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.64259163965426 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.566352858799718 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.566805383395888 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.69866682623467 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.75394066156264 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.77726392352906 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.83009990462467 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.83939780695955 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.83973816142623 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.8537099414393 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.85463525077981 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.85727670725015 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.87808538678115 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.9607598362075 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.96799134724074 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-65.97442305288779 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.01590480120461 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.03880713913625 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.03892604951682 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.10867856527653 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.12515740770534 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.617743179582874 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.18539168661313 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.18888849290704 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.19222253784562 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.22418394518431 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.28416987616518 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.32575992050067 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.34729637398094 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.40225617483775 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.40361775890331 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.642100445523781 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.43122555832622 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.45437650270853 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.648094719821458 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.48327869511073 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.48347912212648 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.52577377672804 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.54646492090465 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.62575603319277 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.7090181984966 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.76738992790634 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.677317669018024 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.77726599459221 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.79117265572307 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.85922534169124 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.89667749783584 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.90126922159938 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.9130398982532 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.693226559776548 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.94089529967874 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-66.95517169831203 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.06643802622285 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.07592772143254 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.09199263552539 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.10015300086326 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.16681990988427 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.1949844779158 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.21440465544595 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.24866236138706 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.2920903450185 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.29939390290554 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.34272401137748 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.36122419292437 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.36446797292325 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.37706490885662 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.39150140364669 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.40766435737531 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.41186900322664 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.41605377950467 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.4382035267727 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.4656952040803 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.46742791210536 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.47970146034669 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.48611492738128 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.4883063730909 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.51679222418588 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.57454906334048 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.62988713461908 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.63057085456288 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.76476978247878 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.69015016338349 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.7014939167114 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.70493456809332 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.73569110964709 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.74436812384583 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.76603909880436 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.80604239013921 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.82431044587611 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.82985202604932 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.85305773129595 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.86288793885751 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.89480027141639 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.93692547951049 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.94102350792433 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.95748997281297 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.96438599516898 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.9657584991046 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.96768541885021 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.97309627784765 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.97483379409199 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.99129547618801 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-67.99133950832024 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.01186202094087 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.01193292139624 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.02046980752456 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.03295490192 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.03887063828623 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.05120500297252 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.05149007637097 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.06038156332713 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.06379201827471 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.15500663178915 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.18176061452199 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,68.27236433107197 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.30152197926651 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.31420321350237 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.43233793202887 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.43833933930013 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.45866948822461 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.46713955639225 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.46954562233026 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.49430073644169 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.855259258657014 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.56689107260136 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.60896845060158 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.64171426809085 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.64373381328805 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.64880389887718 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.69062470983285 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.6973808246801 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.71876535717132 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.72789776614967 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.73251708949147 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.7457139764231 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.78133183518243 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.80119127914668 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.81218074365982 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.81888762563386 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.84288685155585 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.86376272191904 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-68.87195475814809 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.01361774245666 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.02443547496573 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.02892244475207 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.903024459527046 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.908767790345465 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.10279164079247 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.1130536011253 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.1180176752844 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.22590537152804 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.2303460656132 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.25960039014637 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.26272033109761 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.28170108254824 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.929832844650207 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.29912530318687 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.3043384356418 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.38115495064288 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.38712115679368 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.39666950385296 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.39883910420698 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.42527782011436 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.50743802731132 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.5683459876469 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.59214450767892 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.59499088001752 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.62372701712795 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.67206296948913 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.73656736450661 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.81781674439162 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-6.983573964345254 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.85708797415032 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.92662745608945 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.93935665022471 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.94290538733314 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-69.94771917732373 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.00475714244052 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.00786665550851 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.02101695501908 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.0599860103741 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.08571657529899 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.09291112531852 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.10179812222134 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.10947281585985 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.12523037107641 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.16640302410369 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.18911553260511 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.21102610980489 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.21167187189472 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.24519075140873 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.25640827802098 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.26435609009229 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.28159818563788 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.29599944490938 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.030302655669061 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.37762262476619 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.38154159627872 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.39643579852054 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.39674313694202 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.39927495573686 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.43337927131716 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.44906559899675 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.46867540575343 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.5175312206574 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.52202844599869 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.54754622619619 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.54862970201093 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.5510805613782 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.56566218890201 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.56836238707717 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.0652941117624835 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.70536101110407 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.70813051944482 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.71865408618251 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.74643243600516 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.75732246399294 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.77217680286745 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.07728776169327 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.78757353100866 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.84672286423506 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.90280635502349 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.95120126192067 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.95411366123274 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.9556674823068 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-70.96765113553082 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.09968119303646 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.01892011856843 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.04079018593619 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.0548901462748 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.07211306964373 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.11543803168206 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.14014585675284 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.14239184650731 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.18714993701003 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.19001825568161 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.22685489395624 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.25895526655322 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.27300273781782 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.129760868842254 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.30070396071542 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.30486789351338 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.32703164987979 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.33636461767438 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.33683613085549 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.34290508845979 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.34704837327843 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.37928241740335 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.40599939100274 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.40647535139044 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.143586850181478 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.43663227494281 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.44790447831784 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.145439710323046 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.45599465059422 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.46025911280778 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.46189193948571 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.4730539077848 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.49985908897494 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.53369036839081 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.55776252433623 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.55862640531485 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.57204300825353 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.57231028170384 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.58669293290583 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.58756600079846 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.59085846029319 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.61874026262116 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.61989062118757 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.6300017465118 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.16316769082492 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.64036357003681 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.64724192035403 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.6685446841228 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.67865627748327 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.70507453350703 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.74252720173888 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.74730649373666 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.82134753154045 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.82135651531638 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.83696916837825 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.83786357782114 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.187459684457153 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.89382460208509 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.90646956165882 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.97154600080108 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.97794237973487 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-71.9951510016782 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.01057902557068 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.02968560360567 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.0468329861889 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.09174298811674 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.20048269245636 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.24513766036729 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.27201056983705 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.27911371171382 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.29302959272403 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.34551768760545 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.36232038765152 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.36514360206942 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.40922119828035 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.4419918367509 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.44456426386134 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.46122686236836 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.4641829228073 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.4819778366311 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.51739364537934 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.53026625869335 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.55339472646071 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.55960158562924 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,72.5901038113627 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.59209238327773 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.62013308799852 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.63070046577407 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.69330154266271 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.73212049768438 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.75276574622937 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.81622514127706 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.86458247329233 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.8742681753541 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.88075469320484 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.91815913076982 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.293141767415932 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.9636274263657 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.96651798681388 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-72.96678153311728 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.0015348956573 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.02744162997638 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.0428975093969 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.05642856966989 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.10522071667305 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.311681378717779 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.13371206410594 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.16583992935895 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.1971853907576 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.23897266787267 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.24054609259949 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.25986149800127 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.29485639151838 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.29848738449294 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.3054034435888 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.30733764899726 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.31493076448739 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.327322563338 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.33398096721922 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.34148235867045 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.38587678775934 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.42232243832605 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.44095356086406 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.45999407053867 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.50675728179037 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.51295305138319 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.3526269693051916 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.52911613695865 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.53491121425324 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.353901379842284 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.5878910644123 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.6250947908151 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.69922813009154 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.71484751624742 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.74932439921393 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.7810629933939 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.80509982155897 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.85714790814508 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.85727404138595 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.87774278298467 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.91920934604576 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.93611661937601 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.93828915136862 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.95992698826043 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-73.97314793024405 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.01409291782562 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.01437608812911 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.02636375036218 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.404681964638499 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.04800660264523 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.06105016298802 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.07094805330934 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.07272775469373 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.410094645616638 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.10457001929025 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.16077273186279 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.18888435173878 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.19775941738718 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.30264366442518 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.36665741153897 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.37380957063644 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.3931148995316 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.4256024262748 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.43318486204085 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.50442190831994 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.51643571862157 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.53110955372016 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.59780709376456 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.60942362543865 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.63801421699387 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.464883469610072 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.65248272458305 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.6771679944348 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.69791338025011 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.72123472980033 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.74829194706717 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.80328569744415 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.480915893364724 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.85881617231027 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.88261968110763 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.89268191491678 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.92898368428811 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.94186386711132 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.96503795465375 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-74.98883076384877 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.01445219395984 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.02896362884219 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.03151872631126 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.03812435996073 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.10725635022351 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.14706587818941 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.51898997317106 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.19279937543975 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.19441354187866 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.26276706340042 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.29847064858797 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.537734463119875 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.38050413631117 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.40005258017362 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.45519642856848 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.47198866792779 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.48467468943254 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.50593966827266 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.55427526087286 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5576465089516 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.5679500188798 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.60517981083059 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.61493519136819 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.67278847186994 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.69671529606737 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.69778012824291 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.72610366164747 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.76069531923932 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.76249793601231 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.79091250352114 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.8115536640592 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.84687985457366 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.8508418287091 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.85600480847292 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.86359872871056 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.8840094104042 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.88438959821637 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-75.89674870600909 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.00797670020603 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.02733549526326 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.60321638423396 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.0532340782785 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.06777478121208 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.06814212244223 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.08675636468743 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.09384662895292 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.12864529567494 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.14891581567741 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.16305246816461 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.17611557016815 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.19346324418537 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.20280755564619 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.24349240749419 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.625880410019988 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.627867493205983 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.43114813161213 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.43452915416356 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.52202843858989 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.54237950101583 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.63644476783247 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.66189379636657 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.666242871791368 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.67810484526802 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.675711774523933 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.80074417353433 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.80212517639025 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.8133097954293 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.81537910676022 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.81547609081903 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.85022643804014 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.85318898226083 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.85470191144366 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.85584469101283 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.90683307063068 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.92918632219474 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.93173267090137 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.93205081780769 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.9457208671152 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.95601164610058 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.97497862676911 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-76.98772727454828 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.699243461114307 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.01196164707873 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.022609319227 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.06311348838715 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.1099287572637 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.14197525834025 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.714406373266087 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.14877147415409 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.15574420535287 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.16245158413138 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.17616288381275 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.18032571945157 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.21334271462668 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.24532542990585 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.332871834184 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.37864290624337 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.738304345550546 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.38325583137797 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.39522500838869 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.41198265435196 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.48059004389532 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.50205084164975 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.752377940020239 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.56948702993927 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.5860878989265 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.58872110123008 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.759177207122178 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.6181499872961 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.64117628088039 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.68801235640497 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.69567366154722 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.771251103202687 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.75155529502725 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.75962793501449 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.80214279372906 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.86900092574348 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.88865251500397 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.89231387261543 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-77.94996355460322 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.0854229778343 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.10603678315438 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.13794986141565 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.14519221423856 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.17962054809357 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.19345195002214 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.20132027392803 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.23291693182821 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.826288915776942 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.27159000655556 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.29670966977274 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.30315393238985 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.3310528637992 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.33702842018064 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.37001450222492 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.45392529044169 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.4739649094851 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.48768253606593 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.5422942955599 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.55972366768651 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.60710324265783 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.63130089921148 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.64322385646459 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.64953738184425 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.65811167066248 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.66268268511692 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.68774822450466 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.71068616778756 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.73280707227674 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.73833777592417 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.74278355172078 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.74787588333636 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.76680496267672 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.7939223879217 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.81922267877972 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.89097185541834 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.91347971970063 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.92103349861661 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.9276015436174 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.9357681265552 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.937342150742 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.94760100528353 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.94760804795558 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.95032639360167 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-78.95856384114902 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.0121629019078 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.04500092976042 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.04930242472793 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.9086725088505005 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.14837988780658 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.23214411524621 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.25408066151572 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.2704057081741 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.30988022855827 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.31494318973978 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.32641985358572 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.34698266593165 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.35799187577446 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.38181429805333 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.38582888800481 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.41869402141674 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.42132371884327 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.5095859356536 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.55635508883441 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.60773884452101 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.63050509141894 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.66833835051501 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.71713733868502 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.71830034785617 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.72027331680988 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.74973570601915 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.81500435163089 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.86926054554482 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.88702369942771 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-7.988735616320298 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.90189363768272 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.929415016328 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.9372628448235 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.99059932555696 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-79.99633848467752 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.051221854469 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.08225445379921 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.08681512269115 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.10020914468686 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.11992583591422 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.12048905821214 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.01607936821074 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.19254708522826 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.19735072871012 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.24818968817434 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.2488193735337 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.25844501558579 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.341475276547 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.35114538661996 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.38824161395783 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.043183339246497 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.49174601357471 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.5223252606892 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.53080028390569 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.53198266387736 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.57146094949981 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.61191557699226 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.66061745566297 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.6901363248159 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.69521917594608 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.74720323368214 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.77881020048628 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.84130936441206 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.85087624126493 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.90452280036071 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.09345782484246 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.094660575625909 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-80.98077948215928 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.00911331673015 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.07551488670694 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.07956526872073 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.10932094169905 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.14152635491925 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.15782445355262 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.2028640073053 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.20953131113666 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.2273660577189 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.24189560416218 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.28408093091232 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.29729952122528 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.34919853329119 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.135527879526379 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.4066491527297 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.41982522085945 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.43034492771217 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.43723569755119 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.4479589030563 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.47408507685137 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.51982074813687 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.52277954386571 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.57102439596878 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.57598001699284 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.59997484163218 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.60612897878327 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.61399882814317 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.71339999220521 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.177619145569494 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.79988114845628 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.812699455308 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.84382626554063 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.8457396309617 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.86319942913589 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-81.9185420344189 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.03326133204412 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.03396681712054 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.08684684604816 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.09701342125155 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.12330606187884 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.13152359412537 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.15815704907283 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.1686473277531 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.2087173470749 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.2181097513213 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.30717138158334 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.34178377908749 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.34521025038705 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.34899594373897 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.3632973409181 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.37743167089697 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.46872525463817 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.4727897289157 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.49588219873993 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.49704174206104 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.4983009685091 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.51429133621912 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.53048311702804 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.53915555017583 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.54851644740178 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.259674839698562 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.6011124476289 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.71873409238182 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.73041927725217 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.75556215799453 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.84974618525342 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.86289606335235 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.88755775183625 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.291471453825324 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.91825532866577 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.2935764584047 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.95482809951497 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-82.98530137103846 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.04446388694981 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.07506734731248 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.313840132896885 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.14150677226024 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.18677857042091 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.32902940067082 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.29443101114506 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.30428939354597 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.32373584596225 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.36322929515106 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.36775268494267 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.3727733200436 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.4011326112282 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.42748889806086 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.43968242220885 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.347504890727848 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.4938169359308 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.53615320741818 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.54667430819147 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.5473276529998 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.59313972452496 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.61649487908113 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.61658020668219 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.63967868039117 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.66843764465959 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.66904953238202 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.70143302619664 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.7222553915378 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.72718869013774 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.74517331526737 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.78742322872037 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.8769896996848 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.94102326007888 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-83.94764227082905 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.01101069857239 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.07389928064761 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.10682609398997 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.423511108297816 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.250112679444 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.27275650617885 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.29059668612867 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.429448222766084 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.31051336810378 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.3156873925299 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.31910797124449 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.42543456580862 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.45294300924355 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.4613745810176 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.52039878753794 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.52069288019548 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.52149847713686 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.59169782080873 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.6827229865081 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.7422113896462 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.75767299701657 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.78335258820113 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.80712765183111 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.83766644524064 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.85345875077539 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.87426510666828 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.91262304942502 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.98775383658261 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-84.99483726646942 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.07472879964834 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.0776597320697 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.08291249302198 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.09375879039996 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.1255523057781 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.16074906100621 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.16212774675031 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.22140085679489 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.22945532100866 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.524803938957177 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.25460476998819 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.27826854581038 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.2783898801669 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.27925182725329 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.34761151088676 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.35344015269699 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.37729171902883 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.39999158257183 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.53068912695849 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.55856298669417 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.60413735516795 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.63942858473794 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.68415445403541 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.571710587885434 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.73183859165599 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.75110333287381 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.577730688880195 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.77898394337123 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.80905722515448 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.8223299378329 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.82418091961226 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.584760942039921 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.89806569529954 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.90700122504144 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.591126539010219 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.91717879863951 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.92397087201158 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.92739788829762 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.93040194307517 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.93274879161832 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.9334208861743 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.96374295035345 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.96911766849134 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.97898688078772 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-85.98300536532916 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.02011779289556 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.022401767872 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.02566355043382 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.04984864068552 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.05293679027352 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.607065137486842 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.08723999598658 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.0892092900089 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.1205369262409 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.12483883980107 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.1343509224199 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.14654057600472 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.16195149683337 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.20419995774382 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.20573466658104 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.22019676941406 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.22828412816297 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.22986447906315 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.27603103149808 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.28132107132353 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.31830222292945 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.32794848879163 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.34433060641351 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.34968455646181 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.35903787258322 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.635977435296766 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.37916509425965 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.38251403288461 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.39112325238096 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.39652393604989 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.41493552133137 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.42144741182001 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.4386486010404 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.44189323480438 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.44444346691813 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.44653624182399 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.46983479254419 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.47045409902113 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.49581644087607 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.49727372065739 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.5178612478884 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.52365173273503 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.59996205072727 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.65068561755584 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.66377887412563 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.68372211755619 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.71135836947734 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.7467771704637 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.77833322348025 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.82287382491054 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.8505903780998 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.8991640640897 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.91952108698588 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.95900220659021 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.96158549509359 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.98430827477257 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-86.99469108343747 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.04067094915588 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.06182539030381 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.708299863783054 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.09681100531988 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.10963892835117 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.711573937516832 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.14975488710533 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.17185540651155 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.17279245378909 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.19631566889502 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.21808646829396 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.21979163385221 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.22821571572517 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.23234572408217 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.729341697510051 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.33523237229835 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.36536999382062 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.37503950399237 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.39644978990763 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.45858485672086 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.45914212039196 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.46888436477877 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.47644437803581 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.54146716633892 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.54590645670339 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.55882230269216 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.57134923695003 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.59981082574777 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.66955725440768 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.6893325914828 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.69370091064212 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.6967566869405 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.70998420600407 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.75289951550516 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.775937265175116 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.76404073190092 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.78756146811189 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.87012126497207 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.87747154776677 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.88468772664979 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.89399414811223 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.790299324998713 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.90979641341916 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.94760541948612 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-87.95563541681837 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.08237741824207 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.0895415614813 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.11784082819743 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.18534952634704 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.21839827183611 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.826616705587782 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.35905583254835 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.36067518842334 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.838452120592066 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.38747834165066 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.46915310527771 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.48006734169604 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.48220693611952 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.5301137190331 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.53117109163156 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.54849006985555 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.57190373976019 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.860756604511295 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.61381378394773 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.86239577626111 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.7078134045801 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.74920747864716 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.82286883180201 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.82995651981689 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.8435777374591 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.85396976237585 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.85949495239818 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.91490664312522 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.892810900345012 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.94395066309482 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.9680419685253 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-88.98958740865291 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.01967963132668 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.05735493921092 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.05904415484602 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.06456112233661 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.12643673772287 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.12953537422557 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.14209828642478 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.14691815719638 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.21764450595946 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.922665209972294 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.2268401006517 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.24636793063559 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.2703171612542 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.27229696207255 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.29304670107736 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.29388021021644 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.30954479607063 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.31110368078473 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.32335507973043 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.32488474858411 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.33720603161296 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.34717677344786 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.34882383066684 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.38273978413984 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.39577047498501 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.39966358759548 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.40431940804841 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.44421719364605 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.464893636516 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.48312873463651 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.949707669736355 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.52595821728036 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.53210392460397 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-8.955136685407481 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.55427697382873 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.56366888946982 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.58838659017599 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.62916758589733 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.65063168426666 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.67458212303954 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.68964412661458 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.75148172082939 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.75695977182987 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.78362190439628 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.81416312893423 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.86755813701888 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-89.95375714330723 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.0133639470996 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.01806331517443 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.02661864201123 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.03010291180544 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.08356074540168 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.12832283663046 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.13742415241313 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.017843115717383 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.24348978602197 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.26754260110246 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.031031735194034 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.33450878564724 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.33638790277898 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.34309213188041 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.3685496904834 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.46038165209806 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.46677289684666 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.052189955342385 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.5313733135845 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.53585106019099 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.55650977374302 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.56735223738454 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.59912301151046 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.60782797094211 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.69743313940377 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.72874170991534 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.81046000228787 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.87241217444699 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.875575623052 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.88034612222344 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.91483407320813 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.93659438665655 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.097069135503816 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-90.98638813434137 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.00742545171379 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.01413186295564 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.0497469037363 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.106770411172008 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.10719672205991 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.08936723197894 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.10598931114735 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.110810828310775 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.112084469908169 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.20204957271902 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.2114640681984 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.314448206999 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.31462157774979 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.4085846930256 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.4276702327353 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.49991086936973 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.5301641194582 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.57155640977643 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.59514406017388 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.65940589267703 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.69727882329717 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.71962145946861 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.74198599688155 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.75204139560414 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.175314870477024 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.76439913149875 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.78422294836277 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.78881449624798 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.82592275275867 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.82867053013901 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.83056388726713 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.867440900397 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.87251992935225 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.87691990661648 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.88021890800042 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.89917582754572 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.93105825219574 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.95714077315034 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.97972418999714 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-91.98322405904045 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.01285420214143 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.01581738302632 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.03031429517365 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.0653766508228 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.06789427654023 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.103539010131 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.10773550510227 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.14921979263676 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.1675229710909 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.18991672564938 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.20911487607259 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.21563199336069 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.2243210223457 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.222477636223658 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.23966969371307 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.27376697283837 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.29038949445349 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.31732966155765 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.35471042021655 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.3557748547186 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.35738103806388 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.36598670339104 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.36934960600888 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.38499607936255 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.40552709890098 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.41150764040849 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.4325859586427 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.43699083288168 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.44065373937813 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.46108199967674 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.46375275687842 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.51884867643658 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.53205715987968 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.54131283184479 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.54407691947513 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.254532742810099 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.54579077591616 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.5647984517937 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.61763899403041 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.65386898974701 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.65832173591303 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.6996083123055 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.272497711218122 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.74052322379458 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.76468708876155 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.78432995460837 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.82722536514791 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.83980405948424 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.86856301181483 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.87158131160086 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.289048651233983 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.89100956397417 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.898931192872 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.9040454783809 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.9312696781347 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.94734354727862 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.296395857525042 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.97603761504358 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.97951837195339 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-92.99083329194143 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.00539941386903 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.01994408647012 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.03429457244499 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.06115404814967 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.06790111437078 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.14131710928821 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.20280461795124 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.20466090051924 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.20654397300908 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.22388607923564 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.2629090587952 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.26663184647788 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.28316746968895 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.28630507715152 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.29038250159823 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.34837689746116 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.35276409388484 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.35716250894961 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.40175095157308 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.42554600522493 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.48168037882407 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.51507988958167 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.52242199538432 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.53569165620077 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.54699119698138 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6583643420666 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6897427302617 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.6946977049699 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.70421190467431 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.7049160522667 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.72099241415668 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.79198454545019 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.83145110437016 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.83824412779158 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.85306228249802 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.385750896646599 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.86138848785157 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.86358949638867 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.86555211468195 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.88673608587865 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.392627480730027 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.92963633683486 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.9306661373454 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.93647817508742 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-93.93785461298943 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.02462988218801 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.03728582769335 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.06520404605732 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.07710122009317 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.11803463962953 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.13226304235923 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.19330698248277 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.19575754718646 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.21884560585039 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.22188255575328 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.23202754178368 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.2795980958105 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.28778987465192 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.31824187211812 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.36107564582346 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.3630045178578 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.40014906020436 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.44068810858954 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.41524422252496 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.41941956256561 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.49765825194186 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.50898982581836 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.51764995572923 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.53082255413649 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.55063485989234 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.57600788234559 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.57750845398618 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.61543015175293 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.6327628482811 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.6598639386553 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.67177309600388 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.68574647159338 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.7041924721227 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.70663709220784 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.74002877307115 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.476140039651256 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.78006790269076 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.78996244554962 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.80823904328189 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.82437333724609 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.85874074287072 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.87758923565876 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.90627745740147 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.9085411528261 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.96887701963732 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-94.99950500304992 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.07501386439226 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.08805392949714 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.16690992006305 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.18811271316603 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.26758676048344 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.27891137714705 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.28520188106428 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.3204985945616 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.36344672424867 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.3675478870177 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.37533963749891 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.54203333583027 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.54463885315236 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.54722823178989 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.6196203432822 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.62848487466135 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.63534501110351 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.64114642874424 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.64244431678945 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.67591423511486 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.67758703853333 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.569544438356402 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.70323590962686 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.71531474728145 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.81554076241542 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.82464858949781 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.82787904859482 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.85905115564701 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.87123564476931 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.87705340363802 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.89016775074435 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.96172745766889 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.596569034910289 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-95.98677830847167 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.02187259413537 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.08737936210288 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.09777978819933 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.1107079953575 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.12208616091678 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.613660572357702 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.15142251695907 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.16087807823435 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.1958834597067 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.22714271323416 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.24219942433663 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.25799772414427 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.29542569531023 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.34458493344617 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.36289799668725 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.37624544317538 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.42587114958643 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.4376097871088 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.47412871471471 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.48660406147569 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.50013478414007 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.50874764361983 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.651405594157538 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.52451942161582 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.53208674288354 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.55335563574911 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.56008594397738 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.5679839465142 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.63567234646936 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.7424703632056 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.76400684106699 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.77725194032601 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.79476503448944 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.82977103792656 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.8678295927969 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.87152561693908 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.89539000258756 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.91004584845284 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.9403526493795 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.94342397169564 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.96681204358497 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.96752203013648 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.97013105533578 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-96.97374023971501 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.02608683082192 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.02613721978655 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.03726147128826 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.704197023024477 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.07899247750453 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.12691795924147 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.13050216849255 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.20659119482629 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.20841822021984 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.26452743594373 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.30502968759012 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.33451916622029 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.37642706671193 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.39667712789333 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.3986465965214 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.49623222056259 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.53174689341076 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.763352274081669 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.69980862804708 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.70519020759131 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.7457816932564 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.79495401117649 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.82403064139199 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.91659664804926 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.91710877827396 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.92260274841473 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-97.92917922146647 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.0275259103129 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.05246014533581 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.05710450159191 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.076932631661 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.11375009911703 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.13142820282692 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.13149934631937 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.23031334923505 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.25099077504677 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.26984313359546 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.26997476614325 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.27260552397664 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.29538559954915 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.31033749301557 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.38685197386852 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.40092584442988 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.44211838793102 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.846124769721712 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.48349002285278 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.52584659046899 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.55623598457761 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.58764483607541 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.58998215530626 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.6160843384985 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.63661601586074 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.65469727947647 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.66174035484887 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.66738254395048 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.6713059354558 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.869281088471709 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.7080807235361 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.7095793536638 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.7962499418338 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.80070542264183 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.80251331995377 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.80559646358836 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.81983957084014 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.86775154597578 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.86809201094273 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.87263665812809 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.87907304655576 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.95173827781458 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.96002846509191 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.96906042117237 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-98.98698597503906 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.00926295982997 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.01018449822938 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.04538343561957 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.906278159301124 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.09951247559985 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.13318292504194 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.14777775077084 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.1909474948099 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.20875938660485 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.20886387186269 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.92221508043572 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.23086144948523 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.26508245401465 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.29856521190598 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.35017576455482 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.36873952854451 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.42117867006948 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.43367587893131 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.48005122092654 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.50107587853508 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.50693737783078 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.51019593509385 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.55417724360274 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.61473213527343 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.6457835746189 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.67847477830544 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.69476176195433 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.71140915180614 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.74956090665927 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.78554940043169 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.79635066998138 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.79911985955081 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.80626701882507 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.85123178215723 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.86235565574609 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.987188392824791 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.88714601839324 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.90163488421342 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.90834298409294 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-99.9677322924621 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark36(0,0,-9.99741827852823 ) ;
  }
}
