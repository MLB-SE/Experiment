import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(-0.0010551998438070136,-10.268107649605795,-1.5707963267948968 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(-0.0010925416260476606,-17.078177952597983,-6.528616023998751 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011082215990717876,-0.8316497904129293,-82.69704085373897 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark05(-0.001114473166872864,-1.5707963267948966,8.103850378671073 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011608550746642966,-1.5707963267948966,33.61975677827788 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark05(-0.0011919106195560358,-36.11453698542509,-77.11170741286168 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark05(-0.0012463495427266933,-0.7455519941365887,-52.34125610423541 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark05(-0.0012856104694760194,-1.5707963267948966,-96.56953798950747 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark05(-0.0014576518744765525,-66.63991981179086,-68.80105944862731 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark05(-0.001572817937411486,-103.7224005865273,-1.132446483393318 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark05(-0.0015801606934088858,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark05(-0.001622974839134013,-16.9078064849108,-80.8767343769719 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark05(-0.0016827539333335688,-0.18841002618179253,64.16113850513126 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark05(-0.0017178095970835506,-3.1728426535897936,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark05(-0.0017402423776057949,-66.46022782255415,73.56705786848283 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark05(-0.00192771149258272,-22.484993140050236,32.90009196894438 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark05(-0.0021230099848611114,-1.5707963267948966,69.01062090091251 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark05(-0.0021730409339196354,-1.5707963267948966,-4.199067582250814E-16 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark05(-0.002259017300474479,-92.41091238196302,-9.487277965091813 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark05(-0.0023480919149089317,-34.8334846470631,-75.39822464021181 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark05(-0.0026092498268134867,-9.51341967875997,7.602775124266497 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark05(-0.0026449492822800485,-3.1420809348400662,-100.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark05(-0.002661426386064097,-3.1415928980657064,21.80528873242822 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark05(-0.0027687194451781467,-1.5707963267948966,-80.84384917295043 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark05(-0.002813271642302717,-16.343323092386434,1.5707963267948966 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark05(-0.0029675674588994436,-0.019336718022397417,12.642056385249532 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark05(-0.003048379089181443,-92.14431043637458,-5.661238441790925 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark05(-0.003080759411025036,-3.606632272572553E-130,1.5707963267948966 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark05(-0.0031758728623625747,-1.2204879580969519,-10.973205923629166 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark05(-0.0032152394694916356,-9.956207528351541,-8.907930686718647 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark05(-0.003257248677121748,-66.09110358031094,75.88585246272532 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark05(-0.003262091658220446,-0.4516957618758225,8.104186518612085 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark05(-0.0034632056821966156,-0.5847731370474433,11.152158606955654 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark05(-0.0035159728515847797,-3.141592653598583,1.5707963267948966 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark05(-0.003569603346916002,-92.03955701923134,-1.5707963267948912 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark05(-0.003612692198638317,-97.3973800265455,-65.1658903572996 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark05(-0.003660447597881797,4.141592653600965,1.5707963267949054 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark05(-0.0037783614910125995,-48.48916540249229,60.176477428344946 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark05(-0.003838892891371168,-60.82668267004641,42.568073121455036 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark05(-0.003900398694908155,-54.14012104407277,1.5707963267949674 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark05(0.004031075664103879,-91.19462437645655,-13.522729415835975 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark05(-0.00412882313715042,-1.5707963267948966,41.215789555346355 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark05(-0.004170049772632328,-1.5707963267948966,23.854065478199615 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark05(-0.0041725815294920265,-1.5707963267948983,48.02915753614064 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark05(-0.004250962175769413,-66.54300959617872,-20.66980867411558 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark05(-0.004334650592262782,-23.489049084300504,6.283185307179591 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark05(-0.004358481358200383,-34.731899880053746,-97.8326082293306 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark05(-0.0043635544882175805,-23.56076840113963,-26.80180297425884 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark05(-0.00457539973182989,-1.5707963267948966,36.06780938037477 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark05(-0.004768096814510683,-1.5707963267948966,-0.4744288486249456 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark05(-0.00482538480502423,-41.33135400097403,-1.5707963267948966 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark05(-0.004866659095662418,-6.938893903907228E-18,62.50718161117074 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark05(-0.005073748342775743,-72.7834969423601,90.89258635241558 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark05(-0.005092825711188475,-1.5707963267948966,97.463932928296 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark05(-0.005104591832757355,-98.85204959602746,-72.02884088164838 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark05(-0.005159774326059009,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark05(-0.005210105910392837,-10.873035724080538,-8.10398172048774 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark05(-0.0052185845237943465,-1.5707963267948966,-4.712388980384924 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark05(-0.005227810404382421,-0.8102859823182497,21.83756948155073 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark05(-0.005278240639256637,-450.68780299464765,-1.5707963267948966 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark05(-0.005365226981522676,-66.5194510809186,-20.37264292467345 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark05(-0.005372142360938287,-230.52064185608654,1.5624309176393374 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark05(-0.005457740258296564,-103.67256228017116,0.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark05(-0.005473486233905768,-16.151760065358136,-48.51154475790893 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark05(-0.005644112729099839,-48.67460910854668,-0.19472062516009245 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark05(-0.005662621319832125,-0.597918973441624,-75.96249443474397 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark05(-0.005676351194914497,-1.5707913418581712,-119.49236885545056 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark05(-0.006122463650610094,-1.5707963267948966,92.08013765112996 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark05(-0.006142408836161007,-97.69346590716417,1.5707963267948966 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark05(-0.0061787196180685955,-22.055519456300324,-1.5707963267948983 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark05(-0.006246637031934234,-9.575303140854075,32.90730778082795 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark05(-0.006280113682889005,-97.42941456192715,72.86817550507524 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark05(-0.006292745511297601,-3.8703343848236584,-6.287091799778415 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark05(-0.006325194590337396,-28.37573950424247,1.5707963267948966 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark05(-0.006386711091073031,-66.99646064236892,1.5707963265784897 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark05(-0.006574912205108334,2.7220028776537053E-19,90.86682257814584 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark05(-0.0068255620201679015,-1.5707963267948966,1.1775900480927137 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark05(-0.006953075144874476,-135.11366259674503,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark05(-0.0070410949103436515,-1.5707963267948966,4.058035228607931E-15 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark05(-0.0072724204348790225,-48.26519329713712,26.185653475633362 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark05(-0.007310444456769474,-444.535360469182,-92.27097704499626 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark05(-0.007772118310455878,-1.5707963267948966,-69.26035164333825 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark05(-0.0077975268842322976,-1.5707963267948966,-59.547103675781024 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark05(-0.007857440876083992,-1.0338123709651685,0.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark05(-0.007858688343470217,-1.570796305226704,63.22269138628465 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark05(-0.007924490700291997,-0.17622076056869435,43.215012534637424 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark05(-0.008237790025046302,-10.906638432699715,-14.852678756415088 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark05(-0.008241530593123459,-10.956048123302551,-98.55929801057654 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark05(-0.008380954601159387,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark05(-0.008382489384460928,-61.10391125823512,-7.85398306433319 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark05(-0.00849211207619998,-0.04452115743465024,-5.9551612694604055 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark05(-0.008717306532504132,-1.448803452118952,-6.091469220332584 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark05(-0.009127265045947953,-80.0691630721064,-20.824418936311705 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark05(-0.009219677952660635,-1.7763568394002505E-15,-20.58803123022875 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark05(-0.00922511771203438,-60.08707180315537,-51.9161126756112 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark05(-0.009240257819413955,-0.28792590678875885,42.687963771830525 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark05(-0.009319919120892778,-41.62777517217634,-79.0043114415851 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark05(0.009467475495901809,-85.52600285069337,-95.7226416281109 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark05(-0.009533335428862618,-1.5707963267948966,-26.5684476302998 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark05(-0.009931785981684087,-1.0636470268188034,72.65414483152188 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark05(-0.010142186509421358,-9.603980612049547,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark05(-0.01017960632070678,-1.5707963267948966,10.252349495556622 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark05(-0.010247389333440125,-79.23288473739343,13.49544587710313 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark05(-0.010778836741571181,-1.5707963267948961,69.71019063224988 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark05(-0.010959225661567817,-60.482582175132734,-154.92286245268565 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark05(0.011094422635432744,-1.5707963267948966,-26.02544137777461 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark05(-0.011195141039367269,-73.82497840471274,-89.69527944589831 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark05(-0.011464031071471845,-1.0339757656912846E-25,20.83300799400491 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark05(-0.011549323856815142,-47.3255135100755,4.141592652019172 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark05(-0.01175226913167686,-73.08862974706283,-96.5486820857746 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark05(-0.011818702380120302,-73.6006041634704,-20.77681740128598 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark05(-0.01193420284632153,-16.3667207232917,-100.0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark05(-0.011949254817930424,14.429210010550207,1.5707963267948966 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark05(-0.01197973223517675,-0.10786939371196091,36.31564559172439 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark05(-0.01200454244346189,-1.5664413532888342,-2.1450366265746874 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark05(-0.012216933529480025,3.143545930389591,-48.557240026045754 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark05(-0.012223791975254052,-3.2870876258637196,-21.484534860944304 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark05(-0.012266290966797705,-79.62164953196567,-20.845203092006066 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark05(-0.01239677250214161,3.1494051538122543,-56.06983715140076 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark05(-0.012398687733296915,-1.5707963267948966,-6.536310671075384 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark05(-0.01258490504926822,-1.57079634308837,-6.283359640249013 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark05(0.012874675735880544,-85.42274512734372,1.5707963267948912 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark05(-0.012987274463992587,-1.5707963267948966,25.55412345424323 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark05(-0.013754147371331795,-3.266592655727653,1.5707963267948966 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark05(-0.013900536112864036,-10.760747493529935,-91.95724400481544 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark05(-0.014106533063339812,-1.5707963267948966,-0.14203019424723679 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark05(-0.014332894062835194,-1.5707963267948903,0.0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark05(-0.014781790267520746,-1.5707963267948966,39.148512003963255 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark05(-0.014840382686720442,-16.149630941846944,0.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark05(-0.015118117141397823,-1.5707963267948961,95.03546764159887 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark05(-0.015257432039414542,-0.28353911927255826,-1.5707963267948968 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark05(-0.015407524242587955,-16.14355708030412,119.23714116041549 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark05(-0.015528469642401092,-1.5707963267948957,0.9779720055560422 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark05(-0.015602329975550056,3.1415927009286055,-0.07958175801648848 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark05(-0.015623542897556852,-3.1415942825104883,37.894415005692004 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark05(-0.01571151196466719,-562.7147152748114,0.2700141646072609 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark05(-0.015790318042337232,-3.3684520583680584,-1.5707963267948966 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark05(-0.015835730497726967,-35.98558845581862,-49.33803384506329 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark05(-0.015872903274114884,-1.5707963267948966,-21.50452831901302 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark05(-0.015949189570058645,-122.97415276412005,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark05(-0.016125438863381945,-54.89155585369805,-0.09414962686655813 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark05(-0.01614972769398099,-73.03853779186784,-1.5707963267948966 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark05(-0.016160196659827784,3.141594592404781,-97.52861300722013 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark05(-0.016375106933780595,-487.33780211582945,0.20582012816600326 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark05(-0.016467985791767406,-0.007921459012394931,-42.931597467744126 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark05(-0.016719406270229165,-0.15417063374417667,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark05(-0.016884597009177188,-1.5707963267948966,90.91392714843454 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark05(-0.017026804843939827,-557.2827929586031,0.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark05(-0.017195486974723003,-1.5707963267948966,20.420352248333657 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark05(-0.017331800660669482,-1.5707963267948946,-73.71261185122242 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark05(-0.017351839267710976,-1.5707963267948963,1.258318498817246 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark05(-0.017510376458794497,-66.9758425676524,-176.3730061569901 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark05(-0.017518245372014907,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark05(-0.017528992808819255,-1.5707963267948968,-4.7130256730811375 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark05(-0.01802881658702113,-1.552528061928399,18.389659399199942 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark05(-0.01810799540824821,-1.546479708205212,0.6329588439993648 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark05(-0.018168145762555224,-41.88972012784576,98.86239518197456 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark05(-0.018232239190983997,-1.5707963267948966,-20.022648899823814 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark05(-0.01834113096098901,-1.5707963267948948,1.0339757656912846E-25 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark05(-0.018609316395920894,-3.1415929233821966,0.17665737463543102 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark05(-0.018975598927779683,-1.7763568394002505E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark05(-0.01932703132458228,-29.185728597341104,-95.2550402943042 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark05(-0.019657032087494253,2.430478354346165,-1.5707963267948963 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark05(-0.01970336365060825,-4.18212111724368,-0.34288633811453534 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark05(-0.020101685204225728,-48.3479398353994,-1.2609435897536376 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark05(-0.020217421251987444,-581.8296301729201,-1.5707963267948926 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark05(-0.020242091190692722,-66.23289805957525,26.859160396313587 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark05(-0.020263059713636778,-0.04367805528320501,-69.91940217965913 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark05(-0.020425221135774385,-91.8224553115385,-54.2716388685665 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark05(-0.02054489350120614,4.476894842601489E-18,12.832382684871504 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark05(-0.020599794710478757,-1.5707963267948966,-50.26695777695524 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark05(-0.020671151227446942,-23.06682470981146,-77.30563381439815 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark05(-0.020707386207373557,-3.1494053574897145,-1.5707963267948966 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark05(-0.020988990637876265,-1.5707963267948966,10.437179040850964 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark05(-0.021101769805641372,-1.5384515085046864,20.45236229309127 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark05(-0.02131867377807249,-1.5707963267948966,64.39645363231028 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark05(-0.021403404467286558,-34.79213780887952,-1.5707963267948983 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark05(-0.021541368160908802,-15.912687879509862,1.5707963267948968 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark05(-0.02156399577991246,-41.410479064893224,-3.1430144693274777 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark05(-0.02169524762628979,-1.5707963267948966,-1.4072957247369797 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark05(-0.021917138838746575,-53.51320631528921,1.5707963267948966 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark05(-0.022174863328787486,-689.5547643569997,-135.86148036442628 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark05(-0.02217840514696003,-47.228268927745376,-75.50432317482796 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark05(-0.022234216532669215,-1.5707963267948961,82.36219409907491 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark05(-0.022367878490128446,-1.1660976134542522,42.57166881277776 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark05(-0.02242141215423299,-0.21629498278978498,0.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark05(-0.02247199262104746,-97.66749294394684,38.086884676469225 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark05(-0.022483230513398463,-1.141025041685639,55.410983683034814 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark05(-0.022789443949165475,-1.5707963267948966,-31.956555460333472 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark05(-0.022831446071736,-48.07479152640728,-6.513347339018037 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark05(-0.022861591898880852,-1.5707963267948966,73.07169263551813 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark05(-0.02301316946318675,-98.23080931664727,-1.5707963267948983 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark05(-0.023093549853995296,-0.11086746333707385,46.097193796921495 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark05(-0.023209103569338585,-1.5402927423046675,0.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark05(-0.023445563017097326,-116.26417158697376,76.57257545259928 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark05(-0.023514553433914592,-3.142081311418772,-1.5707963267949268 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark05(-0.023776499242653362,-85.490516244901,-97.40784817098812 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark05(-0.023830475193163635,-59.932943068219224,-6.28320056658324 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark05(-0.024014206044940218,-35.40247707030622,48.79690645062148 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark05(-0.02416231722865739,-1.5707963267948966,19.692657812354508 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark05(-0.02436399114188625,-1.156702674662073,49.810106087036516 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark05(-0.024510091648088483,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark05(-0.024556446753390526,-29.383912074303055,-4.712390442498693 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark05(-0.024589278426637013,-0.338552990647608,20.420352248333653 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark05(-0.024777807422465995,-1.5707963267948966,33.21453928119277 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark05(-0.025151189311225272,-1.5707963267948966,84.49213188058737 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark05(-0.025473559601603604,-1.5707963267948966,-95.26492973547151 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark05(-0.025571269415854747,-1.5707963267948966,40.840704496667314 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark05(-0.026170420349185153,-0.47998859954572604,-98.18846583714493 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark05(-0.026478215305412472,-1.5479943481295544,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark05(-0.02654184710705576,-1.5707963267948966,33.966081852040055 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark05(-0.02679599753116026,-73.36724758014253,-1.5707963266359146 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark05(-0.027026747506747717,-47.17373566178622,-4.431080090157858 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark05(-0.027043587753869947,-1.281941805821783,10.595948372454906 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark05(-0.027167232086248407,-1.5707963267948966,80.19769320508829 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark05(-0.027474123402115528,-9.444595669443231,-100.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark05(-0.027742034344947552,-0.8395851791331254,88.91806745698744 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark05(-0.027849839043570284,-98.25690556939514,-1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark05(-0.02832431501145739,-92.1602652208268,0.1881859271312209 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark05(-0.02850605764731995,-41.86621602782401,20.026411087708297 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark05(-0.02853749692682571,-17.276003941840354,-8.104710663833705 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark05(-0.0285404312563573,-1.5707963267948912,72.81923835402114 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark05(-0.028716890451906667,-3.3541442435164313,-82.90942109711426 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark05(-0.028890438054834797,-1.5707963267948983,-26.575190671128126 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark05(-0.028907465732771934,-0.04359419902546863,-6.462348535570529E-27 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark05(-0.02919237606315181,-79.00458621466792,6.283188442120475 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark05(-0.029235367731775236,-1.5707963267948966,2115.612381958503 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark05(-0.02925102933007134,-10.607694768578623,-54.53554218822927 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark05(-0.029362724327016476,-48.67846474053765,1.0004710014276688 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark05(-0.029519273063539967,-35.4877327726099,-47.34601864783076 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark05(-0.02960591769888132,-1.5707963267948966,-31.59971003909756 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark05(0.030032100386648736,-3.1428131405256536,-58.56670567803592 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark05(-0.030073532231503483,-0.7197467493842337,-67.53878514816347 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark05(-0.03015738214784919,-3.7034884522785676,-42.66207013347931 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark05(0.03033844844852218,-92.24146496273798,-39.20756605448832 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark05(-0.03034076683411053,-48.29483364546667,-21.01188625573438 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark05(-0.03039470668311109,-92.05380620930123,1.5133318439371746 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark05(-0.030463612948953056,-67.26659169937551,-64.30894378051008 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark05(-0.03075255588179504,-1.221269050338874,3.3157734968682098 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark05(-0.030973071864648538,-1.5707963267948963,20.3489760340432 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark05(-0.03150491035850919,-42.05390122069683,63.222978196993694 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark05(-0.03171827751080281,-1.5707963267947713,1.5707963267948966 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark05(-0.03197225401217703,-35.809217251825835,209.31201367677488 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark05(-0.0320079584383927,-1.5707963267948966,54.40959143333592 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark05(-0.03233280367808333,-0.015497277861220656,-1.5707963261380504 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark05(-0.032430649505531636,-1.5707963267948968,-50.72262641997558 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark05(-0.03244323334501076,-48.542932930733414,12.360565131059172 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark05(-0.032468919476195124,-142.44259753452613,-66.27036395689825 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark05(-0.03278272771037344,-0.012103683208489025,6.283314229237232 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark05(-0.032931863780997064,-3.142081067039587,1.5707963267948966 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark05(-0.03301928240684404,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark05(-0.033367823366531164,-60.273383516100495,-85.03588114583785 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark05(-0.03343299591872885,-3.293911955880958,0.19013811108111045 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark05(-0.03365045588975351,-53.47062355169641,-57.357904811249334 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark05(-0.033792707049917214,-1.5707963267948966,30.15394896254299 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark05(-0.03402300178230555,-66.332226933498,49.84920157699072 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark05(-0.03411231253988909,-3.1732759723101807,-0.7366181459665981 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark05(-0.03417831432092927,-78.873201714907,-39.08249426979211 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark05(-0.034298385919828464,-98.61431336875421,-21.63085259351365 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark05(-0.0343333759144,-47.248617112836975,98.13336295225946 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark05(-0.034503892492060206,-23.246619497333704,32.26351066704913 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark05(-0.034525341848714614,-10.902056361586576,-20.537753593845082 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark05(0.0,-3.4639861105661263,-0.5090539886622802 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark05(-0.03479629201926386,-4.660622109915096,-76.65257773452551 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark05(-0.03487961219411828,-17.1838303879007,-76.35362858347483 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark05(-0.034963209739999,-1.5707963267949019,-92.99074523848392 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark05(-0.035267410493863505,-1.5707963267948966,18.98253146231044 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark05(-0.03545184861510402,-1.5707963267948963,-50.80268216227008 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark05(-0.03561182579335378,-0.4036507421933546,1.5703723614940472 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark05(-0.035799835628129495,-129.98821758917944,1.5707963267948912 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark05(-0.0358408728061748,-0.2993993693759131,-1.6830594668730696 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark05(-0.03592644976018872,-28.340110749619882,0.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark05(0.035930991808837416,-236.9814655816471,-8.405056518080167 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark05(-0.03593875831843718,-34.62691115012764,-32.60691606818375 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark05(-0.036009823920621686,-1.5707963267947913,1.5707963267949197 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark05(-0.03633267575868109,-60.22346261894039,-233.72588819059902 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark05(-0.036625885054253016,-54.439690061245216,1.5707963267948966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark05(-0.036762028027755744,-3.141613781413517,-56.41490241292982 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark05(-0.036808214287959565,-1.5687672615251047,79.1591975345726 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark05(0.03686405550861674,-1.5707679069098843,-50.17880773764352 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark05(-0.037028745866636806,-3.4625153933594213,93.91539502669121 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark05(-0.037176412009900225,-1.5707963267948966,-38.33653069862484 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark05(-0.03753428709478776,-2.220446049250313E-16,64.19494291251871 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark05(-0.037582820335939834,-85.71624538214704,0.7218808928773797 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark05(-0.037825211954240226,-543.78529425147,-9.097474266556067E-16 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark05(-0.037880069596563565,-86.1320033212311,-1.5707963267948966 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark05(-0.038004593632972594,-42.298609436937085,-39.1801995622582 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark05(-0.03801191844416013,-3.144169722817565,42.36130239661094 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark05(-0.03827989710861281,-0.26830537908452357,-18.622151959854655 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark05(-0.03829130088851064,-42.37703795149765,-20.867850741642073 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark05(-0.0384607060090878,-0.09712443439835791,-72.67724565179307 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark05(-0.03861566027450609,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark05(-0.0387146855033902,-73.81826642432175,-140.832179351339 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark05(-0.0390094169209365,-0.11289062937078143,42.26629568585693 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark05(-0.03925301674123072,-16.08538177830215,-60.19189386708097 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark05(-0.0392652420470867,-72.63178905554062,76.6606656517601 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark05(-0.0395492725919718,-1.5707963267948966,95.65468502858153 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark05(-0.03957102457793951,-17.089731660294728,-28.18317426016221 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark05(-0.039657142471538856,-1.5707963267948966,28.71930500962651 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark05(-0.039698319796757475,-47.34176521877771,-81.9204629553812 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark05(-0.03969889505878696,-54.66634241781871,0.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark05(-0.039871651204773664,-22.296996374698892,1.5707963267948974 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark05(-0.039904995859954745,-28.543088119738073,-54.91848229065941 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark05(-0.03991134996678705,-1.5707963267948966,63.45648597247663 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark05(-0.03997234005858951,-9.976133170687856,147.49640009796514 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark05(-0.04049692669983998,-40.35280815244544,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark05(-0.0410453158472092,-1.5707963267948966,20.61600208518064 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark05(-0.04144299519757379,-0.07685347460499571,75.69076590683648 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark05(-0.04174806390498986,-70.38551317736857,-65.78565401276916 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark05(-0.04185630943355874,-1.554531184340345,53.06819258637148 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark05(-0.04186910852620196,-47.79627362800347,-98.14986403843132 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark05(-0.04193077459103356,-1.3243907999472384,2307.982943827523 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark05(-0.0419670211751928,-66.84685031879023,-84.51717937880956 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark05(-0.04291313842888076,-73.52347920217335,-440.2339154571673 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark05(-0.04302158989940852,1.677481816388202E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark05(-0.04310692918506333,-1.3677108065524681,3.1420809434525365 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark05(-0.0431763839956929,-1.5707963267948848,51.55288601245974 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark05(-0.0432869907675265,-79.70663179683883,-66.47517620799147 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark05(-0.04334263573786559,-10.442968564956091,-16.478866389402604 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark05(0.04337564007646948,-8.881784197000897E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark05(-0.043507520977361186,-60.1892354472533,-3.141601832845981 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark05(-0.04351594182465507,-3.1494059007715336,-76.9206901159699 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark05(-0.04381653268213237,1.3234889800848443E-23,-3.3322416030583355 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark05(-0.04421721584963757,-1.5707963267948966,3.1421002436826915 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark05(-0.04457677887005073,-98.88803231064428,4.017252456084016 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark05(-0.04484692427911974,-28.910473660776102,-56.03676097805794 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark05(-0.045170541155713326,-0.036942039340255306,84.83293089609231 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark05(-0.04561092239153233,-1.5707963267948966,48.85286861547458 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark05(-0.04598038239287053,-54.98760265957865,-146.59462184574573 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark05(-0.04603103626316263,-66.96272600635216,27.48940182406497 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark05(-0.04649549392261132,-676.2329751719839,1.5707963267948972 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark05(-0.04659738321806982,-1.3947990386096414,-62.613682005879745 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark05(-0.04694045415863521,-6.938893903907228E-18,35.457755998395406 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark05(-0.04735996182964186,-1.4462476724823485,-26.37079321443415 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark05(-0.04773659913613199,-0.020520141758713174,12.047478713537714 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark05(-0.04782497723744365,-0.28609085875187773,-55.53996267255532 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark05(-0.04785043187327681,-16.17742407560331,3.141602291221897 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark05(-0.04806429238387011,-78.82703942336508,0.5646536799564604 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark05(-0.048178812727214915,-123.62042946572312,-62.83190719189419 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark05(-0.048334101766111526,-1.5707963267948966,0.50216636392501 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark05(-0.04848491179803795,4.141592680202201,-1.5707963267948961 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark05(-0.04875455937108647,-1.5707963267948966,118.94872819909075 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark05(-0.04904942341143654,-1.570796326794896,-1.5707963267948966 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark05(-0.04931045648360721,-1.5707963267948966,-4.713163154636716 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark05(-0.04955380586088087,-3.8294632498111767,49.76603955917269 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark05(-0.049612676002543016,-1.34492093630509,-6.430281411737327 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark05(-0.04976767258904882,-97.90541889543017,12.568447619315814 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark05(0.04978212068309965,-0.45006296478584346,-111.82311755010961 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark05(-0.05026515038547933,-97.50403359263049,1.123556512622038 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark05(-0.05046557834786759,-1.5707963267948966,-42.874788796327195 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark05(-0.05046868347595727,-1.5643190568995842,0.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark05(-0.05095305330189707,-1.5707963267948966,58.26228601628411 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark05(-0.05097810071280622,-1.5707963267948966,-60.13451768782032 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark05(-0.05136986296306656,-3.165361369673022,-63.77176608792674 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark05(-0.051455884377773195,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark05(-0.051728957781497116,-1.5707963267948966,72.46650756817974 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark05(-0.051831221209020284,-67.37615633944816,-53.402756369543965 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark05(-0.05188000166174438,-0.04169621502144112,-100.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark05(-0.05211085127661892,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark05(-0.052308523306701965,-1.5707963267948966,3.1415926535897953 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark05(-0.05264211743444624,4.1902792285988335,-188.97296737463654 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark05(-0.05271932436301463,-1.570796326586582,-0.34743195271833593 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark05(-0.05287171341741218,-16.141522065673314,-1.5707963267948966 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark05(-0.052986413089484076,-0.37518169445494376,-100.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark05(-0.05339587051867262,-3.1435457785900898,100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark05(-0.05372301643620929,-10.624010404961084,-86.6775810612409 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark05(-0.0539023829063647,-1.1448156651875938,-1.5707963267324683 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark05(-0.05427221993256704,-10.910521058005703,0.034607818480132675 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark05(-0.05487478888552949,-1.5707963267948966,82.55790913230982 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark05(-0.05507018855301915,-41.878681366484216,16.479374479128406 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark05(-0.05567354035789518,-1.5707963267948966,-21.991148575128552 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark05(-0.05570417887678711,-3.141624559703418,-1.5707963267948966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark05(-0.055741091840743384,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark05(-0.05631175556199679,-1.5707963267948966,50.457690757517376 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark05(-0.05654385088306124,-1.5707963267948966,4.712389280865628 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark05(-0.056690548436049516,-1.5707963267948966,-19.945645050882277 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark05(-0.05791299532177131,-1.5707963267948966,-38.826268772567026 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark05(-0.059036153913721634,-34.67119877137043,-96.01341331293914 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark05(-0.05918981743891526,-17.14117942743667,-12.829879240066003 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark05(-0.060418018760611925,-0.9732099785693429,-44.21720741931239 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark05(-0.06051792499106454,-1.5707963267948963,1.761050914342067E-133 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark05(-0.060613453829934785,-1.220954552084499,1.5707963267948983 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark05(-0.06067328125756126,-98.87780000012722,86.5515543685034 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark05(-0.06073925327698133,-17.048760578314102,-89.18908541954931 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark05(-0.060982178613596436,-66.49171567980484,-1.2702635133388658 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark05(-0.06131615834551951,-1.5707963267948966,62.24720895941664 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark05(-0.06133118332180723,-66.43053473776293,-1.570796326502911 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark05(-0.06170561047129193,-79.97241767155266,6.283185342158765 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark05(-0.06186416725980206,-67.50482857345315,-54.17819704706033 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark05(-0.062295562574375074,-16.023952997217126,12.060095327039539 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark05(-0.062438168527681005,-34.573144189487884,-10.090110981845704 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark05(-0.06254946452115985,-1.5707963267948966,8.104437458084732 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark05(-0.06259753155202896,-1.5707963267948966,0.6160310717486421 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark05(-0.06292895980536078,-54.18510699503902,-29.11490358577333 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark05(-0.06320041144206456,-3.1969841211929975,-9.596770181950447 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark05(-0.06337426450502143,-60.19169544317062,-6.283185313676606 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark05(-0.06369590376687083,-97.43054458156813,-5.914621619712591 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark05(-0.06376681638029649,-1.5707963267948966,54.96596818942687 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark05(-0.06423727278015945,-1.334461319771534,-235.6285203062611 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark05(-0.0643698881858513,-1.5707963267948966,-23.859590806092452 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark05(-0.06440101020153621,-17.099101346473688,1.5707963267948983 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark05(-0.06441473579331891,-1.5631217900693408,-73.0904350362093 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark05(-0.06443243433125412,-9.848205981231558,-77.5288494615167 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark05(-0.06486183479509781,-48.06355293998459,-90.3588820036322 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark05(-0.06500720773685686,-1.276479254094356,-87.65513080997441 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark05(-0.06502401697142332,-1.5707963267949392,-0.6586078942200648 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark05(-0.06543428625606529,-185.85060798192117,35.91164605358325 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark05(-0.06558811224803134,-1.5707963267948966,0.22054261092398292 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark05(-0.0657457553032838,-54.72158811778743,-349.1903785953389 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark05(-0.06596520416908502,3.141592892015058,7.858800377389661 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark05(-0.06701035165598812,-44.7899941089191,0.0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark05(-0.06711771367564012,-3.1434189206165124,-64.2147648565261 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark05(-0.06733281803054295,-1.5707963267948966,-6.284161869829875 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark05(-0.0674789679749149,-0.6707863033113388,50.583854621785065 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark05(-0.0680464262281803,-124.06118993114617,-81.07903569713085 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark05(-0.06821282763857542,-431.07747264902895,-42.63994522577542 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark05(-0.06824183801481021,-66.3662092957493,-8.103981701502269 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark05(-0.06835114867055006,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark05(0.06846335168651044,-1.5707963267948966,72.53860483568596 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark05(-0.06857564577716253,3.141600282984325,-95.3378469127421 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark05(-0.06902920444075306,-3.725797968036474,-50.16010830094571 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark05(-0.06908275830779531,-85.70945208437061,265.45948704496857 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark05(-0.06916525452409417,-4.064515879010665,-21.840877336499602 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark05(-0.0692942104211027,-73.79050333909484,-57.86339251961315 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark05(-0.0693524412570331,-1.5707963267948966,-92.85047221889383 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark05(-0.06966167347843566,-1.5707963267948966,-91.25937165929196 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark05(-0.0697486175668054,-48.03947183837102,-89.30673903270832 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark05(-0.06992253449284425,-117.61137861407565,18.189955657012717 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark05(-0.07015867861789375,-0.1883635707025238,22.353986962383033 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark05(-0.0707415167601937,-1.5707963267948963,2.066159403716256 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark05(-0.07095126445211038,-0.03986664905277689,16.59777545605296 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark05(-0.0714334138484718,-59.92533076922544,39.15501173743576 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark05(-0.07151711046284993,-73.57010540879651,-51.0353237003107 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark05(-0.07154962952894905,-1.5707963267948966,-97.9810105132883 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark05(-0.07181138425023713,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark05(-0.07197360382516521,-3.1494051535897976,-65.76354625063688 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark05(-0.07221467056337211,-66.53193972283258,-20.69316136937335 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark05(-0.07248648034319766,-0.9272487390520836,-44.523942982630984 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark05(-0.07255179729403599,-66.86553965032243,1.0963953833237763 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark05(-0.07264626436582654,-1.5707963267948966,29.027107116457916 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark05(-0.07264728823182126,-1.4126922640387038,-74.96671392614537 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark05(-0.07265028534982831,-1.5707963267948966,65.24829324587665 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark05(-0.07278723456094016,-66.42045421299427,13.05313816356086 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark05(-0.07288748899508099,-1.4758164745193854,2.2227587494850775E-162 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark05(-0.07309023954802404,-86.0519851029462,-73.10026204347788 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark05(-0.07341722853536947,-1.5707963267948966,-45.70269341572226 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark05(-0.07373873490544754,-0.09325234148043438,-6.29441255411406 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark05(-0.0738428691341102,-66.71998047469245,-1.5707963267948966 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark05(-0.07392287303205564,-1.5707963267948966,64.97200014628098 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark05(-0.07394954188826278,-9.672694194517561,-14.075366452715352 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark05(-0.074173102038528,-1.5707963267948963,84.32552697390612 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark05(-0.07419356605150818,-29.554653586593457,0.9283333017165365 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark05(-0.07437531011819586,-3.1734192070435228,26.16254463053211 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark05(-0.0744071845824183,-0.4033837166864098,-365.7901323269228 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark05(-0.07462572426164593,-17.0656662555971,-115.68894881409254 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark05(-0.0746257370904768,-72.27436675307358,-57.1867703835875 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark05(-0.0747670194933379,-0.27627755196536863,85.61304517494034 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark05(-0.07480720036882316,-4.202440346731862,-141.89465312316108 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark05(-0.07494603385097598,-1.5707963267948966,-68.3039783406978 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark05(-0.07528517223435749,-16.440177006307877,-13.840191432611718 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark05(-0.07551589992167607,-34.57121146196566,-21.87236338765285 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark05(-0.07596968457545525,-1.5707963267948966,-48.27563473397636 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark05(-0.07671016957140896,-1.397334985825842,-1.5175991185899584 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark05(-0.07672596144068973,-3.2665932684492502,-50.18796706344257 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark05(-0.07679831710782593,-1.5707963267948966,-83.57428941247412 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark05(-0.07733618704393574,-1.5707963267948912,-90.64043140101508 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark05(-0.07768379196867886,-78.59898009211477,1.5707963267948966 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark05(-0.07769323290491688,-1.5707963267948966,89.95277889801226 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark05(-0.07785579420630215,-1.570796325367854,-49.97181758024925 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark05(-0.07801174319539275,-1.5707963267948966,38.8501543316927 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark05(-0.07813796305810834,-1.2358822469596473,11.300862853438286 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark05(-0.07851630111515229,-1.5707963267948966,-1.5707963267949054 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark05(-0.07876431074061252,-1.5707963267948966,21.94640516837446 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark05(-0.07885041984652182,1.3552527156068805E-20,73.22117172885483 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark05(-0.07944265918976645,-1.3353061158569925,-87.77312678817017 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark05(-0.07986399036089144,-53.817603496304315,0.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark05(-0.08030225424817217,-22.12724298320741,-3.3219779851179894 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark05(-0.08058337187880049,-16.955153931161988,1.5707963267948966 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark05(-0.08085854663468295,-60.24507656897793,44.604924027046096 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark05(-0.08135847259314383,-10.043009935676645,78.99500877619938 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark05(-0.08153823142114056,4.141592653591274,55.21147945940322 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark05(-0.08188925490434795,-28.594842601215397,0.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark05(-0.08194960679028555,-1.5707963267948966,79.64685232314162 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark05(-0.08210618485440502,-79.11074575624768,-48.737829171644286 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark05(-0.08215353767603722,1.2924697071141057E-26,-50.190526148470724 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark05(-0.08240859469492107,-98.03568173307502,38.58290975660147 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark05(-0.08287434424728428,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark05(-0.08326804293849155,-91.10940124660229,3.144075093354145 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark05(-0.08352894645044096,-29.088100468047728,-1.5707963267948966 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark05(-0.08356330799335095,-60.788390413001245,-55.363008301479226 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark05(-0.08384490345839744,-1.5707963267948966,15.988037907667934 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark05(-0.08417719316288237,-105.2176220920279,119.38015382812355 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark05(-0.08427348814963058,-41.15996152385956,-95.61895095012629 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark05(-0.08488087341608497,-59.7441441300822,-123.43124939607856 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark05(-0.08508784465028675,-53.87879398084121,-27.021680576228817 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark05(-0.08533262118153229,-4.052766992987799,-42.961203237220175 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark05(-0.08560254059353496,-28.99010037948626,1.5707963267948966 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark05(-0.0856888376875915,-84.83382065189005,27.056331865789584 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark05(-0.08651339386561112,-92.60872760910901,1.5707963267948963 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark05(-0.08652415281388369,-1.5707963267948966,-10.878232776683674 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark05(-0.08663897337098085,-61.0625920788723,-1.5707963267949054 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark05(-0.08672727328194389,-54.350945138234394,-3.172842654588336 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark05(-0.08681886368173702,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark05(-0.08685773545416423,-1.5707963267948966,-89.32443373712775 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark05(-0.08690367696597678,-3.6796865036568915,-53.87044846485184 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark05(-0.08708918014242828,-0.1347865844041869,-73.95740037473033 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark05(-0.08777715507030123,-136.6422041058697,38.371727960616056 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark05(-0.08805365339599425,-1.5707963267948966,-64.36320830288199 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark05(-0.0881035959886125,-1.5707963179154054,0.0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark05(-0.08813843450156586,-1.5707963267948966,61.12301144549864 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark05(-0.08851184365748443,-73.4144341917214,-21.451510777832564 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark05(-0.08851212032469509,3.1496570432641384,-31.656209943443688 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark05(-0.08860517342626384,-16.31498404003721,-1418.7552898352194 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark05(-0.08882351354498041,-154.1936230027403,100.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark05(0.08952443423949223,-1.5707963267948966,-1.78248591350913E-17 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark05(-0.08955996964714968,-1.5707963267948912,60.469000884190734 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark05(-0.08990970718388377,-1.3877787807814457E-17,-49.92761987725201 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark05(-0.09008645152115219,-66.31371586586106,0.3810676906194517 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark05(-0.09046290653252065,-92.11074155555528,-34.61707283842574 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark05(-0.09051921941076053,-16.086813654510628,3.1416026703529503 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark05(-0.09094386579060043,-97.38986083161417,-16.03448110201782 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark05(-0.09104337534789345,-1.5707963267948966,69.69592337179597 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark05(-0.09109985736286885,-23.51559932555972,-165.8223364937922 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark05(-0.09125323965133501,-0.40177005916509956,82.55282107960875 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark05(-0.09151176803353461,-3.1494051567497245,1.5707963267948966 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark05(-0.09178322362310816,-66.59177627646815,33.7419293500746 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark05(-0.09191582456292388,-61.12376185059206,744.3822333563056 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark05(-0.09192681287233395,2.6469779601696886E-23,100.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark05(-0.09196824268344594,-1.5707963267948966,-24.825480168827056 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark05(-0.09214186750029434,-7.105427357601002E-15,-75.63753738642808 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark05(-0.0923818196824836,-28.64939845536086,-0.5342125645240057 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark05(-0.09308626968790908,-0.42208797700858297,10.995574287564276 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark05(-0.09334133484687511,-31.45287975278638,1.5707963267948983 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark05(-0.09351061212085066,-0.06571591861792755,-79.72941979950954 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark05(-0.09358807006224712,-3.209573992443623,-162.54826760692177 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark05(-0.09384395034368771,-142.7712289264933,-98.42626311827694 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark05(-0.09417496669707925,-4.012916988624582,40.09981589429586 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark05(-0.09469844944575931,-262.1948731229285,-3.7364739775990254 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark05(-0.09497236687783106,-66.80787931328443,-1.5707963267948877 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark05(-0.09534993048830222,-60.53851340827589,-1.5707963267948912 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark05(-0.09571501460729337,-29.11021746058948,-80.0785286385979 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark05(-0.09575803142289746,-1.5707963267948948,-1.3859203480552245 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark05(-0.09600426604850354,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark05(-0.0961630374283862,-1.5707963267948966,53.71071097120774 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark05(-0.09654685451425948,-5.5809931214954833E-104,72.76883885797031 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark05(-0.09662060079744847,-1.5707963267948966,79.59564101629398 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark05(-0.09666213606281615,-47.568030659644855,-24.88950432814906 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark05(-0.09674562518652725,-66.49722998456801,-5.0235082894059836E-15 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark05(-0.09734834579723599,-15.90711998560568,-55.3099050724818 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark05(-0.09790212027348044,-48.588462998494606,6.283185307179591 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark05(-0.09791589396914532,-0.9988278679583121,-16.24559357408864 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark05(-0.09794291856297532,-2.9816619682305795E-4,-80.22694845215383 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark05(-0.09830034951963575,-91.53672947288057,-8.659810094521646 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark05(-0.09837081832085737,-0.010102074521575164,-42.07139314447088 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark05(-0.09865169143484906,-98.28483165941878,-42.54564908566724 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark05(-0.09928366345589919,-18.939744626147732,-35.03430377432193 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark05(-0.09930055008491315,-17.25319387458495,0.6350969650872433 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark05(-0.09962680222265412,-49.614234127410384,56.25336646580931 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark05(-0.09969564732999707,-1.5707963267948983,-19.533112654664137 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark05(-0.09993507413487634,-53.814146023556894,-100.0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark05(-0.10079364085539942,-16.9564835090944,1.5707963267948966 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark05(-0.1012680857338185,-98.83413586301124,-1.5707963267948966 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark05(-0.10173874710654263,-1.5707963267948963,91.66931233202311 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark05(-0.10196469673106004,-0.024104974139010048,-6.283185307179592 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark05(-0.10273248425049558,-41.021520740657266,-22.927419835188843 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark05(0.10277831908218331,-1.5707963267948966,-115.12367491540783 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark05(-0.10284994144384374,-66.2367126207612,2.220446049250313E-16 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark05(0.10289562035457493,-42.1137719048633,-1.5707963267949054 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark05(-0.10341728482175347,-1.5707963267948966,58.015916087442406 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark05(-0.10364741165054311,-0.6034031686864577,-180.91644908157548 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark05(-0.10390762103469994,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark05(-0.10403650919204735,-0.10312099115650597,-20.86805277105927 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark05(-0.1042698512521439,-9.950781261012182,12.597752386396518 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark05(-0.10427779965632306,-9.471471032198892,-3.2052031719027334 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark05(-0.10435243676201275,-3.2665926536229835,-53.24917565735711 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark05(-0.10456841729606445,-0.02943538536898723,-92.8115672733128 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark05(-0.10499948968693218,-192.3383831887497,20.790718747475665 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark05(-0.10540452399367883,1.734723475976807E-18,-53.935180330950075 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark05(-0.10623015671507366,-746.018080765956,-38.30608788743615 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark05(-0.1062449776906043,-48.657065452392324,-33.98071777491043 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark05(-0.10639398523701382,-1.5707963262176363,-54.966763221888385 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark05(-0.10659150093178094,-1.5707963267948966,-95.68758929966634 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark05(0.10676788182521284,-47.1286863116665,7.459962142374476 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark05(-0.1067802165049482,4.2351647362715017E-22,-47.09982871169507 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark05(-0.10679367939771409,-85.61388979726043,0.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark05(-0.10698717179127072,-36.01297456973835,53.83980190373586 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark05(-0.10727219396545412,-1.3950770868492235,66.27850109209056 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark05(-0.10738655804821917,-18.597199709136774,53.43692204235032 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark05(-0.10827807083364699,-60.44344885803301,0.8486319901000012 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark05(-0.10841559025787503,-1.5707963267948966,1.2199722829320747 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark05(-0.10848084943042108,-1.5707963267948963,-69.64352246447798 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark05(-0.10867356189162358,-3.5799545406673587,-75.25656375467003 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark05(-0.108861183887078,-4.930380657631324E-32,1.5707963267948968 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark05(-0.108892751754745,-41.577235035150466,-90.06500293168031 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark05(-0.10949092529189591,-10.336882884636012,64.92897096354042 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark05(-0.10970138269890634,-4.466358936902168,-1.5707963267948917 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark05(-0.1099720029305189,-53.73928451729955,-1.5707963267948961 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark05(0.10998963532914731,1.6088275221219377E-16,-0.14561680711017652 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark05(-0.11083842459521143,-66.28997990569029,6.289624271700409 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark05(-0.11163814428662167,-0.8742785675429795,1.5707963267948966 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark05(-0.11179985615174724,-97.58931706050943,-0.01802745437662694 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark05(-0.11199764740282508,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark05(-0.11215868957980835,-97.43665779808232,-18.181790498872473 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark05(-0.11267891417353322,-0.8115348926645418,88.14899200962608 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark05(-0.11277194114805478,-0.487143006395654,-47.057919035413036 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark05(-0.11365470988104279,-1.5707963250155672,49.933699794091254 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark05(-0.11386974542710154,-4.075509772024279,-1.5707963267948966 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark05(-0.1139391401413102,-0.17344928849105443,98.60733483304233 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark05(-0.11410381569537838,-1.5707963267948966,-9.232978617785736E-128 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark05(-0.11468531156626899,-42.24728853935381,-1.5707963267948963 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark05(-0.11500198235508352,-0.49857417976307783,-28.182213584493383 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark05(-0.11515212146848947,-35.692237318686594,15.917387487313704 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark05(-0.11515401754108501,-98.90388772249543,-119.23300145472393 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark05(-0.11629579160538023,-22.2871359869514,20.92699898450678 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark05(-0.11646304916145889,-66.42626393481729,77.87127993759421 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark05(-0.11720770320834895,-1.1068864661811797,-169.21228518051836 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark05(-0.11728098003505592,-1.5707963267948966,9.895554494942388 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark05(-0.11761279625490942,-701.9183419929792,-118.28661151379947 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark05(0.11763560991049705,-129.58601607623854,84.739515576254 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark05(-0.11803174839303265,-1.5707963267948966,-36.98685593958571 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark05(-0.11833903794221565,-1.5707963267948966,44.62940387527037 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark05(-0.11873619370808275,-1.5707963267948966,41.384343724602815 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark05(-0.11875376902286928,-97.75830531662757,1.5660146089311264 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark05(-0.11875563200786797,-34.63248043759526,-78.89803312146498 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark05(-0.11875677996026016,-1.2923088786843937,-84.70221880807067 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark05(-0.1187980604303849,-79.28266585911479,-1.2482088513757494 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark05(-0.11891413827741759,-342.65710898151843,-82.01209689252207 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark05(-0.11904477628880993,-1.5707963267948966,-77.88512222628661 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark05(-0.11907610595414804,-135.6539603105389,10.424782907701374 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark05(-0.11910268981646137,-54.88638802957928,-75.47707876295257 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark05(-0.11933311057749829,-42.31966300789971,-41.39697027279251 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark05(-0.11959278603527689,-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark05(-0.11972517703397756,-22.686322513049234,-10.389740041400428 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark05(0.12005266597666132,-1.6940658945086007E-21,-21.59523428620858 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark05(-0.12010798542531201,-35.141405241114185,-60.66960534639827 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark05(-0.12023082991642298,-0.936726535233308,0.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark05(-0.12027085413921082,-48.13124134711957,-4.141592893515213 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark05(-0.12034817387440552,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark05(-0.12053947791163866,-54.09194057753771,-170.43936248218134 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark05(-0.1207373572856178,4.141592670671375,4.1597953018722834E-18 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark05(-0.12084994592137754,3.1912936974834647,1.5707963267948966 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark05(-0.1208654219970623,-35.36806805138156,-7.841731858633864 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark05(-0.12089076914283967,-1.4774698117324334,-3.5491226380978502 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark05(-0.12104971571462342,-1.0027790424945922,7.854140897742876 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark05(-0.12145527634123887,-1.5707963267948966,882.1331461685019 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark05(-0.1217452330704889,-3.1435457790401586,91.24526754304603 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark05(-0.122328919824374,-186.59499032522237,9.488147085039644 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark05(-0.12237562926530154,-1.1997958444391053,-77.06534974729317 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark05(-0.12266855506510754,-9.997687338045694,65.25921339252218 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark05(-0.12286080039291325,-0.791872603610652,-3.1821990868430325 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark05(-0.12292601413165327,-1.5707963267948963,0.7978245628341615 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark05(-0.12419894327452319,-22.12621886497592,-60.53145059290763 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark05(-0.1252359540499417,-47.3500154949326,-42.86052122257474 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark05(-0.12560231039712433,-0.027523182685418743,-42.557235746127645 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark05(-0.12603606162147302,-1.5707963267948966,-4.712418687081873 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark05(-0.12701269685069944,-22.836447519151235,0.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark05(-0.12730940169605912,-28.276287011702575,-1.5707963267948966 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark05(-0.127485458148064,-73.71678195047005,1.5707963267948966 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark05(-0.1275922578737878,-22.46380973174596,-88.64371455701963 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark05(-0.12786499363671577,-81.93834684273862,81.63176972408037 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark05(-0.1278884853916173,-10.405016010393716,-661.9064079289266 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark05(-0.1282779334589433,-1.5707963267949054,66.81741576885533 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark05(-0.12828708595637917,-0.38095098639742786,-61.14541978110424 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark05(-0.12831856843862,-1.5707963267948966,54.44469885477548 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark05(-0.1283975383745073,-136.57173788729102,13.481728092988092 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark05(-0.12859431761063356,-3.2665926535897936,-100.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark05(-0.12870559639368462,-47.593020772118635,55.084567911792185 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark05(-0.12872126563051672,-1.5707963267948966,-3.021235031453969 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark05(-0.12920731973154675,-0.12825500429121828,1.5707963267949197 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark05(-0.1293773061260207,-1.5707963267948966,-24.736135023847346 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark05(-0.12950807937817654,-1.5707963267948966,1.3491931598143254 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark05(-0.12981510600402268,-48.59028905014884,9.959310277037282 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark05(-0.12981953699040177,-1.5707963267948966,58.42015353419827 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark05(-0.12982630976613416,-1.5707963267948966,66.31362776398066 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark05(-0.1299288394753373,-3.141612332096963,-118.86389261507661 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark05(-0.13016430720064792,-65.99965490800884,55.537402491165764 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark05(-0.13033032125563587,-1.034877985966858,1.5668629058888848 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark05(-0.13034389116794012,-0.23360239665030647,-21.69134742699261 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark05(-0.1316702530687524,-15.960518855244786,-2.8451311993408992E-160 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark05(-0.13182701765055493,-1.5707963267948966,32.41592653589794 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark05(-0.13182732186847246,-1.5707963267948983,1.003772072694001 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark05(-0.13210177757326313,-0.6973099576203654,-2469.5261548500353 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark05(-0.13219846531190674,-1.5707963267948966,-17.3069021657139 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark05(-0.13225250898412355,-1.5707963267948983,74.05286049799884 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark05(-0.1328694610999357,-1.5707963267948966,72.67438458103791 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark05(-0.1329169060424353,-0.4813904833022791,1.5707963267948972 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark05(-0.1329653453071017,-54.27582209620402,-48.61403803083604 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark05(-0.1330823302051174,-3.143551917292458,-47.30738550036709 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark05(-0.13337235164026637,-1.5707963266800216,82.1810515892666 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark05(-0.13354802145967926,-0.41268992560745765,73.82174011514812 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark05(-0.1336519911311886,-1.570796326794896,89.29341455255981 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark05(-0.13394302957705986,-0.2483595494816043,4.440892098500626E-16 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark05(-0.13478224096345492,-1.1923352768239255,-46.03157801237302 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark05(-0.13486508339258663,-155.15231547786186,-22.669892303967345 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark05(-0.13580477564305996,-0.002488436279006806,27.00154341531858 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark05(-0.13598304950721724,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark05(-0.13617038816629823,-1.5707963267948983,61.32261289234046 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark05(-0.13633282253336887,4.1415931068069085,1.5707963267948983 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark05(-0.13639809283737092,-48.55684013182342,-49.83406064332152 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark05(-0.13703488810341147,-1.5707963267948966,-0.0807496102513312 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark05(-0.13711533975863693,-35.255546529317215,91.57705520870024 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark05(-0.1373405760044114,-2.465190328815662E-32,-0.556895451242085 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark05(-0.13759194637862224,-1.5001049202286882,21.309424073772966 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark05(-0.13812563765806196,-36.04467033497076,-116.22994679090297 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark05(-0.1381261116061392,-92.52019955924996,-100.0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark05(-0.13814076451602686,-3.1415926684909548,19.550652075564734 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark05(-0.1384218918585436,-66.25819834096339,78.8241175565287 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark05(-0.13870150433106965,-73.77599150416691,-3.143551531148612 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark05(-0.13883511906004742,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark05(-0.139348302305435,-0.2841979288770983,12.695678985340237 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark05(-0.139391831893116,-1.5707963267948966,132.00939260713372 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark05(-0.14146262565032247,-0.061088343501212325,-1.2669765196118252 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark05(-0.14154995273030108,-3.3337833913788177,-25.95210974732502 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark05(-0.14158976619293595,-72.4472114405803,0.7026303870065922 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark05(-0.14163799168260738,-42.27034338462284,-16.650484249305187 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark05(-0.1420552084246477,-53.46753642281607,-8.12641336903899 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark05(-0.14288637129882753,-22.191171476718267,-64.16512497015879 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark05(-0.1434224920140477,-72.29929553693324,1.5707963267948966 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark05(-0.1441957958995621,-1.2115497793548542,-56.95628751851147 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark05(-0.14430789440992126,-97.96784514431071,-1.5707963267948963 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark05(-0.14457548411630813,-67.0626607502311,-1.5707963267948966 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark05(-0.14482196188204352,-78.99181816270458,-6.283308122850996 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark05(-0.14494914050018165,-40.99858052557582,10.050582102688455 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark05(-0.1452970902940791,-160.25567601013285,-28.19904117358452 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark05(-0.14592550901288331,-47.37703373079763,6.28416186996688 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark05(-0.14598302305920985,-1.5707963267948966,36.822330400744676 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark05(-0.1468987306267735,-63.31453761436477,-32.69649514719974 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark05(-0.14726266757124654,-66.65446057676849,-1.5707963267948966 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark05(-0.1476279081027343,-82.74892686034214,-80.44693669113263 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark05(-0.14764725817869628,-91.13336733449631,-65.8603420082748 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark05(-0.14796986224827055,-79.59577668878313,-1.5707963267949745 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark05(-0.14810220844251015,-1.3128383806762973,-20.349796879221916 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark05(-0.14831220883093432,-0.3166496276345848,112.08964251018645 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark05(-0.1485421069855266,-78.7634449642453,-42.15482447390972 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark05(-0.14865237676958998,-474.98688797803936,-71.84271955889128 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark05(-0.1486684955833445,-1.5707963267948966,0.49158745225673717 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark05(-0.14867233568872548,-1.3177747429038154E-82,-1.5385894315591142 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark05(-0.14902277003778863,-91.15005802501767,1.534662365097776 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark05(-0.14912043991682833,-0.1575471494627748,7.861568075969895 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark05(-0.14922294026423435,-1.5707963267948966,-22.531944978736846 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark05(-0.15011321912991465,-0.089462366492027,1.4754074530055636 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark05(-0.15014191354490425,-0.1605473389286589,85.07211909489666 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark05(-0.15095795808211032,-54.92216790253797,91.3557377068613 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark05(-0.15132356101184957,-3.1420812099330613,-71.66707833221962 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark05(-0.15132575370089668,-41.76388085315697,6.297457130539348 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark05(-0.15146267092005428,-98.51688748434196,-12.597669310398675 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark05(-0.1515764441858842,-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark05(-0.1526355999168023,-0.780752020875292,-22.65494006690885 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark05(-0.1529806060671962,-0.4429106854619525,21.234586956658944 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark05(-0.15324271961307723,-0.6951945117413235,-57.72418155229033 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark05(-0.15407923634296408,-0.6175320815918255,4.071427472695445 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark05(-0.15461636722147354,-1.5707963267948886,-182.08386647450104 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark05(-0.15525852807823645,-1.5707963267948966,38.21387441315554 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark05(-0.15555951825701897,-1.5707963267948966,-61.61221096342921 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark05(-0.15596701239581748,-67.30186931231762,1.5707963267948741 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark05(-0.15610352595140087,-60.82979542459775,29.307638373117584 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark05(-0.15632696729423856,-0.1542763606502738,-63.26057926098137 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark05(-0.15635496080261363,-160.8069984139154,47.16018234218934 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark05(-0.15674920241624896,-1.5707963267948966,38.51546145747221 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark05(-0.15714003074993688,-123.63031298555003,1.5707963267949054 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark05(-0.15731513938839872,-0.05811608103903897,-83.29949538053478 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark05(-0.1576926236231998,-97.79345588760418,44.65386313068671 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark05(-0.15786884632094084,-28.940492734219696,-51.89649531123604 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark05(-0.157936808672613,-70.1881872300315,-1.5707963267948735 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark05(-0.15813358900352328,-41.8890353899901,-10.747523522774053 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark05(0.15846820210249202,-10.05254421174045,56.12047928432021 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark05(-0.1585061868345584,-1.570485527353631,-55.263710406932226 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark05(-0.15852204332355818,-59.720787126963785,-158.36383338777097 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark05(-0.15853969971292656,-1.5707963267948966,64.40264939859077 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark05(-0.1585914431484286,-73.44375508252645,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark05(-0.1589702056432798,-60.343004620285,0.6543941546979989 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark05(-0.15956853389993542,-1.5707963267948966,9.689309440717865 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark05(-0.1595995943583903,-1.5707963267948966,59.32441446557962 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark05(-0.16005496363266272,-1.5707963267948966,-32.174335094480114 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark05(-0.1601274840115927,-66.20328710393561,-13.792536817356996 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark05(-0.16052654514690756,-0.881994196033105,58.06444014895567 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark05(-0.16073482433344627,-73.15359859674953,-4.71238898038469 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark05(-0.16126835904312684,-9.731850215158943,-6.436502992124713 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark05(-0.16137618269216622,-0.011301697125625454,8.656778685670847 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark05(-0.16174164394238177,-1.5707963267948912,59.57039578683487 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark05(-0.16212339869431053,-0.09151571123587172,85.00974235477398 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark05(-0.1621273648730106,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark05(-0.16257550268063492,-47.44284360341911,68.31739675650543 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark05(-0.16259461638590028,-3.2389032126035016,-3.1979818655846914 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark05(-0.16261231999740577,-72.75481626515993,-1.5707963267948966 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark05(-0.1628082079343458,-1.5707963267948257,22.829581374466176 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark05(-0.1630188125613269,-4.141593278842279,-78.46469325127897 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark05(0.16354164277645325,-1.3886249429640132,1.5707963267948966 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark05(-0.16354696006650155,-2.2007101307995226E-16,73.6143712969334 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark05(-0.16479509247287016,-4.148927809521105,-44.226102376134676 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark05(-0.16545340875750789,-41.0272094574759,47.820183381211166 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark05(-0.16553489082493414,-34.557519189487735,-56.02541911429758 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark05(-0.1658651727260541,-48.57888232174646,39.211225447837634 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark05(-0.16626347846201628,-1.5707963267948966,0.11564683209725857 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark05(-0.16628889764584465,-0.22854821647799878,91.82577500250362 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark05(-0.16736274405158238,-48.0223729302733,0.5815758936681308 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark05(-0.16745584612266762,-35.303095160476985,75.73097981244842 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark05(-0.16788461119501963,-97.83589155472048,1.5707963267948966 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark05(-0.16810460917899128,-1.5707963267948966,78.03146938336042 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark05(-0.1683252002729516,-1.7763568394002505E-15,28.87152089202059 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark05(-0.16838462934573434,-0.6935527996955089,54.9988864550723 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark05(-0.16853133762865724,-4.276118652237418,-91.10618695366796 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark05(-0.16883278829918058,-15.938288792341558,89.66445611627881 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark05(-0.16889173832094373,-0.6947342540297718,100.0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark05(-0.17010297852044687,-67.46034861617943,-0.7611024507618446 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark05(-0.17030244902838557,-0.5907422095861481,-93.1661210497038 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark05(-0.17034562534288958,3.1435595167651518,-11.562122401035097 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark05(-0.17094200077823782,-1.5707963267948966,27.979184848061948 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark05(-0.17117019823378474,-1.5707963267947065,-35.419889000907006 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark05(-0.1713309736010272,-15.743791535690955,-1.4911222027534023 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark05(-0.1717435883826397,-98.86671705938075,-84.80577627972693 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark05(-0.17178716384589746,2.1684043449710089E-19,0.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark05(-0.17212903333214702,-78.66486819412626,0.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark05(-0.17218397356168932,-1.5707963267948966,-6.1273694890293156 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark05(-0.17272743749988956,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark05(-0.17280395824620953,-1.5707963267948966,20.945635768168525 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark05(-0.1728050914764068,-0.6500609493083968,38.96041668635276 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark05(-0.1737953487330336,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark05(-0.1738273506074393,-576.481302988508,-0.14266429663091396 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark05(-0.17393136933534947,-3.2665947447329837,-119.73199070338406 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark05(-0.17415060487604006,-1.5707963267388256,122.58736461185933 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark05(-0.17415489749833976,-42.38009518424119,2.220446049250313E-16 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark05(-0.17450985633187666,-394.2416005928962,-10.024278439262748 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark05(-0.17477997400268408,-0.5124545085463253,16.152201037583907 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark05(-0.1748320189547475,-4.440892098500626E-16,1.5707963267948961 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark05(-0.17528809630047354,-61.21046238594942,-1.5707963283614907 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark05(-0.17546890498286216,-29.84421181185448,-20.574374765003064 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark05(-0.17595224189604597,-47.98574900654214,-41.811613887140254 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark05(-0.17629179166072537,-1.5620948087239162,6.284161942281251 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark05(-0.1764120800197393,-29.226368154489435,-75.65652688267828 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark05(-0.17726334342748695,-186.23462207310644,22.1902652046799 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark05(-0.17782488801273466,-60.93218452660798,57.077349689225514 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark05(-0.17791265011830057,-79.99045161789111,-6.284163097913003 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark05(-0.17808341457384966,-41.96174507402351,-94.74443039880053 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark05(-0.17851241785856442,-66.70512518895481,-29.68513319801724 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark05(-0.17875689146788326,-3.2049078615345508,0.34812453780249053 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark05(-0.1791593465751673,-0.3888231020267071,3.1416006232445404 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark05(-0.17931780153192478,-48.649666234312996,12.568323739359174 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark05(-0.17991044293350034,-73.5110374944135,-10.94991086354382 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark05(-0.18033941417838584,-54.38606054537351,1.5707963267948966 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark05(-0.18084776687300946,-5.699590455382316E-16,-37.69956855597758 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark05(-0.18099806181198025,-23.01570439745744,-158.90888557082428 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark05(-0.18117427116428075,-0.14972302799426548,-31.918463123903294 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark05(-0.18125462570672118,-41.60582325047912,-6.28416887782967 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark05(-0.18146161372965253,-16.965160243948063,82.61889362364465 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark05(-0.18284922510835974,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark05(-0.18293161599127306,-66.24306648597432,78.52027615925883 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark05(-0.18374036092140345,-42.14429000191053,0.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark05(-0.18398192854858816,-3.1420809633715474,1.1142836359025123 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark05(-0.18429826606701494,-0.07495035593154642,70.74668864459356 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark05(-0.1849075854528634,-4.141596065891639,-95.14720246475774 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark05(-0.18490846738747146,-1.5707963267948966,-63.531469732502075 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark05(-0.18513314089059216,2.710505431213761E-20,6.695414196642398 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark05(-0.18525308773663307,-1.0808868154640308,-364.2368945128973 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark05(-0.18526863883436942,-10.602991583887087,1.5707963267758 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark05(-0.18536727776684714,-1.5707963267948968,-74.56071054586253 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark05(-0.1859081136310281,-1.1421434134490057E-14,8.104129198073858 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark05(-0.18601153301592066,3.1494051538331616,1.5707963267948966 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark05(-0.1861276398068128,-42.3611435746252,-97.2210113304055 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark05(-0.18612964071681914,-29.333569354991848,1.5707963267948966 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark05(-0.1862002012440509,-73.8094526289581,-146.82295447028616 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark05(-0.18681076076998782,-1.5707963267948966,18.80999256769293 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark05(-0.18682611349079678,-92.06523955146741,-98.80674232165482 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark05(-0.18707209977283076,-1.5707963267948966,72.5074202257556 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark05(-0.18822477457226883,-0.23846737937076712,84.31188397081434 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark05(-0.18833578264067796,-66.8845934434702,57.83109927087612 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark05(-0.18834561461445015,-444.376844997554,-49.100544077793046 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark05(-0.1890230669166575,-1.5707963267948966,-8.238107415479994E-17 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark05(-0.18918924501632173,-22.326389922894194,9.344808741173704 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark05(-0.18931413721950596,-1.5707963267948966,70.5536964329149 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark05(-0.1893924471194911,-0.5170270890770474,-60.008134653740996 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark05(-0.1895222628053972,-53.46895251292465,-55.19124477186001 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark05(-0.189539302758477,-36.114242394383,-39.95133440860509 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark05(-0.18999870985973644,-28.57406484933965,0.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark05(-0.19018438372254143,-1.399952993466484,562.1300800033513 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark05(-0.1904068495778072,-84.85191062224226,26.801268306953745 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark05(-0.1904365417510443,-1.152580603225748,-141.21763713010463 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark05(-0.19072057649210702,-1.5707963267948966,23.18881136173594 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark05(-0.19074247381427567,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark05(-0.1909675264495977,-34.77233188384315,37.99244967758952 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark05(-0.19133672057173234,-41.014633785083504,-30.859998064833448 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark05(-0.19141065922232348,-59.74353808320606,-98.33005909772672 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark05(-0.19158972450520595,-29.45092301864503,-68.95966426445223 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark05(-0.19166864128649763,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark05(-0.19234840129673414,-1.5707963267948966,21.96216061836371 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark05(-0.1926055962498869,-4.141592653589794,-28.32191690495906 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark05(-0.19289983386019002,-1.1076560759489797,-41.541219399321164 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark05(-0.19336793014572395,-3.1415954538493387,1.5707963267948961 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark05(-0.193510064631684,-1.5707963267948948,55.49520936657167 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark05(-0.19411437412474764,-1.5707963267948966,-52.57524995243617 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark05(-0.19431209393271587,-1.5707963267948948,89.88934923549232 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark05(-0.1944776427760473,-1.5707963267948966,-2394.62420915622 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark05(-0.19483529871834926,-54.133778222030266,-58.0956339613755 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark05(-0.19541291799783927,-0.10972094407330589,55.133570900117356 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark05(-0.19592640742888712,-91.4461465343179,76.28587835707135 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark05(-0.1962787671844347,-9.657414132200925,-84.28327930469209 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark05(-0.19652662692724743,-1.5707963267948966,160.4319056111118 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark05(-0.19674434244132533,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark05(-0.19707705785116314,-9.48727796264761,121.86595293889818 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark05(-0.19727453989241095,-23.13593526519472,-4.712388980385612 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark05(-0.19828627677019028,-1.5707963267948966,23.56194490192345 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark05(-0.19861604625346074,-3.615163723935666E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark05(-0.1990054484187092,-85.71249538472003,0.958673965368078 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark05(-0.19918566082661904,9.056329963877101E-13,114.75471947157497 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark05(-0.19937285435502627,-1.6954709144801482E-17,0.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark05(-0.1997696067867878,-1.5707963267948912,-59.80049151667577 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark05(-0.19985563797454442,-1.5707963267948966,27.797999663977947 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark05(-0.20073337210806663,-1.0990142520490553,56.08457471062326 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark05(-0.20090204022872105,-1.5707963267944307,1.5707963267948948 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark05(-0.20132130323176511,-16.992806067885013,-40.17734852324547 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark05(-0.20135275914642456,-1.5707963267948966,-13.419501750196396 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark05(-0.2014568145903013,-10.798372147779869,0.7571896751259484 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark05(-0.20160054904617888,-1.5707963267948952,-1.5707963267948966 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark05(-0.20163635058307097,-0.03571740110022681,-55.11085368527553 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark05(-0.20170628255959894,-2.7755575615628914E-17,4.712389104241267 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark05(-0.20224843246708255,-73.82564237010638,-164.69623435811218 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark05(-0.20241699768965304,-0.49625638216864587,-84.9219389912123 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark05(-0.20284395027287,-72.58179229356318,1.5707963267948966 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark05(-0.20318530307808752,3.1415926535897953,-65.98202072801246 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark05(-0.20322197107431386,-3.4530758833117883,-35.41900248054294 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark05(-0.20331628366155657,-1.5707963154255304,-51.56130640032731 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark05(-0.20384005669939498,-4.415307499244091,-4.316101007515836 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark05(-0.20394462991280554,-3.14159265372908,83.97105904363175 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark05(-0.20401333632711616,-42.004166085626224,-25.563509211767784 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark05(-0.20404808631775456,-79.34633013581148,-31.11781790958048 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark05(-0.20414139463214664,-72.53911129365135,100.75289451549155 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark05(-0.20418589616531999,-1.5707963267948966,89.77889950389843 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark05(-0.20514145866687394,-66.39175988697372,1.5707963267948977 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark05(-0.2056453500437821,-1.5707963267948966,90.08147270063247 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark05(-0.20571559486866775,-1.5707963267948966,-95.17172917624524 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark05(-0.20636740753643168,-66.09709236057914,42.71967385112614 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark05(-0.20665500481965537,-1.1548206984133933,-89.2911382512527 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark05(-0.20691710299409877,-1.5707963267948966,0.46429863272619437 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark05(-0.20693935767140617,-1.3508068024458167E-225,48.33993811295185 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark05(-0.2071088753223485,-47.47346967607173,0.17227862993812826 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark05(-0.20726614023925258,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark05(-0.20726786094839297,-311.7968946497535,1.5707963267948966 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark05(-0.20826226144994242,1.9570781622963105,-100.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark05(-0.20826463844008192,-9.532781821508415,-1.5707963267948983 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark05(-0.20838633561367498,-0.0430265496712318,-48.88312200700477 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark05(-0.20844653198136553,-1.5707963267948966,28.002123783073483 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark05(-0.20877272832577798,-66.24513847220574,-6.283444653596399 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark05(-0.2090648991759937,-28.789509112729704,0.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark05(-0.2091292379821429,-122.67575527410223,78.23479265324316 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark05(-0.20917999314435776,-35.10300822371504,1.5707963267948966 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark05(-0.20931218040295677,-3.142080934973362,-21.903722536056375 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark05(-0.209631172964786,-3.473138617318859,-0.20963202847092158 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark05(-0.2096397093669642,-1.5707963267948966,20.98234224839952 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark05(-0.20966933231702,-98.52017468171411,-509.9187071652545 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark05(-0.20980181407807305,-1.5707963267948966,-22.048129248436133 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark05(-0.21021487037098918,-0.3797720642598092,-0.7670180232238337 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark05(-0.21033245037008907,-1.5707963267948966,34.59640744787785 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark05(-0.21082964763197923,-72.39355433935766,7.418412301374843E-68 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark05(-0.2109733264052256,-166.54294431076886,16.88211983228001 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark05(-0.21199128078665647,-86.0076624944702,1.5707963267948966 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark05(-0.21284503838199953,-1.1070452002557603,0.011255830620813095 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark05(-0.21312957339366934,-1.5707963267948974,41.35778910417008 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark05(-0.21345424310514294,-1.5707963267948966,80.12550788384175 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark05(-0.21361643117550366,-3.2058306341706504,-1.5707963267948966 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark05(-0.2142110666829274,-1.5707963267948966,35.58348801714365 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark05(-0.2142840783061433,-1.5707963267948961,-0.8667583780637682 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark05(-0.21442631413965396,-1.5707963267948966,41.97205663867288 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark05(0.21455701043094766,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark05(-0.214951542779243,-0.6979551255346287,56.54078250164307 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark05(-0.21553182035825874,-22.400145078770677,0.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark05(-0.2155814439609548,-4.436086380087502,0.0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark05(-0.21579949138985877,-3.141592668491726,1.5707963267948966 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark05(-0.21582238794720254,-1.5707963267948966,0.3186525234638243 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark05(-0.21608952436892104,-17.000027395594174,-39.142664216161144 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark05(-0.21619521128037755,-0.052195315870662146,55.279856296040776 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark05(-0.21626169428392533,-1.5707963267948966,6.28318530718348 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark05(-0.21631387083910134,-54.9144455517952,83.68443831386215 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark05(-0.21657064189645653,-1.5707963267948966,19.140810701322735 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark05(-0.21664030428715975,-109.95703395674991,19.16713371937116 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark05(-0.21668704328823957,-1.3437086597083396,-50.536416134004284 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark05(-0.21716517573371388,-0.4536660494937088,123.63538756951893 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark05(-0.21717876907733102,-73.21238717232146,-4.2228028608974615 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark05(-0.21755233247624872,-1.5707963267948966,12.050461684856302 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark05(-0.21756896603002107,-73.65209101351712,-44.50738863956266 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark05(-0.21808268865709501,-79.71160408766482,-9.95210777916115 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark05(-0.21875200253208638,-47.74796342326766,-66.34491831952157 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark05(-0.2187627502598584,-1.5707963267948966,-98.35820695486657 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark05(-0.21913027944981212,1.3877787807814457E-17,-81.23053256378421 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark05(-0.21936588063940876,-0.36172204728370616,1.5707963267948966 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark05(-0.21983121005397618,-1.5707963267948966,16.88601792018987 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark05(-0.21983448515214082,-0.9238798754660758,0.5389697518564881 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark05(-0.22013029386717184,-2.5026038689788762E-147,-61.63342924702195 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark05(-0.22075488887370034,-0.0019371683505001458,76.96902001294994 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark05(-0.2208791980840469,-97.64492399713349,-56.549156620419495 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark05(-0.220905656569769,-1.5707963267948966,-59.764411903155185 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark05(-0.22127397585499847,-1.5707963267948966,-0.6066272688482224 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark05(-0.2216358516344853,-4.555233871176353E-15,0.0029408666517036237 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark05(-0.22174555520085126,-732.5298756899626,-96.17113929671731 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark05(-0.22233999984375474,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark05(-0.22247885836756978,-10.44973642179853,6.283225292103795 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark05(-0.22304682641049567,-1.5707963267948966,82.05198227166912 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark05(-0.22305198981219815,-0.3575431307272804,-64.85811839641009 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark05(-0.2235474830076295,-60.163000396336855,-66.4281254128376 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark05(-0.22420762411987716,-1.4518289013923793E-8,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark05(-0.22442093970669197,-41.58582360083915,-49.91786165268306 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark05(-0.22459623712545843,-66.82659335474126,1.570796326794896 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark05(-0.2251713957408334,-4.445517498970155E-162,1.5707963267948966 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark05(-0.2255726477796249,-1.5707963267948966,27.077803161631365 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark05(-0.2258403034585268,-0.14083739810276796,-30.05780399953224 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark05(-0.22602054207396055,-1.5707963267948966,59.07644376123522 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark05(-0.22610175465094529,-73.09318022047154,0.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark05(-0.22633159223047716,-720.6269276417042,-51.58828460942437 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark05(-0.22670118535928327,-10.459077170783559,63.43566392504471 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark05(-0.22816446463316709,-15.846059438823978,-29.493505649147423 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark05(-0.22834099665439508,-16.204571149559463,-89.25164225119849 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark05(-0.2283509544058417,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark05(-0.2285052487178461,-1.1866839889107585,1.5707964424908696 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark05(-0.22881498532573807,-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark05(-0.22894401357563865,-1.5390038885599717,41.91153585352852 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark05(-0.22936219707971062,-1.5707963267948966,-13.6775245461438 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark05(-0.2294339824688972,-493.94145822347434,-55.313484550364244 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark05(-0.22954347182940332,-40.88336277683812,-54.9829686919321 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark05(-0.22970564152147688,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark05(-0.23028150789843127,-1.5707963267948963,69.98593028231498 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark05(-0.23036866936101363,-48.606719837824066,159.6432565196664 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark05(-0.23071760314227918,-0.15693599619118115,-87.65046026771745 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark05(-0.23092773179336057,-34.801666638354696,0.2820674203044007 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark05(-0.2311778798317885,-29.844254141022518,-169.3559356786423 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark05(-0.23139056507714584,-1.148899553481266,-42.66005041257972 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark05(-0.2315196452327967,-78.86916848963523,1.5707963267948966 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark05(-0.23169017016863735,-0.6206750705904982,-35.63318191867124 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark05(-0.23171710767634354,-1.1287894643479144,5.21238898316175 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark05(-0.23173361770464862,-16.658797304517073,-41.1537229772723 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark05(-0.2319365421960228,-29.735714829759203,-1.5707963267948966 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark05(-0.2320569282174849,-66.01366278011251,-0.9682954721247323 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark05(-0.23238351443485644,-0.0854227010733235,-1.5707963267948966 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark05(-0.23335268101922102,-41.23540117812659,-1.5707963267948966 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark05(-0.2336982424580505,-9.481032422846962,-1.6242827758820155E-114 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark05(-0.234350188388167,1.0339757656912846E-25,-20.940213964732177 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark05(-0.2345051215564018,-15.955485061061918,-56.294274957964916 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark05(-0.23456893881688962,-0.4263647293022329,-65.45755370339245 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark05(-0.23462525743195856,-1.5707963267948966,78.34655656129792 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark05(-0.23471159374605577,-28.85421667809335,-14.195102933134352 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark05(-0.23493363393783068,-42.01389552305331,0.0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark05(-0.23506934015712255,-0.3237216643070493,-1.5707963267948948 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark05(-0.23527316383427888,-1.5707963267948948,37.85612561131439 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark05(-0.23528527750628198,-1.5707963267948983,329.8587843042723 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark05(-0.2352962578213463,-1.5707963267948966,-62.44401339977197 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark05(-0.23544635689361115,-72.91499923088007,0.001021806988091188 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark05(-0.23588294612952254,-1.1102230246251565E-16,-29.66200423579089 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark05(-0.23621152928501943,-8.316327812515919E-112,0.0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark05(-0.23685042573616466,-85.34067131201613,-73.14817088186044 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark05(-0.2370354039493574,-122.56792724053754,-35.335567339311666 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark05(-0.23706442175155384,-122.68425723240972,48.77447695848238 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark05(-0.23709781056557297,-0.3232646954045904,22.28524472260405 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark05(-0.2373246547493364,-1.4160312903654537,46.11705002897706 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark05(-0.2373368815745983,-73.19984099792462,-1.484569536878767 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark05(-0.23748136700346834,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark05(-0.23767465283312195,-10.610092241373316,-49.950300891513656 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark05(-0.23773152511375129,-3.1724467138745878,-27.930574898834 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark05(-0.2377714090306262,-78.88702377015578,-84.76756485873976 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark05(-0.23838380155861513,-98.57453077792782,1.5707963267948966 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark05(-0.23876924877562178,-5.421010862427522E-20,-43.07174021695832 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark05(-0.23883220550932593,-85.76610516546113,-28.11097354895404 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark05(-0.23919245831314345,-23.307153503931062,-1.5707963267948948 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark05(-0.23926523308250225,-0.9879691294368899,619.8325650826878 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark05(-0.23936132761790868,-1.5707963267948966,-1.7290327071306454E-223 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark05(-0.23996491342685788,-0.8876427379098578,56.094075271692844 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark05(-0.240482543728159,-66.2534561192748,-55.01260125274768 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark05(-0.2407725669677217,-41.17575086410899,-85.32329981529249 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark05(-0.24177264393777076,-3.7936138473025522,85.23921895009963 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark05(-0.24197955034987814,-468.24705390907,55.41511697033345 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark05(-0.24202343635019474,-15.760304467233789,-57.69764314790669 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark05(-0.24275850026516188,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark05(-0.24303858534497813,-48.456862204758224,19.52352289885303 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark05(-0.24352860799153597,3.141602506282852,64.1431421160778 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark05(-0.24353822976842066,-1.5707963267949019,-1180.9212793501868 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark05(-0.24427069874493723,-1.3874335274517047,-4.096263167141117 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark05(-0.2446868255275272,-35.15939265772127,91.00928154370925 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark05(-0.24479942843772548,-1.5707963267948966,-40.61322166687495 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark05(-0.24495787148007733,-78.75642330405248,-94.5381242733887 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark05(-0.2453300378384491,-28.90872124993092,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark05(-0.24544695692292415,-1.5707963267948966,-54.12467537389054 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark05(-0.24570532185031224,-66.26249085013752,-20.36713860162031 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark05(-0.2457074016676426,-0.48006036267756713,0.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark05(-0.24605630523290695,-22.476764213293706,13.435078694423323 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark05(-0.24645096827389568,-1.5707963267948966,-83.15285372825277 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark05(-0.24645166215894476,-1.5707963267948966,-64.56283165901539 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark05(-0.24650361569785206,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark05(-0.2465745713451334,-85.60876947891146,86.39379797371932 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark05(-0.24691045116911248,-431.39704404517914,0.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark05(-0.2469982159049727,-1.5707963010210872,20.11166993083936 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark05(-0.24734979092324594,-1.5707899617330485,-49.89574455619636 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark05(-0.24745075682537698,-1.5707963267948966,14.318594757750256 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark05(-0.24787914167378594,-1.3573016440592451,55.303964332428485 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark05(-0.24798950247283802,-1.5707963267948966,-41.63027487521895 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark05(-0.24808459526896134,-42.09677316321376,90.54071892940537 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark05(-0.24816962996736225,-1.5383489706210056,-50.200648939518565 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark05(-0.24901582785764573,-0.18317123869299695,-62.69891736434084 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark05(-0.2490934597888979,-98.94579439277543,50.058486563665824 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark05(-0.24917908875494632,-60.69841284013977,22.188191912801912 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark05(-0.24920376210446613,-0.5710319081994335,89.01503648184706 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark05(-0.24959058314316304,-53.97191012416172,-1.5707963267948963 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark05(-0.24971456329249198,-1.3047966625737355,61.31470090479353 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark05(-0.25063851354939315,-66.23791872014527,-777.3742491784201 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark05(-0.25111396416050874,-15.707963267948967,-93.69788431022793 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark05(-0.2513594418738467,-1.570796326696602,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark05(-0.251985548658211,-0.32944237575235036,9.964871108294941 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark05(-0.2521651851708002,-0.01213963767427284,16.24155195993827 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark05(-0.2521731486392499,-1.5707963267949054,10.531182900058056 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark05(-0.25269961505781924,-2.3646401456273895E-9,96.00918993480383 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark05(-0.2530033566903699,-79.94164523300773,-1.5707963267948966 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark05(-0.2531103198719078,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark05(-0.2532246075694804,-85.34362119882996,1.5707963267948983 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark05(-0.2535058940525502,-1.5707963267948966,81.63955831040201 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark05(-0.25364558969727113,-141.6341222255038,84.80817058149788 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark05(-0.2537173126941551,-66.53166164011122,-55.46388101706796 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark05(-0.2547183090462857,-16.58228066582632,-1.5707963267948966 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark05(-0.2550653097557247,-168.05339410552872,28.839911132467364 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark05(-0.2553921788117283,-4.107442938595419,-1.5707963267948948 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark05(-0.25540625017286506,-0.17950730990568148,0.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark05(-0.2557303180129463,-1.5707963267948963,66.11604603294435 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark05(-0.25608192751900954,-73.49390875363983,1.5707963267948966 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark05(-0.25694495170132825,-17.26190531496961,1.5707963267948948 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark05(-0.2573239193448331,-36.01401633984947,-2304.300745658413 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark05(-0.2574539986438884,-67.00674192052438,3.1420809348413505 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark05(-0.2581380946155787,-79.40358888386876,-87.74276980287914 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark05(-0.2584167803555242,-1.5707963267948948,-27.720903382891336 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark05(-0.25918322976309394,-1.5707963267948966,25.953209974203517 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark05(-0.25938210180968074,-22.656743016856513,-15.321499421946406 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark05(-0.25979227174355607,-1.5707963267948966,58.20844353313629 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark05(-0.2600347140677961,-1.5707963267948966,-3.1415997049819757 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark05(-0.2602982896596825,-1.451813493250615,90.85859619112298 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark05(-0.26062483908882944,-2.2952539161641433E-5,-6.283200574527172 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark05(-0.2607573655904929,-54.18160700764113,-7.4545376364867195 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark05(-0.2610255320953647,-0.8039349077042729,20.44497541603259 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark05(-0.2617741692224157,-23.525213472622106,-20.020380058918175 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark05(-0.26185460796916576,-1.5707963267948966,-71.022638977432 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark05(-0.262850715102509,-67.3780999328053,-122.41529192047847 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark05(-0.2631429821687694,-1.5707963267948912,-4.141592682264391 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark05(-0.26360892247047135,-10.939342693587223,-1.5707963280897053 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark05(-0.2636972496481069,-3.141592669246486,77.16813541035 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark05(-0.26402763186729383,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark05(-0.26455385612942245,-0.04837695225195279,-43.49328704546303 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark05(-0.2647249417955755,-1.5707963267948966,-6.454523566418074 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark05(-0.26562764235682534,-9.725361640215326,-70.05064627535353 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark05(-0.26637118352523004,-41.377192933571294,-55.52815254528727 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark05(-0.26658490054272016,-1.1576852857174071,-9.537204165625774 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark05(-0.2670343789626884,-54.751465255147444,-0.0030474453496752867 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark05(-0.2670445853698404,-35.35860494964085,-45.40361439648444 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark05(-0.26720797660505186,-2.002083095183101E-146,-90.63657604529119 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark05(-0.267605097933582,-67.50719496324459,-14.752743273825605 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark05(-0.26786943888393694,-17.1231704716389,-9.064549578624433 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark05(-0.2679257348270362,-1.5707963267948948,67.70282609946912 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark05(-0.2681029599540857,-4.660878538601876,6.283200565968685 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark05(-0.2693920368257092,-61.08738280756124,-17.378494344531706 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark05(-0.27100109741959694,-1.5707963267948966,51.69559644431532 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark05(-0.27125118973154205,-0.23172817917453642,-48.817327881789716 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark05(-0.2715831074635154,-1.5707963267948966,22.695514884311436 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark05(-0.2718943452857556,-72.54407033443384,-6.983272752429274 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark05(-0.27198869899266404,-9.42479323659663,-31.732358134822988 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark05(-0.2723109960789173,-0.011693658987556341,-43.48694038582599 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark05(-0.27259661878630387,-141.4360298743035,6.907675384096372 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark05(-0.2728548718691929,-9.63123049628048,3.2065883500211885 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark05(-0.27291922414734415,-16.12634168993037,55.18792786681922 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark05(-0.2731582902567836,-1.5707963267948966,-71.03969985420392 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark05(-0.2733446714092277,4.141592653589794,69.3430357559347 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark05(-0.27343498120079784,-996.2807967604581,20.476823659772634 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark05(-0.27349808331596404,3.6387657928953024E-7,-119.2515831825963 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark05(-0.2741837314648127,-1.3472840502605997E-4,34.97965482136914 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark05(-0.2752271342234991,-53.801364173080955,-1.5707963267949054 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark05(-0.2754500160083315,-0.1668267141270171,20.918694160358584 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark05(-0.2756406837975768,2.4293074249901916,26.703537555513243 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark05(-0.27587800504439275,-3.1494135966501453,-41.92237854765911 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark05(-0.2762302809011028,-92.18793132467206,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark05(-0.27668564908593274,-1.5707963267948966,-19.143310819877495 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark05(-0.276690511968583,-72.97023941565851,0.6974600470272948 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark05(-0.27673990043791064,9.460147100936283,0.6842258878587888 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark05(-0.27701986620132096,-40.99969453083252,1.7585084253763126 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark05(-0.2776619651636235,-1.5707963267948966,95.40644589812248 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark05(-0.27770045838954394,-9.545142982040772,-3.180480582218067 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark05(-0.27813353348306846,-10.833444452280812,0.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark05(-0.278329050906321,-54.544949571367496,-1.5707963267948966 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark05(-0.2788942555080789,-79.1358131070691,84.2424872697795 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark05(-0.2789959225040091,-48.50968883144804,-3.5053307530326947 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark05(-0.27905972184768785,-29.564856083112126,-1.4185787451708531 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark05(-0.2793489884420198,4.141592653590019,19.526336194373155 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark05(-0.2795265293336599,-91.94475300438259,6.406665904585923E-145 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark05(-0.2797888006194773,-1.5707963267948966,12.950188768988923 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark05(-0.2800185230885561,-72.74808248775003,-51.56630433810118 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark05(-0.280099820281535,-61.000506820980156,40.91411130392393 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark05(-0.28043154679695736,-42.072619982616274,0.4962423585483774 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark05(-0.28073664331461634,-72.44797259250322,-49.95953351550736 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark05(-0.2809580717554969,-0.27155570826563835,90.35516627999914 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark05(0.2814330358678684,-0.710754161867054,-21.786372517168445 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark05(-0.2814512104357186,-0.6454286640663893,6.966118894340069 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark05(-0.2817053906246132,-1.5707963267948966,59.66724064424602 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark05(-0.28172371093833937,-1.5707963267948966,1.5686183795615338 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark05(-0.2818525540370026,-117.77466929964808,71.13641398328883 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark05(-0.28308097708829694,-42.061967531457256,-26.908088350827953 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark05(-0.2833909077448915,-1.5707963267948966,-43.64409894608428 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark05(-0.283624958521985,-28.39840458423464,-79.25796925017698 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark05(-0.28368233285580563,-0.021368001534339043,12.56832374439266 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark05(-0.28380829496388604,-98.53612916495761,1.5707963267948966 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark05(-0.28409602791854954,-3.2665926535898127,-15.371626996024474 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark05(-0.28410342894203505,-41.573168252699666,-3.5872353081183945 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark05(-0.28423731575692734,-61.089130142718325,49.91629261618863 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark05(-0.28454263731465473,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark05(-0.28464775127403324,-1.5707963267948966,-32.502787868887665 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark05(-0.2849192206718314,-1.5707963267948966,0.3545957727502431 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark05(-0.2850760786378004,-98.92971501719478,1.5707963267948968 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark05(-0.2854029329745913,-1.57079632679415,1.5115578278294235 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark05(-0.28557701173924477,-0.04232344954376789,-82.47476867957822 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark05(-0.28577749251970586,-1.5707963267948948,-64.07460488011338 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark05(-0.2858703974569586,-23.48169198036213,0.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark05(-0.28626857827094443,3.1415926684909974,-1.5707963267948966 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark05(-0.28629103259419963,-1.5173567666712453,-94.1859838482425 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark05(-0.28645949603363974,-22.3788095254349,20.999873336748564 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark05(-0.28668838961483456,-15.723588267990426,0.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark05(-0.28819201381458015,-35.824593198950524,-78.27209584515843 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark05(-0.28830969700318043,-1.5707963267948966,43.20190002366212 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark05(-0.289516862239232,-0.477576784692736,80.54942176711299 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark05(-0.29009730806558326,-537.860302504369,-70.71981779690016 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark05(0.29039272406686123,-84.82495524255344,1.5707963267948966 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark05(-0.29040146450418625,-35.50728451939847,1.5707963267948948 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark05(-0.2906737698022823,-79.5641098859883,-61.261500713435225 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark05(-0.29111080464189343,-1.5707963059929395,-55.426024022460865 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark05(-0.29166303755571477,-1.5707963267948966,-1.1480436022830232 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark05(-0.29175646451312787,-97.95322957923234,1.1179600020390215 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark05(-0.2918502825600129,-1.5707963267949159,-121.98962127255726 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark05(-0.2920407741163995,-79.66874452055748,12.566378116983 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark05(-0.2926736053836736,-122.58609391435948,96.43262575863093 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark05(-0.29311353214502534,-10.838070370540098,-7.144527476642281 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark05(-0.29324733070607206,-54.854090094150514,4.141592653677472 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark05(-0.2934591089488823,-1.464677614365156,-76.20233958741231 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark05(-0.2942976987225729,-53.987884538018484,-1.5707963267948966 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark05(-0.29444841924527054,-3.813486814255839,88.54980113319039 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark05(-0.2947017437553634,-10.82436199179773,-41.232526585999395 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark05(-0.29491837075899335,-4.819839730205768E-181,-45.21979503863422 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark05(-0.2952765863309895,-1.570796326787912,81.94599001584177 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark05(-0.295281484432188,-0.005106842813143736,3.1416002830684078 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark05(-0.2953577112511774,-0.2060513124983659,-1073.279527993325 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark05(-0.29549630048966513,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark05(-0.29581182693801866,4.437243609912304,85.39167018790613 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark05(-0.29593529486675346,-53.65457296274015,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark05(-0.29594303715045245,-1.5707963267948966,7.397709718882574 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark05(-0.29603174756552786,-28.759525543199473,-260.2281341393229 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark05(-0.29611356231783553,-66.52204588637996,0.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark05(-0.29727169048105806,-97.78279571793682,54.977871437821385 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark05(-0.2974964563847752,-0.549061396621332,1.5707963267948983 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark05(-0.29819786140106075,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark05(-0.29854158081951054,-0.025907767389378833,-56.37150110722446 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark05(-0.29902660553976923,-73.41234636586154,1.5707963267948968 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark05(-0.2995430269266236,-4.163332043064322E-11,182.350371802253 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark05(-0.30007952865663023,-777.4617071270162,-117.66114541679653 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark05(-0.30039200431362145,-1.5707963267948983,210.19363256899263 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark05(-0.30062522031633027,-1.570796326724432,27.040793080515 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark05(-0.3010127535821249,-1.5707963267948966,7.048148131122687 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark05(-0.30115477610996455,-1.5707963267948966,56.34393177512273 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark05(-0.3015621914921344,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark05(-0.3033041750786675,-2.1684043449710089E-19,0.5498670618381788 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark05(-0.30331342449859827,-54.809037585242194,55.39959953964937 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark05(-0.30362784468717846,-9.948291632692044,42.53650082459477 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark05(-0.3038831735716603,-53.74398526912888,0.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark05(-0.30388351563094257,-3.3562425258215486E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark05(-0.3041832617031348,8.552651986734062E-17,-0.09524630575948478 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark05(-0.30508340791700717,-908.0901448180873,-49.71586280949256 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark05(-0.305262616946842,-78.69035932128152,9.800281149736302 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark05(-0.3056349433986183,-0.26864452976273157,-32.876087700787366 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark05(-0.3058976781137218,-3.1416721182951184,0.0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark05(-0.30610627675050484,-4.566046055775573,-42.21422852180541 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark05(-0.3064010962572506,-72.45450373594184,309.1799502016205 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark05(-0.30646157475266494,-1.570790094892457,-77.26494227823117 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark05(-0.3066427587386036,-123.00294363038033,472.3921297332967 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark05(-0.30696591854638133,-22.05914233051515,-19.129532602585385 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark05(-0.30738120372202227,-179.24292807023997,85.82018014124378 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark05(-0.3084170965103021,-9.618601203507517,1.9333573510558946 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark05(-0.30858457569854214,-10.477728656174635,-1368.7240599305653 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark05(-0.3093174100703432,-98.6876988814231,91.16636022561272 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark05(-0.3098292139337107,-92.37986441881596,-1.1711205004890672 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark05(-0.31051181755518065,-0.37120603598528124,1.5707963267948974 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark05(-0.31067574077397353,-73.42775700325082,54.809028486946175 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark05(-0.31077453232196445,-85.06848907727822,-78.41543353648177 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark05(-0.31211160780919744,-22.56324003785481,3.1415926535897953 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark05(-0.3125791207079788,-2.710505431213761E-20,-17.113399544352575 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark05(-0.3126767407761948,-0.397162635809726,70.36892095097895 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark05(-0.3131861811523781,-59.69123698070607,-0.7041374758748362 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark05(-0.31324695511749523,4.141592653593607,70.81227786347719 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark05(-0.3134752534815404,-66.50553471405972,7.856381098468596 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark05(-0.31373990371128413,-10.191841428312799,10.369981732236838 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark05(-0.3138377008686724,-1.5707963267948966,82.31530628608901 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark05(-0.3138507831374436,-3.377017006114542E-226,62.20195185579299 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark05(-0.31400711310771307,-1.5707963267948966,-1.570796326699462 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark05(-0.3141361545429209,-1.5707963267948966,89.20919842966569 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark05(-0.3145743202630882,-1.5707963267948912,-10.36693916443376 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark05(-0.31458419259455134,-0.8629473738663291,703.26187667058 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark05(-0.31501483564129984,-54.437044797686184,2357.983124225427 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark05(-0.3152895387535694,-92.40650075123492,-83.33036308580552 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark05(-0.31560262792335625,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark05(-0.3159457229954241,-1.5707963267948966,6.472417090261538 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark05(-0.3161041230402735,-3.515798683343233,1.5707963267948966 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark05(-0.31696619141292803,-1.5707963267948963,-1.5707963267948966 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark05(-0.3171066910932833,-9.64575446640465,-31.415926535898027 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark05(-0.3175688307685574,-28.73072694803419,-96.70502502632509 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark05(-0.3176328813626218,-1.5707963267948966,-23.602867460408174 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark05(-0.31765883927647565,-0.3777177286934963,23.18556705601589 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark05(-0.31785492941268345,4.2351647362715017E-22,55.45301050242182 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark05(-0.31800015303186413,-4.698888994413203,-34.786048563570986 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark05(-0.31806081075553183,-41.75447087748063,-45.536444779496364 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark05(-0.31832381200230647,-1.5707963267948912,-1.5707963267948966 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark05(-0.3184588250549104,-4.004166190366202E-146,-55.33616095096523 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark05(-0.31886232158031186,-72.97166453002812,26.734689807792368 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark05(-0.3190504451917292,-9.425270958983521,-35.388441677478525 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark05(-0.3192260314288117,-8.470329472543003E-22,-1.5707963267948966 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark05(-0.3203803338292994,-15.929380318643169,-25.919266506310095 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark05(-0.3209645141479253,-0.3227455937830941,38.182538865191475 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark05(-0.3216580523057362,-40.85711741225395,-22.853444460950897 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark05(-0.32188983005209126,-48.22167198207799,1.5707963267948966 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark05(-0.3220157819998018,-47.123889811297765,-55.195914386503574 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark05(-0.32224817526985494,-79.28536708683347,31.725076134361487 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark05(-0.3226285093879656,-98.48019018091826,-65.92443377437817 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark05(0.32268896597978614,-60.025083219808124,-1.0054276825349129 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark05(-0.3232385790925667,-98.18621605408117,100.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark05(-0.3235310266457052,-74.74901853524196,1.5707963267948983 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark05(-0.32422237482055416,-73.12697902678474,-75.07903251458534 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark05(-0.3246273798132101,-41.802951328788154,-21.571383204967717 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark05(-0.3246590032332279,-1.5707963267948968,-1.5707963267948966 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark05(-0.3248234598889273,-61.02425320919058,90.96528344855506 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark05(-0.3248772477467168,-54.170686927575275,-24.26772108310533 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark05(-0.3248843027301902,-66.50717189433078,13.613962833834222 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark05(-0.3250662127547935,-3.211839966577699,1.5707963267948966 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark05(-0.3251967737364812,-122.9917393952523,-60.30792056122798 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark05(-0.325408345076407,-66.51302033201554,-20.507095418366276 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark05(-0.3254792951181054,-10.796148871900126,1.5707963267948832 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark05(-0.32561162842078517,-73.8240918693092,-35.94761463214186 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark05(-0.3267055545716828,-54.120594297009546,0.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark05(-0.3275354458712654,-98.34142234803966,0.9242546886667351 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark05(-0.3278740336788363,-1.25964404023095,100.0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark05(-0.3280755427219013,-600.521276420936,-1.334744146466293 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark05(-0.32832722282262866,-1.5707963267948963,13.72118308991108 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark05(-0.32843649667307945,-35.36174392015953,7.446780445749251 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark05(-0.3284761236516131,-1.5707963267948966,-53.40707511102649 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark05(-0.3286588006370038,-22.01296919217896,-9.939320125379357 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark05(-0.3291142601985585,-2.1175823681357508E-22,-53.26739152861015 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark05(-0.3298097245180662,-10.189245034684982,-2.010960300021516 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark05(-0.329929150380848,-4.347782707075943,-26.78032568619441 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark05(-0.33009952270862686,-1.2108989601227498,1.5707963267948966 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark05(-0.330457195502607,-0.238113824455624,-99.98747776056128 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark05(-0.33048630420156144,-4.141592754206758,-7.391544242468456 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark05(-0.33061738514559713,-1.5707963267948966,-1.570796326954847 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark05(-0.3310899733581897,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark05(-0.33233417468609155,-0.5143485479440408,1.570796326794896 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark05(-0.332733375211111,-73.50191425802552,-55.25679403254201 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark05(-0.33279611851861984,-60.20032916768977,1.5707963267948968 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark05(-0.33343649202819736,-1.5707963267948966,-62.15159018962981 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark05(-0.333462320571808,-1.570796323601488,0.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark05(-0.3335837020302255,-1.5707963267948966,-39.209426256842406 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark05(-0.33381209032241643,-66.92299265436873,-54.4195587076413 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark05(-0.333892175654217,-10.122891437542076,-1.3329228049539807 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark05(-0.3342426587329632,-1.570796326794879,-17.7738503104569 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark05(-0.3343435428127198,-3.3794150776478213,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark05(-0.3348559151061473,-9.99488090147696,0.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark05(-0.3350725258568751,-0.6482220811923597,1.5707963267948966 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark05(-0.33553629552261555,-58.337012462607476,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark05(-0.33575880387446777,-34.968669914574704,1.5707963267948966 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark05(-0.3363679234150885,-59.69899051100584,-6.283185307179591 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark05(-0.3365566669947753,-1.5707963267948966,-4.406020065239801 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark05(-0.33681941360688833,-48.607958887509426,0.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark05(-0.3372213641411677,-1.5707963267948966,-73.93323705667085 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark05(-0.33729201445116375,-8.881784197001252E-16,-1.5707963267948968 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark05(-0.33731468070111587,-0.007685402973430341,-60.174668632697994 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark05(-0.33794137699040205,-1.1489140137113774,49.95908495914789 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark05(-0.3389745386913958,-35.61730336621143,-0.7906062832824916 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark05(-0.3392518425123124,-1.5707963267948966,-0.030992045193841133 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark05(-0.3394943271326368,-60.655072310170794,1.5707963267948966 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark05(-0.3398723577767053,-7.888609052210118E-31,91.32511265895405 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark05(-0.3398950163426192,-41.01484358548294,-1.5862136483222808E-117 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark05(-0.33991867167008266,-9.59033273393996,84.4909075026868 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark05(-0.3399805028036358,-0.7569607559695939,-54.0255435647099 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark05(-0.34000447972819836,-1.6153372754956763E-6,-19.385757203929842 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark05(-0.3407948075572878,-85.3933592259578,1.5707963267948966 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark05(-0.3422317274299388,-1.5707963267972562,1.5707963267948966 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark05(-0.3423548086527319,-3.1415928934135917,-74.5136877903149 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark05(-0.34242632186662236,4.141592653640679,41.20833849005302 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark05(-0.3429202589343935,-1.1102230246251565E-16,-0.7921302086031299 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark05(-0.343649840912823,-1.5707963267948983,-135.45209255425632 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark05(-0.34365813477440443,-1.5707963267948966,57.984803148143385 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark05(-0.34383326456868946,-1.5707963267948966,-1.1113793747425387E-162 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark05(-0.3450216672638172,-1.5707963267948963,-63.46458676169664 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark05(-0.34527650558932876,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark05(-0.345544088827614,-76.49666710052409,79.4819655823839 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark05(-0.3460555484727839,-1.0640993296326795,-79.8406669597338 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark05(-0.34606274932863085,-79.09674102752602,0.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark05(-0.34616294367056133,-54.976791261704875,10.030195849893175 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark05(-0.3463783560621816,-41.735423556096734,-9.687683308965703 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark05(0.3469410256140212,-1.5707877898372968,0.8252828196904789 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark05(-0.3470472732993596,-1.5707963267948963,-74.9772379217863 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark05(-0.3475861588457701,-1.1093819093419484,56.55650429533285 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark05(-0.34826205114977543,-47.13153923172978,-22.56783231533724 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark05(-0.34842552682983163,-10.548599747643934,-10.011218032903868 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark05(-0.34888736267911113,-53.78735887720322,-123.46300480194779 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark05(-0.34914095277113966,-78.79672854999491,37.407595355651495 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark05(-0.3498301699825914,-16.733814222133333,-14.723156441233662 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark05(-0.34992421865040035,-10.85926112403741,0.4376160537980181 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark05(-0.3505350755793492,-3.141612072705473,56.46847572586755 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark05(-0.35075253094957093,-1.5707963267948912,260.7521090637633 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark05(-0.3507814596574218,-41.466482845365384,-42.49236375138511 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark05(-0.3510970810388134,-16.427671963461677,-97.83241690373987 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark05(-0.3516707082331603,-54.52791960118286,89.53539062730911 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark05(-0.3519154975930899,-1.5707963267948966,3.5181723347227365 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark05(-0.3524638264137798,-28.397563886230827,-47.9871394823489 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark05(-0.3525268444283857,-92.63590947448398,-87.96557086818939 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark05(-0.35294643951137245,-1.5707963267948966,91.106202213101 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark05(-0.3531519677168369,-41.665760599551646,-67.28021576004089 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark05(-0.35333249939078815,-79.06311792423026,-1.5707963267948966 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark05(-0.3534330740250316,-1.5707963267948963,39.48005038246481 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark05(-0.3537552494430696,-72.49346165044176,340.1922903220387 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark05(-0.35506666443961943,-42.04970183757161,-55.53752950698244 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark05(-0.35549237288083,-47.664429232879385,0.599693860632371 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark05(-0.35564032661059114,-1.5707963267948966,1.1669194466470774 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark05(-0.35574584527948055,-48.40974775631077,0.10775340918635573 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark05(-0.3562385188434354,-0.14207532642369824,-12.733003471182691 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark05(-0.35633236111789746,-110.96936279235544,-53.41766718591292 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark05(-0.35643210569424966,-67.47640336830233,-73.82742735936014 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark05(-0.35670663562626403,-72.69133339793072,76.31465386901934 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark05(-0.35688158816158444,-1.2134640965010073,-56.527282315440395 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark05(-0.35712445682936744,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark05(-0.35735871214105563,-1.5707963267948966,3.1494423982685893 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark05(-0.35777946771895763,-1.5707963267948966,-7.966919953323682 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark05(-0.35786284682997194,-6.938893903907228E-18,1.8331875709826406E-13 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark05(-0.35843281513676967,-1.5707963267948948,-76.63310724395613 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark05(-0.3585740789257361,-1.0938256261882005,648.0616890788422 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark05(-0.35890347822766494,-72.25663103256525,9.93538210366004 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark05(-0.35971306149968996,-9.427038366500756,-87.53503524439914 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark05(-0.3598406261734919,-73.82714153174575,-41.939180469838064 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark05(-0.3599022799107756,-1.4532970324769783,69.415123154635 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark05(-0.36001894224106323,-0.005407413002368244,-16.481493854701785 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark05(-0.3601014668526791,-47.91886895670614,-32.382059364974126 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark05(-0.36024949168281195,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark05(-0.3604044308558752,-98.1381849042827,-11.292474901077696 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark05(-0.36048815344410007,-1.5707963267948912,-384.8450934231229 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark05(-0.36128514290213604,-0.01305786123710409,-28.210581289141217 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark05(-0.3613692147680987,-1.5707963267948966,89.68772171479958 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark05(-0.36264826456477306,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark05(-0.3634670804990394,-191.83658547051152,97.90260466813768 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark05(-0.3636587579443963,-1.5707963267948906,-35.94640786121805 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark05(-0.3638797316433449,-61.25209314844828,-59.2627720880661 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark05(-0.3639658691786775,-1.1102230246251565E-16,9.424815081529434 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark05(-0.36407208529968743,-4.440892098500626E-16,94.27557864382587 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark05(-0.3643370649518257,-9.424778437606577,-54.730838298248315 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark05(-0.3645226014047189,-67.52782563660298,0.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark05(-0.36502616226750284,-0.9631931326220808,1.5707963267948966 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark05(-0.36509868698476566,-35.376658657686896,-1.5707963267948966 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark05(-0.36534822726559274,-0.16137897128981893,-26.814297586610508 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark05(-0.36616422435920803,-97.66839177069393,-78.09766412393721 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark05(-0.3664716936921811,-136.54455478631291,-6.28710763277273 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark05(-0.3670315239410604,-35.27636729966367,-3.1494066894712183 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark05(-0.3670467144710923,3.1420809406725536,92.00165434629575 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark05(-0.36708389590448937,-1.5707963267948961,25.220635542863306 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark05(-0.3671004879586519,-3.3815627654969944,31.902756374574825 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark05(-0.36722241431697694,-22.330152930662585,-11.005642214295468 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark05(-0.3673926206699768,-1.5707963267948966,52.42845098348258 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark05(-0.3675272957663589,0.9314098871178514,-77.2806730887291 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark05(-0.36821244062417524,-0.592692364735493,-86.10914873861833 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark05(-0.36856094403007067,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark05(-0.3687423437756292,-0.8343059656922558,-88.10593582581217 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark05(-0.3688173801689043,-1.5707963267948948,-91.86374723302038 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark05(-0.36934141357964556,-60.894376446659166,-17.914039589183986 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark05(-0.37007707444580673,-3.266592653589878,81.943108520303 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark05(-0.37060150591239005,-3.1415926540555192,-1.306517260975597 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark05(-0.3708816597955802,-1.4214482829441804,36.870407457141965 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark05(-0.37142453763838035,-1.5707963267948966,9.579929447626682 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark05(-0.3716798910367538,-10.933801877427342,-0.2830248805292517 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark05(-0.3717631851343226,-1.5707963267948983,97.42942784169199 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark05(-0.3719100382959353,-42.15726923544542,7.853981633976446 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark05(-0.3720837849619773,-3.1420844751317407,-50.11120113835449 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark05(-0.37214276009545344,-73.57638136995318,-19.799424473605157 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark05(-0.3722928935304384,-0.7617765201589596,612.8091833316521 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark05(-0.37260808188315375,-1.5707963267948966,16.80316459229732 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark05(-0.3730544356601224,-2.7755575615628914E-17,-1.5707963267948948 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark05(-0.37305747787328586,-98.2700548372279,-394.06261018322624 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark05(-0.37343613339329285,-1.5707963267948966,70.425072844505 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark05(-0.3737285428737175,-1.5707963267948966,3.6790778940225426 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark05(-0.37385224524688365,-92.40393955344763,-63.17584005257021 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark05(-0.37430089595568494,-1.5707963267948966,-73.05938032189734 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark05(-0.3748895422621459,-1.570796326794896,90.90259037739946 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark05(-0.3754200452588316,-1.5707963267937788,0.2939996401612983 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark05(-0.37617966893572374,-0.06704687526937114,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark05(-0.3769705915235476,-22.198659863187537,-51.73427783088918 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark05(-0.3769801571248288,-73.7492811686536,-45.185446187797915 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark05(-0.3770284952789909,-1.3899475639132528,-47.2342802391954 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark05(-0.3770633740374336,-104.87011327006066,1.4800960443327005 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark05(-0.37714899252478157,-1.5707963267948957,19.99964202873477 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark05(-0.37715652578522707,-0.007367219050180872,38.92997175050638 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark05(-0.3773078570178825,58.47707301361055,22.911406561253784 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark05(-0.3774022643257454,-1.5707963267948912,-52.402262487716996 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark05(-0.3776371937230929,-1.0822414688228799,-21.861159701379734 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark05(-0.3779300513923558,-73.7060817539975,-8.244295942461425 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark05(-0.3780889082479737,-0.06223757226134867,604.2553824841533 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark05(-0.3783762878035217,-142.5803431587036,-18.513422560664715 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark05(-0.3786356803937901,-3.512800358287187,100.0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark05(-0.37929861354540034,-3.907769985237948,-857.1409039038115 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark05(-0.379416650109606,2.5849394142282115E-26,1.5707963267948966 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark05(-0.3795598672286893,-79.73548827464737,127.02403389434487 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark05(-0.3811855026366575,-0.7460392220910481,-28.4915374798626 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark05(-0.38121397024615883,-60.788723045311045,67.0688419239785 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark05(-0.3814201082996398,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark05(-0.3818143132705944,-15.707963267948967,85.45324926179876 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark05(-0.3819358805269789,-4.252639604350557,12.58945564455243 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark05(-0.38249202674202865,-35.91196032293287,9.48443542537759 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark05(-0.38369962452857864,-35.71286435007441,48.63906533998817 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark05(-0.3839704575125866,-1.5707963267948948,-42.995507471664254 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark05(-0.38401728500706045,0.8858164533286782,-6.315623314285221 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark05(-0.38432893010492547,-1.5707963267948966,-1.5707963267949034 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark05(-0.38466905513804023,-1.5707963267948966,-57.873883884370144 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark05(-0.3848170553033109,-3.1494052593724455,-4.378129911751023 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark05(-0.3848743040371801,-1.5707963267948966,84.47013581211968 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark05(-0.3849458461621998,-1.5707963267948966,-82.83415208436116 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark05(-0.3853084719600577,-41.09496848397787,1.5707963267948983 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark05(-0.38554372799296455,-36.096986441612415,-39.885571057245286 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark05(-0.38572243479158436,-0.08249011163987602,87.61145833488497 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark05(-0.3871695579468631,-1.5707963267948966,0.7205476925698395 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark05(-0.38739165055432384,-154.17744469680073,50.17571707671458 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark05(0.388916395417488,-98.25101822347209,-51.02374176006208 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark05(-0.3889551711974905,-0.02921015276575538,32.4249507593739 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark05(-0.3895126311059258,-1.5707963267948966,-85.60508121307504 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark05(-0.39113581547603005,-98.92447813364134,9.782120539184618 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark05(-0.39144090044385593,-1.5707963267946359,-0.05138151596635715 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark05(-0.3916432390156793,-54.657935762746796,-3.141699401188979 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark05(-0.3928277788083087,-60.917931007842974,45.01457545365369 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark05(-0.3932780956789352,-1.5707963267948966,-0.6344212773205464 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark05(-0.3942626964338771,-1.5707963267948966,49.308035495691854 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark05(-0.39468558255665537,-9.621745347027186,46.94447047181666 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark05(-0.3955270934486027,-0.6774684299663047,78.37641491433105 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark05(-0.39552895849015735,-66.60368072432911,-8.853981633967594 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark05(-0.39623372772025367,-10.94358176819243,-1.5707963267948966 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark05(-0.39725750122819625,-1.4566731802201118,-77.25986698254061 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark05(-0.39787958418445823,-3.2665926535900343,0.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark05(-0.3992548695775643,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark05(-0.3997815193522782,-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark05(-0.3999782725490345,-1.5707963267948966,-26.08401885264844 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark05(-0.39999454521350986,-67.17155412273088,-19.054514662368945 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark05(-0.4003457685809837,-909.393612160082,1.5707963267948966 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark05(-0.4006342794117517,-1.351693230830066,85.4147111591123 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark05(-0.40103225165178685,-41.015848710434646,1.5707963267948966 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark05(-0.40150066481025937,-53.85562477627189,-41.997341912844995 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark05(-0.40150856936940266,-1.5707963267948966,-1.5707963091549348 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark05(-0.40181155185090045,-0.5639686956103338,-27.723204673506736 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark05(-0.4020453703998871,-53.676765274651736,-27.111862591975978 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark05(-0.4022418610244339,-1.5707963267948966,-42.17025089842228 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark05(-0.4022609824653189,-1.5373616176487563,6.776335652232106 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark05(-0.40236902756035775,-17.122293785953516,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark05(-0.402379437111132,-122.70544140803692,-41.237184434139415 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark05(-0.4027696403752381,-25.248187658872226,-58.95744016964337 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark05(-0.4030021086214402,-15.727192253529807,-67.37041796542317 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark05(-0.40312934927105604,-1.5707963267948983,57.20911710721431 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark05(-0.4032824512168154,-123.01511142678496,112.85766005060013 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark05(-0.403658260888351,-1.4970400271258908,51.42399409654581 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark05(-0.4037049681463222,-5.421010862427522E-20,48.80214343838222 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark05(-0.4041495807268368,-0.2092727084802415,-10.632712625461927 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark05(-0.40513469939367824,-10.049710143140516,-3.2665926549984796 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark05(-0.4053224288449726,-1.434285958149647,-0.6116349547969235 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark05(-0.4057502890206913,-98.08236187582766,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark05(-0.40643582840743964,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark05(-0.40681432423463365,-3.1416002830297134,5.962774134784539 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark05(-0.40690485115991604,-67.38904699979359,6.298815627131949 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark05(-0.4070648858159341,-1.2029239334526587,3.883736670831837 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark05(-0.4071615377411752,-1.5707963267948966,28.699722448642763 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark05(-0.40727310188384114,-3.1416075024106154,88.51895970220255 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark05(-0.40746133689113795,-85.99638719473934,-1.5707963267948983 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark05(-0.407548235903753,-1.1102230246251565E-16,409.7406824608725 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark05(-0.4078391450906018,-1.5488771888720714,-144.75746225309402 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark05(-0.4082319495473138,-1.5707963267937,0.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark05(-0.4088823423295371,-1.3597051638945203,3.1416002848069144 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark05(-0.4093903360506256,-0.009826453620652325,-16.94899097376799 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark05(-0.4097233318101985,-1.5707963267948983,-45.74467866921694 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark05(-0.4100468747383714,-0.6661012244439813,3.141593634243874 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark05(-0.4101727443209072,-0.2844323664916786,63.62854920512038 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark05(-0.41024492054605155,-10.55280865337356,-34.58787719512267 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark05(-0.41082127740103225,-191.64170246865794,7.321239874594411 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark05(-0.41091309342955307,-0.23795852060559763,-152.99334966955155 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark05(-0.41121587241889695,-0.668400372146061,62.18052893556302 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark05(-0.4116672309701187,-73.06632779532882,-76.34940737546216 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark05(-0.4120078089528054,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark05(-0.4125670065658579,-1.5707963267948966,-3.30841189573587 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark05(-0.4128412242025076,-1.5707963267948966,-72.9744301715692 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark05(-0.4131629057974757,-1.5707963267948912,-26.55939093907967 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark05(-0.41360600762256183,-9.594656465966152,-1236.8440094392372 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark05(-0.4137148118565027,-1.5707963267948966,0.01700767795007637 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark05(-0.41396898145211136,-167.96883693094242,31.403367657281137 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark05(-0.41445881281170394,-576.4564993999313,-1.5707963267948966 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark05(-0.41450917189684544,-47.415444861425456,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark05(-0.4146888243142529,-1.5707963267948966,-32.37959180958879 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark05(-0.41497990486194514,-0.09208947831161024,38.71408723876388 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark05(-0.4153918726602218,-78.61328478025776,-90.88287430690666 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark05(-0.41564098434995056,-311.927399701004,1.5707963267948983 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark05(-0.41565383458573635,-54.462715380873085,-3.4813491095528377 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark05(-0.4157164724697274,-66.93856217233717,-1.5707963267948966 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark05(-0.41597615121069226,-1.0858362424975183,-78.20926783229699 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark05(-0.4163656538919924,-154.57707440147078,-51.72113594602203 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark05(-0.41685676569660146,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark05(-0.4169580134179768,-3.2642372721575414,-42.073482580113684 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark05(-0.41709665750968344,-1.5707963267948948,-4.3970058003845525 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark05(-0.41750272838247204,-0.5254778683746613,8.103994307199745 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark05(-0.4181769220869981,-67.35395274851093,-9.536242742855396 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark05(0.4185455293918293,-3.1417241279111328,1.5707963267948966 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark05(-0.41860994221496856,-1.5707963267948966,-19.420985401177745 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark05(-0.41947383483936207,-1.5707963267948966,-5.631633662247589 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark05(-0.4199325147380913,-1.5707963267948966,-86.39379797371932 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark05(-0.42025721402540184,-66.24541895024274,42.748205773121796 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark05(-0.4210224496870842,-1.5707963267948966,83.25531316921351 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark05(-0.4211542280119367,-1.5707963267948966,-95.2477796076374 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark05(-0.42127569603241843,-3.14942132067074,0.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark05(-0.421457223875022,-0.5696066225446441,-36.76797638389167 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark05(-0.421579708262363,-4.6955879603187425,-89.61271754157764 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark05(-0.42181092474919524,-53.82243923544059,-29.04910557671427 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark05(-0.42186240236898387,-0.8065716037671531,-1.0511294437337153 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark05(-0.42186527960698683,-1.5707963267948966,18.117980582728105 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark05(-0.42188217779896947,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark05(-0.42199105229527883,-3.2042193551095313,1.5707963267948966 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark05(-0.4221997538589962,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark05(-0.4222785529410977,-0.0872742514012469,204.19895716086583 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark05(-0.42235779172288357,-54.857325633243654,-49.907183170787846 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark05(-0.42286650281120397,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark05(-0.42299866686580767,-23.295121408357982,-425.09801495132774 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark05(-0.4231019815988277,-67.53293924311134,-6.284186212416434 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark05(-0.42396457484316596,-1.5707963267948966,55.75917652862822 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark05(-0.4239824444643004,-1.5707963267948966,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark05(-0.424051997760703,-35.957121879785824,-1.450448563495822 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark05(-0.4240755249211632,-1.5707963267948912,-24.047393136844114 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark05(-0.4242085699328557,-1.5707963267948957,5.141592653961307 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark05(-0.4246079747922197,-92.54361613283943,-49.83452344090364 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark05(-0.4247069511882441,-1.5707963267948957,28.45629669621378 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark05(-0.4247276789989252,-1.5707963267948966,11.481935807412594 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark05(-0.4251544446471547,-10.053578994039974,-100.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark05(0.42529893642459393,-3.1435465178386153,-48.95730898331169 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark05(-0.42605830560885954,9.716933488903983,-20.908735526637955 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark05(-0.42618386899137306,-35.67357005768328,11.740663296890801 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark05(0.42676861522663534,-10.755738572911882,-3.1436550820621356 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark05(-0.42680150322085475,-1.0729921945675436,-1.5707963267948966 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark05(-0.4272251740295122,-1.5707963267948966,3.1583707613452328 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark05(-0.4273014248280635,-0.49999892814877495,0.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark05(-0.4274617872084324,-1.4666220800519516,0.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark05(-0.427483289486971,-48.157125445586274,-1.5707963267948966 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark05(-0.4275226203608892,-66.24022039472761,20.420352248333657 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark05(-0.42791567982066064,-1.4515385068415831,-0.7930145670942763 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark05(-0.42796957428981774,-1.2613593310362172,21.507175468632454 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark05(-0.4291266888857941,-48.26268945256427,-10.294082794167052 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark05(-0.4295225828914081,-10.473344290734225,-67.97465410478684 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark05(0.4296505547881544,-4.141608115478149,-21.878510714529796 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark05(-0.4298565025848208,-85.8293986457098,-18.278848576076697 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark05(-0.42996938845446486,-1.5707963267948966,54.74943835274041 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark05(-0.4309308556383541,-22.431804243865407,-42.93972805376853 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark05(-0.43180183991229937,-0.8604500730058056,392.12200010293395 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark05(-0.43195900116826513,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark05(-0.4326316265186101,-10.58062281824927,-4.544218531220476 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark05(-0.432815038826439,-53.7162976325486,-4.7123905380842634 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark05(-0.43355960237458024,-61.04794609907476,-69.5471147902998 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark05(-0.4340103167483377,-97.88323666042729,1.5707963267948966 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark05(-0.43478897182262266,-1.5707963267948948,-76.72731143546517 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark05(-0.43491327903872445,-155.44739782358528,-65.97638440300548 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark05(-0.43539666768226953,-1.5707963267948983,-1.5482073396613034 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark05(-0.4354674125821899,-3.1417622607321674,-54.99525933983098 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark05(-0.4361336124496838,-98.93958446943442,22.530186572514932 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark05(-0.43628382368247837,10.479333113109398,-73.78859959782682 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark05(-0.4363931118919318,-47.598228512859734,-44.66906935008807 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark05(-0.4366996439436548,-79.34278351492657,-82.43281362510895 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark05(-0.43685018167427625,-29.72839771508519,-9.760020430724392 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark05(-0.43789167129485046,-35.8185334539859,-16.000200857531937 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark05(-0.4382724136647,-4.370271553365062E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark05(-0.4391594625317347,2.1684043449710089E-19,-28.687214034155673 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark05(-0.4394429237667583,-0.2218048452650656,-68.75003084030871 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark05(-0.4394931525631532,-1.5707963267948966,74.1441421966756 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark05(-0.43989276743771805,-66.39501271912015,51.115822864005 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark05(-0.4402241950273815,-3.484926173037735,42.578868140263985 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark05(-0.44032264724733805,-60.197725708606384,-1.5707963267949054 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark05(-0.44110826948078224,-10.398252914283397,88.74719920927224 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark05(-0.4413184037966227,-79.79044806488771,384.59625452545794 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark05(-0.4415650345721358,-0.017542604487673974,90.61521805482442 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark05(-0.44176723083368163,-0.20918579121261477,28.5048601073438 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark05(-0.4421493447176502,-1.5707963267948966,-77.4773851233648 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark05(-0.44294593756924155,-10.577956217527937,-1.5707963267948912 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark05(-0.44336155695934143,-98.14119923564347,44.3339268441489 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark05(-0.44339464757015906,-66.48482795881856,-77.57659719518253 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark05(-0.4436888450586563,-0.26516223886434465,-94.24777960769386 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark05(-0.4437642617615372,-91.53542091269051,-139.81334986167943 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark05(-0.4450810739116734,-48.18226343224305,1.726966343342788 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark05(-0.4452822660149623,-3.2450025394675084,1.5707963267948966 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark05(-0.44565547972626085,-1.5707963267948966,117.51555625941913 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark05(0.44672476181849136,-79.4633189056288,1.5707963267948966 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark05(-0.4467793745786646,-10.286957196662964,-2.2608914603631343 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark05(-0.44724997982308806,-54.53839101534396,-37.53379916758556 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark05(-0.4473182706969914,-167.92439050066434,-1.5707963267948966 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark05(-0.44790140223047614,-0.45694571687643326,31.67742109044113 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark05(-0.44843467676643783,-72.48154423136405,0.4968652417839863 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark05(-0.448799660240396,-0.13148455573472684,82.1908356243772 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark05(-0.4490055948743463,-28.52034014027395,-10.385869704460902 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark05(-0.44987625492768496,-34.75585756660526,1.5707963267948966 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark05(-0.4499425034457456,-122.86216149932112,-47.84881709941003 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark05(-0.4501691332007094,-6.306227085916247E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark05(-0.45030420632219564,-1.5707963267948966,-70.54626322061466 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark05(-0.45088319368226754,-84.94776894162149,-83.02489407148954 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark05(-0.45169728737406134,4.930380657631324E-32,33.393607362508334 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark05(-0.45181798494395253,-1.5707963267948966,-45.5270020083233 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark05(-0.45387419671060736,-104.65271713990722,-56.41990918880685 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark05(-0.4542790857288119,-135.59585618663752,-43.00682281700963 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark05(-0.45487931770550616,-4.0203783026139694,-9.6687097636973 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark05(-0.4554343750374712,-1.5707963267948948,7.426963968145814E-8 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark05(-0.4554389881200465,-1.5707963267948966,29.84460504695403 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark05(-0.4559336744052871,-9.509690899574053,1.5707963267948983 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark05(-0.4561405181050062,-29.807272208752273,-185.18477871606845 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark05(-0.45648630558465575,-1.5707963267948966,-18.274477265012592 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark05(-0.45660609373868216,-78.80146339034953,-1.2362309659808928 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark05(-0.45688489924661546,-9.850546471228215,-13.014758205262837 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark05(-0.4571756109726031,-72.57924963063223,-1.5707963267948966 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark05(-0.4575172015706897,28.703537555513243,-72.72327445860486 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark05(-0.45797140466778785,-0.401634740134834,3.9199018565248736 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark05(-0.45860799148940146,-47.42721538746909,-73.81189842958007 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark05(-0.4588739818626094,-66.99339149164359,-20.789350578503274 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark05(-0.4604062138113624,-1.5707963267948966,41.90041320868934 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark05(-0.4606736934111272,-1.5707963267948966,81.96447993140103 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark05(-0.4608223137524866,-1.5707963267948966,38.44555328470862 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark05(-0.4613192350502283,-1.5707963267948966,-21.446215695985543 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark05(-0.462679441466733,-72.97052750289023,4.814867327416536 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark05(-0.4627034083744368,-129.56637436651954,0.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark05(-0.4632821696986764,-9.536699336785746,15.127224132132824 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark05(-0.4633050695314222,-54.834521610354614,-1.5707963267948966 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark05(0.46373390623667043,-1.5707963267948966,32.80329987641199 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark05(-0.4646688982607895,-73.1217497327655,1.5707963267948966 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark05(-0.4647205107487924,-35.987697128998164,-9.424794781735963 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark05(-0.46489944118054366,-98.93781555112943,-88.20502449888886 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark05(-0.46503409295992004,-1.5707963267948966,59.829512920779116 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark05(-0.46512764089923364,-1.5707963267948966,57.96147101868706 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark05(-0.46543399227522375,-2595.557575576901,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark05(-0.4659850299404764,-67.18120645376449,95.92243842571912 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark05(-0.4660985306626029,-1.5707963267948966,-45.415542695538825 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark05(-0.46620609589773,-67.20171459527948,-92.30050662255371 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark05(-0.4664159360370945,-8.543646725331698,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark05(-0.4668318228050305,-10.148670158213324,-6.2836974461826705 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark05(-0.46685226007316816,-1.569049607407668,-1.5707963267948966 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark05(-0.46691609024512876,-41.743008702410926,6.2831854066018265 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark05(-0.46694304028387257,-9.85257619006751,-37.196367536417114 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark05(-0.46738251655814445,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark05(-0.46756886885545923,-1.0957273356636072,-0.5517459388876798 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark05(-0.46869721768869166,-34.55849575337097,111.79443593998201 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark05(-0.47021605400017563,-104.62870886920047,8.103981956051442 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark05(-0.47038241966798067,-98.9460384077988,393.97484449844364 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark05(-0.47050393665162366,-1.5707963267948966,-44.05354999052746 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark05(-0.4705149685729353,-1.5707963267948912,-85.20203740089099 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark05(-0.47062933723033956,-1.5707963267921392,47.259113278627005 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark05(-0.4721950470868894,-66.81360032493994,50.12949919694567 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark05(-0.47220816865528303,-3.3454289098485432,-1.5707963267948966 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark05(-0.47223512847464444,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark05(-0.47242671963044125,-0.41087381256761657,-21.652415547309808 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark05(-0.47274983442667384,-1.5707963267948983,-148.2208411251258 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark05(-0.47311323985986126,-1.5707963267948966,-94.56133829173248 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark05(-0.4734284846721242,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark05(-0.474263508708885,-1.5707963267948966,60.88810407563644 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark05(-0.47448564079678435,-946.368942795565,-42.734712968341476 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark05(-0.47649996794078486,-123.00893298492306,54.998750630927304 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark05(-0.4768236593240599,-1.5707963267948966,66.24947080789437 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark05(-0.477342758184813,-54.79183587654371,76.860681077507 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark05(-0.4783549018694231,-98.56075132213778,-60.82411538469636 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark05(-0.4783650847802695,-79.07928292685133,-0.42244150653817447 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark05(0.47892436303500074,-9.428758970628635,-112.84038547439464 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark05(-0.478961359134893,-2.5269841324701218E-175,100.0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark05(-0.4800527486329087,-67.17832522399358,-66.5013161532573 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark05(-0.48026301317186726,-66.4743865854316,8.29740687256859 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark05(-0.4802760676270648,-1.5707963267948966,91.03178210386392 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark05(-0.48225923873354615,-3.1416145406476494,-32.86564800741482 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark05(-0.48237078221539775,-91.61428073005088,-43.0987385681066 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark05(-0.4824455514156796,-66.11830320072923,1.5707963267948966 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark05(-0.48301828081183407,-1.5707963267948966,-52.20976902038676 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark05(-0.48307885767398506,-160.8845730321674,94.25871059027085 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark05(-0.4831047649680919,-7.533800060778693E-17,-91.09236307009367 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark05(-0.48347940076842827,-0.5026407111639608,92.07071520189322 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark05(-0.4836778993410942,-78.83980356593106,91.10618695419976 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark05(-0.48395169538382865,-2.1684043449710089E-19,9.676400890819965 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark05(-0.48464966942670173,-28.37177486105238,1.5707963267948966 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark05(-0.48497907417700337,-142.2271526111506,-135.76317495045106 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark05(-0.4864142902974111,-1.5707963267948966,-0.018720497419604753 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark05(-0.48645557784505566,-1.5707963267948966,95.09822176402173 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark05(-0.4868111108490858,-35.81884873791819,84.53236138015825 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark05(-0.48710791925954494,-53.871863574916546,-0.6473248841531963 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark05(-0.4872786233767438,-0.9089046180191875,16.53535874035954 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark05(-0.48761301742859264,-1.5707963265248372,0.0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark05(-0.48830163148456396,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark05(-0.4891859854721037,-15.708024303332024,-50.23363739555279 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark05(-0.4897746119128735,-3.1619251175517036,-1.5707963267948912 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark05(-0.4897992930880566,-1.5707963267948983,-12.381840901002136 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark05(-0.48989124436506004,-61.122791067741325,-100.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark05(-0.48993203747566494,-1.5707963267948966,-25.847584211757237 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark05(-0.49049759388515457,-16.142825082764062,-51.803450776623635 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark05(-0.49070100318162563,-0.5341425192784612,-79.19862571262725 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark05(-0.49105708517933255,-53.47540235455504,-9.952726340772932 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark05(-0.49107054301883446,-664.3629120130914,3.7806780369473736 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark05(-0.49118482827586807,-1.5707963267950964,1.5707963267948912 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark05(-0.49125773144280915,-0.6249149089145285,-0.6324008036488138 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark05(-0.49132894645463904,-9.83824872888573,-78.28322832758553 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark05(-0.4914555364903484,-42.275976583220796,3.1844887146472427 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark05(-0.4915355514231754,-0.0781190681301025,-19.498178793230526 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark05(-0.49183979440696257,-34.81634507839763,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark05(-0.4926660855956446,-1.5707963267948966,67.28754253048983 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark05(-0.4930652098127384,-1.570796326794893,26.76592123462933 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark05(-0.49356680580618817,-72.31749307722707,1.5707963267949019 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark05(-0.49365461768212643,-54.31933155522882,-31.907988567455106 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark05(-0.4937273643429595,-1.5707963267948966,487.94575023994946 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark05(-0.49474811984096134,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark05(-0.49534480601964503,-0.45894485726725165,0.7285497905873797 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark05(-0.4955015357462038,-72.41207395414517,26.167781256457605 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark05(-0.4959800303427473,-129.92025223025158,-50.91521746125534 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark05(-0.4967085979919329,-86.10459914504698,-79.94744952719783 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark05(-0.49691233739915797,-0.624019287111456,-24.777801961304434 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark05(-0.49724092410755416,-1.5707963267948966,-71.44003603862255 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark05(-0.49743661098081526,-67.35938267549808,-64.20199860674992 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark05(-0.4979737289351818,-1.1949488820765026,68.66283895530924 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark05(0.49846360178455185,-1.5707963267948972,-33.11440217906151 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark05(-0.49859297290521953,-1.5707963267948966,88.42947861568729 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark05(-0.49900791948005785,-9.687542501516475,-52.832946076295315 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark05(-0.49921802712987773,-66.67058480239373,86.44312690461436 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark05(-0.5014102268894183,-0.22211080022147725,-90.74244176366288 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark05(-0.5016596723334776,-1.2911130596292486,86.28980087385023 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark05(-0.5022322998248496,-4.140068121946417,1.5707963267949054 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark05(-0.5024777904041997,-154.51457695302685,27.45320350412935 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark05(-0.5033787615019945,-3.6833298814818254,-22.367564625376644 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark05(-0.5051786371335086,-29.01096685531117,-86.10317193846366 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark05(-0.506737040529762,-110.28412345809598,34.5621829284564 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark05(-0.507002760105077,-0.09996743286735016,-0.33194870611845434 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark05(-0.5070664949398633,-9.937317151094518,-77.40782313071963 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark05(-0.507469205256429,-1.5707963267948966,70.11847019254786 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark05(-0.507636705784592,-0.02059118244332796,19.07111805948007 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark05(-0.5080010258793237,-10.681014890928637,-66.26978130357017 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark05(-0.5081876938882459,-0.8185752714142097,-1.5707963267948966 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark05(-0.5089515631641612,-4.527650860399612,-3.141592668545933 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark05(-0.5090158830809647,-1.5707963267948966,28.76634229071533 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark05(-0.5090216709592956,-53.51230550409251,3.9344098387229565 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark05(-0.5096752133594662,-0.07658737579255646,50.449168995265 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark05(-0.5099417871406242,-1.5707963267948966,-89.73516182726492 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark05(-0.5109364201480524,-10.73539068667337,-81.28440358654115 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark05(-0.5113154200137399,-0.2545072281939872,-4.712405957715164 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark05(-0.5118308917252574,-1.5707963267948966,-6.2831857844703345 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark05(-0.5118552895235409,-10.773290320045419,35.69241235091346 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark05(-0.5120509812234612,-1.5707963267948966,-28.60504505883705 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark05(-0.5131152309579767,-1.5707741520413667,55.37385526039678 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark05(-0.5134499869735663,-48.44525935826848,8.103981634245242 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark05(-0.5136176051784813,-9.571929294522944,-17.840646470442838 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark05(-0.5140358458882932,-28.579117118676287,1.5707963265497127 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark05(-0.5140961101326377,-84.83619766790378,15.488849346266036 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark05(-0.5142249480065929,-1.5707963267948957,-1.6182206692278072 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark05(-0.5145778143813837,-1.5707963267948983,62.8338545616792 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark05(-0.5149813485506165,-1.443885260863793,1.5707963267948963 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark05(-0.5159950241312856,-1.5707963267948957,-16.420004943688618 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark05(-0.5160714110417954,-1.5707963267948966,-48.421039956110825 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark05(-0.5162385056953062,-3.3167029345831054,1.5707963267948983 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark05(-0.5162483957455503,-73.80458842581952,-98.54836919259851 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark05(-0.5165338960176349,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark05(-0.5168260128760735,-92.11533268390454,1.4511835822226011 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark05(-0.5171687733508463,-0.15040426371382,26.315976177582275 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark05(-0.5172284360986423,-1.5707963265597606,-11.494372611448327 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark05(-0.5181976393889556,-0.8798528061990514,-24.119673115487146 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark05(-0.518217612113849,-1.5707963267948983,-67.69423583359323 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark05(-0.518714135406853,-1.5707963267948966,54.626060761060415 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark05(-0.5193992681403921,-1.5707963267948912,12.945064451181906 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark05(-0.5196168759470359,-1.5707963267948966,36.415148803205724 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark05(-0.5198000910019651,-160.27260427074125,-75.84735152694473 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark05(-0.5202664742667054,64.55026534099122,67.74737483433702 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark05(-0.5205007177203033,28.703537559999308,-51.25745237354968 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark05(-0.5205547261658552,-0.07775602890192868,397.41051021777326 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark05(-0.5205832991286599,-28.486508182191475,1.5707963267948966 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark05(-0.5208464111808302,-0.2297751159523096,-74.11625977799794 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark05(-0.5209140281637996,-1.5707963267948948,95.26109648050891 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark05(-0.5211362112504326,-1.5707963267948966,42.24083783097214 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark05(-0.5216279555836355,-1.5707963267948966,38.677275431850575 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark05(-0.5218558479653694,-16.189211856755787,49.915911510910405 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark05(-0.5219896729058334,-3.266592660316089,30.22667392985005 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark05(-0.5220406982560779,-9.97939138585798,-92.63629182230994 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark05(-0.5221221103259162,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark05(-0.5226845002144304,-1.5707963267948966,-5.389035505990627 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark05(-0.5229075694523578,-1.570796326797541,25.698836693036583 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark05(-0.5239230326215759,-92.20017965200684,-0.3681828540424264 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark05(-0.5239264345402269,-10.618759746268221,-26.490701641686705 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark05(-0.5240042821938924,-28.874608539842228,-47.98705633050648 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark05(-0.5244166708113199,-1.5707963267948966,28.36151933446709 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark05(-0.5251302228577828,-92.15142133705245,-35.762572073982795 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark05(-0.5252336779254436,-9.63413648433661,549.7671575331705 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark05(-0.5254518067304037,-1.5707963267948966,12.390336587371392 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark05(-0.5258026471114223,-4.141592654413101,-1.5707963267948963 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark05(-0.5261194030929321,-60.60842202136063,-35.75184593853524 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark05(-0.5270061849113613,-22.402581725374212,3.1435457792327153 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark05(-0.5270410313281366,-53.68646333103741,-83.25220532012952 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark05(-0.5271026231016972,-4.373366502963748,0.0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark05(-0.5271107910373127,2.5751561577862314,6.298826753819561 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark05(-0.528138950950724,-1.5707963267948966,-13.031757449846538 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark05(-0.5281664849425561,-3.1494051760975332,-16.185430452454074 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark05(-0.5289406120103076,-8.881784197001252E-16,25.482516645736993 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark05(-0.5299175393089577,-1.4247245848009453,-73.8211484350538 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark05(-0.5299884586748442,-42.201817808703176,82.78335223320562 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark05(-0.5305464449258596,-1.5707963267948966,4.200527081677075 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark05(-0.5311966279673245,-1.5707962836255183,101.96648332776155 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark05(-0.5314148429610019,-98.60956733300297,-21.542878321538904 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark05(-0.5323642752502474,-4.22707344324545,-59.74925287387718 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark05(-0.5329828100027295,-15.983399369349716,20.192306555554836 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark05(-0.5337997947646489,-22.783613660510095,-13.822747622571747 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark05(-0.5338756662653468,-36.05774228447777,83.77376196951991 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark05(-0.5339161164880214,-79.86372098834454,-23.51453065217288 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark05(-0.5346721488323751,-0.01680407594028969,-56.52251119062833 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark05(-0.5353584445815361,-0.1615599476316939,74.63325519320328 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark05(-0.5357838697984035,-1.5707963267948966,78.52180166876184 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark05(-0.5359924679412087,-1.5707963267948966,95.5054467994899 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark05(-0.536461012225733,-0.41013459739178604,8.283868989361991 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark05(-0.5367900600504072,-0.009457215734601121,66.17719231615493 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark05(-0.5372349172916553,-1.5707963267771323,161.26062399919527 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark05(-0.5372362341410764,-29.82461446658374,-100.0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark05(-0.5375417535670692,-111.51710623641947,-63.24879504177434 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark05(-0.5382351746410116,-1.5707963267948966,91.81745786330406 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark05(-0.5385566602119605,-3.1415937246865724,49.84020802918302 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark05(-0.5387640410705394,-0.24049958751904724,-6.283307477234471 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark05(-0.540341633837871,-10.826325240476496,-0.6407239980965405 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark05(-0.5403800044874536,-16.412967397557786,-3.149405153591081 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark05(-0.5407760788162337,-2.220446049250313E-16,-56.22004785645742 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark05(-0.5410573220841558,-1.5707963267948966,18.872871868339576 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark05(-0.541547156645586,-0.06417273457135297,-56.53396082818527 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark05(-0.541644148989549,-1.5707963267948983,67.40192434046571 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark05(-0.5417786253907321,-1.5707963267948966,-85.19462397445979 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark05(-0.5434556408371536,-1.5707963267948968,-4.71238901199571 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark05(-0.5437869653200877,-0.4784950490527082,-22.00505884594108 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark05(-0.5439038351987384,-66.26762587878025,81.97872913691523 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark05(-0.5440294368327683,-167.9346748851661,55.28113957044588 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark05(-0.5440749211330065,-129.8518742705857,-129.52599113285424 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark05(-0.5444749489331109,-130.318083715868,-40.81668275122297 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark05(-0.5446054447326576,-73.42253492000192,-135.18037244851936 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark05(-0.5450564813091662,-1.1733671827223964,70.67395049123415 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark05(-0.5458994200948375,-0.4179498174275925,-0.1339496132044141 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark05(-0.5461797107595827,-28.567624671133114,-16.030637605591572 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark05(-0.5462684352280284,-3.1415926553671554,1.5707963267948966 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark05(-0.5464891261150814,-41.525976178925085,-18.06183622212683 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark05(-0.5465996584319979,2.710505431213761E-20,57.74468217189593 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark05(-0.5467199304277244,-254.6997174796719,53.77962940914955 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark05(-0.5472206000964219,-1.350397097392827,-1.1563176087069091 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark05(-0.5474887132386295,-0.7703757035948822,3.1415944364038264 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark05(-0.5476238887812099,-0.6916295900215221,4.141592744692748 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark05(-0.5483416708634966,-1.5707963267948966,-45.483843494854796 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark05(-0.5489526827984772,-0.027313467656520984,-51.294260397283495 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark05(-0.5490274591994764,-0.2205423698343727,-1.5707963267948966 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark05(-0.5492845636796194,-9.518681303385552,-708.2092598315342 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark05(-0.549372445378195,-1.5707963267948983,78.08192881141255 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark05(-0.5497896269160079,-1.4567721642408142,6.5331853083325715 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark05(0.550664818186012,-110.63194099617203,-113.52213311918088 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark05(-0.5521283247741073,-92.32081761403653,-46.976900037990795 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark05(-0.5529069049564965,-98.15111514712919,-42.536500936595424 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark05(-0.5542347457467287,-34.557519189487735,-76.66661140427185 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark05(-0.5543340855015311,-66.77247777379027,-3.1416002829854337 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark05(-0.554372726969616,-48.51229437378298,6.9438695902670675 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark05(-0.5552492161057255,-0.574357477077233,0.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark05(-0.5553250788034609,-1.5430816483181837,-22.112547327052052 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark05(-0.5553297490127148,-0.5382355978603641,-91.66286900254529 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark05(-0.5554512285319811,-1.5707963267948966,-75.80341689364028 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark05(-0.5566170540372225,-0.5872101361948381,-36.175610633781176 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark05(-0.5577410081496905,-29.27533694447511,1.5707963267948966 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark05(-0.5585037527167757,4.141592653589811,0.0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark05(-0.5593716440259767,-35.137116328349315,1.5707963267948966 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark05(-0.5594895442932081,-1.5707963267948966,1.4694323648479262 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark05(-0.5598308088591236,-4.1433661987438155,-54.51027271988956 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark05(-0.5602335063924248,-85.48788762504131,-100.0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark05(-0.5605761978286532,-3.1822543893243638,-12.955205733616424 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark05(-0.560732735075963,-91.91063248994635,-3.1415926540597794 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark05(-0.5608335226157886,-1.5707963267948966,92.46601489429361 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark05(-0.5615537981122516,-36.06525453311019,-188.80926663241934 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark05(-0.5615786683411625,-72.39692303981529,55.445532060616976 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark05(-0.5618263221154276,-103.88559886202619,-45.208938669879714 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark05(-0.5621591535709008,-3.1416654525818966,-55.131051757111074 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark05(-0.5628354357680241,-73.31767127140769,-90.98970159199109 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark05(-0.5629634288257469,-60.56836160049268,-2384.7435752751826 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark05(-0.5630395625657931,-1.0201705677192647,0.0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark05(-0.5633127456637966,-79.19361851721753,31.447177156966667 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark05(-0.5635287559011536,-47.706366240795006,1.5707963267948983 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark05(-0.5636922686007572,-1.5707963267948966,0.052542137402309654 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark05(-0.563899402254834,-91.8005408136345,-12.741055422212352 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark05(-0.5648252780413384,-1.5707963267948966,-43.71565590850023 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark05(-0.5654719316772486,-1.3236879098683196,56.42905892385848 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark05(-0.5655520127677669,-3.1421239583512275,-63.26553278769229 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark05(-0.5655559889006145,-35.9401446893373,-73.83362914950303 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark05(-0.5659223562444693,-846.4890584295111,87.81884492077029 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark05(-0.5664691784416049,-3.8940668190918615,100.0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark05(-0.5664786055548084,-0.3666864789433282,-16.149844761980408 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark05(-0.5666236441613749,-85.53844978165498,-55.52801551543305 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark05(-0.5666677402624068,-1.5707963267948966,20.714555087294976 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark05(-0.5667025108650124,-2.465190328815662E-32,-44.58760382190174 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark05(-0.5669031702227955,-66.8049286639685,-84.57696082727605 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark05(-0.5675200696139263,1.5032034697702572,1.5604814424463491 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark05(-0.5679885345469984,-0.903009489108346,35.265004829172256 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark05(-0.5699026640944225,-1.5707963267939888,-50.630382317579745 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark05(-0.570597905728158,-22.241537273217233,111.90986998289759 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark05(-0.5706719609440677,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark05(-0.5708040404945791,-10.360984852100003,-10.300001375894016 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark05(-0.5741691221302414,-66.25624754653288,22.629169954015758 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark05(-0.574473406971773,-204.54507178433352,-30.243660501511833 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark05(-0.5747849196865288,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark05(-0.574863370786743,-66.00315313595463,-15.72389791536895 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark05(-0.5749133297503807,-9.953049082195347,-25.24423708753749 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark05(-0.5750228863056899,-0.13609977173805987,-1.5707963267948966 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark05(-0.5751311901942978,-0.48440285845702974,100.0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark05(-0.5754567323978488,-29.364657490623657,-95.80193187744972 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark05(-0.5755404732944089,-44.09126522662644,1.5707963267948948 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark05(-0.5761074905453302,-1.5707963267948966,1.570796326794894 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark05(-0.5764067937192566,-0.3969121487815803,11.980292315145064 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark05(-0.5774809165764588,-28.560820950054236,0.0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark05(-0.577901728971558,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark05(-0.5781324008282231,-3.1494051578721702,-1.5707963267948983 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark05(-0.578857968371624,-0.04583055857000348,4.141592888594002 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark05(-0.5795357057520362,3.3881317890172014E-21,-35.403211564868656 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark05(-0.5796995192995738,-60.949350728795864,-237.53288279916063 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark05(-0.5798079586567972,-29.106001673705915,-64.03087342342725 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark05(0.5798425068477815,-0.7945611402360707,72.88450538192781 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark05(-0.580470818716979,-53.42417684207683,0.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark05(-0.5816745231918272,-0.5425238905670202,-72.72067152554351 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark05(-0.5828114671460285,-1.5707963267948966,-9.48089405274331 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark05(-0.5834378397727308,-10.456804004128536,-3.149414054826426 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark05(-0.5834927555211926,-0.15341304610117795,4.141592658918908 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark05(-0.5841661268466275,-35.73885660969604,-65.46267949246547 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark05(-0.5842290639190866,-78.93883613229963,-59.295820700253344 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark05(-0.5844436301638556,-29.169108318073622,-71.96778325094142 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark05(-0.5852887465923757,-135.87453433295042,107.83835961485632 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark05(-0.5853041915568238,-1.0937611730281702,-22.55508484928083 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark05(-0.5864398189927655,-1.5707963267948912,-76.63885236929983 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark05(-0.5877279635522683,-54.02477572697888,-20.790868821109655 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark05(-0.5879882318456282,-1.5707963267948966,-30.04080072570333 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark05(-0.589417024050552,-41.18345426237986,-0.8139754343952514 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark05(-0.5895066635844302,-130.03019356316827,1.5707966728135583 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark05(-0.5899412167863431,-0.02553031963074856,25.728498155113627 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark05(-0.5900560774527406,-0.09050931908577448,-4.689653719755011 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark05(-0.5901694649808655,-1.570796326794896,-20.650859957904476 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark05(-0.590231192280124,-0.4616177842586697,-0.5174682043607949 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark05(-0.5903617866481454,-72.3859704666863,95.24899909282927 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark05(-0.5910469433795719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark05(-0.5914848748015699,-1.5707963267948966,1.106523307442206 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark05(-0.5916065803695624,-0.9719085682286703,-42.95908388732109 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark05(-0.5917757245128215,-35.74444605125521,38.18903379521031 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark05(-0.5929944251200814,-16.733457759639634,-70.92299090418497 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark05(-0.5933793809073186,-0.018171782778140688,3.1517288263998466 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark05(-0.5934587201966208,-22.45578605677929,-32.22906572153105 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark05(-0.5939975211076529,-172.87569108221453,-132.7996491726533 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark05(-0.5941155454571919,-0.3905672810056743,15.994269410433802 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark05(-0.5944151830758515,-66.40014650407794,42.53650126805955 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark05(-0.5945555726361202,0.8689855452830402,-50.78644758862607 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark05(-0.5947592738241541,-85.27317039392975,0.0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark05(-0.594800568937863,-47.757761913219184,-78.58277537621352 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark05(-0.5951715338973466,-91.42524541039909,6.283185789686045 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark05(-0.5957573259599711,-16.88575488267083,-1.5707963267948966 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark05(-0.5957904110071215,-1.5707963267047649,45.87796684834954 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark05(-0.5966202454975253,-1.5707963267948966,82.11714237216435 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark05(-0.5976014574946871,-85.0533114943081,7.861794777781211 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark05(-0.5976222917690364,-0.038829806474348416,-21.8657270447806 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark05(-0.5994312658528862,-97.65569329393622,-72.33938359838807 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark05(-0.5995810569433374,-1.223342249868285,-1.5707963267948966 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark05(-0.6000269655173202,-1.5707963267948957,18.78539517388782 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark05(-0.6003579539613111,-10.26623856538312,100.0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark05(-0.6006476373286433,-1.5707963251539148,-1.5707963267948966 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark05(-0.6007015937141622,-160.83817691148673,-45.3478709474589 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark05(-0.6011294729514016,-0.26427199668366985,-100.0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark05(-0.6014049347856313,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark05(-0.6017526760285158,-3.143545778589914,-1.5707963267948966 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark05(-0.6017745913496135,-3.547288578761112,-0.7887339213856105 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark05(-0.6020895290093287,-3.141609236019713,-100.0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark05(-0.6024261714717479,-41.20470398993179,-84.36193001763317 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark05(-0.603540106658109,-47.66793722283519,-714.5916775500084 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark05(-0.603687085423644,0.34377260983709046,-75.87029366271682 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark05(-0.6049221040729116,-86.03467722733838,0.5707939777039882 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark05(-0.6052672885644645,-1.5707963267948966,84.98572664758595 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark05(-0.6052818893594998,-92.39161938866877,-122.97616283006285 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark05(-0.6069239224318203,-122.93154434564211,8.103998523869917 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark05(-0.6072280536957102,-122.79259368893932,77.36485484097497 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark05(-0.6073772053489299,-66.24146847134531,1.5707963267948966 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark05(-0.6087362197296343,-1.5707963267948983,76.96902001294994 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark05(-0.6096526391573036,-1.5707963267948948,-72.60621767139631 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark05(-0.6108314824818593,-1.5707963265506022,42.148801410386895 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark05(-0.6109526605660249,-230.8997924685659,0.0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark05(-0.6110058773402248,-3.469446951953614E-18,20.336335360504137 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark05(-0.6110235476403147,-9.64506021695141,-68.9932252634048 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark05(-0.6111945921262674,-98.92361589312489,0.0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark05(-0.6112648658053829,-1.5337450671893764,26.271629241636496 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark05(-0.6115995341282978,-1.5707963267948966,31.416023393424403 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark05(-0.6119258964919634,-66.38876085894226,273.1594541611984 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark05(-0.6123381309148244,-60.509530550914526,-64.95802588334811 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark05(-0.6125203267568963,-1.5707963267948966,-59.75375176435636 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark05(-0.6141471562058537,-41.43276028721692,-8.103985976586559 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark05(-0.614395113216002,-1.1207010395285821,-24.641740514220118 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark05(-0.6146620999866688,-1.5707963267948966,13.28930649594362 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark05(-0.6156030762750176,-3.141654968225541,-79.20694531264294 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark05(-0.6156796852835229,-66.25735475778328,3.1415926537504686 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark05(-0.6157734792475489,-3.723590216048473,68.72743990174658 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark05(-0.6171894881887534,-1.5707963267948966,25.856337354949567 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark05(-0.6187855799470618,-66.2259664943487,32.209581363797255 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark05(-0.6188212632490726,-86.37875580054565,-92.59395932269183 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark05(-0.6190731975571211,-48.543650232091906,-85.10494251217999 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark05(-0.6202940329248655,-0.01644688657388907,-1.5707963267948963 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark05(-0.6210340468659034,-0.048300367579937505,35.40646921863136 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark05(-0.6219658137674884,-23.06016953057855,2448.173940995183 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark05(-0.6225411809885049,-1.5707963267948966,-26.363765520394338 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark05(-0.6228149864521413,-0.5503361856599405,20.960471776485186 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark05(-0.6230570623467571,-73.53787823262319,1.5707963267948912 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark05(-0.6248589951083448,-4.543690800324697,-50.58279897622333 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark05(-0.625047903883197,-1.5707963267948966,72.58360636385586 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark05(-0.6262740813124953,-22.586709792282804,-254.78641462446222 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark05(-0.6263207114116107,-4.376230478623425,-1.5707963267948966 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark05(-0.6264224453236032,-1.5707963267948912,120.10051965013955 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark05(-0.6267222194282832,-92.50946759768432,-92.72446383499697 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark05(-0.627073586358264,-41.018609728720726,-27.81465427664911 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark05(0.6273663425292284,-20.76680780617366,-8.234741798732756 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark05(-0.6278943085316007,-122.6088802693256,-113.9119022285976 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark05(-0.6278977643962635,-1.5707963267948963,30.732445430444418 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark05(-0.6283642991699984,-4.866794409715609E-209,-3.955806195098637E-276 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark05(-0.6288807748799969,-1.5707963267948966,-32.82455739911819 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark05(-0.6290833009717587,-0.9035494614858832,0.0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark05(-0.629474732598311,-1.2443413078317276,100.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark05(-0.6300692029063553,-135.63372140829352,89.53671543582887 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark05(-0.6311385749889684,-1.1769765499162879,1.5707963267948966 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark05(-0.6311693673138841,-48.51992665532133,-75.11081962381587 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark05(-0.6321043194844994,-16.15614209910312,-90.71367515269574 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark05(-0.6327172987450973,-34.59595369762066,94.39673605830487 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark05(-0.6332032680806241,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark05(-0.634196526872955,-28.311473527307342,1.5707963267948966 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark05(-0.6360169417586856,1.0127901940508603,-8.073789181628433 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark05(-0.6369302914772738,-117.6162408124431,-72.92859320883736 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark05(-0.6373624767517477,-1.3788435902565275,-26.10409176546699 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark05(-0.6374050497040097,-1.5707963267948966,-6.4301920990547785 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark05(-0.6381942670877727,73.75795494706449,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark05(-0.6387187903986979,-136.6031584182198,-4.712690710357493 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark05(-0.6390165488962918,-98.24658863642216,-43.628322714481435 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark05(-0.6393816369652465,-280.44577551857947,-92.29891523937432 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark05(-0.6395239728622935,-15.974137589841014,-14.71704532891267 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark05(-0.6400810202552766,-122.68071607129743,-22.15403920708752 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark05(-0.6402974045530089,-48.17925249952351,73.24986525345676 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark05(-0.640618111525745,-54.82370954617698,60.414911454707244 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark05(-0.6408583093751883,-556.4264767761582,1.5707963267948966 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark05(-0.6410627541952327,-48.5234714218003,-24.12709589368246 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark05(0.6414063252780806,-236.6075287217931,-81.75684839529931 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark05(-0.6415121867467447,-4.012777975190727,85.54710580373131 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark05(-0.6418102886200678,-191.78873128382676,12.568330603822668 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark05(-0.643233418966151,-1.042466924904482,-21.628248115836683 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark05(-0.6433934154846733,-1.5707963267948966,4.309977979302971 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark05(-0.6440479571290307,-0.6314779568509278,-69.78784047804383 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark05(0.6457441965878334,7.558550693621337E-7,26.79434435438754 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark05(-0.6465113278326102,-1.4745757765559309,-55.955228083997774 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark05(-0.6470598618115706,-1.7763568394002505E-15,32.8615473194657 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark05(-0.6483241611853963,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark05(-0.648786531709824,-60.76621332160719,91.71620649825792 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark05(-0.6493385585239588,-35.875151207001075,227.38646622109593 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark05(-0.6497042806807904,-1.5707963267948948,-82.41079228417954 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark05(-0.6512462266989335,-0.07551481237746907,-1.5793650827938261E-176 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark05(-0.651528938160169,-0.2753861056289999,-7.855017378793747 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark05(-0.6516769263300776,-1.5707963267948966,91.0369631130916 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark05(-0.6518507904947255,-66.45428776174637,-84.91124224152914 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark05(-0.652144011946644,-952.8332587572896,20.235735326971497 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark05(-0.6538096651483869,-1.5707963267948966,1.5707963267948957 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark05(-0.656419903482354,-47.42696327214209,-0.31397636963346637 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark05(-0.6569904862577324,-91.53915704047901,0.0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark05(-0.6572657436138007,-78.93924606505288,-4.712388981496427 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark05(-0.6577561230784214,-1.5707963267948963,463.31028173233756 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark05(-0.6579847948188955,-0.7232314197532876,0.7547845012490342 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark05(-0.6582271712299435,-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark05(-0.65865987219091,-1.5707963267948966,-5.377394324070153 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark05(-0.6590734324355457,-0.5769650843522527,0.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark05(-0.6611196150969487,-0.7702762516293539,-44.030642611189144 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark05(-0.6611279660004595,-5.556896873712694E-163,14.754138592029008 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark05(-0.6613568610194953,-22.05040402454948,-67.0373755255311 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark05(-0.6615812408955881,-53.679604305030935,32.1527773917488 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark05(-0.6625054417675517,-0.452470248525175,-1.450874053217986 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark05(-0.6631401774128325,-66.28003782534081,-35.12732783863551 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark05(-0.6640376490316768,-3.7652695429088396,6.284161878013493 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark05(-0.6658945831518364,-23.305959485633586,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark05(-0.6660025376373206,-0.6514984122552674,39.65312858800411 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark05(-0.6667173422403625,-29.780175962847764,-71.39306762033485 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark05(-0.6670316801133036,-61.173789152449395,-21.13524195624862 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark05(-0.6675946333553225,-66.28737546051909,-7.853981633974487 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark05(-0.6679385822597651,-35.902356569630754,4.712445967471092 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark05(-0.668267818875156,4.1415926535898056,1.5707963267948966 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark05(-0.6683449929375936,-1.5707963267948966,-12.697671894501903 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark05(-0.6689761492081517,-1.5707963267948966,6.283201441708332 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark05(-0.6689888076560062,-4.584061756816382,1.5707963267948948 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark05(-0.6693104591181394,-48.13908632072359,0.49346438817968236 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark05(-0.6694284722232169,-53.92788314622784,-35.643344639474606 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark05(-0.6697321203864135,-689.5790460530995,-50.48499142549326 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark05(-0.6700902314311608,-10.820155654522452,-23.56194490192345 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark05(-0.6707039961326757,-10.22911297261789,-12.566493311147298 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark05(-0.6707952323943976,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark05(-0.6714695115176563,-91.44660578412918,-32.080178679993594 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark05(-0.6716082676163055,-4.281577825846245,-176.96199688383487 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark05(-0.6746488374115944,-180.46478025664217,-16.928650009595653 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark05(-0.674767256404296,-41.59275176753707,1.5707963267948966 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark05(-0.6755714584425466,-34.6383821293158,4.712388983615615 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark05(-0.6759174916971337,-53.751294561446784,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark05(-0.6763403744997445,-72.82698102357317,-38.71032301517071 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark05(-0.6766500555754542,-5.421010862427522E-20,55.44425736293269 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark05(-0.6771054115092286,4.158388433273546,-0.7559986554794145 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark05(-0.6778338192954223,-28.671210561170387,1.5707963267948966 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark05(-0.6781484431388178,-73.78876311063752,-1.570796460270327 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark05(-0.6783399593163917,-66.97734561770667,-65.72896133910508 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark05(-0.6786161509497923,-84.85425164696895,-19.62254379305701 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark05(-0.6792789566162577,-54.18001728229536,1.5707963267948966 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark05(-0.6792932441285182,-10.26024784796612,-42.663690821867526 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark05(-0.6810662464115924,-128.92027647134637,-2.1138170549305073 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark05(-0.6812171756661178,-1.5707963267948966,17.504134100822093 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark05(-0.6813901994930021,-1.5121841913101244,-57.62530400683521 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark05(-0.6818436334633571,-9.628641964344794,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark05(-0.6822511684126705,-1.5707963267948966,-15.931768476043116 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark05(-0.6832346173322605,-1.5707963267948966,-52.83158724496857 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark05(-0.6840691833668205,-47.47644703980871,4.712443353271421 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark05(-0.684439150936973,-9.917785783375074,6.28709160337334 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark05(-0.6853176641446669,-1.173814495817938,69.71533336095933 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark05(-0.6858481353460925,-78.88687683859567,12.551612091055823 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark05(-0.6864591387225939,-53.868148594642584,0.746904233556485 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark05(-0.6872008402078689,-161.60714424716016,-72.46560725743166 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark05(-0.68746912157321,-54.642320692837785,69.65926989164453 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark05(-0.687770393652004,-72.48040104355731,-26.704818473123186 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark05(-0.6882560595121044,3.141623171167919,11.0156072760174 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark05(-0.6883055147731745,-34.645968162266534,-1.5707963272454748 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark05(-0.6886966494782317,-47.67275126414703,-1.5707963267948966 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark05(-0.6899066902406616,-47.93877386314424,70.46279078595731 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark05(-0.6907746340630194,-1.5707963267948966,13.071377707130193 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark05(-0.6920996669846327,-28.311680286421492,12.65487690784667 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark05(-0.6925411868618307,-66.34829774855142,-4.712389301453145 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark05(-0.6932100542298654,-92.01961014846223,133.34868563505032 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark05(-0.6933617233793068,-1.5707963267948966,-1.4756553303114495 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark05(-0.693966476991643,-0.8818520534238229,-3.7433730188930863 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark05(-0.6939761423465725,-92.06207405014881,-147.65464599894523 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark05(-0.6942661447034304,-0.5104944559682013,-21.658165456687403 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark05(-0.6943227023196229,-53.735787015031875,-77.39449842182543 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark05(-0.6945039169791336,-1.5707963267948966,1067.9087701281128 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark05(-0.6946316654883631,-79.2251040148475,-10.275788282359937 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark05(-0.6948376888765206,-1.5707963267948966,49.66809441326444 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark05(-0.6948706846495618,-54.032657203194915,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark05(-0.6955029768066558,-1.5707963267948966,21.504449905489615 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark05(-0.6964945361137822,-16.47530465876168,-1.5707963267948912 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark05(-0.6967771936385745,-98.59220813375423,-82.98135604318526 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark05(-0.6968767119193706,-41.484454283199334,1.5707963267948966 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark05(-0.6969559900589501,-104.82032212674265,-88.28986207922459 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark05(-0.6975864134947907,-40.92378030579072,-27.83114243346848 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark05(-0.6979417771939467,-28.469600939486423,0.0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark05(-0.6981837200325769,-2.959633482471693E-4,-57.75574771862707 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark05(-0.6985918244923499,-66.80939873863133,77.52322967954038 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark05(-0.6990662850903817,-0.5682496200282233,28.148267763571027 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark05(-0.6991165936825532,-1.570796326794848,12.424498255925574 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark05(-0.6992426778628982,-4.451860558617927,-17.117368129335578 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark05(-0.6993947707330215,-60.30828068262939,100.0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark05(-0.6999414186064503,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark05(-0.7007417964462415,-28.95185198469358,-91.94452959035024 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark05(-0.7012284973267242,-47.265111300051146,8.234742617932184 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark05(-0.7034167079684126,-22.18588552728734,-1.5707963267948983 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark05(-0.703678533359736,-0.030720857317588675,26.695960113485228 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark05(-0.7037483088214986,-0.6604404736329756,-9.987954462851548 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark05(-0.7040642716831617,-91.93276436400818,76.75981237354854 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark05(-0.7041806867990026,-47.37497314868546,-32.90101753814342 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark05(-0.7043313300500085,-22.345645231046422,-28.07121576095095 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark05(-0.7043448331273101,-53.62139814900298,0.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark05(-0.7044846298530568,-1.5707963267948966,-12.570995548495508 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark05(-0.7045242808777252,-1.0716841680992826,1.5707963267948966 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark05(-0.7050154311743134,-9.9646906165231,1.5707963267948983 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark05(-0.7051853930995178,-0.9793673532718757,1.6242827758820155E-114 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark05(-0.7056614046041066,-1.5707963267948983,4.581980214452813 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark05(-0.7064220762820171,-47.42612179155222,-80.81740182540678 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark05(-0.7065948348705433,-28.81052604298788,-1086.2987902791963 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark05(-0.7069395467620474,-0.5498269076848944,95.58148756984504 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark05(-0.7074796324962893,-1.5707963267948966,61.924826443861335 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark05(-0.708106450747489,-3.1416012839615344,-157.39280983973768 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark05(-0.708307924234588,-42.01738518515071,-31.081132733658325 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark05(-0.7091292140388438,-0.02801594311497364,-3.142094797219837 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark05(-0.7097352088934201,43.59829797125957,21.090159691559805 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark05(-0.7108957869565309,-0.47302313656796424,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark05(-0.7113970228408305,-0.1394767490703313,53.31768953586459 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark05(-0.7118483371969807,-1.570796329847015,-41.49746171077867 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark05(-0.7125832209180203,-85.06944439252716,0.0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark05(0.712742626015264,-3.159267352646704,100.0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark05(-0.7129609436591129,-16.636231475357818,-99.50166259050029 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark05(-0.7129731796423096,-0.46174084199460924,-78.4114196201221 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark05(-0.7139853197414844,-79.02079440597636,48.71644624525947 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark05(-0.7141289894611811,-1.5707963267948966,-12.82827145695094 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark05(-0.715471384143604,-7.105427357601002E-15,100.0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark05(-0.7156129681339138,-1.5707963267948841,49.753519107821134 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark05(-0.7161849071702507,-0.034885822990033566,0.8091334523645678 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark05(-0.7161851505263661,-23.550933312805576,-71.93947723488029 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark05(-0.716537343470385,3.149405316710286,-39.419904876656275 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark05(-0.717223460137306,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark05(-0.7175393173068431,-86.37346524432736,6.283321123292608 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark05(-0.7177066653921729,-47.66677335022233,-57.34818903776482 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark05(0.7183934694277195,-8.46751692591164E-16,44.66009763642532 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark05(-0.7187039009396121,-4.3368086899420177E-19,-0.03724061984728967 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark05(-0.7190426510541155,-0.005256279750041163,503.0335331846926 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark05(-0.7191459406347036,-123.19822793853443,-133.01972618711437 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark05(-0.7192233030159046,-1.7763568394002505E-15,-4.81463794609715 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark05(-0.7192793594670186,-66.43702231879217,-100.0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark05(-0.7200266908241446,-3.1435459389861444,177.07712132970653 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark05(-0.7214194561211936,-1.5707963267948966,-0.18263187681263304 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark05(-0.7217972001523874,-142.198207894811,95.21810217420226 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark05(-0.7218098347252372,-1.5707963267948966,6.283185307179593 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark05(-0.7219594074212491,-0.02743844047644646,-7.6096037327788535 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark05(-0.7221810565725671,-443.2542691136551,-1.5707963267948963 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark05(-0.7225939858842025,-10.986922936361168,-164.76254619806514 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark05(-0.7227645795040866,-0.396859773805066,-42.06028818178681 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark05(-0.7228017525816981,-1.0536361963612313,-49.893953056769575 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark05(-0.7232482209165658,-85.61345789662059,1.5707963267948966 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark05(-0.7234662506678724,-53.66594339038062,-1.5707963267948968 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark05(-0.7237856787232427,-3.11474842221799E-207,-1.5707963267948966 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark05(-0.7247965722516989,-80.0990247276354,1.5707963267948966 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark05(-0.7252536008292945,-1.5707963267948966,290.5121848387226 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark05(-0.7257753678731795,-10.648825251404205,-53.614381717494624 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark05(-0.7259917605466734,-60.13116244787286,19.052969455372263 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark05(-0.7260840280860832,-1.5707963267948966,-58.09912430210511 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark05(-0.7275497120212445,-1.5707963267948983,84.5613383513003 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark05(-0.7285662191397138,-66.6669701678009,-1.5707963267948966 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark05(-0.7291814620092474,-42.36065699549693,-0.9141484813048948 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark05(-0.7292219961597133,-28.351291314515123,28.064488216865726 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark05(-0.7292239544791954,-1.5707963267948966,98.38226082366747 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark05(-0.729322446261656,-15.950007827616956,-38.54138941679808 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark05(-0.730274704717587,-48.682850816509664,16.244074059868097 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark05(-0.730278841674507,-1.5707963267948974,-912.9118125202087 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark05(-0.7308766750940321,-9.649642733613945,-56.75312595404585 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark05(-0.7340058267321123,-260.7647289868835,1.5707963267948966 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark05(-0.734953550805451,-23.196877875169918,-1.5707963267948912 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark05(-0.7360090493656546,-0.18500524649817573,78.03796583925016 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark05(-0.7364302119692526,-47.20857863372168,-100.0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark05(-0.7364384215079521,-1.5707963267948966,-10.389641443685306 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark05(-0.7374763100093635,-66.77962284345524,88.07763611304188 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark05(-0.7376926680668249,-1.5707963267948948,-99.1430038082692 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark05(-0.7386011970795113,-23.270787439288654,-10.003993883318934 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark05(-0.7401804956241498,-54.79685944895505,-42.536738260376715 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark05(0.7403573725780888,83.37130202626457,-37.70349959245891 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark05(-0.7406489582793967,-60.13917077940232,88.18077148813768 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark05(-0.7412897124560791,-0.3924996082270705,-71.5981296015749 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark05(-0.7423040298510555,-1.5707963267948943,-88.6421598751955 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark05(-0.7436043681527068,-66.57383181605414,-55.474303720318765 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark05(-0.7444979423211516,-73.49625752833799,-12.489984258037197 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark05(-0.7448001360167358,-10.863243036041311,-1.5707963267948966 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark05(-0.7461199300133223,-85.44293401181332,-3.1852854268819115 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark05(-0.7464979409105377,-1.5707963267948966,42.48755297929433 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark05(-0.746629869279205,-73.48316830189464,1.5707963267948966 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark05(-0.746729374738607,-73.57127313477503,-111.08907216141958 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark05(-0.7489981884941006,-0.26231188027554353,-21.56436350075205 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark05(-0.7500250123562466,-85.3776512199959,14.438906498314005 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark05(-0.7506750304942464,-1.5707963267948966,-97.85414359952145 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark05(-0.7507961717740557,-1.5707963267948966,80.9187091888827 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark05(-0.7523957868334754,-1.570796177197566,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark05(-0.7526627571641553,-35.660156215698024,-71.79055467166967 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark05(-0.752961562223402,-1.57079632679487,-8.440463603447292 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark05(-0.7530766455307,-10.051602348471976,-1.5707963267948983 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark05(-0.7535682234655542,-1.5707963267948966,-69.7797250147467 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark05(-0.7535977832744954,-1.5707963267948912,-26.655301233041186 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark05(-0.753980523097012,-9.559517099260376,67.0709625366836 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark05(-0.7551777148836161,-54.84604204144338,42.01027582463014 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark05(-0.7551940354935878,3.141600282993384,-61.48203018287228 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark05(-0.7553903527554301,-35.40656727597748,-59.6235628095465 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark05(-0.7570388465362962,-1.5707963267948966,-2412.9364350512324 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark05(-0.7571848623110373,-1.5707963267948966,808.2241956903603 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark05(-0.7577646134226073,-1.5707963266466254,76.66821391025807 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark05(-0.7577753913251292,-1.5707963267948966,25.799315285341184 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark05(-0.7578282074530125,-73.41337655526905,-23.24133458083737 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark05(-0.7582381874207265,-1.5707963267948983,-43.476515786275556 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark05(-0.7586518836136836,-3.4946319927314575,-51.074462470470614 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark05(-0.7586618640201043,-1.5707963267949054,-541.1281644184223 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark05(-0.7595646475051334,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark05(-0.759716982356613,-42.26879348383235,-111.35870089204431 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark05(-0.759850526633562,-4.40808200948436,-11.804627148866189 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark05(-0.7607178617197843,-1.5707963267948966,-35.433212758175785 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark05(-0.7609897447558852,-35.84819579681176,-24.857165449607287 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark05(-0.7610248533386235,-66.3966201329778,64.49386534384072 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark05(-0.761175717926207,4.595419426122206,-3.149412502710754 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark05(-0.7615423002704964,14.447984147180762,27.977299644236226 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark05(-0.7619446314736579,-1.5707963267948966,1.5271894638639105 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark05(-0.7630997666551778,-9.506841562048912,147.3807501391962 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark05(-0.7642970671376949,-1.5329232286960621,-1.5707963267948966 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark05(-0.7653042507810879,-54.97489692056533,-1.5707963267948912 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark05(-0.7655649180344346,-242.78593759835812,-16.529510399850025 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark05(-0.7657471008269287,-47.69385797459742,0.013226820558499996 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark05(-0.7663232615289677,-1.2364715164208258,-16.79960918941235 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark05(-0.7676314651604426,-66.27929667243716,-17.781403075077677 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark05(-0.7690152213933242,-98.1586588308298,-55.456126549007315 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark05(-0.7691975699223574,-1.3670021868469318,44.18484145111336 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark05(-0.7697503192931642,-1.5707963267948948,28.1295165319934 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark05(-0.7702676777965672,-35.67973567991217,1.5707963267948963 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark05(-0.7702957960208097,-3.1420819869472543,1.5707963267948966 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark05(-0.7716698839667304,-1.5707963267948966,50.29905939217713 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark05(-0.7716736921801184,-16.25719118227805,-12.337650733238569 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark05(-0.771865790682952,-0.08026437324741437,-4.8300621803635675 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark05(-0.773691033987838,-10.806167813852369,1.5707963267948963 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark05(-0.7744971651764887,-1.5707963267948948,-3.733591563900113 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark05(-0.7755866377955627,-36.71610832314599,-0.7195708818478628 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark05(-0.7769161153641857,-1.5707963267948966,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark05(-0.777351273094971,-10.709936993341723,-44.01525591711555 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark05(-0.7776270261556454,-1.5707963267948966,-12.184636600078422 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark05(-0.7776676666541421,-3.234462675885638,-8.163864120948872 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark05(-0.7781221637768891,-3.14208093486472,-100.0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark05(-0.7783487813472462,4.14159285323734,46.69478483177903 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark05(-0.7784193174223751,-1.5707963267948966,-11.93500161578176 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark05(-0.7788553161302437,-1.4131474083552424,-1.5707963267948983 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark05(-0.7791304444936727,-73.34883971128824,-6.283799228668476 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark05(-0.7792282721015225,-29.391078238776835,44.50601063124168 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark05(-0.7794440319683886,-0.8025102201051824,-12.947802462248358 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark05(-0.779458131651035,-530.9607628036451,-42.76813748325439 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark05(-0.7815232428193823,-111.17278762687636,90.47372093158603 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark05(-0.782762531115919,-0.07072671367780288,-8.5692782435584 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark05(-0.7829587476692002,-1.2324636591610276,-0.25474969746675147 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark05(-0.7832595521780892,-1.5707963267948966,12.59762079789411 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark05(-0.7840992416164969,-3.1711679183094366,-133.20696539323689 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark05(-0.7847280379457544,-3.8149688182494117,62.04147266563227 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark05(-0.7848612196419724,-1.5707963267948963,-74.60468934989669 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark05(-0.7853778975734684,-1.0927043848838227,77.86584561040496 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark05(-0.785999871708003,-1.375325998900056,-66.17578607074401 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark05(-0.7869044165817627,-41.89357725669822,70.47310320001 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark05(-0.787873549046214,-3.1440776079433457,-47.78815816975292 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark05(-0.7883100945296525,-0.18593597231106698,6.28339647245325 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark05(-0.7884460903580899,-4.699642963435235,-34.424097012430394 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark05(-0.7901950581501332,-22.589294103568562,1.5707963267948966 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark05(-0.7906259856411014,-0.37658847490725933,1.5707964843510807 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark05(-0.7907041221890538,-73.29317860977805,8.104015893899863 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark05(-0.7913399650690457,-1.5707963267948966,-0.12157392334519668 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark05(-0.7919245855889141,-35.52355615535936,-91.0606812164431 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark05(-0.7930246004045867,-0.778611392610356,31.895697624935227 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark05(-0.7930395692192579,-3.14947516683596,-27.017129244032716 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark05(-0.7936659028035106,-35.79872592170216,5.0052077379577523E-147 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark05(-0.7943505303784878,-10.153527782694937,21.676552899517763 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark05(-0.7952708697636228,-0.5184955580859276,-1193.3691109602814 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark05(-0.7962436223799538,-1.5707963267948957,0.014592255966784415 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark05(-0.7967712908421873,-122.77307390118042,-67.14184624571857 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark05(-0.7972468644011629,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark05(-0.7977710525543134,-79.64561512944158,-1.5707963267948912 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark05(-0.7979294663762284,-42.133826566552415,-6.3946092748984995 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark05(-0.7982190696538007,4.354373513949299,41.532984115366204 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark05(-0.7982498456871957,-1.5707963267942262,-76.77661223552961 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark05(-0.7993181656715493,-0.7582840855926601,9.71380892425562 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark05(-0.7995543241790607,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark05(-0.7999375265856694,-135.30871378947987,1.5707963267948966 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark05(-0.8009042034125591,-0.004511550822652727,-63.99868264963413 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark05(-0.8011087644449356,-1.5707963267948966,-28.05198065990369 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark05(-0.802093259934118,-1.5321004202079536,-49.80367358828881 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark05(-0.8023937169250475,-1.5707963267948966,-63.29654948707572 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark05(-0.8024058740572025,-79.74426832194527,-20.42226571989513 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark05(-0.8032619721260007,-16.16628067015346,-26.21830468372076 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark05(-0.8034649749889935,-66.44584309453558,1.5707963670619285 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark05(0.8037471280132448,-6.776263578034403E-21,94.26533426936376 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark05(-0.8042953341056904,-73.20984921800638,-92.41493319065279 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark05(-0.8043539890443898,-1.5707963267948912,0.45019884772746543 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark05(-0.8045761594867422,-1.5707963267948966,10.995574287564278 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark05(-0.8051873890166454,-0.9034134125852153,1.5707963267948966 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark05(-0.8054350488428442,-469.5892868516913,180.68244931220391 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark05(-0.8073335476682175,-4.477729459957224,-100.0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark05(-0.8075276437447028,0.5123517898278924,-39.530048904080076 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark05(-0.8078208851772996,-1.5707963267948966,-11.89787036811743 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark05(-0.807832667287459,-16.669950302226027,0.0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark05(-0.8085271074995068,-330.0302539451743,-89.72933098271909 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark05(-0.8085402595235429,-1.5707963267948966,-0.35943773368154314 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark05(-0.8085950217777671,-4.141592865107523,-78.70181302705265 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark05(-0.8092031884566392,-16.637429945078992,-0.4627383852464229 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark05(-0.8098154636340436,-34.933366470462936,503.74872664180134 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark05(-0.810524072395014,-29.227550306710242,-8.106855361893707 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark05(-0.8113523618067888,-1.5707963267948968,24.19544390440076 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark05(-0.8114769485570296,-0.17263560249309962,43.031747064497836 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark05(-0.8116268407835526,-41.174020235165614,-53.407091974617806 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark05(-0.8121089742595249,-0.22997014431897833,1.5707963269024408 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark05(-0.8128334059816833,-135.3947538105861,-4.712391787514704 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark05(-0.8132733159750645,-0.46019427887639186,-1.5707963267948966 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark05(-0.8136449497639013,-47.17542016915945,1.5707963267948966 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark05(-0.8139959597645685,-1.5707963267948966,24.003894670549528 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark05(-0.8145522750336185,-41.90079233739994,155.51647824040566 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark05(-0.8146365762320441,-10.601939873938106,-5.7600155774794075 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark05(-0.8149983750527462,-98.07530945243028,0.0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark05(-0.8150868593618841,-1.5707963267948966,16.55003470741663 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark05(-0.8153589795435695,-41.881235734369405,-147.63479003457886 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark05(-0.815647174054779,-7.105427357601002E-15,82.03787776233878 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark05(-0.8160193120773584,-22.322964923728705,-273.3109459546337 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark05(-0.8175551784282858,-1.5707963267948961,-100.0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark05(-0.8176720676552236,-28.704697832595684,-75.71925051040489 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark05(-0.818133673645682,-3.1415926684910653,-67.98575282115692 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark05(-0.8182020720176781,-0.5467344438020484,-7.85398242656211 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark05(-0.8187936227596992,-0.6233658175549834,0.02425058842195793 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark05(-0.8202297194935252,-0.7423309548835025,84.2623409288162 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark05(-0.8207444278411956,-1.5707963268009983,1.100048550995766 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark05(-0.820768542630846,-1.570796326794897,35.802588002696424 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark05(-0.8208206499557633,-0.6048972549727427,36.98622731673561 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark05(-0.8215726470896888,-66.38545619367389,-20.420352248333657 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark05(-0.8219769266920709,-1.5707963267948912,-7.911575649545648 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark05(-0.8220265223991605,-1.5707963267948966,3.7752437912599817 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark05(-0.822071137578562,-1.5707963267948966,41.03089109574054 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark05(-0.8228008219678384,-3.266592653607379,100.0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark05(-0.8235667082320219,-67.14577646538908,-1.5707963267946496 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark05(-0.8236055609071746,-3.596276902923549,-1.5352975729250768 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark05(-0.8236604156685724,-28.744533058196595,-130.09194215374453 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark05(-0.8241251497526565,-1.5707963267948966,91.6827001324848 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark05(-0.8250812799326267,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark05(-0.825248160813778,-22.33241089710492,58.96082013204108 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark05(-0.8253637784574811,-92.48616993409536,-87.503882797748 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark05(-0.8256882934643826,-0.2316460208247558,2.926047721682624E-98 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark05(-0.8262668954493779,-72.47014055848817,15.774263414074298 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark05(-0.8267084131853512,-79.94770903453156,-30.935293534139532 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark05(-0.8272501893337446,-0.01693172706387788,-33.82276681830734 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark05(-0.8274279132700855,-1.5707963267948963,78.04539154775048 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark05(-0.8276843348827413,-1.5707963267948966,-1.570796326989467 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark05(-0.82871698468783,-764.8879341059474,-32.507644913401975 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark05(-0.8289316320080964,-61.0155915494649,-7.449596095926477 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark05(-0.8293362584568342,-0.08862746089395193,64.97110707273818 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark05(-0.8300305778613293,-16.426182792852018,-1.5707963267948983 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark05(-0.8301719822692619,-1.5707963267948921,-128.81824771270323 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark05(-0.83048789692914,-85.10243712325979,-94.40448889720491 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark05(-0.8312445071322685,-34.85003857978879,36.95104875428876 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark05(-0.8315834556777687,-1.5707963267948966,-92.08778768641332 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark05(-0.8320395518204092,-1.5707963267948966,-53.5621024664282 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark05(-0.8320557829310076,-67.46931396202787,-732.8783138771455 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark05(-0.8328916591307811,-85.05193041988579,40.18830946224321 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark05(-0.8331916337942349,-1.5707963267948966,44.1602638762236 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark05(-0.8332313494287886,-1.078264876533653E-15,48.02392957949678 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark05(0.833311829160279,-1.5707963267948966,-9.173591236523356 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark05(-0.8336074522517279,-3.9699834390383977,-168.2679715265391 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark05(-0.8339655942916795,-73.25861039587467,-15.723589278494613 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark05(-0.8347779792220265,-0.36948261568275453,-86.32337836877174 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark05(-0.8354589575245448,-1.5707963267948983,21.844127930898647 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark05(-0.8357710933130448,-97.93825221166306,-31.712959047120364 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark05(-0.8374239320957345,3.172881013341545,-29.27981866431924 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark05(-0.8377597468329088,-16.025844391787174,-95.20311964794277 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark05(-0.8378438745609595,-42.114605096798286,-12.19883824430826 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark05(-0.8378683257648856,-67.41993648081547,-29.885390645939054 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark05(-0.8380355672192783,0.240161540872481,100.0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark05(-0.8391867597965018,-1.570796326794898,453.3264375023383 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark05(-0.83981287565809,-0.003539148062584034,-0.0065763093494462235 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark05(-0.8398772182946683,-0.6116981020870735,-34.45980131611228 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark05(-0.8399454103248313,-6.200733638619031E-16,0.0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark05(-0.8402595731335443,-670.5468210525453,66.14184171368343 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark05(-0.840333288445699,-92.09690559543635,-1.5707963267948983 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark05(-0.840395874712411,-22.831315537799547,1.5707963267948983 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark05(-0.8410242849018389,-72.43908092725192,-8.103981639082422 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark05(-0.8426202769669324,-9.616702413218007,25.051683652394658 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark05(-0.8430566509506581,-9.588260744693848,85.75433122904312 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark05(-0.843570680504537,-105.18254726150644,50.75632078136118 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark05(-0.8439899992914711,-78.75171719102516,-56.140698836181514 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark05(-0.844796342083179,-4.208093085585618,-8.793494188908667 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark05(-0.8449933350302494,-10.656410498994134,-39.46150119230418 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark05(-0.8451756842774691,-1.5707963267948952,-3.1420809363986026 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark05(-0.8461471620124108,-0.08824471472340573,-5.1415950409441065 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark05(-0.8463146629265543,-35.93673478247524,59.99128430097067 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark05(-0.8467832362253335,-16.049076054439716,-85.04874296802251 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark05(-0.8468981688255952,-135.16867516523178,20.786723592059076 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark05(-0.8478210950824492,-28.96006676851627,-21.844706862000777 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark05(-0.8478828834944481,-10.487558600759169,-2.5922417073351074 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark05(-0.8480970165738652,-1.5707963267948983,117.33941648774191 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark05(-0.8482896861333137,-1.5707963267948966,35.38245464956998 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark05(-0.8483120138758489,-1.5707963267948966,32.57216293052882 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark05(-0.848687425679233,-10.235770930830451,169.18949278317456 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark05(-0.848963550611117,-1.2792462265632336,-1.5707963267451481 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark05(-0.8493610363187905,-1.4200506341465458,13.310585927235616 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark05(-0.8498153413489349,-4.709870794933718,-4.712490850271834 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark05(-0.8498751011834375,-48.32399809436699,25.70476516949854 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark05(-0.8511739134602294,-97.49237292777914,-27.213799232018857 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark05(-0.8512726785515343,-4.60855427246851,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark05(-0.8513329869096959,-129.48010740615655,84.55688629578275 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark05(-0.8516521551970584,-60.24587086577115,-67.37985838561785 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark05(-0.8522403709506605,-1.5707963267948966,78.33775610126389 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark05(-0.8523942567197444,-1.5707963267948966,69.4665315802977 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark05(-0.8526653915718185,-0.2978673430922858,-84.7341018885671 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark05(-0.8527272890859421,-0.40580554865410234,22.563267519874717 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark05(-0.8533994797339723,-72.55571142207208,-79.45104482622682 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark05(-0.8539946493722135,-1.1102230246251565E-16,-61.470583380286484 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark05(-0.8544214744567317,-0.14639344223063738,6.447758549882477 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark05(-0.8547734997687088,-66.17988174512672,-1.5707963267948961 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark05(-0.8561963373767589,-42.393819995452894,16.530501578058512 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark05(-0.856394685099759,-53.748252490305944,7.604366265180639E-211 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark05(-0.8567772766965506,-66.0545403975155,44.874212407160854 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark05(0.8569365195382633,4.633580691207541,-1.5707963267948966 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark05(-0.8580649792194951,-23.229188401375893,-0.3639146339207871 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark05(-0.8592478130485595,-0.028423961971121924,-25.147219400592405 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark05(-0.8604364616376747,-29.147044012405118,139.77251859072834 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark05(-0.8609837305075517,-10.967326215205603,-38.69911184245076 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark05(-0.8611595953710638,-5.0052077379577523E-147,-59.5614828319642 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark05(-0.8615700599092425,-53.74069670218531,-0.9352261426795508 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark05(-0.8617311760495342,-607.8979296579506,-58.25487092988918 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark05(-0.8619079759737103,-97.40004099393744,102.01178288977069 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark05(-0.8624180188646386,-54.46162624129444,-28.598742340432537 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark05(-0.8628958442507284,-1.5707963267948966,3.141600312521741 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark05(-0.8629095562137952,-3.8815400251428684,-43.67278848146798 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark05(-0.8639978553893909,-1.5708029058220094,3.15020271555559 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark05(-0.8649295230519726,-1.1099893215292296,-42.88975372134294 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark05(-0.8649506440526658,-0.24127436152656911,1.5707963267948966 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark05(-0.8651446626935577,-1.5707963267948746,-1.5707963267948966 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark05(-0.8652516662642711,-141.8649545995211,-5.142062306025565 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark05(-0.8656329348616011,-1.5707963267948966,-1.5618270905274574 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark05(-0.8663579860556443,-16.5603220825066,-79.22432642817589 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark05(-0.8669261869565932,-3.757551623897882,-68.80089077492006 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark05(-0.8670873348275112,-23.261476532513086,-89.51414566794077 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark05(-0.8686358885900725,-53.41225969921087,84.29763744882044 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark05(0.8693603747116752,-111.03990361906638,106.88325616211424 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark05(-0.8695047469369688,-61.09947566430928,84.66797884301978 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark05(-0.869669293999392,-66.50607213075838,-80.95488080349513 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark05(-0.8704499717150611,-78.68089795257424,64.86469231014755 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark05(-0.8707113730408284,-66.43717945442557,56.54694491497828 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark05(-0.8713925402773818,-3.1420818195491043,-167.32384195202042 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark05(-0.8716633737019218,-0.15035013436130748,27.866475448197694 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark05(-0.8719474272743701,-1.5707963267948966,41.44404891385662 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark05(-0.8725455065977545,-2.1684043449710089E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark05(-0.8729276915333842,-1.5707963267944123,77.1104008319202 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark05(-0.8730265065746934,-48.63955332379679,-1.5707963267948966 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark05(-0.8740460374122666,4.470253988429129,-3.207299252838476 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark05(-0.8740985846935021,-66.0606874133067,-63.34548987999855 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark05(-0.8754433672163133,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark05(-0.8761739930714508,-3.141594560938471,-50.13369138945569 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark05(-0.8768258812474403,-3.383105052702433,100.0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark05(-0.8776095583783601,-66.46562846842409,-4.712389105396104 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark05(-0.8780875934317642,-0.1833002155389276,-114.4942484028483 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark05(-0.8783140525984493,-10.219868208215104,0.5818481514865699 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark05(-0.8790165273654413,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark05(-0.8793527571802304,-42.14685747357618,0.0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark05(-0.8794077824118071,-3.159161629279012,56.83148724777959 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark05(-0.8804402435441432,-1.5707963267948966,63.00202581492753 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark05(-0.8805220661461037,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark05(-0.8807868562624857,-65.97389289535731,-84.81343069216906 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark05(-0.8812926334115767,-0.08744668698144994,27.094967481625375 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark05(-0.8814751520230768,-1.1968591997922924,-509.805530591053 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark05(-0.8816718407118393,-0.3146795890077321,1.5707963267948966 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark05(-0.8817060011284573,-10.142695230470494,1192.8502559085177 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark05(-0.8828802551981028,-0.5544878373982822,-89.53539062730911 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark05(-0.8830902619171754,-66.42729665841992,12.568323739361817 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark05(-0.8832379570699409,-1.5707963267948983,-51.45121288543568 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark05(-0.8832873199952245,-53.83820664352844,1.5707963267948948 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark05(-0.8835255861531158,-2.220446049250313E-16,-9.487277960884294 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark05(-0.8846826046332358,-3.1415928920085787,-1.5707963267948966 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark05(-0.8847366583050715,-3.1415926541306547,0.0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark05(-0.8859278792692429,-29.7720961351256,-48.63699692837395 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark05(-0.8862448157027276,-3.142080957982728,-22.266730793359542 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark05(-0.8863284555385997,-23.474240361904005,0.0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark05(-0.8865843797386326,-15.88454958780611,25.151264303560097 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark05(-0.8876224783455395,-3.583747525453603,-180.696553928394 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark05(-0.8881540944324898,-41.300638538116786,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark05(-0.888354045615183,-84.94211225254878,1.5707963267948875 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark05(-0.8888282927025166,-0.9635821215220073,-1.0150789325529097 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark05(-0.8895893911725352,-66.1355343278318,-18.857394190628717 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark05(-0.8900078755025906,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark05(-0.8905632329186728,-41.1639764368115,1.5221946429252518 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark05(-0.8915307178689602,-3.239001945487393,31.47578973284385 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark05(-0.8918302315420981,-72.25663293991403,-2.7149352492497663 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark05(-0.8920781516583083,-1.5001118650076912,-92.29501733579414 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark05(-0.8921672254773135,-53.46847670565511,83.3081730378761 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark05(-0.8928113288883803,-98.16582866903957,-1.5707963267948966 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark05(-0.8954876408950807,-48.448930586816985,97.81152508410214 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark05(-0.8959694102939151,-1.5707963267948966,-550.2434772034487 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark05(-0.896624848215546,-0.8061646154071594,-544.4948511642052 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark05(-0.8968585604563533,-1.5707963267948966,9.140322734201206 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark05(-0.8968798874726073,-1.5707963267948966,41.996470974269734 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark05(-0.8970751592390656,-78.74995060748589,77.07216753200831 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark05(-0.8987051229830841,-3.15848659688668,83.6358028596595 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark05(-0.8988951690181283,-36.085251231055885,-134.9783694935275 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark05(-0.898960883246898,-1.2669360502718714,-644.4484134484131 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark05(0.899312661739927,-16.49008590628671,-0.21394708240414673 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark05(-0.9007875049033853,-0.9338202979580941,27.591083793311242 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark05(-0.900845877675774,-66.44347585517679,-7.08304191510269 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark05(-0.901063333977906,-86.29563207326505,-164.8266279247324 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark05(-0.9014907424566527,-66.52306786454832,-69.84798187521382 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark05(-0.9016635458926283,-9.561939200857264,-61.1453651973064 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark05(-0.9017281157507577,-1.1230795860781801,1.5707963267948957 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark05(-0.9018034705244844,-1.57079632679444,-28.88757640358233 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark05(-0.9020276222098504,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark05(-0.9023235779735033,-1.5707963267948746,457.1017310827067 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark05(-0.9026163637353248,-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark05(-0.9028176643999135,-1.2206874506165377,-83.83236054647685 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark05(-0.9036126891126417,-0.6254159337313462,6.283185784034303 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark05(-0.903892165693515,-79.93172191799076,4.1415926556012765 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark05(-0.9039409264497213,-1.5707963267948963,-65.98125822676853 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark05(-0.904790372918022,-0.9337039610882645,41.52408962076457 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark05(-0.9049810247690573,-1.5707963267948966,-47.65330627224373 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark05(-0.9052356846176421,-60.5989651611494,-54.521831821415105 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark05(-0.9056632722448787,-1.5707963267948966,95.35768835418489 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark05(-0.9059406937670008,-72.41348784351047,-88.56763284153837 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark05(-0.9074265469887366,-10.197296113113623,0.0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark05(-0.9075623811432685,-72.99436040045171,-190.58074823856262 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark05(-0.9089983259894635,6.236998004968851E-17,-88.87393229607032 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark05(-0.9090784304450467,-1.5707963267948966,591.3874497703634 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark05(-0.9103931925646277,-15.98525694320752,86.96718955605485 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark05(-0.9104086696979887,-0.47266579334396397,83.86117658810889 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark05(-0.9107193671451271,-1.2500910082181238,0.4596356763509003 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark05(-0.9108323723696238,-60.822936774887495,95.46108088517039 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark05(-0.9113018090182656,-1.5707963267947989,-57.03595332815463 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark05(-0.9115609021506259,-59.95527149685975,-1.5707963267948966 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark05(-0.9116484109702107,-1.0130609769222585,-236.6179035278872 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark05(-0.9127936572763871,-1.5707963267952325,8.274615195281415 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark05(-0.9131111523993568,-54.90033111195836,-12.956956663446265 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark05(-0.9148805215145589,-98.2412829901524,0.0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark05(-0.9150577832579069,-98.86724938923439,4.141592653589793 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark05(-0.9150874284179241,-0.7796377226759127,3.834942214776168 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark05(-0.9153838893421443,-42.267705443780024,71.22323526689992 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark05(-0.9160009654378523,-0.21786457325583483,63.54084074791035 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark05(-0.9175713442017346,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark05(-0.9177014905252552,-1.5707963267948966,-19.747736230734844 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark05(-0.9177534498066643,-1.570796326794895,5.212391345964906 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark05(-0.9186879894075632,-0.6506231400045783,-1.5707963267948966 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark05(-0.9191501741153942,-79.81773700894757,-1.5707963267948966 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark05(-0.9195087069155622,-0.1272015939965688,19.757966256787178 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark05(-0.9207981734293889,-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark05(-0.9214630000389995,-66.36829239474447,-38.67962934556479 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark05(-0.9216547038974227,-1.5707963267948966,3.697038081771171E-273 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark05(-0.9216664051769988,-1.5707963267948966,6.283200759172751 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark05(-0.9234483158280103,-10.9896356642586,-25.863180862682583 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark05(-0.9239630086366573,-0.932292649608673,63.25388597706703 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark05(-0.9242980311408567,-0.5049561860686236,-0.133064685957903 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark05(-0.9244775498960983,-60.2082671061324,1.263014871940277 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark05(-0.924653120121695,-42.105192408789435,100.0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark05(-0.9259350279680234,-0.7509925439336835,-146.22898530744123 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark05(-0.9264098263063215,-10.636807212911947,-35.08957153298891 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark05(-0.9266175564556898,-72.44044012695343,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark05(-0.9272114430327546,-22.91984071426056,-29.15906251545571 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark05(-0.9272373367634583,-40.98215337587043,-28.018889283392365 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark05(-0.9281825325389839,-1.5707963267948966,87.7879150225252 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark05(-0.9297319259343686,-22.46330740074877,42.66842338883976 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark05(-0.9297743252004063,-16.868858122605175,31.960657629959407 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark05(-0.9304716232593222,-0.6528701480194079,74.2697719614198 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark05(-0.9305977442361615,-73.51570806204684,-90.62621709098701 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark05(-0.9310290117961628,-10.315697558337128,0.0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark05(-0.9315603413971019,-15.78266264202071,75.56402271712761 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark05(-0.931635698707795,-1.5707963267948966,-1.5707965311785252 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark05(-0.9316457089141745,-61.22515670947457,-10.818900276150544 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark05(-0.9316522457599241,-0.10573405490240824,-40.011578975642514 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark05(-0.932279793443905,-1.5707963267948966,40.46812781026398 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark05(-0.932962105733786,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark05(-0.933311158820469,-78.77322842608741,-88.96525087258644 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark05(-0.9340977735947718,-35.61872931071481,-10.669070159446505 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark05(-0.9341482498861096,-29.508860449847475,1.3127476784815997 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark05(-0.9354505975948405,-0.5975763219771162,79.26491062708075 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark05(-0.9355675292710062,-16.052375331186326,-79.41909111047045 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark05(-0.9358480488134424,-17.05305173141052,-1.5707963267948966 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark05(-0.9360796152951707,-42.322346136322565,-77.30921266440953 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark05(-0.9363422004841971,-1.5707963267948966,-3.1416145712683794 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark05(-0.9368067859546134,-0.2880670221252899,-6.406665904585923E-145 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark05(-0.9369054701795825,-1.5707963267948966,0.12271577501110711 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark05(-0.9369476199738254,-0.318875676344927,73.81071560187003 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark05(-0.9375274196520359,-16.396344226256133,-1.7178963037994492 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark05(-0.9376867583096861,-0.3859973415293719,98.3873819791998 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark05(-0.9378298771273563,-1.5298392892244341,-762.4747220849155 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark05(-0.9390228645286953,-1.4925075223260438,79.22328308845675 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark05(-0.9396793176760476,-1.5707963267948963,-64.94339714425185 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark05(-0.9405898526524854,-3.552713678800501E-15,92.55485869733099 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark05(-0.9406199088620709,-1.5707963267948966,5.611031933461512E-191 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark05(-0.9409747237751783,-73.73517147493176,-18.23057430177758 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark05(-0.9411130875203624,-16.346310008571624,-49.08190082309754 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark05(-0.9411591319085051,-60.35399899050187,8.470329472543003E-22 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark05(-0.9414023672328427,-16.047198238434124,0.0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark05(-0.9416588491763176,-91.61594179179005,-49.77048499879177 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark05(-0.9419267126725762,-3.1415928925807206,92.32389074613471 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark05(-0.9424126308010594,-1.2761652689954963,1.5707963267948966 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark05(-0.9428339197282742,-3.7255568727687205,56.5200875485217 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark05(-0.9430368447739683,-15.94889934647135,-0.40218489631243226 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark05(-0.9431196790778666,-1.5707963267948968,73.72107635312221 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark05(-0.9442584610901008,-55.55287754943754,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark05(-0.944552874910964,-9.520462222586227,-78.78671337218007 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark05(-0.9446696294476605,-0.529082335023726,-6.2831849218498235 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark05(-0.9454025568148531,-1.5707963267948966,34.558495752234116 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark05(-0.946143683399093,-29.746505528120927,-82.49923675768866 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark05(-0.9462919848171323,-0.7285006264714509,90.46772413756997 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark05(-0.946402644812846,-22.410947541535165,-35.199535771003525 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark05(-0.9465215223111443,-29.65816050421713,-53.67105806648366 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark05(-0.9465257725385412,-3.14492424954147,64.95722614636188 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark05(-0.946726771127604,-22.92896077456684,0.0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark05(-0.9467869265972411,-1.5707963267948974,-43.314484471248846 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark05(-0.9470990369630553,-9.926163061233595,82.7194254044349 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark05(-0.9471844660847658,-0.8458257822068538,0.0022209039280091923 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark05(-0.9475949309636884,-10.014731773599522,55.66995358763083 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark05(-0.9482990470949204,-48.142559996442145,54.21480204601852 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark05(-0.9483879819442934,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark05(-0.9486554102730587,3.1420809348398544,20.638468089779963 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark05(-0.9494495043671917,-72.99107270570482,-20.61683783949546 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark05(-0.9497388999745687,-0.47925240813883235,92.20941509276955 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark05(-0.9500261405516643,-98.62837937097632,168.6397134440395 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark05(-0.9504336358299221,-9.461968846329299,-55.24148924041705 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark05(-0.9507456208787387,-0.7487126641735304,169.6362745527835 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark05(-0.9514046491158237,-16.575426203287776,-4.7123889807732535 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark05(-0.9524087767552719,-41.394956228649825,-349.694976234012 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark05(-0.9528912105919873,-66.26958290567748,-47.191936254239806 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark05(-0.9529680729937908,-54.75720549044128,-1.5707963267948983 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark05(-0.9539941611105407,-15.953904682277944,0.0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark05(-0.9555225749803236,-91.83065494651225,-12.597622768988733 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark05(-0.9558003886710691,-41.8531237996133,-3.6846672968758885 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark05(-0.9560433807367276,-557.0184996871949,-21.75111129289334 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark05(-0.9563829993907171,-7.31511930420656E-99,-63.77642005602783 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark05(-0.9571257297016318,-1.5707963267949971,-12.874600468685333 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark05(-0.957551441523325,-42.27800579177176,63.89204764663714 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark05(-0.9578403530777209,-1.5707963267948912,70.15385848531129 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark05(-0.9584329918727548,-0.2401862854130037,-1.5707963267948983 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark05(-0.9590448415324636,-67.41488234548518,5.141593303451866 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark05(-0.959778239764995,-538.2119714637832,13.654530333237048 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark05(-0.9603410036900142,-66.33307506501656,-494.27698542149653 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark05(-0.9612481565356215,-4.237602125553629,-51.22487935630275 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark05(-0.9614413585528594,-0.22372805232974521,20.420487935673023 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark05(-0.9621564530805293,4.14159266070541,140.80689623472216 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark05(-0.9635461420541844,-73.54940127110358,-12.904497879239244 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark05(-0.9635978418169382,-1.3647019460237615,-0.511217059664336 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark05(-0.9637857130637668,-17.164277909900875,-45.2718738908919 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark05(-0.9647829760332804,-4.414623123019396,-106.82469003653149 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark05(-0.9649146632316814,-1.5707963267948966,-59.644982285903694 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark05(-0.965889309106322,-1.283816153603401E-14,0.0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark05(-0.9665908860725398,-85.18921781323108,-38.34288211321221 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark05(-0.9670589040706314,-3.1826903409943554,-846.6220322442526 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark05(-0.9676963211236549,-2521.0122898041805,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark05(-0.9679267502663293,-41.76519850452123,8.312078918916574 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark05(-0.9681113806110597,-72.55321642981424,5.141594703418794 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark05(-0.9682149476538546,-66.47629889153015,-16.086194581560648 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark05(-0.9687341043063271,-0.8751018943171545,-42.96635870964091 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark05(0.9696487754946617,-6.192581881391305,-86.03206154007037 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark05(-0.9698288705940784,-42.35967342618505,-55.459028751879075 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark05(-0.9700925598723964,-1.5707963267948966,4.712388980396749 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark05(-0.9705171242930688,-61.00769960078614,-169.27404901686606 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark05(-0.9709816297979493,-16.241045571218393,-89.91160815075584 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark05(-0.9717028838846815,-3.1494051535897976,50.627775068613346 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark05(-0.9723339120286071,-0.11505793202236021,1.5707963267948961 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark05(-0.9725803204936738,-1.5707963267948966,-82.74002994174866 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark05(-0.9729354061353892,1.6523409935806999,170.51544652868245 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark05(-0.9741381610171231,-1.5707963267948966,75.83534623058571 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark05(-0.9747044761393873,-66.53511036161981,2.539492682473684 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark05(-0.9748188356059403,-1.5707963267948948,-83.32501307777488 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark05(-0.9750493643736726,-1.5707963267948948,71.7073180773164 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark05(-0.9750692371870395,-66.41788447509553,90.82026376153289 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark05(-0.9758644233773666,-1.5707963267949117,-168.46177037760344 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark05(-0.9764283865776392,-1.5707963267948966,-52.22115389628552 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark05(-0.9764519435914705,-1.5707963267948948,-58.855633211997244 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark05(-0.9767186609389373,-78.98169563944647,-0.5704025575395467 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark05(-0.9774757595742579,-15.708207408588493,-1.5707963267948966 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark05(-0.9781398331129023,-488.13255143863364,13.549557682963197 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark05(-0.9783969058368465,-0.029321848461139683,60.02087238725519 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark05(-0.9785537406434437,-0.5272895971461092,-1.5707963267948968 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark05(-0.9794028915918735,-34.924871442630575,9.496486950434349 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark05(-0.9798066023669563,-54.011949997229145,-21.64912851218289 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark05(-0.9802353161753163,-16.448536646476825,-82.62458916013685 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark05(-0.9804010564998662,-122.88267460461864,-1.5707963267948983 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark05(-0.9807124978996811,-35.23942422958267,-65.76401585287508 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark05(-0.98191224925894,-53.43235187466573,0.997301190863639 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark05(-0.9822929990849532,-1.5707963267948906,1.5707963267948948 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark05(-0.9835073051370141,-9.96862698102683,20.11832283552789 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark05(-0.9835900808782098,-0.21615460683303622,-50.67311171906252 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark05(-0.9837865446967982,-22.32868612860173,48.58430732946522 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark05(-0.9843991030159406,-0.3789713121947362,-4.71238899193524 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark05(-0.9848415783285216,-1.5707963267948961,7.853985344819329 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark05(-0.9849951955927724,-85.04807502025096,-38.17539784325137 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark05(-0.9850140252606708,-28.274333882308156,-85.27519785185338 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark05(-0.9853290973044406,-35.92161992934413,-62.237790960083366 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark05(-0.9856495305541197,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark05(-0.9861377796734558,-98.60470539436535,84.2134044282362 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark05(-0.9879894313646297,-1.5707963267948966,-73.87000381881208 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark05(-0.9882316038736576,-47.45124347511147,-56.12882446160502 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark05(-0.9884831202547986,-73.59626216979373,-11.040837816551932 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark05(-0.9888618720660745,-16.120789819889154,-45.53406094870093 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark05(-0.9899417936070153,-1.5707963267948948,-7.896825413969131E-177 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark05(-0.99014652350251,-66.99653921121725,-45.10753418928936 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark05(-0.9901732254296629,-16.136506659182928,-55.42352971585499 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark05(-0.9903861912291347,-1.5707963267948983,-4.874394653843492 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark05(-0.9904440879747978,-1.5707963267948961,-14.429299909073578 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark05(-0.990629212286576,-29.26596958520669,-0.03412153876892668 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark05(-0.9906782277607731,-1.5707963267948912,53.83355193636882 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark05(-0.9907648560610876,-0.3352988705192358,90.61132502691402 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark05(-0.9911734080777682,-9.424777960769381,1.3844778332923597 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark05(-0.9923555891291052,-22.558354477648294,-20.63120703453446 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark05(-0.9927170135955049,-1.5707963267948966,-75.40157312807409 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark05(-0.9931007916738905,-10.228021692596158,-94.10360207851643 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark05(-0.9932394639084003,-10.934289973287576,-36.10406855859383 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark05(-0.9932663378452719,-59.69026065669317,-64.93289976187124 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark05(-0.9934903193109852,-23.368433192973967,-104.70509396944118 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark05(-0.9935454803036957,-22.707384933033865,-23.462982356770354 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark05(-0.993585189175036,-66.28649274545589,33.98987853747917 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark05(-0.9936324715990172,-86.14754055617432,-6.287141079082914 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark05(-0.9943970433273128,-86.26670365384544,-100.0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark05(-0.9947352900553779,-1.5707963267948966,89.21507689163288 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark05(-0.9949395202901307,-23.3815043653266,-1.5707963267948966 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark05(-0.9953040468056216,-425.1147368604794,7.788028655171686 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark05(-0.998844261155158,-864.8944653333974,-47.316436132312305 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark05(-0.999190477030477,-10.475114131099218,-154.74198811923418 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark05(-0.9996947241739809,-1.5707963267948966,-31.63890346829184 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark05(-0.9998225940412732,-15.803269346530591,-91.03766807858521 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark05(-1.0004179038613157,-66.4399611557023,-27.01614408138986 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark05(-1.0004411222753191,-0.17065516699562783,44.26656498321016 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark05(-1.0004708948173306,-0.6731058926990756,85.0162234962436 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark05(-1.0006714384189086,-1.570796326794896,96.48261791853822 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark05(-1.0007577391411988,-9.978051685426971,-77.25324623079983 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark05(-1.0007688309385956,-86.33065126093811,-52.46608434906452 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark05(-1.0010415475915505E-146,-72.278013906023,0.0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark05(-1.001270522108058,-1.5707963267948966,-32.85804506157548 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark05(-1.0012967322377595,-54.77018897069419,-95.55622776535074 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark05(-1.0020754506890515,-35.82412261371692,-13.338843957579385 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark05(-1.0023036052732046,-53.64820553879342,-87.12103295675288 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark05(-1.002763243492609,-92.32735928205311,-78.95066377330927 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark05(-1.0027918095932844,-0.0965081066867521,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark05(-1.0039844152248634,-1.5707963267948966,-31.735964347639015 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark05(-1.004035780518792,-60.949375163928075,-14.13969672040602 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark05(-1.0041159245952969,-53.947973693035244,-96.57012157621254 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark05(-1.0041841630753967,-6.628609994475277E-15,-4.0607069397050388E-115 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark05(-1.005025356188961,-1.5707963267948912,-31.532802475536993 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark05(-1.0053805715947157,-1.5707963267948966,58.38535119514516 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark05(-1.0054871125488238,-1.5707963267948966,-641.7797362454437 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark05(-1.0058939149962425,-3.9307131750109807,175.58805342489535 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark05(-1.007061708487107,-3.1426456699075245,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark05(-1.0074041592003866,-1.5707963266481666,-55.105592710520355 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark05(-1.0091607337911301,-97.38937250638075,0.0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark05(-1.0099945916253334,-67.21960098715485,-39.39454914356733 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark05(-1.010389557916497,-29.271569471955623,-9.560821526997842 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark05(-1.0106325506614375E-4,-1.5707963267948966,-1149.0713600635959 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark05(-1.0107936529880487E-174,-35.55926962115248,76.07838367331696 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark05(-1.01106157563391,-73.3469567825026,-58.278017957520504 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark05(-1.0117637131309363,-1.2359950255228145,-3.420314191907977 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark05(-1.0118405286675127,-53.899173465584106,1.5707963267948963 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark05(-1.0124115183497437,-393.52566146669176,1.5707963267948966 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark05(-1.012447456298219,-0.6851024119799671,-1.5707963267948966 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark05(-1.012497944959156,-9.988092755029887,-63.5795538008375 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark05(-1.0126334277086537,-1.5707963267948966,9.424777960769381 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark05(-1.0131806369934253,-67.00430009975581,19.214531725841184 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark05(-1.0135133273195314,-0.11594698379526322,-39.75402539767936 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark05(-1.0136490062578036,-22.864091343923587,-88.46851332575767 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark05(-1.0150763182638503,-85.02970431546348,-43.05011731678612 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark05(-1.0164843985366196,-66.10844047497656,6.435321176740854 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark05(-1.0165179921475982,-0.10351806835421479,-51.82520273162135 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark05(-1.016873076809105,-1.5707963267948966,-56.16866279094321 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark05(-1.0171306999274872,-0.5388363057098657,17.563172827712123 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark05(-1.0177783595241987,-1.5707963267948966,-83.79061008978297 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark05(-1.0179780529576545,-1.5707963267948983,812.9783116558964 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark05(-1.018029890871726,-22.285854423556074,47.32362057517531 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark05(-1.0196914264894001,-72.50182534442794,0.0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark05(-1.020275249226212E-16,4.2351647362715017E-22,-59.10874086486591 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark05(-1.0204173363291626,-3.14165755358961,-1.5614821499961813 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark05(10.209601791916896,11.408447250225251,39.66880224196467 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark05(-1.021409471185344,-1.5707963267951175,176.10408901528675 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark05(-1.0226862805065347,-3.141592653597078,60.997404887638744 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark05(-1.025388619030513,-1.5707963267948948,-1.2671352531254894 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark05(-1.025505288585805,-72.65698377093177,-97.77787420617847 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark05(-1.0257708088637696,-42.41122984929554,-84.67816242921502 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark05(-1.0258077127547836,-78.75692226693162,-72.66557792432701 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark05(-1.0278000082481893,-98.11306913519816,38.7193803329047 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark05(-1.0279064575871253,-0.11126991337521513,-147.65029932479 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark05(-1.0279324638980845,-1.5707963267948912,27.734407829693282 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark05(-1.0279788656633784,-60.93509955534917,112.77988820323586 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark05(-1.0282618176458627,-72.25663103349657,-1.5707963267948966 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark05(-1.028425233901423,-48.18331630395512,23.68338978738601 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark05(-1.028516622243405,-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark05(-1.0290002879004185,-79.77987382516591,0.0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark05(-1.029274167211338,-29.31050556325646,94.40123249230348 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark05(-1.029411143016361,-66.26030293664407,-47.91780566922556 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark05(-1.0302393122356732,-10.007896028897974,-32.060937527654005 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark05(-1.0304948540106962,-1.5707963267948966,76.96902001294994 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark05(-1.0309913910520014,-4.4864592632839475,-1.5707963267948983 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark05(-1.0315144745805005,-1.5707963267948966,56.36632876532096 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark05(-1.031592492168758,-53.609178989107775,1.5707963267948948 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark05(-1.0340253700509638,-29.06295972773008,-26.703537555513243 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark05(-1.035748300453747,0,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark05(-1.0361018297718543,-0.960570226287554,6.64593542683454 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark05(-1.0364286447085629,-53.97250607502732,56.905988107977244 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark05(-1.037896177604585,-22.865452186013695,-1.5707963267938656 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark05(-1.039368851525909,-1.1540331762403928,-24.86136222456898 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark05(-1.0412510026194013,-48.29071793506559,0.0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark05(-1.0428113862138062,-4.457467128609956,0.0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark05(-1.0441988778301883,-97.76851889745359,-8.853981462774701 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark05(-1.0456012295629467,-135.58121891096795,9.430901723418707 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark05(-1.0457324469037863,-16.687758327511858,-57.80323609844509 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark05(-1.0459197639723814,-0.20023940731049555,-22.597588081525082 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark05(-1.0461475705774168,-0.26679027698954605,2.403438850109623 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark05(-1.0462763237038664E-13,-1.0012253960277626,-1.5707963267948966 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark05(-1.0464076737750396,-91.96608589201615,0.23771931806023774 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark05(-1.0465912667119994,-1.5707963267948966,93.61482079212117 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark05(-1.046904614590355,-1.5707963267948966,41.30287833414556 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark05(-1.0482303668326094,-1.0547185920671553,1.5707963267948966 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark05(-1.0485875761095196,-3.976362970874569,-1198.8759719408638 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark05(-1.0494310377187315,-1.5707963267948823,-21.856296026297926 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark05(-1.0501867930116349,-34.689816487096245,-613.0619611095086 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark05(-1.0509555478204276E-9,-4.141846067538358,-107.53740777779281 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark05(-1.0523739361280908,-41.073440955466765,83.29268023501277 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark05(-1.05266733409351,-3.3881317890172014E-21,-95.22736579485944 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark05(-1.053408677920642,-79.9999990899504,-82.63843648297807 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark05(-1.053601613972639,-0.49891565281011274,-1283.7213939965325 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark05(-1.054590154174603,-100.0,-85.19061343775712 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark05(-1.0557113701057863,-3.7347412173715853,34.55751918948772 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark05(-1.0567990191298129,-54.57340145724589,-1.2916396090085414 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark05(-1.0571217497433296,-0.21699787038230878,66.34301705651532 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark05(-1.0576853396347394,-1.0010415475915505E-146,-53.58861953880343 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark05(-1.058506323119555,-29.474127795122953,-20.775652148995018 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark05(-1.0586128069593173,-1.5032945687260622,1.5707963267948983 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark05(-1.0587911840678754E-22,-0.15250960389484752,1.1066877775864088 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark05(-1.0587911840678754E-22,-1.5707963267948966,78.54182796028002 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark05(1.0587911840678754E-22,-79.57359168282044,32.393191255751304 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark05(-1.0595765132850155,3.142080934912749,94.72384988201887 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark05(-1.0604713858924063E-5,-1.5685421573337284,-144.5311729083339 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark05(-1.0605732255920843,-0.010721851105066738,9.683865974745892 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark05(-1.0608007293337696,-15.844351075920429,-16.654996743395728 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark05(-1.0610176595827134,-72.48729884983713,10.995574287564276 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark05(-1.0610215013445146,-91.28651728734997,-175.99761536871023 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark05(-1.0611313820597044,-79.9989043784847,-1.5707963267948974 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark05(-1.0612584498297197E-15,-66.29473184550498,-1.5707963267948966 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark05(-1.0618925934751118,-1.5707963267948966,-0.5702628372618973 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark05(-1.0625987989507093,-1.5707963267948966,-69.32219585368622 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark05(-1.063225271685699,-47.477928387472645,163.605908429252 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark05(-1.063399761732513,-1.5707963267948966,56.69738178625187 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark05(-1.063968371507971,-40.85450188299104,-44.225950784608045 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark05(-1.0646649306787088,-1.5707963267948966,-63.70572871919156 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark05(-1.064744521698301E-6,-1.5707963267948966,157.64541759057556 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark05(-1.064765400093852,-67.30811362504714,-57.239057098740034 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark05(-1.0650177342934648,-1.5707963267420701,91.16344222402424 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark05(-1.0656019390900728,-0.31395152398839893,98.96016874461985 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark05(-10.657588288111668,88.69867352577069,55.729962863645085 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark05(-1.0661917766497937,-3.141592892196175,-21.84318260956954 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark05(-1.0664839678857705,-47.46540110145805,-53.19439444977619 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark05(-1.0667055294047423,-66.49243353152401,-83.17791617094454 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark05(-1.0667972427134247,-1.5707963267948983,63.34633549215766 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark05(-1.0670387443321567,-53.94671092341683,-1.5707963267948966 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark05(-1.0670429884385628,-111.1953049119652,25.45250862885021 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark05(-1.067955807508512,-1.5707963267948912,15.790052584592885 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark05(-1.0681770285293921,-98.35653423750009,-91.23445108914724 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark05(-1.0687973836512974,-0.6983178207374983,0.0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark05(-1.069696863485177,14.429225001486643,55.48242101105837 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark05(-1.069737155578074,-29.586146849206884,-89.59487728666709 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark05(-1.070503708752928,-22.539399716304167,-78.07221898372461 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark05(-1.070770861870244,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark05(-1.0717047056005566,-0.7963955142883785,-97.69371119402291 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark05(-1.0724983578752671,-1.2801490213439812,6.2832811753946345 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark05(-1.0735249037678898,-3.287865449573129,113.45588825002584 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark05(-1.0742116584348937,-78.94632279476414,56.35492118663964 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark05(-1.0753031083544187,-41.18498960226072,-92.45778435449682 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark05(-1.0756215891908367,-67.09948392912324,-53.07984096477289 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark05(-1.0772288710768168,-16.19691291428144,-24.8562145577138 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark05(-1.0780195588750008,-0.05129904793792911,88.70399267017119 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark05(-1.0785507033654438,-356.5707100524604,-59.81774423270889 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark05(-1.0787887589001315,-1.5707963267948966,-1.2854155252340482 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark05(-1.078961862846159,-1.5707963267948966,28.882521641121947 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark05(-1.0796646609195806,-154.36800889013693,1.5707963267948983 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark05(-1.0801954902688604,-65.99572592143457,-31.84026281221786 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark05(-1.08043362983592,-0.20610303921200668,8.103981635512474 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark05(-1.0808607169253737,-48.60237636578123,-1.5707963267948983 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark05(-1.0809541237662148,-167.89908252561264,-516.1842376149443 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark05(-1.0818366485682622,-0.3791152505029355,89.56425229814516 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark05(-1.0819360030139533,-53.91296464083455,1.5707963265816764 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark05(-1.0820760709853852,-16.08736247862271,-10.147272797619674 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark05(-1.0828944010058132,-1.5707963267948966,5.778276754513439E-15 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark05(-1.082940821692934,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark05(-1.0830839966970722,-54.46152991656086,-1.1869459682199748E-66 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark05(-1.0833596674844324,-41.65149841612735,53.73314760503564 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark05(10.840635146946639,65.33315908702886,4.984860086594708 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-1.5707963267948966,-21.991047476412785 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-1.5707963267948966,84.82301525197816 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark05(-1.0842021724855044E-19,-2.1684043449710089E-19,-1.5707941863976365 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark05(-1.0844913021135703,-1.5707963267948966,1.570796326800729 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark05(-1.0853852056898763,-1.57079630474396,-7.8539816527493835 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark05(-1.0859155460855154,-78.57226861555233,1.5707963267948948 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark05(-1.0865387174360905,-4.5310363022389275,-1.5707963267949054 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark05(-1.0868894086946674,-73.76680496341855,-15.70772945791244 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark05(-1.0875344257681967,3.1415929369304036,-79.41453572161667 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark05(-1.0878495317736385,-78.57351380800652,-48.80483550708996 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark05(-1.0879974368211334,-1.5707963267948966,-21.286508389573104 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark05(-1.088092872680468,-1.5707963267948966,72.9575584740049 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark05(-1.0882335541158832,-28.381284727553503,-41.255006929918835 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark05(-1.088428154605253,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark05(-1.0888903426430006,-73.57414450958191,0.0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark05(-1.0890996631096768,-9.902528479822976,-1.5707963267948966 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark05(-1.0892375815656827,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark05(-1.0894489767834656,-700.5948422308037,-8.418031184460304 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark05(-1.08954524312864,-22.945427985846422,-192.48068717315107 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark05(-1.0900195854177923,-2.7743113653275098E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark05(-1.0900788478285637,-807.989181426981,0.5381636496878445 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark05(-10.905771401368895,10.884600324139512,82.94858695887419 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark05(-1.0906142885373598,-1.5707963267948948,-54.4296099526592 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark05(-1.0924633356193567,-160.82863669525602,-108.7453427108721 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark05(-1.093191344432745,-0.5855719047848034,-3.1415926535897953 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark05(-1.0934663024123128,-1.5707963267948912,-3.7124744890881516 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark05(-1.0934800185465698,-54.547873414023336,-3.1415928986689092 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark05(-1.0937311026854872,-1.5707963267948966,56.54866776461632 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark05(-1.0937879410638658E-19,-1.570796326794893,-37.94918269899364 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark05(-1.0953882006950908,-0.14552407629530664,-59.5827879425929 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark05(-1.0959046745042015E-193,-1.0230363882155702,-22.44290744726569 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark05(-1.0960457285335028,-73.24344825587197,-3.1415932016867285 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark05(-1.0975445311305805,-35.13462216012042,58.40825591799286 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark05(-1.097590396757008,-3.266592734982657,1.6208540404677618 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark05(-1.0977527211323719,-78.93692780697262,-1.5707963267948983 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark05(-1.0980655757178148,-34.95387494722843,-7.854437995006609 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark05(-1.0987487906930296,-9.516057878687043,52.280020245180694 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark05(-1.0990259103942746,-41.406068673583164,0.0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark05(-1.1001436741225687,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark05(-1.100384235684081,-1.4251093177387242,100.0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark05(-1.1005020053109844,-67.01991107669133,-16.31680098561096 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark05(-1.1010206537400755,-22.363617244880515,26.83533256566517 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark05(-1.1010802279370449,-35.86566438585889,61.26105674500097 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark05(-1.1013501731798174,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark05(-1.1017805714948212,-0.05431908170626692,1.5707963267948966 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark05(-1.1024781225780553,-79.28589115441181,5.551115123125783E-17 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark05(-1.103016172477877,-1.570796326795261,-33.417822804609585 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark05(-1.1030972302050088,-1.5707963267948966,17.069947442084306 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark05(-1.1036757852177708,-166.9394448637982,37.99356632783065 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark05(-1.104148683648813,-1.5707963267948966,-42.424391691825704 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark05(-1.1042646688850772,-1.5707963267948966,42.411500823462205 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark05(-1.1044065559561551,-66.3002448085015,-98.40564621751797 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark05(-1.1054757262564268,-1.5707963267948966,-78.26128314098075 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark05(-1.105614107320316,-0.3390994959627969,44.62081129750018 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark05(-1.1056920222036382,-0.5891674992022893,122.56302795108947 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark05(-1.105966739708924,-41.686055434288505,-29.431535547165666 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark05(-1.106771627401397,-9.582654023310598,28.189467317340593 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark05(-1.1069075800691621,-22.87295929223056,-26.43395382089587 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark05(-1.1069490153896306,-1.5707963267948972,1.5707963267948983 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark05(-1.1071867043821193,-1.5707963267948966,89.92316582295405 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark05(-1.1073725454379355,-97.66506540184682,484.8440726204761 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark05(-1.1078075502097295,-22.37112841196252,1.5707963267948966 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark05(-1.1081360785043226,-72.43992149348985,-1.5707963267948966 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark05(-1.1082075501542672,-72.45613571280151,-25.189293463827273 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark05(-1.1083191631822062,-1.5707963267948961,-579.5788288439121 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark05(-1.108769787888258,-3.2149607729731775,-79.32870474034772 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark05(-1.1090237921437307,-35.284312828330116,47.24011961207124 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark05(-1.1099394394877706,-10.47373251046765,6.283217635411818 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark05(1.1102230246251565E-16,-0.9952792879823351,52.90508448891492 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.02813226211701,-55.50447279223398 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,1.3877787807814457E-17,-49.38015364475347 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.4045582570650348,0.0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5484104279983926,48.07395611307591 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,0.01902749666876334 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-13.770547252318053 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,45.004497187604045 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-4.7123889804635 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-53.986537566700434 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,-70.47011985188247 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,8.135832909975818 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-1.5707963267948966,92.18466125707826 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-23.301442012300004,1.5707963267948966 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,2.4294642113715557,66.98934092910781 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,3.141600282984357,-4.755903313715182 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.1420809382346992,-1.5434079035171335 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.2665926536436145,22.740072649812262 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-35.795649346850574,-7.85398165777816 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,4.998297109177144E-7,44.339194699681926 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-53.51971495317265,1.5707963267948966 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-5.632041928420789E-4,100.0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-60.200358573184,-21.65060680658074 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark05(-1.1102230246251565E-16,-60.97409713784631,32.35274722568359 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark05(-1.1103891187246857,-1.5707963267948664,-4.141593085559126 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark05(-1.1113383204066118,-9.994227056187247,77.05839330186808 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark05(-1.1124006562485163,-173.87729072151103,33.863290839596516 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark05(-1.112727177522836,-1.5707963267948968,-1.570796203655741 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark05(-1.1128771337163486,-3.880183892045096,-89.61075533812982 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark05(-1.1129000948583506E-14,-1.5707963267948966,72.25663187850314 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark05(-1.1139453456824606,-4.440892098500626E-16,-1.4235194433753744 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark05(-1.1144460944088901E-14,-1.734723475976807E-18,43.741450782436495 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark05(-1.114685127664302,-34.75300772381864,-1.5707963267949268 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark05(-1.1148101705851803,-66.22785689340535,67.3511685819382 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark05(-1.1149831272139912,-161.45825737745247,66.71557271840905 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark05(-1.1153751148993267,-1.5707963267948966,-10.623904761734025 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark05(-1.1165534642041126,-777.5441767845326,-5.922054891685638 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark05(-1.1166889964452587,-79.88182194656146,-1.5707963267948966 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark05(-1.1169591039776352,-0.262413941276762,31.63383998971699 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark05(-1.1178304382391002,-3.1415929240019214,-0.19727906251953037 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark05(-1.1181316355493283,-35.68422752634019,-62.520479342585645 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark05(-1.1184068891866752,-1.5707963267948963,-15.70802431985076 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark05(-1.1203777003493638,-66.22546075244841,26.750596871245392 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark05(-1.1206668754624283,-418.9964263109579,21.435096532939667 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark05(-1.1209912756217548,-91.53500763518342,-41.53336574324572 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark05(-1.1210604662561465,-1.5707963267948966,28.334453729404544 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark05(-1.1212883035762145,-10.033084997996381,-9.254268181685816 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark05(-1.12266017971569,-74.0346921017867,-164.98820078713186 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark05(-1.1228061873499777,-1.5707963267948948,-95.40658095283506 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark05(-1.122997494408742,-42.081649507489196,7.853981633974487 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark05(-1.1231452962163797,-85.53901951020868,-64.40756321189387 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark05(-1.1235626065705322E-7,-1.5707963267948966,77.00279742279554 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark05(-1.123609691100121,-98.77943475708258,-18.924760114474985 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark05(-1.1238896606451192,-66.7700725786397,-3.548126777251497 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark05(-1.1245497356891754,-22.438606855333422,38.83929111387482 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark05(-1.1246186012182129,-0.12681996453341027,97.73460327824759 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark05(-1.1252574525910326,-1.5707963256269122,-1.5707963267948966 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark05(-1.1257087694214352,-103.98037174105409,-69.1184027111099 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark05(-1.1261024844412197,-0.02828802663550569,26.699890148994584 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark05(-1.1270725851789228E-131,-0.9211262889918486,-89.76295215716655 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark05(-1.127384633576374,-1.5707963267948966,71.64489715179013 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark05(-1.1277956381970828,-47.563701748183064,88.59709655195351 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark05(-1.1279885886245242,-0.14881941804164933,-9.541005127795218 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark05(11.284334091398222,-39.82072986406955,11.154833748245466 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark05(-1.1288651778014973,-110.62270553460392,-50.17160434993607 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark05(-1.1294247433801132,-3.143778139000045,-90.71775771549474 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark05(-1.129916597171916,-54.91415549772575,93.98559224492044 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark05(-1.1303520988720475,-3.1494051537222227,-50.86239748140072 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark05(-1.131628817377333,-1.5707963267948966,-63.9462905101133 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark05(-1.1319133558557974,-191.80050952455775,-4.71238905480177 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark05(-1.1324490625022037,-4.440892098500626E-16,-21.878346609808723 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark05(-1.1327713240221893,-1.5707963267948966,-4.437802696033677 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark05(-1.133221223951235E-17,-1.5707963267948966,36.2806705157916 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark05(-1.133465898903367,-16.01817590387254,-71.33060210874282 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark05(-1.133614453380885,-46.70351362484225,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark05(-1.1337622034836943,-42.15098041509101,664.1825294689019 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark05(-1.1348133568732812,-67.44185015680304,-40.84070449666731 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark05(-1.1348696632570703,-801.8327101467521,-1.5707963267948966 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark05(-1.1360532926329479,-1.5707963267948966,-60.355114316242165 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark05(-1.1360654054040942,-1.5707963251362442,-42.345701337950906 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark05(-1.1362106639505418,-1.4385430908100183,31.532336035261608 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark05(-1.1373303698132085,3.192072795228893,55.37394513166777 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark05(-1.1378349898675415,-191.74400030057294,-2159.018259144889 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark05(-1.1379840771319842,-0.9632080798424738,-1.5707963267948966 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark05(-1.138039637431608,-3.2665967036684873,-44.9196728815829 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark05(-1.138449865420538,-66.38473387305527,-456.6396265543456 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark05(-1.1384863727380323,-122.86873810329139,-168.23022546392048 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark05(-1.1392477139125088,-65.97568352549825,-83.41140172001535 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark05(-1.1393271114280648,-35.557827388049425,-134.07865744080544 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark05(-1.1394957396707732,-3.845230099916586,9.705683873021194 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark05(-1.1397233584365831,-3.143543051221316,26.659888286157525 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark05(-1.1404099615658545,-2.0590230357872116E-84,62.93947408051537 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark05(-1.1418110740779197,-0.12991965281896795,0.0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark05(-1.1418205124783027,-91.59310402550375,1.5707963267948957 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark05(-1.1428283873885974,-1.5707963267948966,-77.68934768550646 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark05(-1.1428501750101068,-1.5707963267948966,-62.34889871216282 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark05(-1.1447776221957422,-1.5707963267948966,-82.65651898314732 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark05(-1.145264758199278,-60.8859689451604,77.04437065633545 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark05(-1.1454994995359031,-9.630926300214554,-340.267314966998 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark05(-1.1456261183635874,-126.48282921445715,-117.91890434469379 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark05(-1.1457671725141938,-85.70156978648473,-14.464861235272345 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark05(-1.1459834014356667,-0.5337819950039002,70.75856407523618 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark05(-1.1462905663121639,-0.07345581065036232,76.96902001294994 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark05(-1.146340387677398,-418.8920802100913,25.571244257474586 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark05(-1.146654047520185,14.436274736744416,63.0343942129933 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark05(-1.1472823963273413,-97.40264859392532,99.94700199452703 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark05(-1.1476620910859707,-0.031932337631335295,-10.62910178026245 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark05(-1.15053994504878,-0.02065184642152318,1.5707963267948966 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark05(-1.1506052526595072,-1.246347381853474,1.5707963239389113 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark05(-1.1506229160553474,-0.14686075047620273,-58.301927255982406 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark05(-1.1513043757446915,-86.30341313897559,-1.5707962831273306 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark05(-1.1518911441794604,-0.4899730787994338,-6.284517151045744 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark05(-1.152827689417007,-1.549207706253186,16.182130827015726 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark05(-1.1536721809219899,-60.067915805963935,89.02422910824203 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark05(-1.1541579995879214,-79.30457091359071,-117.1996253923015 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark05(-1.1549157737804499,-0.1449722787587453,-91.74371561617497 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark05(-1.1554704715027337,-1.0241340547924238,-91.10618210487529 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark05(-1.1565201263454412,-48.68334096728399,-8.62767237921085 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark05(-1.15653751367578,-1.5707963267948966,4.712388980519038 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark05(-1.1567592233241637,-66.36203638360439,1.5707963267948983 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark05(-1.1570714799411235,-9.488472202959688,-5.1420036414399615 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark05(-1.1578806502799162,-10.638428096186333,-134.06332978233272 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark05(-1.1587973131562668,-1.479831296825489,18.860657629342406 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark05(-1.1592140053053193,-1.5707963267948966,-25.245332845032237 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark05(-1.1592583848339189,-28.90331931331434,-33.76033230962648 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark05(-1.160554853475341,-1.4600746081131435,-73.69557629903059 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark05(-1.1605824482838065,-1.5707963267948926,54.81720369599903 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark05(-1.1606225220785493,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark05(-1.1624130519396516,-67.30744018313088,-45.492689064979295 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark05(-1.1624162639054694,-66.99798855012236,-1.5337956698009036 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark05(-1.1628708104480987,-67.10925259345487,-84.88130965655151 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark05(-1.1629979455600175,-9.694677345611444,-3.141592654083053 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark05(-11.630030295823772,49.598657981062786,79.38262292669393 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark05(-1.1633966391521733,-66.04123925521347,-5.1421530498297185 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark05(-1.1635101023620593,-154.6693146098788,-20.8579081639336 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark05(-1.1635857742819318,-0.4273627366115538,-9.517086342539415 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark05(-1.163698929198926,-16.35485914460634,-56.258238635377225 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark05(-1.164420395528322,-15.91463377177078,1.5707963267948983 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark05(-1.1650485511302546,-0.22111309584872013,14.503150717007358 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark05(-1.1662299610654594,-66.294071531368,-89.72406918935414 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark05(-1.1664768684594917,-67.08058445172742,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark05(-1.1668072025146032,-0.8096214301956906,84.44282869799369 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark05(-1.1671139984997279,-73.00965616577543,1.5707963267948912 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark05(-1.1679387921064477,-67.28162741291823,-1.5707963267948961 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark05(-1.1690101524377687,-41.150859855654744,-28.196122731968007 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark05(-1.1691786937974948,-8.881784197001252E-16,8.103981635790902 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark05(-1.1692633592821422,-41.58806614122035,926.6186938752139 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark05(-1.170717417037211,-9.956081647442396,-329.8372920734737 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark05(-1.1710995537291709,-0.5457841653158804,-61.26105674500097 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark05(-1.1711306677738924,-1.1228038798590956,-50.936464727120715 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark05(-1.1719691161636803,-0.8227156290368639,18.87240941893579 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark05(-1.1728563078976526,-1.5707963267948877,22.351337869370774 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark05(-1.1733862353067326,-1.5641992373487936,19.325680899871095 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark05(-1.1735953268316295,-1.5707963267948966,-0.2536737270439948 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark05(-1.1747933920761655,-0.3922106904442947,-3.154067521998995 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark05(-1.175076737859615,-1.5707963267948912,-7.697620192271074 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark05(-1.175797102622305,-73.08212743341538,-73.77567872819975 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark05(-1.1758685208810775,-10.018348289848506,1.5707963267949019 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark05(-1.1765850930965427,-3.141592668624455,6.746748668397571 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark05(-1.1781338767868743,-3.157393120951638,-21.991152984692224 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark05(-1.178161544255554,-122.98571983732396,45.61122801492371 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark05(-1.178438689270294,-79.45189957062169,-181.1730262055299 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark05(-1.1784724636743797,-4.598264522366111,-1.5707963267948966 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark05(-1.17901219594722,-0.5691038174859226,-34.833540396959165 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark05(-1.179324314096533,-35.57513403617099,15.867341880694987 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark05(-1.1795222404271184,-28.73127286760686,-50.01657954872915 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark05(-1.1799538571573618,-98.79751827728124,0.0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark05(-1.181949149803304,-4.535644537597273,1.5707963267948966 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark05(-1.181958683606284,-1.5707963267948966,-6.283185869554267 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark05(-1.1831989735891921,-1.235509375992177,204.19142690965566 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark05(-1.1833661265915683,-53.81503416663025,-25.789076991474218 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark05(-1.1833890366076076,-0.018914890201839705,4.7125255503211445 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark05(-1.183583723347628,-0.007719818867798267,-2.697136161033285 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark05(-1.1836541510084857,-1.5707963267943823,82.27450191271635 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark05(-1.1840606356161436,-98.80700832807163,-47.28827432186647 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark05(-1.1845491517147095,-0.62271854374741,6.284161869682114 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark05(-1.1853348040982734,-34.57770829621206,77.59709655235118 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark05(-1.1854683328146982,-1.5707963267948966,-6.283185356275878 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark05(-1.186317247664145,-48.189562478886536,3.1012578981388215 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark05(-1.186651465820134,-86.22371082447759,-43.34531343462644 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark05(-1.1873618315305006,-142.7006697786499,-78.2962167357457 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark05(-1.1881822289344749E-212,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark05(-1.18842511516159,-732.4537931316964,56.609049211644674 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark05(-1.1891865983025456,-9.583330038533575,-1.5707963267948966 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark05(-1.1902214186284992,-66.31908150467069,-59.776606786526685 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark05(-1.1904505203186083E-4,-1.5707963267948966,-98.956340791015 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark05(-1.1905070403499067E-14,-1.5707963267948966,-70.26319300007687 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark05(-1.1914812489598945,-1.5707963267948966,-0.6440106474609752 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark05(-1.1917863011784444,-1.5707963267948966,-24.776364606599277 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark05(-1.1929501573286483,-73.08339953012052,0.9844089723403133 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark05(-1.1941756674938304,-1.5707963267948948,-53.945629350894016 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark05(-1.1946661101247789E-17,-1.5707963267948966,-80.11061266653444 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark05(-1.1949099042091804,-9.609564618327376,-20.91055849426845 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark05(-1.1966926937580467,-66.10710053692497,4.141592653573249 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark05(-1.1968340763720844,-67.34348342055665,-0.4754336907137532 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark05(-1.1974556111466717,-0.631257969810872,-9.953150656696637 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark05(-1.1976606854324718,-3.14159337318879,97.9487241544385 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark05(-1.1976785148178302,0.20410159126577898,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark05(-1.1977100492373367,-1.5707963267948966,-22.753866737102566 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark05(-1.1982667546833603,-41.86023906351488,-19.055420553690453 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark05(-1.1983780082929567,-78.64973101358743,-112.94288095526898 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark05(-1.1996131099062746,-1.7763568394002505E-15,-84.79301530998003 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark05(-1.2003694764250261,-3.9074115995075402,100.0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark05(-1.2008608517127963,-23.39073749495136,-100.0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark05(-1.2013992216418161,-0.03160234130720679,-46.74016440069726 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark05(-1.202137095862171,-0.1584992259292412,82.9960695125061 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark05(-1.2026480353588593,-72.26075048392997,8.320451963130466 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark05(-1.2031149154703655,-0.22638641478346244,-3.855050841290762 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark05(-1.2032571482299106,-1.5707963267948963,3.143545782095313 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark05(-1.2034316327854395,-84.93287706409684,-100.0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark05(-1.2038301099080515,-0.8358619176822528,-1.5707963267948966 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark05(-1.204594799947012,-0.2790918174661608,0.0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark05(-1.2046794999315804,-85.33115154142926,-619.3460607352654 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark05(-1.2049438051640344,-79.7773737208631,0.7411178937412046 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark05(-1.2053686209731964,-0.4516150718372566,-1.5707963267948966 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark05(-1.2053988371253945,3.142080934846595,69.13270929701966 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark05(-1.2058909193321725,-0.46942633245168053,-57.87561278274469 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark05(-1.2064626572108699,-23.158261852086106,-79.06306990094649 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark05(-1.2070340889794768,-1.5707963267948966,59.693222775365875 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark05(-1.2070344638908708,-22.512935757341303,-6.283185784018276 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark05(-1.2090207887254232,-72.50030783695837,-44.50322210359904 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark05(-1.209046345177897,-3.220052156598986,-4.479737253155275 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark05(-1.209378732720065,-22.065124867073152,-50.082426666232976 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark05(-1.2094950189541827,-4.141592653594469,-20.729762933430383 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark05(-1.2095088441153177,-41.99781831411498,155.52511503952644 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark05(-1.2108538001324831,-23.276926868719357,-74.3987565125746 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark05(-1.2113832800274484,-0.2486884973326538,-0.550006104412124 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark05(-1.2117407474806292,-41.740017105456,71.58485409373647 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark05(-1.2121252869550154,-22.379754450841588,14.43743009605727 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark05(-1.2129706732907486,-48.52129881910719,23.245788883438863 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark05(-1.2137687385724538,-73.4691113837578,6.2836797778176265 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark05(-1.2139450390171729,-1.5707963267948966,1.5707963069994983 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark05(-1.2141031414359702,-47.12730829818798,1.5707963267948966 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark05(-1.214897890527669,-1.5707963267948966,-1.5707963267949006 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark05(-1.2159499230245072,-10.357892143820505,-82.99443296403325 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark05(-1.216054179535412,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark05(-1.2164687889868242,-48.10540037869225,-20.394068385021647 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark05(-1.2168776427988335,-122.81717005058854,589.0485095200366 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark05(-1.217769316315328E-15,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark05(-1.219145537954148,-0.005528532728475451,-651.8799818032352 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark05(-12.193991736654255,-73.25184201731986,9.799889648058738 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark05(-1.2206909273854387,-10.485777992984572,0.0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark05(-1.2209481812867593,-1.3730267251319284,-1.994528658880526 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark05(-1.220999508741011E-4,-98.94381082375573,81.68922269347215 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark05(-1.2211261919666778,28.703537555515066,0.8898380009471175 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark05(-1.2215775289177333,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark05(-1.2217439227113545,-11.90787653927206,-9.805584638929417 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark05(-1.222889821815833,-105.22235386780062,-19.446185697724076 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark05(-1.2237266719650037,-66.66074375247548,29.641696964674082 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark05(-12.237319469710897,-57.06632752271743,4.238332622002645 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark05(-1.2240102106527395,-1.0917905077366967,-8.103993898012442 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark05(-1.2240501255435305,-0.09281677795344044,12.569341543375517 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark05(-1.2247741109873307,-111.441305714387,18.540198493195234 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark05(-1.224824095115328,-1.5707963267948966,-37.71716173384378 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark05(-1.2259340792542146,-1.5707963267948963,1.5707963267918539 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark05(-1.2266239138107613,-80.06436783765247,-67.80686332029376 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark05(-1.2267403853420138,-1.5707963260703268,-45.53515678756726 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark05(-1.2272733663244316E-91,-60.447160409486536,-1.5707963267948966 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark05(-1.227765318870386,-1.5707963267948966,92.45272601683399 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark05(-1.2289673095548277,-1.5707963267948966,44.92834269646608 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark05(-1.2304815452132098,-48.32283556075926,4.876807468447826 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark05(-1.2307855264825711,-3.141593001874401,1.5707963267948966 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark05(-1.2309369872023823,-6.64135031695906E-5,102.07018546008263 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark05(-1.231528102456634,-3.552713678800501E-15,99.49878676937614 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark05(-1.2316018901606556,-85.02485484802477,-1.5707963267948966 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark05(-1.232136972626137,-0.7327841492359983,-46.83590160784974 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark05(-1.23288249951585,-1.5707963267948966,-74.90969107183605 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark05(-1.2335772153956952,-10.207332849997417,6.288834548108966 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark05(-1.2338160604125683,-73.1878735646107,35.311871439692524 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark05(-1.2340918528367157,-72.5386823457514,-7.601024442516874 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark05(-1.2342397557720421,-1.5707963267948966,478.0217540037076 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark05(-1.234784620846967,-86.12226983339053,-82.36861388752824 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark05(-1.2348584070491821,-1.5707963267948966,69.45067852263355 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark05(-1.2349530527261343,-16.134326229810327,50.113575953532106 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark05(-1.2352630306407946,-67.27653781462965,-135.40470232871283 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark05(-1.2354303310336745,-98.91920634252295,67.32718478294089 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark05(-1.2354606233206036,-91.84482847117765,-100.0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark05(-1.235785918037324,-0.19764470283137098,53.28041778096343 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark05(-1.2366971984089739,-1.5707963267948966,-4.712389260172162 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark05(-1.236789152064726,-79.33872833600391,-47.7948586204306 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark05(-1.2371119785877787,-4.1359030627651384E-25,52.128900372125194 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark05(-1.2371471643741443,-54.734822259338976,7.027879477464396 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark05(-1.2373987993558035,-0.3437930431804276,58.502503821986004 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark05(-1.2383108180366913,-66.54722034495862,-50.72701095788792 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark05(-1.238323808714254,-16.25237649583982,-31.696337724684966 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark05(-1.2388221689506291,-4.239146897062794,-1.5707963267948966 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark05(-1.238905485265608,-5.293955920339377E-23,20.73404870659305 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark05(-1.2390690865218594,-48.57141138466587,1.5707963267949054 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark05(-1.2390985062485065,-29.53913438696129,8.110035643220582 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark05(-1.2391024249601612,-0.6395833008435418,92.28189318949669 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark05(-1.2418561136630757,-0.12977889525918118,-62.184871172801756 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark05(-1.2422588978807567,-72.26442745242169,-44.497999298012026 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark05(-1.2426101890301613,-60.68784611171391,-4.141605963249664 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark05(-1.2441621234816882,-9.817760082449356,-4.9980326270961655 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark05(-1.2444812419641764,-29.737181463382708,-1.570796326794896 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark05(-1.2447785267277558,-66.87991852910324,-64.4306631486777 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark05(-1.244959374432683,-1.5707963267948966,50.73969118434068 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark05(-1.2450745591360217,-79.81591132818575,-22.728298593733356 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark05(-1.245356618101007,-86.51245035972819,0.0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark05(-1.2460628387707529,-0.01652506541688572,40.2067291346476 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark05(-1.2462170365794405,-0.9297351906057783,2.4601641955453935 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark05(-1.2470092336335326,-98.7485582646142,84.61358126834699 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark05(-1.2471744555124213,-72.3865063148654,108.76938929747087 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark05(-1.2480928858536942,-72.6286861862378,-87.52962828537407 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark05(-1.2483333046178438,-0.09620359270255463,9.98451374012852 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark05(-1.2487026345997663,-97.90993632908626,78.66848114990673 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark05(-1.2490761496458205,-3.8734836836074322,-40.84070449666731 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark05(-1.2492786458846135,-34.807664762789074,-41.033401727378745 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark05(-1.2498783603682964,-53.73626577539186,-6.283185314630188 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark05(-1.249903634672843,-29.3017033866343,-8.103981707245897 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark05(-1.2506927696568415,-67.30994631627107,6.958698238671137 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark05(-1.2508237441000214,-1.5707963267948957,-1.5707963267948966 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark05(-1.2511638295902168,-1.23493480097915,-4.407855664255263 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark05(-1.2518209707834695,-1.5707963267948966,55.91765133382107 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark05(-1.251878600882899,-274.8780283035217,-1.3157489055833465 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark05(-1.2520375080198818,-66.43307771779911,-1.0691058840368783E-50 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark05(-1.252453880661526,-28.937250312962966,-92.30777890522427 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark05(-1.2528327095863891,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark05(-1.2536941191332787,-54.061923002418325,-36.44182304014846 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark05(-1.253733331783644,-73.81229485501598,1.3783412956616714 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark05(-1.2538284353318063,-3.552713678800501E-15,-82.38614398849116 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark05(-1.2539385711701483,-17.050781480509215,-8.205313837594634 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark05(-1.2542195598059545,-1.5707963267948966,23.11184772401043 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark05(-1.2542534943548365,-85.01748414131815,78.58006624131806 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark05(-1.2546199462152758,3.142080934844615,-10.20780805674178 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark05(-1.2547317589919862,-1.570796326794893,-118.84591123990481 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark05(-1.254998693166011,-355.99385808253123,1.5707963267948966 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark05(-1.2552965591606977,-286.63418628144655,24.076808619310114 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark05(-1.256466131888918E-15,-1.5707963267948966,30.549917857641923 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark05(-1.2565630871313611,-66.3689861564309,-7.853981633974588 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark05(-1.2565935203734133,-15.762798908315336,29.5599912352632 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark05(-1.256727927116218E-88,-36.06953609041854,4.717541648502344 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark05(-12.575554846794802,-26.026601023699982,81.39938071659952 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark05(-1.2577193185790825,-66.73650735567504,-12.791948720009442 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark05(-1.2577748669214577,-5.551115123125783E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark05(-1.2587612790587457,-0.7399153970579244,49.9363791534451 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark05(-1.2590278757435351,-9.541359633998265E-4,20.420352248333657 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark05(-1.2594206628384252,-9.524316046098157,7.853983465336941 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark05(-1.259674774139631,-135.59376300160696,-27.05041940581126 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark05(-1.260033113614457,-1.5707963267948966,20.3313743102824 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark05(-1.2601012116027297,-79.54423365687197,-389.7619332786479 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark05(12.606223201583248,7.434321592212044,-89.55178907924216 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark05(-1.2616060765717126E-15,-72.45820274236235,-1.5707963267948966 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark05(-1.263028351856331,-66.28136817476957,-13.469526276739598 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark05(-1.2634213306647413,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark05(-1.2634920662350609E-175,-73.05306456677398,-77.54520884794256 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark05(-1.2636917824835225,-1.5707963267948957,-31.37294112398495 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark05(-1.2638523354014388,-66.33401458891464,9.19178006447071 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark05(-1.2645797065875892,-35.92618746312158,78.43783579351269 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark05(-1.2653343610442656,-1.513205081283559,8.104015926628836 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark05(-1.2661438910526261,-53.780633756498844,0.0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark05(-1.2666138977389263,-1.5707963267948963,-78.34822758950145 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark05(-1.2666872583501996,-0.3945433817806452,-157.328651539892 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark05(-1.267034857276901,-84.89830244767255,0.0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark05(-1.2678254738302452,-72.27389862510105,-44.05569693022011 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark05(-1.2682688121879102,-67.21287057679561,63.577150394968896 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark05(-1.2684771461822597,-9.608772813423855,38.60958026865648 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark05(-1.2691849731450398,-3.53206408622818,8.10398194973521 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark05(-1.2691959006843399,-36.103323279389784,-16.003684573843202 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark05(-1.2707418993423942,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark05(-1.2712947476932066,-28.720794430269038,-89.85486524509443 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark05(-1.2717108168087208,-23.211264569461733,-1.5707963267948966 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark05(-1.2730034058286324,-1.1493520986523302,456.72335993016895 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark05(-1.273174269901844,-53.44900655107397,614.1739947333692 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark05(-1.2733449210916394,-1.5707963267948966,4.142983225801499 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark05(-1.2735980158831557,-1.5707961840777198,-1.570792907370557 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark05(-1.2736519001965974,-22.116611795495754,0.02337065379464867 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark05(-1.2740377623349466,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark05(-1.2744204120382054,-1.5707963267948966,438.1484516224277 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark05(-1.2744528885816926,-1.5707963267948966,-81.13842789653586 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark05(-1.274798181378118,-1.5707963267948961,-56.92343786495748 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark05(-1.2749485277129902,-59.830245707446686,-54.72166985064456 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark05(-1.274954868375136,-22.35280561418159,3.2476612451088442 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark05(-1.2753056426181928,-29.12428096998849,-1.570796326794893 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark05(-1.2759940897696291,-73.19912518157885,49.72127990400563 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark05(-1.2762659248524029,-0.04056991423583606,1.5707963267948966 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark05(-1.2765081541737082,-59.72885284086217,21.49146862622864 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark05(-1.2769993376613504,-53.78793881316467,26.218206714709893 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark05(-1.2770154767302968,-72.34284813839287,-1.5707979408118593 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark05(-1.2770893181811698,-9.913453306477473E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark05(-12.775987014604766,-58.34192925387085,-52.42188097996121 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark05(-1.2794100558084378,-1.5707963267437512,-1.5707963267949054 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark05(-1.2796530994019635,-0.2552919014203381,18.857368436333854 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark05(-1.2799199092319586,-67.38654621077582,-10.377529431768949 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark05(-1.2800675400603292,-53.53435818325608,-6.289162435771888 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark05(-1.2803707910680135,-128.93228774875683,-22.02800925974591 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark05(-1.280427920214269,-41.57393078021009,-20.42037229799418 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark05(-1.2808788629698995,-1.1908806505961043,-64.13036227803062 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark05(-1.2811995840786414,-66.40213444016302,-75.97742330632613 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark05(-1.2812283062033978,-1.5707963267948983,-88.89230305575732 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark05(-1.2813331809171846E-144,-41.60091088499235,19.630705604549398 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark05(-1.281736998875922,-0.5707650726116672,-3.4569844072790623 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark05(-1.282099499814973,-3.141600282984449,-57.02253007217597 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark05(-1.282143767882475,-10.774552544188023,-5.499879559803247 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark05(-1.2845474254985274,-16.267832723952505,-68.04450119404319 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark05(-1.2851593689374212,-60.91210024916263,-1.2125571833349817 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark05(-1.2852088455036843,-1.5707963267948966,27.455663167294972 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark05(-1.2853794989310796,-3.2665926535897936,-37.45126172949143 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark05(-1.2856712287541188,-66.32440295802296,0.0 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark05(-1.2859830332213633,-1.5707963267948966,1.478341638478014 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark05(-1.2860821288564805,-4.422723941193567,-12.875441367899036 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark05(-1.2868374410784493,-35.72495614220959,84.77922171874782 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark05(-1.2871843914695609,-84.82300930607887,96.41243625825011 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark05(-1.2878548703568125,-1.5707963267948966,58.98596530780199 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark05(-1.287955594456691,-34.71949403342293,-0.21448892595791774 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark05(-1.2886597556655752,-29.092994296036693,0.2479230710506513 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark05(-1.2889095430704853,-3.992949860633851,-4.712414713336951 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark05(-1.2893714440829007,-97.91522628259531,1.3540530201588576 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark05(-1.289701561418775,-66.43716729147948,-28.248978018904268 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark05(-1.29027305047439,-72.51145876617127,-121.22915874260723 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark05(-1.2904774246786763,-0.14501469464814626,-29.8759192975022 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark05(-1.2906193768286145,-78.78644384994942,-63.49117002304884 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark05(-1.2907469891288212,-1.5707963267947154,-90.87108428133517 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark05(-1.2910760411268039,-0.5685915694599616,5.556896873712694E-163 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark05(-1.2916378164154132,-0.07810865796111349,-28.70353760847622 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark05(-1.2917174824503395,-1.5707963267948948,-7.853981714357105 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark05(1.29188574672186,53.566111909029445,-20.467657734892526 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark05(-12.923115365414887,-51.415484499554196,17.84156474849425 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark05(-1.2924697071141057E-26,-1.14471751534199,3.9753047289642525 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark05(-1.2924697071141057E-26,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark05(-1.292841411168855,-0.664180954118514,100.0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark05(-1.2934159503152927,-1.5707963267948966,-31.130617032114827 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark05(-1.2936710484612284,4.1415926535898855,-44.53418841576741 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark05(1.2943589108312528,-53.88627801041281,-15.913883226234443 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark05(-1.2951670302621887,-1.5707963267948966,-40.57252271721163 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark05(-1.2960482942206493,-3.1992062831753674,0.0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark05(-1.296140680211194,-35.386760039063546,-338.29006089484744 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark05(-1.2978227888683176,0.09574405409855646,20.431072252502087 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark05(-1.2979233558915269,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark05(-1.2981667154624368,-29.387326380550817,-20.530589216470112 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark05(-12.98792406011988,-26.626980260109164,-78.65956250301866 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark05(-1.2989084634989352,-4.638804691907334,1.5707963267948966 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark05(-1.3003624042241029,-1.0022170969341153,47.9528420867011 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark05(-1.3005727400660816,-0.7218013173649875,13.215191836275952 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark05(-1.3012127067917567,-53.70786173801106,0.0 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark05(-1.3025456912962605,-35.39716395637336,45.45760122793985 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark05(-1.303583158988982,-1.5707963267948966,79.54753034181738 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark05(-1.3037219819694659,-72.7536262345371,-77.35143479942516 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark05(-1.3037247936023795,-98.12393933368956,-223.06125964687152 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark05(-1.303988445517758,-1.5707963267948966,20.337846710680424 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark05(-1.304077109361149,-1.5707963267948966,12.683287877766482 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark05(-1.3044587140713935,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark05(-1.3063907618818096,-42.0847469704687,-1.5707963267948983 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark05(-1.306655293933833,-73.08105116289774,-1.5707963267947989 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark05(-1.3070902247585698,-1.5707963267951262,-31.73122550044281 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark05(-1.3074486787156565,0.33312607370073344,0.0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark05(-1.3079346574610469,-54.48320293620079,32.614551980474204 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark05(-1.3082173414248675,-1.5707963267930691,-18.948867862317314 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark05(-1.3082516430751046,-9.883251183329946,-82.03811548434643 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark05(-1.3086560587785518,-1.5707963267948966,-27.842327654716623 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark05(-1.3087914495879645,-23.55812954332349,-75.65810568138988 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark05(-1.3089950012135922,-1.5707963267948966,97.03969118484424 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark05(-1.3090895538463554,-1.5707963267948912,-16.300935174253027 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark05(-1.3091025235180156,-73.32628842317848,-528.2978906594185 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark05(-1.309200686128575,-0.6740800058667512,416.24703992315324 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark05(-1.3092497300717643,-66.50312356003283,-78.47124724123192 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark05(-1.3098218660276784,-0.9076355762604909,-15.153807618734334 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark05(-1.3107258346946962,-54.487434772778236,28.659348689905524 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark05(13.107605979656256,-24.86326663867527,-28.692692386605216 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark05(-1.3129798786414957,-41.00492793004489,-1.5707963267948966 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark05(-1.3134484105161344,-48.094088697717766,-90.32978697902556 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark05(-1.313452759165487,4.141592653641939,-98.49279159123556 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark05(-1.3146180274348631,-123.93927348775556,-62.37996378872405 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark05(-1.315374573397769,-10.032960595277814,267.03536783504853 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark05(-1.3154288023840448,14.431294232003957,19.56769885824623 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark05(-1.3156726135669141,-1.5707963267948966,14.525624255555242 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark05(-1.3158567279419149,-0.6073084426407445,55.179493159778076 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark05(-1.3170839781351313,-1.4751258910522829,-100.0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark05(-1.3170874343298817,-0.1520549359604445,78.07297765275585 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark05(-1.3174256315960924,-3.406847619119856E-16,-75.90383484008167 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark05(-1.3179677646772243,-0.7596701288888678,-91.44361654890838 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark05(-1.318433394133561,-72.46815334748894,1.5707963267948966 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark05(-1.3184517755614662,-72.78516149297185,-17.876236438237406 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark05(-1.319061463958395,-41.300080411769684,0.0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark05(-1.3191617544319434,-1.5707963267948966,16.985260784694898 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark05(-1.3192524837177222,-54.138343546479376,-19.26567550778004 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark05(-1.3198184055991269,-3.149167107990536,-55.2995793032947 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark05(-1.3199504855930686,-28.877648071917704,-1.5707963267948966 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark05(-1.321270352917516,-10.349928291014365,-21.86231386067564 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark05(-1.3214156948736582,-0.014254926931883127,-5.141592683135905 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark05(-1.3215618094396935,-47.63548421451651,-19.594950187127353 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark05(-1.3219320122960097,-0.2681766885072673,-66.18312025989067 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark05(-1.3228176536645624,-66.3489050709076,60.521377773927924 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark05(-1.323302251939855,-9.611040129788062,-59.69123701558978 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-1.5707963267948966,-10.994299845244942 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark05(-1.3234889800848443E-23,-85.03413774403008,54.41351432231917 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark05(-1.3235273697830515E-17,-1.5707963267948966,19.349847640955257 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark05(-1.323533514353862,-0.2083663026660558,78.28846003234572 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark05(-1.3241675000658215,-0.06218334694283347,65.98139879671353 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark05(-1.3245417478879231,-1.5707963267948966,-15.329477108656704 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark05(-1.3246738167472927,-23.13449199818895,-94.79464698577453 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark05(-1.3253721933357756,-1.5707963262290399,-15.530527309344858 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark05(-1.3254107698542512,-60.696335973336716,-57.04253981731969 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark05(-1.3262998614286137,-67.25382437242665,-242.6530210216745 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark05(-1.3263691426036637,-104.72039327705306,-83.25242550428489 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark05(-1.3264592703795586,-1.5707963267948966,71.35061549409986 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark05(-1.3269248901300514,-48.182628286009255,100.0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark05(-1.3273370625838115,-22.403349626486367,55.43807080147466 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark05(-1.3281306618041757,-1.5707963267948966,90.86933614357719 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark05(-1.3283513789991446,-9.626925094678962,84.0904622952269 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark05(-1.328459566666806,-79.24556006405207,-80.27395963095036 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark05(-1.3287536061231595,-40.852875068760234,0.0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark05(-1.3290726928484802,-54.88431998552623,1.5707963267948966 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark05(-1.3291128871502487,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark05(-1.329441214970226,-3.1415930387613606,0.0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark05(-1.3306124500025471E-110,-41.726663290729185,-85.13934483089793 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark05(-1.3315463873857165,-4.141592721704024,-22.21485879068605 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark05(-1.3318585053667307,-72.7226529271462,-8.103981635485233 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark05(-1.3325174746347415,-41.0544334522172,-84.70131620273739 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark05(-1.3330033126478704,-1.5164583404138203,-1.5707963267948966 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark05(-1.333080781314493,19.79072141832185,73.36984774236609 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark05(-1.3337643911549923,-1.5707963267948966,26.80398501342502 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark05(-1.3341846704032854,-122.8351269267451,-12.79208045187184 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark05(-1.3351367654773039,-48.27116503898641,-71.28234578493223 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark05(-1.3351402160077765,-98.63705776942193,0.0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark05(-1.3356939286783147,-1.5707963267948983,-0.16536319521006337 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark05(-1.3362997599000896,-54.50678364363532,43.410794950705025 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark05(-1.3363270211001086,-72.39501236939302,20.70500138970148 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark05(-1.3365485477570251,-66.25417620162135,73.51887292133685 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark05(-1.3371782310749183,-3.1895086323147543,0.0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark05(-1.3372338810504374,-48.02898627607699,-84.61894683349315 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark05(-1.3373896412847333,-66.37177672041102,-3.1494056287040566 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark05(-1.3374631881440706,-20.32976141902914,-78.14994155629685 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark05(-1.3377257327448504,-66.28850725950703,0.0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark05(-1.3377559451186696,-54.81809073686272,-14.42973973370632 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark05(-1.3378912528876374,-0.2847347243460103,91.76753101745435 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark05(-1.3381847022733566,-48.67980979875961,56.43846499765462 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark05(-1.3382588943251323,-136.26727759331047,44.486679707633726 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark05(-1.3383938351672475,-95.54781502009423,-74.44065891107398 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark05(-1.3384596365677488,-3.266711165162673,0.9670465530847 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark05(-1.3385961393046806E-5,-73.38600095237638,-20.436048075662068 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark05(-1.3394284238197813,-0.7081436261613486,20.81686224058339 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark05(-1.3396853094661003,-1.5707963267948966,6.308628457912233 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark05(-1.3399668715220603,-174.14603691168685,16.701185626276867 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark05(13.419363734379047,-55.14080481519543,-14.147178607635098 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark05(-1.3420093796283972,-92.57595665189197,9.860761315262648E-32 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark05(-1.3428091247763025,-4.440892098500626E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark05(-1.343904699713001,-42.050973294815805,3.1416236125957817 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark05(-1.3442330780401976E-18,-1.5707963267948966,0.24853009992130873 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark05(-1.344486835688774,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark05(-1.3449843444550806,-15.794394783558218,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark05(-1.3451788933577769,-66.42959871132967,84.59051282222454 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark05(-1.345456052830471,-1.5707963267949054,-90.95988469682798 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark05(-1.346094881873512,-7.105427357601002E-15,88.3486188474223 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark05(-1.347284321646745,-1.5707963267948912,61.535552878832334 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark05(-1.347322988213987,-66.34306676387335,1.5707963267949054 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark05(-1.3483698099296182,-0.5835767143859831,-1.5707963267911704 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark05(-1.3485438616776833,-22.406351149963832,-63.90164626052404 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark05(-1.3485445448815145,-4.030738548236215,-84.79122074469574 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark05(13.498924735079882,1.464318621813419,-93.07527152383432 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark05(-1.352165597556952,-0.6958896903838898,99.40542607004913 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark05(-1.3523377285600588,-0.029856890871629085,90.6568850956645 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark05(-1.3523803890136605,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark05(-1.3524337055710172,-2.7755575615628914E-17,3.266592653615535 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark05(-1.3528076620411025,-17.0949204315408,-43.98976639519633 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark05(-1.3537639536976211,-1.5707963267909446,-1.5707963267948966 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark05(-1.3543805973445708,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark05(-1.3550917306836006,-0.22115708953904073,0.0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-1.5707963267948966,72.25663153330972 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark05(1.3552527156068805E-20,-21.993062902310754,61.42544991621385 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark05(-1.3552527156068805E-20,-60.49281017203618,-0.8280940593579152 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark05(1.3552527156068805E-20,-79.00201711923395,55.395284046824486 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark05(-1.3554820934158143,-3.3744689625054605,-173.40811081913523 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark05(-13.556092322175118,-16.48400432827451,96.92258000651168 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark05(-1.3561596146810833,-9.950670723492337,-21.880803229851395 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark05(-1.3565262969913836,-1.5707963267948966,31.68608453413303 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark05(-1.3566206262515426,-59.97309276395411,1.5707963267948966 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark05(-1.3570053882939683,-67.49038620816373,-163.80795011255773 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark05(-1.357462258748697,-16.117453799147256,604.3323483430789 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark05(-1.358982201727945,-3.14354604004866,-48.70162184105305 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark05(-1.359248517261758,-0.040195805157764095,-55.60895117198292 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark05(-1.3593616864265516,-1.562506308446595,5.51858390310143 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark05(-1.3607356477005268,-79.92626815478673,-135.63885714802745 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark05(-1.360844095464521,-85.75534293733229,89.26779395187603 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark05(-1.3608985166774437,-35.479547297315975,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark05(-1.361213389417357,-3.2980441793867055,6.283185559923007 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark05(-1.361251992339486,-2.220446049250313E-16,2197.975175268025 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark05(-1.3614020791851957,-1.5707963267948948,111.68425359702366 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark05(-1.3614641228575455,-110.41870591028714,4.712393488119349 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark05(-1.3615908289657763,-47.717399118817205,1.5707963267948966 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark05(-1.363757314918853,-0.3797962732769249,8.327351786923103 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark05(-1.3638377562229933,-66.35783923686192,33.389658153182594 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark05(-1.363894599686757,-98.64301202205104,49.94013351629437 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark05(-1.3639831144444425,-1.3694320839502545,80.4153920003966 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark05(-1.3642494669850502,-16.02497739018483,-49.90956983373826 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark05(-1.3649001560271004,-1.5707963267948966,-1.5707963267948486 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark05(-1.3649875349765415,6.436958620552496,5.14259856855599 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark05(-1.3651144847975798,-0.11610694640273878,78.2947989812674 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark05(-1.3652625095303028,-1.5707963267948966,77.29361684389968 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark05(-1.3652749457873572,-1.1102230246251565E-16,0.5010667806747053 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark05(-1.3652877110299486,-1.5707963267948966,50.70317197143842 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark05(-1.3656832179130394,-3.141768547672885,-42.59658793764888 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark05(-1.3658126396961545,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark05(-1.3660090384218653,-41.08054802095287,-56.475051875888326 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark05(-1.3663619174348582,-1.5707963267948966,3.283629441038701E-288 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark05(-1.3677982699537026,-92.3404536195008,-112.86034661808725 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark05(-1.3683792474448804,-1.5707963267948966,-24.104441009377567 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark05(-1.368655668443854,-135.48096963215696,-102.10176133059787 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark05(-1.3687290303554476,-0.4485048664516332,-1.5707963267948966 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark05(-1.3688271544619386,-3.142084557046109,1.5707963267948966 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark05(-1.3688772982568012,-47.24767569145128,1.5707963267948966 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark05(-1.3690452451245254,-34.667451171965624,-76.03815264848498 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark05(-1.369065261328501,-73.81375338183675,-53.45598985400517 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark05(-1.3697539049483058,-53.54056950779965,-1.5707963267948912 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark05(-1.3702195098006376,-79.74810419017703,-76.80339335236688 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark05(-13.703519324342793,-91.5508304579496,47.50937419655256 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark05(-1.371486899210792,-0.9697728045644692,1.5707963267948983 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark05(-1.3714962356093305,-1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark05(13.71709260603265,69.55734437197546,-33.15392201314941 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark05(-1.3719628344865862,-41.69835726462499,-40.5463256785862 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark05(1.3720336204733792,-3.151638003945004,-28.48117576968224 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark05(-1.3727554871299463,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark05(-1.3730943370699875,-1.272712066173996,-14.938671356436942 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark05(-1.3732155223960056,-1.4377312943813791,-1.5707963267948948 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark05(-1.3742473525089478,-66.1576791956789,0.0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark05(-1.3746727687687863,-16.490515581090506,-27.12978457405381 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark05(-1.3748483752188339,4.141592653589794,-94.26227567181684 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark05(-1.3749497565139865,-0.6486569115316171,4.712388980773862 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark05(-1.375326356663718,-0.6582732670862783,-21.64183778265084 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark05(-1.3758948550107883,-0.04695190914546141,90.81546192607351 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark05(-1.3761122387643758,-0.3601271602300375,-53.43658554117104 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark05(-1.376745413034151,-73.17557236144751,25.797607458917263 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark05(-1.3767835798376922,-22.153675073018857,-65.19488817289917 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark05(-1.379165604629086,-41.44932832390775,-1.5707963267948948 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark05(-1.3796926698350707,-549.8957887407514,-26.339983931586957 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark05(-1.3813398262580663,-1.5707963267948966,20.612463269750208 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark05(-1.3815617539803968,-1.5707963267948966,-38.5243991571757 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark05(-1.3823059984477741,-72.42265084140016,56.548662466590855 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark05(-1.3826446281382938,-1.5707963267948966,88.57000354944819 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark05(-1.3827044016592893,-1.570796326794896,-3.9168593937374396 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark05(-1.3831707129837483,-1.5707963267948983,6.585768184429824 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark05(-1.3838869939555647,-1.5707963267948966,89.33814186084655 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark05(-1.3841618078721263,-79.16195014150418,14.621157479690694 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark05(-1.384933783923681,-8.673617379884035E-19,0.13289264270869805 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark05(-1.385104931449488,-97.42234334207352,95.10197858691458 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark05(-1.3853224683546819,-1.5707963267947918,54.59884598828269 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark05(-1.3853513564343392,-0.4357878681354904,40.289215086350836 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark05(-1.385498019356044,-0.09697712839907259,0.0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark05(-1.3860947742407401,-1.1518470651164927,-1.6822925872262289 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark05(-1.386152911125862,-98.59692903057731,89.20898063270882 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark05(-1.3864394127906365,-47.128042795120265,76.26728509985671 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark05(-1.386539071315518,-1.5707963267948966,62.85127079449281 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark05(-1.3870165737792484E-17,-48.69468613063442,-1.5707963267948966 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark05(-1.3873399811923701,-35.435563594004066,3.042595380093963 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark05(-1.3873645142233542,-1.5707963267948966,44.70128330963563 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877098903332248,4.141592653593512,-1.5707963267948983 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-22.086296874583145,-83.0123055302354 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark05(1.3877787807814457E-17,-4.485868679818324,-42.92555826360825 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark05(-1.3877787807814457E-17,-86.3937979737164,-1.5707963267948966 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark05(-1.3879170169858408,-122.55259942527525,-40.84073075954394 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark05(-1.3879915402782859,-9.977802900527955,-78.16243407500497 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark05(-1.3886325493767087,-72.30435525451358,-27.105534554677305 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark05(-1.3893232474192798,-23.059220187177473,-938.291114290205 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark05(-1.3908015359179946,-4.141592711591681,0.0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark05(-1.3912126764566248,-28.451009263281033,-1.5707963267948966 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark05(-1.391278981377269,-1.155179527268558,62.83185307179587 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark05(-1.3915364819630531,3.3881317890172014E-21,66.518015175439 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark05(-1.391570745754057,-53.9647743200115,-268.57617649902534 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark05(-1.3932864701749113,-707.0638148797111,-21.987047996489622 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark05(-1.393456737895571,-1.570796326794893,0.0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark05(-1.3936714721077974,-4.141592653589794,-100.0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark05(-1.3940692498819072,-1.5707963267948912,16.27757503478611 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark05(-1.3944379003067868,-54.82688110155685,3.248565551764031E-114 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark05(-1.3944786224199428,-10.356249119036875,1.433212624845205 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark05(-1.39533010841965,-1.5707963267948966,-0.27948176147861803 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark05(-1.3960646943831188,-10.802228701462823,-4.152649134228247 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark05(-1.3964326383699126,-3.141604659843171,42.54577411537292 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark05(-1.3968009393752254,-48.05510918730063,-53.70380591465624 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark05(-1.397169469273635,-98.43890348216298,-84.0187386964642 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark05(-1.3972481175208382,3.1415926535897953,-51.003964732023654 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark05(-1.3974148824294899,-0.36974714101648065,3.1435761899658763 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark05(-1.3974945766391496,-10.331118770819984,30.32857609395853 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark05(-1.3975409421881115,-9.989429543254104,1.5707963267948966 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark05(-1.39784236327692,-130.13218948142128,-51.21391451446846 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark05(-1.3986147602025762,-1.2295560726864943,-87.58182423000197 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark05(-1.3987725816957726,-0.5593213123527107,20.61611113213364 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark05(-1.398794311629278,-0.2465361007902344,6.533185638408489 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark05(-1.3989643369669345,-72.84494328708006,-1.5707963267948968 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark05(-1.3993755879235517,-1.5707963267948966,-13.1573433623591 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark05(-1.399521843181229,-55.25935514695532,-6.382370267125638 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark05(-1.3995252105385785,-66.41240638430413,-4.712389069205245 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark05(-1.4000762683976127,-53.67899172251499,0.06365328063973907 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark05(-1.4014515600837727,-0.0383079394903314,-34.84306721886887 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark05(-1.4015497878801453,-9.424777960769381,-53.29552971669208 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark05(-1.4016526265320406,-3.141600408115045,84.52516942283833 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark05(-1.402269527247313,-1.5707963267947989,-25.348684233491568 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark05(-1.4023384787871742,-22.413736076066364,0.0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark05(-1.402533767389037,-47.12388980384693,95.73075498523242 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark05(-1.4029625526563905,-1.5707963267948966,1155.0467317131636 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark05(-1.4030391891293839,-66.09622428002686,104.45306063926921 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark05(-1.4032761330893384,-0.29256060027055253,-9.497398334762918 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark05(-1.4034979709061446,-91.76095532951358,-31.223859299561994 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark05(-1.4035170918015936,-0.364216570372334,34.54831904487739 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark05(-1.403580632072182,-15.977793720198363,0.0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark05(-1.4037774814877897,-54.384320699652115,-0.20826496702931296 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark05(-1.4042475272009587,-1.5707963267948961,-57.08103577739666 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark05(-1.4043507286993493,-1.5707963267948966,73.78065409417337 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark05(-1.4045319675694614,-98.74279907396892,-27.830273823039192 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark05(-1.40532070452827,-16.07774274768647,15.630813128242648 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark05(-1.406321224824849,-0.287084527056238,-27.03177645200547 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark05(-1.4063606887845286,-1.5707963267948966,72.4112488324407 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark05(-1.4064198945813537,-85.43701930666401,1.5707963267948966 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark05(-1.406952229216065,-1.5707963243713678,-60.299952151801705 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark05(-1.4070159543423173,-1.5707963267948966,-0.35433112494090047 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark05(-1.4071549998564739,16.72008139590423,-100.0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark05(-1.4072208327937705,-35.50409539261972,55.18306798610229 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark05(-1.4074590677815702,-0.9693661192543899,-15.335967636546098 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark05(-1.4076708568888314,-1.5707963267949019,59.5451717121631 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark05(-1.4080290028632763,-0.8138375939709974,-10.565584634307392 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark05(-1.4084310826866777,-66.53323474248636,-1010.9353100424368 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark05(-1.4085416918739349,-1.5707963267948966,0.29278678058687135 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark05(-1.4085806257286275,-91.65100700031168,-1.5707963267948966 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark05(-1.4085982354335855,-4.606559923302502,-1.5707963267948966 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark05(-1.4086873555979593,-0.5468652759988658,1.5707963267948966 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088053632820916,-98.12081880183776,60.3703335618246 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark05(-1.4088437818443817,-1.5707963267948912,77.46949637476988 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark05(-1.409061567558153,-22.42204615405882,-67.17963211856693 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark05(-1.4100953543671528,-10.260680403961885,5.141593728076264 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark05(-14.1166647481096,52.466572446591584,88.4240899925278 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark05(-1.4127684895934678,-84.8477426482286,-68.50996000439409 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark05(-1.412806174255703,-98.21641428778354,89.75373978254666 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark05(-1.4128485044340178,-3.2669625671586484,74.63736703086931 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark05(-1.413122527599817,-0.41267752948719144,-25.742011864632858 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark05(-1.4132882568102034,-0.8342283644148125,-1.5707963267948966 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark05(-1.4135560428505232,-9.792385325740348,-32.70817096752984 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark05(-1.4139304862435007,-42.216610186009,38.53876864095284 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark05(-1.4141450903374633,-22.383535510994015,-25.982316909663552 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark05(-1.415007254717063,-600.4016461429362,-50.53628315919549 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark05(-14.15223651739879,-59.48652649835804,-94.78155583432577 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark05(-1.4152651756268175,-0.5692032068797511,-30.608569333477135 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark05(-1.4162415034026836,-53.96859633181088,-0.06456175973679193 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark05(-1.417371839455193,-0.37895525773738736,-15.238102193073097 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark05(-1.4179000791561642,-79.7808846543399,-396.39737739524696 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark05(-1.4182384641127186,-18.73130052079992,-25.59211982011307 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark05(-1.4183771620107795,-0.2814608889803054,-56.25496220482169 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark05(-1.4187369455738015,-36.032322082116885,-37.83060384505029 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark05(-1.4189281916374246,-0.6886318639754734,-27.752447378048842 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark05(-1.4191075038556085,-60.102702874891655,-6.24893133829347 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark05(-1.4191550391590662,-4.344286639591205,-895.353792446636 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark05(-1.419221787237146,-60.410775876060654,-92.48710365196446 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark05(-1.4193137740573356,-35.10013903394764,-4.712389046119379 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark05(-1.4194223115906146,-19.509551735960013,-107.13116212627033 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark05(-1.41996396275157,-97.7909462921596,82.1052472048248 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark05(-1.4199780155760855,-0.012007726930583898,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark05(-1.4202414384635484,-1.5707963267948966,58.929592667637166 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark05(-1.4204806102603342,-0.12655563536735515,4.970231943007396 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-16.01138743887946,13.266776566102564 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-179.54578161134953,-2.730983159476707 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-67.35174517413517,-24.36374141317424 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-73.31624686421759,-1.5707963267948912 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-86.34637581482372,-42.12166748466133 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-9.442048749704696,-1.5707963267948966 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark05(-1.4210854715202004E-14,-98.16623458163673,-26.44062534543285 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark05(-1.4221428094423476,-16.232770671703207,-26.98818044828724 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark05(-1.4223870732283854,-1.5707963267948966,-76.19518969274267 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark05(-1.4231323359916184,-16.37822021743662,-37.98152967624995 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark05(-1.423756180196646,-72.41845556804842,66.18413796881106 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark05(-1.424602577857161,-4.142177295806871,-209.41515559073272 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark05(-1.4255258646217897,-0.824491805967845,-1.570796326794897 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark05(-1.4255366913730123,-1.5707963267948963,69.38036538899942 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark05(14.256172054265619,-20.490476178692504,-77.47886217980513 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark05(-1.425853020079848,-1.5707963260992792,1.5707963267948966 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark05(-1.42639902959259,-65.979670526087,-100.0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark05(-1.4267148948853912,-41.45820708602372,-42.63570678992558 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark05(-1.4268609938126786,-1.5707963267948966,-1.0346002810072532 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark05(-1.4280469253272192,-10.591489764795739,1.5707963267948948 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark05(-1.4281981354783397,-9.800785134495145,-20.66550415400946 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark05(-1.4282255192956481,-1.5707963267948966,-26.025841527478804 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark05(-1.428967326141305,-4.591479751976851,31.415926535897935 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark05(-1.4289978594109392,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark05(-1.4301579901203483,-1.5550702968154302,84.74061276999007 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark05(-1.430702786155976,-1.5707963267948966,31.91222111169839 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark05(-1.430711658275684,-48.39529369755113,-96.70915355279786 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark05(-1.4319505845963132E-14,-1.5707963267948966,21.991288369341756 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark05(-1.4322099615226973,-38.74369185909457,0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark05(-1.4325525361667824,-0.003330816310924181,5.141592654154756 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark05(-1.4327154069913783,-47.30369900675182,-1.5707963267948974 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark05(-14.327820766001963,76.76521865022005,30.0635294028273 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark05(-1.4328017409413263,-1.5707963267948966,3.1420809773114144 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark05(-1.4328898859417951,-85.72017369961756,-384.8450116066546 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark05(-1.4333397468740334,-78.96267991914954,138.2682705460982 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark05(-1.433857848395699,-1.2713650534701917,0.0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark05(-1.4343687197402273,-4.063901344541506,-133.79588902829556 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark05(-1.4348315583962696,-1.5707963267948966,-76.67554395711132 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark05(-1.435051321137057,-0.32998782080127054,-38.404763974127995 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark05(-1.4355346512011922,-1.4381337426382856,54.52439409669883 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark05(-1.4359980596079962,-66.23079972426609,-3.1435457790643038 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark05(-1.4362576177200599,-47.391722158156846,-34.55751919837804 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark05(-1.436343201756332,4.141592653851114,-82.19168094667972 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark05(-1.4363826521677083,-29.19711797133435,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark05(-1.4367106691068037,-1.5707963267948966,43.41405715216881 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark05(-1.437091504607733,-98.59403979559946,1.5707963267948983 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark05(-1.4376402538862796,-3.351811922578875,-56.58225584582928 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark05(-1.437766228446908,-1.5707963267948966,-20.307373518995064 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark05(-1.4378815167476628,-4.132327215962363,20.27581043042825 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark05(-1.4381901432033495,-73.47069144046864,-31.458576755113683 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark05(-1.4383939354744095,-0.020619254295918932,1237.2211706039025 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark05(-1.438455873667272,-977.8828366689785,-43.20290479414781 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark05(-1.4394028254099155E-5,-1.5707963267948966,84.82300164695471 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark05(-1.4411862082731455,-3.2665926535945826,-42.28977158974706 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark05(-1.4417883579331778,-53.96080368772519,-12.557332762496412 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark05(-1.4417964345672196,-3.1416067243061705,0 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark05(-1.4418732427434265E-12,-0.9963540932053938,147.53428488819983 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark05(-1.442264599771172,-1.5707963267948966,47.322038040805886 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark05(14.429203861384153,-67.32427668807466,-20.890978444305485 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark05(14.429203990089448,-4.763586316866378E-31,-100.0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark05(14.429205246252828,-3.694942603042623,0.0 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark05(14.429205384142612,-1.5485908112076625,-1.4238019547269463 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark05(14.429208913702617,-91.68146347705222,-1.5707963267948966 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark05(14.429209308282296,-0.19644435555325981,-53.596500075439614 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark05(14.429213029545302,-1.5707963267948966,91.39462127363386 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark05(14.42921701591905,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark05(14.4292297509405,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark05(14.429235369333206,-6.162975822039155E-33,29.820253941201226 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark05(14.429306396423485,-1.5707963267948966,-69.7875356062114 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark05(14.429319590933474,-1.398428961600693,0.0 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark05(14.429354898246267,-0.975362800681225,-57.721334145647035 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark05(14.429471415998819,-0.47858865068526557,47.94189190574866 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark05(14.429474667861534,-0.42361448811915314,88.3067358454109 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark05(14.429512497623925,-22.198005218548037,-28.716672581223797 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark05(14.429736511246986,-0.11709530852584432,72.63491172659496 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark05(14.429975096066052,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark05(14.430231485090694,-3.169855113948584,-53.19466261330184 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark05(14.430572207117372,-34.59193591465327,99.21529020424809 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark05(14.430742114866995,-1.0842021724855044E-19,0.0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark05(14.431229660531649,-4.109647769147102,-117.85778807346131 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark05(14.43148455062925,-1.5037724080933688,76.86040085641443 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark05(14.431578351885214,-3.2700894294956253,1.5707963267948966 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark05(14.432098909454865,-85.27793632448304,-100.0 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark05(-1.443242297116576,-0.541953881337428,12.568433067254075 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark05(14.433360744929196,-1.1001715011039788,0.0 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark05(14.433742990875743,-1.5707963267948966,61.166239250150554 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark05(14.437869667128481,-1.2142897834090658,7.85654009101482 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark05(14.438654711543734,-10.649609188863224,-50.005481837454546 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark05(14.440354724529854,-0.003869811109114223,-164.8383075691725 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark05(14.441272185065827,-0.8196348172631877,-29.630772048525888 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark05(14.441774729395874,-97.42602979491743,28.57401596171306 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark05(-1.4441951515828786,-0.22651879828152893,-61.91483533017084 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark05(14.444700996332806,-7.441852320348064E-9,-161.74399787137662 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark05(-1.4445118079429875,-1.474429718420996,87.27544695746329 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark05(14.457363643682108,-3.1416576513449574,-34.063130164874266 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark05(-1.4457715441207086,-1.5707963267948912,38.73783492846921 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark05(-1.4459059749317325,-54.44204407357446,41.95753517644001 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark05(14.46435233726033,-1.5708014519425888,149.15719054884207 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark05(14.467220060224733,-1.0898584509747566,7.870699172664545 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark05(-1.446941279602907,-1.5707963267948966,58.573995872824526 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark05(-1.4471153040563465,-72.85353881920491,45.312461595948605 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark05(-1.4474007465792817,-42.17348818790352,100.0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark05(-1.4477117920267106,-60.4514878544193,-0.052458815583576464 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark05(-1.4477864665391564,-0.4942841062976685,-66.17260564610905 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark05(-1.4481969218006696,-85.07687201229191,0.29203252434643495 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark05(-1.4482721414438688,-72.28854930796427,-4.14164969867176 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark05(-1.4483054617552613,-4.532664190833339,477.91990988954035 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark05(-1.448503226979256,-1.5707963267948912,-26.926560932254496 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark05(-1.448666710179732E-14,-1.5707963267948966,-84.55297863710399 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark05(14.486672367430756,-135.32421536590164,-41.56292863072412 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark05(14.492295568015464,-135.2629065478614,0.0 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark05(-1.449721724015246,-9.82783475377151,-45.426358995404364 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark05(-1.450139650611152,-35.89704347223125,-11.550928351730956 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark05(14.508456967699942,-34.91591504239202,-1.5707963267948966 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark05(-1.4510610319777646,-53.7638010235988,-181.0509936809009 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark05(-1.4512154455048107,-1.5707963266537293,-42.87546424319009 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark05(14.527246391045367,69.5162643502428,30.577805280101018 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark05(-1.4529634417377053,-54.730415089702596,-135.22653492609894 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark05(-1.4529946164541274,-155.4385980878115,-0.03744436671183214 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark05(-1.4532502860593304,-66.60149658159384,-6.754116162984035 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark05(14.534033504181252,-23.322419971446944,-3.1659260659492294 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark05(-1.4537455650037825,-9.488522817495042,32.397528832984506 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark05(-1.454935925437729,-66.13088769183403,-56.76429969646075 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark05(-1.4549794252749393,-66.66023499114891,0.0018060147788302834 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark05(-1.455287757880371,-79.62841101601543,-98.96574888077274 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark05(-1.455503142557944,-3.199226951102217,-48.71834901012852 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark05(-1.4558118445235948,-48.53740561978475,-686.0726388228674 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark05(-1.4563679250444626,-1.5707963267948966,-0.02826493247608803 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark05(-1.4571119163353132,-1.5707963267948966,-23.130065560866534 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark05(-1.4576087423531703,-72.47046128423258,-6.28320056596865 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark05(-1.4580710274848703,-9.425287798904858,0.0 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark05(-1.4587442188625077,-85.56722002990892,-58.80976952858807 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark05(-1.4587762780523659,-0.0034373042313749027,1.5707963267948961 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark05(14.589009241186865,-0.7479884037710173,0.5993847598232674 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark05(-1.4589763798078053,-42.04012090957774,-3.1494052275584945 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark05(-1.4594853391961868,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark05(-1.4596233462592374,-72.94998968720779,59.443120815758355 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark05(-1.4596342659748944,-9.979386756622352,-3.1435458164052323 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark05(-1.4596905200523955,-0.014697857175113294,25.667662546657937 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark05(-1.459998177527947,14.429879557536339,-8.104394319742731 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark05(-1.4601884401300391,-35.72992830829665,-144.0443755982486 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark05(-1.4602544168022842,-91.10670956435659,-28.34986893512999 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark05(-1.4603825301405493,-0.45252772860202484,129.20481498697853 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark05(-1.4609929403654376,-85.58498396496515,-0.23735879507370916 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark05(-1.461626048812247,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark05(-1.4616566392559756,-92.54806064669972,-189.9146803303254 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark05(-1.462086963675358,-1.5707963267948966,67.06530467900018 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark05(-1.4621085786757337,-54.27480061929386,38.04043372780478 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark05(-1.4624686037473775,-47.24653843696274,0.25782465736192156 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark05(-1.4627930219179601,-1.5707963267948966,4.71236969789984 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark05(-1.4639953933665055,-0.17418115864987987,71.6298722368406 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark05(-1.4644046940470057,-141.70711981992906,8.103982045471291 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark05(-1.4651031004459043,-142.2771312341096,-89.0766817297672 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark05(-1.4653019323348346,-53.57526721671384,1.5707963267948912 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark05(-1.4653178613224465,-1.5707963267948963,-1.2950682110092988 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark05(-1.465825083324728,-17.19588946089118,81.6892215669747 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark05(-1.4667454059356413,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark05(-1.468266738477224,-10.61288698521538,-37.78444995517847 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark05(-1.4685040301491528,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark05(-1.468941254683756,-40.89384004155465,-93.72667828048318 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark05(-1.4690159298483483,-41.636068074287486,8.64270704297184 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark05(14.693512375619548,-79.99603707407735,95.05864036388957 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark05(-1.46997896037613,-1.5707963267948983,-29.69185026679186 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark05(-1.4700948699188818,-1.0090689481836874,-0.999706691404189 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark05(-1.4704368395818601,-17.026970425689015,1.5707963267948966 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark05(-1.4707315729511663,-72.4183721664697,-48.79061450142431 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark05(-1.470839162484098,-78.92613532386194,-1.5707963267948912 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark05(-1.4715305949166975,-28.274333912530484,-7.810446165686392 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark05(-1.4718263307581383,-66.51743991712704,6.283185784021314 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark05(-1.4718546387247269,-1.5108863307255314,-2.0111356008875307 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark05(-1.4723217561729243,-54.21357418141057,-59.47859957273074 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark05(1.4723495046462474E-19,-1.5707963267948966,-56.94375979880641 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark05(-1.4726498230395844,-1.5707963267948963,-25.648472659791654 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark05(-1.4732953000918152,-53.42028760226507,-162.72220259623998 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark05(-1.4738804502962894,-3.266592655289821,1.5707963267948966 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark05(-1.4739534462335087,-1.5707963267948957,8.347176575199729 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark05(-1.4739943828103215,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark05(-1.4747296637276577,-3.733256411647246,-14.863161999766838 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark05(-1.4752454576235312,-47.88170909155012,-1.1754943508222875E-38 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark05(-1.47588727775115,-72.63232819461855,-718.9999896566819 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark05(-1.4759152354940959,-41.67534661513861,0.0 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark05(-1.475916118041264,-1.5707963267948966,-9.795679010261296 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark05(-1.4760757979664405,-1.5707963267948966,-28.300447051300747 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark05(-1.4762325816090334,-1.5707963267948621,-1.5707963267948966 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark05(-1.4771728316119763,-15.73467067494536,-32.54132029740022 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark05(-1.4771786806582146,-3.7102350224140963,-24.44246271963611 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark05(-1.4772263201696618,-168.05096687720214,-72.48771132444399 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark05(-1.4773001848153895,-1.5707963267948966,96.14245912502419 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark05(-1.4783257686877882,-54.758990613226025,-0.5132398843778379 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark05(-1.4785296379630775,-0.5587630192126491,-4.712389079395715 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark05(-1.478579194397416,-1.5707963267948966,3.141592653590329 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark05(-1.4787205965217434,3.1420809348398175,98.11374152548022 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark05(-1.4787351557257864,-1.5707963267948966,32.85228355781402 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark05(-1.4788517590546055,-1.1102230246251565E-16,-1.570796326794896 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark05(-1.4792084333417446,-4.563395209233567,-20.958777553177825 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark05(-1.4792283980000032,-66.52474937567756,42.83307250909701 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark05(-1.479459469156343,-3.149405155172878,-0.14917047538422623 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark05(-1.479666142876983,-35.02612698983285,1.5707963267949019 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark05(-1.4807435285896084,-1.5707963264565656,1.5707963267948983 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark05(-1.4811506053722352,-16.061273165701795,1.5707963267948983 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark05(-1.4812503730580535,-1.5707963267948966,63.77771119065261 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark05(-1.481438696207847,-1.5164791818658865,1.5707963267948966 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark05(-1.4815877905748907,-86.20105025787969,6.283185359389503 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark05(-1.4816614796406302,-35.3729085198899,-22.494009576225736 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark05(-1.4823032208586688,-1.5707963267948966,44.25650064218697 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark05(-1.4826042754944893,-1.5707963267948966,58.379460677127305 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark05(-1.4831000570218507,-1.5707963267948966,-1.6361573310575634 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark05(-1.483408405051367,-84.90399980586847,57.936874252840795 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark05(-1.4839650424326911,-41.5145115369523,-135.72071891521577 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark05(-1.484638277008831,-0.1320478435092287,34.98356726163121 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark05(1.4846782389497697,-457.1013978398857,-38.10785667363514 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark05(-1.485040944725175,-41.3515665080039,-56.33139757882455 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark05(-1.4851722103169267,-8.212743748054245E-11,1.5602453265322438 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark05(-1.4856311054839644,-1.5707963267948966,4.71238897090447 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark05(-1.485694519667177,-16.163063716151893,-8.103981634401517 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark05(-1.4858481905411036,-3.2668614600736374,1.5707963267948948 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark05(-1.4863476341784385,4.141592706704038,42.536500826726005 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark05(-1.4867525801447206,-1.5707963267948968,1.5694853079533062 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark05(-1.4868795716691445,-1.5707963267948966,61.26105674500097 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark05(-1.4870887620863122,-1.5707963267948966,1.5707963235115505 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark05(-1.48720064169556,-1.5707963267948966,3.1416003018815557 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark05(-1.4872217447406857,-73.81731988536849,-1.5707963267948966 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark05(-1.4873540547792343,-17.056664510472984,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark05(-1.4874667423694206,-98.52205931754577,95.34818513405841 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark05(-1.4878159312468973,-1.5707963267948966,-1.56728398293404 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark05(-1.4881722814600993,-28.510972122807313,31.917440487719666 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark05(-1.488816105744596,-0.3100548044605858,0.6397083067574982 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark05(-1.4892552764788811,-23.210677980860893,-87.62516315746758 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark05(-1.4894917824352834,-3.142515769930632,-51.257845225458425 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark05(-1.4895009749295904,-260.8905015859701,163.51231557966457 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark05(-1.4899020249047972,14.43116230812661,-48.22151226724574 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark05(-1.4902236809666796,-1.387778889085748,22.702930467396072 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark05(-1.4904907947878157,-1.5707963267948966,-393.2245691416356 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark05(-1.490506003046959,-9.70838219403437,-93.79168426439676 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark05(-1.490525923675706,-179.32078038595367,145.0094681219212 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark05(-1.4906933036924244,-85.69882852977895,-2.0590230357872116E-84 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark05(-1.4911108396190813,-36.071301594478,48.790589626799424 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark05(-1.491387587074089,-0.0012009060356133186,26.697445105092903 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark05(-1.4915224031385161,-47.455276565941084,-265.4445085624059 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark05(-1.4919429832744484,-17.12830514741215,-15.872896236211066 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark05(-1.4921662706420928,-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark05(-1.4922257581161436,-19.968451064288658,21.8026694928932 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark05(-1.4926043436806835,-1.5707963267948963,-52.687248527786565 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark05(-1.4929373464678006,-85.55710216528536,-22.249542539909534 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark05(-1.4930754843099279,-1.5707963267948966,-16.62310043455905 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark05(-1.4938962875815602,-79.98164486788781,-64.20595126924097 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark05(-1.4948270161764692,-0.4838081606513977,-6.287091558122559 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark05(-1.4955021434977587,-72.2566315094111,26.365250979777556 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark05(-1.496010473127759E-16,-1.5707963267948966,62.83185307178789 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark05(-1.4960979675594117,-54.62267614545985,59.06737524076931 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark05(-1.4972872002386555,-9.490500959806573,-3.1416048155574914 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark05(-1.4974656380162021,-0.1432996237431766,89.89840916564307 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark05(-1.4975250099231328,4.2351647362715017E-22,-15.85406972505092 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark05(-1.4978318032882783,-122.7523274295711,40.02933651942026 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark05(-1.4980144018382962,-10.615155069638503,1.5707963267948966 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark05(-1.498041932746782,-223.98650169937224,3.1435511094396436 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark05(-1.49822637028889,-117.9937906265707,-77.31323441776523 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark05(-1.4984501674968187,-1.151396790702341,-3.1416005134100495 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark05(-1.4988288833570351,4.14159363417896,120.37058185145932 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark05(-1.498935918171229,-1.5707963267948966,-15.120176416996655 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark05(-1.4992583521981753,-1.5707963267948966,23.41311902067686 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark05(-1.4996746503039189,-3.141592893805644,0.09765581166058454 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark05(-1.4998333349479027,-10.175494617061652,44.075759692976106 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark05(-1.4998614621042836,-92.23565411793068,1.5045586830576723 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark05(-1.5000086045808012,-48.42722709470607,35.29297392713523 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark05(-1.5001859859992663,3.1415926535897953,-8.538706347555992 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark05(-1.5002545854382776,-0.5915755404642408,89.84332439424284 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark05(15.003186723832272,35.21128782764987,33.646277341123664 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark05(-1.500983952523711,-1.5707963267948852,-6.283190438856789 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark05(-1.5010373714472698,4.141592751235491,6.288899227406041 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark05(-1.5012690652849927,-3.1416080545658938,-64.4422627128899 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark05(-1.5016520035834569,-0.41294339416844317,-82.53702366869231 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark05(-1.5017197549584398,-136.3820462392381,-100.0 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark05(-1.501843931882958,-1.1102230246251565E-16,-77.69746129892411 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark05(-1.50225345979066,-122.7941626090824,-34.931886431502576 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark05(-1.5024810802997064,-0.6490659862523467,67.07033923687158 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark05(-1.5025887613849052,-1.5707963267948966,9.994246515501429 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark05(-1.5026188673578762,-72.2737496010145,1.5707963267948966 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark05(-1.5029195432301259,-35.30648278235127,36.08682764120179 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark05(-1.502981609370783,-3.1421980775857685,1.5707963267948912 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark05(-1.5032556029524815,-47.31556785515623,-1.5707963267948966 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark05(-1.5032763384212087,-72.32551578316016,-9.232978617785736E-128 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark05(-1.503278672836341,-23.27797602781793,-7.023238468279544 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark05(-1.5033941516989797,-55.67545079481854,1.570796326794895 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark05(-1.5038085726442008,-22.04632511628563,-1.5707963267964888 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark05(-1.5040155623712907,-67.34378756918719,0.0 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark05(-1.5041111541850816,-66.41355921337913,8.103981634445416 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark05(-1.5045862571327562,-66.6048625021097,-1.5707963267948966 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark05(-1.5048673385720406,-0.5179758108087187,-17.278759594743864 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark05(-1.5052372622301322,-0.3798353202634988,-10.702211773812797 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark05(-1.5054115692259624,-3.910318545279494E-149,1.53797277987148 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark05(-1.506071272389443,-0.23428079228492377,1.5707963267948966 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark05(-1.506137149758814,-3.466350296688958,-1.1750635779770846 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark05(-1.5063333612661693,-122.80262346395672,-117.66390804712044 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark05(-1.50634790254699,-1.5707963267948966,51.541027097513556 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark05(-1.5064055376715633,-72.53938028124578,-1.5707963267948966 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark05(-1.506964647210834,-91.11588252398536,77.01148326695676 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark05(-1.5069916785309396,-54.69340356329156,48.13647033855208 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark05(-1.5075433078569491,-53.76629700883092,-30.55937593154296 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark05(-1.507819793035101,-98.20687345852026,0.0 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark05(-1.5081700522727117,-3.266592750403893,-6.749101265938933 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark05(-1.5082579428938858,-3.532701978604452,4.712388981637867 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark05(-1.5083284953579579,-61.01696971457593,170.99213887698053 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark05(-1.50868809202602,-1.5707963267948966,84.6587290505424 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark05(-1.508752453443025,-0.19990328557392595,10.922024424945446 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark05(-1.508904062936573,-3.820775789412437,-150.61486345140585 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark05(-1.5089147844327129,-0.6598845841412625,-0.004627900084356609 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark05(-1.5090162040836421,-3.1775608392894146,232.72977588337025 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark05(-1.5091651518171307,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark05(-1.5094615895647236,-66.23855805847623,-73.09636623803235 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark05(-1.5101856947687442,-40.911258226248925,-3.4411343545387467 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark05(-1.5106463900303415,-1.5131740852923534,-26.1547737432936 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark05(-1.510945529262123,-72.49982273081577,-100.0 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark05(15.110799612741886,52.497993893187214,69.29752664936791 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark05(-1.5113130192661854,-1.2559200341199106,-100.0 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark05(-1.5115450451425,-135.50676921031888,-69.6818541906538 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark05(-1.5119390362239027,-9.440050979633057,-55.5566701878406 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark05(-1.5120886019199502,-1291.352849957198,98.36062710073614 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark05(-1.5126590256350834,0.7542837199475229,86.31188166778053 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark05(-1.5131492589338273,-73.46430817321566,-1.5707963268173322 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark05(-1.5134405962554214,-29.278697916144587,-0.1967606964680734 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark05(-1.5148329343562528,-72.5473287584037,-40.461431972863444 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark05(-15.149628494675255,71.44029889103726,-43.96715158927162 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark05(-1.5149852692803791,-41.23761427053372,-90.0158772951031 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark05(-1.515221518811411,-1.5707963267948968,20.420352248333657 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark05(-1.5154026121814343,-16.316114093127847,-73.14799232658171 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark05(-1.5157589081192582,-73.70995557696955,-1.5707963267948963 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark05(-1.516339485212897,-9.674900361397556,157.60104025180237 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark05(-1.5164954618212008,-47.47011384839842,34.80978364878816 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark05(-1.5166537297762428,-72.92381159774943,58.44165794554432 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark05(-1.5169127120329822,-0.0014956405851453843,20.844511578148396 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark05(-1.5174679814535914,-1.5357870012494068,-1.5707963267948968 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark05(-1.5184491822461723,-17.23646001717229,0.0 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark05(-1.5185997714957296,-0.05090471716347162,56.34046936691419 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark05(-1.5189662403328836,-3.7914615855712412,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark05(-1.519053112408028,-79.76940827799415,1.5707963267948963 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark05(-1.5200093229325282,-1.1584488352296332,-1.5707963267948912 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark05(-1.5209705807458826,-22.275278491035372,-1.5707963267948983 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark05(-1.5214588238444406,-54.843405887605044,-1.5707963267948983 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark05(-1.5214650882354492,-0.0298133329865988,0.0 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark05(-1.5217082881378579,-1.5707963267948963,75.98574710399623 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark05(-1.5218809209384387,-1.0760256032561213,0.9856038732684522 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark05(-1.5222712639510716,-191.78934990884733,-77.39079048405861 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark05(-1.5222965530913317,-0.271529442873907,4.795124295049767 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark05(-1.5224180109609313,-28.336833882312664,-167.2172098973008 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark05(-1.522516120204719,-1.5334082740022954,1.5707963267948966 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark05(-1.5225830947871373,-22.287968856720685,-72.95728934101602 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark05(-1.522834072065377,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark05(-1.5228766522186439,-1.5707963267946206,-35.71703434003592 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark05(-1.523625342407249,-73.38054695640112,-95.55644631131126 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark05(-1.5239472830778715,-1.570796326823578,0.0 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark05(-1.5242075596246878,-9.890483520054476,-12.566370949592173 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark05(-1.524287218293372,-8.673617379884035E-19,-94.07133673506979 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark05(-1.5246526813143972,3.472966814616889,-136.0360590259197 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark05(-1.5249356399028364,-67.22550541222436,-1.5707963265080878 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark05(-1.5249930120702657,-79.45142884571939,-76.96369394117897 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark05(-1.5250894665389532,-66.50168191819775,1.5707963267948966 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark05(-1.5253936214088595,-1.5707963267948966,-0.6922492210181908 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark05(-1.5256104637505374,-66.09535369614458,8.103981634139174 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark05(-1.5259186929653268,-54.41624804447733,-44.40907432867533 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark05(-1.5259236289997753,-34.983006989042764,-48.816295455620484 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark05(-1.526379612715524,-124.04374415490912,0.00753110963749117 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark05(-1.5266437871685354,-1.5707963267948966,-863.8282563874866 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark05(-1.5268193868834963,-1.5707963267948966,8.103982398032914 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark05(-1.5269768814808744,-1.5707963267948948,-29.790941973406827 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark05(-1.527243247747495,-60.93371509243608,-10.502475900541622 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark05(-1.5273247046953287,-34.73940824373133,4.118046071574423E-84 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark05(-1.5275340159993362,-72.83238873557073,-1.5707963267948841 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark05(-1.5275729093082373,-80.84673440976171,0.0 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark05(-1.5280249215151567,-1.5707963267948966,-12.571410041469361 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark05(-1.5283077465173598,-66.12148234038187,-12.18215167171914 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark05(-1.5285400672431915,-40.98976164008346,1.5707963267948966 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark05(-1.5286892512478971,-1.5707963267948968,1.5707963267948983 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark05(-1.5286977071876229,-1.5707963267948801,46.18088719875661 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark05(-1.528909649039544,2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark05(-1.5289215448432878,-85.5118562186529,-3.778058752066677 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark05(-1.5289804624950964,-67.36764271965286,-8.104011091937506 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark05(-1.5291949418151913,-16.08453830447459,1.5707963267948966 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark05(-1.5292252965953277,-72.51110654581605,-0.040532053952221425 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark05(-1.5292553929080006,-47.463849115969374,68.03919628240902 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark05(-1.5305592002629524,-17.24829317609234,-95.37849679447025 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark05(-1.5306168268952867,-72.43224014727086,1.5707963267948966 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark05(-1.531158105926763,-1.5707963267948963,0.0 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark05(-1.5318556561443253,-104.7415742622332,12.257560168067513 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark05(-1.5320658241705087,28.70353755551325,-100.0 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark05(-1.5322652205446834,-41.69646836489588,6.283185784097272 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark05(-1.5324769739292425,-0.4210933149810776,51.34062333368163 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark05(-1.5332988090363746,-91.941069419537,-57.55603466261964 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark05(-1.5333558401151655,-0.784972206810463,-21.99125333111421 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark05(-1.5334441395542466,-67.24449350519797,-25.13303175818789 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark05(-1.5334567109191255,-1.5707963267948957,-49.310201873298496 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark05(-1.5335563486797907,-3.4487184762215914,89.78440469503545 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark05(-1.5335597586574998,-67.42649359633869,-95.19146464644561 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark05(-1.5338091437942283,-91.85312568269785,1.3434162001689727 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark05(-1.5341471072978834,-9.959749604389716,-26.703561878059077 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark05(-1.5343795423504507,-66.41808548165542,505.2227900719495 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark05(-1.5344215105257326,-1.3943608177263698,-49.80331601681662 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark05(-1.5344510395141324,-0.9683093321659672,43.1149646436867 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark05(-1.5346350556822301,-1.5707963267948966,74.94997680242709 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark05(-1.5355233300894444,-4.125038717859368,-41.37139902385702 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark05(-1.5361003426510729,0.21427871709798,16.931957020534014 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark05(-1.5361852479301157E-5,-1.5707963267948966,43.98229699922071 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark05(-1.536445542758099,-22.319452916916447,100.0 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark05(-1.536781338221898,-66.30921620124784,77.1159463304144 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark05(-1.5368188820787252,-67.20199813525923,-35.90358318830516 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark05(-1.5369251180545476,-79.14513179521262,63.01321036640245 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark05(-1.537132864891109,-4.0389678347315804E-28,-68.05358120418104 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark05(-1.5372628342408294,-66.76262753457047,-56.435490912423255 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark05(-1.5373176655213332,-0.3787090406855396,0.0 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark05(-1.5375137677170927,-104.07596728039039,44.495215825059866 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark05(-1.5376650899657147,-9.716935561606551,6.776263578034403E-21 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark05(-1.5380800682940146,-66.13059445302544,0.031379984078186415 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark05(-1.5381310348872863,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark05(-1.5386049152696795,-1.5707963261501772,66.86255562247298 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark05(-1.5386437792194188,-54.116885258022485,-28.339464037824893 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark05(-1.5386448717406258,-0.012802671798093327,1.5707963267948966 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark05(-1.538914352765817,-4.439883505093789,-667.1250547240094 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark05(-1.5390746886083122,-4.386250041024439,-52.652579290566486 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark05(-1.539097849255697,-47.19334644193016,-86.21699890777649 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark05(-1.5395040629501262,-0.8489260746598869,4.712507435192892 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark05(-1.5396513528278954,-3.1420811576373424,-8.564488430680655 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark05(-1.5396782114728156,-1.5707963267948966,85.24531718830946 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark05(-1.5398378226253735,-23.071480049288187,-2.195395158912163 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark05(-1.5405156725401274,-60.13515417563049,0.09740403270606023 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark05(-1.5410145204845591,-1.5707963267948912,20.313365311900775 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark05(-1.541044865350938,-98.02122491096793,12.889867663751915 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark05(-1.541179759629303,-3.1584086836355683,10.263568462375758 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark05(-1.541207985672969,-92.24648177384975,-52.01435235731602 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark05(-1.541371322432759,-85.13647158977483,-248.2711799345459 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark05(-1.5414365949362236,-0.02268497499417409,-1.5707964164974946 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark05(-1.5419215871772523,-16.41800490182805,-0.22504701420228912 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark05(-1.5425949075224488,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark05(-1.5428665153373309,-15.818696372017289,0.734733160065618 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark05(-1.5429614156061566,-10.453561514982129,10.42477796075441 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark05(-1.5434360085982737,-0.11721367912748948,-4.712388982665633 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark05(-1.5434620570945228,-59.72369520074066,0.0 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark05(-1.5435436475231454,-98.13593164214826,-1.5707963267948983 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark05(-1.5436787707796173,-1.5707963267948966,-37.93723053712999 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark05(-1.5437250441698767,-84.89717151262813,-0.21061178468039543 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark05(-1.543738499188532,-91.98809237554991,-16.939043353730334 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark05(-1.543810265970828,-152.05024365394456,42.86933173110391 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark05(-1.5439348603528167,-16.930529917101314,-99.49291337340509 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark05(-1.5443444566220572,-1.5707963267948966,-50.28530982050703 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark05(-1.5445879814156291,-16.128729147180195,-77.20238566026497 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark05(-1.5446102146356813,-4.440892098500626E-16,-51.74053455837219 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark05(-1.5449162531330085,-1.5707963267948966,67.43906593613896 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark05(-1.5451814846869485,-48.590990661216864,-85.12823825844708 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark05(-1.5451972175953315,-1.5707963267948966,-60.872100950553246 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark05(-1.545637611008527,-66.4643785293953,-6.31443530720043 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark05(-1.5458002554185923,-1.570796326794896,-1.5707963267948966 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark05(-1.5462295190007442,-73.17898625044083,0.8483860064870048 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark05(-1.5462460560297986,-3.456520313048287,-1.3395108581442052 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark05(-1.5465994520131627,-72.38147599696592,18.849591615148054 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark05(-1.546839087480187,-15.780984772260402,-26.538164401659333 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark05(-1.5469905483185171,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark05(-1.5470468345449662,-15.839294765978286,-1.570796326794894 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark05(-1.5471553745234408,-0.23629617146033052,91.03932945827646 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark05(-1.5472807968882762,-5.027407174788806,-63.35541369286695 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark05(-1.5479358618025714,-1.3642836692382772,0.0 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark05(-1.548141055535427,-66.44667369816531,0.0 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark05(-1.5483294076900525,-35.5922385925721,1.5707963267948966 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark05(-1.54834783037835,-1.5707963267948963,-3.1255752380637176 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark05(-1.548406662692144,-53.985027875073975,-1.5707963267859488 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark05(-1.5485870900048773,-1.5707963267948966,-295.9838696177278 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark05(-1.5486675686421145,-91.1114527115479,1.5707963267948966 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark05(-1.5500710572989738,-35.96460643738905,3.14159266851377 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark05(-1.5500885516539993,-1.2396686018170655,1.4809879032345918 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark05(-1.5501198963459306,14.660714330110451,48.8884682008854 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark05(-1.5501351163635448,-1.5707963267948961,-7.8539816472855515 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark05(-1.5502407941120406E-5,-1.5706925556592872,87.90986796883308 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503293154661897,-1.5707963267948963,0.009728404158319326 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503502960414746,-28.424794187581142,107.05418802718972 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark05(-1.5503974891675145,-1.5707963267948966,35.51540817707457 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark05(-1.5507624235265294,-97.77272062554079,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark05(-1.5511372940775936,-1.5707963267948966,51.23127496546428 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark05(-1.5512192270536882,-1.5707963267948968,45.9797119187387 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark05(-1.5512242504683236,3.141592653589819,-49.91195373475926 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark05(-1.55138527441581,-54.58847468724621,0.0 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark05(-1.5514875567346,-0.9257151287525343,133.80747382910334 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark05(-1.5515517731557564,-42.23236187026836,-72.50364419589218 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark05(-1.5516237572812908,-41.31530716461252,0.0 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark05(-1.5517006722865418,-1.5707963267948966,35.56645002664169 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark05(-1.55171456465923,-1.5707963267948963,-99.36803998101458 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark05(-1.551749566581504,-73.4800942165166,31.677214312812787 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark05(-1.5519062733175166,-91.10618719316166,1.5707963267948966 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark05(-1.5521327905083275,-1.1619210869592638,-21.777007240841204 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark05(-1.5525513955526271,-1.5707963267948657,-25.35247517280826 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark05(-1.5532197681854103,-1.570796326550353,55.03595736393184 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark05(-1.5536687690359219,-66.51153292086298,1.0912526806220768 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark05(-1.5537101033860925,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark05(-1.553894915091583,-0.5703691568957489,41.388004451374975 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark05(-1.5543062552224571,-54.86131223652728,28.210570916590854 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark05(-1.5544389237531975,-1.5707963267948966,6.283248915238899 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark05(-1.5554033127159643,-16.04837722116234,-88.41144593890047 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark05(-1.5555839143942508E-12,-0.5559530907331887,-57.90438666742286 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark05(-1.5557358769425975,-3.142080956966824,-7.165357055037051 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark05(-1.55582837009975,-53.99775897718461,0.35212974824748805 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark05(-1.5561481131024704,-85.26694774779708,-3.1416002830616603 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark05(-1.5564824637140733,-122.93736831459753,89.87261020733713 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark05(-1.556495022836299,-1.3313491158432527,34.55797517586658 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark05(-1.5566755791605031,-1.5707963267948966,64.13096777075486 ) ;
  }

  @Test
  public void test4346() {
    coral.tests.JPFBenchmark.benchmark05(-1.5569744406207295,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4347() {
    coral.tests.JPFBenchmark.benchmark05(-1.5571618214777763,-22.423225856695453,90.79735029958108 ) ;
  }

  @Test
  public void test4348() {
    coral.tests.JPFBenchmark.benchmark05(-1.5575098006772152,-1.562213493304597,45.40985632644579 ) ;
  }

  @Test
  public void test4349() {
    coral.tests.JPFBenchmark.benchmark05(-1.558084363132541,-1.5707963267948917,0.0 ) ;
  }

  @Test
  public void test4350() {
    coral.tests.JPFBenchmark.benchmark05(-1.558104610428256,-273.83105497074985,-84.55669129630152 ) ;
  }

  @Test
  public void test4351() {
    coral.tests.JPFBenchmark.benchmark05(-1.55812549589281,-41.07341953867129,78.02969505431818 ) ;
  }

  @Test
  public void test4352() {
    coral.tests.JPFBenchmark.benchmark05(-1.5581609642596426,-1.5707963267943228,0.0 ) ;
  }

  @Test
  public void test4353() {
    coral.tests.JPFBenchmark.benchmark05(-1.5582615458059512,-1.1102230246251565E-16,91.10618510318454 ) ;
  }

  @Test
  public void test4354() {
    coral.tests.JPFBenchmark.benchmark05(-1.5584074987446423,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4355() {
    coral.tests.JPFBenchmark.benchmark05(-1.5589504768321634,-1.2503207362006818,-4.7123889803847865 ) ;
  }

  @Test
  public void test4356() {
    coral.tests.JPFBenchmark.benchmark05(-1.5592111602019931,-3.494333356571581E-15,54.78823167806718 ) ;
  }

  @Test
  public void test4357() {
    coral.tests.JPFBenchmark.benchmark05(-1.5592595188450526,-0.07183070478412745,75.71704891902918 ) ;
  }

  @Test
  public void test4358() {
    coral.tests.JPFBenchmark.benchmark05(-1.559273490174192,-0.9336829955442842,-79.4394445704672 ) ;
  }

  @Test
  public void test4359() {
    coral.tests.JPFBenchmark.benchmark05(-1.5596126808499815,-1.5707963267948966,77.38349863414781 ) ;
  }

  @Test
  public void test4360() {
    coral.tests.JPFBenchmark.benchmark05(-1.5598292888850267,-97.38937226128358,-100.0 ) ;
  }

  @Test
  public void test4361() {
    coral.tests.JPFBenchmark.benchmark05(-1.5599500935138597,0.0,0 ) ;
  }

  @Test
  public void test4362() {
    coral.tests.JPFBenchmark.benchmark05(-1.5601442474386955,-47.13525781246917,-51.509442591780456 ) ;
  }

  @Test
  public void test4363() {
    coral.tests.JPFBenchmark.benchmark05(-1.5604213213190825,-3.0942396543733656E-17,46.15356362714638 ) ;
  }

  @Test
  public void test4364() {
    coral.tests.JPFBenchmark.benchmark05(-1.5604647135830452,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4365() {
    coral.tests.JPFBenchmark.benchmark05(-1.560541060171392,-1.5707963267948966,-32.799532826719265 ) ;
  }

  @Test
  public void test4366() {
    coral.tests.JPFBenchmark.benchmark05(-1.5606747318533472,-98.4668856122333,-169.58317280483226 ) ;
  }

  @Test
  public void test4367() {
    coral.tests.JPFBenchmark.benchmark05(-1.561088623664027,-9.424778093262457,20.475736975127774 ) ;
  }

  @Test
  public void test4368() {
    coral.tests.JPFBenchmark.benchmark05(-1.5611077873933428,-1.5707871385596202,-3.26659265359745 ) ;
  }

  @Test
  public void test4369() {
    coral.tests.JPFBenchmark.benchmark05(-1.5613952263822293,-1.0439825775266127,59.2852604893543 ) ;
  }

  @Test
  public void test4370() {
    coral.tests.JPFBenchmark.benchmark05(-1.561871705056515,-1.360656464731414,0.0 ) ;
  }

  @Test
  public void test4371() {
    coral.tests.JPFBenchmark.benchmark05(-1.5619950789334414,-41.59685006861151,20.970747235916207 ) ;
  }

  @Test
  public void test4372() {
    coral.tests.JPFBenchmark.benchmark05(-1.562230674129832,-625.3584181911361,92.24057991835843 ) ;
  }

  @Test
  public void test4373() {
    coral.tests.JPFBenchmark.benchmark05(-1.5623569386153244,-54.63475817457521,-1.570796326783655 ) ;
  }

  @Test
  public void test4374() {
    coral.tests.JPFBenchmark.benchmark05(-1.5623635338434338,-1.5707963267948966,-37.92018186691814 ) ;
  }

  @Test
  public void test4375() {
    coral.tests.JPFBenchmark.benchmark05(-1.5625080368198914,-9.496366997350869,77.37942119306715 ) ;
  }

  @Test
  public void test4376() {
    coral.tests.JPFBenchmark.benchmark05(-1.5625404634813125,-85.66229182089845,-20.421924104095492 ) ;
  }

  @Test
  public void test4377() {
    coral.tests.JPFBenchmark.benchmark05(-1.562564154470047,-53.71476797656296,5.2710989716152616E-82 ) ;
  }

  @Test
  public void test4378() {
    coral.tests.JPFBenchmark.benchmark05(-1.5628548216368237,-1.5707963267948948,-0.1341766378850765 ) ;
  }

  @Test
  public void test4379() {
    coral.tests.JPFBenchmark.benchmark05(-1.562936012676827,28.703537555513307,90.39384197371075 ) ;
  }

  @Test
  public void test4380() {
    coral.tests.JPFBenchmark.benchmark05(-1.5633440355497341,-28.574715153028137,-100.0 ) ;
  }

  @Test
  public void test4381() {
    coral.tests.JPFBenchmark.benchmark05(-1.5633483674498279,-72.80801386580038,-1.5707963267948966 ) ;
  }

  @Test
  public void test4382() {
    coral.tests.JPFBenchmark.benchmark05(-1.5634211952787684,-48.2673951230656,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test4383() {
    coral.tests.JPFBenchmark.benchmark05(-1.5634384322892898,-47.14025032549332,-112.07072596098428 ) ;
  }

  @Test
  public void test4384() {
    coral.tests.JPFBenchmark.benchmark05(-1.5637441147272142,-1.5707963267948966,50.550781026267025 ) ;
  }

  @Test
  public void test4385() {
    coral.tests.JPFBenchmark.benchmark05(-1.5638169495519894,4.141747081861219,-3.173535346144777 ) ;
  }

  @Test
  public void test4386() {
    coral.tests.JPFBenchmark.benchmark05(-1.5639748637668496,-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test4387() {
    coral.tests.JPFBenchmark.benchmark05(-1.5640992054610514,4.141592653605082,-8.106702461342453 ) ;
  }

  @Test
  public void test4388() {
    coral.tests.JPFBenchmark.benchmark05(-1.5643718314374435,-3.7527450399254576,182.2040283485847 ) ;
  }

  @Test
  public void test4389() {
    coral.tests.JPFBenchmark.benchmark05(-1.5646127896576818,-72.3111809674203,0.0 ) ;
  }

  @Test
  public void test4390() {
    coral.tests.JPFBenchmark.benchmark05(-1.5646766437620818,-1.53468769044439,-4.712399351732503 ) ;
  }

  @Test
  public void test4391() {
    coral.tests.JPFBenchmark.benchmark05(-1.5647082347957924,-1.325012504838863,-58.63604785720205 ) ;
  }

  @Test
  public void test4392() {
    coral.tests.JPFBenchmark.benchmark05(-1.5647535878949017,-10.871127583942545,44.53806555292657 ) ;
  }

  @Test
  public void test4393() {
    coral.tests.JPFBenchmark.benchmark05(-1.564823520935498,-1.8087499834285668E-4,-67.53599060416623 ) ;
  }

  @Test
  public void test4394() {
    coral.tests.JPFBenchmark.benchmark05(-1.5648247659395933,-34.616203372186355,45.18422901683371 ) ;
  }

  @Test
  public void test4395() {
    coral.tests.JPFBenchmark.benchmark05(-1.5648290955960573,-85.71272401076268,-15.947946529922664 ) ;
  }

  @Test
  public void test4396() {
    coral.tests.JPFBenchmark.benchmark05(-1.5651439150487785,-1.5707963267948966,47.397224443614185 ) ;
  }

  @Test
  public void test4397() {
    coral.tests.JPFBenchmark.benchmark05(-1.5651912057342015,-15.85214846838225,-42.6782065437052 ) ;
  }

  @Test
  public void test4398() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653038532601748,-1.5707963267948966,37.701064968089824 ) ;
  }

  @Test
  public void test4399() {
    coral.tests.JPFBenchmark.benchmark05(-1.5653839999453394,-0.6809801287263078,-57.761377213384726 ) ;
  }

  @Test
  public void test4400() {
    coral.tests.JPFBenchmark.benchmark05(-1.5655646288347473,7.458168886126868,1.5707963267948983 ) ;
  }

  @Test
  public void test4401() {
    coral.tests.JPFBenchmark.benchmark05(-1.565645755303784,-59.694517090488276,-73.94271160608409 ) ;
  }

  @Test
  public void test4402() {
    coral.tests.JPFBenchmark.benchmark05(-1.5656661820330544,-98.58379905731907,-21.973406906645167 ) ;
  }

  @Test
  public void test4403() {
    coral.tests.JPFBenchmark.benchmark05(-1.5657295233640092,-35.99804244914818,5.141593106415453 ) ;
  }

  @Test
  public void test4404() {
    coral.tests.JPFBenchmark.benchmark05(-1.5657503884177093,-1.5434974768346676,8.145234507974813 ) ;
  }

  @Test
  public void test4405() {
    coral.tests.JPFBenchmark.benchmark05(-1.5659990608771819,-73.4650778780982,-34.82292148194671 ) ;
  }

  @Test
  public void test4406() {
    coral.tests.JPFBenchmark.benchmark05(-1.5662157197526283,-9.499056978239864,-23.56194490192345 ) ;
  }

  @Test
  public void test4407() {
    coral.tests.JPFBenchmark.benchmark05(-1.566226161603694,-2.4886835281075105E-6,-17.241809681436326 ) ;
  }

  @Test
  public void test4408() {
    coral.tests.JPFBenchmark.benchmark05(-1.5665822965832201,4.141592653589813,56.79253126146547 ) ;
  }

  @Test
  public void test4409() {
    coral.tests.JPFBenchmark.benchmark05(-1.5665988756147649,-9.571746293764635,-100.6653998931899 ) ;
  }

  @Test
  public void test4410() {
    coral.tests.JPFBenchmark.benchmark05(-1.5667048296705122,-9.97776878441438,-91.09355011999136 ) ;
  }

  @Test
  public void test4411() {
    coral.tests.JPFBenchmark.benchmark05(-1.5667569878590837,4.141592653589825,5.115082972900839 ) ;
  }

  @Test
  public void test4412() {
    coral.tests.JPFBenchmark.benchmark05(-1.566958925846803,-16.033610791695416,8.466749628299269 ) ;
  }

  @Test
  public void test4413() {
    coral.tests.JPFBenchmark.benchmark05(-1.567107711885077,-22.355096647507068,3.536898126044786 ) ;
  }

  @Test
  public void test4414() {
    coral.tests.JPFBenchmark.benchmark05(-1.5673190011964417,-1.5707963267948966,1.5707963267948912 ) ;
  }

  @Test
  public void test4415() {
    coral.tests.JPFBenchmark.benchmark05(-1.5675245513936211,-0.08980572399416087,49.81318884732631 ) ;
  }

  @Test
  public void test4416() {
    coral.tests.JPFBenchmark.benchmark05(-1.5676201626684494,-1.5707963267948966,57.81105289201263 ) ;
  }

  @Test
  public void test4417() {
    coral.tests.JPFBenchmark.benchmark05(-1.5677207924113603,-47.603119554595565,-12.008190435054292 ) ;
  }

  @Test
  public void test4418() {
    coral.tests.JPFBenchmark.benchmark05(-1.567759162640005,-1.5707963267948966,8.103981634077424 ) ;
  }

  @Test
  public void test4419() {
    coral.tests.JPFBenchmark.benchmark05(-1.567806987698874,-47.45964397550373,-49.94918753375619 ) ;
  }

  @Test
  public void test4420() {
    coral.tests.JPFBenchmark.benchmark05(-1.5680632204757279,-1.5707963267948966,-6.2832009672113225 ) ;
  }

  @Test
  public void test4421() {
    coral.tests.JPFBenchmark.benchmark05(-1.5681581859961156,-186.58049005039297,169.7011536550405 ) ;
  }

  @Test
  public void test4422() {
    coral.tests.JPFBenchmark.benchmark05(-1.5685827306202837,-0.8252605423271822,47.12686337154087 ) ;
  }

  @Test
  public void test4423() {
    coral.tests.JPFBenchmark.benchmark05(-1.5685992713116261,3.141593096590345,-1.5707963267948968 ) ;
  }

  @Test
  public void test4424() {
    coral.tests.JPFBenchmark.benchmark05(-1.5686254199864023,-7.105427357601002E-15,-1.5707963267948963 ) ;
  }

  @Test
  public void test4425() {
    coral.tests.JPFBenchmark.benchmark05(-1.5686574023692579,-0.14147328734337022,13.391238851913275 ) ;
  }

  @Test
  public void test4426() {
    coral.tests.JPFBenchmark.benchmark05(-1.5687299758568687,28.703537556534446,-84.7905716312824 ) ;
  }

  @Test
  public void test4427() {
    coral.tests.JPFBenchmark.benchmark05(-1.5687720899449908,-1.5707963267948966,73.27289412347939 ) ;
  }

  @Test
  public void test4428() {
    coral.tests.JPFBenchmark.benchmark05(-1.5689240572508114,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4429() {
    coral.tests.JPFBenchmark.benchmark05(-1.5690725986790695,-35.306316957293376,-66.12149615604699 ) ;
  }

  @Test
  public void test4430() {
    coral.tests.JPFBenchmark.benchmark05(-1.5692250913083186,-1.5707963265635805,-78.71180806568162 ) ;
  }

  @Test
  public void test4431() {
    coral.tests.JPFBenchmark.benchmark05(-1.56936056559777,-1.5707963267948966,14.429455351073159 ) ;
  }

  @Test
  public void test4432() {
    coral.tests.JPFBenchmark.benchmark05(-1.5694578903485807,-59.976758879880094,-27.14164021741813 ) ;
  }

  @Test
  public void test4433() {
    coral.tests.JPFBenchmark.benchmark05(-1.5695196366012327,-0.05091504961166926,100.61958927517074 ) ;
  }

  @Test
  public void test4434() {
    coral.tests.JPFBenchmark.benchmark05(-1.569592034179512,-41.352738072503016,8.103981634730006 ) ;
  }

  @Test
  public void test4435() {
    coral.tests.JPFBenchmark.benchmark05(-1.5696191875108676,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4436() {
    coral.tests.JPFBenchmark.benchmark05(-1.5697647714862182,-1.5707963267948966,52.75293478105543 ) ;
  }

  @Test
  public void test4437() {
    coral.tests.JPFBenchmark.benchmark05(-1.5697894269144257,2.5243548967072378E-29,47.65648458113568 ) ;
  }

  @Test
  public void test4438() {
    coral.tests.JPFBenchmark.benchmark05(-1.569799583155223,-65.98125995615534,1.5707963267948966 ) ;
  }

  @Test
  public void test4439() {
    coral.tests.JPFBenchmark.benchmark05(-1.5698157877192853,-1.5707963267948966,-1.5707963651249592 ) ;
  }

  @Test
  public void test4440() {
    coral.tests.JPFBenchmark.benchmark05(-1.5698361338036912,-54.97691892892894,-1.5707963267948966 ) ;
  }

  @Test
  public void test4441() {
    coral.tests.JPFBenchmark.benchmark05(-1.5698489300361709,-36.016216185964765,3.574509859000016 ) ;
  }

  @Test
  public void test4442() {
    coral.tests.JPFBenchmark.benchmark05(-1.5698512923836319,-9.466316513106896,32.28586412742421 ) ;
  }

  @Test
  public void test4443() {
    coral.tests.JPFBenchmark.benchmark05(-1.5698954898955793,-72.51569520588237,-1.5707963479590745 ) ;
  }

  @Test
  public void test4444() {
    coral.tests.JPFBenchmark.benchmark05(-1.5699023734143736,-48.455246136698975,88.08959430080225 ) ;
  }

  @Test
  public void test4445() {
    coral.tests.JPFBenchmark.benchmark05(-1.5699219347973579,-60.61957682008905,-1.2622298857969838 ) ;
  }

  @Test
  public void test4446() {
    coral.tests.JPFBenchmark.benchmark05(-1.5699274187540657,-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test4447() {
    coral.tests.JPFBenchmark.benchmark05(-1.5699438129290915,-0.5686902441440945,-20.01284098778948 ) ;
  }

  @Test
  public void test4448() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701245129345205,-17.14832294828409,-20.950423875123043 ) ;
  }

  @Test
  public void test4449() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701749052538025,-67.25905074474518,-91.10610845263298 ) ;
  }

  @Test
  public void test4450() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701758832246355,-4.431278576917364,-56.28351180597875 ) ;
  }

  @Test
  public void test4451() {
    coral.tests.JPFBenchmark.benchmark05(-1.5701964871134757,14.433806387279802,-1.5707963267948966 ) ;
  }

  @Test
  public void test4452() {
    coral.tests.JPFBenchmark.benchmark05(-1.5702772119237016,-3.141592668494332,-1.5707963267948957 ) ;
  }

  @Test
  public void test4453() {
    coral.tests.JPFBenchmark.benchmark05(-1.5702851449646045,-85.03778459776376,-85.72672737467379 ) ;
  }

  @Test
  public void test4454() {
    coral.tests.JPFBenchmark.benchmark05(-1.570300394042494,-1.1102230246251565E-16,-3.14159347634629 ) ;
  }

  @Test
  public void test4455() {
    coral.tests.JPFBenchmark.benchmark05(-1.5703051730137036,-0.915323890517786,1.5707963267948966 ) ;
  }

  @Test
  public void test4456() {
    coral.tests.JPFBenchmark.benchmark05(-1.5703263080074157,-179.6335404230814,-80.15722872081089 ) ;
  }

  @Test
  public void test4457() {
    coral.tests.JPFBenchmark.benchmark05(-1.570346513489257,-3.163711659894995,32.87462293428884 ) ;
  }

  @Test
  public void test4458() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704203568093547,-16.257291733630552,2.3970182936024055E-94 ) ;
  }

  @Test
  public void test4459() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704694577008738,-1.5707963267948966,-0.8819930628955319 ) ;
  }

  @Test
  public void test4460() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704917125963735,-1.7123510539128149E-195,-50.13613646196184 ) ;
  }

  @Test
  public void test4461() {
    coral.tests.JPFBenchmark.benchmark05(-1.5704997437837829,-1.5707963267948966,53.60960180397059 ) ;
  }

  @Test
  public void test4462() {
    coral.tests.JPFBenchmark.benchmark05(-1.5705493553014243,-3.141594616916639,1.1640630728588557 ) ;
  }

  @Test
  public void test4463() {
    coral.tests.JPFBenchmark.benchmark05(-1.5705878172622252,-36.12666388301046,-7.104631570132417E-15 ) ;
  }

  @Test
  public void test4464() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706595079427883,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test4465() {
    coral.tests.JPFBenchmark.benchmark05(-1.5706612036692262,-1.5707963267948966,-14.430011545920365 ) ;
  }

  @Test
  public void test4466() {
    coral.tests.JPFBenchmark.benchmark05(-1.570694023166727,4.1415926602743705,6.312164412472974 ) ;
  }

  @Test
  public void test4467() {
    coral.tests.JPFBenchmark.benchmark05(-1.570708897623642,-72.25666156155391,1.5707963267948966 ) ;
  }

  @Test
  public void test4468() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707416709984083,2.7755575615628914E-17,0.003331444185417268 ) ;
  }

  @Test
  public void test4469() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707445823639965,-10.09393506932686,-6.2565096724471904E-148 ) ;
  }

  @Test
  public void test4470() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707517169041154,-1.3552527156068805E-20,-64.97301715494764 ) ;
  }

  @Test
  public void test4471() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707592005451216,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4472() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707641811373156,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test4473() {
    coral.tests.JPFBenchmark.benchmark05(-1.570768930418425,-8.89103499794031E-162,42.830290034007646 ) ;
  }

  @Test
  public void test4474() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707895461434844,-5.604130299516018E-17,-36.12849999352845 ) ;
  }

  @Test
  public void test4475() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707896117503652,-28.274333882550625,0.0 ) ;
  }

  @Test
  public void test4476() {
    coral.tests.JPFBenchmark.benchmark05(-1.570792003917286,-34.55752711812734,1.5707963267948966 ) ;
  }

  @Test
  public void test4477() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079336906516,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test4478() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707937749438943,-59.815383802408796,-6.2831858879229605 ) ;
  }

  @Test
  public void test4479() {
    coral.tests.JPFBenchmark.benchmark05(-1.570794543913412,-6.634508948525791E-5,-31.47826659159545 ) ;
  }

  @Test
  public void test4480() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707945743436134,-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test4481() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707951498107362,-1.5707963267948966,-18.59444837887843 ) ;
  }

  @Test
  public void test4482() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707952329004051,-161.3173774897856,56.4414522669825 ) ;
  }

  @Test
  public void test4483() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796159060947,-216.89759641728674,-112.04744117320486 ) ;
  }

  @Test
  public void test4484() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707961901677465,-1.446652276340684,0.36193416944074386 ) ;
  }

  @Test
  public void test4485() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796207387281,-1.3552527156068805E-20,-6.301447115459263 ) ;
  }

  @Test
  public void test4486() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962082229956,-85.92371315489702,-42.756333335301534 ) ;
  }

  @Test
  public void test4487() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962466807919,-5.958557748795447E-22,71.46796139043842 ) ;
  }

  @Test
  public void test4488() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707962795896317,-16.114027588031895,112.72676810276025 ) ;
  }

  @Test
  public void test4489() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796292355828,-28.732775991779235,0.0 ) ;
  }

  @Test
  public void test4490() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963012457973,-3.1415933099111673,-1.5707963267948966 ) ;
  }

  @Test
  public void test4491() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963131012028,-117.23716579421591,-1.5707963267948948 ) ;
  }

  @Test
  public void test4492() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963145146817,-1.0889850326801531,1.5707963267948983 ) ;
  }

  @Test
  public void test4493() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963182769205,-16.40172864186711,-185.88164224626564 ) ;
  }

  @Test
  public void test4494() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963204001134,-0.20980048009684105,77.21260818442849 ) ;
  }

  @Test
  public void test4495() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796321189798,-0.6607802719310261,-1.5707963267948966 ) ;
  }

  @Test
  public void test4496() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963215482448,-34.67176523274068,-99.52504682273225 ) ;
  }

  @Test
  public void test4497() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963222807606,-1.5707963267948963,-57.16047836295368 ) ;
  }

  @Test
  public void test4498() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963224859802,-1.5707963267948983,-0.08482454916628664 ) ;
  }

  @Test
  public void test4499() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963228856352,-48.12153382928397,-60.023536464644835 ) ;
  }

  @Test
  public void test4500() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963232889486,-60.01257933440924,1.5707963267948966 ) ;
  }

  @Test
  public void test4501() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963233690685,-1.46816078519997,73.88721094316497 ) ;
  }

  @Test
  public void test4502() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963236191713,-1.1412972665017602,69.5195593643317 ) ;
  }

  @Test
  public void test4503() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963241712124,-173.03862518468895,-151.95947615136564 ) ;
  }

  @Test
  public void test4504() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796324179555,-1.5707963267948966,81.83483736639955 ) ;
  }

  @Test
  public void test4505() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963246642846,-73.18728695326384,-3.2673318565483593 ) ;
  }

  @Test
  public void test4506() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796324780853,-1.5707963267948966,-61.82096930192345 ) ;
  }

  @Test
  public void test4507() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963250151686,-1.5707963267948912,48.03069562437898 ) ;
  }

  @Test
  public void test4508() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325194317,-1.5707963267948966,50.90873740517753 ) ;
  }

  @Test
  public void test4509() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963253048998,-218.13520367892363,-50.19347235281946 ) ;
  }

  @Test
  public void test4510() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963253473392,-1.2958152176164022,28.587418742387097 ) ;
  }

  @Test
  public void test4511() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963253965949,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4512() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963256635773,-40.963687265904895,152.07960664635044 ) ;
  }

  @Test
  public void test4513() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963257849082,-103.67599984191081,-26.007105911015117 ) ;
  }

  @Test
  public void test4514() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796325814181,-116.31612709006293,1.5707963267948966 ) ;
  }

  @Test
  public void test4515() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963258644213,-3.5320605158728737,42.88497258433668 ) ;
  }

  @Test
  public void test4516() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963259478126,-0.5573734520269154,-1.5707963267948966 ) ;
  }

  @Test
  public void test4517() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260609095,-97.68033340454262,-26.859338947600822 ) ;
  }

  @Test
  public void test4518() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260675732,-104.66008499040835,70.34331191880955 ) ;
  }

  @Test
  public void test4519() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963260831166,-1.2536577339092325,-54.546786682198785 ) ;
  }

  @Test
  public void test4520() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261392743,-1.5707963267948966,73.35878570889122 ) ;
  }

  @Test
  public void test4521() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963261444433,-54.706318238757156,-57.353466296702685 ) ;
  }

  @Test
  public void test4522() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632615165,-1.5705581380422093,56.28068454042281 ) ;
  }

  @Test
  public void test4523() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262010896,-65.99040302525219,22.23932492222221 ) ;
  }

  @Test
  public void test4524() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963262842284,-6.938893903907228E-18,30.335258591570543 ) ;
  }

  @Test
  public void test4525() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263137534,-1.5707963267948966,-44.100992686722094 ) ;
  }

  @Test
  public void test4526() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963263436893,-4.866205489943923E-11,83.23224448404142 ) ;
  }

  @Test
  public void test4527() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963264914944,-9.568306154537485,77.51045974167599 ) ;
  }

  @Test
  public void test4528() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265082685,-1.5707963267948966,19.034109994685227 ) ;
  }

  @Test
  public void test4529() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265103198,-9.845817177010034,-1.5707963267948966 ) ;
  }

  @Test
  public void test4530() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265133382,-1.5707963267948966,-37.90677308674788 ) ;
  }

  @Test
  public void test4531() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326515489,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4532() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265158118,-1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test4533() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265192624,-1.5707963267948966,35.77721134503801 ) ;
  }

  @Test
  public void test4534() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265211378,-10.593685130633242,-7.969642900351229 ) ;
  }

  @Test
  public void test4535() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265232912,-10.373576737301567,0.0 ) ;
  }

  @Test
  public void test4536() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265235694,-148.4864032296617,-72.56120673044236 ) ;
  }

  @Test
  public void test4537() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265241758,-1.5707963267948963,0.5184118473945518 ) ;
  }

  @Test
  public void test4538() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265342588,-79.92173766496845,-0.30269248031546137 ) ;
  }

  @Test
  public void test4539() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265370213,-34.90870836200652,-1.5707963267948983 ) ;
  }

  @Test
  public void test4540() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265419487,-1.5707963267948966,0.517133515180916 ) ;
  }

  @Test
  public void test4541() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265440745,-4.5910980957663305,-78.00589058716147 ) ;
  }

  @Test
  public void test4542() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265458937,-3.433891772701301,100.0 ) ;
  }

  @Test
  public void test4543() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265474316,-10.93061402226573,-1.4000754152050325 ) ;
  }

  @Test
  public void test4544() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265487577,-73.15594164054366,3.6891249359176133 ) ;
  }

  @Test
  public void test4545() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265589837,-123.32838654777208,-100.0 ) ;
  }

  @Test
  public void test4546() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326561931,-0.7589626395719815,44.253539438269996 ) ;
  }

  @Test
  public void test4547() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265641567,-66.36142813919834,45.482329789740476 ) ;
  }

  @Test
  public void test4548() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326568538,-92.34630831723503,38.187367642621005 ) ;
  }

  @Test
  public void test4549() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265790927,-1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test4550() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265815392,-1.5707963267949008,-100.54210298480416 ) ;
  }

  @Test
  public void test4551() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265824203,-1.5707963267948963,-39.81191813458147 ) ;
  }

  @Test
  public void test4552() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265872198,-0.9074891043534101,51.93204042187609 ) ;
  }

  @Test
  public void test4553() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265875748,-53.51162786382139,-46.06624998520839 ) ;
  }

  @Test
  public void test4554() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265897362,-0.5863834202871172,-25.701483212238244 ) ;
  }

  @Test
  public void test4555() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326589851,-186.08958672076002,-58.8925407969809 ) ;
  }

  @Test
  public void test4556() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265916627,-60.52937749255291,-30.465800104976683 ) ;
  }

  @Test
  public void test4557() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265933245,-0.582758185453093,20.568760772338873 ) ;
  }

  @Test
  public void test4558() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963265978289,-0.46562506531419534,-38.22362186692153 ) ;
  }

  @Test
  public void test4559() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266016685,-0.11719815219176266,1.5707963267949054 ) ;
  }

  @Test
  public void test4560() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266028457,-1.5707963267948983,78.55918183539029 ) ;
  }

  @Test
  public void test4561() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326605734,-15.880184628957783,-42.26035836873453 ) ;
  }

  @Test
  public void test4562() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266075167,-1.5707963267948968,59.20674985347432 ) ;
  }

  @Test
  public void test4563() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266080913,-0.3504881744027786,-65.09330395214079 ) ;
  }

  @Test
  public void test4564() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326616953,-0.32145413095682995,72.43212613225188 ) ;
  }

  @Test
  public void test4565() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266180558,-1.5541387072533122,-50.05752596364737 ) ;
  }

  @Test
  public void test4566() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266187661,-97.5182852744001,-6.969157740441176 ) ;
  }

  @Test
  public void test4567() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266210305,-1.5707963267948966,94.77741950322104 ) ;
  }

  @Test
  public void test4568() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326628175,-48.563216414922024,-27.117620447518107 ) ;
  }

  @Test
  public void test4569() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266367395,-10.955794268478442,1.5707963267948966 ) ;
  }

  @Test
  public void test4570() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266419942,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test4571() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266479512,-78.89586157006367,-100.0 ) ;
  }

  @Test
  public void test4572() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266514173,-48.353940778794055,78.87259999867507 ) ;
  }

  @Test
  public void test4573() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266515872,-35.93274509902105,-63.37819485708518 ) ;
  }

  @Test
  public void test4574() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266548088,-9.510165707722578,1.5707963267948966 ) ;
  }

  @Test
  public void test4575() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266621774,-48.68955253622738,3.36040299055103 ) ;
  }

  @Test
  public void test4576() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326679299,-79.85323103520437,-50.72001281791332 ) ;
  }

  @Test
  public void test4577() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266809941,-35.493631378141544,-1.5707963267948983 ) ;
  }

  @Test
  public void test4578() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266865808,-1.5707963267948999,46.82070432147367 ) ;
  }

  @Test
  public void test4579() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266877458,-3.469446951953614E-18,-77.05465969956819 ) ;
  }

  @Test
  public void test4580() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963266967455,-1.1490542673957873,1.5707963267948961 ) ;
  }

  @Test
  public void test4581() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267151008,-4.710011757801823,0.4373817771096667 ) ;
  }

  @Test
  public void test4582() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326725411,-1.5707963267948966,-0.03916931428571971 ) ;
  }

  @Test
  public void test4583() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267346274,-1.5707963267948966,86.1228071417768 ) ;
  }

  @Test
  public void test4584() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267355616,-23.311948475927792,-1.5707963267948983 ) ;
  }

  @Test
  public void test4585() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326747288,-1.4066584322713984,-42.78165803955113 ) ;
  }

  @Test
  public void test4586() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326747637,-1.5707963267948983,70.54484412076505 ) ;
  }

  @Test
  public void test4587() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267544658,-85.14568727221366,0.0 ) ;
  }

  @Test
  public void test4588() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326758531,-0.25780461301558066,-1.5707963267948966 ) ;
  }

  @Test
  public void test4589() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267586165,-72.78288994257541,15.480228552510887 ) ;
  }

  @Test
  public void test4590() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632676927,-3.799274677523078,-104.20521483234148 ) ;
  }

  @Test
  public void test4591() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267727156,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4592() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267730274,-1.5707963267948966,0.37790487376502147 ) ;
  }

  @Test
  public void test4593() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267759435,-54.011456995264695,1.5707963267948966 ) ;
  }

  @Test
  public void test4594() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267769036,-1.4902846394684173,-0.30226887869273344 ) ;
  }

  @Test
  public void test4595() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267794474,-1.5707963267948912,25.193027053088628 ) ;
  }

  @Test
  public void test4596() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267822649,-1.5707963267948966,-127.14619395304784 ) ;
  }

  @Test
  public void test4597() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267824387,-48.34122540501746,-70.20743990409564 ) ;
  }

  @Test
  public void test4598() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267870129,-9.397114707975526E-17,-46.485752717734066 ) ;
  }

  @Test
  public void test4599() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267870324,-1.5707963267948966,61.114411517452794 ) ;
  }

  @Test
  public void test4600() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267876397,-97.71402177603241,0.21482878794498722 ) ;
  }

  @Test
  public void test4601() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267881369,-85.17391084626544,-18.850535641559514 ) ;
  }

  @Test
  public void test4602() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326789122,-10.367966535901333,-30.169636943475716 ) ;
  }

  @Test
  public void test4603() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267895175,-1.5707963267948903,0.0 ) ;
  }

  @Test
  public void test4604() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267897647,-1.1436081525890731,1.5707963267948966 ) ;
  }

  @Test
  public void test4605() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267913823,-54.519000796378904,20.952843348186164 ) ;
  }

  @Test
  public void test4606() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267913918,-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test4607() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267916094,-1.5707963267948966,-48.00852008568227 ) ;
  }

  @Test
  public void test4608() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267927136,-73.61409710989986,-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test4609() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267928022,-0.29136270457624036,1.5707963267948966 ) ;
  }

  @Test
  public void test4610() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793012,-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test4611() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267931,-86.30401651848157,-77.21772487513665 ) ;
  }

  @Test
  public void test4612() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267932346,-60.55695160463208,-79.52160289858573 ) ;
  }

  @Test
  public void test4613() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267933291,-22.017333419314625,0.0 ) ;
  }

  @Test
  public void test4614() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267934562,-0.1770876821716142,-0.2993211301572725 ) ;
  }

  @Test
  public void test4615() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793544,-1.5707963267948966,18.866233107314557 ) ;
  }

  @Test
  public void test4616() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267937992,-5.612451788084568E-16,-15.91211750707279 ) ;
  }

  @Test
  public void test4617() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793893,-60.061685425790024,-1.570796326794896 ) ;
  }

  @Test
  public void test4618() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326793951,-97.48244121019994,0.2799621220506709 ) ;
  }

  @Test
  public void test4619() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267940181,-1.5707963267948966,-59.774573888185316 ) ;
  }

  @Test
  public void test4620() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794101,-1.5707963267948966,-0.442403043742436 ) ;
  }

  @Test
  public void test4621() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267941367,-29.530303933528423,-48.74116081811317 ) ;
  }

  @Test
  public void test4622() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267942453,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4623() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943048,-29.53474033927884,-152.38385747625816 ) ;
  }

  @Test
  public void test4624() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943086,-92.46734783081769,-1.5707963267948966 ) ;
  }

  @Test
  public void test4625() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943115,-97.9128485601922,88.07290941089082 ) ;
  }

  @Test
  public void test4626() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794367,-0.4870488804785547,-41.07194980306461 ) ;
  }

  @Test
  public void test4627() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267943708,-1.5707963267948966,4.947330708843367 ) ;
  }

  @Test
  public void test4628() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944844,-79.40965828320915,-42.04924911892508 ) ;
  }

  @Test
  public void test4629() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267944884,-1.5707963267948966,-45.38379038332522 ) ;
  }

  @Test
  public void test4630() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794504,-1.4765661704256559,71.17505362966324 ) ;
  }

  @Test
  public void test4631() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945146,-3.1757591523753916,-84.92564620401271 ) ;
  }

  @Test
  public void test4632() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945197,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4633() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945253,-1.7763568394002505E-15,39.1302240890937 ) ;
  }

  @Test
  public void test4634() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945353,-1.5707963267948966,-182.05032171579808 ) ;
  }

  @Test
  public void test4635() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794536,-0.9552045970713721,31.40814946718504 ) ;
  }

  @Test
  public void test4636() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267945537,-1.5707963267949019,42.597249665897934 ) ;
  }

  @Test
  public void test4637() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946365,-3.1420809405577006,0.0 ) ;
  }

  @Test
  public void test4638() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946452,-0.8873920506003665,28.498490368151742 ) ;
  }

  @Test
  public void test4639() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946492,-91.98259869859821,-0.5955175049238517 ) ;
  }

  @Test
  public void test4640() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794654,-0.08878184087252874,85.72338837600914 ) ;
  }

  @Test
  public void test4641() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946674,-1.5707963267948966,31.921357295012896 ) ;
  }

  @Test
  public void test4642() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267946736,-1.5707963267948966,-83.38419234820965 ) ;
  }

  @Test
  public void test4643() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794692,-0.6759525460195488,-42.80848138109339 ) ;
  }

  @Test
  public void test4644() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947025,-41.119781686133216,0.0 ) ;
  }

  @Test
  public void test4645() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947025,-41.98867544236022,86.09160393454944 ) ;
  }

  @Test
  public void test4646() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947316,-68.51218160479169,-1.5707963267948966 ) ;
  }

  @Test
  public void test4647() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947327,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4648() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947387,-0.00814646357528416,5.184513224174935 ) ;
  }

  @Test
  public void test4649() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794742,-1.5707963267948948,-21.879362141329437 ) ;
  }

  @Test
  public void test4650() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947544,-2.7397616862605038E-194,-78.61641411821894 ) ;
  }

  @Test
  public void test4651() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947598,-1.5707963267948948,54.727967282671756 ) ;
  }

  @Test
  public void test4652() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947598,-53.976308259405535,-60.8436800884962 ) ;
  }

  @Test
  public void test4653() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947729,-2.5653355008114852E-290,27.20211424877222 ) ;
  }

  @Test
  public void test4654() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947869,-54.89322761692608,50.03827389009648 ) ;
  }

  @Test
  public void test4655() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794789,-1.5707963267948957,-1.5707963267948974 ) ;
  }

  @Test
  public void test4656() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947918,-22.44219931758619,-1117.1651039977662 ) ;
  }

  @Test
  public void test4657() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794796,-0.35689432537980686,8.881784197001252E-16 ) ;
  }

  @Test
  public void test4658() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267947989,-67.01511426814744,0.0 ) ;
  }

  @Test
  public void test4659() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948024,-1.5707963267948555,1.5707963267948966 ) ;
  }

  @Test
  public void test4660() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948053,-60.48783497320423,-55.50043359629067 ) ;
  }

  @Test
  public void test4661() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794806,-10.17050286763066,3.5042066349273 ) ;
  }

  @Test
  public void test4662() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794809,-2.0107646833859488E-87,56.80441002455001 ) ;
  }

  @Test
  public void test4663() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948095,-67.33652970378031,-67.29978883443397 ) ;
  }

  @Test
  public void test4664() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948202,-136.61686991028859,-75.39732358032475 ) ;
  }

  @Test
  public void test4665() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948273,-0.10142282166802907,-1.5707963267948957 ) ;
  }

  @Test
  public void test4666() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948308,-0.31598089734196577,100.0 ) ;
  }

  @Test
  public void test4667() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948308,-1.5566254081272215,42.81359025477991 ) ;
  }

  @Test
  public void test4668() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794833,-41.439163141376476,42.688729374751205 ) ;
  }

  @Test
  public void test4669() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948384,-79.23893822993121,-38.71354152134923 ) ;
  }

  @Test
  public void test4670() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948415,-141.69187582357173,140.89752013009607 ) ;
  }

  @Test
  public void test4671() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948422,-1.5707963267948966,1.144841728619323 ) ;
  }

  @Test
  public void test4672() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948433,-0.7303947780017188,57.36618028879636 ) ;
  }

  @Test
  public void test4673() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794845,-1.5707963267948966,-91.38096528834357 ) ;
  }

  @Test
  public void test4674() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794845,-97.81470017774356,1.5707963267948966 ) ;
  }

  @Test
  public void test4675() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948486,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4676() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948486,-9.584517113025566,6.5431554941934085 ) ;
  }

  @Test
  public void test4677() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794849,-1.5707963267948966,77.41578275211135 ) ;
  }

  @Test
  public void test4678() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679485,-1.5707963267948966,-63.509418590016516 ) ;
  }

  @Test
  public void test4679() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948521,-25.05860482496054,-84.56497139289304 ) ;
  }

  @Test
  public void test4680() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948541,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4681() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948557,-1.5707963267948966,66.16048355012109 ) ;
  }

  @Test
  public void test4682() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948557,-29.688429326124407,-29.71452203974127 ) ;
  }

  @Test
  public void test4683() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948557,-4.284104336128845,1.5707963267948966 ) ;
  }

  @Test
  public void test4684() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948593,-1.5707963267948983,-37.752749784242965 ) ;
  }

  @Test
  public void test4685() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948608,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4686() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948613,-1.5707963267948966,35.854986455755515 ) ;
  }

  @Test
  public void test4687() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948637,-1.3463634336445902,41.4135014461879 ) ;
  }

  @Test
  public void test4688() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948644,-155.35251021118134,37.48411229354966 ) ;
  }

  @Test
  public void test4689() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948657,-48.12853891828849,7.853981767388322 ) ;
  }

  @Test
  public void test4690() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948672,-1.5707963267948963,-100.0 ) ;
  }

  @Test
  public void test4691() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794868,-1.5707963267948963,0.9324390029845017 ) ;
  }

  @Test
  public void test4692() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948715,-67.08212035235309,0.10508820640372395 ) ;
  }

  @Test
  public void test4693() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4694() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-22.483427118536742,-93.55049751448053 ) ;
  }

  @Test
  public void test4695() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948728,-2.220446049250313E-16,71.42478952527236 ) ;
  }

  @Test
  public void test4696() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948732,-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test4697() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948735,-35.061232336376705,64.75459730765022 ) ;
  }

  @Test
  public void test4698() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948744,-0.5707626002087093,1.5707963267948963 ) ;
  }

  @Test
  public void test4699() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948761,-47.42225744489805,32.43235115852563 ) ;
  }

  @Test
  public void test4700() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948766,-1.570796326794897,0.0 ) ;
  }

  @Test
  public void test4701() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-135.2060332335389,-1.5707963267948966 ) ;
  }

  @Test
  public void test4702() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-1.5707963267948966,42.002223273696416 ) ;
  }

  @Test
  public void test4703() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-29.594419716981434,-51.212224517570924 ) ;
  }

  @Test
  public void test4704() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679487,-73.03233433683098,-1.5707963267948966 ) ;
  }

  @Test
  public void test4705() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-35.509855725067794,-84.44201420620047 ) ;
  }

  @Test
  public void test4706() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-3.552713678800501E-15,-9.946766596303206 ) ;
  }

  @Test
  public void test4707() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-53.93515162137483,-8.007545075116226 ) ;
  }

  @Test
  public void test4708() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794877,-72.63333555910894,56.70219940493398 ) ;
  }

  @Test
  public void test4709() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948784,-1.5707963267948966,82.03678260583884 ) ;
  }

  @Test
  public void test4710() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948788,-0.3157949933350104,56.12720219978386 ) ;
  }

  @Test
  public void test4711() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948806,-60.148307041223916,1.5707963267948966 ) ;
  }

  @Test
  public void test4712() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794881,-0.21849493799321262,-31.655290593482068 ) ;
  }

  @Test
  public void test4713() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948812,-0.2123259653231385,10.832255655129401 ) ;
  }

  @Test
  public void test4714() {
    coral.tests.JPFBenchmark.benchmark05(-1.57079632679488,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test4715() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948821,-1.5707963267948966,42.1906721474368 ) ;
  }

  @Test
  public void test4716() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948828,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4717() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-0.4563509636463392,92.60038257689746 ) ;
  }

  @Test
  public void test4718() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-0.4669949502303667,18.27600998358927 ) ;
  }

  @Test
  public void test4719() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-23.02688449130884,1.422685445202184 ) ;
  }

  @Test
  public void test4720() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-23.33141705415656,-31.27511259862696 ) ;
  }

  @Test
  public void test4721() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-28.343505973402614,35.90917573243077 ) ;
  }

  @Test
  public void test4722() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-3.4799444704327733,-73.7556926915442 ) ;
  }

  @Test
  public void test4723() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-66.90022814654597,6.697436356679987 ) ;
  }

  @Test
  public void test4724() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-73.74316368162766,-22.047271644745788 ) ;
  }

  @Test
  public void test4725() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948841,-78.72874940170948,-0.11908557728088454 ) ;
  }

  @Test
  public void test4726() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948843,-16.692813396972102,-1.5707963267948966 ) ;
  }

  @Test
  public void test4727() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948848,-78.88709143953166,77.5156072294912 ) ;
  }

  @Test
  public void test4728() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948852,-92.17283842900538,89.29105412737714 ) ;
  }

  @Test
  public void test4729() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948861,-1.5707963267948983,-3.1099053049854746 ) ;
  }

  @Test
  public void test4730() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794886,-22.151177938225942,-100.0 ) ;
  }

  @Test
  public void test4731() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948872,-1.3485176005362465,-33.13166583232231 ) ;
  }

  @Test
  public void test4732() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-10.728455836008322,-86.2043247993673 ) ;
  }

  @Test
  public void test4733() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-1.5707963267948966,-36.958625008787166 ) ;
  }

  @Test
  public void test4734() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794887,-73.5815343696476,-1.5707963267948966 ) ;
  }

  @Test
  public void test4735() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-42.10456279737051,90.03942879591376 ) ;
  }

  @Test
  public void test4736() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-53.40707511102649,0 ) ;
  }

  @Test
  public void test4737() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948877,-54.412118796972095,-3.4213266693002424 ) ;
  }

  @Test
  public void test4738() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948883,-97.67092225254707,1.5707963267948966 ) ;
  }

  @Test
  public void test4739() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948886,-1.5707963267948948,-25.13664778518495 ) ;
  }

  @Test
  public void test4740() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948886,-29.41381770745919,-48.44496485000254 ) ;
  }

  @Test
  public void test4741() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,0.3632639497666204 ) ;
  }

  @Test
  public void test4742() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,-23.60062139823853 ) ;
  }

  @Test
  public void test4743() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,82.44469761809209 ) ;
  }

  @Test
  public void test4744() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-1.5707963267948966,-9.534542431671525 ) ;
  }

  @Test
  public void test4745() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-3.1704103516866278,1.5707963267948966 ) ;
  }

  @Test
  public void test4746() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948888,-40.91603603923927,-1.5707963267949125 ) ;
  }

  @Test
  public void test4747() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948892,-54.292496699043895,-164.1954765255851 ) ;
  }

  @Test
  public void test4748() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948892,-7.711743568329229E-180,79.29809279545744 ) ;
  }

  @Test
  public void test4749() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-42.28602862807478,-10.380738170526575 ) ;
  }

  @Test
  public void test4750() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-47.18327260847191,-91.57856464452921 ) ;
  }

  @Test
  public void test4751() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948895,-79.63915917684363,-76.44104356351464 ) ;
  }

  @Test
  public void test4752() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,-1.4992957060059788,-0.3659760789776242 ) ;
  }

  @Test
  public void test4753() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948901,4.141592653600804,0.0 ) ;
  }

  @Test
  public void test4754() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-0.9941949876901727,-67.54641686064481 ) ;
  }

  @Test
  public void test4755() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948903,-48.32425367295059,-1.5707963267948966 ) ;
  }

  @Test
  public void test4756() {
    coral.tests.JPFBenchmark.benchmark05(-1.570796326794891,-1.5707963267948966,-39.675263304222696 ) ;
  }

  @Test
  public void test4757() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.01629248398938842,75.61195215561062 ) ;
  }

  @Test
  public void test4758() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.054119719109408486,-68.00946907139003 ) ;
  }

  @Test
  public void test4759() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.10032768982938756,45.38502262674541 ) ;
  }

  @Test
  public void test4760() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.17305461790435245,53.723281063810475 ) ;
  }

  @Test
  public void test4761() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.1965993274274339,-1.3874184048253002 ) ;
  }

  @Test
  public void test4762() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.19985802791207563,39.87472250976944 ) ;
  }

  @Test
  public void test4763() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.21480781880151242,90.05430947165763 ) ;
  }

  @Test
  public void test4764() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.22601917779109212,-41.5197320486776 ) ;
  }

  @Test
  public void test4765() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.2604103057533617,3.1420810982033274 ) ;
  }

  @Test
  public void test4766() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3441016186511403,4.146925774960678 ) ;
  }

  @Test
  public void test4767() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3575732834507648,-9.456931645808424 ) ;
  }

  @Test
  public void test4768() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.3613635910667057,76.4800611788161 ) ;
  }

  @Test
  public void test4769() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.4529078931493099,-66.70676444267491 ) ;
  }

  @Test
  public void test4770() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.508800032835159,29.180376308075296 ) ;
  }

  @Test
  public void test4771() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.5798265180081991,37.83396339390974 ) ;
  }

  @Test
  public void test4772() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.608018349909619,47.81043404222018 ) ;
  }

  @Test
  public void test4773() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.6263778731299101,21.383579452102456 ) ;
  }

  @Test
  public void test4774() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.639753896180796,47.138273929150046 ) ;
  }

  @Test
  public void test4775() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.7057483736039722,15.995136151698148 ) ;
  }

  @Test
  public void test4776() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-0.9006904749402602,-30.25638773426334 ) ;
  }

  @Test
  public void test4777() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.007309057099846,-52.84691256517067 ) ;
  }

  @Test
  public void test4778() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.111500433747334,65.59874124090423 ) ;
  }

  @Test
  public void test4779() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.262197403322519,48.73991939951303 ) ;
  }

  @Test
  public void test4780() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.419828763289868,8.576684824799912 ) ;
  }

  @Test
  public void test4781() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.424777960769049,-28.27089664987848 ) ;
  }

  @Test
  public void test4782() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.442624480615176,0.0 ) ;
  }

  @Test
  public void test4783() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.704581465790888,-77.18125040877557 ) ;
  }

  @Test
  public void test4784() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.766265492635966,-60.71733881980781 ) ;
  }

  @Test
  public void test4785() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-10.987162364474166,-1.5707963267948966 ) ;
  }

  @Test
  public void test4786() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-110.81809337220436,-42.95187365625692 ) ;
  }

  @Test
  public void test4787() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-122.80520262182121,-272.82139403388817 ) ;
  }

  @Test
  public void test4788() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-123.1683487487809,-67.50121358182923 ) ;
  }

  @Test
  public void test4789() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.2538628496705027,78.35241861932843 ) ;
  }

  @Test
  public void test4790() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.2597438067987525,16.045365475417526 ) ;
  }

  @Test
  public void test4791() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-135.3540122301517,315.2600189538912 ) ;
  }

  @Test
  public void test4792() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-135.5478385149655,-66.45869299807222 ) ;
  }

  @Test
  public void test4793() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3589721293612291,86.2342162560912 ) ;
  }

  @Test
  public void test4794() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.3624576431259356,78.31592266717351 ) ;
  }

  @Test
  public void test4795() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-136.37411707342918,-6.533196780999469 ) ;
  }

  @Test
  public void test4796() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-136.5985648496023,63.19581753101852 ) ;
  }

  @Test
  public void test4797() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4124963626766451,-91.06540449081409 ) ;
  }

  @Test
  public void test4798() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4132251374813325,41.98846618453331 ) ;
  }

  @Test
  public void test4799() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.4902045307842027,26.961938840219716 ) ;
  }

  @Test
  public void test4800() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5053741509694087,-38.01515868419196 ) ;
  }

  @Test
  public void test4801() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5059453089098884,-1.570796326796388 ) ;
  }

  @Test
  public void test4802() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5164699267639183,104.81501443989231 ) ;
  }

  @Test
  public void test4803() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.565726128065731,-27.81247125918508 ) ;
  }

  @Test
  public void test4804() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963265609584,20.64241818495684 ) ;
  }

  @Test
  public void test4805() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.570796326792527,71.04142120464189 ) ;
  }

  @Test
  public void test4806() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948912,78.21699086250104 ) ;
  }

  @Test
  public void test4807() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948921,-71.31741926936654 ) ;
  }

  @Test
  public void test4808() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.570796326794893,-18.53562651618897 ) ;
  }

  @Test
  public void test4809() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,-32.8708628609303 ) ;
  }

  @Test
  public void test4810() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,53.25713407506598 ) ;
  }

  @Test
  public void test4811() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948948,89.04321630090428 ) ;
  }

  @Test
  public void test4812() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948961,21.80330242677967 ) ;
  }

  @Test
  public void test4813() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948963,-25.135769070842727 ) ;
  }

  @Test
  public void test4814() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948963,-8.944809989741211 ) ;
  }

  @Test
  public void test4815() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4816() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,0.33075044278197985 ) ;
  }

  @Test
  public void test4817() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-1.1234629090132557 ) ;
  }

  @Test
  public void test4818() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,12.419264689691413 ) ;
  }

  @Test
  public void test4819() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test4820() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test4821() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,1.5707963325809389 ) ;
  }

  @Test
  public void test4822() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,19.369949206788036 ) ;
  }

  @Test
  public void test4823() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,20.087738901525825 ) ;
  }

  @Test
  public void test4824() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,27.16896121345009 ) ;
  }

  @Test
  public void test4825() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-31.816345775858878 ) ;
  }

  @Test
  public void test4826() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,34.274088440545654 ) ;
  }

  @Test
  public void test4827() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,47.687333227489574 ) ;
  }

  @Test
  public void test4828() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-64.9851448479746 ) ;
  }

  @Test
  public void test4829() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,66.98750908708624 ) ;
  }

  @Test
  public void test4830() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,-67.9238651446958 ) ;
  }

  @Test
  public void test4831() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,78.41481707708508 ) ;
  }

  @Test
  public void test4832() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,78.89681048714246 ) ;
  }

  @Test
  public void test4833() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-1.5707963267948966,97.93234235627355 ) ;
  }

  @Test
  public void test4834() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.74787813387649,-23.03978564536016 ) ;
  }

  @Test
  public void test4835() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.767593335981978,36.102444888279095 ) ;
  }

  @Test
  public void test4836() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.820619484496916,-1.570796327387429 ) ;
  }

  @Test
  public void test4837() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-15.823168261759342,-55.98251381434386 ) ;
  }

  @Test
  public void test4838() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-160.24172157163153,40.148402528943166 ) ;
  }

  @Test
  public void test4839() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.125620231570466,42.74383644828199 ) ;
  }

  @Test
  public void test4840() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.33575003388873,-90.06265464943307 ) ;
  }

  @Test
  public void test4841() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.349305490713007,1.5707963267948912 ) ;
  }

  @Test
  public void test4842() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.404742320239315,-65.49783387882289 ) ;
  }

  @Test
  public void test4843() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.6538734350972,-6.465062498477982 ) ;
  }

  @Test
  public void test4844() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.848243284197423,0.0 ) ;
  }

  @Test
  public void test4845() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-16.937095395288807,76.70724243445875 ) ;
  }

  @Test
  public void test4846() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-17.03914021536678,-1.2203438157533928 ) ;
  }

  @Test
  public void test4847() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-17.18636635601996,-15.216921529692897 ) ;
  }

  @Test
  public void test4848() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-17.222832061254167,-6.005681805141776 ) ;
  }

  @Test
  public void test4849() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-17.23826600876204,-172.78839529195523 ) ;
  }

  @Test
  public void test4850() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,1.734723475976807E-18,7.627051989290924 ) ;
  }

  @Test
  public void test4851() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-2.220446049250313E-16,2.1541874074619636E-16 ) ;
  }

  @Test
  public void test4852() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.451219478990993,-9.487078719273427 ) ;
  }

  @Test
  public void test4853() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.569185271237156,0.0 ) ;
  }

  @Test
  public void test4854() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.62758145662083,-15.76556234200767 ) ;
  }

  @Test
  public void test4855() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.758689150978626,-89.63686016171921 ) ;
  }

  @Test
  public void test4856() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-22.790019865538255,5.379402595273476 ) ;
  }

  @Test
  public void test4857() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.180126003473024,-13.829119073476342 ) ;
  }

  @Test
  public void test4858() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-23.224961546770402,-42.102750311166396 ) ;
  }

  @Test
  public void test4859() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-242.3437230397335,-186.23380721957267 ) ;
  }

  @Test
  public void test4860() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-2.465190328815662E-32,30.730471291461146 ) ;
  }

  @Test
  public void test4861() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.390837653274406,40.49391987356364 ) ;
  }

  @Test
  public void test4862() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.61687266559278,-64.79244991415607 ) ;
  }

  @Test
  public void test4863() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,28.703537555515616,-99.96778894759179 ) ;
  }

  @Test
  public void test4864() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-28.837918732964,-51.39757202575043 ) ;
  }

  @Test
  public void test4865() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.0030087697301,-60.37504562116135 ) ;
  }

  @Test
  public void test4866() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.301012931090636,2436.721794352952 ) ;
  }

  @Test
  public void test4867() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.36402329308367,-6.5688036857846015 ) ;
  }

  @Test
  public void test4868() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.495357618741465,0.0 ) ;
  }

  @Test
  public void test4869() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-29.65239777746525,-69.31348339768324 ) ;
  }

  @Test
  public void test4870() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-305.72625414267577,-12.377453319434409 ) ;
  }

  @Test
  public void test4871() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1420312980214464,6.747046840589249 ) ;
  }

  @Test
  public void test4872() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.1664791201462306,-20.00103333979256 ) ;
  }

  @Test
  public void test4873() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.2298621832315764,-79.45345644217309 ) ;
  }

  @Test
  public void test4874() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.2665926535897936,17.108350172354953 ) ;
  }

  @Test
  public void test4875() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.365937987893966E-13,-0.0027334765218087983 ) ;
  }

  @Test
  public void test4876() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.55849575285229,1.5707963267948966 ) ;
  }

  @Test
  public void test4877() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.58772007264811,113.3986559838478 ) ;
  }

  @Test
  public void test4878() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.599576689864655,77.28981069680584 ) ;
  }

  @Test
  public void test4879() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.64691214373869,129.64024314600087 ) ;
  }

  @Test
  public void test4880() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.64808760352691,-21.475266898935935 ) ;
  }

  @Test
  public void test4881() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-34.939198720066145,-0.4031185739224417 ) ;
  }

  @Test
  public void test4882() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.005485967602695,-9.55048843124706 ) ;
  }

  @Test
  public void test4883() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.5091866432220655,-64.18705701810032 ) ;
  }

  @Test
  public void test4884() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.5398830996238644,-1.5707963267948912 ) ;
  }

  @Test
  public void test4885() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.443465951119734,88.79795762268903 ) ;
  }

  @Test
  public void test4886() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.55958838175192,-58.596325197699024 ) ;
  }

  @Test
  public void test4887() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.655748376472346,56.371861046187945 ) ;
  }

  @Test
  public void test4888() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.77414343007247,-23.448211293828336 ) ;
  }

  @Test
  public void test4889() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.791487802198276,0.8398139704137578 ) ;
  }

  @Test
  public void test4890() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.82951544265585,59.157747112063774 ) ;
  }

  @Test
  public void test4891() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-35.905213776528235,-15.305175593467187 ) ;
  }

  @Test
  public void test4892() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-36.049419929019535,-57.58855885716143 ) ;
  }

  @Test
  public void test4893() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.7935060734671566,1.5707963267948963 ) ;
  }

  @Test
  public void test4894() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.798716704108929,2.062400512111335 ) ;
  }

  @Test
  public void test4895() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.847804311894924,9.367430104106518 ) ;
  }

  @Test
  public void test4896() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-38.7589188569121,-41.671438765941275 ) ;
  }

  @Test
  public void test4897() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-3.8901164434086155,88.67059241868839 ) ;
  }

  @Test
  public void test4898() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.057688257603282,86.58247078855513 ) ;
  }

  @Test
  public void test4899() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.002018705608265,63.19956032838611 ) ;
  }

  @Test
  public void test4900() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.00966482111855,47.00463503829285 ) ;
  }

  @Test
  public void test4901() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.11227538684703,-18.84325209138528 ) ;
  }

  @Test
  public void test4902() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.25652645329667,-113.10215904683578 ) ;
  }

  @Test
  public void test4903() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.30159377047462,82.0839330378563 ) ;
  }

  @Test
  public void test4904() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.32005480463284,-91.83364059619865 ) ;
  }

  @Test
  public void test4905() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.141592653767017,-25.384340169405714 ) ;
  }

  @Test
  public void test4906() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.426840367609906,-75.84979822768601 ) ;
  }

  @Test
  public void test4907() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.446433063110135,82.36098781185784 ) ;
  }

  @Test
  public void test4908() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.59382686380815,1.5707963267948966 ) ;
  }

  @Test
  public void test4909() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.60948716122235,49.747039023693816 ) ;
  }

  @Test
  public void test4910() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-41.901274795128394,96.45672394770395 ) ;
  }

  @Test
  public void test4911() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.07180011784583,-129.45810456554977 ) ;
  }

  @Test
  public void test4912() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.174745059729986,74.42798914234442 ) ;
  }

  @Test
  public void test4913() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-42.25734435576293,19.700797716676647 ) ;
  }

  @Test
  public void test4914() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.258622420433293,4.148762638545873 ) ;
  }

  @Test
  public void test4915() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.431131043067632,-100.0 ) ;
  }

  @Test
  public void test4916() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.576494066700546,-35.76611689866913 ) ;
  }

  @Test
  public void test4917() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-4.690709765566538,1.5707963267948966 ) ;
  }

  @Test
  public void test4918() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.53859147343147,-87.45892012658373 ) ;
  }

  @Test
  public void test4919() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.70876390649151,5.14159293849446 ) ;
  }

  @Test
  public void test4920() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-47.72920503286255,0.0 ) ;
  }

  @Test
  public void test4921() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-481.66367073494547,-6.375158702675154 ) ;
  }

  @Test
  public void test4922() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.41422019425201,15.80466422874608 ) ;
  }

  @Test
  public void test4923() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.45791968647528,-777.5240059393404 ) ;
  }

  @Test
  public void test4924() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.54212425815857,2323.1445795367135 ) ;
  }

  @Test
  public void test4925() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-48.60993606037039,-51.51926790785847 ) ;
  }

  @Test
  public void test4926() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.52211890826496,87.50891259658907 ) ;
  }

  @Test
  public void test4927() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.74845654744785,-84.59571193151307 ) ;
  }

  @Test
  public void test4928() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.82177106266754,-39.98807321465496 ) ;
  }

  @Test
  public void test4929() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-53.849000464409706,-1387.6304045932889 ) ;
  }

  @Test
  public void test4930() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.1080026963479,-56.34788275174301 ) ;
  }

  @Test
  public void test4931() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.389529530524115,-20.478911181965955 ) ;
  }

  @Test
  public void test4932() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.44026524438386,56.55824282332637 ) ;
  }

  @Test
  public void test4933() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.465009304778945,0.0 ) ;
  }

  @Test
  public void test4934() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.652017865363234,-84.90802485347051 ) ;
  }

  @Test
  public void test4935() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.68614450613806,-48.46573477224632 ) ;
  }

  @Test
  public void test4936() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.713228046745634,72.12837908004579 ) ;
  }

  @Test
  public void test4937() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.78225105781047,-41.571571642420004 ) ;
  }

  @Test
  public void test4938() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.83185211569639,-58.17432612073048 ) ;
  }

  @Test
  public void test4939() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-54.865234412414424,-77.9803125770429 ) ;
  }

  @Test
  public void test4940() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-55.182954994789725,47.05865599531366 ) ;
  }

  @Test
  public void test4941() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-5.551115123125783E-17,59.96932315686982 ) ;
  }

  @Test
  public void test4942() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-59.80757461772843,26.359300311439444 ) ;
  }

  @Test
  public void test4943() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.148362438054434,-55.493972824357954 ) ;
  }

  @Test
  public void test4944() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.149319497905985,0.0 ) ;
  }

  @Test
  public void test4945() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.37992220791622,-1.5707963267948966 ) ;
  }

  @Test
  public void test4946() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.48154755328504,-1.5707963267948966 ) ;
  }

  @Test
  public void test4947() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.58277696562833,1.5707963267948966 ) ;
  }

  @Test
  public void test4948() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.65156914914631,-69.25199209655716 ) ;
  }

  @Test
  public void test4949() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.76398002416039,1011.5803262946192 ) ;
  }

  @Test
  public void test4950() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.76653698661374,-94.75058244580265 ) ;
  }

  @Test
  public void test4951() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.780447557023805,0.8834568281972972 ) ;
  }

  @Test
  public void test4952() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.783196988777306,40.33497564662264 ) ;
  }

  @Test
  public void test4953() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-60.90566746016052,13.72926474319523 ) ;
  }

  @Test
  public void test4954() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-61.0206946877478,-63.58566163481913 ) ;
  }

  @Test
  public void test4955() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.03879824690762,71.54130021205344 ) ;
  }

  @Test
  public void test4956() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.07688083352852,0.22768026305530542 ) ;
  }

  @Test
  public void test4957() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.10529485436777,-39.15610636393012 ) ;
  }

  @Test
  public void test4958() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.37874600885267,1.5707963267948968 ) ;
  }

  @Test
  public void test4959() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.39169294512293,327.6323042526901 ) ;
  }

  @Test
  public void test4960() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.41623706497535,-5.169878828456423E-26 ) ;
  }

  @Test
  public void test4961() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.54104878181035,-24.430034289777566 ) ;
  }

  @Test
  public void test4962() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.58798545063632,26.76083681450182 ) ;
  }

  @Test
  public void test4963() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.6398740800952,1.5707963267948983 ) ;
  }

  @Test
  public void test4964() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.65517221586222,-25.13227750293774 ) ;
  }

  @Test
  public void test4965() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-66.80777176493339,-77.17596303787192 ) ;
  }

  @Test
  public void test4966() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.04867976210912,0.0 ) ;
  }

  @Test
  public void test4967() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.07737667096175,-4.564091122467052E-17 ) ;
  }

  @Test
  public void test4968() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.37330406798583,-100.0 ) ;
  }

  @Test
  public void test4969() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.44902706397843,-79.36088936688404 ) ;
  }

  @Test
  public void test4970() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.45700890223623,20.15426102978215 ) ;
  }

  @Test
  public void test4971() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.50268872050214,-38.64777457509989 ) ;
  }

  @Test
  public void test4972() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.5221984500341,-0.03371929114743874 ) ;
  }

  @Test
  public void test4973() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-67.53041790367388,-6.533185307249028 ) ;
  }

  @Test
  public void test4974() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.35223436931665,-77.46447922916296 ) ;
  }

  @Test
  public void test4975() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.42193337534147,19.362570657949583 ) ;
  }

  @Test
  public void test4976() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.44023936656889,1.5707963267948966 ) ;
  }

  @Test
  public void test4977() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.50554485503966,-8.103982690080873 ) ;
  }

  @Test
  public void test4978() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.54036365212012,-16.224608569189343 ) ;
  }

  @Test
  public void test4979() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.55185802879744,-91.50540798266414 ) ;
  }

  @Test
  public void test4980() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.57348623940345,-100.0 ) ;
  }

  @Test
  public void test4981() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.70935693331656,0.0 ) ;
  }

  @Test
  public void test4982() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-72.89206735763426,0.6743613773490837 ) ;
  }

  @Test
  public void test4983() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.36346476579254,-22.759856910867867 ) ;
  }

  @Test
  public void test4984() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.38368629116928,0.07779810170176593 ) ;
  }

  @Test
  public void test4985() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.39282933139935,-3.1494051535905387 ) ;
  }

  @Test
  public void test4986() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.53897656367523,-52.46612052842485 ) ;
  }

  @Test
  public void test4987() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.55859442030254,-63.0562298522524 ) ;
  }

  @Test
  public void test4988() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-73.8103535895754,-73.1365776508945 ) ;
  }

  @Test
  public void test4989() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,7.723192932417697E-17,83.31774238583493 ) ;
  }

  @Test
  public void test4990() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.71573041406657,1.5707963267948966 ) ;
  }

  @Test
  public void test4991() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-78.7427165780391,-108.62092916943409 ) ;
  }

  @Test
  public void test4992() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.00316643654652,-7.853981678765218 ) ;
  }

  @Test
  public void test4993() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.32927411714171,-1.5707963267948966 ) ;
  }

  @Test
  public void test4994() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.5239287593987,-103.84545375249888 ) ;
  }

  @Test
  public void test4995() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.65959966861122,-975.7725832851431 ) ;
  }

  @Test
  public void test4996() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.81366036944726,-86.39379797371932 ) ;
  }

  @Test
  public void test4997() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-79.9832786639358,-187.12102605761237 ) ;
  }

  @Test
  public void test4998() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-80.03175305922663,-75.96365010259083 ) ;
  }

  @Test
  public void test4999() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-80.06029798430892,1.5707963267948983 ) ;
  }

  @Test
  public void test5000() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-82.42315843711559,-29.52317610023944 ) ;
  }

  @Test
  public void test5001() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.91353856956401,-42.54625313831349 ) ;
  }

  @Test
  public void test5002() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-84.96632798735067,-42.55427907811886 ) ;
  }

  @Test
  public void test5003() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-85.03014709589274,38.87047009527694 ) ;
  }

  @Test
  public void test5004() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-85.1154066847366,-89.83411052302306 ) ;
  }

  @Test
  public void test5005() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-85.53323366546766,76.52765867770256 ) ;
  }

  @Test
  public void test5006() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.30913530458142,0.0 ) ;
  }

  @Test
  public void test5007() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.65445388863215,-77.13631731770408 ) ;
  }

  @Test
  public void test5008() {
    coral.tests.JPFBenchmark.benchmark05(-1.5707963267948912,-91.66168616798392,-1.5707963267948983 ) ;
  }
}
