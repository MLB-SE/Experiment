import org.junit.Test;

public class Sample19Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark19(-0.8136516866112515,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark19(-1.0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark19(1.0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark19(-1.000000000000007,-1.1102230246251565E-16,-1.0000000000002014 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.035725869834868584,-1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.035747919088537694,-0.7394392186581226 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.03577376410402254,-1.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.03992318583006926,-1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.047915645449593536,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.05405446896652444,-0.2873712043061869 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-0.9999999999999996,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-1.1102230246251565E-16,0.9999999999999999 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-2007.0126172531313,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark19(-100.0,-5.551115123125783E-17,-100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark19(-1.1560992037563693,-0.03674361671718607,-21.418859307554754 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark19(-14.260583286715914,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark19(-15.593863134171333,-2.220446049250313E-16,43.70116936388079 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark19(-16.88201784031436,-0.05520391280367058,-69.35723463581787 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark19(17.109844306196038,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark19(-19.152849597353615,-0.001845429701624164,3.4081055078013485 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark19(-2.0344128330513485,-0.038115030429280744,-0.9999999999999998 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark19(-2.1796565770518868,-1.1102230246251565E-16,-0.9999999999999999 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark19(-23.262418521473634,-0.0187681186498287,-0.0017824876333481594 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark19(-26.293488230962183,-0.010855293487158413,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark19(-32.88725962378176,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark19(-33.740356834556756,-0.02568217846790553,-0.9999999999754621 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark19(-33.87667858187585,-0.061748039139822276,0.21771773053469598 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark19(-34.588520692543725,-0.05242348228193541,-0.3943337504327644 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark19(-36.55473040251604,-0.04181714193555116,-0.9999999999999982 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark19(-36.740042164238574,-0.04405719134430516,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark19(-38.542720521477534,-0.8344583894139725,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark19(-38.55755982516109,-0.0472378794402637,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark19(-40.100590593852864,0.0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark19(-41.29833117783839,-0.04799673658291426,-0.5097503548632432 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark19(-42.821856502749235,-0.01686473086844703,-0.5391858378331449 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark19(-43.86267851595027,-4.440892098500626E-16,0.9999999999999982 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark19(-44.83953710047917,-0.05908942711673475,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark19(-45.76732756986137,-0.014587330139875121,-0.29512402502037105 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark19(-50.946044130561205,-1.04E-322,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark19(-51.90097395361166,-0.02072221251053996,-22.468691459640173 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark19(-52.87281664739068,-0.042966725056324206,0.885448898719243 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark19(-53.143503789481535,-1.1102230246251565E-16,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark19(-58.00987573760733,-0.04177747870160033,-6.762355656246993E-14 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark19(-58.397127831741955,-0.011457811557492065,52.150895338055335 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark19(-59.414821229217,-0.03529042490290468,87.8337961292181 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark19(-60.2750813529912,-24.63060851929491,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark19(-60.57442149098665,-1.7763568394002505E-15,-0.9694380357553034 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark19(-60.96562411752327,-0.032478066513732945,0.9999999999756464 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark19(-61.83585343981717,-22.384936085573088,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark19(-62.59836251782512,-0.02109885580033527,4.6044233315940017E-26 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark19(-63.09328382918091,-5.551115123125783E-17,0.08327671074770904 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark19(-64.14158426291246,-0.02251725898389667,1.0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark19(-64.93028809255608,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark19(-66.42142902661466,-1.0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark19(69.64729451551463,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark19(-69.81404253879968,-5.551115123125783E-17,-0.7542682378263379 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark19(-79.42892148760225,-3.2085108243673233,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark19(-80.03903179501702,-0.031398429670360495,-0.16465051999798164 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark19(-82.14333498515444,-0.029398773483166378,-0.8004061132143505 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark19(-85.05337213666928,-8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark19(-86.0165443132484,-0.04598846291004359,-0.7071067811865476 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark19(-87.17588379899807,-0.03774410462299574,-0.08005280086539689 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark19(-87.72017555932395,-0.005250486516563235,-24.779640941907857 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark19(-87.82441079215977,-0.029432594335454837,0.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark19(-88.35764886217625,-0.05800531266396844,-0.8358495870422615 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark19(-88.8327418518951,-0.041382936449605445,-0.2193817345475395 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark19(-89.27390848592086,-43.39856678971501,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark19(-89.28158178129888,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark19(-90.03236222547076,-0.019310554964437454,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark19(-90.52758169179148,-0.05380001615211408,-0.9999999995772368 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark19(-9.096385463481893,-0.02409380612893633,-1.433443251980196E-36 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark19(-93.73122428556219,20.61725506906764,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark19(-9.44719977536414,-0.029167486730614978,-1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark19(-96.86873564954693,-0.005562025718188313,-0.007303020131431026 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark19(-98.19477207177329,1.9721522630525295E-31,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark19(-99.0626485736042,-2172.136193023877,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark19(-99.32873153541598,-0.03832367793714204,-0.14266540478629808 ) ;
  }
}
