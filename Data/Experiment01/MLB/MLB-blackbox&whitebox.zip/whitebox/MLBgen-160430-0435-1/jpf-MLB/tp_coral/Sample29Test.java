import org.junit.Test;

public class Sample29Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark29(13.329203869197556 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark29(-1.4941406249999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark29(-1.494140625 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark29(15.315141560276444 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark29(-16.569358196137614 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark29(-16.86857623751301 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark29(-20.153632970644836 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark29(-22.611605328565915 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark29(-23.258116637656485 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark29(-2.8865811675336204 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark29(38.512912585240485 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark29(-40.113688027955696 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark29(-40.19119083755678 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark29(-40.19140625 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark29(-709.1292779342216 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark29(-709.4379288247242 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark29(-709.477083610069 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark29(-709.6196225070288 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark29(-709.6440384186716 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark29(-709.8227671629929 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark29(-709.8548338701833 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark29(-709.9067433456614 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark29(-709.9726599511533 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark29(-709.9884849904888 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark29(-709.9960097811595 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark29(-709.9967903356544 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark29(-709.9988642604907 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark29(-710.4944360923457 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark29(-715.3989309164349 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark29(-717.1336287849641 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark29(-720.1916998380128 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark29(-721.022601117976 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark29(-727.2226958652627 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark29(-733.6758102877732 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark29(73.38007777524848 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark29(-742.7379710823657 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark29(-745.2445024448174 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark29(-745.2652948788779 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999851 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark29(-745.9999999999998 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark29(-746.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark29(-746.000000000031 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark29(-746.0000000000518 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark29(-747.1914062500748 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark29(-748.1914062502176 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark29(-760.5956287817515 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark29(774.6299236141663 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark29(-78.84092442880527 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark29(-87.86518306602997 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark29(95.51519864699395 ) ;
  }
}
