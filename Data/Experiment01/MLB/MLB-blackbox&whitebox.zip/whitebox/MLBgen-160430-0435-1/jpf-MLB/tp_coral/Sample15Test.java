import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(-0.4477232290774964,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(1.0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000036,-0.001495877226888806,0.36759284603873876,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark15(-1.0000000000000036,2.584611943954799,0,-99.80733886639503 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.001436798820939762,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002163528549438641,-2.0194839173657902E-28,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0022185523079053127,0.0,0.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0025462303755879444,99.76339366565124,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002571536007602959,-54.102535170868066,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026236539782920746,-1.0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026290172573491593,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026298406372043674,0,99.99965917446441 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002629840638792825,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.0026298409355215435,0,0.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.002762934497977465,-4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.007284411121772119,0.0,-21.258583069404594 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.009240769693759641,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,0.02644395630297781,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.07764551230992589,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.1356766222571356,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-0.21046983486341697,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.1102230246251565E-16,2115.470490185216,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,-1.5707963267948886,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark15(-100.0,6.429612188777807,-1.0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark15(-10.523621082966386,-70.46376140707169,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark15(-10.731163457169089,-1.5707963267947953,0,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark15(-1.0856282597311542,-1.0617812266077635E-6,-1.0000000003321146,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark15(1.3331656107989858,-81.82342711903397,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark15(-13.419142411818482,14.42931367602447,1.0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark15(-14.079896564308715,-5.358752669904904E-4,-1.0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark15(-14.158031848311097,54.23983545364081,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark15(-14.287277483667104,-0.0026298406388801238,-21.513384942973687,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark15(-14.907287960160659,-57.32057312589922,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark15(-166.41257611773844,-0.44606965803172305,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark15(-17.047499670289312,-44.75111587182292,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark15(-17.103165414439637,-0.002550816637620799,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark15(-17.987108834147175,-0.002619706682663065,-100.0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark15(-18.68207339159791,-2633.2793442208263,0,0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark15(-18.935280911949924,-0.001309906149134912,0.0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark15(-19.009355194280964,-0.0026298433122414677,0,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark15(-19.16923663270553,3.583027376257149,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark15(-19.530912623026737,-1.338922718249023,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark15(-20.411871670238497,-1.2438419529631801,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark15(-20.67094279707564,-9.514292311633039E-4,-100.0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark15(-21.55870132465144,-0.0024024212599907933,-92.22984690539467,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark15(-21.599392753582897,-3.5601605621864414E-11,-94.22027366764874,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark15(-2.185337199935759,-0.3533141434992899,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark15(-23.19503709357413,0.0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark15(-23.61147652901165,2.6660811771193482,-47.42886996654436,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark15(-23.806754114115265,-23.489920984457015,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark15(-23.846457567864604,-0.3841995771999436,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark15(-28.207302876561027,-0.0026298406388948073,0.0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark15(-28.39989926260069,14.429203677312124,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark15(-28.583926863359395,-45.03079271893835,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark15(-28.87530692716624,-0.021932364337641536,-43.39314643849104,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark15(-32.930601438357485,-0.03984004670879013,-2137.294920633887,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark15(-36.06786803965064,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark15(-36.28431091567443,-0.005411295996623336,-909.4348567719144,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark15(-36.67110705165696,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark15(-3.698986474362137,-0.021674324345838464,0.0,-53.91263650708214 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark15(-37.19782924635826,-1.1102230246251565E-16,-1.0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark15(-37.73700870129598,-0.012275687532438673,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark15(-38.09880358001638,-0.04819834714122351,0,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark15(-38.52287858319821,-0.0011484824950192957,-1.0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark15(-39.46409995882367,-1.5707963267948952,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark15(-41.52320373926325,-3.652022718222558E-5,-20.60147700788723,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark15(-42.43595096909456,-0.9785657777018173,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark15(-4.37567554918979,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark15(-46.207170900695445,14.430831384714068,-4.2351647362715017E-22,17.366651869226985 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark15(-46.20821845444492,-0.0026298406388826773,0,0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark15(-46.21363250603756,6.455507780327744,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark15(46.68093311906321,0,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark15(-47.78289276084896,-0.5700372113766369,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark15(-48.73484834374935,-0.0017014007056864492,0.6081128644120164,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark15(-50.38638392964019,-0.4177252660708655,0,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark15(50.99746690258564,0,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark15(-51.04407047979556,0,0,0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark15(-51.46030906461681,-2651.866989608554,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark15(-52.67187720509499,-0.2126222669443899,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark15(54.049415783444545,0,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark15(-56.026365019303384,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark15(-5.663720622862101,-0.0026298406382773113,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark15(-58.78138942080919,-76.22239244724267,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark15(-61.42403771690174,-0.026390850801932902,-23.3948182652252,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark15(-63.50174677273992,0.004658935819322462,0.0,100.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark15(-63.681095326674495,14.42972886012253,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark15(-64.10059850476044,-3.8582970772304965E-15,-57.91077338375394,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark15(-64.15086937957213,-0.5707308686735632,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark15(-64.76500506236944,-0.020955784971793463,-32.94931168514748,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark15(-65.54904480995896,-1.4399767347180443,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark15(-67.56786147762938,-0.41518299465336883,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark15(-67.57192399843719,-32.496081524398576,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark15(-68.28762845942876,-0.36808898093760517,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark15(-68.63995374111423,0,0,0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark15(-73.45867050180881,-0.0026295683511717714,1.6242827758820155E-114,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark15(-74.4470026851517,-1.570796326794893,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark15(-76.04962573774756,-1.1723144909129104,0,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark15(-76.91790350589159,-0.0026298406392937937,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark15(-77.11524516735558,-0.0030686038332586457,4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark15(-77.33422376072059,14.431058139627808,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark15(-78.49433198612141,-0.0026298406388735765,0,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark15(-78.95995126111552,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark15(-8.092639245530691,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark15(-81.26041348139563,-0.018044774519680118,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark15(-81.88541088776225,0.47146167765230174,-0.2016193550708914,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark15(-82.21248981750897,-0.0026298406388548462,0,-31.277532754181667 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark15(-84.0892896937501,-0.009066078055013024,0.0,100.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark15(-84.42900600284543,14.430277716981514,100.0,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark15(-86.9167714774282,-1.1430771618955902,0,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark15(88.0703273263104,0,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark15(-8.908632310062503,-5.060108653338659E-5,70.52978214942634,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark15(-90.52250913830093,-0.01928674944421936,-1.0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark15(-90.82447168198063,-0.0026298406389160924,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark15(-91.75646655070383,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark15(-92.41341614238519,82.60712668695325,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark15(-93.51344674391747,-6.9784838824158304E-6,-11.921721755951316,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark15(-95.14718012177313,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark15(-95.28818114993129,-0.0031553108658065113,86.57308782395262,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark15(-96.25723022278237,-0.045843675282782215,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark15(-97.96470678821613,-0.00262984063887526,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark15(-98.76006481627185,-1.5707963267948928,0,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark15(-99.08919234179027,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark15(-99.53712030903671,-0.07491124624828338,2243.681431726492,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark15(-9.965611143447976,-0.0026299279891087287,0,93.2102514154386 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark15(-99.99585430297417,-0.0026298406388870093,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark15(-99.9962333879266,-0.012466846066170179,0.9999999999999929,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark15(-99.99963588160755,-0.0026298406388695038,0,0 ) ;
  }
}
