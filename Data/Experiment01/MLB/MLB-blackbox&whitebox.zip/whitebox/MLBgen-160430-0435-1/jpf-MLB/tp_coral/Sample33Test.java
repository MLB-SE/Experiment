import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(0.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(-0.03647404729277781 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-0.05593555977860538 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark33(-0.08478272128885067 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark33(-0.08903479306947037 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark33(-0.5187707255957061 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark33(-0.8072372716125784 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark33(-10.500410703322387 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark33(-111.48224227828945 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark33(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark33(14.42920392152758 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark33(-1.4981364335015035E-95 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark33(-1.5700987179367498 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark33(-1.5703779284822121 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707089683815982 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948957 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948961 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948963 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948968 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark33(-1.5707963267948974 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark33(-16.000191455959296 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark33(-16.125565936268686 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark33(1.7933345419787522E-7 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark33(1.7973237997289954E-7 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark33(19.394053455265833 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark33(-198.78634985511758 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark33(-22.379651962108397 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark33(-2.443075037407638 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark33(-2615.049567440157 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark33(-2720.54620071719 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark33(-3.141592653589796 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark33(-3.141592653589881 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark33(-3.1415926535916125 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark33(-3.141592653612537 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark33(3.141592657315084 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark33(-3.1435457785897936 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark33(-3.3656871745620975 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark33(-35.91283934228045 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark33(37.026176801657414 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark33(-40.84318264126623 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark33(-41.53729241514406 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark33(-41.98064288021372 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark33(-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark33(-44.264047765184664 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark33(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark33(-475.9314240836924 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark33(-48.59904740741528 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark33(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark33(4.969486685269516 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark33(-51.24734475861166 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark33(53.32771512619365 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark33(-59.747609272612 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark33(-60.70245434779251 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark33(-60.86636534510974 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark33(-66.38466663998838 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark33(-66.47744611627758 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark33(-67.99433723311925 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark33(67.99965876711133 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark33(-68.32003892188838 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark33(-68.55580736449511 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark33(-72.43586900956629 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark33(-78.65747411976352 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark33(-82.06947394254074 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark33(-85.03803672850214 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark33(-86.32921763498369 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark33(-8.757110568828068 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark33(-88.35777400635827 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark33(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark33(8.881784197001252E-16 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark33(-94.42886666538995 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark33(-97.76331705895656 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark33(98.09156081786469 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark33(-98.91797553975596 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark33(-98.97373193913575 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark33(9.924610970282662E-6 ) ;
  }
}
