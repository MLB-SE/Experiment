import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(0,0.0,-0.4559744185240504 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(0.0,0.13387849300826543,-1.5707963267948912 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(0,0,10.129090316008927 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(0.0,1.2155152860976143E-14,-1.4767247544704265 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2732.977707462039 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2733.5437490615495 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-2.8728284618174627 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-33.74489579552676 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-33.894500135806965 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark27(0.0,-3.504853097483646E-17,14.440284577063473 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark27(0,0,3.925249350789528 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-4.298760115913765 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-47.92758782400885 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-48.62081001561409 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark27(0,0,59.55219143185789 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-60.42428433521998 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-70.86251317803934 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-83.62755069661793 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-90.64270489379878 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark27(0,0,-95.9726251462482 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark27(0,100.0,-0.6558000503899799 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark27(0,10.393958322733255,-1.2751577191892431 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark27(0,106.34054984248597,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark27(0,11.276969791241402,-1.5707963267948948 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark27(0,15.994090989453497,77.07030041050052 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark27(-0.16001747020427892,0.48598905123304836,-1.1642530292162547 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark27(0,17.13993738248344,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark27(0,17.820053629640796,-1.5707963267948957 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark27(0,2.1519297963715758,-0.7208120741786694 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark27(0,2336.953724271524,-1.5707963267948963 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark27(0,2591.463220909787,-1.5211298919809595 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark27(0,43.19983051161816,-1.5707963267948948 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark27(-0.4866885848050728,0.12468540554482681,-0.3385302006352262 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark27(0,56.62963172030729,-1.5707963267948957 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark27(0,64.35456707079143,-0.9271981383182473 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark27(0,76.1745682912695,-1.962764250564937E-11 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark27(0,76.21683085087207,73.40638117013432 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark27(0,-80.60350374874481,-0.2181490558136101 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark27(0,99.97891017718524,-0.015711923193154734 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.11301630121748962,-1.527384946773835 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,0.17098092448639524,-1.5707963266019513 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark27(100.0,0.7996488755471567,-0.05345128143214661 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark27(100.0,1.49999978551241,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,17.970864490377863,-0.030836093162917855 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,2.0896313926071022E-15,-1.5707963267948963 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark27(100.0,2.596462122982309E-10,-1.5550041508855157 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark27(100.0,4.051019737960725E-11,-1.570796322762167 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark27(100.0,-43.41701697083788,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark27(100.0,45.15424126541477,-4.168685261573949E-4 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,71.75765766094649,-1.3230793626841059E-17 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark27(-100.0,8.881784197001252E-16,-0.969214025780019 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark27(-100.3621141970673,-0.6159128228036632,-1.570796326794896 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark27(-11.197181540370366,16.19688877599757,-8.978539863452E-16 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark27(1.1232183413885175E-17,7.3432782092166455,3.206545002417073 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark27(1.2621774483536189E-29,18.2981822323591,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark27(13.653533203531408,0.2747827609980295,-0.18623443532467515 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark27(-14.976431209011555,8.080641600161224,-0.0703791603317274 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark27(-1.5261914761124853E-198,36.91804541871085,-0.01089867974131836 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark27(-1.5705168602606474,22.545851174313416,-0.01737509839636902 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,17.151666556624324,-2.8959439709210954E-16 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,32.35895821555164,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,42.98169435530254,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,58.08112002383444,-1.3082457765304716E-17 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,77.64396241423303,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940935348,7.902441163924454E-13,-0.9663491515871484 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark27(-1.570790794093535,100.0,-7.851739255895364E-17 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark27(-1.57079079409354,47.371145576134495,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark27(-1.570790794093547,0.0018346016089165196,-0.5516103405226431 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940936248,1.7181323395432402,-1.3530661429915247E-9 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707907940940218,81.40562986527647,-1.5454862312153572E-10 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark27(-1.5707936442962802,0.0023377886073353282,-0.9347815609562445 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark27(-1.5708486025193018,0.008555225804681543,-1.569211232095757 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark27(-1.571117889883529,0.07951602604920266,-0.2592300657140748 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark27(-1.5711614632081434,1.570941178742956,-0.0138134209771692 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark27(-1.5711878416172491,0.02245884513561796,-1.5707963261054843 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark27(-1.5720358253665838,2.695725377667042,-0.014757276982987344 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark27(-1.5763400764282236,1.573032382196308,-0.053371177341547706 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark27(1.5777218104420236E-30,47.764706222484264,-0.011684507898892804 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark27(-1.5780451546142675,4.771112486398019,-0.020102430224462127 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark27(-1.5814529898818837,1.5140275813513568,-0.0768039897041786 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark27(-1.5819011506111647,61.54333957571643,-0.0019266410990909201 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark27(-1.5921462406160738,0.8337935882940577,-0.19792738100686091 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark27(-1.5944099430142098,99.99017057256805,-0.0017234197438754765 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark27(-1.6143435513634994,0.23421123100019825,-1.460956163019876 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark27(-1.61564295765389,0.23616745171917342,-1.5707878005951441 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark27(-1.6247282006084243,65.93899944925802,-0.003918484130914779 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark27(-1.683123363321519,0.3674838521577488,-1.549949369283695 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark27(-17.007705305590477,24.337946416874416,-0.015165365279954915 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark27(-1.7058370199791548,4.117688487514906,-0.09743621585789697 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark27(17.887212176866484,75.84376300212122,82.21591885369546 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark27(-1.792758032503557,66.29483986250456,-0.0075858435630978376 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark27(-1.8850846206891134,0.0015455525039413942,8.772651958916894 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark27(18.85937845081863,0.12081167693735544,-1.3804001673296171 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark27(1.8897659545771717,56.07117844764784,-4.513385187203681 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark27(-19.340814920544176,-93.06988888656744,9.223958272601521 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark27(-2042.4168179326414,1.4156277143750917,-7.779785726505228E-4 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark27(-2.1159742703343767,65.92333734092058,-6.276568679876998E-6 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark27(-2123.4843082583448,1.0533987883650706,-0.1259539493865678 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark27(-2306.0456320326452,0.12871424910925075,-1.5707963267948963 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark27(-23.404855889074,89.39242403015227,-6.636995898379925E-11 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark27(-24.959719268023306,7.13391631375809E-17,-1.1201805612986233 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark27(-35.65549867102378,8.006681748262107E-8,-1.5707963267948963 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark27(41.058480838209334,21.320219105677296,18.23161478403526 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark27(-45.90370212812185,-16.301606162381788,49.96823435349461 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark27(-46.66016954019525,-48.20164597573151,-93.87117282459289 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark27(4.930380657631324E-32,0.39827148643243065,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark27(49.32732401729872,84.74633402189745,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark27(52.0569364278486,623.4993890828912,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark27(-53.800561325554156,71.24546738918283,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark27(-56.55117337589077,71.02788446828711,24.39940136813729 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark27(57.5636492556759,9.661035205847728E-17,-1.5705448424200235 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark27(-5.903943720575455E-7,0.024133589200342698,-1.3983010055376497 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark27(61.05423996665471,2.7484139009624747E-4,-1.838593341528619E-12 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark27(62.62211089862123,3.0101209408271963,-0.06678408602048971 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark27(-6.462348535570529E-27,1.8900436771218665E-12,-1.5820925633010094 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark27(69.40983807074906,-58.116200180280764,58.895002094557185 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark27(-7.105427357601002E-15,11.537210278394873,-6.647675482027096E-12 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark27(-74.38682459449954,21.391453868089656,68.86947403154414 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark27(-76.17294827721534,0.027866491858207,-0.027938419381587035 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark27(-77.37610277767033,49.49121553131732,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark27(-78.95882100549278,0.004407404926367042,-1.0944796190474726 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark27(80.22566488633406,3.1502369020170217E-12,-1.5707963267948961 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark27(80.74092928878018,13.078483718374162,-4.6527316317258665E-4 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark27(-81.57369082420831,47.00714963361864,-0.0011091191255438448 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark27(-8.277178599520596E-4,20.08543279153102,2.7530531876296465 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark27(-83.19020726535081,113.35449763050022,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark27(84.02206630884973,-3.518778074187158E-8,2.4380546930155567 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark27(86.11565289071913,0.04546911227245337,-0.26709855000889804 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark27(-87.98517245924536,29.72192720917605,-0.001301952547444027 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark27(89.85344409420892,6.123502241145044,-1.1845416182681978E-5 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark27(-90.72314269024821,71.59187879594094,65.81673252726534 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark27(-96.5652978869896,0.2730315696527274,6.758360439701638 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark27(-9.821001194813329,-11.32037226697148,-2.907138821543045 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark27(-98.30890431317607,2.1769646399941614E-7,-1.5707963256869535 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark27(9.914022265180272,-2.220446049250313E-16,-0.6196425472815289 ) ;
  }
}
