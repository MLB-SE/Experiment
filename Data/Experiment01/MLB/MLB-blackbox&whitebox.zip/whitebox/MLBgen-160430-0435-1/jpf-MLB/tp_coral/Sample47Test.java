import org.junit.Test;

public class Sample47Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark47(0.8018418362213566,-0.8018418362213566,-0.5628006249730078 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark47(100.00000000000001,-100.00000000000001,-745.6660363902347 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,0.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-40.19140625 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-709.057601341927 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-709.7556190702594 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-709.9643932748091 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark47(100.0,100.0,722.4237210994451 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-100.0,-727.0508323596459 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-734.3318317784959 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,737.5498772782626 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,740.6241825260535 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-746.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-753.4360395594429 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,100.0,-754.4708290292393 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-58.337229590296005,0.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-76.11126022126427,-40.13217253279205 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,85.10442551964012,0.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark47(100.0,-86.43121470432064,-709.7316088681956 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark47(-100.0,-87.08694716652494,-784.6005088107803 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark47(-10.491637781596012,6.735277216336016,-80.01549091117806 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark47(-106.89542453340303,-22.288660328029536,-714.8886326530903 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark47(11.073895990400004,-8.294883299354552,-760.9383335606791 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark47(-111.89208927211888,-47.603038443770295,-709.9670968340905 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark47(-115.7313666397234,-612.903032606669,-0.7153523495274641 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark47(1.1768751505722443,-1.1768751505722224,-743.9060194231984 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark47(-123.26154780219913,-592.2808401762683,-709.3426123101448 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark47(129.07596069673693,58.5104605466463,-745.9758834800051 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark47(13.550934457079336,-84.4084349387629,-745.4055015001403 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark47(-13.859609123370205,30.26224018157481,88.5042464040244 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark47(14.446273123316105,-15.935721766315595,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark47(-145.45121584788495,-563.9411603329108,-709.1157589738405 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark47(-154.81771250868357,-558.9638698787295,-718.0116773957017 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark47(15.904239850361975,-16.18457035470064,-743.7914447493486 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark47(-159.36610129769718,-588.8253049523028,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark47(161.5317772522573,61.45923805399377,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark47(16.240873826578582,7.506576080291466,-40.19140625 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark47(-163.65481330261423,-545.4742033961206,100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark47(-169.56229524320486,-646.2735117495691,743.1584408532987 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark47(-17.15168136358716,-97.09947080330113,97.06689247597131 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark47(-175.98342029939127,-615.639251541569,-57.81716917506008 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark47(-178.64777543102485,-540.0433656723607,-745.8349018352153 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark47(-180.57170729816104,-529.4113310652093,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark47(-18.1129373421618,40.49060832844603,-723.0902017916403 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark47(-182.40296431365155,-527.4390629871834,-724.5932384114615 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark47(-184.56996811412083,-524.9964859331345,-709.9479644092679 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark47(-18.704494604773856,-71.74558619094178,-709.5166589340324 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark47(-192.59646030540384,-553.4035396911526,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark47(-193.4404799100697,-515.8563958781536,-727.5995668851476 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark47(-194.13281053432834,-515.1644221599786,-782.9680290340842 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark47(-194.35823929899414,-559.1644080211728,-719.458104824846 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark47(19.5088238919709,100.0,0.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark47(-196.35559105233295,-513.2917597602399,-725.2731123820614 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark47(20.334662218323672,-63.51502506353721,711.2731184580681 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark47(-20.592666072558302,98.97825369329848,31.462754042268898 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark47(-20.84197036491038,71.83392181170689,23.5920801301487 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark47(-21.02531418998565,21.02531418998565,61.19995409802158 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark47(-211.3372323737871,-562.8094273408684,-726.0141687269908 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark47(-211.40939668301942,-509.19585758007156,743.8168923878486 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark47(-213.47712569220892,-496.186411756028,-40.04620932049712 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark47(-21.399432920861102,15.176539460343875,-742.6749322188147 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark47(216.08040508009773,500.90226311695847,-100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark47(218.28511049407638,515.2896489696165,-742.4788087008089 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark47(-21.864846449841508,-70.6815586993784,-709.0943901500723 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark47(-22.22745764947001,-32.47476552199214,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark47(-224.22853154069327,-484.9987591871303,-745.9998890930457 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark47(-224.67539022462074,-488.20328981928947,-740.3093582775048 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark47(22.497489126333562,-89.18853067725661,-745.782529842759 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark47(-227.9021123305742,-481.51137291030153,87.25062816815563 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark47(-228.4724455181136,-480.7882947748124,-745.4951358454738 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark47(-22.904390006810885,-28.873650091238716,-745.9356221229871 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark47(-230.34969435881868,-485.6686936617473,-745.2777497565494 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark47(-234.09529672958666,-494.88647280348977,-709.9011265860252 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark47(23.881636642640288,65.62258971800566,0.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark47(-24.174391118167343,-36.68133211796998,0.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark47(24.440335682734826,-99.6135170976675,-763.4712202195473 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark47(24.514365100323147,87.76048421435806,-714.2120538923109 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark47(-249.3326040971508,-466.11270942019644,-760.3751087164984 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark47(24.966673637294875,-5.124367359114785,-726.4543466960921 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark47(-253.44155150044958,-523.2162243716265,-40.07479872367604 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark47(-257.91070617412765,-487.8380778804999,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark47(25.841406995901096,36.1800648127404,-761.182225562249 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark47(-262.6152854859131,-463.3419393058294,-742.1304900542904 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark47(-264.48708854779613,-492.83645438497587,-709.8687332631855 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark47(-26.486420356381586,-71.93750509265456,-41.0732702542215 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark47(-265.63214749812647,-464.8449285496963,9.07326812783208E-18 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark47(-268.95156387656,-551.146672694684,-709.2142608481322 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark47(268.96542562691934,480.50493297158675,-709.9197955706954 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark47(270.40050260234716,449.6351475460498,-2.796242815734669E-5 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark47(-270.7783628252533,-438.26732779264825,-1.494140625 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark47(-272.1876138330484,-436.83043922401123,-743.4074774923643 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark47(-27.3157879229648,-4.480692863745034,-2.16070135960058 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark47(-274.4895713103062,-490.6217497848319,-713.1537843998896 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark47(2.7453681670401373,7.144452206370422,-709.0915704492352 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark47(274.570038875035,472.5958390583612,0.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark47(-274.76735424836363,-434.40466771792984,714.8194102331488 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark47(-278.7581745173473,-430.38034570780064,-758.8065375681339 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark47(-279.9471749238744,-486.48153448916605,24.554176974327873 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark47(283.69389219873517,440.7034982215928,-743.1165211260661 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark47(-284.6757842275676,-425.01266307454074,69.69793093605702 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark47(-287.56686971181836,-421.5835686808632,-753.2618280360782 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark47(-287.92080576304505,-471.37404913427093,-778.2125388276478 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark47(288.9970187840425,451.063030947902,74.19038729262778 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark47(-296.3434422785073,-413.0398177528236,-714.0341679369312 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark47(-297.06133620948094,-412.8938873049055,-716.0445078023502 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark47(-298.6613642138347,-415.62197602489056,-751.1250274865195 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark47(30.279183609342027,-30.279183609342027,74.3260437611416 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark47(-303.9031434757719,-406.0747366360509,-744.2615253970712 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark47(30.877538949347183,-30.877544101578806,-745.9999999877556 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark47(312.54411355880603,452.25051892424256,-745.9999999816644 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark47(-313.4998547907173,-471.4749312712991,-100.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark47(-315.6585715979899,-442.3746607591457,-1.494140607806631 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark47(31.681830062623565,-17.26929445673955,-1.4941406249999991 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark47(-31.696128445673907,4.018305132822491,-709.8599349882628 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark47(-32.043409773269076,-72.79436092514649,-80.86588599552036 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark47(322.40041230866325,409.5608862729088,-708.2590247688684 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark47(32.35359820635006,-19.916583052705477,-745.2907577246101 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark47(-324.079956227275,-414.00064183086783,713.5132514956343 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark47(-325.027821658297,-384.74505431435324,-100.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark47(-33.07014330253016,33.07014330253016,0.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark47(-332.5770554693282,-376.7329235503714,-3.000000000019243 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark47(33.26469307603696,-33.264692893215745,-709.4391073756061 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark47(-33.595657302280515,-6.595748947719464,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark47(-337.461344804053,-408.5355084292217,-6.239637061923464E-10 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark47(-338.8568253908218,-405.40912251256157,-709.8988547583531 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark47(-339.09871236672524,-386.5097850506824,-70.52211652255312 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark47(-340.97196282465524,-455.47190152087086,-714.9786431722001 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark47(-340.98282318243974,-368.162428910545,-709.7809470832598 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark47(-343.648734936258,-365.82485343086455,-709.9998471532526 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark47(-344.3230476069701,-368.45377311427364,-100.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark47(-34.45431585893779,100.0,-791.1665062871607 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark47(-345.2797756181875,-364.01069858835666,-77.4394311317765 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark47(-34.56688766987412,91.018925125207,-75.73623613116276 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark47(-346.03346981629255,-375.43653269144215,-733.2228107288407 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark47(-348.7914783017042,-360.4004780365706,745.0929811705653 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark47(-350.44388845370014,-363.04589603076727,-709.4240146884885 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark47(-35.2327312306723,-27.394396612315433,-40.19140625 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark47(35.27961073888861,-91.2549721323806,14.979367949783324 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark47(-353.046361153705,-367.502046639408,5.400223784771725 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark47(-353.2422217982895,-356.3871627197912,-40.19140625 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark47(-353.4272901246451,-373.2827386989227,-787.2298655830981 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark47(-355.41969009146527,-375.09526797478355,-709.0311524722101 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark47(35.583497825166745,14.670241166682857,-736.1781517482538 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark47(357.6410152248402,383.7955041758332,-1.494139770763174 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark47(-358.0537613341356,-433.9242841549245,45.29683665717286 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark47(-358.5310286762493,-351.2491056363198,-2.18591936356256 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark47(362.32708182950023,362.6879546194664,-745.7327378450008 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark47(-365.871895194657,-483.06854383063234,-745.5869581046242 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark47(-366.19923570662365,-343.6893960737206,-709.6881999810481 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark47(367.2987531223585,391.6962903119446,-40.16143474435055 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark47(-368.22361124798437,-400.13047616932306,-64.08611870533397 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark47(36.85352595926622,-90.21487865082682,-709.5091723102446 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark47(368.91260328153584,368.38021797984106,100.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark47(369.5098808133313,373.51983845274754,-100.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark47(-369.73623389170206,-376.2637661082979,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark47(371.151680208693,351.5155418490891,-2.5056395793281183 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark47(371.79585866487935,355.3295572675762,-46.810753298118456 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark47(-371.8060137157885,-339.9858002667784,-708.7189400723246 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark47(-375.28744954149903,-371.0711385810028,-709.6694609799615 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark47(-376.1750876904037,-333.80788409019743,-1.4941406249999982 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark47(-378.0330240621693,-373.8924633540149,-709.4503539536181 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark47(-378.63435060307086,-367.3656493969291,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark47(-381.3180463199862,-329.91759026326315,26.47815431549843 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark47(38.1533071197739,-30.35198879277499,55.096328601598486 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark47(-383.0925997889119,-383.03070707233184,-744.0348965285275 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark47(385.3443438224635,373.16683586716545,-761.2445484372698 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark47(38.791836250830556,-0.5776487725149764,-709.898232392939 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark47(-390.1577090572719,-319.01831870987445,-745.0266339179096 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark47(-390.7177248768708,-319.0689379973214,-709.4405766026546 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark47(-391.57568916710164,-366.7719489296199,-714.8325379785803 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark47(-394.17714419360993,-351.82285580639336,4.963648382638212 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark47(395.66884357310136,329.20300474488863,-716.1151558320935 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark47(-396.69398799190225,-312.6902075174976,-709.0187123000975 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark47(-40.048358362466516,20.916596918337675,728.9810423673686 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark47(-402.9081835146056,-306.5972758892175,6.049615825994087E-17 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark47(-403.0898337820585,-333.96321766179625,-732.3815728484655 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark47(-404.3287842593651,-305.2605306494566,-37.86389155593979 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark47(-407.1479749940061,-309.5997403301364,-745.2967368366147 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark47(-407.78831020561825,-305.99346563135424,27.079256398012987 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark47(-408.4018776789321,-349.3859933572014,-724.1186267948667 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark47(-41.16677734646859,41.16677734646859,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark47(-412.9581309355085,-322.8757348213093,-739.764478677263 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark47(-415.41620554190973,-299.8320770942169,-709.9745133338147 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark47(-415.7514686781244,-363.9430968255541,100.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark47(418.3433276941692,317.9283556939685,-743.0664632518125 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark47(-419.68534968297365,-319.176427421031,-1.0803958889875007 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark47(-421.2336885029547,-329.4381942301274,-1.2973393911126259 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark47(421.2930885661219,295.7464882840419,16.039488209665834 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark47(-421.93742825228446,-321.9054087915548,9.463104883819 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark47(422.5376346723465,372.6182866248619,-40.19140625000001 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark47(42.42989923923852,-42.45036561366127,-81.20098234060589 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark47(-425.6033937654671,-284.1298229011629,46.83113666494387 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark47(-427.43570806662194,-320.70842714345383,-709.6474057402105 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark47(-427.4939132713651,-318.3348414506682,-12.089623908017444 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark47(-428.5026735838421,-281.1568111433055,-19.85843750456 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark47(-429.565646065676,-288.84826770363514,-746.0000000000001 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark47(429.9642071963711,287.17151804118635,-718.0163647242355 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark47(-429.98933127633916,-325.94837573911497,1.1226121895619938E-6 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark47(-433.14984863882466,-338.84468092925323,-709.8582324300562 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark47(43.89537070380513,39.325720608465275,-3.468561625579099 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark47(-439.35941652065827,-422.71172671065943,-709.2411273933328 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark47(-4.394615254097744,-98.92523010099974,0.0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark47(-442.2374910627261,-298.58929459530805,-730.9861245778709 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark47(-44.270650634697695,44.270650634697695,-6.278132443587268 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark47(443.5644529759892,293.6367257935332,-715.737417767295 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark47(-445.07344108546687,-284.8672095278174,38.94791313932049 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark47(-445.08730408789677,-359.6169851708662,-708.9782537538908 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark47(-446.8834200208021,-344.4711674627687,-709.6815422202155 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark47(-447.1068189603304,-283.2270625452726,-709.7096180823261 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark47(-448.475034200204,-260.85534230661557,-709.3212213218608 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark47(-450.01185125523284,-270.46978397263143,-40.19140625 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark47(45.22497705017861,71.56182439624803,-743.726036288193 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark47(-452.6511092815222,-264.0675800685489,-90.27197000756509 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark47(-453.3777963593207,-276.2305543804423,-745.4982626711272 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark47(-454.8806351279112,-293.89074823795517,-715.3750983585157 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark47(-455.6777791324469,-253.9702618424939,-745.2585722036735 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark47(-46.259689382459726,-68.84862804991103,-709.8977521911212 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark47(-462.5976200892,-270.089187205025,-40.014472007926656 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark47(-466.65276963289773,-274.9698152669404,-709.7241588496736 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark47(-467.8282955144875,-243.56758960226048,-83.97177537897662 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark47(-468.0269577345297,-245.36266936279438,-709.4965660090776 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark47(-468.87503496216,-240.5396813220792,-722.8531875778133 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark47(469.6444413356545,252.94290709494166,1.311579070818951E-8 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark47(-472.04594445101804,-277.8974946531015,-709.9745852592209 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark47(473.19705708137565,303.84431663290866,-1.0521928703234487 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark47(-474.1049496901178,-303.1222722458049,-717.2779079692622 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark47(47.66723877115386,-47.66723877115386,0.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark47(-48.15142744203645,-53.61873105969263,0.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark47(48.33904949816703,-48.33904949816703,39.11178631885187 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark47(49.4989746664061,-13.970803845452124,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark47(-49.92340545576796,30.137230667913457,-78.34905049070811 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark47(500.77758271868936,246.236823609388,-743.9499208578802 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark47(-50.17634301147096,-34.1433478526413,66.49523973006521 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark47(-501.9861253459222,-261.02825459876215,-709.846961107374 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark47(-508.65506123976274,-278.4926040900684,-745.7250770739159 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark47(-512.9350414955045,-196.2781517399203,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark47(-517.037375983781,-236.05325209338554,-54.711489873821826 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark47(-518.1623533813284,-232.1717406896954,-709.5123703643721 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark47(-520.7909919554413,-228.89923476983736,-66.85652787658816 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark47(-522.111109431397,-221.27977274857662,-745.373600871276 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark47(-522.4360443316234,-195.498993764156,-753.8984883978089 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark47(52.26905160342299,-52.26905160342299,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark47(-523.549107579348,-222.45089242144263,-11.604250573864903 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark47(52.47337962968062,-52.47337962968063,-714.2546013468332 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark47(-525.8860360133913,-197.63715598087757,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark47(-525.9834858754884,-183.1721057408542,-751.6040549402429 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark47(-526.6566424327876,-182.7617487353088,-712.3980459746463 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark47(-527.8636153365959,-228.22552788980136,-745.9999999999958 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark47(-52.94247755394472,52.94247755394472,-1.4941406249999964 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark47(-5.298351394683742,-45.227798297433594,-1.494140625 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark47(-532.0092620809313,-221.31984746944534,9.360411871902066 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark47(-533.3332582943971,-275.89615148786004,-100.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark47(53.390770095186895,32.23085439197223,-10.148558659381976 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark47(-535.9129359066375,-238.51016062811996,2.453537694301545 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark47(-536.5742449047661,-207.3182905061281,-62.14050184291138 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark47(-53.872521221830056,53.872521221830056,-709.4480615506607 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark47(-539.3947431680244,-170.56850507733046,63.2828550213894 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark47(-544.0783468793809,-189.37977676153315,-709.5249543274358 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark47(-546.4488461550468,-250.64904513387262,-40.19140625 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark47(-550.6655453488312,-161.58438493555258,-709.9747276872541 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark47(-551.1080490620676,-172.9055676732994,-1.4941406870450724 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark47(-5.514653298094132,-22.363144861517625,87.03705834408305 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark47(-55.45593644346629,15.264530193466292,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark47(-555.6267317419873,-154.01035703309105,-86.48689923465551 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark47(55.67147947728983,-55.67147947728983,69.97651388098558 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark47(-55.67246748938517,-8.748355286495311,-745.5069187169752 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark47(558.6607665097714,159.43288947813562,-100.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark47(-562.606164339748,-147.24934034483567,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark47(-56.406284691599964,29.96546477952276,33.30752606448905 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark47(-567.87926677987,-141.22973033864582,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark47(-56.89594995716505,-24.190338650331867,22.196340849005708 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark47(569.5170798743618,158.13414568185155,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark47(-57.17362926711513,-14.207013504012082,71.08763625568992 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark47(57.354517257834445,61.890196309219434,-1.4941406250000004 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark47(-582.345695949635,-135.72847027572442,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark47(5.834083088737742,-26.76326351050666,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark47(-5.868859605364804,-19.771212147024684,-10.706404702861235 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark47(587.3283410000189,168.0922602840937,-713.5331061671313 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark47(58.97443674338584,20.928995933164302,-21.56108884548229 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark47(-58.98329937144031,-65.52262061568446,-756.0736637974012 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark47(-592.0744032780883,-219.7451687624702,-745.4775265260525 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark47(-59.4871180054666,-686.1793803974832,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark47(-59.50789195363492,59.50789195363492,-746.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark47(596.525447571447,175.60629158920844,713.4736987510977 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark47(-60.71295322877375,96.291040005052,-719.7074528200103 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark47(-607.498868675991,-100.0,-709.1318159057737 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark47(-607.4992308047628,-102.17315707982526,-40.07441029576624 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark47(-61.895406041367075,41.058895148494344,45.027689796845806 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark47(61.91635910227549,-90.31952038474316,-87.45688097610761 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark47(62.16612244181681,7.745932643730754,-745.323102296923 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark47(-622.8569246822739,-100.0,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark47(-628.7143585367053,-81.28564146323562,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark47(6.314350145021152,-2.6790658013143798,715.9144740734023 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark47(-634.1231681508142,-180.70293411570384,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark47(-635.312817555624,-100.0,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark47(-635.3419946738351,-74.26478094249966,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark47(63.69333916649907,58.69787979397313,-51.204249185764624 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark47(-637.011097230105,-161.00386529390812,-100.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark47(64.40252956167373,64.46984317662748,-0.17171688351207592 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark47(-646.1914510723689,-99.99995517782769,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark47(-650.2087352606437,-95.79126473935621,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark47(-650.7275272510286,-59.272462240594635,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark47(-661.3188946764539,-84.68110532354613,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark47(-66.19735940690381,-96.76390623126821,-707.3042237486408 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark47(6.722721535588477,5.589558122655518,-85.07489489735842 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark47(6.850540913203275,100.0,-713.1430807071412 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark47(-685.466327858189,-60.533672141811,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark47(69.45214196824924,91.69330245469612,-709.1888429277105 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark47(-694.642963183348,-51.357036816651956,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark47(69.57935424257451,-1.3458308596057975,80.00314737139973 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark47(70.64976800781088,-41.5038510328708,-23.146036925877155 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark47(-70.67034653078056,70.67034653078056,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark47(71.14147942212057,61.29495364995344,-709.3876616391243 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark47(-71.75504850224915,-674.2449520579091,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark47(71.92062110454748,-51.2200874630526,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark47(-72.86837036567462,-651.8177996331844,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark47(-72.89447988348564,62.28651329423943,-709.2428438891784 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark47(-73.08101846746973,76.96010764933331,-737.7031876427619 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark47(73.15378955359299,-158.9884097134423,-727.8494501499969 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark47(-73.3007766483721,73.30077664837212,-40.0290729342966 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark47(73.40742715245793,-10.56709991967844,25.95678073386196 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark47(-74.5951087473338,74.5951087473338,-40.19140624999142 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark47(74.69828538276744,-76.19242600776744,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark47(-75.38498127610798,35.19357502610798,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark47(75.47315210287024,-55.37001807192019,-709.8625361979103 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark47(-75.51103567719737,-46.92048012647261,-86.8655765001204 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark47(76.08484100783778,42.292812715992,-709.3825741429724 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark47(76.62481934370169,-14.243675537441973,-709.6832720098872 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark47(77.91922866129332,-86.84437087657003,-724.105696540732 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark47(-78.00665107618781,-631.9931676778424,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark47(78.50806754173439,-78.50806754173439,-1.494140625 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark47(79.55750746778466,18.754656353210535,-21.900803008059682 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark47(79.70557131278476,-91.32650771828834,-709.9899254958705 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark47(-80.08001891617964,92.68145068196381,-85.7068367477448 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark47(80.53783308249481,57.96547152955901,89.20266163429554 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark47(-80.9668963239719,-628.6572758195105,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark47(81.3191252293515,16.374107057745253,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark47(-81.35524189369934,16.999734947624475,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark47(-81.84787860901882,81.84787860901884,-793.6446998629344 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark47(81.97517989915272,-28.175199372108416,-709.5626842947627 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark47(82.03800545239255,-6.582744621321865,-745.3379063538578 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark47(-82.12969133071493,13.049575539525236,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark47(-83.13215042595961,-626.3147859385921,-708.0464648912601 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark47(83.32383739929212,-83.32383739929212,-40.18093130487501 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark47(-83.3269669608859,-43.328546356751005,-75.0916055252639 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark47(-84.0501234639512,84.0501234639512,-768.1362165814154 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark47(84.68363813118863,-84.68363813118863,-40.19140625 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark47(-85.01906921033266,-89.73879571337244,-63.05715351130385 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark47(-86.42399746756398,4.6970359572673885,-31.42461180787315 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark47(-8.710311705146694,93.01506088808449,-825.8303628214858 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark47(87.73552159972584,-94.1269931316805,-8.707544717610418 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark47(-87.95910658399643,-14.41278486937965,-746.0007379198518 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark47(-8.873745707304408,96.69876373702527,-709.5135727101315 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark47(-90.51725986605919,87.72219204627791,-709.3232619583036 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark47(91.13463374129222,95.35281846277144,-40.53127540193127 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark47(92.81131030728989,13.603457107292366,-708.6857818775184 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark47(-94.4921981883484,-47.08748453394336,-731.5312295264625 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark47(95.21033295381304,36.01778271339714,-708.468509594744 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark47(-95.38469693944407,-614.6136704876305,-52.41554085535527 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark47(95.78204125126636,637.7962780102084,-744.5180005890319 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark47(-9.62451715054899,9.624517150548968,-712.1630147023179 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark47(-96.29423980686707,56.102833556867076,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark47(-96.32197785811766,73.67972817416651,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark47(-97.1899196957106,-10.051847318937362,-38.006093552343835 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark47(-97.46425179111718,-648.5357482088829,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark47(97.65166922375371,55.0868871613707,-710.4859661554925 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark47(-97.70693656234022,-31.510268941233406,-1.2631016288486165 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark47(-98.06051981890144,100.0,0.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark47(-98.14651649158155,-59.47751316894296,-746.9180424910005 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark47(-98.87705881111413,73.04429858974399,-709.0670380497745 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark47(-99.03140390427751,-93.08638566715564,-709.689411723026 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark47(-99.06499697841795,-88.68949627742921,-724.4361798974536 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark47(-99.82364310105005,-609.6282855561378,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark47(-99.99999999988613,-646.0000000002688,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark47(-99.99999999999999,99.99999999999999,-709.9994703774587 ) ;
  }
}
