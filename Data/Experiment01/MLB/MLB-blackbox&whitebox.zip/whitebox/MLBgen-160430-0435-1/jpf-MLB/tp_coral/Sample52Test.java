import org.junit.Test;

public class Sample52Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark52(0.005040990714230049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.005273036692865391 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.02229422192983278 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.037677670828496684 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.04907754675812798 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.061837550771386765 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.07099210749577212 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.10047382828519888 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.1564484167634781 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.2321183872321977 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.23679042875094425 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.25178379337594614 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.27005663705074845 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.29311381414814264 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.40936268336957987 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.44313375120608933 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.6752950711437067 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.6801282480740846 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.690855700311972 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.7635488312892589 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.7645398445340805 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.7704649619925722 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.7912185676303178 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.7930635873593023 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.8001555991369781 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.8368649571622094 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9039622767806854 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9138821741288666 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9376313172957932 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9884628233488906 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-0.9999999999999982 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9999999999999982 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9999999999999989 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0000000000000004 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.0000000000263323 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.0000000001086247 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-15.611006105473598 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-17.221625247002706 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,18.602854481493125 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,1.969624350549017E-178 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-2302.106210109737 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,2314.3936321855335 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-2.3455402353653483 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,23.732424063492267 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,2.6507322825387127E-10 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,31.22855691045698 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,31.79876161351814 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-34.73798085160586 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,37.59439065875074 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-39.61753076407448 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,41.76462812810871 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,44.73688731539577 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,45.09995115756095 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-45.28886381705723 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-4.689103382426201 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,4.705988533856842E-5 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-54.038500540121305 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-5.7684374012148914E-27 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-5.985103435906978 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-60.313888818399654 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,61.856859746609246 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,62.68978164669186 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-65.38598808969536 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-68.4389787463625 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,77.98024242057836 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,80.01887985958106 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,8.206444114443443E-8 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,84.29045064481654 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,87.26822007918628 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-8.790241664726711E-4 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-90.49873880179044 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,9.262227369011072 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,97.59340279645622 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-98.48909365156877 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948966,-9.90262427940355E-9 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.570796326794897,-1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,-1.0712849893315386 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,-2344.5972341470338 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948983,2352.56082503701 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark52(0.0,-1.5707963267948994,-0.014541434140784317 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark52(0.026922152764569773,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark52(0.03048803440542258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark52(-0.062418693976181494,-1.5707963267948966,0.0538648882696145 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark52(0.08073863387269853,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark52(0.12835502871252258,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.3552527156068805E-20,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark52(0,-14.841340671592704,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark52(0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark52(0,-15.770636297740694,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark52(-0.1629125263193535,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark52(0.180614552850291,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark52(0.18865881904317805,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark52(0.2098370578769675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark52(0.21467957096857493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark52(0.2420949251019898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark52(0.26107516920996465,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark52(0.2657043612250618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark52(0,-2724.4987214783723,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark52(0,-2731.4697006014203,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark52(0,-27.50686488040195,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark52(0,-28.694722673527707,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark52(0.3215900623172383,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark52(0,-32.25834301996986,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark52(0.420350886134508,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark52(0,-4.3135757513689725,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark52(0.4893360774582509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark52(0.49275465488825887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark52(0.5629114195473939,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark52(0.5695074417639129,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark52(-0.5801671269757946,-1.5707963267948966,-0.7847866780086914 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark52(0.5821379605153689,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark52(0,58.29469618369845,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark52(0.5956532972370452,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark52(0.6045122580572713,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark52(0.6061390684632757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark52(0,-62.27825972962777,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark52(0.647971826158759,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark52(-0.6601101610696245,-1.5707963267948966,1.989728987730757E-15 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark52(0.6681584211268614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark52(0,-6.9366445537008445,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark52(0,-71.90980828543454,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark52(-0.721292364683455,-1.5707963267948966,-12.80564367589201 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark52(0.722862166796908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark52(0.7507143697092737,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark52(0,-77.10212733771675,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark52(0.7787187481416993,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark52(0.7817666908117462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark52(0,79.75160920048069,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark52(0,8.228357834827008,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark52(0.8292108576793586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark52(0.8496728531377471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark52(0.8525385706485178,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark52(0.893480951957855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark52(0.9283456925051894,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark52(0.9506503418846428,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark52(0.9675956815164373,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark52(0,-9.77650811311183,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark52(0,-9.860761315262648E-32,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.570796326794886,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948895,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.570796326794893,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.05025867942507997 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.06255254595638443 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.3620892722346 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.5343236475391999 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,0.5830272169341444 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-1.0512631023503465 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,-2.7397616862605038E-194 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948966,75.12109531955248 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.570796326794897,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.570796326794897,1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948983,0.6148969092920009 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark52(-100.0,-1.5707963267948983,-100.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267949,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark52(100.0,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark52(10.00389636794674,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark52(10.027196806060559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark52(10.072477865825485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark52(10.102614127913512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark52(-1.0118E-320,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark52(10.151543375479898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark52(10.19143671481978,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark52(10.248802370234415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark52(10.25589893301641,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark52(10.334373313354796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark52(10.349192261435178,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark52(10.371690930632454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark52(10.373625861876029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark52(10.527319058246686,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark52(-10.540712667090418,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark52(10.558362481911004,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark52(1.0585367404912063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark52(1.0600605081996832,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark52(10.644092873254868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark52(10.737269295261086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark52(10.838424401417406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark52(10.845060445331576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark52(10.912486489636763,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark52(10.945519324962437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark52(10.98533459325646,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark52(1.1029324421489832,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark52(11.05489964140618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark52(1.1064919636368693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark52(11.206937295116262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark52(11.212505941709608,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark52(11.28744837630953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark52(11.296428820127408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark52(11.307444154891856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark52(11.310706423280767,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark52(11.366436901049,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark52(11.369523138870605,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark52(11.407654650873639,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark52(11.412122787829416,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark52(11.468841350902508,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark52(1.1483057958998135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark52(11.484356923716234,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark52(11.511495374955892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark52(-1.153235336919515,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark52(11.532775049115621,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark52(11.578298149348035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark52(11.60255852453643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark52(11.633301149466742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark52(11.683070834876816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark52(11.706064152220332,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark52(11.709561638813598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark52(11.766207875645705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark52(11.834676475095911,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark52(11.834745829961534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark52(11.85899863370416,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark52(1.189458329925232,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark52(-11.896861434452637,-1.5707963267948966,0.3863573733636819 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark52(11.897939833129769,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark52(11.90443389157798,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark52(1.1915491500675408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark52(11.961188767908437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark52(11.975104264523603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark52(-12.024207459660568,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark52(12.065393843529254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark52(12.104112183074548,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark52(12.109698246473883,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark52(12.117057758172034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark52(12.127616637152956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark52(1.214430201641056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark52(12.156545015257649,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark52(12.181853202946499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark52(12.192610789236632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark52(1.2197508813443332E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark52(12.20678282025247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark52(12.217964469298408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark52(12.220233841818185,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark52(1.2239039351527907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark52(12.26240708434388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark52(-12.28502237616287,-1.5707963267948966,-0.9348971382826823 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark52(12.319215034231982,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark52(12.353135586310438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark52(12.356989678737389,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark52(12.382040219472785,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark52(-12.39167093682567,-1.5707963267948966,2.9704555723361872E-213 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark52(12.472663066526415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark52(1.250845434501727,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark52(12.535967088025455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark52(12.553950119991939,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark52(12.558954873891459,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark52(12.56624268714144,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark52(12.609703465818939,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark52(12.61233925997941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark52(12.631364661786312,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark52(12.645058850069113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark52(12.645931234351067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark52(12.648639120716334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark52(12.654984655352512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark52(12.711021926159006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark52(12.715263971572078,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark52(12.716776242466073,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark52(12.77179213375365,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark52(12.773633961259279,-80.70585085529373,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark52(12.862516355335169,-1.570796326794897,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark52(12.915979625282745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark52(-12.931074755685042,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark52(12.975140704975956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark52(13.05831673847037,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark52(13.070177941885248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark52(13.08742472423681,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark52(1.3162027620124366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark52(13.236263151951036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark52(13.238634066561602,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark52(1.3250751663966758,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark52(13.255157452743745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark52(-13.257674834129197,-1.5707963267948966,0.3331487422546502 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark52(13.274530940629493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark52(-13.277952372439369,-1.5707963267948966,-2377.0621238642657 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark52(13.310506177047348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark52(13.31143753023092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark52(13.33751185754355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark52(13.459450947519873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark52(13.479785503886603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark52(13.484484524696041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark52(1.348657320449156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark52(13.554691589422191,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark52(13.616089252780945,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark52(13.65500361621897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark52(13.66220446360262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark52(13.682368897737497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark52(13.752277444137697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark52(13.820997977276079,-1.570796326794897,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark52(13.915286637965977,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark52(13.940389194048407,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark52(13.95562269215715,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark52(13.978687472527824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark52(14.11561032214199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark52(14.243980049274587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark52(14.247364067593423,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark52(14.260277706276954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark52(14.304252931285312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark52(14.396306715798175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark52(14.439433882361499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark52(14.450325770025863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark52(1.4456177360544018,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark52(14.473565511861537,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark52(14.505902845848922,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark52(14.520297368441362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark52(14.569028058682079,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark52(14.579753487419707,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark52(-14.619319565620069,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark52(14.628202150544524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark52(14.713683196466201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark52(14.726076907657415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark52(14.784312483285722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark52(1.482929892328798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark52(14.832256373481783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark52(14.886141669179892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark52(1.4888906270310835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark52(14.899012928047838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark52(14.907179053478394,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark52(14.92578733025482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark52(14.943331777663033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark52(14.958374770274123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark52(1.4985738853520658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark52(-14.998405489626187,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark52(15.02866380891335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark52(15.185033174861593,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark52(15.20931166295316,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark52(15.251949104074436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark52(15.267542776021429,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark52(15.294421072533936,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark52(15.306494603706497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark52(1.5354803777165813,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark52(15.383565345434626,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark52(15.480441340933549,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark52(15.52226705347141,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark52(15.522554991740686,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark52(15.541776792526136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark52(15.5466858457211,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark52(15.591494113496935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark52(-15.644235757960544,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark52(15.675884124580087,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark52(15.761169786235214,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark52(15.82392247229285,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark52(15.919636693897257,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark52(16.063823814349853,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark52(16.07250264247102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark52(1.6078008893905942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark52(16.102529641672206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark52(16.139028274186643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark52(1.616395698270324,-49.232401266861395,77.26744750370221 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark52(16.178245591659138,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark52(16.187482828248434,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark52(16.2567730573286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark52(-16.269152018446785,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark52(16.27930932739234,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark52(16.414467957597658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark52(16.417986359521166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark52(16.425722853492687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark52(-16.43248043277555,10.353884657948555,-27.077793318271205 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark52(16.46361068785914,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark52(16.472842194898746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark52(16.495184274594152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark52(16.518203009437627,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark52(16.519661331329623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark52(16.547920467572336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark52(16.61582388237582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark52(16.630297423379204,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark52(16.633245554406603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark52(16.661659630935294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark52(16.794071059233318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark52(16.91097672442968,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark52(16.97141215535109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark52(-1.7004442009931982,-1.5707963267948966,-3.1650828922634135E-15 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark52(17.091388622796217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark52(17.20793293899413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark52(-17.248390704155383,-30.881127499068015,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark52(17.25213788425033,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark52(1.732859618435298,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark52(-17.377888897296643,-1.5707963267948983,56.442611461078826 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark52(17.383208187792174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark52(17.39976768671305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark52(17.41268939000217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark52(17.414260525746137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark52(17.455081041522405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark52(17.529610139089698,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark52(1.756220687443772,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark52(17.574347713860035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark52(17.581318033303674,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark52(17.634733604025264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark52(17.641175381456506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark52(17.644612534779938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark52(17.655960569383225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark52(1.768675049325381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark52(1.7763568394002505E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark52(-17.77463999286413,-1.5707963267949019,-1.0000000000042646 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark52(17.80582671926834,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark52(17.84645089158704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark52(17.87284309312268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark52(-17.891132881990885,-1.5707963267948912,20.155161590561235 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark52(17.908094051378487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark52(17.91448466536744,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark52(18.038057587746984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark52(18.061401564048577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark52(18.068119735898154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark52(18.092433920995575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark52(-1.8093153025151079,-1.5707963267948966,32.96641011747566 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark52(18.101239373844308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark52(18.102880932370383,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark52(18.145835581452133,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark52(18.161936764802043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark52(18.204602882757705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark52(18.239099679750552,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark52(18.2628977226709,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark52(18.266746351352054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark52(-18.28378587206612,-1.5707963267948966,0.8505030428383682 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark52(18.30080911294577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark52(18.371275673450835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark52(18.377087249118215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark52(18.416097812045294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark52(18.419920294181196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark52(18.42194914686926,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark52(1.8440687144194596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark52(-1.8441439553595416,-1.5707963267948966,-1.9769741094817164 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark52(18.443598163359223,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark52(18.487141984373466,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark52(-18.498621487476967,-1.5707963267948966,-93.54670472306792 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark52(18.507328798505853,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark52(18.56150816632094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark52(18.605612393896372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark52(18.6624994220366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark52(18.708219607799606,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark52(18.718017446849526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark52(18.79290218350245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark52(18.88505809745075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark52(18.897361704448244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark52(19.016105709811,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark52(19.029664942962054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark52(19.06479855161261,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark52(19.139993191852085,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark52(1.920433062707506E-37,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark52(19.20547931438564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark52(19.208711529129225,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark52(19.221877243910555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark52(19.281816411157227,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark52(19.33221822494589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark52(19.361984862205695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark52(19.48527359518361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark52(1.9488508607919925,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark52(19.53752759785985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark52(19.576127788121997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark52(19.59398749289838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark52(19.630227955745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark52(19.671787270321445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark52(19.697687208337257,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark52(19.728197829953473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark52(19.74931119731554,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark52(19.75879297422906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark52(-19.80377669485691,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark52(19.89950282358636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark52(19.91107962193722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark52(19.913321741540386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark52(19.96793198551761,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark52(19.988167494722717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark52(19.99075376788236,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark52(20.02881767811345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark52(2.0041683600089728E-292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark52(20.049524885707733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark52(20.0613541575632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark52(20.06139507430995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark52(2.013420645865887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark52(20.13504790328207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark52(20.158488696386677,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark52(20.205428406763517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark52(20.227503496218063,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark52(20.234791127745495,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark52(20.263655495094767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark52(20.27554673242369,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark52(20.29895713557231,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark52(2.0317721518908476,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark52(20.330286584052928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark52(20.38151949494201,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark52(20.390101181257904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark52(20.419304319608095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark52(20.478156918629075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark52(2.050726397329697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark52(20.595785650040142,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark52(20.60267580037509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark52(20.646952260099305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark52(20.682652050383325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark52(20.689876254058944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark52(20.695931077837642,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark52(20.77425805912185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark52(2.0794536125212275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark52(2.079738289415147,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark52(-2.082791329570327,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark52(20.882289890489666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark52(20.907444900494454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark52(20.92248517273481,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark52(20.978299477675954,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark52(2.0E-323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark52(21.06558523727312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark52(21.086674657943135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark52(21.18062330260335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark52(21.199390536278997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark52(21.225899155657643,-1.570796326794897,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark52(2.123411196339088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark52(21.237085340430568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark52(21.24802909669801,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark52(21.275032753254884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark52(21.29546777079938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark52(-21.32199898225989,-1.5707963267948966,0.9440057525404825 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark52(21.33401463111551,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark52(2.1361332452162713,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark52(21.367769687353213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark52(21.37103049475605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark52(21.41641314912307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark52(21.483020021900593,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark52(21.492756077770387,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark52(21.501537979056366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark52(21.50235880796278,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark52(21.565574541398703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark52(21.58981073272162,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark52(21.59640109874562,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark52(21.61342021366373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark52(21.643827837246874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark52(21.650224137317224,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark52(21.65528871800933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark52(-2.167776475157433,-1.5707963267948966,-1.0000000001411227 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark52(2.1751531427822286,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark52(21.752276011916393,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark52(21.762836055092272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark52(21.781924428669164,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark52(21.787150974676564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark52(21.813568348242065,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark52(21.82081123928529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark52(21.8377699013446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark52(21.843601884690656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark52(-21.879175655033194,-1.5707963267948946,0.2097878130671954 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark52(21.905628315032693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark52(2.201513498833182,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark52(22.10210253820712,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark52(22.140939740489465,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark52(22.20146652633469,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark52(22.202727058330154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark52(2.220446049250313E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark52(22.2678900487689,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark52(22.272241807519094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark52(22.28802388624726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark52(22.33529324468892,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark52(2.2492200294996394,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark52(22.495953524448666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark52(22.50679236959851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark52(22.529579034838942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark52(22.562831178406498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark52(22.567126952491606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark52(22.57854333535603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark52(22.641791018064218,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark52(22.67579923306235,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark52(22.692550911865027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark52(22.703614392593327,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark52(22.75608387461061,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark52(22.774032950801228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark52(22.80931097741141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark52(22.94790955732158,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark52(22.955748782445085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark52(23.01050086642074,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark52(23.015715621463073,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark52(23.045133824275496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark52(23.07752828706058,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark52(23.108428399843355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark52(23.23532396238615,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark52(2.327671834274167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark52(23.27860137805954,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark52(23.28525402098225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark52(23.30647997901518,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark52(23.318423522622133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark52(23.353571459005583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark52(23.411174015299792,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark52(23.429767344445214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark52(23.454674038306294,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark52(23.470425546313702,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark52(23.54619834372927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark52(23.55128960411299,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark52(23.608109913823522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark52(23.68221771518577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark52(23.687969035751767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark52(23.757826559715355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark52(23.8129059886869,-1.570796326794897,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark52(23.874602416365992,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark52(23.881153409203424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark52(23.881825264552674,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark52(23.924161498751232,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark52(23.93415440275214,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark52(23.945325383409738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark52(24.00663051650084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark52(24.1015394670232,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark52(24.11126197899504,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark52(24.134386692658424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark52(24.193865625630938,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark52(24.210159094429855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark52(24.326229736477828,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark52(24.365240342701526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark52(24.40841767193013,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark52(24.412421393016842,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark52(24.41626891358364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark52(24.452984954908644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark52(24.531669088108185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark52(2.453348266012398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark52(24.562491017617475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark52(-24.592585266009483,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark52(24.610626630907944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark52(24.62092194039485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark52(24.640552208910037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark52(2.46598293093345,-1.570796326794893,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark52(24.666564503545032,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark52(24.70036654272511,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark52(24.706649821398543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark52(-24.722169646266714,-1.5707963267948941,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark52(24.744620495623458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark52(24.76445154060703,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark52(24.815592119326354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark52(24.837868617463336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark52(24.871175310688614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark52(24.894412616799517,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark52(24.913535598468258,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark52(24.918305141985826,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark52(24.96629788938371,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark52(24.973666114894414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark52(24.97475579246951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark52(24.978953355354406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark52(25.034114449194547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark52(25.06387067147831,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark52(25.08376745511849,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark52(25.09597518112697,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark52(2.5106235836743735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark52(25.146776813917,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark52(-25.153122026495264,-1.5707963267948966,92.31453045813737 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark52(25.157227110117656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark52(25.166476645169034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark52(2.517234795074174,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark52(25.175914061317044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark52(25.205665713662054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark52(25.227222078215775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark52(25.23562391859072,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark52(25.24647246151026,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark52(25.257439861935538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark52(25.26954339530411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark52(2.531181858339764,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark52(25.343099408444854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark52(2.5411336846485,-1.5707963267948954,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark52(25.417884411183735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark52(25.418731865356715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark52(-25.42591490572433,-1.5707963267948966,45.82565914946608 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark52(25.513886429795956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark52(2.5529572450783493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark52(25.547448206175844,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark52(2.5609331708038408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark52(25.648546517578637,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark52(25.676968649841584,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark52(25.701163808971412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark52(25.771750761295603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark52(25.808068467605217,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark52(25.814094013202745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark52(25.865740301686838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark52(25.89844278365825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark52(25.923326558803822,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark52(25.92424309636108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark52(25.933234629164254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark52(25.999559073563375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark52(26.009369952110603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark52(26.0526302054455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark52(26.10345235940759,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark52(26.12407039787499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark52(26.128964766907657,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark52(26.207128729271773,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark52(26.225317068980928,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark52(26.29442532116542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark52(26.32078676238092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark52(26.355492200749794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark52(26.364446381660834,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark52(26.373379319976294,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark52(26.436432130566352,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark52(26.468654572581542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark52(-2.6469779601696886E-23,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark52(26.546060502441808,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark52(-2.6551697716110136,-1.5707963267948966,-0.04589000632865996 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark52(26.611481749718195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark52(26.63791783628386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark52(26.64084862690109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark52(26.75256275332538,-1.570796326794897,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark52(26.769110193143547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark52(26.773669284603386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark52(2.6907943359687105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark52(2.6935411076957507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark52(26.942503202084225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark52(27.068719985443973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark52(27.106909525769638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark52(27.11395298211732,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark52(27.210355032964557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark52(27.22279135904482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark52(27.261482578946243,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark52(27.326232401141915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark52(2.7327155991183787,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark52(27.35868682230415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark52(2.750524969832412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark52(27.542746368779092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark52(2.7564690853802443,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark52(27.591645670856323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark52(27.64097668617029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark52(27.66684496002475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark52(27.675746973530753,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark52(27.693218987940828,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark52(27.746673068165155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark52(27.770827060283978,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark52(27.791594637208277,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark52(27.93899695445331,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark52(27.988087215358792,-1.570796326794897,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark52(28.033567819271006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark52(28.04845666495056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark52(28.049941491127868,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark52(-28.063770792913317,-1.5707963267948966,32.671774346487155 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark52(28.06434599519644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark52(28.135628601007745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark52(28.246736502453608,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark52(28.259074064251752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark52(28.25938677028384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark52(28.288188833335056,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark52(28.317625664341456,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark52(28.322495348893312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark52(28.326044963042886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark52(28.36397695052505,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark52(28.375126482131815,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark52(2.837737754179368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark52(2.838698317315874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark52(28.402947695466167,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark52(-28.404357445496732,-1.5707963267948966,-86.69995375061883 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark52(28.452756077088633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark52(28.46177025680791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark52(2.8480945388892178E-306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark52(28.510402293022064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark52(28.527323590636193,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark52(28.572517337575732,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark52(28.60835782417554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark52(28.616012106231906,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark52(28.623424103712438,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark52(28.678548898019752,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark52(28.69389196692302,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark52(28.702081885512857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark52(-28.74015538189239,-1.5707963267948966,-0.684684022287902 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark52(2.8842667470387306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark52(28.864892480172927,-55.78787768238709,-39.54478556846166 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark52(28.882271187051458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark52(28.900796719029643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark52(28.953040991887903,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark52(29.00660899213466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark52(29.01564313374941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark52(29.019221847821026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark52(29.048724239649744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark52(2.9163853601113487,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark52(29.190215798979516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark52(29.197557457138743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark52(29.214019005501314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark52(29.26165438034791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark52(29.30098485977303,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark52(2.934788501976257,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark52(29.38080572984319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark52(2.9424685836620528,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark52(29.43109625832512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark52(29.43372763935099,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark52(29.455515599990115,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark52(-29.475764073030334,-1.5707963267948966,0.02152861312927161 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark52(2.950750456512811,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark52(29.50806694672975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark52(29.51785904876002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark52(29.5523893334749,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark52(29.55899060708883,-1.570796326794897,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark52(29.562203354843547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark52(29.576279775133628,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark52(29.599412386034295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark52(29.634880147553794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark52(29.677850632043203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark52(29.680134407426905,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark52(29.68236944071778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark52(2.9696261587468373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark52(29.766946970617532,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark52(29.792244823018695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark52(29.828753044980118,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark52(29.874778421232556,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark52(29.927988764961853,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark52(29.978100918417965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark52(30.082293542228285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark52(3.016693260324388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark52(30.26571406546249,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark52(30.304863141764507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark52(30.312218250208765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark52(30.424159849645953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark52(30.434005989564042,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark52(30.539971215486474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark52(30.618374255153675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark52(30.64974453684738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark52(3.069452327508319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark52(3.0723977035582877,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark52(30.75899375339514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark52(30.8187228037406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark52(30.969629408947025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark52(31.022664893708345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark52(31.05250500651409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark52(31.059085088739835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark52(31.07915654737361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark52(31.103843120314266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark52(31.117503355709346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark52(31.124686642078405,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark52(31.144381390697916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark52(31.239359133693284,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark52(31.24512776956363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark52(31.255256310610378,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark52(-31.265810188276262,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark52(31.28830955516289,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark52(31.29355278505423,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark52(31.352371551691817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark52(3.1375319273077196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark52(31.39457121226593,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark52(31.43797158406375,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark52(31.44710991388881,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark52(31.47326336200318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark52(31.4782976002408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark52(31.551849702564617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark52(-3.1554436208840472E-30,-1.5707963267948966,3.1554436208840472E-30 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark52(31.64858471928443,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark52(31.650569470689664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark52(3.1718473323813896,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark52(31.75042790350307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark52(31.75212122387933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark52(31.76980026045888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark52(31.884839479895675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark52(31.89407079767034,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark52(31.95111968937772,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark52(31.961218433765794,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark52(31.964872760847356,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark52(31.98937299208444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark52(31.99182959138841,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark52(32.12104348746766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark52(32.19279087171364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark52(32.22566523083577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark52(32.23699774734167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark52(32.27628288992701,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark52(32.288749968297495,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark52(32.29300967831999,-1.570796326794897,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark52(32.34248994348895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark52(32.37177315703268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark52(32.43000556570847,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark52(32.43617143408798,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark52(32.45915177693631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark52(32.51424288453642,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark52(32.55550845750018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark52(32.62355384955909,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark52(32.69562398607509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark52(32.73141741020163,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark52(3.275913281726943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark52(3.2771201579032265,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark52(3.28290528790051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark52(32.92971563319895,14.632144179861982,99.8364169960933 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark52(33.00979822710691,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark52(33.01264290443564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark52(33.05155039561075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark52(33.12102770322423,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark52(33.13690795507268,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark52(33.15145735916146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark52(33.2111191271315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark52(33.22825254204005,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark52(33.22957650375227,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark52(33.297518053431915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark52(33.34891349507774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark52(33.351195219565646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark52(33.62510843648098,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark52(3.3650687107761623,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark52(33.66749195064363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark52(3.369275609050362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark52(33.782565545758814,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark52(33.82340613054723,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark52(33.86545172906084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark52(-3.3948694162072,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark52(34.1017160570417,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark52(34.13233857638673,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark52(34.1471266561931,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark52(34.1479949625959,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark52(34.15665514446323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark52(34.17453218592902,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark52(34.19207502327123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark52(3.421939413698368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark52(34.24634721850421,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark52(34.36906199352539,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark52(34.370678757232724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark52(34.39361657128094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark52(34.47915744827458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark52(34.51824809444895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark52(34.52001193527636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark52(34.537013253180916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark52(34.580206261915734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark52(34.6776004728549,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark52(-3.4737993936535194E-56,-1.5707963267948972,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark52(34.74597447849402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark52(34.80247271233185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark52(-3.4893187461417075,-1.5707963267948966,-62.18066839718874 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark52(35.00072561707999,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark52(35.03694886700861,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark52(35.056209595330735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark52(35.06415165514012,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark52(35.071813935920545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark52(35.13650373757057,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark52(35.13921750696869,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark52(35.153369751282526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark52(35.15777186875947,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark52(35.17481371241121,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark52(-3.520735828790423,-1.5707963267948966,-0.8877090173283637 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark52(35.255581063956214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark52(35.262243113059384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark52(35.28835928077767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark52(35.291793461442154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark52(-35.39004687626375,-1.5707963267948966,17.9872706580194 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark52(35.39476721492946,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark52(35.39850145305837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark52(3.540655688539871,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark52(35.41983413515748,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark52(35.46755308216308,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark52(35.499149598366586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark52(35.50731953936112,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark52(3.552713678800501E-15,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark52(35.59641808397337,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark52(35.62800351751057,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark52(35.941723327735026,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark52(35.947224548706785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark52(35.97746721129744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark52(35.99978886684055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark52(36.02177638631211,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark52(36.10771085649972,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark52(36.12407421526929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark52(-36.19318627805592,-1.5707963267948974,0.04557663507192433 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark52(36.198721771068634,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark52(36.21485485088348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark52(36.3009596558002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark52(36.31154115214479,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark52(36.33166504050292,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark52(-36.33737783110231,-1.5707963267948983,0.9072586871744442 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark52(36.34459042151685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark52(36.40745269179891,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark52(-36.42981712923286,-1.5707963267948966,-6.897055743034201 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark52(36.430150521121305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark52(36.43248566572953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark52(36.45074225986451,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark52(36.46844656779634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark52(36.49412844823402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark52(3.6499866256537246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark52(36.507726650735876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark52(36.51985440018966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark52(36.55772888461044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark52(3.6580181474218243,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark52(36.616930667116264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark52(36.656674880667524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark52(36.6751465975817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark52(36.71908692616542,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark52(36.79431172964571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark52(36.81339937285229,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark52(3.6818352905153304,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark52(36.860637285308755,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark52(3.686800434362609,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark52(36.946866776174275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark52(37.03018201605872,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark52(37.05192864967259,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark52(37.05877222670635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark52(37.122765791651815,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark52(37.150219155614025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark52(37.164816072089934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark52(37.17645473728929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark52(37.22511586661155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark52(37.248895801078966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark52(37.328678487349414,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark52(37.329758086081256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark52(37.34077419307428,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark52(37.3466523267543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark52(37.37558785457474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark52(-37.46207764099075,-1.5707963267948992,1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark52(37.46521054081461,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark52(37.47131483377672,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark52(3.7513294315627093,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark52(37.52910203985987,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark52(37.54161461329786,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark52(37.579741185574825,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark52(37.6161436199167,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark52(37.687696860902165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark52(37.71802029348082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark52(37.76487742441866,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark52(3.7768839522047273,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark52(37.81619135822157,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark52(37.83385167321137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark52(3.784775310513112,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark52(37.85020207647368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark52(37.85644271314544,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark52(38.06440866491795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark52(38.07355222053708,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark52(38.07479616878462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark52(3.8095522347818425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark52(38.15106200702202,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark52(38.18942940766345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark52(38.26852202105795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark52(38.305262809206795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark52(38.32563895958731,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark52(3.838060839798591,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark52(38.3823096139397,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark52(38.40967815187123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark52(38.42998962857888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark52(38.43850778190176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark52(38.45723832267368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark52(38.47243905611961,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark52(38.57550658800812,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark52(38.625772770421804,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark52(3.878100945763234,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark52(38.827969975279785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark52(38.89321761594406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark52(38.915929764496724,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark52(-38.9592477501301,-1.5707963267948983,-0.27536289439936823 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark52(38.96098628345366,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark52(38.97352863461708,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark52(39.056547466353194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark52(39.06821704579312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark52(3.908113092048369,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark52(39.158185194626675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark52(39.25455604068985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark52(39.308823548748975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark52(39.3347200190545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark52(39.35786698924494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark52(39.357984545135785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark52(39.36914976265069,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark52(39.37456843041588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark52(3.9424121248493204E-49,-1.5707963267948966,0.06255252523349725 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark52(39.530634126714574,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark52(39.53726675324262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark52(39.55183596645698,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark52(3.957018958991603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark52(39.613412519466664,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark52(39.62509316273635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark52(39.6485743316089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark52(-3.9664761266162665E-28,-8.077935669463161E-28,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark52(39.72197865590006,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark52(3.975929896239208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark52(39.82846009189322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark52(39.874469982091824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark52(39.90180380903625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark52(39.935131097290736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark52(4.000857976202385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark52(40.033420728189796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark52(40.0643626445036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark52(40.09003388680715,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark52(40.12836885477064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark52(4.01315124145747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark52(40.135691061571464,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark52(40.170079678444736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark52(40.22775156608097,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark52(4.033103521711573,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark52(40.3556742595313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark52(40.36192183690363,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark52(40.398317866596216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark52(-40.4111199154554,-1.5707963267948966,-68.96178805086707 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark52(40.42501404075122,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark52(40.44556014474762,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark52(40.45973662849558,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark52(40.48475024824738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark52(40.50570411264823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark52(40.52354769502887,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark52(40.531338095755544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark52(40.633602640919726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark52(40.65348979350148,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark52(40.65450313353816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark52(40.670614751208305,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark52(40.70229615054208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark52(40.75568860924474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark52(40.7569206910512,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark52(40.760013400674325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark52(40.80549396416129,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark52(40.81095780645768,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark52(40.824915423856766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark52(40.862875503984554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark52(40.876671788950986,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark52(40.90539378940093,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark52(40.93951012098384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark52(4.098256250378427,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark52(41.05112546302796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark52(41.29602577609444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark52(41.33131328711845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark52(41.339790978325226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark52(41.346563719199196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark52(41.357735357412395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark52(41.37584628895192,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark52(41.37702149864493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark52(41.38774181372438,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark52(41.40161935897489,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark52(41.42109309120977,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark52(41.494623803099614,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark52(41.50241235451082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark52(41.51355523980499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark52(41.59682759366179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark52(41.61140934826741,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark52(41.63374488510365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark52(41.66312598585162,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark52(-41.697050751833764,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark52(41.69729886601748,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark52(41.70566784356336,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark52(41.72805368537746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark52(41.733029079658834,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark52(41.767009361694974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark52(41.80183569483442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark52(4.1859619867500735,-1.5707963267949,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark52(41.86828153135788,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark52(41.90864150022509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark52(4.192963565266188,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark52(41.959631533922845,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark52(41.97487871026528,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark52(42.00748470423717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark52(42.03067501915319,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark52(42.03165877333332,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark52(42.033872733579436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark52(42.05698858673656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark52(42.10010594431233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark52(-42.11982389426468,78.2299129177494,77.06740960083843 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark52(42.151524420202826,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark52(4.216595513614308,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark52(42.17494366382523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark52(42.195157437594624,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark52(42.21762924232553,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark52(42.22193819864929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark52(42.24671160325472,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark52(42.27899537000511,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark52(42.30179630563816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark52(42.30431993560336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark52(42.31166437223744,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark52(4.23352103121001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark52(42.35161141492618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark52(42.38269543483037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark52(42.39396679890899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark52(42.481689280673585,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark52(42.501505881031605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark52(42.50466595945143,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark52(42.58361079141415,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark52(42.635682837706824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark52(42.65843515916909,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark52(-4.269162885819043,-1.5707963267948966,-0.18709604407128833 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark52(42.69667298261235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark52(42.71015670891276,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark52(42.79673657625281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark52(42.87599478929524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark52(4.287970032931475E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark52(4.298678298390059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark52(43.01018991799066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark52(-4.309350461630913,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark52(43.10574782078265,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark52(43.1322047189194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark52(43.16728070557591,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark52(43.20467870341119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark52(43.215581744791166,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark52(43.22152814827474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark52(-4.323385848331908,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark52(43.25028872743183,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark52(43.261929460384266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark52(43.29340633865792,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark52(43.29583892193233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark52(43.31180280725809,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark52(43.31671618580595,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark52(43.370583915550576,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark52(43.40720862193942,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark52(43.44004898538409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark52(43.47811456888415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark52(43.50740305828157,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark52(43.519927591367036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark52(43.545684959238756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark52(43.56171631887605,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark52(43.57034822945607,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark52(43.5858100860507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark52(43.605357303609196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark52(4.366056960582824,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark52(43.681098741008924,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark52(43.70096700013221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark52(43.76856608713275,-1.5707963267948912,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark52(43.771775675201425,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark52(43.82938330637978,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark52(4.390623275532045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark52(43.931429228041644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark52(43.97849886096202,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark52(-4.398849936282177,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark52(44.01839055686408,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark52(44.02322023481188,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark52(44.09394270745108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark52(44.17800783629599,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark52(44.20435103460178,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark52(44.26442003832216,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark52(44.27713671596542,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark52(-44.30855716234589,-1.5707963267948966,-0.3977619258465641 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark52(44.31537369808255,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark52(44.356817100471524,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark52(44.38795821356775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark52(4.440892098500626E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark52(-4.440892098500626E-16,-1.5707963267948983,-0.9350807617576757 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark52(44.42321845885945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark52(44.454917758547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark52(44.47696909926577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark52(44.48178965535818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark52(44.50550343439045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark52(44.52244262867606,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark52(44.54285340751667,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark52(4.458862735840128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark52(44.659929952003154,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark52(44.677202584545675,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark52(44.71535990440562,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark52(44.716589193770474,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark52(44.772923909795395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark52(44.77459544088387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark52(4.4781692576480765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark52(44.784099349951425,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark52(44.7965624791951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark52(4.479732753865349,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark52(44.88242392423706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark52(44.893406383352584,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark52(4.493081740670381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark52(45.00788870464789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark52(45.02120737394661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark52(45.021525702303855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark52(-45.048700490152086,-1.5707963267948966,-0.4887980232398801 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark52(45.07906725580496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark52(45.08413111648653,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark52(45.17338233774444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark52(45.236642927296955,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark52(45.24182542928538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark52(45.28941448385284,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark52(45.36032800562168,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark52(45.38292579313106,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark52(4.539192501686662,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark52(45.53102776024704,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark52(45.61816751275124,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark52(-45.633363370128436,-1.5707963267948983,44.15765525861501 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark52(-45.63559435558976,-1.5707963267948966,4.201125923908942E-30 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark52(45.65634981913581,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark52(45.65648917621502,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark52(45.66894563095207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark52(45.6709002885995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark52(45.69233309465865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark52(45.693869472897916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark52(45.72946608034087,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark52(-45.78175003822682,16.229186890144547,10.221998049935536 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark52(45.86695331581724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark52(45.874595522693376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark52(45.89535359214004,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark52(45.940800790063285,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark52(45.95451120710137,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark52(45.96166598885687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark52(46.00392034219248,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark52(46.043221215613045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark52(46.08023962216325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark52(46.11108133584686,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark52(46.24618125579215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark52(46.2638716964401,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark52(46.28303772447323,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark52(46.34404176682075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark52(46.38033745628377,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark52(46.48038063767382,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark52(46.553590159085964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark52(46.56752413123253,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark52(46.588091700233676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark52(46.60050753732122,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark52(46.601073998331586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark52(4.660174424488438E-27,-1.5707963267948966,-0.06255252524170596 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark52(46.87878987878125,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark52(46.940715775514974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark52(46.9869053985226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark52(46.98929708014503,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark52(47.0220759859379,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark52(47.0386950794487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark52(47.1582274981249,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark52(47.161280847659555,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark52(47.18011666834073,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark52(-47.20840009960687,-1.5707963267948966,89.61846557103955 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark52(47.21093972988274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark52(47.2384201908322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark52(47.29991488302173,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark52(47.35936141681039,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark52(47.365121558589365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark52(47.386303296765874,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark52(47.399399840577466,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark52(-47.42368766865048,-1.5707963267948966,45.381068024817694 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark52(47.436807429508335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark52(47.45581730429868,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark52(47.509635979926884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark52(-47.516015292498224,87.79402159629242,-39.93808104389838 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark52(47.64964811302224,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark52(47.700056331490714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark52(47.70171434225176,25.20775156993369,-62.45414039385177 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark52(47.72244963244399,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark52(47.78069680595908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark52(47.79927962566774,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark52(47.821679933910104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark52(47.82647311505267,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark52(47.83125090754471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark52(47.89849700638517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark52(47.90757583677974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark52(47.93527413985404,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark52(48.0206269916543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark52(48.04592564905539,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark52(4.81088517365022,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark52(48.11242012952263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark52(48.127895176671444,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark52(48.14030956559208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark52(48.16555319823652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark52(4.8180002504020365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark52(4.821351870894631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark52(48.21518721314945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark52(48.24950159599075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark52(48.276861426078256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark52(48.39768261320084,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark52(48.42235888188114,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark52(-48.449563313604386,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark52(48.47719961063188,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark52(-48.47797975438816,-1.5707963267948966,-42.08659644698522 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark52(4.851364912326138,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark52(4.851376761881809,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark52(48.56211392696227,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark52(48.642724522284254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark52(48.70534446917048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark52(48.71897611405238,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark52(48.805331367504195,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark52(48.856116282825916,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark52(48.868889795571846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark52(48.9181480672762,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark52(48.97465012165036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark52(48.98037543632239,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark52(48.999489971890014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark52(49.031701278550166,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark52(49.063885078825535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark52(49.09421945851631,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark52(49.11782424817508,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark52(49.14992374117027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark52(4.916632821308945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark52(49.18010236457626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark52(49.189425089544706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark52(4.920125071868981,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark52(49.23166342707225,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark52(49.27327492092687,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark52(-4.930380657631324E-32,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark52(49.34709341395043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark52(49.43844481729337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark52(49.477347523199455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark52(49.49968251283744,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark52(49.53723463322661,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark52(49.54303373376052,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark52(49.606450167991625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark52(4.961689227631905,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark52(49.65157135412157,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark52(49.67620135162894,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark52(-49.70284349342911,-48.72512837625644,59.37490341558933 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark52(49.70805935700179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark52(49.71011729588466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark52(49.75034916819688,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark52(-49.78494623050307,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark52(4.9808450524888706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark52(49.81971766845902,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark52(49.8215060387117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark52(49.92361180855002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark52(49.94495759697023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark52(49.970977129487835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark52(49.98347056410921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark52(50.020479011216096,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark52(50.05890551671726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark52(50.13269144426206,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark52(50.139857498599895,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark52(50.16263146739368,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark52(50.171809527248485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark52(5.026986911807372,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark52(5.038229900483557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark52(50.41074319700897,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark52(50.45737484967179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark52(50.461927767859066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark52(50.51218076235415,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark52(5.053761134265768,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark52(50.5411974519719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark52(5.0561879857842795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark52(50.56234540743525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark52(-50.59046784974033,-1.5707963267948966,-35.66864232135065 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark52(50.59430985546108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark52(50.681742848735965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark52(50.75717034300696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark52(50.78356192898588,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark52(5.081903531221471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark52(50.8538882401341,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark52(50.91600823532724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark52(50.93019142932108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark52(50.985000240143094,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark52(50.985026417800704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark52(51.01550860878612,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark52(51.12005533946618,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark52(51.15844579878632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark52(51.180573462130354,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark52(51.19653099694055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark52(51.19799452604226,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark52(51.24157360308743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark52(5.129222897308564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark52(51.30829371645088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark52(51.342984483516716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark52(51.34708187753676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark52(51.37162002169677,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark52(51.394006055789134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark52(51.412094046588855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark52(51.45683359196902,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark52(51.47746682589525,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark52(51.56118462120152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark52(51.609721531378426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark52(51.676572375370355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark52(51.72903435128694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark52(5.176005504682635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark52(51.81352972915999,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark52(51.878175576600455,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark52(51.95953084950185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark52(5.201736898424485,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark52(52.05206129162923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark52(-52.07569448903468,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark52(-52.26360103605767,-1.5707963267948966,41.294537367224905 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark52(52.278677408201105,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark52(52.30281640118312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark52(52.37811787535827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark52(52.39233803692227,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark52(52.414910203551074,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark52(52.45529163566658,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark52(52.48465678112464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark52(52.495237095182176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark52(52.5081908729459,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark52(52.50918399650782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark52(52.51460385622205,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark52(5.2547040726367475,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark52(52.568352719689614,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark52(52.569793420660744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark52(52.59791589461393,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark52(52.61922929181827,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark52(52.6503676155246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark52(52.677898399878075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark52(52.70649868259437,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark52(52.730636656571626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark52(52.7312950074304,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark52(52.78757005618326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark52(52.8240628720855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark52(52.83259052565661,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark52(52.84751465151538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark52(-52.872740119005186,-1.5707963267948966,-0.01023346985827106 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark52(52.89698383478658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark52(-52.9144359806501,-1.5707963267948966,2.7254551178036976 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark52(52.95031727611823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark52(52.95864980727021,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark52(53.00129769935583,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark52(53.06955069409265,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark52(53.24201763669067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark52(53.250984669444364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark52(5.331984020960362,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark52(53.33185251033136,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark52(5.3340387083443375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark52(53.361757785892394,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark52(53.37443260337798,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark52(53.38628758369348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark52(53.4237874965237,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark52(-5.346624584847376,-1.5707963267948966,8.470329472543003E-22 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark52(53.48934655960886,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark52(53.54463442310153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark52(53.57078964045613,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark52(53.60442605557848,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark52(53.62442816257867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark52(53.655440872652406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark52(5.3712687474730245,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark52(53.735566444434625,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark52(5.373848052788848,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark52(5.373906349632534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark52(53.780537059519304,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark52(53.81933710210228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark52(53.85781994838977,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark52(53.88636718374758,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark52(-5.395973427962895,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark52(-53.97476922362498,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark52(54.0446036373134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark52(54.050419311263,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark52(54.06941321818863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark52(54.14509566632993,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark52(54.15330244584953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark52(54.21824540853314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark52(54.220268548588905,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark52(54.223319547847645,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark52(54.229366190000725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark52(54.27154962061521,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark52(54.325463223146386,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark52(54.37423342303679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark52(54.381358346997246,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark52(54.39683191545388,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark52(54.466900626651416,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark52(54.47834342115644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark52(54.52077717963711,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark52(54.52815866069318,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark52(54.60938150714557,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark52(54.63008991723806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark52(54.63079339885317,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark52(54.78708682702288,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark52(5.47906881055269,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark52(54.85086320033082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark52(54.91442571121206,-1.5707963267948877,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark52(54.936793089923086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark52(54.99475206264645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark52(55.028114142048764,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark52(55.04904131510051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark52(55.05841617238617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark52(55.07669203599862,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark52(5.5140757492174775,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark52(55.180688278432996,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark52(55.196130018601735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark52(55.223108439344145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark52(55.25120986291038,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark52(55.270977501438665,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark52(55.27937059348389,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark52(55.28776412346124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark52(55.33611739757981,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark52(5.53487421423254,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark52(-5.534946740756922,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark52(55.48792699476758,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark52(55.50211884564596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark52(55.53578713828457,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark52(55.55905573582745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark52(55.56631770429311,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark52(55.568290242520376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark52(55.57328326554634,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark52(-55.58586928893023,-1.5707963267948957,2531.5910285958425 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark52(55.68871240890597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark52(55.70231999108904,-1.5707963267949037,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark52(55.729974853098184,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark52(5.5770870150739285,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark52(55.831153897209816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark52(55.856538135431265,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark52(55.86070985820251,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark52(55.94087984940674,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark52(55.95808294028184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark52(55.9984572766794,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark52(5.605989450433995,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark52(5.610101298157933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark52(56.166592989690486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark52(56.2110624915742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark52(5.624157664583706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark52(56.28936595468929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark52(56.2976571869585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark52(56.3189594618124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark52(56.35628116010133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark52(56.44916836746889,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark52(56.473256422448024,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark52(56.53639967446702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark52(5.660786115463054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark52(56.62131473916429,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark52(5.668797349712182,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark52(56.71320480954617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark52(56.8091837265179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark52(56.85119771180961,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark52(56.86802878381289,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark52(-56.87944415780461,-1.5707963267948966,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark52(56.89042140934086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark52(56.89526094346428,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark52(56.94271744566507,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark52(56.989511242902886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark52(57.07739815271085,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark52(5.716503509114929,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark52(57.20357792637337,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark52(57.20604925925293,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark52(57.273193738963045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark52(57.29563038849262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark52(57.315792551037745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark52(57.32800819811989,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark52(57.33762524653088,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark52(57.4026693434364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark52(57.420677065264385,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark52(57.47260619797646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark52(57.52306548351595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark52(57.58207857685972,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark52(57.635426937716296,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark52(5.764466834549921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark52(57.65439973001334,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark52(5.769045857159215,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark52(57.72632634694045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark52(57.7264402043092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark52(57.773436531133385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark52(5.7784159778570015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark52(57.80920115757633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark52(-57.83322576975172,-1.5707963267948966,7.451658374982358 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark52(57.83986950479903,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark52(57.8418984926802,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark52(5.786299784424104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark52(57.972835453471504,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark52(57.97508973869553,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark52(58.06091324531346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark52(58.072263055461015,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark52(-5.8122406682993047E-64,-1.5707963267948966,-2.5489470578119236E-57 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark52(58.16456541686043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark52(58.17354618960985,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark52(58.20968225563405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark52(58.261910931516375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark52(58.26898108264466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark52(58.30803609775519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark52(58.31746147946745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark52(5.831844691965642,-1.5707963267949,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark52(58.329807346563534,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark52(58.38872064063176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark52(5.847731686071459,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark52(58.4916127876717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark52(58.50628464710618,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark52(58.52956072326151,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark52(58.53987294259798,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark52(58.55337127205496,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark52(58.56009317582184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark52(58.664643609414,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark52(58.712143684003664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark52(58.78933586657743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark52(-58.897272200746585,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark52(58.924764381632,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark52(59.0724315290602,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark52(59.0731480573651,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark52(5.912286083169051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark52(59.16951046457038,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark52(59.17458826498603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark52(-59.195125208104216,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark52(59.20660635052702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark52(59.21837927215514,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark52(5.923622318361325,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark52(59.26319800747359,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark52(59.314110517138374,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark52(5.946749316180373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark52(59.53242833911778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark52(59.59954122952229,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark52(59.63450884341243,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark52(59.638904562159595,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark52(59.76370447828674,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark52(59.777947654493204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark52(59.78664561113735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark52(59.841264045455745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark52(59.84950208413832,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark52(-59.85197518540335,-1.5707963267948966,-2427.4559405817713 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark52(59.871555469880484,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark52(59.87774083085501,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark52(59.88994488567204,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark52(59.9707937714402,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark52(60.00040438758283,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark52(6.0056603564863025,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark52(60.0856303743045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark52(60.11090579570238,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark52(60.14584846003235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark52(60.28078513991355,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark52(60.34467799086546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark52(60.40077953045554,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark52(60.42075149194172,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark52(60.4530253194463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark52(60.56238380552054,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark52(6.05655262295744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark52(60.588434720462956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark52(60.61456172857436,10.38144179728775,78.21514235798665 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark52(6.061689783814302,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark52(60.620117635090594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark52(60.62483093995066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark52(60.66428214001152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark52(60.723093709596796,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark52(60.78501049444313,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark52(60.820164009958596,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark52(60.823930805845535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark52(60.85265191583454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark52(60.89998489192575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark52(6.092849099002424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark52(60.97688204438377,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark52(61.01223309642151,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark52(61.02055822757766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark52(61.06914943635513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark52(61.07459301357315,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark52(61.07747760829168,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark52(61.143384147930604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark52(6.115336299153043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark52(61.18627536702482,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark52(6.124856296089703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark52(61.25268482135066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark52(-61.25302707708295,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark52(-61.2787611830538,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark52(61.34069075644643,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark52(61.35194582609778,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark52(61.40631097310852,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark52(6.148178140002365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark52(61.53848790421492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark52(61.56053679358747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark52(61.567719434876956,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark52(6.158925357132602,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark52(61.609097603473806,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark52(61.62735904189466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark52(61.648878829298795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark52(61.715518118249264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark52(61.7296848544262,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark52(61.755102410071906,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark52(61.801778818722894,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark52(61.80715973719294,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark52(61.82375786339594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark52(61.83417704773335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark52(61.90183353339984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark52(61.970157828743176,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark52(61.99726216431913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark52(62.06617162393994,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark52(62.0777816799381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark52(6.214162599448609,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark52(62.274022769889086,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark52(62.282918599465674,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark52(62.3001287405592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark52(62.322115468440586,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark52(62.364035327443744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark52(62.37857420415949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark52(62.44002404643109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark52(6.250164415285738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark52(6.250756285153102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark52(62.59351237596571,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark52(62.59917879595951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark52(-62.7141113246077,-1.5707963267948966,2414.353039970943 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark52(62.734685470978064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark52(62.743303411727226,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark52(6.276561821980131,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark52(6.276810064625948,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark52(62.81409004408306,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark52(6.2913201251056705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark52(-63.075855655962684,-1.5707963267948966,0.2669625171955001 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark52(63.17982738632113,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark52(63.182515665862134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark52(-63.19363554609071,-1.5707963267948966,57.693519105255895 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark52(63.25742463412048,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark52(63.28391124592531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark52(63.398050331093344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark52(63.41934517138923,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark52(63.44508629750076,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark52(63.453206074013536,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark52(63.561483599327886,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark52(63.59726858428289,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark52(63.79599853061567,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark52(63.831703756921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark52(63.944938947933196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark52(63.968810273921974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark52(63.99158364665209,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark52(64.13593171590192,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark52(6.413841944546121,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark52(64.15723616092424,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark52(64.1661101700743,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark52(6.421568194552944,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark52(64.27560329146718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark52(64.36545208404112,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark52(64.41037306116921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark52(64.44448486482648,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark52(-64.48665257562429,-1.5707963267948966,-93.03006173142794 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark52(64.49062233642539,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark52(64.49479066717424,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark52(64.56731791083611,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark52(64.57159074404582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark52(64.5909848320309,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark52(64.60443156871418,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark52(64.6485255136393,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark52(64.66088990720895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark52(64.69190871299212,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark52(-64.74904560492836,-1.5707963267948966,-0.771182472335887 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark52(64.78650749414336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark52(64.80765567444135,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark52(-64.82589257664854,-1.5707963267948966,9.022237388782775E-14 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark52(64.82795046532078,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark52(64.8368171084307,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark52(6.483908448138507,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark52(64.87607210266036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark52(64.89861735321014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark52(6.490479599247198,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark52(64.98854118775866,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark52(65.06207517644185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark52(6.50674169213173,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark52(65.09181734000504,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark52(6.511033991497051,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark52(65.11753541256152,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark52(-65.16513512676303,-1.5707963267948966,0.5399157233401548 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark52(65.18966751115644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark52(65.22844183914786,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark52(65.26423731086305,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark52(65.27384283290728,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark52(65.2884180138791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark52(65.2928435547656,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark52(65.295512389974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark52(6.535429547307572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark52(65.3548373014793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark52(65.50179952082242,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark52(6.553552942532349,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark52(65.58314041842279,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark52(65.63577327946138,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark52(65.64438153958345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark52(65.6596623432766,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark52(65.67068092450295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark52(6.5718012740771705,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark52(65.72331641296101,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark52(65.75580883650454,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark52(65.79431501218498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark52(65.82825493572261,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark52(6.589795493429577,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark52(6.605781581550492,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark52(6.6082777579887235,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark52(6.6112386048646385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark52(66.27494411499876,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark52(66.3281159008603,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark52(66.43598632527434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark52(66.44622427645027,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark52(66.45537938528926,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark52(66.47687963019203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark52(66.49218105875747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark52(66.50128836366537,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark52(66.50873943783714,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark52(66.5309333501578,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark52(66.53216082350272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark52(-66.55745078287367,-1.5707963267948966,-21.276421722085036 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark52(66.65832851965743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark52(66.73412488358949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark52(66.77169505931208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark52(66.82411408594156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark52(6.686688542659992,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark52(66.94021051426546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark52(66.96336348216325,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark52(66.97715099688685,-1.570796326794893,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark52(66.98180505839858,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark52(6.715617966548129,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark52(67.18205479795935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark52(67.2170340728255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark52(67.21849742292623,-1.570796326794897,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark52(67.23023329963898,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark52(6.724466553396139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark52(67.25316842195934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark52(-67.39654218405462,-1.5707963267948966,3.2311742677852644E-27 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark52(67.40344840894855,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark52(67.48224483836933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark52(67.50838071898522,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark52(67.5500988237014,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark52(67.56442400046933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark52(67.57684384995115,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark52(67.64601660982592,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark52(67.65006497523761,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark52(6.765612794928927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark52(-67.68901776253276,-1.5707963267948966,55.59064629806548 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark52(67.69873977089273,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark52(67.74416572517589,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark52(67.77085938779373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark52(67.78757360297607,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark52(67.83488147689029,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark52(6.7882396837696835,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark52(67.97356011241064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark52(67.97716156089629,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark52(-68.0689799959304,-1.5707963267949,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark52(68.0727900951056,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark52(68.10794686233464,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark52(6.812636601339335,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark52(68.21230099147513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark52(68.30155299192441,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark52(-68.30961502970378,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark52(68.40970224474991,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark52(68.46209780223795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark52(68.55130706307742,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark52(68.55215502976907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark52(68.5791914573789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark52(68.64026395950405,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark52(-68.64344443425372,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark52(68.64512758141409,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark52(68.66781821546766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark52(68.69964735393546,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark52(68.74778617929346,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark52(68.7668973232519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark52(68.83906719847738,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark52(68.88845334070179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark52(68.88910906222493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark52(68.9399863423207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark52(68.96241963637061,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark52(6.897739902756644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark52(68.97929258647281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark52(69.1672181966056,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark52(69.28647856758393,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark52(69.29029824393794,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark52(69.36464094407685,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark52(6.939136025684498,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark52(69.39148152134007,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark52(6.940501387740777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark52(69.40783858159921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark52(-69.44068522687755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark52(69.5359937620108,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark52(69.56381023214837,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark52(69.6632570255391,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark52(69.77957331362175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark52(-69.7962021092664,-1.5707963267948877,0.7903482113418627 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark52(69.82883510700023,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark52(6.983987333260799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark52(69.99999243957012,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark52(7.005353467619457,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark52(-70.06355849393103,-1.5707963267948948,-0.8144137989999294 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark52(70.10308427596044,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark52(70.1819861886716,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark52(70.20325804011387,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark52(70.23262499535646,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark52(70.24929624410835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark52(70.3528375319076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark52(70.39570150754993,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark52(70.48121751620398,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark52(70.5531574604878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark52(70.5559560539019,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark52(70.55612822369261,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark52(70.56321713313372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark52(70.5968814494036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark52(70.61812047206372,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark52(70.62844051986573,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark52(7.066652675694384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark52(70.79101771625116,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark52(70.79222823410893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark52(70.79815358984447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark52(70.79986090265692,-52.78780400232239,-51.80114421886775 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark52(70.80712606703713,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark52(70.80745757583247,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark52(70.85618150060725,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark52(70.8647227079552,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark52(7.088953244696839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark52(70.90351166543513,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark52(70.91069070960782,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark52(70.91359138092623,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark52(70.93705195345544,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark52(71.04807367505336,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark52(7.105427357601002E-15,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark52(-7.105427357601002E-15,-1.5707963267948966,-19.45459780841241 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark52(71.10319375763265,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark52(7.1111518527475965,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark52(71.14953414687838,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark52(71.18383313824089,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark52(71.2147526189748,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark52(71.21847557270635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark52(71.45054385607531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark52(71.50091144192118,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark52(7.16391414992621,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark52(71.65977202326451,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark52(7.166036203058264,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark52(71.66365650343717,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark52(71.6828519377213,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark52(71.69043284386252,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark52(71.73805854289722,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark52(71.74449574967109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark52(7.1762004171809854,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark52(71.80949587780762,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark52(71.81587920087595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark52(71.82149672915884,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark52(71.83351192212521,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark52(72.04316568571488,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark52(72.05278589007473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark52(7.207395704466315,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark52(72.15950035884791,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark52(72.22150143595894,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark52(72.23407035081982,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark52(-72.24264593424913,-1.5707963267948966,0.5336002715856196 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark52(72.29060356332897,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark52(7.229626604917055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark52(72.299376848132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark52(72.37302983773469,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark52(72.39807497872,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark52(-7.241594886155365,-1.5707963267948966,-53.98655190776624 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark52(72.42455594999976,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark52(72.42753727702527,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark52(72.45261106019967,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark52(72.4986733265082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark52(72.56946652276012,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark52(72.59740655453749,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark52(72.62997583494521,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark52(72.64148243428636,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark52(72.65789736416816,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark52(-7.272077499672438E-25,-1.5707963267948966,1.0269992293206252 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark52(72.74870714799658,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark52(72.75405515240513,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark52(72.79290969139545,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark52(72.82378388077682,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark52(72.82760748219103,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark52(72.82879631773487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark52(72.86931647359347,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark52(72.91402320696002,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark52(72.94445915345507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark52(72.99151799753339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark52(73.01364017890823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark52(73.03022128080018,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark52(7.304377754245067,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark52(-73.09754858321294,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark52(73.11855007169194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark52(73.14859861069947,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark52(73.19569965121048,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark52(73.2722783804889,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark52(73.30612373158958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark52(73.4209409767143,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark52(73.47026911477249,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark52(73.48556154656478,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark52(73.49008736848626,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark52(73.49203807885844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark52(73.5597313540038,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark52(73.58194350357127,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark52(73.59521643422846,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark52(73.67897307847838,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark52(7.379047848707096,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark52(73.90370964531519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark52(74.00300744488233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark52(74.0345209227221,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark52(-74.1588395922125,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark52(74.16674819042848,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark52(74.19234680385419,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark52(74.19713067778312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark52(74.20624921732434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark52(74.313245443951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark52(7.4326382902893275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark52(74.34164425160361,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark52(74.35754109367298,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark52(74.37888565970228,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark52(74.39282613164893,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark52(74.4139760014856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark52(74.41451931059598,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark52(74.4659029821922,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark52(74.5087721150187,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark52(74.53278379236744,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark52(74.54816785050943,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark52(74.7545525709543,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark52(74.76346921040818,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark52(7.481610147422785,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark52(7.482960380146281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark52(74.83462457959865,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark52(74.893600515351,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark52(74.97429157369956,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark52(75.06724443646681,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark52(75.07850457757463,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark52(75.21629075299344,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark52(75.2441258544145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark52(75.25372011195533,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark52(75.38775811499085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark52(75.40466080474134,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark52(75.43359305423645,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark52(75.44851429828375,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark52(75.45110804518441,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark52(75.46306613005619,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark52(75.5262387694373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark52(75.60650021647518,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark52(75.67771127391644,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark52(75.73867626497619,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark52(75.76392513252348,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark52(-75.76659567873521,-1.5707963267948966,0.2596766848176617 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark52(75.81123475594194,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark52(7.5873503257021895,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark52(-75.91985169464829,-1.5707963267948895,-0.6053916399026917 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark52(76.06555508978317,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark52(76.10024657892941,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark52(76.11856872605911,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark52(76.15051780605332,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark52(76.20028008224982,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark52(76.22039725030118,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark52(76.43587398399242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark52(76.53579684104997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark52(76.66086153733863,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark52(76.72206355228529,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark52(76.74170696957157,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark52(76.78672695902233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark52(76.80655328965395,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark52(76.84213323037778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark52(76.92477322102836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark52(76.92862532443243,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark52(76.9468287865644,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark52(76.9553023636861,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark52(76.99953196385314,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark52(7.701756651200256,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark52(77.02268968453983,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark52(77.12513887900583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark52(77.15128438863486,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark52(-77.24950231920519,-1.5707963267948966,0.9482927851691394 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark52(-77.2839262022611,-1.5707963267948983,-45.32520648660706 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark52(77.33784967055914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark52(77.35514499567257,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark52(7.736471591389385,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark52(77.40162376060772,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark52(77.47537875108372,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark52(77.52324764067046,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark52(77.55736844473277,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark52(77.5728412509497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark52(77.57793684081071,-1.5707963267949054,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark52(77.63358845225147,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark52(77.70238545557493,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark52(77.77005980578312,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark52(77.80126999892104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark52(77.93334380132185,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark52(78.03168665531726,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark52(78.05077304050734,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark52(78.06508230164638,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark52(78.06987169521105,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark52(78.160483279935,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark52(78.26506323554523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark52(78.27237367214028,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark52(78.3157782668339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark52(78.41735112232391,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark52(78.42262945262468,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark52(7.850651678803473,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark52(7.854327425560797,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark52(78.76408752174304,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark52(78.84093463539597,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark52(78.93104542960023,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark52(78.96357821893436,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark52(7.899271910090448,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark52(79.0507397826633,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark52(79.0535933665373,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark52(79.05974756966526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark52(-79.08591884215559,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark52(79.12893804673718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark52(79.18194475617864,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark52(79.22277023589899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark52(7.9241659551402535,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark52(79.30149391302547,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark52(79.32295541964244,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark52(79.40284266066973,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark52(79.42234598050953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark52(7.943279053299685E-18,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark52(79.44751891741564,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark52(79.55393040429077,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark52(79.58278795616326,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark52(79.58947779569179,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark52(79.64147215326975,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark52(7.965652316259607,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark52(-79.7727732421944,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark52(79.77511926764507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark52(79.85178134829977,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark52(79.87641781368757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark52(79.8832747843997,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark52(79.94125902079196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark52(79.9585095922499,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark52(80.13795383016155,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark52(80.19389531908146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark52(-80.20530816335167,53.29297575151796,79.84599464550007 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark52(80.27523269773339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark52(80.39716469108092,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark52(80.47858069515016,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark52(80.53048115885747,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark52(80.65653556278124,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark52(8.066142411947688,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark52(80.75839763653664,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark52(80.77363119396384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark52(80.77469737719599,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark52(80.78392780978615,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark52(80.82731157925411,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark52(80.82874816103487,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark52(80.83264609538104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark52(8.087945073007159,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark52(8.104014111937904,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark52(81.11664221234182,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark52(-81.12420394657897,-38.884866536113826,1.976681377273934 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark52(81.18177806053001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark52(81.1982611739365,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark52(81.19852243026679,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark52(81.26311674598182,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark52(81.26799019157572,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark52(81.27190244907693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark52(81.33417001380059,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark52(81.36283750817836,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark52(81.3862750676291,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark52(81.42557240852173,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark52(81.5114656783743,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark52(81.51157628429175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark52(81.54075945127119,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark52(81.5605734477825,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark52(81.75010791269494,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark52(-81.76788581272001,-1.5707963267948966,0.06255254311203826 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark52(-81.80359217416664,-1.5707963267948966,-0.020763056650860316 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark52(81.82818175419447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark52(81.87954117327568,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark52(81.9217529701966,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark52(81.94965684138876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark52(82.01772533116517,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark52(82.11425958796036,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark52(82.11639672336678,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark52(82.13863880395458,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark52(82.14341562621075,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark52(82.18156233878821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark52(82.26296115026413,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark52(82.28231336930958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark52(82.32044234495129,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark52(-82.37775271134271,-1.5707963267948966,-68.68331543498486 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark52(82.39881256493823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark52(82.42171945122666,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark52(82.46537291807036,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark52(8.246926545697104,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark52(82.52599743828145,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark52(8.256868979897746,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark52(8.258573707649322,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark52(8.260634489707446,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark52(82.63937228984724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark52(82.6819657206595,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark52(-82.70337188590864,-1.5707963267948966,-63.85335687450395 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark52(82.77363505228365,-1.570796326794886,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark52(-82.86733466317861,-1.5707963267948968,0.38541155677000816 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark52(82.95398831616745,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark52(82.994072928495,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark52(83.06336142610951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark52(83.14488729518683,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark52(8.316453367759852,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark52(83.22698447462938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark52(83.32402921337196,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark52(83.4566234222965,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark52(83.53947455162039,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark52(83.56345816607703,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark52(83.56507419031269,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark52(83.5733140959949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark52(83.64079204601336,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark52(83.64639113421579,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark52(83.66295463781378,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark52(83.67409986405627,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark52(83.68449214108095,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark52(83.69269314548295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark52(83.89761120243676,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark52(8.39273541356043,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark52(83.94403042434055,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark52(84.00147639653255,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark52(84.00964053814117,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark52(84.12621744935888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark52(84.22060558319274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark52(84.23794241552696,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark52(84.28361124097434,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark52(84.30249373523509,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark52(84.33908181007857,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark52(84.34122551909823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark52(84.40616145629694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark52(84.45985208179442,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark52(84.46707682143237,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark52(84.47668664084345,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark52(84.50838099297789,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark52(84.5442971744604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark52(84.58992400377385,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark52(84.65782601694974,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark52(8.475576714457471,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark52(84.91986087045927,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark52(84.94313771105112,-91.16667091218281,85.37873729020069 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark52(-84.97526510777827,-1.5707963267948966,-64.55459748148441 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark52(84.9901576379902,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark52(-8.503092866963437,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark52(85.11992998569835,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark52(85.12676809008003,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark52(8.521694622334829,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark52(85.25270803945756,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark52(85.33163722612915,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark52(85.37578893407826,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark52(85.41042012914133,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark52(8.546666769070551,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark52(85.51664042301567,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark52(85.55244488396156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark52(85.56093746477765,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark52(85.57235430585851,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark52(85.62046756757434,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark52(8.562315090554165,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark52(85.630763718406,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark52(85.65189703172095,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark52(85.75930394205184,-27.065635629565122,57.612040458659294 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark52(85.78427812879079,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark52(85.82894383672519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark52(85.90839514527134,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark52(85.96076400091766,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark52(85.96205754581354,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark52(85.98588739945066,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark52(86.05808706712214,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark52(86.08430951491849,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark52(86.10256477869422,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark52(86.10260763406724,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark52(86.18360029024831,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark52(86.2476234115899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark52(86.26023542440413,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark52(86.2795292998799,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark52(-86.3489761473826,-1.5707963267948966,-0.9999999999999989 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark52(86.35654364383132,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark52(86.36011404214447,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark52(8.637473270216567,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark52(86.38199832762339,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark52(-86.38804471202675,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark52(86.4666272805718,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark52(-86.46873503778251,-1.5707963267948966,-24.996003444052434 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark52(86.48215082367426,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark52(86.51619002295934,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark52(86.51658393633483,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark52(86.55609498804053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark52(8.656107981810864,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark52(86.70138317860412,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark52(86.73311743332422,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark52(86.73824076333995,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark52(86.77923021482493,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark52(86.8091735950519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark52(86.86778989904275,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark52(86.87087954621907,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark52(87.0234999576012,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark52(87.03648505672938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark52(8.705198605062815,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark52(87.05501626699953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark52(8.705811801273457,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark52(87.16730325836201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark52(87.17586055358132,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark52(87.28393429989583,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark52(87.326643867146,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark52(87.37465970926297,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark52(87.40554243817755,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark52(87.50064341051376,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark52(87.50285407490156,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark52(87.50296310992984,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark52(87.51305931591617,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark52(8.751570884369867,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark52(87.57138369007151,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark52(87.60016178619497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark52(87.62645268314219,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark52(87.69055668877408,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark52(8.770680523688384,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark52(87.72571455191888,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark52(87.77046769645301,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark52(87.82373654932431,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark52(8.785322732518251,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark52(87.93615474831812,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark52(-8.796600926223604,-40.29433856418401,56.5560276637041 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark52(88.00941910471971,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark52(88.07054656660921,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark52(-88.07894185396164,-1.5707963267948966,1.000000000012663 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark52(88.11486428026421,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark52(88.18966902538702,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark52(88.20199091294563,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark52(88.21561936416899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark52(88.24489737256123,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark52(88.25161578963525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark52(88.56939531816876,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark52(8.86292839209053,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark52(8.86512857732582,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark52(8.881784197001252E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark52(-8.881784197001252E-16,-1.5707963267948966,1.0706651855826603 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark52(-8.881784197001252E-16,-1.5707963267948974,-45.12581192905352 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark52(88.8525061989861,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark52(88.90465918289809,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark52(88.91002547079111,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark52(88.91537240977752,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark52(88.94926680990704,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark52(88.99711506015387,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark52(89.00062003556951,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark52(89.07878758396245,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark52(89.19650432302856,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark52(89.2890111637492,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark52(89.29792320274561,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark52(89.30921445068981,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark52(89.33662835662037,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark52(-8.936565552106558,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark52(89.36646169180722,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark52(89.52179530826757,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark52(89.54209073372594,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark52(8.95747814248795,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark52(89.58304061429001,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark52(8.960902157771727,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark52(89.6531241209345,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark52(89.80183118468781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark52(89.84918863327201,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark52(89.90024315259703,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark52(90.140222215036,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark52(90.16236904304736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark52(90.24304305932128,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark52(90.24850154484523,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark52(90.36078075567687,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark52(9.047344783250068,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark52(90.49303183484979,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark52(90.55480041434798,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark52(9.056178233702525,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark52(90.68751901514125,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark52(90.69721441088242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark52(90.76809306131207,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark52(9.078661231323835,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark52(90.80029962989153,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark52(90.9801505456447,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark52(91.0023845150767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark52(91.02688053594989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark52(91.03648938570439,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark52(91.04422755307442,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark52(-91.13788760841122,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark52(91.16372235802403,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark52(91.17109891055085,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark52(91.24681184651783,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark52(91.36014920169501,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark52(91.42310505055671,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark52(9.142476692799068,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark52(91.4542249216548,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark52(91.47188633427218,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark52(9.153673509817889,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark52(91.56153705405727,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark52(91.64163570413501,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark52(91.67832292200661,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark52(91.73680598024421,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark52(91.79140260005966,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark52(91.85039577860778,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark52(91.86727242562628,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark52(91.88214823318694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark52(-91.97808787663674,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark52(92.00113174134519,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark52(92.00652434607255,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark52(92.02662157154721,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark52(92.09354876284272,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark52(92.10593788405102,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark52(92.12297521048964,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark52(92.14231971201313,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark52(92.18491935787083,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark52(92.21712503475266,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark52(9.232771119178274,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark52(92.33896170545762,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark52(92.3738937586862,-90.93164174059136,95.78646519311678 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark52(92.37981101232735,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark52(92.3888785738767,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark52(-92.5058306651147,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark52(92.50723053965777,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark52(92.58340442110281,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark52(92.58425121712543,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark52(92.6570898673736,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark52(9.269081929453733,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark52(92.70778691787041,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark52(92.79061253568833,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark52(92.79574187184357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark52(92.90923296238914,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark52(92.99440827487186,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark52(93.02023100136793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark52(93.06204072878731,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark52(93.31933648502365,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark52(93.33300006223342,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark52(93.40831256353562,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark52(93.4141637407183,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark52(93.42220723544204,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark52(-9.342981759860852,-1.5707963267948966,0.04923465230407731 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark52(93.44977244570771,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark52(93.46753179313589,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark52(93.53962633902938,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark52(93.560031051035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark52(93.56304169598039,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark52(93.69626451333133,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark52(93.69698823891989,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark52(93.73622402322599,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark52(-93.75171595979174,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark52(93.87473261030368,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark52(-93.88238445045184,-1.5707963267948966,-0.948613620729239 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark52(93.91309367921141,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark52(9.39645317664078,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark52(94.00662367130032,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark52(9.406575257680629,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark52(94.12465190621577,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark52(94.23336130585719,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark52(94.37981333768958,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark52(94.41459534884497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark52(94.48833423656575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark52(94.49806889852142,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark52(94.54680024833067,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark52(94.57553978170016,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark52(94.5769451205199,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark52(94.57994419925559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark52(94.64958682851531,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark52(94.65265161637873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark52(9.46611637191441,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark52(94.81113512916082,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark52(94.89589444616428,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark52(94.95693896358245,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark52(94.96095624441489,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark52(-95.17810150337438,-1.5707963267948957,56.70052179271184 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark52(95.19955044986172,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark52(9.522275093686462,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark52(95.25877220187823,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark52(95.32544131447166,-1.5707963267949019,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark52(9.535653397919559,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark52(95.36487312758953,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark52(95.4473170537035,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark52(95.48485990117925,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark52(95.52263936804596,-1.570796326794893,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark52(95.6426683907538,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark52(95.64979060349017,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark52(95.66515730733809,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark52(9.575020572743071,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark52(9.583706109912924,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark52(95.94381995809553,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark52(96.1140006507575,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark52(96.25097708432045,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark52(96.27864433061399,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark52(96.29645584281064,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark52(96.29749121844239,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark52(96.3162334520191,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark52(96.32712801686844,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark52(96.41302434533364,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark52(96.42160567797563,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark52(96.45140275896588,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark52(-9.647580948278922,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark52(96.49617578128677,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark52(9.649831925673832,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark52(96.69364728750244,24.436932425088415,22.188948439895412 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark52(96.73101858121197,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark52(96.7707446491839,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark52(96.78066212719031,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark52(96.91953324735175,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark52(96.97842564249203,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark52(9.69883900882516,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark52(97.0072882210076,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark52(9.703718885057976,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark52(97.09636221428693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark52(97.11908331944585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark52(97.13333189060552,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark52(9.71598563713139,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark52(97.20699164150949,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark52(9.722495503835873,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark52(97.24278015358652,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark52(97.29952497839466,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark52(97.46051832218811,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark52(97.58123322216329,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark52(97.62772037723585,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark52(97.66396129258587,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark52(97.6668570508439,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark52(97.72685478403321,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark52(97.73947973282381,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark52(97.78666614199233,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark52(97.8836654291853,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark52(97.91058825663649,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark52(97.91580057943776,-1.5707963267948948,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark52(97.9423465643506,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark52(-98.02935134254436,-1.5707963267948966,-0.2790009464087234 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark52(98.03477674573242,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark52(98.30967379929899,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark52(98.33604806132706,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark52(98.3436370785779,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark52(98.39910790768295,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark52(98.42890320177793,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark52(-98.46535896495381,-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark52(98.49028865305695,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark52(98.57363382931788,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark52(98.60613369920111,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark52(9.860761315262648E-32,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark52(98.74870335633497,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark52(9.881420823745913,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark52(98.9301095665821,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark52(-98.99011015625304,-1.5707963267948966,5.484997921663565E-16 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark52(99.05026972596781,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark52(99.08255605673878,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark52(99.14262638013508,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark52(99.23922257198467,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark52(99.34086410202761,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark52(99.49834381865739,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark52(99.50230582007526,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark52(99.51681934378357,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark52(9.968819547464507,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark52(99.7434252508445,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark52(99.786379796109,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark52(99.82610701853318,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark52(9.985490357207208,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark52(9.98589632018544,-1.570796326794897,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark52(99.918040552184,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark52(9.999752063406525,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark52(99.99999999999933,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark52(99.99999999999996,-1.5707963267948966,0 ) ;
  }
}
