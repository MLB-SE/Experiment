import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.007031898958397509,1.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.007790222306553088,0.45908287718778285 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.020115791694965874,-1.0000000000065565 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.021431190693267068,-0.42525061051030916 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.02593154467838097,0.06255319393346088 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.04848967243780274,57.96615639894448 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.05440368899894258,0.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.05857383161655916,-52.15971221953245 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.06379594261897728,3.469446951953614E-18 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.10404016428909611,1.0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1112731157643173,-7.090013094284477E-9 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.12227607469661742,-1.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1306087332100159,43.07987342841574 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.13216894362327095,0.46908005192895347 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.13836087034433198,-0.9641642441982564 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1461667709136525,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.14815173254503655,-1.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.1556029785540778,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.16239418380914294,0.05575171517819166 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.16301012337530363,15.604383449132495 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.17621824104405825,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.17693526621816508,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.19017208180949136,100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark55(-0.0019322952492277778,-8.881784197001252E-16,0.7645285349372067 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.21738119518075097,10.48022507982428 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.26308421421671263,33.46085883232193 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.27542853769922093,62.22248535751499 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2780930725615147,-1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.2994751056359579,28.09318250451822 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3138836385964451,-61.29675801187411 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3166057153967494,-0.33823661850738584 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.345861966364226,0.05794257940029289 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.35522643150809746,-100.0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.3787081676071014,-0.8138544888309744 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.41644826047726635,-27.838777638441343 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4324748004347832,-1.0000000000000002 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.4812803922776292,-24.23986367149364 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5313462890681098,1.0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5653386250451194,5.551115123125783E-17 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5682543910177318,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.5693520827288978,-79.800170682228 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6042138234484393,0.22470437043298322 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark55(0.006186689883662666,-1.432291392780157,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6687924556055411,0.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6744622945514739,-0.5242705875176211 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.6886801609649555,-25.2062800354313 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7243456922028678,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7249336157022944,94.27246075427905 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7293041288943035,-2153.4913187085654 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7710025171607757,-42.908540872723556 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7842915923217424,-7.460867670012034 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.7991984452773768,-0.28395598575565373 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8084454628220072,-18.06833206651841 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.8340111790303477,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark55(0.008658097704564938,-0.850049804176976,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark55(0.009142004577225471,-0.20728557568422543,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9307751432791381,-0.025424761652990298 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9640811673453876,-0.04357207807895815 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-0.9911327163729222,100.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0584150533346604E-5,0.25303149557033733 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.0607968863537451,-1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.098555552046626,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1073396761602963,-1.0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1468962011959087E-10,43.391486829849526 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1512141956197472,-27.005872586226456 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1587300891894736,2243.0572628351006 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1717052154933532,-0.5822784860869223 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.1814235029421236,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2032451024399204,1.0104178262620573 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.207490429565548,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2321504169182278,0.9999999999999994 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2482240172559311,0.9070755407957876 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2484864608247566,1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.249524952361107,-92.41329557427173 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2725737361690024,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2731499794912757,1.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2757611384650207,0.3344132884824518 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.283236109132849,-1.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2878081065380274,0.36215741795116385 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.295176433711236,-1.0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.2957424065885206,-51.65688407321792 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3182761853588247,-1.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3232754138714455,2227.8181648723607 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3614571227848453,95.04225096461408 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.368323928608751,1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.3838105880243603,-1.0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.13884657146448465,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4194497713211691,-1.0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4347758754338764,66.935859067992 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4350512912331932,-1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4471017648263549,1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4605228830963712,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4749815379693554,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4755723292200373,-0.0625525380740466 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4795071015417498,-96.374591772643 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4830466155445643,1.0000000002870921 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4869321604822672,0.8659018867986807 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.491542658103979,-1.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4916361695419456,-1.2272733663244316E-91 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4927017757276189,1.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4979630650147817,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4993488536503206,0.4199296863771256 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4994630308311026,18.420331114371322 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499967924421963,1.383201706626234E-4 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999997874694448,-0.49515797600831074 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999970510085,-1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999996646176,0.6193202497851846 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999170033,1.000000000000007 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.499999999999977,1.0000000000000333 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999962,-2325.5648501294895 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999982,-1.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999982,-65.47212230945884 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999991,-0.08457924056387989 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999991,-87.1539151205267 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999993,-86.45538303675177 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,-0.8546634046444845 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,1.0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.4999999999999998,-45.00561664305624 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.17092888225323577,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.7763568394002505E-15,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark55(0.018592174125732334,-1.4685036653141559,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-1.8903235848892505E-6,0.104838561440312 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark55(0.02209985621967658,-0.15128483248882751,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.2320697932759522E-8,-0.9999999999999983 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-2.410217093392317E-9,5.658998009197393E-22 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.255975039845614E-5,-0.9999917390180642 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark55(0.0,3.469446951953614E-18,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark55(0.03538663045888141,-0.060698844822078366,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.552713678800501E-15,-0.3621204993359703 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-3.552713678800501E-15,1.0756612264412926 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.3729334562109221,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark55(0.03985525752741914,-0.06321216221520842,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark55(0.04165000494550952,-0.287529920012247,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.440892098500626E-16,0.02153653725951121 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.440892098500626E-16,1.0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.503055161692015E-16,0.9999999999999963 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-4.517998047525031E-4,-0.6472027406020032 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.5320118367558488,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-5.551115123125783E-17,-0.007854769101241546 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark55(0.056072995504171885,-1.0921827504943213,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-5.941690585774148E-6,0.7346902394870556 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.6250269000744577,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark55(0,-0.7716934388605239,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark55(0.08109532646770043,-1.4932643137429358,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark55(0.08455878818078588,-1.2105351516061935,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark55(0.0858153817761611,-0.35331290468490606,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark55(0.0,-9.359423468816642E-4,58.907784114451445 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.0482408212465568,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.0996941344023412,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark55(0.11062206250463497,-1.4364709075653376E-9,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.141611807550583,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark55(0,13.094522459394483,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark55(0.13145331266856886,-0.8940395689689478,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark55(0,13.364672962153733,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark55(0.15066058306278762,-0.49710052428144635,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark55(0.15184593569908555,-1.4382924266872408,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948957,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark55(0.1636263591690792,-1.1123297320216246E-15,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark55(0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark55(0.19652298272558233,-6.537892036023694E-9,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark55(0.19673616221213486,-0.8617596693882348,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark55(0.2427028585213975,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark55(0,-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark55(0.25866135789586187,-1.0965091945919236,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark55(0,-2.5E-323,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark55(0,-2645.0812636028813,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark55(0.26717303626601563,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark55(0,-2718.257184149237,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark55(0.3006086648004217,-1.286824299021437E-4,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark55(0.304287954355537,-0.4983503635292692,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark55(0.3049248303270957,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark55(0,3.069615554396001E-25,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark55(0.30748913157754665,-0.9436912614492714,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark55(0.3162527250859859,-1.533252028150101E-9,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark55(0,-34.15089240296882,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark55(0.36101124346863384,-2.3826699849988537E-5,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark55(0,37.87405693008358,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark55(0.3808409290198824,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark55(0.404727673147363,-3.2144789479092166E-9,0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark55(0.41976570029903115,-0.0141862778004728,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark55(0,-4.199537104792483,0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark55(0.44422052733408557,-0.2438225403752624,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark55(0.4470123743508818,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark55(-0.4550330765920473,-0.9580459275524985,0.999999991979732 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark55(0.4588011105418843,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark55(0.46581337908548903,-0.633228471333311,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark55(-0.4943488819970021,-0.17496821535716253,-80.70261833756686 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark55(0.4997176794103866,-1.1715852402595643,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark55(0.500978279871101,-1.4500512625920043,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark55(0.5045749376311477,-0.47326336961113746,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark55(0.5095383921018168,-0.3640037598578656,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark55(0.5167467388226044,-0.6445244337221041,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark55(0.5226065018098467,-1.432779300228196,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark55(0,5.293868944994841,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark55(0,-53.57785007280926,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark55(0,-54.15929217323892,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark55(0.5533752451800282,-0.09916992663350777,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark55(0.5547375738109217,-0.6287559026856133,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark55(0.5944535627286873,-0.047456939253450514,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark55(0.5949647290635767,-0.43664026283294244,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark55(0.619251215884475,-2.3159051350899983E-6,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark55(0.6325285698940067,-1.2409388878939336,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark55(0,-6.336039613800693,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark55(0.6395200539047963,-1.0215905356648145,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark55(0.6401805245955939,-2.2413766763850785E-6,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark55(0.6866501826323885,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark55(0.6949321906306523,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark55(0.7013035402952599,-0.2619060256744423,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark55(0.7446294581827715,-0.6298193734400428,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark55(0.7547985511533746,-4.3822082863007205E-10,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark55(0.7616841941745314,-0.1628110995372145,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark55(0.7675045055100185,-0.1811460641773489,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark55(0.7678225704532906,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark55(0.7733604056606964,-0.13828432937774296,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark55(0.7878915615383413,-0.733757304154794,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark55(0.8055787472942555,-0.3760611830022129,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark55(0,-81.12334003785644,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark55(0.8142962553832681,-0.5454556981103847,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark55(0.8195011304332525,-0.14327230890654774,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark55(0.8198177440438332,-1.1468687995473061,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark55(0.8354412767420243,-7.547450317573013E-5,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark55(0.8414763819563262,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark55(0.8684942577109745,-0.9131953833783262,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark55(0.8865399719889808,-0.47906011390583825,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark55(0.9379394637741356,-0.3598972327520231,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark55(0.9420923052710735,-4.1183762216175086E-10,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark55(0,-94.8029069822394,0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark55(0,-94.97518009522106,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark55(0,-97.37737654148737,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0015468903503212837,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0036337929162153916,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.012946202207374203,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.022256311910492377,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.029818739908966635,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.03724073393180316,0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.04278260921103327,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.04953185651935876,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.05009767002058619,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0519310098102479,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.052843743131373216,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.06522149775821713,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.0658163733547692,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.08088125609498042,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.08753740726760229,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.09377586856276476,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.10432404487739783,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.1045985715557943,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.10971197835728574,0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.11983677036059638,0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.14265996222180335,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.1535665949867836,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.16237077101147224,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.18562504375283595,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.19705059477551146,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2024753155204384,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.20830552546796963,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.21777577298889872,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2240399765268209,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2344461291297345,0 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.25415926669697075,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.2744826625719414,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3039249658473408,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3505094391070377,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.3533389772185125,-1.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.37229604024188667,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.38440398883975724,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.3910759700639703,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.40376142529745396,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4161638791655251,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.42375499417721557,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.4273613878402929,-72.9055062927784 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.45358122715533433,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4735193312354271,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4750703759871604,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.47918963089868283,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.485250350549419,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4876862531420824,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.49110354974582127,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.4927909389242924,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-0.5108310579518713,-0.009908732073373727 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5234342260633671,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5269593139549915,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5285241248653785,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5322133982176753,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5330037505433386,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5419351637782563,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5593897723340799,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5696260504959914,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5698688528420494,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5823290095514551,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.5932134769273109,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6071273804567671,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6179661046108375,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.651989021189405,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.6769357609317128,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.7206225779576583,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8040814233603981,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8088664756150332,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8143882252146278,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8438252170084249,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.8704070676387929,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.898751560591924,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.902910239828272,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9152276709371349,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9181528330060773,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9252118506260416,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.9600916555327572,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-0.970183913937979,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0101945245330146,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0328438837830096,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0351137627603346,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0585712258092419E-15,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0613887431137257,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.06837254948493,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.0893670740611938,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.1157734123434977,2390.4022719603886 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1453237796328062,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.148201703988403,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.1751288128218973,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2047753876704954,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2232480144670284,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2234962475971285,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2286883182872965,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.2459126014743556,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.278807257247702E-9,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.2852458534194727E-16,0.009743512698949559 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3165835880254273,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3184268983706693,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3235488581372645,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.354068403384927,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.3708386657019926,39.911876827785306 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3728470470696035,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3744607247325957,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3744849458073147,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3780720126563915,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.3943716801125063,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.4096960058680286,-0.9999999999999996 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4297916991640411,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.469698245520321,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4789592975424188,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4795894033834738,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4843801465556914,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4936029258596355,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4976016347148664,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4990593853410008,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4995514565827808,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4996343448122067,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999623996459972,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.499999973763512,4.819839730205768E-181 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.499999999999993,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.499999999999996,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999976,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.5066885194729809E-15,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.6745438267918392E-6,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-1.8065157373239026E-16,-0.06021570034950112 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-1.9381023558974475E-4,0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.2534999284954913E-7,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.5686806057829692E-6,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-2.959234514608283E-7,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.5375884041849856E-16,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-3.9858622700907434E-6,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-4.707604632360426E-8,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.007998026455314E-10,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-5.563438870027722E-10,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-6.136640886334726E-8,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark55(-100.0,-7.105427357601002E-15,-100.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark55(10.007984576120379,-0.44096873034459927,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-8.51000908483322E-8,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark55(100.0,-9.13496117387677E-6,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark55(10.035008440677133,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark55(10.040522482739348,-0.24369820086560368,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark55(10.115581466589148,-1.4646300986764993,0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark55(10.127274868896958,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark55(10.139807002174102,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark55(10.14399482248021,-1.0943433206167268,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark55(10.150560933280175,-1.4913299309251684,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark55(10.15759377335769,-0.040919102659123324,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark55(-10.173362456769407,-1.1407065668433325,46.17536016024786 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark55(10.186805344018612,-2.1522420312971157E-9,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark55(-10.187247762889879,-0.24421212738121456,0.9687876779364945 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark55(1.0191397695355562,-0.8570638607022403,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark55(10.200113011753785,-1.2251467664853983,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark55(10.228495984854518,-0.09099206714683272,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark55(10.238853882695338,-0.5306584576503042,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark55(10.255911116765038,-1.3153752865540298E-9,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark55(10.269537316207746,-0.46079621144618166,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark55(1.0351204264565133,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark55(10.351578437089941,-0.035253972859531024,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark55(10.367052964482397,-1.4047403623718866,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark55(10.371877947038442,-0.28006308139542124,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark55(10.389903585849662,-1.2463427519108141,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark55(10.426746671293714,-1.1186128077971773,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark55(10.43404966037859,-0.6286468311281936,0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark55(10.483686592042119,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark55(10.491764549623142,-0.5586041335206033,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark55(10.503551520230058,-1.4999999999693738,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark55(1.0507614211323843E-286,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark55(10.541417010629576,-1.193841244442065,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark55(10.542395868356625,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark55(10.6062467230104,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark55(10.60929438189578,-0.9543363502875604,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark55(10.632624030811133,-3.261024496776379E-8,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark55(10.674073627768422,-0.47397447844007434,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark55(10.69829627354175,-6.347448767200887E-9,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark55(10.710097826235947,-0.6787871665596725,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark55(10.723297534666415,-0.058059803209767225,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark55(10.740564613637218,-0.2470240932284753,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark55(1.0760281906739237,-1.4870908315909013,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark55(10.772942767534374,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark55(10.782111658446354,-0.5821870756149249,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark55(1.0811273120519416,-0.8472091934019162,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark55(10.845164856912916,-1.499999999999984,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark55(10.853357207932945,-0.062226110371123244,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark55(10.86392888961934,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark55(10.863949137564589,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark55(10.88991335482023,-0.09723150467863717,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark55(10.895377988928065,-0.11806328629009943,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark55(10.922910970927408,-0.05979856665968794,0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark55(10.95675379518859,-0.5379997326266883,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark55(10.961161139351596,-1.1881504842324695,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark55(11.010206271405522,-1.0788060525262617,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark55(1.1020526054634843,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark55(11.03575633336113,-0.15323128251080154,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark55(1.1102230246251565E-16,-0.041127528198543165,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark55(1.1102230246251565E-16,-0.803453424061392,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark55(1.1102230246251565E-16,-2.6201125507812403E-8,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark55(1.110425004439719,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark55(11.10575491158589,-0.8992590909798253,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark55(11.129989750245812,-1.8338528751294697E-8,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark55(11.282700467005498,-0.9685938260481208,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark55(11.308057115576503,-1.3725749882066856,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark55(1.131363604465463,-0.05036192466721767,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark55(11.370967588947659,-0.24241375979413426,0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark55(1.1388259335961841,-0.6653694116999787,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark55(1.1425160180195064,-0.8374515927706909,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark55(11.430988647613415,-1.0389174883055037,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark55(11.470239800694799,-1.3472761182840696,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark55(-114.93394859385133,-0.8112401464721944,-0.8079192414024692 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark55(1.1498309627312722,-0.6012165724908565,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark55(11.574208161655301,-0.4487771683218451,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark55(11.612129772714226,-0.1057296780899668,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark55(11.615931509628581,-0.852882110374594,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark55(1.1626664264494324,-0.9463722418668011,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark55(11.63758816402678,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark55(11.677522846025681,-0.2692758710461443,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark55(11.685419985700506,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark55(11.694489752568789,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark55(11.699626803766265,-0.9122243694935896,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark55(1.1753338210297244,-0.048124441185427844,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark55(11.763668061149104,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark55(11.830449207114722,-0.7799153255368427,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark55(11.84049013630117,-0.005969411066857333,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark55(11.843092925481209,-0.8816045271562997,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark55(11.853278035823104,-1.3231176834309082,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark55(11.88781046762304,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark55(11.95760619530246,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark55(12.00845744504231,-0.19907933436740688,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark55(12.041227273088705,-1.2820645158733157,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark55(12.106110226003967,-0.31969234851568795,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark55(1.2107285786797917,-0.43037471047041187,0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark55(12.111632487550096,-0.757391182860994,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark55(12.135086612101901,-0.24603838324053418,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark55(1.214187236852112,-0.7799917836728107,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark55(12.142971252086411,-0.35757156688553154,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark55(12.146623137748705,-0.5683362135676326,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark55(1.2166986024289023E-209,-1.0452304483189847,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark55(12.181766888152382,-0.9438345003001949,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark55(12.196107590657277,-0.034755522232160274,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark55(12.230067930774837,-0.6907566194987282,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark55(12.294348005034097,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark55(12.335570455955704,-0.07992507569347027,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark55(12.362228174376156,-0.9127829417946836,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark55(12.370676683075857,-0.6042856416082276,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark55(12.40562638223481,-0.7068293892814642,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark55(12.477137606176031,-0.27629649884055185,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark55(12.534281362515799,-0.3959539741899345,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark55(12.535223329392807,-1.395868790841186,0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark55(12.544205704304943,-1.1090530579256086,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark55(12.544351435394674,-0.5394186351014589,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark55(12.55036253941293,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark55(12.573524204080927,-0.09383422050558066,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark55(-126.05992923980824,-0.26078184754815936,0.7123757605141297 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark55(12.656963057398542,-1.4018600170342363,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark55(12.67423687594895,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark55(12.709689534278311,-1.4921884425626375,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark55(1.2750302597136116,-0.24498672703047375,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark55(12.814464558930755,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark55(1.2823013432923425,-7.978974679648192E-17,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark55(12.836800708676126,-0.9591917682934921,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark55(12.865874793181604,-0.7333496560134822,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark55(12.899241934414595,-7.803290948630989E-7,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark55(12.914400805249697,-1.499999978572313,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark55(12.927443501608767,-1.0031149823970669,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark55(12.927725178454509,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark55(12.962616885582733,-1.3075521819190215,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark55(12.996972178349651,-0.8733080980268335,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark55(13.000425491961948,-1.0282361281431645,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark55(13.019474066488158,-0.5056221589264889,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark55(13.041689632786142,-2.4038118769387773E-6,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark55(13.04460982391096,-1.3402791823495077,0 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark55(13.049071346031994,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark55(13.106548684265915,-1.0021195673000964E-8,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark55(13.151148862600891,-0.30483101469912033,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark55(-13.184716616275608,-0.17902856316982674,-0.36160840892455304 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark55(13.205499489334585,-0.12619709859919737,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark55(13.28182612385228,-0.2287548647841371,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark55(13.287342636790527,-0.22578299302814742,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark55(13.297432054001224,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark55(13.31186269565832,-0.017452761654524807,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark55(13.336791386541066,-1.3199521215153283,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark55(13.3647970211007,-1.3293004296812683,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark55(13.390531329078966,-0.19200080253452256,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark55(1.3401829949167545,-3.83540407223323E-7,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark55(13.437474083086379,-0.06471453057510246,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark55(13.4745932084344,-1.1510892913199489,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark55(13.478855511483559,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark55(13.482054851530606,61.065535255302194,63.78099600725008 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark55(13.532737902605547,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark55(13.57118892289239,-0.9417313700302964,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark55(13.631995132790488,-1.4999996649245912,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark55(13.68137635571027,-0.4739278282862651,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark55(13.68325750240935,-4.247316911581044E-6,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark55(13.736399226775806,-0.32813524372284775,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark55(13.740439634351006,-0.40374508178790075,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark55(13.761531378456795,-0.6380600613222072,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark55(13.786245770369106,-0.624362037506828,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark55(13.792561657904788,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark55(13.823451887903374,-0.6625234124696817,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark55(13.839283133098348,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark55(13.86515572837439,-0.5127273027010175,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark55(13.891194845216376,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark55(13.908348379843034,-0.17398115107166956,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark55(13.924046336469218,-0.9889230837532086,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark55(13.939428130807084,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark55(13.978187471957384,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark55(13.987951746589886,-0.4502299368328879,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark55(14.023170169847493,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark55(14.056513660575007,-0.2199702683798952,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark55(14.083589332871647,-0.4782250015556181,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark55(14.086244986189243,-1.349939985132055,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark55(14.107800542366306,-0.4371312739363744,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark55(14.145497640045072,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark55(-1.4210854715202004E-14,-0.7867362002070136,-83.78067846576727 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark55(-1.4210854715202004E-14,-0.9169453347425608,0.3621235515773705 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark55(14.235252909176495,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark55(14.245407475946205,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark55(14.250354604221855,-1.4038920881438565E-5,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark55(14.256648861207793,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark55(14.291050964025622,-0.6310124870707192,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark55(14.300320144005457,-1.4903309085850651,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark55(14.305472832143991,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark55(14.307072485014373,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark55(14.321478293752705,-1.265535922375715,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark55(14.321670858204442,-1.3609696118188783,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark55(14.337659505445831,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark55(14.340751468859306,-5.910356030088494E-10,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark55(14.394880730113382,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark55(1.442022033226915,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark55(14.432442257509948,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark55(14.435174221190294,-0.629234379576225,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark55(14.455639724027805,-0.704440742156228,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark55(14.458623674663102,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark55(14.462386419452955,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark55(14.473153269335256,-0.3157526718413819,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark55(14.530634651340327,-0.5083485762993812,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark55(1.4544860004109523,-1.162824681188256,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark55(14.560454710935574,-1.232990465147863,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark55(14.562568569373934,-0.23095901730068497,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark55(14.571945705552153,-1.173445636739956,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark55(14.585844547021836,-1.435226344534432,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark55(14.593853309891465,-0.5407204477183929,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark55(14.596475157766605,-0.37679793068096906,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark55(14.597205333404325,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark55(14.616316347527885,-0.007530978826380019,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark55(14.641352201331003,-0.0883931381874774,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark55(14.64816528854858,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark55(14.669143700786961,-0.32191167699682954,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark55(14.689725965999884,-0.3066984012306051,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark55(14.729220272930974,-1.0730717361682238,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark55(14.763476042821452,-0.018167670880931856,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark55(14.82697247116944,-0.4471061326882011,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark55(14.833766973175315,-0.49582056230774185,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark55(14.863150841166046,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark55(14.86871458771839,-3.8039324030425346E-16,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark55(14.869784880243728,-0.9165173260662671,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark55(1.4903482586833974,-0.12982699224829397,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark55(14.920262536427174,-1.1498860855082853,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark55(14.990924578301133,-0.15660588284116195,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark55(15.015693647319566,-1.4901404198160104,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark55(15.02280221324732,-0.6110028914578871,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark55(15.038302972593627,-0.05617276412493766,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark55(15.044360709820914,-1.4999998871783646,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark55(15.099404249643285,-1.1356482405140662,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark55(15.223640046684821,-0.43490346687957926,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark55(15.24386456543263,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark55(15.307818492997939,-1.3798922836597143,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark55(15.310443065072164,-0.6574971240584659,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark55(1.5318252864077806,-0.6244797793143069,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark55(15.322210675656446,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark55(15.32451888617436,-0.3778627758183914,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark55(15.3321265635429,-0.5544025915832747,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark55(15.333950820074833,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark55(15.361359378744764,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark55(15.405050552764905,-0.4007508821953234,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark55(15.410099042769964,-0.21833847035736653,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark55(15.473220752166647,-0.7725477451740184,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark55(15.500047765377872,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark55(15.510968834892353,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark55(15.532363076675358,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark55(15.550458341735437,-1.499999999999999,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark55(15.56370300351675,-1.122168111698659,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark55(1.5563951579054844,-0.9090647226191051,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark55(1.5583325221542879,-4.034914421700009E-4,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark55(15.63577914380837,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark55(15.649133555086639,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark55(15.663865681395635,-0.6977618980316365,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark55(15.675990428992854,-0.04200062353203155,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark55(15.677701922358153,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark55(15.69117813939673,-5.866524981940722E-8,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark55(15.711275471654428,-0.9807751659499724,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark55(15.71450773208538,-0.6805754233138401,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark55(15.730211681695579,-0.6733507716570566,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark55(15.75278348566161,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark55(15.807446701636565,-1.499999999999993,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark55(15.82437636731288,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark55(15.837405947156943,-1.2984987751782273,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark55(15.853076479968209,-1.286699760433578,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark55(15.880035804526727,-1.2913576716114021,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark55(15.883866687083597,-1.4584951929447774,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark55(15.900421335222276,-0.5160401788127018,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark55(15.929927273890097,-3.1975747283333894E-9,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark55(15.978824131640744,-1.4999999998613935,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark55(15.984613752087654,-1.4999723304968489,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark55(1.5990779762808671,-0.4883797327488976,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark55(-16.00293291656064,-0.8896452406814419,14.520506344620156 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark55(16.020622459994826,-0.0013528334548722806,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark55(16.030987073026523,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark55(16.031252347711188,-1.355775507400212,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark55(16.04588101749766,-0.45886772398520437,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark55(16.051152139815628,-1.0469198444530783,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark55(16.058144092261358,-0.35237940874766593,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark55(16.06557310729932,-0.2860025797053618,0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark55(16.12040602552787,-1.2202466149992084,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark55(16.148090137372307,-1.2919843415674124,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark55(16.150935311078328,-1.084065412552464,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark55(16.154779483942306,-0.8789002459749469,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark55(16.157340522609886,-3.5499968301477836E-4,0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark55(16.159297134972235,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark55(16.167980717132295,-0.9863868961862607,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark55(16.17918994591781,-1.1490041316077453,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark55(-1.6203915868687617,-0.8015556036532431,-1.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark55(16.237531493583038,-1.3182819800797518,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark55(16.347263914509732,-0.6538795243902249,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark55(16.34898391854329,-1.2784070187726977,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark55(16.35097765154636,-0.809504784480015,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark55(16.36740402707136,-0.4732039115638784,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark55(16.379110957275557,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark55(16.387589585375622,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark55(1.641965172244923,-1.317718716260714,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark55(16.443334627860843,-1.083978811195008E-6,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark55(1.6453317350421983,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark55(16.460085015696798,-0.6685667030742368,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark55(16.51066081746638,-0.11855151855665058,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark55(16.513507040249674,-0.5953926805132976,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark55(16.523636516406803,-0.7838260810225983,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark55(16.53022074396198,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark55(16.536340672011583,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark55(16.574235962610825,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark55(16.58317918975318,-0.1677021423817512,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark55(16.588263493355697,-0.5657816722016309,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark55(-16.61800313641208,-0.476891247512429,1.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark55(1.6674693233290583,-0.05506973733935361,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark55(16.68276240971211,-0.2519985284803852,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark55(16.68481514701549,-4.946631894870136E-10,0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark55(1.6700576214463823,-1.0306572581000237,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark55(16.708050201147813,-0.8700740669240284,0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark55(16.75601017407968,-1.4812693544399091,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark55(16.776375697372075,-1.062600938565467,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark55(16.7773597785893,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark55(1.678351763608248,-1.2463527925247666,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark55(16.871773931716888,-1.2590108847486654,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark55(16.90151223811935,-0.15509728301708284,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark55(16.936667001769308,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark55(-16.94069793812291,-5.1157240845898406E-5,0.9772021820903224 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark55(16.942147365205628,-0.727236772403117,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark55(16.972818499661642,-0.7561424497376315,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark55(16.98761325279341,-1.1594403800472932,0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark55(16.9892414014746,-0.26283085128658,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark55(16.991829527736396,-1.1378768146537879,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark55(17.011872594733532,-0.8265387657564505,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark55(17.019815858800605,-0.7177936279527126,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark55(1.7020205111570839,-0.7167959689385168,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark55(1.7030493981748513,-0.9888288453791736,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark55(17.04257082722755,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark55(1.7063569109061234,-0.3489798764093841,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark55(1.7130531374397293,-0.44710659074198134,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark55(17.224318963226715,-0.22545367301587593,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark55(1.7240990994539915,-0.49002927722704936,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark55(1.7274632926321527,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark55(-1.7290327071306454E-223,-0.3710717595621478,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark55(17.31600274808697,-0.05963386658804559,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark55(17.368398967473002,-1.430755091176809E-6,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark55(17.381076283405747,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark55(17.38994135073453,-1.3211586559110078,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark55(17.39365237876796,-0.3200845720170058,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark55(17.402711841774106,-36.25527623004323,52.304073662680764 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark55(17.41240652205876,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark55(17.418930707211345,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark55(-17.421099084779765,-0.4759526769363617,-0.3622231621797133 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark55(-1.7428572668851814,-0.3205937956432461,69.03530066947775 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark55(17.452600477716686,-0.024025190373174077,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark55(17.462011234231912,-0.31368966774740237,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark55(17.464971665651333,-0.5975582668814781,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark55(17.469473777429805,-0.6367118219391479,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark55(17.49588071235535,-0.5176429066468984,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark55(17.50410845687189,-1.1008656142065023,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark55(17.53255460535729,-0.1577371437348063,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark55(17.56902208141078,-1.2389777944647937,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark55(17.5719474167445,-1.4509184233138428,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark55(17.64488052597224,-1.499999999999745,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark55(17.659378825251014,-0.0789041301143063,0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark55(1.7666957717885339,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark55(17.66707084911991,-0.2894679358332204,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark55(17.66788997474973,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark55(-17.684616284002757,-0.11406233910320511,1.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark55(1.7699128362252843,-1.499999884995481,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark55(17.72339730071822,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark55(-17.726446481499053,-0.7710373811729614,-68.07808149734446 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark55(-17.755362237095667,-0.27557143091346026,0.011148625885846933 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-0.18600074382145237,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-0.2511535472631411,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-0.5080704979175161,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark55(-1.7763568394002505E-15,-1.254563707687802,100.0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark55(1.7763568394002505E-15,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark55(17.76753647123155,-0.3638957914314087,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark55(17.781528203786223,-0.05518704947584041,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark55(17.784418750858517,-1.186181320479675E-8,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark55(17.821274301578157,-1.0292614307228831,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark55(1.782721541939992,-0.18427485281829092,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark55(17.88152606691658,-1.3606528323901723,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark55(17.886006437681317,-1.2187735876911745,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark55(17.924620030397435,-0.8311899540338086,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark55(17.938810988534186,-0.676750601415135,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark55(17.9596832594233,-0.48150050406539524,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark55(1.7971250928526046,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark55(18.007974746011087,-0.09528533500755998,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark55(18.047868554342188,-0.2598965211429337,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark55(18.11928158246968,-0.3133930394661316,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark55(18.17889429715263,-1.4272885586553372E-9,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark55(18.1982738375619,-1.499999988255648,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark55(18.19854533307877,-0.21165529200535305,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark55(18.23790413581699,-0.6882317881535975,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark55(1.8244308756341914,-0.37480992938493296,0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark55(18.30384479657657,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark55(18.30479970782614,-1.2967864115362275,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark55(18.324028074644033,-0.6624833673268333,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark55(1.8326387367744132,-0.24823530466647492,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark55(18.342146483022475,-0.10815769127277708,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark55(18.374747090943345,-3.613129316595005E-9,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark55(18.37621277567753,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark55(18.42386436715006,-1.442531990430627,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark55(18.427543537111422,-0.20202616119733466,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark55(18.438493039761795,-1.2804556406112333,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark55(18.464421597058518,-1.0034060319099183,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark55(18.478847417489416,-0.07954149411557432,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark55(18.4890386046296,-0.9354371118434903,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark55(18.492588719157155,-1.0092283733536864,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark55(18.50955746514491,-1.4614491787348634,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark55(18.54528944030804,-1.336878323188344,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark55(1.8552957868511881,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark55(-18.562147309586095,-1.4772335070970446,0.9999999999976906 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark55(1.8610507591697276,-0.0015174981151724332,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark55(18.656611101325854,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark55(18.689483849100498,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark55(18.693752127411486,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark55(18.70489719078006,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark55(18.739069125443507,-0.1873248676935309,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark55(18.744395832338228,-1.4280861182764788,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark55(18.74778812328178,-8.209505838892364E-5,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark55(18.757414017477096,-1.9966852530188785E-7,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark55(18.774758021685884,-0.4000915423203928,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark55(1.8775735206169868,-1.4320784353032905,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark55(18.789515624136733,-0.5192162100806156,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark55(1.880309652431194,-0.15545933019956237,0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark55(18.809870905192568,-0.18138606393597345,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark55(1.881218022534469,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark55(18.833717392274913,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark55(18.866367292357562,-0.7302428017868863,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark55(18.87815831488365,-0.5087770353109469,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark55(18.88228466224386,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark55(18.891090316341774,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark55(18.893962833843307,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark55(18.917090833800884,-0.41987384806126127,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark55(18.934628206287087,-1.3281298359064042,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark55(18.951341776120373,-0.9404752600083254,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark55(18.95767554346628,-1.420083256129308,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark55(18.980641151266923,-0.3568395087291418,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark55(19.019080646032478,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark55(19.053400690930914,-1.4173323811953225,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark55(19.08689717257714,-1.2906598482530995,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark55(19.108998949481432,-1.0776396610173542,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark55(19.198732835590732,-0.31822163257186276,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark55(19.229931781336266,-0.4603301828059868,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark55(19.23585962354207,-0.01661885461626506,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark55(1.9237686640018992,-1.4999999990954211,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark55(-19.26756712810291,-1.3878955741767793,-1.0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark55(19.290052261642657,-5.736739354741424E-10,0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark55(19.324097602631156,-1.0658726342419378,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark55(19.332883542833233,-0.801301780819008,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark55(19.33715239257364,-0.8195543467330264,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark55(19.343155686733947,-0.847633771317658,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark55(19.34459567397964,-75.85742949132617,64.30326941505638 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark55(1.9371242984686403,-0.09177650167731288,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark55(19.372296684154634,-1.437144464167588,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark55(19.39643339862343,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark55(19.39903021688984,-0.995659934956322,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark55(19.400356154586593,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark55(19.417813208732724,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark55(19.43683211117211,-0.9821505527877084,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark55(19.439550320846436,-0.13428758217257553,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark55(19.455962472868123,-1.4597344582910483,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark55(19.465838447846238,-0.21826117118653965,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark55(1.9482157815881038,-0.2489050331877678,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark55(19.486351916632344,-1.0071046278051594,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark55(19.49244255180689,-1.2486717375193024E-5,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark55(19.51199235040137,-1.310426615507314,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark55(1.9540249459752346,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark55(19.56609814693688,-0.23341785559338435,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark55(19.593923336071484,-1.4999999999998472,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark55(19.603912370871242,-1.140009517725531,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark55(19.62073876775231,-9.284046528813305E-9,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark55(19.646160298547755,-0.05779645258422894,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark55(19.68346335535162,-0.5887666307210537,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark55(1.968724465939609,-0.14925456125514103,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark55(19.69029589209964,-0.7630773135435012,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark55(19.70289136139067,-0.806260776735158,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark55(19.719386216645802,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark55(19.735927666271238,-1.1388313608965346,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark55(19.752857879287774,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark55(19.77436523899179,-1.166862337254451,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark55(19.778342118121948,-0.9700640620346164,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark55(19.805512324424623,-0.04329174867568908,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark55(19.826830779111006,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark55(19.849348904426407,-0.6266309045975357,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark55(19.858572411732204,-5.1663620905674884E-9,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark55(19.889846638536298,-0.5433124848511579,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark55(19.896687256920373,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark55(19.898958244407726,-6.66937136224773E-8,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark55(19.92384647424958,-2.1793638261335957E-4,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark55(-19.947079774915068,-1.4999999999999964,0.4224149035795701 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark55(19.97986797957587,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark55(19.996089844142787,-1.4829272832488893,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark55(20.007269773909513,-1.1085955230637978,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark55(20.024551596672083,-0.6320884169972956,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark55(20.029710238774584,-0.7870848881204751,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark55(20.038041095408296,-0.3941725984224864,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark55(20.054446765861606,-1.0552523336779216,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark55(2.007261431642803,-4.169026824607136E-10,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark55(20.079647989493044,-1.5258969957432394E-8,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark55(20.08652773053153,-1.0274305860920299,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark55(-20.08862711574733,-0.892766296845096,0.0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark55(20.092841169027935,-0.18049908571773532,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark55(20.111887721000457,-4.4067477588000365E-10,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark55(20.153279620863806,-0.027619145049517006,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark55(20.15929211662524,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark55(20.22299244061705,-0.36114785771690805,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark55(20.238842350692234,-1.3964944883690524,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark55(20.257990367410144,-1.2415058508633265,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark55(20.26875037624951,-2.4217792544973036E-8,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark55(20.287178341747023,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark55(20.28794593300327,-1.095987566223184,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark55(20.30348970575065,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark55(20.33816514698789,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark55(20.34602049653489,-0.6983608911613146,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark55(20.349496272372853,-1.3435893519160558,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark55(20.357927118513963,-0.061881624370551225,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark55(-2.0377226892713622,96.71590890929463,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark55(20.377832257134827,-0.1204356714837388,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark55(20.40367387505728,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark55(20.488324744668102,-3.796388125357631E-5,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark55(20.506563373735162,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark55(20.539568088517584,-0.2388125152050975,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark55(20.55144479470505,-0.8496383318476859,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark55(2.055159431669253,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark55(2.0559258404587553,-1.3763823293858835,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark55(20.605487437475787,-10.572991663631882,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark55(20.68962401345825,-1.3446449676249468,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark55(20.753464541637385,-0.09659060254697782,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark55(20.77252703063025,-1.2697962088502885,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark55(20.82535638708206,-0.15666145406369847,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark55(20.855220313921496,-0.4990154366990138,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark55(20.877368099877998,-0.43617732773199513,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark55(20.93886764249393,-0.18177458819538772,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark55(20.947766308313767,-3.0351689695918386E-6,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark55(-20.957387011581623,-0.8688599825576616,-1.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark55(21.065659236686944,-1.0819774954373014,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark55(21.07749958748306,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark55(21.081141752268486,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark55(21.12081779697678,-3.5590601956902475E-4,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark55(21.125780634003675,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark55(21.154975212625637,-9.557834818626922E-17,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark55(21.16720984084759,-1.4479428191131176,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark55(21.190296990253827,-0.2675287465055065,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark55(21.247054386468832,-1.2772346926889209,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark55(21.28433022118581,-0.0651970741016683,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark55(21.302608487376617,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark55(21.314598311056514,-0.06155048206597957,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark55(21.33472786713007,-0.8761893713311224,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark55(21.3411336708419,-0.1649146450529102,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark55(21.353836909257904,-0.4380165362770055,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark55(21.371546997524064,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark55(21.414402165917014,-2.3066384712025988E-4,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark55(21.457919050152753,-7.248557054750532E-9,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark55(21.458492381954585,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark55(21.51288277826996,-1.4946347487612563,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark55(21.520300973611413,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark55(21.54348142587861,-0.8208065023926787,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark55(21.547925923434317,-0.5277871765680909,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark55(21.564019376858298,-1.311870975167011,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark55(21.57159350570481,-1.0733392331310219,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark55(21.674483996676393,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark55(21.70535101476733,-0.4409032957669945,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark55(2.1729236899484E-311,-1.606670337409557E-8,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark55(2.174619654371128,-1.4797842920672888,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark55(21.77786510548627,-0.7005377271347357,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark55(21.828591420884983,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark55(21.857290917855778,-0.8682111693420609,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark55(2.1860834328961687,-0.9202695939042735,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark55(2.1871463004662965,-0.4413594152001284,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark55(21.871913342426467,-0.29311250395731747,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark55(21.877482194105482,-0.28296481005641283,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark55(21.883026111348286,-0.23501274651485904,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark55(2.1884864782232683,-0.3085410516550102,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark55(21.894345126023875,-0.6380703775483454,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark55(21.89941437788964,-1.0916522123722388,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark55(21.900961420976163,-0.9891734025736341,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark55(2.193033465089769,-0.13512741727980426,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark55(21.97513801332387,-0.06722112196128027,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark55(21.99327775801443,-0.7934328125696446,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark55(22.014115654413374,-0.2562729237074437,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark55(22.08054964646142,-0.928927431060202,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark55(22.090136740583816,-1.4999999998710367,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark55(22.11020495344438,-1.499999999999865,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark55(22.112297632627246,-0.14907332392697015,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark55(22.15161556382428,-0.93130713404812,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark55(22.17167479844003,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark55(22.200033468498532,-1.029789000154807,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark55(22.258116725388266,-0.8467491197330596,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark55(2.2290063022279156,-1.1709247078402996,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark55(22.296365684334596,-1.4054495998945904,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark55(22.335645558351573,-6.2233994096426235E-9,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark55(22.34068116642952,-3.6023102562460683E-9,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark55(22.34396765976794,-1.4318837245455853,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark55(22.381697103795076,-1.1325928233410627,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark55(22.38567152444881,-1.146842815874884,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark55(22.411539659303017,-0.6656365029097833,0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark55(2.242257370457763,-3.9086738421205755E-7,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark55(-22.43701211211642,-0.19757808800855825,0.05282093889207379 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark55(22.43846344380988,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark55(2.247193731437209,-1.3528973069319146,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark55(22.49288870699411,-1.194696331217914,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark55(22.56337852514534,-1.527316502864191E-7,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark55(22.62740994591759,-0.7632277854476399,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark55(22.671724981102386,-0.7391395715898881,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark55(22.83022925498013,-0.7194907155897398,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark55(22.84054337447286,-0.4235526909087288,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark55(2.284543396029875,-0.3255885817576427,0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark55(22.877653300989973,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark55(22.920121332716427,-0.07657582450710088,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark55(22.933022858808215,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark55(22.994109372820716,-1.4817383183325843,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark55(22.996370586353866,-1.0973292792281217,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark55(23.010748099111474,-0.41369167935648354,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark55(23.015832726250807,-1.0866172590886691,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark55(23.03251230729488,-0.9881109226857999,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark55(23.042741901792148,-0.49404461867505334,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark55(-23.096321684867817,-0.36348634790513445,-2453.3891464895287 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark55(23.11021531993901,-1.0340774931311225,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark55(23.123284710174417,-0.9732618673835987,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark55(2.32092096173497,-0.09004042256234102,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark55(23.294902801831682,-0.014677335944660697,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark55(23.314389666126672,-1.1829809084540415,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark55(23.341817807658256,-2.6526917018832565E-7,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark55(23.37153389398862,-0.3697673233397763,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark55(23.437007835135248,-0.8568533376017045,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark55(23.444088326923335,-0.6560137870584839,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark55(23.45050878416327,-1.1051700493841925,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark55(23.45534534473161,-1.173951651179678,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark55(23.47005460698044,-0.02527082023731675,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark55(23.473040174733285,-0.7915966825548899,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark55(23.49116080407266,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark55(23.49522945790099,-0.5505456474763046,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark55(2.3497226907649917,-0.13402551465617607,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark55(2.3505471239829063,-1.3974659699760963,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark55(2.3512626849419647,-0.7860950805521979,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark55(23.566262421205035,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark55(23.56910270092709,-1.189934950098376,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark55(-23.58120656861489,-1.4999999999999991,-99.85109007434217 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark55(23.620467074027005,-0.7432266374808199,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark55(23.65553312479689,-0.3932232627863371,0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark55(23.68843924944218,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark55(23.688807196641108,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark55(23.693712215380536,-1.499999999831491,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark55(23.6963406181809,-0.6011060808237327,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark55(23.7126846364804,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark55(2.3737114561733534,-0.5117331973693542,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark55(23.741599890323283,-0.535091516480947,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark55(23.75492360816351,-1.1736859554861894,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark55(23.791818312931696,-0.7883171206527999,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark55(23.84939668700055,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark55(23.8677210577531,-1.361436205889646,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark55(23.88569788602781,-3.1335316776187302E-6,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark55(23.92666672757593,-0.30818570392406563,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark55(24.009239993659875,-0.3237100608991983,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark55(2.4054507195088632,-0.5866218612064635,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark55(24.15693846908076,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark55(24.171072426308896,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark55(24.17938186542152,-1.3834484340152926,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark55(24.19540206130732,-1.0621756709639552,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark55(24.218228848965268,-0.32339472542145353,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark55(-24.226126431012002,-1.4909023917573416,0.04954728961951993 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark55(24.23116733417619,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark55(24.24313442599475,-1.12508272444878,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark55(24.256570260701565,-0.02307598619917428,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark55(24.29360463848987,-5.832167444857196E-7,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark55(24.368788757453316,-0.32348876787927594,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark55(24.378889310391244,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark55(24.382371542898007,-0.5423887673182426,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark55(24.429369818616195,-3.913814326612874E-9,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark55(24.45237083498924,-1.4559758857163594,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark55(24.474723084948664,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark55(24.491875606012826,-0.3038327946295034,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark55(24.49899947904161,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark55(24.569674075450905,-0.6667211296433209,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark55(24.610044918989217,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark55(24.627436972375506,-0.5652850592713362,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark55(24.634361876181593,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark55(24.65060544922018,-1.2571370985894816,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark55(24.667774911528674,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark55(24.679143542618284,-9.437654279310827E-8,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark55(24.683329700326848,-1.4999999989967125,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark55(24.697918771257243,-0.9867774070951834,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark55(24.709907887540282,-0.8302979257025207,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark55(-24.753675309015804,-1.2189597403559869,30.26989571640587 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark55(24.799402501115097,-1.29171172844983,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark55(24.799455159793254,-0.0900454743920136,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark55(24.8081286568774,-1.0144279266014422,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark55(24.836749755203837,-6.238065032887777E-9,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark55(24.838521793291505,-0.19797539022954602,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark55(24.842474187639702,-0.4620371480274504,0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark55(24.84297481034449,-0.0037496845957357525,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark55(24.86777185439817,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark55(24.918790997132263,-0.3060370329369905,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark55(24.9449974442021,-0.8997024926481973,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark55(24.966856473879446,-0.03362864310360292,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark55(24.970353171959168,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark55(-24.989918320423342,-0.984845898606296,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark55(24.990960547638903,-1.400583897593795,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark55(24.992059452564845,-0.4002546400947864,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark55(2.500660795913533,-1.3861502908439434,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark55(25.05383271451039,-1.1392978066058357E-8,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark55(25.05447444614353,-0.45206278945256506,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark55(25.07136206495521,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark55(25.099099889194072,-1.0151741164510115,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark55(2.511397373057946,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark55(2.5120077900585187,-0.6733872344191124,0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark55(25.146108224759487,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark55(25.190728616755933,-0.3210207913243553,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark55(25.191425405335565,-0.6387056204908823,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark55(25.196704989640647,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark55(25.22831603773185,-1.4010516591226805E-7,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark55(2.523909401652927E-6,-0.48334202157159467,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark55(25.241423699462317,-0.35756804114043517,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark55(2.5299026503525344,-0.759793543671833,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark55(25.303903671742532,-0.8428339039494865,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark55(25.318763325559978,-0.021423618653958608,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark55(25.3347824406478,-0.15635525689393193,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark55(25.345545287764566,-1.4860346643132658,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark55(25.351635786857727,-1.0711356380706434,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark55(2.538296409585101,-0.5028021826566089,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark55(25.388253172561555,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark55(25.400877770135473,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark55(25.44003572031137,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark55(25.453284116519864,-2.2344604664871533E-9,0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark55(25.46069486880822,-1.0702923304612,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark55(25.463836569478786,-0.33920742588981034,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark55(25.497414260743895,-0.8304215388107821,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark55(25.505939039523327,-0.45364409219330437,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark55(25.512507769341084,-0.1940555466382059,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark55(25.517915811500288,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark55(25.523024354357368,-1.0277920984091584,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark55(25.55913281285138,-0.10662159042977837,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark55(25.56247148781661,-0.24228330584308821,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark55(25.56711209417199,-0.45922878979951065,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark55(25.589029203786296,-0.1285237200499687,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark55(25.59184603567329,-0.0151173937069502,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark55(25.60978195700362,-0.19870097570027007,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark55(25.64973451611712,-1.499999999999936,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark55(25.663558098964366,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark55(25.6898437985369,-0.9444314090006272,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark55(25.71574932957401,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark55(25.753404576542323,-1.3959032260509736,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark55(25.762625708234644,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark55(25.80055339902722,-1.451676133084609,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark55(25.81496583440999,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark55(25.821894492944445,-0.19748450233545173,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark55(25.84717011760084,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark55(2.585734923476224,-0.6065798707071917,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark55(25.867549511815714,-0.5729680870837397,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark55(25.886404932418557,-1.1573553443673508,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark55(25.930326210911076,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark55(25.931099992858226,-0.7503696574715519,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark55(25.987426338507163,-0.6480506276834088,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark55(25.989575945783756,-0.2051127117477886,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark55(2.601325655330892,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark55(-26.038061835496045,-1.4392078922024134,-0.9999999999999991 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark55(26.050080170251718,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark55(26.072119823237003,-0.5594834152935171,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark55(-26.07483681841238,33.388640007667675,-9.181759487413132 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark55(-26.08672938668971,-1.4998691844060936,-0.999999999999999 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark55(26.09418641595284,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark55(26.110626912701985,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark55(2.6120455685987674,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark55(26.128211225406957,-1.440097514211855,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark55(26.1285865913219,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark55(26.130192856252393,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark55(26.160651269287207,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark55(26.184538210865057,-0.1590458357489392,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark55(26.184965228972118,-0.32493015200599185,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark55(26.25511643321137,-0.9528710053189116,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark55(26.322909312487923,-1.028366245398698,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark55(26.350540443632568,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark55(26.35325933881009,-0.2336744645748201,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark55(26.3869433872068,-0.34870723090358435,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark55(26.39735509363304,-0.5936611203162947,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark55(26.421664341225988,-0.0068203294955555115,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark55(26.423114549738315,-1.2702588077973314,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark55(26.46677539584193,-1.2718157257110076E-15,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark55(-26.478961969849085,-0.9760653980190754,-0.999999109431885 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark55(26.48604620164367,-1.2066282618969149,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark55(2.650325581297224,-0.14873877269160918,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark55(26.523231296939564,-0.3391944877925397,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark55(26.528565008197475,-0.5741777806726787,0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark55(26.54275190760815,-0.29731878788427935,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark55(26.571328747391533,-0.43201434918577,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark55(26.57268433226022,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark55(26.581303622436412,-0.3755274355349112,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark55(2.6594128018350176,-0.5250630896191559,0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark55(2.6614413385607065,-0.13703728541807436,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark55(-26.62188732948931,68.40691807794889,-0.9550045460685226 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark55(26.670141990839383,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark55(2.66862401875467,-9.420992636417389E-4,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark55(26.742022516724283,-2.7730098321914172E-5,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark55(26.764162390906108,-0.5077344736458511,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark55(26.776228097708046,-0.6459402146081459,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark55(26.785857176568157,-0.2453342536586618,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark55(26.84029326558199,-0.31294468012674237,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark55(26.919629408639636,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark55(26.947493067521805,-0.45479051294338646,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark55(-26.95041164802808,-0.5793759279406885,-45.46910478876796 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark55(26.962346227848727,-0.4639355379543897,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark55(26.979949363218438,-1.403505977992184,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark55(-2.699895924228585,-1.3229814131439748,-1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark55(27.096210466293996,-1.0740938379750418,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark55(-2.710505431213761E-20,-0.2542408402019305,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark55(27.113850833394324,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark55(27.116465656782566,-0.9514880216563881,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark55(27.12640796529415,-0.766456847504235,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark55(27.137827331559677,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark55(27.14482126154795,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark55(27.161417712462764,-0.3942380387976705,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark55(27.21531842948832,-1.134092638217882,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark55(27.231507781507737,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark55(27.2532195736855,-0.5265713458573432,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark55(27.26932087299349,-0.14026925241151833,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark55(27.304091700745616,-0.5170404513471993,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark55(27.317911855698494,-0.011700425674355353,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark55(27.367631519681293,-0.19876651372250675,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark55(27.378413520843278,-0.8100061707024784,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark55(27.41893789941821,-0.06016902350261555,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark55(27.42964170836308,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark55(27.45352817816081,-0.8543126872395845,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark55(27.455764554759327,-1.017357937898268,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark55(27.48089542913733,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark55(27.481093144228304,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark55(27.48780777171487,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark55(27.503625274914924,-1.492744571099644,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark55(27.59311496404821,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark55(27.633693509390085,-0.5613254929116254,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark55(27.71535988040074,-0.14777883961948424,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark55(27.71775171205488,-7.818298296619708E-9,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark55(27.721453664859453,-0.13273002456048744,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark55(27.725898965647048,-0.3759939697845416,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark55(27.731728131670266,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark55(27.73528122189073,-0.2430126491651805,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark55(27.737721725571035,-0.8207028033019723,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark55(27.738544542957897,-1.1180243134475347,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark55(2.7755575615628914E-17,-1.479011129093942,-0.9694876930397837 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark55(27.761239312425584,-1.0219024776751158,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark55(27.769411104626812,-0.23561768406257055,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark55(27.814654812065896,-1.1084986697694745,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark55(27.850456353168738,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark55(27.851268233200816,-1.499999999072002,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark55(27.856911463149302,-0.8775777821503752,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark55(27.905647401004614,-0.5881944758292759,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark55(27.909339872401063,-0.09021226616850736,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark55(2.792529774109017,-0.4428145376399235,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark55(-27.93127047009241,-1.4999999999999998,0.9248599653729934 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark55(27.94007454660678,-0.3550425966637647,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark55(2.7946348609143037,-0.0027556813303078807,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark55(27.949778772808244,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark55(27.950521710229122,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark55(27.953485273994715,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark55(27.986406017244164,-1.3950433974055674,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark55(28.069512595578885,-0.99383404989333,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark55(2.8076648608562036,-0.09240315293919339,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark55(28.098535208175587,-0.6696890384331255,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark55(28.10602694023979,-0.5793928089410088,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark55(28.127509310114135,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark55(28.13978898290182,-1.487279070662475,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark55(28.172015401530558,-0.11199838783033705,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark55(28.17659080972527,-1.276978557106677,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark55(-28.18720372353829,-0.4749395705049668,1.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark55(28.189453430865285,-0.8564443359952543,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark55(28.206143060620832,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark55(28.217308996260552,-0.7872600867265942,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark55(28.22059719716099,-8.161055488434166E-10,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark55(28.253377066290057,-1.0869967533813365,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark55(28.265531616413448,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark55(28.27739317988658,-1.2866619490491065,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark55(28.30983852019594,-0.8969492383984203,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark55(28.315930318166807,-0.6113720659869194,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark55(28.334285692817815,-0.009817787700460379,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark55(28.35927227731588,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark55(-28.400686002509175,-0.012153683738910969,0.43462182584730613 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark55(28.464792295665376,-0.6444667253233751,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark55(28.47490969153455,-0.18546398011281207,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark55(28.499224183098676,-0.022831849295599227,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark55(28.50395824699443,-0.4848323033752564,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark55(2.8514469351143106,-0.04353697808049617,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark55(28.528640726325307,-1.319642050705065,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark55(28.580749186218526,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark55(28.589138337891058,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark55(28.592974021798355,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark55(28.595465817576184,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark55(28.617046480142932,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark55(28.621651539951017,-0.9907415570983635,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark55(28.633422160277732,-1.110425241750292,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark55(28.641286359553135,-1.0727362323467844,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark55(28.711401680449164,-1.7514653987853992E-5,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark55(28.712104435941228,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark55(28.725954355063976,-0.2521968386394826,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark55(28.72768290378471,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark55(2.8732861829881133,-1.1839466452349665,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark55(28.773849743733393,-0.45062642244100815,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark55(28.774286153182675,-5.497245900206903E-10,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark55(28.78302554352851,-0.7112829281487218,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark55(28.80206980689107,-0.7195011290944073,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark55(28.82665119592656,-1.456727109812224,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark55(28.83993789986362,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark55(28.861117174388653,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark55(28.88536297134616,-0.6376972311889397,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark55(28.896809272344562,-4.3070662158307764E-5,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark55(28.92770808158255,-0.33919131156096477,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark55(28.929539441018427,-1.218354449855577,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark55(28.93254654700698,-0.331674421889395,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark55(28.958066771051932,-0.04895704854524439,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark55(28.968412552502883,-1.486020988039828,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark55(28.97402518119179,-0.29730844932702116,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark55(29.003929862663256,-0.9470165530540946,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark55(29.007534883035458,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark55(2.9009347923896485,-0.16806193972825012,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark55(29.0124080428456,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark55(29.02147890742048,-0.3542949424182101,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark55(29.086162274611326,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark55(29.111739005251337,-1.2204065823924584,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark55(29.162188241575826,-0.7290821397897425,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark55(29.19288224546773,-0.5539888326390656,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark55(29.20217847685472,-0.9290878515979859,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark55(29.222790010167266,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark55(29.25048406567231,-0.7264635680464124,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark55(29.290632405626866,-0.30941644036289484,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark55(29.29399221386143,-1.2504671403267151,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark55(29.29408659856071,-1.3820011325380381,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark55(29.337410363235705,-0.11251932113076435,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark55(29.34136876561736,-1.4999999966126398,0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark55(2.9349451631551537,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark55(29.35293126313787,-1.023118767588968,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark55(29.360488316477397,-0.7105333182394568,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark55(2.936925192247336,-0.4892108135621374,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark55(2.9381639653219196,-1.2247228174923404,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark55(29.396662349881026,-0.3782882461603094,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark55(29.41170717020328,-9.395838159963954E-9,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark55(29.422454427341023,-1.3026042738014638,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark55(29.46440579579516,-1.1889773689556837,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark55(29.477631538069677,-0.5995869661983142,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark55(29.49597397217924,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark55(29.541215069055227,-0.967216792248497,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark55(29.59300773833586,-0.0054137838990997444,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark55(29.60036591403666,-1.1184276755507625,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark55(29.620503536151404,-0.347856664682225,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark55(29.652165784192334,-1.0217288653209096,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark55(29.653995166216305,-1.4999999999999076,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark55(29.65472888274857,-0.97704459710912,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark55(29.661679093559716,-0.3907574878221644,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark55(29.708179710384673,-1.387156942239275,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark55(29.708970813595954,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark55(29.71344714950061,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark55(29.749301957886388,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark55(29.75713550325948,-0.5232103285870677,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark55(29.812456871904335,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark55(29.821990468763516,-0.7381609914183542,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark55(29.827625820954978,-0.9973154763888346,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark55(29.831387079824502,-0.7688379715437769,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark55(29.846682841711356,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark55(29.895886546028006,-0.4044304138583854,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark55(29.902460258353557,-2.3442685603881816E-7,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark55(29.930568159326214,-0.7831553367577442,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark55(29.936590309482142,-1.2476650423187863,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark55(29.96074425409782,-0.19348310252558498,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark55(29.96776157369274,-1.1362940074480017,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark55(29.980612612298557,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark55(30.00960602816535,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark55(30.05612256011426,-1.4999999999997833,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark55(30.056558867808093,-1.026909379249123,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark55(3.0095429352764014,-0.9795198196670085,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark55(30.09710319077533,-0.5495274171751419,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark55(30.09759221799212,-0.8684578567445418,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark55(30.098223272572767,-0.1315179738999177,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark55(30.115883786396438,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark55(3.0161147635655823,-0.8716025369880782,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark55(30.21072109646704,-0.12099039190111682,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark55(-30.218363117642532,-8.881784197001252E-16,-34.4362456863192 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark55(30.234615046431927,-1.2594543413080108,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark55(30.245032790597037,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark55(-30.274058103715888,-0.8216948383088294,-89.73035827384952 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark55(-30.274945074810553,-1.499999969208039,-16.089959332706353 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark55(-30.28346674639597,-0.5556164357608262,-1.0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark55(30.321560073354846,-0.9055456110349196,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark55(30.351044984240957,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark55(30.369169604951875,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark55(30.369862957011037,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark55(30.37392265032896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark55(30.386294454465325,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark55(30.390492484161967,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark55(30.452428201007187,-8.262659290215911E-4,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark55(3.045761021969162,-0.49933738665549143,0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark55(-30.465064060828766,5.357919029646581,-98.0837036174351 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark55(30.518233612483932,-1.3066426163277072,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark55(30.520018455859116,-1.214813936615434,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark55(3.0550157641916655,-0.6082353428201577,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark55(30.597903925635357,-0.3926170997449292,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark55(30.598082011435693,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark55(3.0618252036288567,-0.2778477604009204,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark55(30.630980772990362,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark55(30.698554627174683,-0.3084671270753354,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark55(30.70591382378243,-5.6306685051408285E-9,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark55(30.719860889566206,-1.4999472566851804,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark55(30.733425847236326,-0.8425862995348865,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark55(30.76295232816338,-0.645428113866835,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark55(30.790511112926605,-1.4860831645178136,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark55(30.81645170788471,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark55(3.0827486756692366,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark55(3.082848240019757,-0.6466828816340853,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark55(30.865551734508536,-0.3133518025444664,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark55(30.90958513356371,-0.3122731706831132,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark55(30.927931777412653,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark55(30.938996510431856,-0.2734667504353,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark55(30.944426701154356,-0.07308752972645038,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark55(30.94447554793797,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark55(30.944891398997356,-1.3426307633140908,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark55(31.00373667017284,-0.9311988916266718,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark55(31.04392492070363,-0.48279348244301534,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark55(31.058586976527295,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark55(31.070297250486107,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark55(-31.07279351294079,-0.0014880094189547205,-1.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark55(31.107651498867483,-0.12061939531655241,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark55(31.157068376240403,-1.1162845084466824,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark55(31.15903883849178,-0.06789066069329433,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark55(-31.159439558595547,-3.327728565803276E-7,87.00911588495615 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark55(31.191519566857068,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark55(31.214765072808234,-7.978080671620091E-4,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark55(31.23556369187301,-1.455943402040731,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark55(31.29033371383457,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark55(31.31265084597454,-0.5056856771423553,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark55(31.32178482207661,-1.240830439552326,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark55(31.33632055424752,-0.6816100533735678,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark55(31.341795742863297,-1.4246403750791408,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark55(31.344456896227832,-1.0883738368305338,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark55(31.355589973621278,-1.359387361235946,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark55(31.395018726539917,-0.6056700323605568,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark55(31.427586670961006,-1.0800571974438906,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark55(31.451150372622152,-0.28775399497372867,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark55(31.45639822010466,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark55(31.48056991820377,-1.4999999999999734,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark55(31.484919309650337,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark55(31.513000196752415,-1.1390174357885963,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark55(31.54115431893284,-0.7928948327647989,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark55(31.541528465351337,-1.004564171929337,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark55(31.55406985619521,-0.838600529758402,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark55(3.159693405132069,-0.36706339195029725,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark55(31.602302165851427,-0.3041726000409133,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark55(31.63281167397801,-1.2290070813367275,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark55(31.63320191467559,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark55(-31.65282742948293,-1.1367024703440778E-9,1.0193201429486605 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark55(31.66752439026382,-1.2109066555898007,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark55(31.714574786551907,-0.3764467297505689,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark55(31.73237123162346,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark55(31.751291599806898,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark55(3.1781060800831913,-1.9526800091072638E-8,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark55(31.787460811574327,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark55(3.191412103997142,-0.7460691677169393,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark55(31.91979404727121,-2.1389274404617963E-4,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark55(31.921266324072377,-0.003567761280586419,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark55(31.923275484619943,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark55(-31.958457651157175,-0.06042650291993534,1.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark55(31.967778714380188,-0.18766903589056483,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark55(31.97503801290202,-0.45100366697597494,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark55(32.00947155077756,-0.20265985579735601,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark55(32.02353163441188,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark55(32.024447259504655,-0.18427947163190606,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark55(3.2026010046915627,-0.024659188765370044,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark55(32.051469979042075,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark55(32.06258323145315,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark55(32.084835837060865,-0.09614862111079782,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark55(32.15970983048214,-0.1376190169548961,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark55(32.21033288598824,-0.061513760891187985,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark55(32.21033849231014,-0.5029622946403789,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark55(32.26308033806612,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark55(32.26514869562049,-0.15904632832770638,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark55(32.26587090631932,-1.229817220605317,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark55(32.281189720654176,-0.7894551322507064,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark55(32.29621419872521,-0.4199553668023581,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark55(3.230025033825086,-0.2587933701455256,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark55(3.23092510384442,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark55(32.31603262404951,-1.396475884775447,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark55(3.2316477875934027,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark55(32.356263387541446,-0.10994435680551806,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark55(-32.38438558018706,-31.349881234532845,39.310189989450464 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark55(32.40754982369666,-6.970087497993882E-4,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark55(32.458920478610146,-1.4920009845179638,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark55(32.471140703333475,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark55(32.51295025802406,-1.40026765862763,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark55(32.53468999054411,-0.8596863865731204,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark55(32.56348994198842,-0.9098600788984905,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark55(32.56892953476203,-1.4077790615099133,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark55(32.60256690521818,-0.2869572748241691,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark55(-32.638332167087825,-92.47839695373537,22.73532786622596 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark55(32.70308915399204,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark55(32.75592712721538,-0.029914625234212622,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark55(32.78839186361737,-0.6644535021662632,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark55(32.83701289060937,-1.1830695476494526,0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark55(32.84185655436015,-3.6453839073077584E-8,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark55(32.84872438676904,-0.394854751345763,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark55(32.856916479175226,-0.9330901220620467,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark55(32.85924145244738,-0.03612230945012129,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark55(32.863846648780935,-0.16428678659866058,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark55(32.863963768719714,-1.043367896305437,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark55(32.881215584802774,-2.6809230806296097E-5,0 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark55(3.2883103641221805,-0.9353767747707936,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark55(32.91934110894658,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark55(32.9344489380058,-1.3729546225670077,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark55(32.959105053802745,-0.3448097017994769,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark55(32.95916000006426,-0.5693279688805961,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark55(32.964803378565875,-0.5961397533691679,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark55(32.96734581874614,-1.876446137540024E-5,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark55(32.97227583569898,-0.4853290222142427,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark55(32.99714973322275,-1.015824853217641E-6,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark55(32.99762838000349,-1.1519058930797705,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark55(32.99907803176521,-0.810173675994085,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark55(33.016222827132964,-1.3474937326883722,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark55(33.0305327465305,-0.42227355921845866,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark55(33.078808970599056,-0.9707225285703487,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark55(3.3104107786829076,-0.020210305067919876,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark55(33.13238102952485,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark55(33.14605208267162,-1.4301668193373258,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark55(33.14987307828861,-0.16201507998670195,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark55(3.315304379845287,-1.377924394597931,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark55(33.18906441563817,-1.196750440683367,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark55(33.20947580516207,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark55(33.27002796692892,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark55(33.31896347071387,-0.3381895416139783,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark55(33.32591404110039,-0.4835494466536939,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark55(33.387380595584645,-1.2635813581955153,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark55(3.342938673296551,-1.2988847347311714,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark55(3.3431665267739987,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark55(33.52842048369914,-4.1358342615103494E-18,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark55(33.53773492907103,-0.01875316282394479,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark55(33.556541312578915,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark55(33.57126799089616,-0.8226610973983455,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark55(33.5804492249361,-0.025520213178620077,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark55(3.358779312985604,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark55(33.59526943674457,-0.6471377121637989,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark55(33.624182867001,-0.26511249069482323,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark55(33.650963773025865,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark55(33.669356504540254,-2.9214522808109196E-8,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark55(33.67788743665335,-0.20765691799119868,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark55(33.68547958215764,-0.4842894501893112,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark55(33.69450616301839,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark55(33.70792330697006,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark55(33.709561926732164,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark55(3.3777017990511986,-9.514722527722886E-7,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark55(33.806807685090156,-0.5291001026423245,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark55(33.820549133071296,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark55(33.824405042030804,-0.5521966703435366,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark55(33.84084786237076,-0.10310762217672093,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark55(33.868163369627666,-1.0124416570647128,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark55(33.877752984870845,-8.174303556795094E-8,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark55(33.891362982744496,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark55(33.92342575680604,-0.27158543384852063,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark55(33.9701187037262,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark55(34.00848969736177,-0.07744253170164939,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark55(34.03626680680088,-0.8132332986100373,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark55(34.06188303976827,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark55(34.07666080404572,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark55(34.15112760717548,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark55(34.21364553343119,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark55(34.24135219617432,-0.15701053105732898,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark55(34.30949977383787,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark55(-34.31938111125028,-1.4999999999999964,1.0000000000000002 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark55(3.4321774584216342,-0.33882779005198893,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark55(3.4363547955918534,-0.18330240709447354,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark55(-34.397587583466176,-1.4965348274595045,3.392745198135401 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark55(34.40701069350936,-0.7168645600519616,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark55(34.42110920143238,-1.4739810879705872,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark55(3.443106651793549,-0.311254194870382,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark55(34.432987465084665,-1.04872574949764,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark55(34.44354184709516,-0.9022848611399183,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark55(3.4453323723958853,-0.35910863429924755,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark55(34.458229160724066,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark55(3.4490453514535533,-1.48391435276625E-9,0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark55(34.537231120347364,-0.4124184524912424,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark55(34.57410909665995,-0.15366802249709544,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark55(34.57864722094047,-0.31964057649121536,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark55(34.58710797632966,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark55(34.60777463408166,-0.7354778833353817,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark55(34.616719844139205,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark55(34.63966328063566,-0.611401942655462,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark55(34.65012069882883,-0.06270019187320397,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark55(34.66606258851233,-3.2621092364139076E-4,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark55(34.70862095462063,-1.18430022715612,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark55(34.71492125149237,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark55(34.73198138725334,-0.36326673869876913,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark55(34.742527483730875,-0.4967096991828108,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark55(34.744455743355445,-0.2843834827283258,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark55(34.755625391667714,-0.001071033226136623,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark55(34.770307610644124,-0.0644555460968399,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark55(34.802139347981694,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark55(3.4813569473568293,-0.47006413374481326,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark55(34.81636816010408,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark55(3.4827303270130727,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark55(34.84270949271158,-0.7786856959921096,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark55(3.4904106461908384,-0.9030513508204479,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark55(34.91989002287431,-0.3524794529304849,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark55(34.92169953502213,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark55(34.936007269195535,-0.022118622604511827,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark55(34.93636902460486,-1.1437872699893035,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark55(34.938508771574476,-0.3688376922439147,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark55(34.93898519048767,-0.9649112705024265,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark55(34.94683948753726,-0.2300249493772757,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark55(34.96750321044291,-1.3093808491287307,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark55(34.9882050272648,-1.4708357296490453,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark55(34.99210283369675,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark55(34.99566465223536,-1.0085851043151193,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark55(35.02298794332637,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark55(35.0615524592495,-0.7789657186411674,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark55(35.08905762079186,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark55(35.20427187375577,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark55(35.22710447737688,-0.0701869125958785,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark55(35.24086298601591,-1.2048452539495287,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark55(35.25361320881771,-1.3436663725087001,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark55(35.31536255969149,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark55(35.34982494517901,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark55(35.389144206600434,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark55(35.44914510256254,-0.8636675440788348,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark55(35.45160290618095,-0.7043948399872807,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark55(35.475511539573944,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark55(35.47816679492155,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark55(35.507574471611065,-1.0386600923892644,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark55(35.516981354295865,-0.5412072900947166,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark55(35.52036850095794,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.1305307080368028,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.4253663955858418,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.4350518128099106,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark55(3.552713678800501E-15,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark55(35.551985425359796,-0.020027591537848152,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark55(35.55829276806131,-1.0447684231593328,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark55(35.56447308511289,-0.7817958825981661,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark55(35.58287524245887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark55(35.59816818939862,-0.02552196188210143,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark55(35.61745518367769,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark55(35.63803434944424,-0.13958837487926573,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark55(35.64629412347625,-0.30688665837466994,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark55(35.703427022873896,-1.4905129473456964,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark55(35.72186095514246,-0.1989612747095807,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark55(35.78782119090488,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark55(35.80870632731334,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark55(35.82722562079584,-0.9558893646744758,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark55(35.84299080763677,-0.728527060779812,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark55(35.85285260680567,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark55(3.591874763447043,-6.820931821530795E-8,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark55(35.928710637109106,-0.09542708821543876,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark55(3.5975523431596503,-0.5992366722082827,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark55(3.602770421356375,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark55(36.06316722372108,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark55(36.07695522049576,-0.9867615544935688,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark55(36.1122583914937,-0.010082311565767554,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark55(36.19787140616619,-0.645090117771673,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark55(3.621286313712468,-0.25046657197519195,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark55(3.622793252557555,-1.4581793046256895,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark55(36.25017866215384,-0.4266230835217977,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark55(36.257874529991795,-0.388683378838545,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark55(36.27852852935945,-0.8501784469158826,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark55(36.29754775476168,-1.0014312002979413,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark55(36.30192898664959,-0.055759720656959146,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark55(3.632105103004818,-0.7312631246946069,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark55(36.32399290265265,-0.2562725904464174,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark55(36.35149411921992,-0.7756553405034472,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark55(36.352580695561684,-1.1407213134631773,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark55(36.35542139734987,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark55(36.35549734981984,-0.9305559907158633,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark55(36.39253528224526,-0.2853180948813925,0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark55(3.641447402256432,-0.3560730982000768,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark55(36.414751247813854,-0.9005474320993399,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark55(36.430944013113006,-0.6194595630767354,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark55(36.46034040110143,-1.4392434120741875,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark55(36.4710043631586,-1.2297297358783468,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark55(36.47689655256673,-0.7782514672853438,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark55(36.47742427703676,-0.28705302656940557,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark55(36.52553820506898,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark55(36.52587325576971,-0.1643987930875621,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark55(3.653576630223605,-3.939847227996164E-8,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark55(36.55256279026052,-0.7428081424125573,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark55(36.59338529553034,-0.2639273571546843,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark55(36.61142180743184,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark55(36.64901500313561,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark55(36.653950001316296,-2.6715041662843257E-9,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark55(36.70316621637019,-1.2512624906784393,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark55(36.73531192062903,-0.28533596885106016,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark55(36.738003142245496,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark55(36.74926639588037,-0.17211249236620896,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark55(36.75474601219697,-3.5462525220835064E-8,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark55(36.80376900853816,-0.05661692067606955,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark55(36.813571341062755,-0.09273472549827355,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark55(36.815177200368424,-0.9975280382924971,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark55(36.82113136433031,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark55(36.82511519346496,-7.587812085399047E-10,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark55(36.827953241297344,-0.0772920209703394,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark55(36.88652012732507,-0.7903820083753601,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark55(3.6913120038864995,-1.7683558445857451E-9,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark55(36.920510432142386,-0.7991001932529471,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark55(36.94871266495511,-1.1128212351754316,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark55(37.02010122453486,-1.4999999999110287,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark55(37.04630275572584,-1.2959231110992615,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark55(37.05403942913139,-1.1455036490827455,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark55(37.07220325107884,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark55(37.08929404702314,-7.781870416685715E-8,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark55(37.10442478462073,-0.472719472073019,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark55(-37.13260898133599,98.99104123383145,-41.257255839575954 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark55(37.14910535711265,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark55(37.17168775086181,-0.3000206270654605,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark55(3.7192851343152142,-0.9810619016627129,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark55(3.7224894162526994,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark55(37.24008084884227,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark55(37.2581946944276,-1.431083061155424,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark55(37.26815010331809,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark55(37.28877438487254,-1.2499957272141824,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark55(37.29521629321306,-0.6681551636298018,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark55(37.29686078485847,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark55(37.30668610594307,-1.0981371112026181,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark55(37.313387632530834,-1.3726805539014677,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark55(37.321889016000526,-1.2801091256105366,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark55(37.3461396299935,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark55(3.7350973498314772,-0.4270866502158146,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark55(37.36074692362739,-3.0955396760032415E-8,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark55(37.401250569334906,-0.5905697963492996,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark55(37.42032883165686,-3.043598923025333E-4,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark55(37.443781597702525,-0.953040174121675,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark55(3.746086932676297,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark55(37.50309259706913,-0.06847620649565409,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark55(37.511172728017144,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark55(37.51398276774131,-0.3404819320860585,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark55(37.59074925828106,-0.18267545453802325,0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark55(37.59810151118958,-0.33401515496181755,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark55(37.60231616376532,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark55(37.61655900852603,-1.3617152298779445,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark55(37.61864080119677,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark55(3.764066660551734,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark55(37.72108768991248,-1.1959674174994603,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark55(37.729203138972025,-0.6744120620746201,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark55(37.7947901397485,-1.2437400817919553,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark55(37.816734694659004,-1.1230336184511762,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark55(-3.7826252610603612,-0.030438485532997068,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark55(37.837111149239135,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark55(37.83969784339126,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark55(37.8491535663527,-0.2014156346827315,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark55(37.85758018059495,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark55(37.865286170274175,-0.766398831532527,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark55(37.87669607218203,-0.14713026314532918,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark55(37.87832058586159,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark55(37.88644920229689,-0.7241536736188435,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark55(37.89289853197494,-1.9101644980771076E-9,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark55(3.790209674593953,-0.7163005394621351,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark55(37.92367495625345,-0.84465859652218,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark55(37.93638970481476,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark55(38.02658582212729,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark55(38.02900113746625,-0.4685880027638376,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark55(3.811609654696909,-0.8812465984174214,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark55(38.15854566588878,-1.1180225331084412,0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark55(38.17382101635563,-0.5207547693234326,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark55(38.20069545054011,-0.6082810682604329,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark55(38.27655547032157,-0.3513738329595195,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark55(38.321171625156325,-0.4207117321794822,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark55(38.35654170536773,-1.2456000119734925,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark55(38.40698359141675,-0.35138614138268665,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark55(38.41614106079024,-1.0252455117089672,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark55(38.47054929886835,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark55(38.503276226700216,-1.2906577540079693,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark55(38.515196035024815,-1.4483607225375827,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark55(38.535245979464946,-1.3844332447468786E-9,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark55(3.8573624070531025,-0.9162880918155878,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark55(38.6076796107526,-0.11201787759753756,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark55(38.65742518143302,-1.162677129560084,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark55(38.66855251673329,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark55(38.678396711209494,-1.6672864764094312E-4,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark55(38.73028453989994,-0.9498017364072808,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark55(38.74153488498544,-1.11255571261853,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark55(3.8779704683501564,-4.201242829327828E-7,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark55(38.810438739542846,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark55(3.8818474023471197,-0.4500869924455664,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark55(38.84667438419498,-0.07190823258264345,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark55(38.86252344341824,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark55(38.87618272911513,-1.2148920518393727,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark55(38.89373186036282,-0.028149793633421183,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark55(38.89422586906501,-0.3729005332990755,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark55(38.903967081186465,-0.6902967824163397,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark55(38.90624258749287,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark55(38.94371528274948,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark55(38.99725841237371,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark55(39.07835319658626,-1.1234814562469535,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark55(39.086053250107824,-0.796711067559785,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark55(39.08879855247167,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark55(3.9091105064515546,-0.4628447618240803,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark55(39.097911689257955,-1.4298142653587487,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark55(39.11907768003337,-0.5844796850223153,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark55(39.12233076063055,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark55(39.12546488692081,-0.5097542929762953,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark55(39.15923859576307,-0.04061851201779465,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark55(39.24588137628439,-0.4377364122335905,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark55(39.279661236973396,-0.2396856332720798,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark55(39.28270224975868,-0.7307797784005459,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark55(39.28957012414338,-0.9507468727456398,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark55(39.305794771178284,-1.3824237770625403,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark55(39.32636521949995,-1.4999999999691747,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark55(39.32984197744902,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark55(39.345688829743864,-0.5828448505225197,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark55(39.35771750948939,-1.3552909530730695,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark55(39.36588726437623,-1.0468805459539396,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark55(3.942818965599649,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark55(39.476209432599774,-0.5360246221791982,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark55(39.48783415467881,-0.10391682810881875,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark55(39.505055614525475,-0.5366313058998458,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark55(-39.53377341424715,-4.440892098500626E-16,95.71252227741235 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark55(39.53582542314217,-0.7177508670504675,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark55(39.54978913371782,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark55(39.5680257749993,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark55(39.58866598208256,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark55(39.59917910620504,-0.12722380652532372,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark55(39.60458097623214,-1.4559334496571807,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark55(39.606966767868954,-0.8076094658774059,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark55(39.61134698815536,-1.083750976179144,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark55(39.634984314968676,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark55(39.637482688223855,-0.587693139772489,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark55(39.656764893961025,-0.9581400832110729,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark55(3.968150320543913,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark55(39.70857640577648,-1.4305040574867496,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark55(39.72160794763213,-1.475238171564135,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark55(39.73892956618002,-0.6805851467205364,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark55(39.74115935491126,-1.0255234255894348,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark55(3.9777195662257308,-1.04247309129765E-9,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark55(39.79418096376736,-0.5792127621169427,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark55(39.855727106337184,-0.43062357193085576,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark55(39.86809157422977,-1.0235527040218564,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark55(39.87002535295488,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark55(39.908770389683696,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark55(39.91861464558602,-1.4237015208690167,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark55(39.920872358988696,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark55(39.92091682332051,-2.0539982539350474E-15,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark55(39.92803004962485,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark55(39.98963005276289,-0.46500886545449305,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark55(39.997201710017606,-1.1018626225874897,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark55(40.0091270362434,-1.4999230746994876,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark55(40.02324667351266,-0.19898985702982636,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark55(4.007557681231887,-0.48720228592905523,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark55(40.10645861811026,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark55(40.1188862884529,-0.8265324702999638,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark55(40.11984480927211,-0.24688057461461188,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark55(40.149635895414406,-0.20850322300526525,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark55(40.15293085487954,-2.985598786800818E-8,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark55(40.15522288618706,-0.2602505776406484,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark55(40.17184470569802,-0.6584648196167762,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark55(4.0192393875639,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark55(40.19415042693885,-1.3185257974434779,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark55(40.196566295106905,-1.0153640208658121,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark55(40.22277902050237,-1.123535404923393,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark55(40.30927647990217,-1.219074336589813,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark55(40.32274213051747,-0.06811894649136274,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark55(40.33947295213224,-0.4098270608626695,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark55(40.34664527884382,-0.8044942243125031,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark55(40.3760546396041,-8.09638053501244E-10,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark55(40.41721204098914,-0.7281805893271951,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark55(40.42104937851088,-0.47370994707799063,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark55(40.426060021644275,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark55(40.44279703077044,-0.8969292163501666,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark55(4.044952954705394,-1.303062754758443,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark55(4.050666257171031,-1.1911161064959659,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark55(4.051074523278583,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark55(40.51565883850142,-0.8770867284892463,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark55(40.52733377364427,-1.3514488726576843,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark55(40.5477637832264,-0.4913702826958204,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark55(40.56283476956062,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark55(40.59167189474857,-0.9407573208113398,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark55(40.632015695093315,-0.05462063817530072,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark55(40.64904455476639,-1.0857461427201809,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark55(40.65805017234095,-0.42746826820159356,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark55(40.69894008153854,-1.4008382704411109,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark55(40.711963544006224,-0.787981333059203,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark55(40.72910890864425,-1.1364130637698542,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark55(40.74389952861641,-0.01412700264646985,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark55(40.74715171831144,-0.6755193779383082,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark55(40.755874242872125,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark55(40.759484082899974,-0.6757488935575586,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark55(40.76900375921136,-0.2726214613318234,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark55(-40.77077226365446,-1.3071269212799455,-0.5184959488841088 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark55(-4.081657164366121,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark55(40.8201803560375,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark55(40.88009283636935,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark55(4.098349111666039,-0.23116671069404937,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark55(4.102645366514104,-1.007620907934462,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark55(-41.08872223985633,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark55(41.10264953807382,-0.2635374206718366,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark55(41.114888721813486,-0.3316480410085001,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark55(41.1473130166508,-0.9345001981538612,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark55(41.23323442811687,-0.35829777318924094,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark55(41.24328479495588,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark55(41.24818292722924,-1.2072910223502813,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark55(41.26225954151287,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark55(41.28247247199445,-1.3800271546471776,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark55(41.29992243458349,-0.8034613730228983,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark55(41.375260170423275,-1.4706379038031192,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark55(41.3889407580038,-0.9419720270570994,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark55(41.397045139579106,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark55(41.434536767427005,-0.7219930964191015,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark55(41.45288628421414,-1.3791154127091643,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark55(41.46984012059943,-0.982469391334913,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark55(41.480587025512136,-3.7512282935440426E-5,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark55(41.51422628523608,-0.33544570593517165,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark55(-4.1575690173086555,-1.7459549543758856E-9,31.68516576909719 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark55(41.58393021396688,-0.5615823888153556,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark55(41.60387952846114,-0.2908878300882787,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark55(41.62121099325654,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark55(4.162524574537656,-1.2164140111935893,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark55(41.64252099275507,-0.939069922953621,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark55(41.644448806345906,-1.271271111801809,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark55(41.654335366271795,-0.49886884337568915,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark55(41.66320190248803,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark55(41.691953598905215,-0.23996748495194797,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark55(41.70720002480138,-0.19380826093167003,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark55(41.750805728374004,-0.8488127253607409,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark55(41.755111662884076,-0.6255284595121681,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark55(41.775060068436574,-0.20968337544694227,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark55(4.181140511670662,-0.4815776485954322,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark55(41.81307810635889,-0.9344930618932281,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark55(41.879152557740866,-1.3719358793031868,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark55(41.91583496386332,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark55(41.91843567974314,-4.48664128746025E-5,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark55(4.1957968705459905,-0.9792071781274525,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark55(41.961507132340365,-0.26534192329065753,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark55(41.9659181261153,-0.027615848729631912,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark55(41.98245870781776,-1.0878877345597209,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark55(41.996292178058944,-8.84519457471562E-4,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark55(4.20178640704863,-0.6243102639539537,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark55(42.1117729889025,-3.141602287079493E-6,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark55(42.11378795535589,-0.647385581036505,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark55(42.120668685153845,-1.2331670377839379,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark55(42.12334742780135,-0.5560018404557314,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark55(42.140808332484056,-1.0753960629782586,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark55(42.1554412050628,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark55(42.158352105878,-0.12872323873527525,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark55(4.217985993064709,-1.3035964149399524,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark55(42.198946251219176,-0.008970168140589898,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark55(42.26447857146439,-1.2398299513745834,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark55(42.27209649248074,-0.8866741448573693,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark55(42.288956024212176,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark55(42.31141719778771,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark55(42.332941450214946,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark55(42.3497786002357,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark55(42.39048999827364,-0.0348160187748654,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark55(42.39399755155644,-1.0713783581176868,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark55(42.42226463391631,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark55(42.44781954711723,-0.5689135818266662,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark55(42.44886998199138,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark55(42.47360770041473,-0.03594123558727347,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark55(42.47575650468082,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark55(4.249299087618052,-1.1237127539869505,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark55(42.53229247387375,-1.0821294886118906,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark55(42.537958510467185,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark55(42.55378808657537,-0.05202158096874787,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark55(42.565658111304884,-1.260094204329023,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark55(42.56712532587875,-0.04511087214343146,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark55(42.63488041993838,-0.5631588469608371,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark55(42.63961669312567,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark55(42.68114519200515,-1.4834354453627556,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark55(42.683873904526536,-1.3581199463945808,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark55(42.690559467758135,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark55(42.69339711676855,-0.8627012786105868,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark55(42.694594198204925,-0.24519740053910288,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark55(42.700962321850234,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark55(42.74297980653091,-0.08865948510566568,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark55(4.275366875878973,-1.364678909724205,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark55(42.76479525682433,-0.9370934370516864,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark55(42.77496324439255,-0.17144541726106044,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark55(-42.81096220279558,-1.7763568394002505E-15,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark55(42.82359180888167,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark55(42.87774090346929,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark55(42.899245429076814,-0.09603260977937111,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark55(42.92038757970642,-0.8586474600907248,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark55(4.296177736131241,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark55(42.96976439300285,-1.499032106127058,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark55(42.99536031373878,-0.03181260345123487,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark55(43.0275256738249,-0.4721725814480284,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark55(43.0302354664189,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark55(43.03307919608874,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark55(43.04785492528433,-0.003608651348553593,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark55(43.06918463551881,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark55(43.11748353719972,-1.2788369222297185,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark55(4.312677684518704,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark55(43.126786869062045,-0.6685853345018984,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark55(43.159192023363005,-1.1438110819264793,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark55(43.16820012999122,-0.023086307260111547,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark55(43.21632661104397,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark55(43.21755447988042,-0.6051192665089218,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark55(43.23412611648912,-0.3045075376051325,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark55(43.264389830724326,-1.4999999999999432,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark55(43.28234415432104,-0.9376324298646921,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark55(-4.3368086899420177E-19,-1.305517344117168,1.0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark55(43.39093178473932,-1.266017291592334,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark55(43.39971126675508,-0.07739658415466533,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark55(43.42383396931876,-0.25776985848312645,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark55(43.44266210640606,-0.11725902817317535,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark55(43.446663500763506,-2.0798299788305928E-8,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark55(43.47120224771573,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark55(43.49814365441796,-1.1821460998083066,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark55(43.52383479328407,-0.5474902481925881,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark55(43.5447442480089,-1.4052677213103135,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark55(43.55061956084114,-0.5375482830158553,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark55(43.569274776891206,-0.7716489589320048,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark55(43.60683677659631,-0.6122507408456669,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark55(-43.6087215906875,-0.040900425888195646,1.0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark55(4.361149919354604,-0.12663984441410037,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark55(43.63769304505348,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark55(43.68710310429381,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark55(43.691804199942595,-0.4888342931263594,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark55(43.770406145058786,-0.21900687330830126,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark55(43.78949989842652,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark55(4.381540144085004,-0.2445872576876605,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark55(43.8382613328277,-0.9476903756071788,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark55(43.87668680113996,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark55(43.90862451255076,-1.4999999995352455,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark55(43.910930872367786,-0.3882639044292864,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark55(43.91804642311607,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark55(43.92954075441892,-0.459386539465215,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark55(43.946185169435694,-0.03275008985596628,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark55(4.396921341334519,-0.8134259402849722,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark55(43.984551666444986,-1.343232965385809,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark55(43.99254355647986,-0.9288501218712717,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark55(44.00780053516467,-6.153663299985447E-9,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark55(44.01163163859696,-1.3748901779273002,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark55(44.01164028501906,-0.16876046283823465,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark55(44.05653493768821,-0.8436663258578907,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark55(44.05695243463538,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark55(44.06060304875231,-0.4329312242628447,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark55(44.071772415465425,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark55(44.108702722467214,-0.07817162826957802,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark55(44.148021346240995,-1.0272357462023791,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark55(44.245529043148906,-7.105427357601002E-15,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark55(44.28693707756386,-1.4974396377639363,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark55(44.323005794893135,-1.0002014034506899,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark55(44.32613905542159,-1.2129154980379702,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark55(44.3495596566189,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark55(4.440892098500626E-16,-3.0049998674695717E-17,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark55(44.435714819745925,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark55(44.512230827875754,-1.2978202635760987,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark55(44.52522132290151,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark55(44.58816841617835,-0.7115303870418415,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark55(44.612280773583535,-1.337760576240697,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark55(44.634979145093126,-0.6985365776358519,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark55(44.63759970334672,-0.14235210533415277,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark55(44.65923739443278,-1.1588691881351432,0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark55(44.683653111618575,-0.14669050622084165,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark55(44.6889277371353,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark55(44.758196107927745,-0.8208558624586111,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark55(44.77964026841031,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark55(44.77971027544914,-1.3579757358871198,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark55(4.478202329193138,-0.697490418384076,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark55(44.78434461318883,-0.6322577018098696,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark55(44.79201971636252,-1.0332069607136773,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark55(4.48132436862826,-0.9566070660097346,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark55(44.813270579035134,-0.4994740063963916,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark55(4.481566651390921,-1.4200449460318223,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark55(4.493656066155578,-1.4616599996314235,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark55(44.96760443462739,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark55(44.99006351284868,-0.5459873812565403,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark55(45.03516816382876,-0.627178967148299,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark55(45.10637159847926,-0.4290552346841583,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark55(45.11648824461335,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark55(45.143296225501054,-0.6777665319897597,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark55(4.515532762544723,-0.38877149171758696,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark55(45.16759671225883,-0.24337037628421543,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark55(45.16800529879538,-1.084065649188184,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark55(45.20673707313918,-1.3165998932151226,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark55(45.2089864019584,-0.17647103856894508,0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark55(45.24267193432749,-3.265905893390943E-5,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark55(45.28129960191771,-1.209835078117046,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark55(45.2888136528328,-0.6902138365723118,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark55(45.30031008237282,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark55(45.321102041779056,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark55(45.33387369974042,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark55(45.3391353765079,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark55(45.34879963947918,-1.4458104027590206,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark55(45.398931344570876,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark55(45.4692339852424,-0.7171878831725422,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark55(45.48377361305151,-0.43207809214548115,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark55(45.48414616292544,-4.804363412765746E-7,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark55(45.52751455192006,-0.8611307403872672,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark55(45.54362650962506,-1.3810501391113847,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark55(45.58260236803977,-1.3304233316715014E-7,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark55(4.558727510129277,-7.881641718474437E-4,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark55(45.59945996102164,-0.0517776349928174,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark55(-45.605705884800486,-0.2348129829059168,-1.0000000000000002 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark55(45.65425023270507,-0.36545357500969633,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark55(45.676548460049275,-0.4750598986775403,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark55(45.69931476523581,-1.1381036723612779,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark55(45.725464127101304,-0.9692926996639422,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark55(45.75211930687601,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark55(-4.577629677353315,-1.009722763778413,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark55(45.77775047551981,-1.3694830518704713,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark55(45.79551516212969,-0.8150050658250301,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark55(45.8027729711486,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark55(4.581615352933161,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark55(-45.842067072856494,-0.06656358049305222,-0.08885743654617073 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark55(45.86489258133062,-0.028506019163674127,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark55(45.878327938354374,-0.6351496981634099,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark55(45.90787318910859,-1.1327508945587095,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark55(45.911623535839055,-0.5205148835514279,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark55(45.917342983059285,-0.4568878652389827,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark55(45.920836204148316,-1.3588668045261407,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark55(45.97709304168504,-0.4154735036116648,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark55(45.990048119342674,-0.5518133774524001,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark55(46.006587779678085,-1.4999054107305165,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark55(46.01129597725968,-0.4278405029368466,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark55(46.02693150300945,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark55(46.02752189627693,-1.4999997458998875,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark55(4.603517904583271,-1.1162327138095978,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark55(46.050247224217344,-1.0238630309886503,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark55(-46.061541785145344,-0.5557661320897682,74.3262149050577 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark55(46.06244940077232,-0.8652769210337983,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark55(4.611722987266091,-0.14513628654012223,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark55(4.612102790954124,-1.4999999999641833,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark55(46.124742204274554,-0.7338644100159266,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark55(46.137147584865545,-0.7305821213293321,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark55(46.14814325724099,-1.4999999879520776,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark55(46.17222505441947,-0.6474095600206482,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark55(46.18649393439842,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark55(46.19662923237638,-0.2634822207211679,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark55(46.20915280140957,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark55(46.272394435712734,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark55(46.28388580015675,-1.4491890244837222,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark55(4.629721597615187,-0.538462028007299,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark55(46.31050353149345,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark55(4.63135425652322,-1.1487639293912206,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark55(-46.322539928343474,1.2370571973912234,-89.6298999556403 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark55(46.32288786543597,-1.4999999997712312,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark55(46.3448040910842,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark55(46.38600806851164,-0.4697287474729315,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark55(46.40113101795626,-0.9981359280096487,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark55(46.410947859828944,-6.535765638261386E-10,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark55(46.41107978337152,-0.856210454412024,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark55(-46.41535081065695,32.929622997794894,24.41560859292437 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark55(46.41580478308279,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark55(46.42629833125826,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark55(46.45848395757313,-0.3694706034176756,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark55(46.47303787288152,-0.376443538700741,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark55(46.4938806510294,-0.8178962619801933,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark55(46.50057687187983,-0.2121855860862235,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark55(46.524466110134,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark55(46.564017565308404,-0.5205438882531723,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark55(46.602130393120554,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark55(46.6278780053851,-1.4514441408670677,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark55(46.628804420754506,-1.037798622034105,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark55(46.726903932318805,-0.5283099515084024,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark55(46.73868114054403,-1.3956951115534613,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark55(46.77166329556911,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark55(46.79355472096134,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark55(4.683990776974568,-0.19139273231581277,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark55(46.8444844466554,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark55(-46.86276989209006,-1.2259623776371786,0.0625526772978839 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark55(46.88301191739572,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark55(46.89054211500115,-0.7782072665122541,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark55(46.90752684314549,-1.00058890772749,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark55(46.95937629026196,-0.3198690105297004,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark55(46.96255827109067,-0.8542055858812292,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark55(46.96727090620786,-0.7198784685073889,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark55(47.002069403402345,-0.01102327405342729,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark55(4.703747616042975,-0.8186545449921887,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark55(47.061130925523145,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark55(47.06945962151812,-0.04104975826344148,0 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark55(4.707968822909535,-1.4038085623432526,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark55(47.09299762568779,-0.5721609609638421,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark55(47.10465942920027,-0.921245775606323,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark55(47.11563672229545,-0.12141739106512528,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark55(47.12452321688201,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark55(47.1279945275393,-0.8309750222713959,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark55(4.715117522934229,-1.2139004565201523,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark55(47.174440128267065,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark55(47.19542078609148,-0.8272023166254963,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark55(47.200589809441766,-0.02758954322930851,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark55(-47.25034989564429,-1.4644190367190622,-19.90225492565601 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark55(47.260876340387085,-1.1049847698138393,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark55(47.29516963761643,-0.4175130127274471,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark55(47.33395213374058,-1.0516871500514169,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark55(47.393891858088494,-0.8690485927682745,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark55(47.415033954833916,-0.278755106630709,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark55(47.43976034726509,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark55(47.449072151529066,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark55(47.48633346894431,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark55(47.56483825643298,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark55(47.70357092888265,-1.362939954721191,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark55(47.737606466226545,-0.003395295276856159,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark55(4.7739311426865125,-7.898186118581812E-9,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark55(47.74846724537872,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark55(47.75319143043858,-3.875788935625853E-4,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark55(4.776543268604399,-0.47973499091396077,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark55(47.82938090598798,-5.771599710059023E-10,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark55(4.784301749413672,-0.4488244836113431,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark55(47.84370557181942,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark55(47.869995882142995,-0.8138633270638973,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark55(47.88008885756028,-0.33438847918786463,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark55(4.788509345967597,-0.6727249125049117,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark55(47.88843671667266,-0.9325236777757553,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark55(47.9100799382137,-1.9122700130120065E-7,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark55(47.918233963252646,-0.2576869404407063,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark55(47.92507029156229,-0.10415813040410171,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark55(47.93523895098696,-1.0900725675967635,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark55(47.93776703170764,-68.39735090036385,-60.30291022040295 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark55(47.96681392172583,-3.770504033374697E-8,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark55(47.96687629259586,-0.034856704696664464,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark55(47.97566375957666,-1.1339698645053726,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark55(47.977291051891456,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark55(48.092145445471296,-1.1581830299741669,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark55(4.81303328439742,-0.9217798664440835,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark55(48.18765821888036,-0.26514261060307476,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark55(48.19075833899706,-0.4675004966691301,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark55(4.822245748022965,-0.06445871460666663,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark55(48.226602334882074,-0.7215014096734294,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark55(48.25420135759987,-1.1506744797210864,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark55(48.27326595652033,-0.8712863008932361,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark55(4.827334419454199,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark55(48.29913735993884,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark55(48.35230751322554,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark55(48.35809814263972,-5.000115623669244E-9,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark55(48.36663258245364,-0.002108620198419135,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark55(48.39178559284528,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark55(4.840146458060673,-0.5113000263085326,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark55(48.40982033702625,-0.7787911915604124,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark55(48.44990682967679,-1.1818203727763588,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark55(4.846689147631148,-0.2499465421043715,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark55(48.47888592898809,-0.9950578128796792,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark55(48.49921781924931,-2.724325422195337E-9,0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark55(48.508277215707864,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark55(48.54874191385181,-0.17327680640687637,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark55(48.559273743669834,-1.3219940758925999,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark55(48.59022686145866,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark55(48.617681077109836,-0.2968023239143016,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark55(48.675058373270076,-0.4580974793366069,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark55(48.70512312440789,-0.6172950624733389,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark55(48.74580236808037,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark55(48.81501976862238,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark55(48.819327165622724,-1.1200806784102049,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark55(48.82364582140727,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark55(48.83061797266784,-0.7912647918645059,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark55(-48.89516563921945,-1.4999999999999982,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark55(4.89076820228592,-1.4999998710496918,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark55(48.91220775505188,-1.4999999053056707,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark55(48.91769452510664,-0.6127372657102228,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark55(48.95107575134986,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark55(49.022827029700125,-1.4999999999998757,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark55(-4.90249768819459E-202,-2.491798737774392E-206,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark55(49.03745447927559,-1.4287643325238903,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark55(4.905163913272176,-1.4543003934138437,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark55(49.07317835134525,-0.46389740831420934,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark55(-49.077288003521225,-1.3168385511523986,-70.14255711942272 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark55(49.07984153454393,-0.8363168883425447,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark55(49.1470970117405,-1.4247697970258653,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark55(4.916051972058392,-0.4461612666710794,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark55(49.1951678090023,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark55(49.206117263036504,-0.243055108737664,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark55(49.25625482740507,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark55(49.26181420820129,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark55(49.27221011488619,-2.841650633816096E-9,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark55(49.34897354215677,-1.3409395990702624,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark55(49.39336550107683,-0.6941780695388764,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark55(49.442832472330736,-1.3394492482619293,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark55(49.48174940010904,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark55(49.51631188712768,-1.4999999978560166,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark55(49.582827494995655,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark55(49.60087264966822,-0.7098540895480454,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark55(49.64503952908626,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark55(49.65070337645864,-1.1984207590239726,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark55(49.651425799999856,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark55(49.65280479333768,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark55(49.658490217428934,-0.8719514428284793,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark55(49.68492449546068,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark55(49.76456234907715,-1.4606685910442108,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark55(49.783780273791166,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark55(4.979667922043035,-0.30347522041165576,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark55(49.80396984313623,-0.9413353303816123,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark55(49.81350159708501,-0.6085395720453022,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark55(49.85315798844863,-0.017875139471616563,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark55(49.85994917507023,-0.5651455446674287,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark55(49.88340667736666,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark55(49.93597446229665,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark55(4.9977256096218134,-1.4785129424854295,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark55(50.00232625134703,-0.1935220852831463,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark55(50.04122242991798,-1.1240697340839367,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark55(50.04998039786871,-0.9201558638214342,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark55(50.07691202777781,-0.018502746786795088,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark55(50.09677843947725,-1.1911020023025805,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark55(50.131014881948516,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark55(50.14211752194018,-1.1086088348275291,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark55(50.16915707600532,-0.9882928291576771,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark55(50.19725323780761,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark55(5.0219422772139755,-0.6783604672534977,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark55(50.23226747586838,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark55(50.30025467902385,-0.7072688998302166,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark55(50.305991581415796,-1.1895713220805728,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark55(50.31945723348491,-1.1575676058781568,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark55(50.34189119472756,-0.19734904108566917,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark55(50.35809051565096,-0.05279648241500334,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark55(50.374774860948776,-1.2700550116593377,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark55(50.379370309703376,-1.095403347590505,0 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark55(50.39343220906758,-0.4009448062467982,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark55(5.039614438544859,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark55(50.44581084193073,-0.23033162730612045,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark55(50.46107609795507,-0.40970650634720673,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark55(50.46229186193955,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark55(50.49358861759663,-0.20155615344011157,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark55(50.527247979899585,-1.436744397489349,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark55(50.52814894275406,-0.09640805820590259,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark55(50.53577796407731,-0.88103128842393,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark55(5.0540735591482475,-1.819567247852487E-9,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark55(50.59943652842861,-1.1464457659438043,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark55(50.607887946072914,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark55(50.61518420965234,-0.47672041414369837,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark55(5.062429094872691,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark55(50.63892636077071,-0.3646118449391192,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark55(50.646410796676065,-0.8946522835937039,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark55(50.659548771074284,-1.0100704647065601,0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark55(50.683311215221465,-0.9498809359714286,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark55(50.70395248375668,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark55(50.79743328292768,-0.4806627471043101,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark55(50.92988661779827,-0.8771348431638372,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark55(50.96149827025129,-0.22024924497426943,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark55(50.99354205488193,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark55(51.06332464715163,-1.4223480421398946,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark55(5.107279161054734,-1.4459179755220035,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark55(51.08189821473902,-1.4021763810828891,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark55(51.09129969582119,-0.32750399598668745,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark55(-51.09853883960477,-1.4918622716654695,-0.9999999999999973 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark55(51.10722669393547,-0.9667814287951537,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark55(51.13589399511142,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark55(51.154862059575954,-1.092192910259893,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark55(51.19532095558143,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark55(51.204224518594316,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark55(51.219435299039276,-0.8379187246857356,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark55(-51.24776605198072,-0.7036506573101047,0.10077125814343335 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark55(51.256217120083704,-0.2663313963192131,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark55(51.28845246006008,-0.7708828693968148,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark55(51.333450376241636,-1.4338022728507136,0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark55(51.35221526268893,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark55(51.36347890700628,-0.0482681373409406,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark55(51.36788855940988,-0.38061481868963,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark55(51.38002670167633,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark55(51.40855201969553,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark55(51.4190279961621,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark55(51.49952397148485,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark55(5.151091901983094,-1.7687062338466198E-6,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark55(51.53337953581166,-1.4999999999999796,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark55(51.54064749733579,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark55(-51.54861996421971,-8.881784197001252E-16,-29.42817923524605 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark55(51.5698776475377,-0.013123779772425515,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark55(51.581470081311515,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark55(51.59190021812117,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark55(-51.641589313634896,-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark55(51.69167154205679,-1.0812478532660421,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark55(51.69289090241395,-0.8741730695649028,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark55(51.69530748311102,-0.7573273253350852,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark55(51.703854237879135,-1.510183465929375E-4,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark55(51.736459935420896,-0.19353009631869345,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark55(51.73737546029383,-0.6636451788008623,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark55(51.76176300808143,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark55(51.82112057803215,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark55(51.829123581243664,-0.016957786151516756,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark55(-51.84401067426828,-1.1116641980220707E-8,1.0000000038540728 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark55(51.85623061529384,-3.2779339179732753E-6,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark55(51.85879515923105,-1.118330763018216,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark55(51.86342447631587,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark55(51.86553929688954,-0.5449839431352361,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark55(51.9517987103035,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark55(51.983495138918556,-0.9152587903005216,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark55(5.201147972985922,-1.499999999817634,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark55(52.012515151581425,57.570682207932975,43.91176321060482 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark55(5.202780758331002,-1.183295465653785,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark55(52.04080715721943,-0.2749602441283603,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark55(52.05578924384551,-1.4028649218084848,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark55(52.06075726715648,-1.4999999938625355,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark55(52.07376226427104,-0.31585321576384606,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark55(52.13036908402696,-0.5866435312174314,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark55(52.209821937680246,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark55(52.215298629180715,-1.499999992869402,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark55(52.22137783148392,-0.5362057890613521,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark55(52.24753205407327,-0.726941129828482,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark55(52.28653755258908,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark55(5.228665465054334,-0.25644480954794346,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark55(52.35503418446848,-0.4957706263035111,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark55(52.359198769297365,-1.3260293101388942,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark55(5.236267283043205,-1.838957039085593E-6,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark55(52.365608039566524,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark55(52.374782792632175,-0.5054485382967471,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark55(52.380818216705734,-0.16617124039773445,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark55(52.42930925147601,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark55(52.44332168801026,-0.2460713020544083,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark55(52.50167876058339,-1.38040702211938,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark55(52.51053791445533,-0.9445161983950356,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark55(-52.52926803736759,-0.6810461550318797,-57.323810658227025 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark55(5.262505217612885,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark55(52.6813808114958,-2.5764246110952946E-8,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark55(52.73137511388006,-1.2340088355973573,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark55(52.750063252284974,-0.18638235652424895,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark55(52.77485834265448,-1.391645328703902,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark55(52.802617659078294,-0.3202619916192573,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark55(52.842061528773144,-0.176977879291913,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark55(52.84746401337023,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark55(52.84823096901158,-0.8193934884435095,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark55(52.87330429887161,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark55(52.87802236691015,-1.4724780212777362,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark55(52.88514853253007,-6.202563991138547E-7,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark55(52.89583694638151,-0.5311522268274982,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark55(52.97454023369886,-1.0240471661180424,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark55(53.005623958900486,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark55(53.059143063624276,-0.5938998116660024,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark55(53.0725180397512,-1.1328925559006962,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark55(53.09564685623042,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark55(53.11989504753197,-0.20870806721601465,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark55(53.168066785385044,-2.0504942389184367E-5,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark55(53.177110423457975,-0.5515289320599646,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark55(53.18687864005691,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark55(53.24895974602812,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark55(53.25112803268078,-0.18385595103426078,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark55(5.329163224993772,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark55(53.324608573802806,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark55(53.32721225286835,-1.0714004269189463,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark55(53.32737639126421,-0.984014844000101,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark55(53.33056925981069,-0.0973949029531056,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark55(53.343446741484684,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark55(53.371218022808826,-0.17515084581944418,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark55(53.37842088732717,-0.7710640164879692,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark55(5.338702315797281,-0.13307414482842125,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark55(53.45181402656033,-1.4321317728220602,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark55(53.470464855867064,-0.5597839431842679,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark55(5.355154673829716,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark55(5.358262619642097,-6.307068309675398E-8,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark55(53.5876542840395,-0.18167024063779125,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark55(53.58785769541632,-3.9732011388296554E-5,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark55(53.61629353806867,-0.009743054437729015,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark55(53.62150557591097,-3.240127142899724E-8,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark55(53.633261009151525,-0.6501965426176737,0 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark55(53.64162492936546,-0.33045734111866665,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark55(53.67648356979429,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark55(53.68352105995206,-0.8457205006022601,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark55(53.701565138196386,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark55(53.72164561486383,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark55(-53.72299762426629,-0.9678199601203069,0.9999982199980147 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark55(5.3732804128823375,-0.7199487539167126,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark55(53.73845448725935,-0.9208878023696556,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark55(5.37466146254566,-1.40112109407106,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark55(53.759376857297866,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark55(53.77699275766332,-0.1881934911396338,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark55(5.3820301351391855,-1.1440726013671707,0 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark55(5.382264932735993,-0.706558348294763,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark55(53.88993117157298,-0.4472407645562271,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark55(53.910718347239246,-0.5298321820357681,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark55(53.91235527913289,-0.14386775411722041,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark55(5.3928609682738085,-1.4636156892008076,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark55(53.95814283928769,-0.15218690802109558,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark55(53.99716336276077,-0.11926831962129292,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark55(5.400986173357753,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark55(54.01523986501381,-1.276146332685356,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark55(54.034457294825685,-0.12387625705466543,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark55(54.0410269308712,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark55(54.04717735901474,-1.125301759117285,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark55(54.05718711373794,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark55(54.06319995087091,-1.0540201344846507,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark55(54.0667631631199,-0.5229003228461924,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark55(54.073416817738654,-4.1001737053513927E-7,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark55(54.09266889403957,-0.036993643955354025,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark55(54.09804666665542,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark55(54.12305650239705,-0.056346417024627726,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark55(54.14242304933356,-1.1944256985426875,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark55(54.163382311786336,-0.5224850815087141,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark55(54.17693158634762,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark55(54.18756568937084,-1.3129591999192964,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark55(54.19055284575801,-0.41936065440969306,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark55(54.21937884440216,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark55(5.422499021772232,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark55(54.241896501492846,-0.2691652201406882,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark55(54.25284856303011,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark55(54.25331637831778,-0.44895543616873157,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark55(54.25547167875001,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark55(54.281908306829166,-0.3893976472913323,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark55(54.3299707099863,-0.7861639164911409,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark55(5.438336215296565,-0.3398570020715489,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark55(54.38857959410956,-0.7918713772785253,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark55(54.389135164435345,-0.03402877376930491,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark55(54.44815483651664,-1.0203165216192,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark55(54.46414607446954,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark55(54.5030829688485,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark55(5.453159311128971,-0.38154494874697775,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark55(54.539390647067265,-1.3036654015503624,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark55(54.59328260946035,-0.42589308333470965,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark55(54.62388921161988,-1.2381454373000693,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark55(54.65738533027523,-0.4561886597552256,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark55(54.67897233115546,-0.8497030242886499,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark55(54.69365996298015,-0.1956027627540986,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark55(54.72032310677872,-1.138758182877524,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark55(54.76510204528611,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark55(5.476577059782084,-0.8331505785761271,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark55(5.477169337519754,-1.0956364227705877,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark55(5.480757973441783,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark55(54.81639152828065,-0.44845847742902356,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark55(54.81690696245556,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark55(54.83455496854339,-1.392769713524185,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark55(54.854337452203225,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark55(54.861571187632705,-0.6034034971855675,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark55(54.883783612851346,-0.7910954226244948,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark55(54.889442309512816,-1.4999999997955082,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark55(5.489859271164832,-1.278754181518984,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark55(54.9115500178886,-0.5626240288534579,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark55(54.920382890180065,-1.2446129541017195,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark55(5.496356779197114,-0.6321203893738794,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark55(54.98631323552611,-0.6248145871819908,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark55(-54.98925052149993,-1.395716914647322,-56.98420145681312 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark55(54.991280185968606,-0.025802664859292057,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark55(55.023183424574995,-1.3424614142802076,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark55(55.04256462050028,-1.24483266638125,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark55(55.055996512622805,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark55(5.514712623611148,-0.029283355531085298,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark55(55.170611007090145,-1.274439996261414,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark55(55.17608411464701,-0.10033955841194331,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark55(55.20939645792532,-7.78363256492492E-8,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark55(55.327030554715854,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark55(55.33020071535663,-0.9940186612853514,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark55(55.332031581688256,-0.08095751239051864,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark55(55.343739758227514,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark55(55.37166851459415,-1.4004475439196895,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark55(55.384588221177324,-0.7041613679607828,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark55(55.39763369445592,-1.0032958440490631,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark55(55.44342273090905,-0.41041220483940855,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark55(55.44496123963864,-1.497728964961806E-8,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark55(55.44523893056066,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark55(55.46083623798532,-1.4538784129531734,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark55(55.464822923220765,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark55(55.492547770484464,-1.4999999999994635,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark55(5.551115123125783E-17,-0.7366809075137651,1.0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark55(55.55162068154145,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark55(55.55868049296478,-1.2251030456145457,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark55(55.60989145461646,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark55(55.62080127674656,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark55(55.645891995267164,-0.9356997762573798,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark55(55.665855213479745,-0.12371378236001118,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark55(55.684147253893315,-0.8656877327532335,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark55(55.69308836702646,-1.4160767330968955,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark55(55.69743234571101,-1.0143639442883576,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark55(55.703634122806605,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark55(55.74933688469799,-0.07405387209671477,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark55(55.8204783797579,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark55(55.84133762187534,-0.3059079635371571,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark55(55.86095073127484,-0.6143464556757652,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark55(-55.8654749308072,-0.1159351475472947,-0.051994644338783313 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark55(-55.89858336206157,-1.2692931760205814,1.0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark55(55.912173210262765,-0.563923469056621,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark55(55.92601128284082,-0.8842648870902483,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark55(55.96370656783418,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark55(55.969988163088715,-0.11992204482000512,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark55(5.597906385286713,-1.4966064702902109,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark55(55.98010516521538,-0.7814778676046785,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark55(5.599300004104501,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark55(56.011886133081845,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark55(56.02911717837026,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark55(56.03082907139885,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark55(5.603912372067022,-0.8890661084059232,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark55(56.06812969993308,-0.4518020330750628,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark55(56.132316254698395,-0.17399010774892076,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark55(56.13659343557552,-0.47857221481757506,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark55(56.18803084872667,-0.7389247630499796,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark55(56.20169963719162,-0.0481793777007411,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark55(56.221009947791885,-1.0480864876851967,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark55(56.273353162903106,-0.10576875044595502,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark55(56.29447698493602,-8.926985257908523E-16,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark55(-56.31052655667672,-0.5418244920056217,0.0060525414555527846 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark55(56.33008698667689,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark55(56.343729554841566,-0.4883835505795687,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark55(56.35067343590507,-0.055753901799993955,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark55(56.37554633323039,-1.2601241091741826,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark55(56.38402248804434,-1.4829516241684644,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark55(56.393822612671244,-1.3990183335255155,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark55(5.646062103845594,-0.5432612295408333,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark55(56.4679212796795,-0.48280394562282236,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark55(56.48215972153275,-0.012504945013702584,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark55(56.48705494411328,-0.1097723312344474,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark55(-56.4932274608094,-0.8474115441229486,-88.1685180807376 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark55(-5.650629520329352,-1.4999999999999964,-0.9999999999999982 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark55(56.52346427554181,-1.280235263009308,0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark55(56.53810546468927,-1.3235661778634835,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark55(56.556021940973295,-0.7544799799833015,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark55(56.560306644175654,-0.17367092831475617,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark55(-56.62682439939648,-0.425839990497264,1.0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark55(56.64827133631276,-0.04967085002655426,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark55(56.65716936710706,-1.5361468164624884E-7,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark55(56.67831310518029,-0.20248168851235393,0 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark55(56.68698501905581,-0.3623637329431233,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark55(56.689471698677124,-0.08513532109780897,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark55(56.68999539286375,-1.964336636365396E-9,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark55(56.69587259878443,-0.08792925609513969,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark55(56.70106674660491,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark55(56.71325004865492,-1.226971000968312,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark55(56.723879016952225,-0.97420632562023,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark55(56.73118964967857,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark55(56.73300940643662,-0.8297806569741653,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark55(56.765055849749125,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark55(56.771601615020074,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark55(56.77827878376803,-0.6468454723379979,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark55(56.779850891606486,-0.9152073815398376,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark55(5.682252061308452,-2.317978076092958E-9,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark55(56.85031021613517,-1.317923265033896,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark55(56.8566160200507,-0.35004703953570493,0 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark55(56.89941443572266,-0.9652580967898774,0 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark55(56.97181864139671,-1.4336089869658082,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark55(5.697892853608778,-0.32362455685105473,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark55(56.99714078248091,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark55(-56.99826985386264,-1.0222618597418027,2.465190328815662E-32 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark55(57.00218991717779,-1.1405637005867995,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark55(57.06007133120295,-1.4999999999999094,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark55(57.083485472163744,-1.4247835174880352,0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark55(5.708559526340894,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark55(57.12452691234652,-0.886266583008303,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark55(57.142755564940174,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark55(57.15210275685611,-0.35020181263853,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark55(57.16945441022,-0.008550347091304644,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark55(5.720687617767069,-0.042830474628701154,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark55(57.209302812934396,-0.6121216118221753,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark55(-5.721090061689928,-0.2124970426265072,1.0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark55(57.256769154350536,-0.933993748942413,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark55(-57.27345149591045,-1.4919541472861839E-9,45.924145420943404 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark55(57.30984532181833,-1.2986978537102054,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark55(57.3282365172019,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark55(57.34406095100667,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark55(57.378885766227526,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark55(57.39402266741652,-0.4966762136009475,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark55(57.42388377508604,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark55(5.746080572462514,-0.044994763199871834,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark55(57.495599023234206,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark55(-57.50034284014154,-4.302693481351102E-9,12.665696898321496 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark55(5.751146969457693,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark55(57.51932244613789,-0.01373537902709221,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark55(-5.753376267075053,-2.220446049250313E-16,-2209.9145314082693 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark55(57.55976352549064,-0.2120081456297669,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark55(57.56982228113975,-0.09981494722748607,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark55(57.57181893971607,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark55(57.59083375200175,-1.499999934095122,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark55(57.60149582830399,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark55(57.60490861649896,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark55(57.663428819288924,-0.7343175317498982,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark55(57.68824547289138,-1.4311972757294122,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark55(57.69034084009351,-0.055038257947259694,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark55(57.709968870704614,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark55(57.7251652980915,-1.3750426911697673,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark55(57.73015587172728,-0.9339536305190583,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark55(-57.74020155680346,-1.1296540495577305,57.531178967464 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark55(57.77764494183778,-0.629607052504752,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark55(57.782804830080984,-0.5212113748560021,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark55(-57.78412137972776,-1.42725077237195,32.20317157174822 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark55(57.78530707762629,-0.0086256518123351,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark55(57.794058022965395,-1.9110153470916123E-9,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark55(57.80069311439803,-1.190851522634354,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark55(57.82054280777248,-1.1711164012990407,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark55(57.82170671520018,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark55(57.825900771784234,-1.2496920600960966,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark55(57.85816357480318,-0.10484637913918682,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark55(57.951850746822174,-0.7138127844631739,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark55(57.95945679112165,-0.07464752389924811,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark55(57.998242495501216,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark55(58.00989668820074,-1.2703723552950485,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark55(58.01669972267632,-0.7872652886054468,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark55(58.07344188389632,-0.20475047956171544,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark55(58.10869844888907,-1.4496083094397594E-7,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark55(5.813991008978263,-0.060356857861670554,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark55(58.1513944176362,-1.0772772408863958,0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark55(58.156538090614376,-1.0568324455338096E-16,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark55(58.244493291894,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark55(58.27881990851088,-0.2670211564228939,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark55(58.298156771166084,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark55(58.40643536099111,-0.7841002578146714,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark55(58.41032585250145,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark55(58.41517433453428,-7.229481620476404E-10,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark55(5.841678599484959,-4.303010687394575E-10,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark55(58.41690947082873,-0.5180055748316006,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark55(58.42176635607819,-1.4938737350559064,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark55(58.4453442170487,-1.4801242161941985,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark55(58.450759534907604,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark55(58.46190050774637,-1.1394434354776317,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark55(58.482845032801464,-0.12160140572837186,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark55(58.50572831786519,-0.8632478624798665,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark55(5.853478580964172,-0.5868324992740399,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark55(58.542465562416766,-0.044533797864117375,0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark55(58.549254088393525,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark55(58.555595336374,-0.64428596647936,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark55(58.565437479145054,-0.30656980441874726,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark55(58.56585910752824,-0.5734498419162009,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark55(58.58427804539671,-0.3314853955724796,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark55(58.629032917778176,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark55(58.683090980436276,-0.22391263867993416,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark55(58.68782537049975,-1.0685471843880947,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark55(58.71590290934641,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark55(58.716162028026446,-0.35576582169960724,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark55(58.73915797779699,-0.07269070768660868,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark55(58.75328556119571,-0.40474771482597205,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark55(58.77197369401415,-1.1793843292337596,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark55(58.78379864596235,-0.060422826791308726,0 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark55(58.78710832285047,-0.3049038505415602,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark55(58.807614806816275,-0.9168281115045301,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark55(58.88195958665423,-1.4931745117872526,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark55(58.88997718635662,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark55(58.892988125985,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark55(58.8953324683165,-0.23199334216990963,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark55(58.925631462290255,-0.16118471740902635,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark55(58.942235746685185,-0.520252841186847,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark55(-59.02151865754471,-1.0828779445865884,-0.9515028290646064 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark55(5.902933661312886,-0.14675081207566532,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark55(59.043613261695526,-1.1350589262366881,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark55(59.06944032194819,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark55(59.07136743395776,-0.6452200910703922,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark55(59.10685396231534,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark55(59.16362073989316,-0.03861542612924618,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark55(59.23493553450734,-1.2775504488128622,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark55(59.23599265630594,-0.7637636889206334,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark55(59.32936737280204,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark55(59.35013556194072,-1.4999999999619094,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark55(59.363356871605745,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark55(59.4145693638049,-1.1691190244559886,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark55(59.461375675744904,-8.284567316539858E-7,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark55(59.49287526871618,-1.24651228261587E-9,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark55(59.50611814910384,-1.6558006272610236E-9,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark55(59.55083954378227,-1.055215184861979E-9,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark55(59.555253949710675,-0.6392714259103915,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark55(5.957327365637369,-0.47025831512424077,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark55(59.578355385774984,-0.7908958554547536,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark55(59.60660530871568,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark55(59.63603081345221,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark55(5.965447443786303,-1.4411439865021745,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark55(59.65722840167072,-0.7675818825816103,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark55(59.67196404820089,-0.15339467968098397,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark55(59.719833162761375,-0.9191413673474056,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark55(59.763453436332256,-1.6984539155494496E-9,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark55(59.76507166687708,-0.9097844447362782,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark55(59.76867192865177,-0.8863056776217144,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark55(59.803311281808874,-0.05549923461019546,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark55(59.80415114876243,-0.7382679109916863,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark55(5.986866924155326,-0.10485587814193487,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark55(59.91828981017295,-1.4876835361674288,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark55(59.92170155299456,-0.020419143315606535,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark55(59.92913989747173,-0.03253129298874491,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark55(59.93293617380026,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark55(59.9466176792543,-0.2054236068966654,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark55(59.950214666531295,-1.3694987372096836,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark55(60.02422791858088,-0.5432021142980585,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark55(6.00591808626929,-0.831448857863454,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark55(6.006940971607406,-0.1877451505114599,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark55(60.09624007952104,-1.1403599253479086,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark55(6.009961108415425,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark55(60.105284602902266,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark55(60.11352336611594,-9.048269325686149E-8,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark55(60.12216584623292,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark55(60.13198823872537,-1.4074347228271673,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark55(6.0138102076650135,-4.805470545756406E-8,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark55(6.0166572760472565,-7.388806285666803E-8,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark55(60.1954967028918,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark55(60.217367433588834,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark55(60.218408522822585,-0.2089305524899827,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark55(60.25509327790101,-0.7043066549521084,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark55(6.028552678070255,-1.1882154075002607,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark55(60.33457534346553,-1.2404997825860136,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark55(60.33548435233131,-2.4421944127512737E-5,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark55(6.034334695568873,-1.1075068112912274,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark55(60.359505097601414,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark55(60.37430927644368,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark55(60.382401951656306,-1.2235774340471295,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark55(-60.40445383217291,-1.000815776402345E-6,1.0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark55(60.43933341497376,-1.0183457691929902,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark55(60.487237002917425,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark55(60.53396440657569,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark55(60.53678838048958,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark55(60.56699830909673,-0.7296881262378836,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark55(60.56925285306042,-0.00636070330380023,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark55(60.59083229302016,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark55(60.60244201568785,-0.8996707225676781,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark55(6.061021420394435,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark55(60.64795440125255,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark55(60.682034149205634,-1.3490733825802863,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark55(60.70156604423634,-0.2487857390628676,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark55(60.706210957987565,-0.3291927038961938,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark55(60.73269550927728,-1.3023050161937029,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark55(60.73441504199499,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark55(60.757055093761636,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark55(60.763169929697625,-0.8556630317011189,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark55(60.78479440988619,-0.32688476161562363,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark55(60.79524860655795,-0.34660225980238124,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark55(60.83481589980748,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark55(60.85362959618295,-0.1928463561376858,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark55(6.089169459879855,-1.3832265874626652,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark55(60.92120887936143,-0.2284387391753171,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark55(60.945235755390854,-1.2627001311444195,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark55(60.96297314118406,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark55(61.03303682256235,-8.680161378992954E-7,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark55(61.068401393943645,-0.751428675878838,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark55(-61.17461619495393,-4.989600042565304E-10,1.0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark55(61.23418440440324,-1.2097729659990648,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark55(61.23808794780254,-0.8142861975815556,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark55(61.25520210099439,-1.6199101608305275E-9,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark55(61.26714453659364,-0.9960416704011017,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark55(61.26918971999592,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark55(61.27928319776845,-1.147031980005167,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark55(61.29999739644682,-0.34206941296528726,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark55(61.305743110181766,-0.6461177887754594,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark55(61.41067187984016,-0.20871389074478752,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark55(6.141671105540695,-0.9092063539419426,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark55(61.47883944022269,-0.034163633749773284,0 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark55(61.524727280830305,-0.10845956366729037,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark55(6.155551002342307,-1.2221102621321762,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark55(61.62416088719277,-0.9517525133552032,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark55(61.67890307366511,-0.28468413827911065,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark55(61.69651853047512,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark55(61.71552070932494,-7.671092195907097E-16,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark55(61.82884694208764,-0.29319020050271494,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark55(61.837544101738615,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark55(61.84898147093813,-0.7881541208274543,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark55(61.86422972313807,-0.43971376893172726,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark55(61.90433181010515,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark55(61.916614852406354,-1.3242582292883611,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark55(6.194830131154646,-0.9156068094052615,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark55(61.980405705143454,-0.8589810896745731,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark55(61.997234356162274,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark55(62.01916569264278,-1.4999999907996806,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark55(62.068780018160254,-0.30672315796225824,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark55(62.090855799780144,-1.3618111289599213,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark55(62.09657970734895,-0.8188180272819929,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark55(62.09717349529157,-1.063098576455257,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark55(62.10697344620047,-1.3192233636491153,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark55(62.11422740399577,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark55(62.13086777889861,-0.09212737381301617,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark55(62.1344101147819,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark55(6.214189342183005,-0.16367746132037908,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark55(6.217643622955265,-1.3832648778168561,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark55(62.27774087307753,-1.1301967067238579,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark55(62.32353861560005,-0.5282671403562271,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark55(62.32735219790001,-0.1450337325450164,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark55(62.348507863900565,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark55(62.3674891480012,-0.7291078287691352,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark55(62.44591666426944,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark55(62.448861532885815,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark55(62.45139475254166,-0.6580105383846613,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark55(62.49858592919725,-1.0716602989400315,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark55(62.50715461023276,-0.7861259172240267,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark55(62.51128564783252,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark55(62.51135093229243,-0.1606145579263174,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark55(62.522257736927,-0.6203478162869231,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark55(62.52880699076874,-0.7651902004312091,0 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark55(62.53593856106781,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark55(62.610028686443144,-1.3293901549476193,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark55(62.655789191794184,-0.19880500463423434,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark55(62.65959619335618,-1.385017913943683,0 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark55(6.268745899043481,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark55(62.70243356503695,-4.616325389174844E-9,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark55(62.74591622567473,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark55(62.783224471903985,-1.4006267909862973,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark55(62.802633426910006,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark55(62.80416247967373,-1.2257272816264033,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark55(6.280945533199159,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark55(62.81793533160018,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark55(62.826559078039054,-0.5560381253980795,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark55(62.91896831037522,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark55(62.97622102595585,-0.6385587383868132,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark55(62.98212658027474,-0.4334976520463476,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark55(63.00591622759756,-1.4999999999705038,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark55(63.03525944446881,-1.1071000800511106,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark55(6.306216678791525,-0.4332357574147445,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark55(63.08489443368137,-0.1744756020874506,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark55(63.09371231452396,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark55(63.11238176882843,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark55(63.14846297176192,-0.5684617765892037,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark55(63.15174290563007,-0.5454000362254732,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark55(6.318966457262714,-8.261515722850807E-7,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark55(63.20465408950284,-0.3637393142677183,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark55(63.26405986224259,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark55(63.28977977590482,-0.9596869507785755,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark55(63.301301489149154,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark55(6.33036553451144,-4.818455622817439E-7,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark55(63.33125624076078,-1.270638281725534,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark55(63.34014793980376,-1.4291023598697596,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark55(63.34663552398638,-5.948921726799645E-4,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark55(63.349287501595995,-1.0518146695480013,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark55(63.35269204581296,-1.1891926766748986,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark55(63.41194506285984,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark55(63.433388222624885,-0.9180941884725096,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark55(63.45597169838095,-0.99118792735986,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark55(63.475310458759466,-0.048789932234663436,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark55(63.55830122592613,-0.7750652310435393,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark55(63.59098206399685,-0.11419675457482814,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark55(63.59228446976567,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark55(63.599683879947385,-1.1823715654192923,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark55(63.607593016904815,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark55(63.646781766179515,-1.1545518567918478,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark55(63.65709957107586,-1.1756858151179659,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark55(63.669346070688846,-0.8102412957935348,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark55(63.677603327002146,-0.3232446731802564,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark55(63.694533449707066,-0.39672026848494557,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark55(63.76294984135106,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark55(6.376752440268007,-0.7496058062243112,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark55(6.377674552504416,-0.8582181078811573,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark55(63.78140816646419,-0.31005312787144657,0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark55(63.80572485266114,-0.8133860296389348,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark55(63.83443714173225,-0.6037523838303862,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark55(6.3888154262969366,-7.284863842621519E-5,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark55(63.91093895102361,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark55(63.9130247393021,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark55(63.96067478179852,-3.841671592783763E-8,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark55(63.975388654889855,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark55(64.0428987532806,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark55(64.04955802654362,-1.2060431925772406,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark55(64.07014824962653,-0.4243315684423946,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark55(64.07086873119059,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark55(64.08315128552027,-0.5129381199469663,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark55(64.08864573126657,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark55(64.12238526154752,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark55(64.12299207424155,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark55(64.12307591773745,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark55(64.14572560909623,-0.13812335582340296,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark55(6.415949797420367,-0.23886743147575173,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark55(6.417609945482887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark55(6.421387223813895,-0.1517789186969054,0 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark55(64.22284506426222,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark55(64.27907306775478,-0.13270204460086443,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark55(64.31836579558134,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark55(64.33664080932839,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark55(64.40062299604793,-0.21538440622199362,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark55(64.41005479912369,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark55(64.41078212235348,-0.05118397220276005,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark55(64.44154680363697,-0.8323644304081909,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark55(64.45167705664721,-0.16440505938219907,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark55(64.45531771922367,-0.45367951668676376,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark55(64.4599555672651,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark55(64.4630619715069,-1.0426412929497104,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark55(64.46822984683772,-1.3743251577147637,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark55(64.47515398092025,-0.09868251481889434,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark55(64.48422676519621,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark55(64.51766538855114,-0.722635457190326,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark55(64.54667800158191,-0.15650667448924738,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark55(6.455225815361672,-0.694962350156004,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark55(6.457133476846195,-0.47014235873562527,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark55(64.5727137599026,-0.9986503633538888,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark55(64.5812748561267,-1.4752447363471362,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark55(64.62968799457707,-0.9959383040278365,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark55(64.65903694878222,-0.07884189963947108,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark55(64.67617994748882,-5.622568656485509E-9,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark55(64.7352439488771,-1.3554538997198866,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark55(64.80168871983446,-0.053549816638484904,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark55(64.80238613145838,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark55(64.80490500795582,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark55(64.81280250664759,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark55(6.482121879780124,-0.6764536301306663,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark55(64.83702642004371,-0.7818495861179103,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark55(64.854389180759,-1.1071596917446516,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark55(64.88011709030155,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark55(64.8810080030427,-0.6008611934852468,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark55(64.88501441431671,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark55(64.8994160347697,-0.028537169815663274,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark55(64.93405952041545,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark55(64.9527132581591,18.153184700648623,22.035418949246093 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark55(64.95574424599414,-0.2773833029378751,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark55(65.01935124582366,-0.9321357970397468,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark55(65.09388581295457,-0.9356680910955388,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark55(65.1477101821622,-0.4202761090957381,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark55(65.15176665856612,-1.4986683467152329,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark55(65.17473501244297,-0.49840043676998214,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark55(65.24947761365004,-1.22725585853685,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark55(65.25060091092641,-0.8234529738152361,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark55(65.35961767489675,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark55(65.37187699952653,-0.6779481401468788,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark55(65.38088692366287,-0.3334682035668811,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark55(65.41058090540953,-0.23499893377250158,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark55(65.43731130550279,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark55(-65.43879439437521,-0.4203107850671719,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark55(6.5466102392416055,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark55(65.47938697315561,-0.5991645909273198,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark55(65.50880912909815,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark55(65.56319366281366,-1.0826042829004905,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark55(65.58799315667619,-1.2695798454596805,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark55(6.559296588470701,-1.269254196179452,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark55(65.61165715762323,-0.44400359300024395,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark55(65.62609521776326,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark55(65.63133676925594,-1.1932553199619584,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark55(65.63703541927957,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark55(65.6386253734333,-4.862254333944266E-7,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark55(65.66844626594273,-0.4575571947659487,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark55(65.67523002550485,-1.4558101858862351,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark55(65.67606923556924,-2.2387667809672013E-8,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark55(65.67733033388393,-0.35551225267926556,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark55(65.71334158771708,-0.1954593604575856,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark55(65.76267909909086,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark55(-65.77405733572593,-0.4029143019644453,-63.55403299168207 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark55(65.78108285329002,-0.7893756092942903,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark55(65.83005990606523,-0.6244120422642432,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark55(65.84176109569378,-0.4317236856851965,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark55(65.84804149820633,-1.4588441052938892,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark55(65.86235282812879,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark55(65.87284311290541,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark55(65.90364140458519,-0.47650216686016655,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark55(65.91970447516744,-0.0030845402306818315,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark55(65.94039177508618,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark55(65.94411888384428,-0.5526086169102999,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark55(65.97847490923155,-51.15719479061938,-28.008096628891437 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark55(65.99061090474851,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark55(65.99303799084528,-0.9649193305625645,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark55(65.99309528346535,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark55(66.03504552195,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark55(66.05281564516551,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark55(6.6063398424418835,-0.8129525299928808,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark55(-66.09914808484366,-0.5606257420946696,-7.664796619363868 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark55(66.11785734646219,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark55(6.6174449004242214E-24,-0.9707131176075328,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark55(66.18834555727537,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark55(66.19000993432502,-7.393623621469557E-8,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark55(66.20555912972782,-0.5208796031537242,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark55(66.22617913636046,-0.37723427883858635,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark55(66.24837033610541,-0.2205138968309151,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark55(66.26746322402906,-1.4254951214662877,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark55(66.29001410129533,-0.26522098055826887,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark55(66.30850932580947,-0.10196432241947515,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark55(66.33210230706933,-0.6342308047029235,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark55(66.33457663545053,-0.07193304602677486,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark55(66.35254728643594,-0.1521393998194824,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark55(66.35963145554487,-1.4999999999998757,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark55(6.636344819756658,-0.9214725032480544,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark55(66.39917342077993,-1.16543729135171E-8,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark55(66.406716699594,-0.8680186218066268,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark55(66.44080391184349,-1.2789085269768492,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark55(66.4528358633514,-0.6673495194332482,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark55(66.47569933421948,-1.011814557121454,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark55(66.48332810026247,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark55(66.51653831745173,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark55(66.52491984643495,-0.9568125744072722,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark55(66.55245667887493,-0.22429136373114655,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark55(66.55804176462723,-1.0434987313715716,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark55(66.56840883290201,-4.155077079333173E-16,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark55(6.661287022499238,-0.8136226900371923,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark55(66.68249516798807,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark55(66.68362836001702,-1.3881618308508805,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark55(66.74486535571157,-0.48938178566124035,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark55(66.76059688258931,-0.9538364008643967,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark55(66.77122784797888,-0.2738182371881961,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark55(66.82004883144165,-1.352827437786818,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark55(66.8286681948594,-0.27393353909227924,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark55(66.87671054970203,-0.7626740693308802,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark55(66.8965998544916,-0.26121683498732473,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark55(-66.93286828516256,-1.4999999252980276,1.0000000000001903 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark55(6.695392528956148,-1.0001146284503961,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark55(6.6960588170705595,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark55(66.96369918233336,-1.3071325570092256,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark55(66.96576006833357,-0.5943142339395866,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark55(66.97629624857205,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark55(67.00302135950758,-1.1511221409123493,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark55(67.01033791197929,-0.12074565567408635,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark55(67.01581690642135,-0.14068762821760783,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark55(-67.02552219869787,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark55(67.09178348067559,-0.5533059614566342,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark55(67.11167799897112,-0.32529587554737804,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark55(6.712059634857965,-0.4933840322439911,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark55(67.14088437138125,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark55(67.18759686630952,-0.7470164210754069,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark55(67.21203613856366,-0.19786549271581677,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark55(6.722984309812133E-9,-0.4352861877165819,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark55(67.28450887775554,-1.3880255201121088,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark55(67.34831103421163,-1.464898156928478,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark55(67.3549723195712,-0.981775861167443,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark55(-67.38135358933252,-0.08469896976169364,8.881784197001252E-16 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark55(67.38840024066613,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark55(67.3956513969709,-8.254103615240936E-7,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark55(67.4286374168058,-0.3265007307413441,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark55(67.43966732172234,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark55(67.45778416775815,-0.564744119578565,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark55(-67.4640131741628,-0.7426535896779727,0.685562719921214 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark55(67.5007042008514,-0.2077273164985689,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark55(67.51094495225239,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark55(67.54857921907592,-0.21254609844886987,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark55(67.55157192536808,-0.4310979865093394,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark55(67.69787422422365,-0.0306997401881407,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark55(67.69868227851305,-0.5203048216468584,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark55(67.75797216618908,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark55(67.78262966837141,-0.6876691802324473,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark55(6.782287221606055,-1.3720928213273282,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark55(67.85878439892305,-1.4999999986967358,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark55(67.86356157569173,-0.6580104775898517,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark55(67.88291136472611,-1.423188297759026,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark55(67.93620199577312,-0.7925849754095997,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark55(67.95586380533521,-0.8259902933969556,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark55(67.977839862732,-0.013977121966405992,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark55(67.98837411396337,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark55(68.04107660209492,-0.7065841172192764,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark55(68.08143505417831,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark55(68.09120207969374,-0.2945546983328855,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark55(6.809363172078628,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark55(68.09476469543046,-1.1449618210565227,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark55(6.810236637725618,-0.7630051023470941,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark55(68.10511195156039,-1.4815932869269504,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark55(68.11178445408095,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark55(68.14307722029415,-0.1035334841285902,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark55(68.15439370852937,-1.1588816329526104,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark55(68.1607206846475,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark55(68.19097918114893,-0.5481189422978234,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark55(68.20371780315955,-1.328468343703545,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark55(68.23502166096628,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark55(68.2627171191217,-1.4494620847169575,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark55(68.28538925837165,-1.3216530434440443,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark55(68.29306248347724,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark55(68.31234880482344,-0.05974888687699309,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark55(68.33066733666567,-0.8374377986393009,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark55(68.41475133820279,-1.4044897696948513,0 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark55(68.44519554785128,-0.28454016881669464,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark55(68.45690812198521,-0.6746767521332373,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark55(68.47591479140587,-0.06946745546831323,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark55(68.5041604895668,-0.643572444220041,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark55(68.50596347318529,-1.2366579890522251,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark55(6.850663317566336,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark55(68.54028059275595,-1.2161948277890309,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark55(68.56443430563101,-0.7423823228920128,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark55(68.58207615730434,-1.4992684139746406,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark55(6.859359512682002,-0.4371513683604178,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark55(68.60132130978297,-0.6969118500300815,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark55(68.60440168119507,-0.6478754542573384,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark55(68.61375526538487,-1.3189688528012766,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark55(68.62999123462345,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark55(68.68749803651937,-1.095925573474517,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark55(68.74042271184194,-1.2830648625869145,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark55(68.74457037707485,-1.0539200618927533,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark55(68.74914103502567,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark55(68.74924051956745,-0.2751150748647011,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark55(68.75360697714444,-1.428929488131364,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark55(68.80220242368097,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark55(68.81291671036348,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark55(68.81614231096464,-0.8228810169374694,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark55(68.85535575871097,-1.355659621626196,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark55(68.85571130700043,-0.06854912588154696,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark55(68.85903688775272,-1.2290140418574115E-15,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark55(68.87365076756555,-0.6827282738001497,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark55(68.87431557679514,-1.4836640683539093,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark55(68.88046461928673,-0.9045819748269928,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark55(68.9646528191106,-0.31319509681449287,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark55(68.96905176194389,-1.345593028232086,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark55(68.97077342435983,-1.3075243771303473,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark55(68.97252609175575,-1.222204590635819,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark55(6.900493866131427,-0.029330128330732546,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark55(69.03207537508652,-0.0071991522762335815,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark55(69.06555535352763,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark55(69.08109243335285,-1.3660856658691927,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark55(-69.10574946484327,-0.07497819789226301,0.3652618658069422 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark55(69.12411164806815,-0.8139747427377353,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark55(69.1294656009567,-5.634775884935833E-7,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark55(69.1966770559035,-1.480379699873211,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark55(69.23639774616501,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark55(69.25106953664738,-0.24592386694806725,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark55(69.25387865572281,-0.4625049107660004,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark55(69.30536828807872,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark55(69.31820841969818,-0.4277780283521895,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark55(69.32556516707345,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark55(69.37462920806813,-0.1500477349595184,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark55(69.38157191195069,-1.1042412453611217,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark55(69.38539164646821,-0.13177810003421234,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark55(6.938893903907228E-18,-0.007782130681326634,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark55(6.938893903907228E-18,-0.052266916776439194,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark55(69.41386578577172,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark55(69.42060905865176,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark55(69.42343942600435,-0.7897422678779122,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark55(69.47729528847512,-1.2588733248186372,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark55(69.47803959744832,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark55(69.48210187619244,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark55(6.949940785241944,-0.23795274307059344,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark55(69.5167760862942,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark55(69.52939208993372,-1.3030534572176808,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark55(69.53903293505654,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark55(69.54232518886266,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark55(69.59254554817475,-0.022918338412920916,0 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark55(69.59650209711427,-1.153971647944303,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark55(69.60108564952557,-0.20382288372324187,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark55(69.63106060348667,-0.33497819807149654,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark55(69.66839223699625,-0.4735503498570779,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark55(69.67916969447941,-0.7548620534335129,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark55(69.68851950722191,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark55(69.69725157907101,-1.5538033772321921E-7,0 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark55(69.704240982442,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark55(69.72272000101452,-1.2997837019592418,0 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark55(69.79001701279469,-1.3294135091506547,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark55(69.83881037395011,-1.0927727063542036,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark55(69.84950312102333,-1.3729109146802418,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark55(69.86402656675153,-1.2345296476581513,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark55(69.8836763460489,-0.47128820787844283,0 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark55(69.90118883249049,-0.09515895297013716,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark55(69.95999819731989,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark55(69.99051503610647,-0.5470413767456361,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark55(70.02606980157951,-0.15032241492402293,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark55(70.02824364575241,-0.46403347647956394,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark55(70.03696560831219,-1.4999999999997478,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark55(70.03696741896282,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark55(70.04425984527226,-0.4884076713229624,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark55(70.06986868024211,-1.0312056046395384,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark55(7.007421600926818,-1.255206612583052,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark55(70.11723984946515,-4.1854065723343626E-9,0 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark55(70.13611449639342,-1.3922053976999536,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark55(70.14788150786777,-0.018459360041099604,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark55(70.1823935644451,-0.5619251882508836,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark55(70.19785196723726,-0.7355694527248602,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark55(70.24060038425364,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark55(70.24218655242538,-0.493312235561858,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark55(70.27867817223202,-0.08025844291582307,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark55(70.29444754005831,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark55(70.32457615262376,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark55(7.034772006926429,-0.8100705213492141,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark55(-70.3484785162148,-1.4999999235252768,-0.8958466472165366 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark55(70.3823228569264,-4.509845166910998E-10,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark55(70.42510814237198,-1.4758566572475922,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark55(70.44997908702376,-1.2085590412601044,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark55(70.46972728986262,-1.022983164072853,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark55(70.48011928272578,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark55(70.49532545341498,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark55(7.0519107645178565,-1.4820665409913838,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark55(70.53033376881295,-1.0244601805144653,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark55(70.53526320218572,-1.6674479790091463E-8,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark55(70.57737357422724,-1.4525496511902949,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark55(7.060795312384565,-0.44547386722652504,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark55(70.62687703041937,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark55(70.62915930723906,-1.4999999999999645,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark55(70.63736113166954,-0.6568432202336151,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark55(70.63891283860549,-1.166881959932056,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark55(70.6457574800983,-0.36234582069957333,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark55(70.67507556941044,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark55(70.6809128198739,-1.3772813113725562,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark55(70.70449997195563,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark55(7.073710200707865,-0.6896472987837825,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark55(70.73832527134829,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark55(70.74191246387775,-0.3854764409627246,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark55(70.75139599551089,-0.4335333980015004,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark55(70.75447131813769,-1.2581397195885564,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark55(70.76668101312438,-0.2076355224102311,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark55(70.77454750320976,-0.36585057159674816,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark55(70.7845674356096,-0.06033494420045238,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark55(70.81033209744623,-1.2487879286345924,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark55(7.081977497568204,-0.7259203089025759,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark55(7.082163016313335,-1.094209170386001E-5,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark55(70.82910106841888,-0.44272559213158647,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark55(70.8861320234742,-1.0507489823575793,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark55(70.89039747165509,-1.0343352757328041,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark55(70.89807148223073,-1.4153088225891342,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark55(70.9821616032213,-1.4999999999998455,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark55(70.99674111063285,-1.4999999999982285,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark55(71.01939941389358,-0.6247256999130215,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark55(71.0369231612801,-1.1654996918996403,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark55(7.105427357601002E-15,-0.5268237647712968,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark55(71.06831591274212,-0.5252075414100936,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark55(7.107317290567039,-1.172659305874924,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark55(71.08889023643636,-0.22054197249232638,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark55(71.09854778147516,-0.03153806801175785,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark55(71.10694308484179,-0.9187076648811967,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark55(71.10757670817372,-0.28067402474156644,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark55(7.110964682878137,-0.7759826596776577,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark55(71.1127426310579,-1.8445656017035336E-8,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark55(71.1234650267038,-0.6595767740480456,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark55(71.17375156316388,-0.4540336587112219,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark55(71.20400938458366,-1.1367469885722734,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark55(7.12168554495689,-1.4091093110758948,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark55(71.22795308802304,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark55(71.23286766517347,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark55(71.24168376173557,-85.66041707693905,12.888478724957466 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark55(-71.24722345401891,-2.220446049250313E-16,2335.4349061810562 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark55(71.28983975151607,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark55(-7.1297423286913695,-0.3785152157680298,0.5834845595264746 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark55(71.3191266954729,-1.0357584173307783,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark55(71.34083339270748,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark55(71.35180948100779,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark55(71.37841025932187,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark55(71.39958305291117,-1.2712491729863649,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark55(71.40969048890148,-1.0983822710191493,0 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark55(71.42164593580614,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark55(71.43237443219859,-1.499999999950008,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark55(71.44089042432645,-1.4131024117814595,0 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark55(71.44520432319862,-0.7045054531047956,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark55(71.4565339986482,-2.365422561656868E-4,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark55(71.50477769536013,-0.48620100756997964,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark55(-71.50855162670227,-1.4999999999999996,1.0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark55(-71.52116299911158,-0.32979280847707043,-1.0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark55(71.60502120493041,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark55(71.61569276175314,-0.4426705157871842,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark55(71.61702571861554,-1.1016145775821542,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark55(71.62265477783268,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark55(71.62887475294244,-1.3854021058227495,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark55(71.65562405658014,-1.3122819217210508,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark55(71.66593115059214,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark55(71.70301185900487,-1.1479542522201593,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark55(71.79768418452542,-1.3409988064926663,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark55(-71.80276277852761,-1.4999999999999964,1.0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark55(71.83709868719717,-0.836777089909162,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark55(71.8536799217359,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark55(71.86071851374558,-0.8600791602024849,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark55(71.8609382298043,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark55(71.87032874057437,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark55(71.87106125136552,-0.7273353075544442,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark55(71.90144848149347,-1.393323343703197,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark55(71.94253969492918,-0.8046672175725715,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark55(71.98078214094303,-1.0474136255038111,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark55(71.99266427013876,-0.42964569664184715,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark55(71.99514733651786,-1.303776162710938,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark55(72.02095268916212,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark55(72.08010857511081,-0.8623275488556517,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark55(72.09654269074898,-0.15321197992718671,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark55(72.15191717870803,-0.09194450089027262,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark55(72.17684137072203,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark55(7.224581238826062,-0.5441186991279636,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark55(-72.25238095007686,-0.55983839176883,55.54451707218586 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark55(72.25908208636582,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark55(72.27104454017038,-0.8541380331406772,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark55(72.27740218454426,-0.7800435260648477,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark55(7.228453157721489,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark55(72.31481000362332,-9.847930237864751E-9,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark55(72.33787006285255,-0.7184472556469359,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark55(7.2361083878783745,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark55(72.36336593588801,-1.1356173615419742,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark55(72.37735703620822,-0.8034810336091471,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark55(72.37997104669867,-0.24914327409397086,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark55(72.39782425204936,-0.08205953160288154,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark55(72.42912455703538,-0.07296065336168112,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark55(72.46157150153502,-1.4882247344737305,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark55(-72.48487892265135,-4.260001853090895E-4,-1.0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark55(72.49191115468176,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark55(72.49842686222279,-1.4984157030200258,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark55(7.24991960373562,-0.26367602683483793,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark55(72.5314823377081,-0.5555899569462763,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark55(72.5341714689566,-0.620314488399984,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark55(7.2541243207734425,-0.14176000246688147,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark55(72.56897479234223,-0.2729356058965635,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark55(72.58531143106329,-6.299716384521065E-10,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark55(72.5875109074228,-0.18831318283552712,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark55(72.60296173785353,-1.3301469839521773,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark55(72.61257153170902,-0.7141627630250008,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark55(72.68543735144806,-0.11194550060275787,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark55(7.270220167567878,-0.488978770634811,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark55(72.72063104371645,-0.14847312013368885,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark55(72.76718798745704,-0.19238590026541136,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark55(72.7677625830504,-1.463536402788506,0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark55(72.77185875444815,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark55(72.78519416333879,-1.499999999999769,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark55(72.79991958074362,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark55(72.90731685537511,-0.16964799724465252,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark55(72.92546265033855,-1.2065427157979036E-6,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark55(72.93231633123237,-0.8257443524450065,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark55(72.93447773632245,-0.6509942029421014,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark55(73.06097503484045,-0.6534077547698018,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark55(73.06540152603488,-1.1318829453263106,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark55(73.17459593582797,-0.6691823029772461,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark55(73.17800432300913,-0.979062146399091,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark55(7.326115635665374,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark55(73.30517960289461,-1.2655624945052268,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark55(73.32859189154121,-0.35456122339919993,0 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark55(73.34546141151856,-0.4329323979887789,0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark55(73.37988463673008,-1.2753108444460253,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark55(73.3839583044944,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark55(73.40053885429619,-1.4408901320957535,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark55(73.40840207981287,-0.025814785543303742,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark55(73.40961682694663,-0.023665799434510026,0 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark55(73.45852869332586,-0.3669385305013577,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark55(73.4640430960473,-1.202416558533855,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark55(7.347000432361966,-0.722777532019989,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark55(73.52906855563663,-0.5534417617925698,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark55(73.64711243767115,-0.024854837603328052,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark55(73.65342628481895,-0.3947004348252736,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark55(7.36604024900182,-1.4999999698846918,0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark55(7.367196208999501,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark55(73.68801758244004,-1.2848707414983522,0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark55(73.70766650599799,-0.6416520026245092,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark55(73.74350019873093,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark55(73.76761900283432,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark55(73.80956135884428,-0.29381169531634865,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark55(7.382767690243668,-0.4047971537623325,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark55(73.84733918177778,-0.5466310406672505,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark55(73.86599203489797,-0.5950441826164283,0 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark55(7.390387737338086,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark55(7.391727973447868,-1.4597247722762374,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark55(73.96445574184827,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark55(73.97084055308318,-1.4568029289631914,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark55(73.97474878575326,-1.122249108660872,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark55(74.07999070481702,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark55(74.12528357402823,-0.5445499813398413,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark55(74.21714786113502,-1.2462368689358951,0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark55(74.22220119504729,-1.0279542782582212,0 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark55(74.23078355223137,-0.07884536619329846,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark55(74.24098898976962,-1.026129437817218,0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark55(74.24151817811855,-0.1349081382701954,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark55(7.429934702221001,-0.1997087323637982,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark55(7.432650692397829,-0.7780854023895456,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark55(74.3355324524479,-1.2411778352090295,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark55(74.34120923125877,-0.21230621560603913,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark55(74.34222273002985,-0.025605886827971602,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark55(74.35990223204118,-1.367684656475078,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark55(74.42716099515643,-0.26274359863720576,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark55(74.46642847087847,-1.4999999999999254,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark55(74.52669033862699,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark55(74.52849841455955,-0.0342590523316062,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark55(74.53152475603157,-0.057952423004824505,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark55(74.55060595748002,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark55(74.56385735999257,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark55(74.56823964141775,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark55(74.59567497982587,-0.8587848725215643,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark55(74.60716717146562,-0.5103344538746857,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark55(74.64432742844727,-0.33001209579413365,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark55(74.67568938826224,-1.0137646076900708,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark55(74.70932590974863,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark55(74.72098447745194,-1.2257795487005296,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark55(74.72972973007657,-1.4094895578378663,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark55(7.473844331550822,-0.05552666094482106,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark55(74.78228966995714,-9.671498433826513E-9,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark55(74.85982500400107,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark55(74.90720246034363,-1.0145999498096208,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark55(74.93434594327132,-0.01712439411928871,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark55(-74.9796375281145,-0.23798480513429854,3.552713678800501E-15 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark55(75.00569875052506,-0.014229002791227074,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark55(75.00702218119788,-0.8767693011789652,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark55(7.502779238596155,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark55(75.03528211245337,-1.325524544059201,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark55(75.06502748480852,-1.0767921376266294,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark55(75.07624776372558,-0.6836586994590501,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark55(75.11083874094362,-0.4940269692619941,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark55(75.12526530554655,-0.3811724102762355,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark55(7.514389744843442,-0.1870949120604144,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark55(7.5153190555405525,-0.02217528312781969,0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark55(75.1679122429845,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark55(75.20896256463496,-1.3592747535985126,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark55(75.2124948541097,-0.6291093713423446,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark55(75.21659399071831,-0.26905720135332456,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark55(75.25757507259624,-1.48849044681252,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark55(75.2584053573658,-0.18715397157026104,0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark55(75.27199348748351,-0.1553830156655387,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark55(7.527265269093661,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark55(7.528657944802241,-5.254374853938003E-17,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark55(75.32371181272595,-0.29049432089897387,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark55(75.35422083588946,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark55(75.36880336126868,-0.9670098705445809,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark55(75.37223998904622,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark55(75.38889636703857,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark55(7.544906371151332,-1.2542780458414917,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark55(7.547044268101644,-0.4796018833694884,0 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark55(75.47053711062776,-0.09383452401189807,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark55(75.50098260070574,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark55(75.51440340878493,-1.499999951590763,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark55(75.54031664183861,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark55(75.59986833046747,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark55(75.60547643858203,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark55(75.67484967274086,-0.008329092044545298,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark55(75.70284673569932,-0.8413755191315286,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark55(75.71221859323578,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark55(75.77013583442363,-0.3086443931127576,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark55(75.77847459781819,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark55(75.81316655419386,-0.7089344300818232,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark55(75.85290919958962,-0.7995073764370044,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark55(75.89902345359786,-0.5988089197863555,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark55(75.89950095992161,-0.4710691398005551,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark55(7.590866518884809,-0.018440973380396353,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark55(75.91530243470741,-7.70997870955771E-8,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark55(75.93271182623329,-1.1931019798957294,0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark55(75.94620382641322,-0.19813081479710148,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark55(75.957713985828,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark55(75.9606037549081,-1.2007674328468043,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark55(75.97437347402013,-0.5595653748453446,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark55(75.98512146670372,-4.4362510159232075E-9,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark55(7.608812169175394,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark55(76.15072369386915,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark55(76.15489724494631,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark55(7.6230182434833065,-1.10369621802608E-5,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark55(76.23363704806245,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark55(76.26081829456069,-0.11880219287802518,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark55(7.62671905334318,-1.0426329830583079,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark55(76.27848857722961,-1.4541302364680668,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark55(76.30395100603377,-1.351637937692542,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark55(76.34539470744983,-0.9413421677967002,0 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark55(76.34573611698315,-0.198507111339969,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark55(76.3609929324086,-1.188226737387648,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark55(76.38978317416931,-0.3648078851012837,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark55(76.40758421165461,-1.117105701959062,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark55(76.43314644896583,-1.3150193552168759,0 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark55(76.43528126778364,-0.5224710359060655,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark55(7.646653804601769,-1.3973987415835645,0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark55(7.647549732696703,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark55(76.47985601388612,-1.174869448545408,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark55(76.48327746586085,-0.3558504928956704,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark55(76.49007394186413,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark55(76.49449429381454,-0.6786116463732412,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark55(76.50794865831877,-1.4595673960004771,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark55(76.51221202004089,-0.4518492362419535,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark55(76.52327284920428,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark55(76.53844787103822,-0.5212841307941289,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark55(76.62469409719836,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark55(7.663020144699445,-1.1230423531878273,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark55(76.6411050135564,-0.7291767795080526,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark55(76.67188467953594,-0.1269288156436239,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark55(76.70443425646337,-0.8019392782337942,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark55(76.72637775892227,-0.05806885920002247,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark55(76.7561763790492,-0.12289866095702018,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark55(76.77853710941514,-0.22547131854977964,0 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark55(76.79575153894969,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark55(76.79636852633479,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark55(76.80459303824387,-0.022358965817232956,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark55(76.8209462801698,-0.3703668878737538,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark55(76.82519446812842,-1.2083981116911762,0 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark55(76.84446231045317,-0.5205335109946976,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark55(76.87956962772773,-0.6846180839717961,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark55(76.93208565484275,-0.9546034895317028,0 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark55(76.95120704765904,-1.21984386105835,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark55(77.01045946166417,-1.4251609493025605,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark55(77.02616704736252,-0.2542106720096804,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark55(77.08983284504535,-0.1569279409497284,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark55(77.09303382437051,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark55(77.14061367089363,-0.7144033224512327,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark55(77.16348709175719,-1.2238273838482434,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark55(77.21252965260759,-0.5234716690456882,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark55(77.25477799723598,-0.1881859010690896,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark55(77.27528430292529,-1.2573863630736355,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark55(77.29197957990223,-0.4503998549478183,0 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark55(77.32232910962333,-0.6930021224944305,0 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark55(77.34890951908423,-0.22768175515290845,0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark55(77.38022182406306,-0.9744365294669171,0 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark55(77.39199719125638,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark55(77.39851278834598,-0.10167023316050283,0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark55(77.40738576718036,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark55(77.42328194793325,-0.4046462801730675,0 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark55(77.42717212987807,-0.1060800984257213,0 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark55(77.43902997455105,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark55(77.47635894016011,-0.673282897850541,0 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark55(77.49014577668497,-0.6828458399674046,0 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark55(77.49258632447237,-0.8701957261223974,0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark55(77.56410654085204,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark55(77.57444411482362,-0.04054301644883089,0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark55(77.59376463661388,-0.01791595327318396,0 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark55(7.760946263879802,-0.0016205039947010391,0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark55(77.6438954069821,-0.8940852320537669,0 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark55(77.66583597026612,-1.2632509186671162E-15,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark55(-77.7529672699555,-0.9921593854663087,40.01368052644523 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark55(77.75399876911115,-0.47815842417375176,0 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark55(77.77329635234224,-0.8177817817903232,0 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark55(7.779515517995634,-0.5024462448446663,0 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark55(77.83025695769976,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark55(77.85580002783142,-0.4274603603665099,0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark55(77.90325572833035,-0.1015468737108165,0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark55(77.95732206648532,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark55(77.96234507825571,-0.44045804336559513,0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark55(77.98766401939733,-1.1428175431405236,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark55(78.00229209088684,-0.2054328614996166,0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark55(78.00793265652973,-9.245499541484094E-8,0 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark55(78.08577004794677,-1.499999999999977,0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark55(78.13684560551161,-0.4247131324386544,0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark55(78.1469923220272,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark55(78.15906231724861,-0.25929083833599265,0 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark55(78.16663837401403,-1.36051315511395E-6,0 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark55(78.1720590154599,-0.25894377253332723,0 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark55(78.17581054618782,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark55(78.18447396046065,-0.1156547678813789,0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark55(78.20027953976896,-0.06272356778213894,0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark55(78.21494317639929,-1.499999999999996,0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark55(78.26426626603993,-1.0394694153551782,0 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark55(78.2766987884001,-1.464920090689759,0 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark55(78.27917605013147,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark55(78.28343141518852,-0.6656771798073855,0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark55(78.29528805129718,-1.240727553795156,0 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark55(78.31323397820934,-1.4999999946738718,0 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark55(-7.833036017582586,-1.031849026417774,-1.9742063534922827E-177 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark55(78.42753233955943,-0.23267968142819484,0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark55(78.45859065239608,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark55(78.46852191566362,-1.4864400209819353,0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark55(78.51273432572981,-1.453471940456799,0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark55(7.852456209371937,-1.1203074751654472,0 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark55(78.53606814489783,-0.23842942602483674,0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark55(78.55932174970076,-1.3325543077676008,0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark55(78.57664288686811,-0.5852279681331112,0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark55(7.860195558696054,-0.10639725963097169,0 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark55(78.6114263081265,-1.4622647234192123,0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark55(-78.61439446329001,-0.03627606694623557,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark55(78.75286173474113,-0.09800279255121325,0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark55(78.85984122094239,-0.7504144410263773,0 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark55(78.87399867568885,-0.8457227626234349,0 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark55(78.89540017064515,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark55(78.92362371867992,-0.5171690344338176,0 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark55(78.93458648888597,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark55(78.9641595893959,-0.461589781766957,0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark55(78.98439928842643,-0.6429334951519139,0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark55(79.01153349683761,-0.27314880479349,0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark55(79.01738422348198,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark55(79.03654260711815,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark55(79.0679640808323,-1.3853201690317292,0 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark55(79.0770570427932,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark55(79.11171879043096,-0.7708460819517384,0 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark55(79.15703024071857,-1.06004804254641,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark55(79.17670339152014,-0.9659309034884282,0 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark55(79.20033726789498,-0.74642030954071,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark55(79.21156442506307,-1.2352385167457447,0 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark55(-79.26853971773286,-0.626259439608678,1.0 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark55(7.927511467225628,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark55(79.33591661613798,-1.0469362098210553,0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark55(7.934399392521197,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark55(79.39752956153049,-0.32451295090295823,0 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark55(79.51670151344803,-1.3199396605644087,0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark55(7.952330746911642,-0.8067593525125147,0 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark55(7.952917646565499,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark55(79.55648709799807,-1.3539388146094495,0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark55(79.5811462105797,-1.4554372381275633,0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark55(79.58980704836029,-1.189045343862623,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark55(79.62466648067894,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark55(79.63359783146456,-0.8347464529655895,0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark55(79.67694179226274,-0.3094955312952934,0 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark55(79.6930678712389,-0.8199283045746313,0 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark55(79.71798939101006,-0.5363023990545059,0 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark55(79.82297539189486,-0.48241627860845426,0 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark55(79.88165468460411,-0.4563066885909728,0 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark55(79.89540595422005,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark55(7.991156146143737,-1.1633017551045697,0 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark55(79.91167766281508,-8.706231627147733E-8,0 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark55(79.96067711121034,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark55(79.9615265060688,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark55(79.96406935920973,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark55(79.97221652966275,-0.8381274518651883,0 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark55(79.99544075615606,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark55(80.01286765955697,-0.08436950466716775,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark55(80.02510647232822,-0.128064722078701,0 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark55(8.00440137033516,-0.3655572831791858,0 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark55(80.04527444975952,-0.045641706649124175,0 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark55(80.0888647373331,-1.4999999999999005,0 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark55(80.10619893508263,-0.4936741784614981,0 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark55(80.140911050097,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark55(80.1513279411511,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark55(80.16360366413059,-0.22639803043891504,0 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark55(80.17017791366537,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark55(80.17336146336842,-6.064059860044079E-8,0 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark55(80.17923051684652,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark55(80.255590516666,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark55(8.026349324019705,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark55(8.027440190663462,-0.5750736295966912,0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark55(80.34969698515144,-0.2498807576141484,0 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark55(80.38712125847144,-0.3969685262487346,0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark55(80.38823851694903,-5.691379357435678E-10,0 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark55(80.42635796960403,-0.5046508717234843,0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark55(80.43855600257449,-0.8566290100405625,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark55(80.45907434267743,-1.2252498574439818,0 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark55(80.54806901485603,-0.43203460660933635,0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark55(80.54887725176152,-0.9665507597546479,0 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark55(80.55854982774991,-0.6253343661774302,0 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark55(80.56634612458811,-1.3035465095096292,0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark55(80.57182245492474,-0.03157181384151431,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark55(80.58945425120154,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark55(8.060245039294074,-1.464886444225868,0 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark55(80.64824615343679,-1.169403600350881,0 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark55(80.65682148562041,-1.2791973634532021,0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark55(80.66724924855092,-0.0729922621588397,0 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark55(80.67225694710473,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark55(8.067512603680864,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark55(80.68115060844502,-0.48514442899768984,0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark55(-80.6897204040765,-0.5874847271069029,1.0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark55(80.72143100158962,-1.2468611722251879,0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark55(-80.72568205633993,-0.3252966849485459,1.0 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark55(80.76037611750415,-0.12717278626498718,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark55(80.76173899213296,-1.323657681564761,0 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark55(80.7646520711356,-0.996344396349046,0 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark55(80.80944884232696,-0.2187050260847201,0 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark55(-80.82073155131395,-0.12494039317196197,-1.0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark55(80.8621349467656,-0.6747536947376975,0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark55(80.94314369184674,-0.08886625510704738,0 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark55(80.9599821286958,-1.4999999997525715,0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark55(80.96566792581132,-1.0350486530531307,0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark55(80.96737657384676,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark55(81.0038119622383,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark55(81.01598432898831,-0.3017262359932391,0 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark55(81.05547728976316,-0.05360617076753904,0 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark55(81.0589674919905,-1.279202971634137,0 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark55(81.13198997956101,-0.19223150585812954,0 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark55(81.14583176486386,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark55(81.14600510351636,-0.09344063999869645,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark55(81.1462691684871,-0.7371588569562109,0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark55(81.18265041275326,-0.4899358008580492,0 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark55(81.21313855165423,-0.5640596593818632,0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark55(81.26183120289994,-1.114873483868985,0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark55(81.27138915057236,-1.1324898754648212,0 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark55(81.27420429303,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark55(81.29183244226726,-0.5616577704616832,0 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark55(81.29826342892403,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark55(81.31432076804975,-1.432657883119326,0 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark55(81.32224220558408,-1.0491202751332414,0 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark55(8.13442883033005,-3.2264587229032217E-9,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark55(81.36574585266453,-0.9385974834105468,0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark55(81.3712036776841,-1.1815716285481574,0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark55(81.41329680739409,-1.262222231821429,0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark55(81.43989222484336,-0.8777470422888616,0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark55(81.44018269949515,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark55(81.51490651858416,-0.5521369229750637,0 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark55(81.5656711683512,-1.499999915064722,0 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark55(-81.607751705291,-1.4462756723879393,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark55(81.63893036180266,-0.5939816451011737,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark55(81.69916583238415,-0.9556570940350926,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark55(81.70603808222407,-0.02689219896087362,0 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark55(81.71330705233018,-1.0059102040275385,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark55(81.7274888546695,-1.0471679499277862,0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark55(8.175646096507876,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark55(81.75976256492882,-3.6671148413794233E-6,0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark55(81.77740438022711,-0.7939733299728551,0 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark55(81.79603739291653,-0.9105542827662222,0 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark55(81.83102240656932,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark55(8.186924405779992,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark55(81.8738843151328,-0.3739402043475786,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark55(81.89721294300924,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark55(81.91350404959415,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark55(81.92174565517473,-0.9169270371366591,0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark55(8.194365247260823,-0.4943977774070967,0 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark55(81.9490502293697,-0.6954032573470919,0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark55(81.95319753102648,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark55(81.95943493905071,-0.030702458688285028,0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark55(81.96524260145887,-0.07669941304284578,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark55(81.99155517032467,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark55(82.02369769322465,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark55(82.02869589956444,-0.7359771108958029,0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark55(82.08426991740231,-0.3765629027737418,0 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark55(82.08898013357503,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark55(8.214315581027902,-0.6506334252979827,0 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark55(82.16454509595474,-1.181377740447843,0 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark55(82.18319850322732,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark55(82.19198188806236,-8.194200835767735E-6,0 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark55(8.220351457204984,-0.6355849257879478,0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark55(82.20531270987658,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark55(82.2282251680461,-1.256169650180918,0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark55(82.24372375703915,-1.0252949194626173,0 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark55(82.25026679870226,-0.1477596733520521,0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark55(82.25424399588488,-0.6990679554409116,0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark55(82.27155587817188,-1.5994968842383733E-4,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark55(82.27794329771586,-0.40449664050808565,0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark55(82.28243194585959,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark55(82.30950632903941,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark55(82.31713953837007,-0.585736082177036,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark55(82.31836329711146,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark55(-82.36307581267735,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark55(82.3781188835024,-0.8263551765782173,0 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark55(82.39617473382663,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark55(82.4109326399896,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark55(82.41222811020819,-0.30823771366660313,0 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark55(8.241378742883441,-1.2387252036551606,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark55(82.48084167932475,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark55(82.48634823390043,-0.879273943241487,0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark55(82.50809573270828,-0.7509199543245695,0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark55(82.54820807370012,-0.02307434472300507,0 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark55(82.5833671979299,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark55(8.259575464963234,-1.4999999999999574,0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark55(82.60187576558737,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark55(82.60372956423794,-0.6573334671265219,0 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark55(82.63149976297669,-0.004587068177700139,0 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark55(82.6534849590083,-0.8748147167854032,0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark55(82.66447611895717,-1.2330752534103802,0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark55(82.66862861563155,-1.1591840243882847,0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark55(82.67649379138577,-1.3290675808291874,0 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark55(82.68832928135538,-0.8637496013214179,0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark55(8.278672618440083,-1.415229473882107,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark55(82.78909472747652,-1.3879233825876423,0 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark55(8.279920542968469,-1.4999999999999867,0 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark55(82.80331087898821,-1.0371623105648808,0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark55(82.82573579700592,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark55(82.83026879955612,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark55(82.83655006574881,-0.44827064574907394,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark55(8.285827508123802,-0.41049296954874137,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark55(82.90181620003774,-0.2499248643816392,0 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark55(83.08952717690494,-0.15433484223285132,0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark55(83.12726371455076,-1.266153271883951,0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark55(8.3137829232395,-1.4741596902172134,0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark55(83.1463818373424,-0.35760300918636645,0 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark55(83.16117969628837,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark55(83.1630349753114,-1.2058295947376507,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark55(83.16743980983975,-0.2834226719576811,0 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark55(-83.16843324147608,-1.4999999999999998,-1.7733952741316101 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark55(8.317575363598898,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark55(83.2563846019963,-0.8876562217771053,0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark55(83.29135231710318,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark55(8.342118633580741,-7.932779967709777E-9,0 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark55(83.42486479085106,-1.888100693311457E-9,0 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark55(83.42835489727759,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark55(8.345963135695417,-0.7997141577005316,0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark55(83.48470553561327,-0.35600202138032633,0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark55(83.48751307385086,-0.8891458745409202,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark55(83.4962349828512,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark55(83.62263282821081,-0.24755931129905862,0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark55(83.62318870773186,-0.3576322003959733,0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark55(83.66441797461363,-0.6189516892140707,0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark55(83.68145258561971,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark55(83.70897574795418,-0.8099754047420333,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark55(83.71171756335585,-0.9485674168218625,0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark55(83.73288188309306,-0.22492754623045652,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark55(83.73359071810705,-0.585396211205061,0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark55(83.81763274882968,-6.268354772363568E-9,0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark55(83.83032066447024,-1.3306435114544826,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark55(83.87751213338322,-1.3653156339101429,0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark55(83.96255894302632,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark55(84.00425681855904,-0.17315869757961044,0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark55(84.02968103150383,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark55(84.09352813822849,-0.29582746442218877,0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark55(84.10701022947876,-0.8411964750749519,0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark55(84.15914822806658,-0.40964270686864696,0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark55(-8.41701356505057,-0.23396894226499904,-1.0 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark55(84.18294553683539,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark55(-84.1927483588776,-0.3176368000516896,69.77478490348636 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark55(84.24183850304738,-0.28019509573719503,0 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark55(8.429914601663583,-4.62338163733188E-9,0 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark55(84.30991060993753,-0.0788811075112915,0 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark55(84.316825543415,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark55(84.34144076221958,-0.5813304118907512,0 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark55(84.34651167804736,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark55(84.35533064523345,-0.35914269011483,0 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark55(84.35886557589885,-1.2673751096266415,0 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark55(84.36622171519542,-0.5787266192383107,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark55(84.36770839533992,-0.6087415104505478,0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark55(84.40059368942056,-0.2413537951745055,0 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark55(84.40968869763466,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark55(84.4492944433502,-0.4846552892928915,0 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark55(84.47346791486595,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark55(84.48353703219007,-0.5401030931646744,0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark55(84.55466989195014,-0.7869626306557009,0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark55(84.5692078921592,-1.499999999999968,0 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark55(84.59637786393066,-0.39329374474132806,0 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark55(84.60229359163142,-1.2561736645851513,0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark55(84.61174125365255,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark55(84.63106593105766,-0.02217326307857581,0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark55(84.63766236817904,-1.4908743599724872,0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark55(84.66620029602939,-1.0529067540876582,0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark55(84.67817731243075,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark55(8.471455066797585,-0.009269820965997539,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark55(84.77373702153764,-0.10509956738759918,0 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark55(84.77800138714109,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark55(8.484220801166032,-0.9288132514814005,0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark55(84.85411377378605,-1.4231041133187663,0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark55(-84.87201444181352,-1.2721761081368754,-1.0 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark55(84.89752864556483,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark55(84.9007652533688,-0.2346374771995099,0 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark55(84.90908755292179,-0.7275942459638127,0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark55(84.96294554650964,-1.296092592445043,0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark55(84.97899206414084,-0.9023025716727906,0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark55(84.98795689241567,-0.05068274388379934,0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark55(84.99340893280495,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark55(8.5015303559111,-1.4077812356533013,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark55(85.02380635833768,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark55(85.0248756149557,-1.3029738172908698,0 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark55(85.04651597908742,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark55(85.04656848412324,-0.013273542455806364,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark55(85.06178758494237,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark55(85.09480976793307,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark55(85.12472438527138,-0.8223965315087378,0 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark55(85.2097880857482,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark55(85.2267764445107,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark55(85.23170770650103,-1.3683293365359788,0 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark55(85.23591160337342,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark55(8.523736159992808,-1.1563787934827587,0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark55(-8.525818289362107E-10,-1.31056833565359,1.0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark55(8.52679250913664,-0.8102589301681835,0 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark55(85.36100123256486,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark55(8.54162533013752,-1.4350198018329137,0 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark55(85.44207049404358,-0.0020323257493544133,0 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark55(8.547855379762773,-0.28673770329581005,0 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark55(8.549010956910294,-0.7164615162212229,0 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark55(85.53888033525999,-0.4571344386979046,0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark55(85.60570571563483,-0.7028259002079201,0 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark55(85.62555998884426,-1.4999999999532747,0 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark55(85.66519849950583,-0.13674073158258482,0 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark55(85.69232370344935,-0.67578161442888,0 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark55(85.70961241096127,-0.08205033150483543,0 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark55(-85.71543843504789,-1.0482018443546033,-0.9999999999352984 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark55(85.74453741814924,-0.45339637895229146,0 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark55(85.74916129403317,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark55(85.7555350413609,-0.23549644413007798,0 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark55(85.80307112595641,-1.1696567689070019,0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark55(85.85818332072434,-0.48304702862084437,0 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark55(85.86931574899671,-0.8689393417657243,0 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark55(85.8866096643138,-0.34796141518711465,0 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark55(8.589795800361173,-0.22385315049730226,0 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark55(85.92426633909209,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark55(85.97549137626106,-0.6992655318009624,0 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark55(85.98679202597744,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark55(86.0126712293067,-0.5266252521284982,0 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark55(86.04189195301518,-0.3165369143385277,0 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark55(8.605004939705646,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark55(86.05266838216934,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark55(86.06353238530933,-6.595805936252584E-9,0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark55(86.1806520684124,-1.3359567782592876,0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark55(86.23296369899793,-0.49672386573890037,0 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark55(86.27555110785397,-1.4249593666682898,0 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark55(86.29373446676277,-0.17330539833528924,0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark55(86.29871927754161,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark55(86.3155435457252,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark55(86.33309666636607,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark55(86.34023337721064,-0.23097974318095282,0 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark55(86.35834717398129,-0.9537018122578065,0 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark55(86.39477358130624,-0.6984398039146206,0 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark55(86.40289498752875,-1.4718185999051583,0 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark55(86.46402105462018,-1.4999996801211404,0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark55(86.49238971223716,-0.7335114278456913,0 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark55(86.49293273090242,-0.508759354856096,0 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark55(86.5001787219,-0.7024405392670873,0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark55(86.65795636217689,-1.3965250272687166,0 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark55(86.70246211251832,-1.4999698502771264,0 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark55(86.71668426073495,-1.2407328540471418,0 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark55(86.73426842947276,-1.0115221465010258,0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark55(8.673690589209656,-0.8461857814638671,0 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark55(8.675022599758778,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark55(86.78008971382653,-0.3984132023171014,0 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark55(86.7928013985298,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark55(86.80111503633707,-1.4843911257748241,0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark55(-8.683070996633067,-2.7755575615628914E-17,-0.9459974535389176 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark55(86.83528763797955,-0.09458834081260076,0 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark55(8.686083643400494,-9.25638153523767E-9,0 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark55(86.87583977180117,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark55(86.88971619072038,-1.3871458270577222,0 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark55(86.89524387745917,-0.2185610169738852,0 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark55(86.9068532516857,-1.788436503880703E-6,0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark55(86.94720397388834,-0.8772758079270404,0 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark55(86.96521672944147,-0.5494418601395737,0 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark55(8.697031805204617,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark55(86.97675165010438,-1.0320043056165034,0 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark55(86.98422543385846,-1.2663992560183317,0 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark55(86.99456935751365,-1.2064866147037492,0 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark55(87.06807463696927,-0.9811071867618715,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark55(87.10501992690652,-1.0973794475078051,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark55(87.13561565070768,-0.7046973326393144,0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark55(87.14405944647075,-0.3461767752957675,0 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark55(87.2216710476614,-1.2608396039398695,0 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark55(87.2305764176104,-1.1270239086524754,0 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark55(8.725997836266275,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark55(87.27788034261118,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark55(87.27803775340925,-0.9519887712818189,0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark55(-87.30074530042114,-5.2739726928801175E-9,0.9999999942956946 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark55(-87.32978606088406,-1.4950135475793744,-1.0000000000000002 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark55(87.43555867894844,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark55(87.45785367120067,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark55(87.46547877701084,-0.12310189878323863,0 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark55(87.46741339826411,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark55(87.4790971340712,-1.4194773205179836,0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark55(8.749474118811278,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark55(87.49692444149815,-0.5454018505681127,0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark55(87.5133887183737,-0.0870443347504164,0 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark55(87.5274597692401,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark55(87.58418133939333,-1.266926556408405,0 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark55(87.6004023494398,-0.03389456670615354,0 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark55(87.61424147189899,-0.5936815670240208,0 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark55(87.62227374625655,-0.7992265468308943,0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark55(87.66111704915306,-0.5711889325956463,0 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark55(8.766250248477377,-0.2555901423355711,0 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark55(87.6883673325341,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark55(8.772639221887015,-0.19775154906980008,0 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark55(87.75121278117882,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark55(87.76416523818557,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark55(8.778274662401643,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark55(87.8274055274187,-0.05991980069659064,0 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark55(8.791744520732282,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark55(8.79180322876158,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark55(87.98302067206271,-1.2701044698654584,0 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark55(87.98439419673934,-0.32876816671028053,0 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark55(8.799151292666012,-0.008572055279502942,0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark55(87.99473476950396,-0.0031317950479632373,0 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark55(88.02612561350999,-0.7779318332385641,0 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark55(88.05314739006246,-0.43321021357871103,0 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark55(88.14566344465769,-1.0346074400806013,0 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark55(88.16708133148367,-1.2865014143154547,0 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark55(88.16927741686743,-0.0927710321560653,0 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark55(88.17503615933754,-1.4103500190992548,0 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark55(88.21014734977126,-1.2192782579566113,0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark55(88.21643671484355,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark55(88.22191923831662,-0.40641069354576587,0 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark55(88.25756735595313,-0.20148263661616883,0 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark55(88.30892224050629,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark55(88.36125160296135,-1.4685173612335944,0 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark55(88.37013615219601,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark55(88.39038281171943,-0.7537061992610958,0 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark55(-88.39244171835503,-0.7111762713435894,0 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark55(88.39645813516256,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark55(88.4132629552749,-0.4051605947344818,0 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark55(88.4304807580018,-0.4976818394293712,0 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark55(8.848474502328045,-0.40800058400261396,0 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark55(88.50079943306504,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark55(8.857684112869402E-13,-1.4999999999672204,0 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark55(88.57828179047345,-0.9545328751767834,0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark55(88.58087025436322,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark55(88.61778588752728,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark55(88.62001089792366,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark55(88.6268381897774,-0.053508614815379135,0 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark55(88.63052591671911,-0.6142390323735274,0 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark55(88.64577424521778,-0.8592870668688033,0 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark55(88.6573768745873,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark55(88.66694529663576,-0.11914161302485171,0 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark55(88.6691415218485,-1.235812171697436,0 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark55(88.67224577791339,-0.07510957548837664,0 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark55(8.86902472250977,-2.053852724670974E-6,0 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark55(88.6920256288611,-0.5090588652019363,0 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark55(88.69627811520694,-1.150282855571245,0 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark55(88.70356405210723,-0.6567366093900735,0 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark55(88.7591883763242,-0.7388267868640415,0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark55(88.79570303813045,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark55(88.79736841035458,-1.2455924551654647,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark55(-8.881784197001252E-16,-0.09602616004376807,98.5519008368183 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-0.5956621068485128,0 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.0039221516473062,0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.0365344120501154,0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.2699117977883247,0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.2814529087055466,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark55(8.881784197001252E-16,-1.43072308042737,0 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark55(88.82357574744526,-0.9109632609673399,0 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark55(88.82874321444686,-0.4182705889617711,0 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark55(8.884399851409805,-1.26660316270846,0 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark55(88.85454561550466,-1.499999999999997,0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark55(88.87698141256845,-1.0449655023948452,0 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark55(88.89643852959384,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark55(88.90506332803301,-0.5783944542039166,0 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark55(8.892604020960931,-2.2729432038293516E-6,0 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark55(88.94394442772574,-0.7370471856111283,0 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark55(88.94469716951852,-0.24016103858978965,0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark55(88.99537453184269,-0.09170740140729938,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark55(89.01663913762215,-0.3656735495962735,0 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark55(8.903132980469692,-0.2379027103343958,0 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark55(89.03703965754517,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark55(89.03713828730835,-0.619875353849312,0 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark55(89.04351555187228,-1.3624035484953443,0 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark55(89.07114284671627,-38.709443150802514,-96.77538259725105 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark55(89.16106467736475,-1.3568121592188334,0 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark55(89.16125407548158,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark55(89.16560946784635,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark55(89.19177228881881,-0.7013322693826467,0 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark55(89.19665790216123,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark55(89.2132577042562,-0.20770043068038735,0 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark55(89.21405386138059,-0.9319174425662241,0 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark55(8.922399486833356,-0.20970912337280395,0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark55(89.3589982464905,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark55(8.939435915680059E-17,-0.2615048204123269,0 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark55(89.46973224480487,-0.3193249508502376,0 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark55(89.48695712390656,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark55(-89.49699939481272,-1.4903351708279537,-0.7810218521086989 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark55(89.52154019698906,-1.4240617031863794,0 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark55(89.52458345160872,-0.5433883430585926,0 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark55(89.55279124958767,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark55(89.58414670484856,-0.8267701321934045,0 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark55(89.59435369046362,-1.0690972136274266,0 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark55(89.60361997109673,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark55(8.961550720167837,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark55(89.64868413342512,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark55(89.65064422712626,-0.675074804705055,0 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark55(89.70221402899463,-0.42184887446524044,0 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark55(89.7040490582587,-0.6598595131659213,0 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark55(89.73170457603212,-0.36195645917849983,0 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark55(8.973500007931023,-0.5551500891460694,0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark55(89.83230096367194,-1.7262835670071368E-9,0 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark55(89.86131704542635,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark55(89.86191989396204,-0.28404487698059366,0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark55(89.88080401234652,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark55(-8.9889635053481,-1.3181426048641538,-1.0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark55(89.89166792682866,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark55(89.9093410703986,-1.4803800434054,0 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark55(89.91914367066747,-1.0104936334815449,0 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark55(89.92073561701235,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark55(89.92753717850843,-0.029245847598371455,0 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark55(90.0399278528478,-0.23390306156799134,0 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark55(90.05444590996834,-1.1948505257698976,0 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark55(90.14784390647927,-0.17865429635043317,0 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark55(90.15247546032509,-0.9352125218539413,0 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark55(90.20651746550575,-0.7721157038616866,0 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark55(9.02247038893374,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark55(90.24148460139511,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark55(90.246504002203,-0.9950604113437462,0 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark55(90.27524683262988,-0.1307424586025019,0 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark55(9.028009913414323,-0.7632306779836049,0 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark55(9.02902345391614,-2.4533925825448016E-9,0 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark55(90.30500280392963,-0.9814374512339583,0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark55(90.31183996778404,-0.6577491497332261,0 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark55(90.32852452556595,-0.05896454160100384,0 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark55(90.39515230453844,-0.5607217826566018,0 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark55(90.40755476770457,-1.4474726633478525,0 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark55(90.43925203582404,-0.13212654906999433,0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark55(9.046149937805325,-1.3411289609896366,0 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark55(90.46758425223629,-1.2968332459926302,0 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark55(90.54094968501957,-0.38526015497948407,0 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark55(90.55315044721624,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark55(90.55663425512039,-0.6154076003677407,0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark55(9.055973717306273,-1.3514244296370597E-6,0 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark55(90.67396534346139,-0.1070774144497122,0 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark55(9.069866465035531,-60.08560913659555,35.67364263845107 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark55(90.7961535586092,-0.2632384037242481,0 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark55(90.80959967219118,-0.9150266788945962,0 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark55(90.82473276842174,-1.499999999999977,0 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark55(90.85910935054389,-1.9815217143513515E-4,0 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark55(90.87305840205983,-1.3312200178806965,0 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark55(90.89184970692122,-0.7344688177249026,0 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark55(91.10379486202356,-1.0912997735003873,0 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark55(91.14501689799333,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark55(91.26154413424388,-3.2958862218951507E-6,0 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark55(91.26582320367157,-0.7866400361919261,0 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark55(91.32352243231117,-7.128121488515201E-9,0 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark55(91.37970711029638,-0.41112386636396847,0 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark55(9.141553736593423,-0.6843073874029102,0 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark55(91.43508853825941,-0.9210991055776776,0 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark55(91.44311645786436,-0.973868800512733,0 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark55(-9.147597452375617,-0.5771832001694415,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark55(91.48290295617593,-0.8965023524809004,0 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark55(91.49060450725125,-0.9230462288772485,0 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark55(91.53735258990326,-0.1751226465751925,0 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark55(91.57636456006941,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark55(9.163030853019038,-0.8813143824572336,0 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark55(91.63529578032336,-0.36238651679978773,0 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark55(91.63627156720017,-0.28127260248999386,0 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark55(91.6371147600988,-0.5500372160393152,0 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark55(91.69294156786927,-0.9301918717144986,0 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark55(91.69853790473354,-0.13022502850727324,0 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark55(91.71609911716624,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark55(91.75472267089978,-0.7570832010606665,0 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark55(-91.76241125982934,-1.1115132029864667,77.00555774358361 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark55(9.177116931069278,-0.4326730077579174,0 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark55(91.85963094833207,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark55(9.187002712702405E-16,-1.4996920774580376,0 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark55(9.193969382302342,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark55(91.9824966755566,-0.2493285371482319,0 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark55(92.00755267117003,-0.620867977605978,0 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark55(92.05690307340353,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark55(-92.07260509188843,-0.1533372344046513,1.0 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark55(92.09301927348434,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark55(92.15231910238691,-1.4937739649239283,0 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark55(92.25721492437278,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark55(92.26415239789677,-1.0368807816300691,0 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark55(92.26473114942124,-0.45414108725603564,0 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark55(92.30941220479397,-1.4030069618285381,0 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark55(92.32909220031442,-0.9191753747921751,0 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark55(92.34360452160388,-0.884588388137459,0 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark55(92.34961716169775,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark55(92.45220359098028,-0.5836817725757726,0 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark55(-92.47322653025785,-8.922801565753764E-10,0.0 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark55(92.49549620670345,-0.5633995007970096,0 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark55(92.49848129435789,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark55(92.5191692092766,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark55(92.5531114602968,-7.845639678568501E-10,0 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark55(92.5634895458038,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark55(92.5683344793513,-1.4999741270229476,0 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark55(92.57413974918649,-0.9915482235561606,0 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark55(9.258547090210135,-0.6804229611816175,0 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark55(92.62787186782529,-1.0787977196443372,0 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark55(92.67731962218056,-0.32245717073273283,0 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark55(92.69218575482668,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark55(92.7458785894323,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark55(92.84013295362007,-0.07570065666493342,0 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark55(92.843589252015,-0.48822949278581973,0 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark55(92.86702394231737,-2.5485869369836042E-9,0 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark55(92.8887467027017,-0.14787799055694784,0 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark55(92.90020253585422,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark55(92.90753154364232,-1.4999999976685283,0 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark55(92.90810166888387,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark55(92.96370004459686,-1.449715922484269,0 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark55(93.00749349209988,-2.8282727866590317E-8,0 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark55(93.02400568206944,-0.07187846462074474,0 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark55(93.0305880284516,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark55(93.06581564042077,-0.7608132921065014,0 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark55(93.09423113099331,-1.3774778767910494,0 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark55(93.09979937489928,-0.7578664995345292,0 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark55(93.10229655709036,-0.6966183601787117,0 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark55(9.311612728226976,-0.3491404706272192,0 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark55(93.11646415569865,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark55(93.21062939280927,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark55(93.29364055123305,-1.4260480055732039,0 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark55(9.329371323637519,-1.4968683026266247,0 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark55(93.32962053696244,-0.5138570177932138,0 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark55(93.35564488474711,-0.6345892366721486,0 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark55(-9.33584379383521,-0.00204703825371052,-0.9999999999999998 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark55(93.38084772951207,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark55(93.38343795180248,-1.4258830309608497,0 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark55(9.34189601814181,-1.1995936634089759,0 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark55(93.45927857204111,-1.499999999999993,0 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark55(93.47269624691816,-1.327491211539602,0 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark55(93.51155781716342,-0.30954274295072537,0 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark55(93.52935826031887,-0.24038787217860147,0 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark55(93.54605876774417,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark55(93.57602505601199,-0.15567070991622245,0 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark55(93.60421923649355,-0.9739781715142328,0 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark55(93.61614957555057,-1.020968477266857,0 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark55(93.65366970780943,-0.0847852485129863,0 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark55(93.66762757248341,-0.7574924485411145,0 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark55(93.69256132536833,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark55(93.69499700664028,-0.6342302670838649,0 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark55(93.7764945023458,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark55(93.8503128152868,-0.8842450645748708,0 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark55(93.88345290385652,-1.311915847219002,0 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark55(93.92059019273808,-1.1743452720344045,0 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark55(93.9254622693289,-0.1418949225274304,0 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark55(93.95818408073936,-0.12299649418963665,0 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark55(93.98235417984026,-1.2057685461878123,0 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark55(94.01675587146656,-1.3171400785910725,0 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark55(-94.05048214094084,-0.13148032860197406,-2.2575932980119624E-11 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark55(94.09730919613492,-7.863576728298463E-9,0 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark55(94.1276048349579,-0.11961245384510033,0 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark55(94.16797505340188,-0.6136293921373435,0 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark55(94.1699289085044,-0.3142604307367094,0 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark55(94.17035487094626,-7.805445651994426E-4,0 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark55(9.417535008053491,-0.7691278291163837,0 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark55(94.21457002115704,-1.3258064366575533,0 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark55(94.22533015554177,-0.0926933992046724,0 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark55(94.28932343214743,-1.4292729451903117,0 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark55(9.429109059303936,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark55(94.37289388960681,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark55(94.3767165889433,-0.34065323812730974,0 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark55(94.382172201206,-1.414664324629702,0 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark55(94.40985080174771,-0.3433207853774911,0 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark55(94.41427003127865,-0.7595896855197624,0 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark55(94.41907752675996,-1.1144149213054675,0 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark55(94.4734256987941,-1.0132804321175355,0 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark55(9.452596838128912,-1.292965612030447,0 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark55(94.5342467190828,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark55(94.55264726736786,-0.6358550681309936,0 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark55(-9.45658796855185,-0.02543964077720695,0.1949599856750308 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark55(-94.59179289940994,-1.2665655025619884,47.59393844766828 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark55(94.59637725843459,-1.076329702149998,0 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark55(94.6217690236474,-1.3459692628976936,0 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark55(94.6319570375006,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark55(94.66624870188062,-0.299664307914051,0 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark55(94.7641495042983,-1.374507228852216,0 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark55(94.81041560775728,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark55(94.8282432998767,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark55(94.84207710951412,-3.3904027667615556E-8,0 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark55(94.84238498348984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark55(9.489143873794903,-1.0061578804130773,0 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark55(94.90906162120999,-0.36857587581762896,0 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark55(94.9621615797263,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark55(95.03737753078246,-0.2788654941156059,0 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark55(95.08019306200629,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark55(95.1101183851637,-0.10486260527290561,0 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark55(95.11706066160028,-1.1699688969730555,0 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark55(95.16014976222291,-0.004338644845741639,0 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark55(95.20274858257227,-0.7035701062192917,0 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark55(95.30745540554166,-1.4999999998619722,0 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark55(95.32771781614974,-0.7291655042409564,0 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark55(95.34363433296977,-1.3956324584739812,0 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark55(95.35756109305356,-0.15542064103352699,0 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark55(95.36315535934955,-0.7760644947959137,0 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark55(95.4026525073204,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark55(95.43813966652766,-4.337190930172862E-9,0 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark55(95.47776407329712,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark55(95.50767399526117,-0.3146171689825792,0 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark55(95.53150791152581,-1.081139399350434,0 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark55(95.62111117648274,-1.1236305421617026,0 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark55(9.56840989072639,-0.4719275953118114,0 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark55(95.68466592583192,-1.386449860378526,0 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark55(95.7087836362374,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark55(95.70915103930355,-0.389828580543751,0 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark55(95.72560056027817,-0.9351459162721674,0 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark55(9.58412212454786,-1.3686531692842705,0 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark55(95.86182341086452,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark55(95.87590143146556,-0.4136535275653115,0 ) ;
  }

  @Test
  public void test4215() {
    coral.tests.JPFBenchmark.benchmark55(95.88293598680967,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4216() {
    coral.tests.JPFBenchmark.benchmark55(95.88469932746978,-1.3424238007197253,0 ) ;
  }

  @Test
  public void test4217() {
    coral.tests.JPFBenchmark.benchmark55(95.91001233002498,-0.6007284728661375,0 ) ;
  }

  @Test
  public void test4218() {
    coral.tests.JPFBenchmark.benchmark55(95.93814412826578,-1.3182085051250718,0 ) ;
  }

  @Test
  public void test4219() {
    coral.tests.JPFBenchmark.benchmark55(95.94496781563257,-1.097595779300753,0 ) ;
  }

  @Test
  public void test4220() {
    coral.tests.JPFBenchmark.benchmark55(96.05620842563127,-1.101271181989354,0 ) ;
  }

  @Test
  public void test4221() {
    coral.tests.JPFBenchmark.benchmark55(96.05867162630096,-0.4012787366354713,0 ) ;
  }

  @Test
  public void test4222() {
    coral.tests.JPFBenchmark.benchmark55(96.06202665155762,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test4223() {
    coral.tests.JPFBenchmark.benchmark55(96.07200274160016,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test4224() {
    coral.tests.JPFBenchmark.benchmark55(96.09529827308992,-0.6213672335784679,0 ) ;
  }

  @Test
  public void test4225() {
    coral.tests.JPFBenchmark.benchmark55(9.614353705794485,-1.4999999998890559,0 ) ;
  }

  @Test
  public void test4226() {
    coral.tests.JPFBenchmark.benchmark55(96.15071965885565,-0.30093875367922907,0 ) ;
  }

  @Test
  public void test4227() {
    coral.tests.JPFBenchmark.benchmark55(-96.17204379801333,-7.1779779636076525E-6,0.5228376466002418 ) ;
  }

  @Test
  public void test4228() {
    coral.tests.JPFBenchmark.benchmark55(96.35152026440073,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4229() {
    coral.tests.JPFBenchmark.benchmark55(96.37574445670523,-1.11329829253809,0 ) ;
  }

  @Test
  public void test4230() {
    coral.tests.JPFBenchmark.benchmark55(96.38663961863888,-0.19485701378656928,0 ) ;
  }

  @Test
  public void test4231() {
    coral.tests.JPFBenchmark.benchmark55(96.39686497704056,-5.402551421949858E-9,0 ) ;
  }

  @Test
  public void test4232() {
    coral.tests.JPFBenchmark.benchmark55(96.42085129491045,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4233() {
    coral.tests.JPFBenchmark.benchmark55(96.46978877920569,-0.0499275691264196,0 ) ;
  }

  @Test
  public void test4234() {
    coral.tests.JPFBenchmark.benchmark55(9.647067765256782,-0.3799349075944738,0 ) ;
  }

  @Test
  public void test4235() {
    coral.tests.JPFBenchmark.benchmark55(96.47735799247022,-1.0041856229923212,0 ) ;
  }

  @Test
  public void test4236() {
    coral.tests.JPFBenchmark.benchmark55(96.4823466304494,-1.281339732482948,0 ) ;
  }

  @Test
  public void test4237() {
    coral.tests.JPFBenchmark.benchmark55(9.649522313880611,-0.27102048791896993,0 ) ;
  }

  @Test
  public void test4238() {
    coral.tests.JPFBenchmark.benchmark55(96.51462681936599,-0.059448068125905085,0 ) ;
  }

  @Test
  public void test4239() {
    coral.tests.JPFBenchmark.benchmark55(96.53232213268558,-0.7767211135091685,0 ) ;
  }

  @Test
  public void test4240() {
    coral.tests.JPFBenchmark.benchmark55(96.55706601724953,-1.2910890540535407,0 ) ;
  }

  @Test
  public void test4241() {
    coral.tests.JPFBenchmark.benchmark55(96.56421989702146,-1.4999728711241709,0 ) ;
  }

  @Test
  public void test4242() {
    coral.tests.JPFBenchmark.benchmark55(96.58506127165361,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4243() {
    coral.tests.JPFBenchmark.benchmark55(9.66128359391265,-0.4813695332975013,0 ) ;
  }

  @Test
  public void test4244() {
    coral.tests.JPFBenchmark.benchmark55(96.70558923697823,-0.1680731528352939,0 ) ;
  }

  @Test
  public void test4245() {
    coral.tests.JPFBenchmark.benchmark55(96.76569681136766,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4246() {
    coral.tests.JPFBenchmark.benchmark55(96.78723406318394,-1.1927901214328216,0 ) ;
  }

  @Test
  public void test4247() {
    coral.tests.JPFBenchmark.benchmark55(96.81944519590431,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4248() {
    coral.tests.JPFBenchmark.benchmark55(96.92651850394107,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4249() {
    coral.tests.JPFBenchmark.benchmark55(96.94619496375711,-0.6794616960161663,0 ) ;
  }

  @Test
  public void test4250() {
    coral.tests.JPFBenchmark.benchmark55(96.9618773916664,-1.0596940964706028,0 ) ;
  }

  @Test
  public void test4251() {
    coral.tests.JPFBenchmark.benchmark55(96.96413107819654,-0.27369931169931583,0 ) ;
  }

  @Test
  public void test4252() {
    coral.tests.JPFBenchmark.benchmark55(97.01515301419849,-0.40755523078766487,0 ) ;
  }

  @Test
  public void test4253() {
    coral.tests.JPFBenchmark.benchmark55(9.713711859939767,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4254() {
    coral.tests.JPFBenchmark.benchmark55(97.17865598119408,-0.43953507316027274,0 ) ;
  }

  @Test
  public void test4255() {
    coral.tests.JPFBenchmark.benchmark55(97.22744012757755,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4256() {
    coral.tests.JPFBenchmark.benchmark55(97.25211563546455,-1.4631124995421887,0 ) ;
  }

  @Test
  public void test4257() {
    coral.tests.JPFBenchmark.benchmark55(97.26191203068575,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test4258() {
    coral.tests.JPFBenchmark.benchmark55(97.26259379942016,-0.8728109732859792,0 ) ;
  }

  @Test
  public void test4259() {
    coral.tests.JPFBenchmark.benchmark55(97.26335717076807,-0.33095192207107527,0 ) ;
  }

  @Test
  public void test4260() {
    coral.tests.JPFBenchmark.benchmark55(-97.28033093217665,-1.4999999964567803,-1.0 ) ;
  }

  @Test
  public void test4261() {
    coral.tests.JPFBenchmark.benchmark55(97.28610462965915,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4262() {
    coral.tests.JPFBenchmark.benchmark55(97.28878926438924,-0.07740378095129596,0 ) ;
  }

  @Test
  public void test4263() {
    coral.tests.JPFBenchmark.benchmark55(9.731010821102899,-0.6170033281686589,0 ) ;
  }

  @Test
  public void test4264() {
    coral.tests.JPFBenchmark.benchmark55(9.731352536942552,-0.004732183941564827,0 ) ;
  }

  @Test
  public void test4265() {
    coral.tests.JPFBenchmark.benchmark55(97.33125624513929,-0.8067862886745631,0 ) ;
  }

  @Test
  public void test4266() {
    coral.tests.JPFBenchmark.benchmark55(97.37584745107571,-0.21020568217926439,0 ) ;
  }

  @Test
  public void test4267() {
    coral.tests.JPFBenchmark.benchmark55(9.741730628859672,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4268() {
    coral.tests.JPFBenchmark.benchmark55(97.44781981100004,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4269() {
    coral.tests.JPFBenchmark.benchmark55(97.44888296930648,-1.4660668629763975,0 ) ;
  }

  @Test
  public void test4270() {
    coral.tests.JPFBenchmark.benchmark55(97.50485689825885,-1.033678005935733,0 ) ;
  }

  @Test
  public void test4271() {
    coral.tests.JPFBenchmark.benchmark55(-97.52647221349883,-8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test4272() {
    coral.tests.JPFBenchmark.benchmark55(97.52702087408062,-0.8615998354764858,0 ) ;
  }

  @Test
  public void test4273() {
    coral.tests.JPFBenchmark.benchmark55(97.53681018489553,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4274() {
    coral.tests.JPFBenchmark.benchmark55(97.54113006316342,-0.7632663005782432,0 ) ;
  }

  @Test
  public void test4275() {
    coral.tests.JPFBenchmark.benchmark55(97.54605218261491,-0.426695808715304,0 ) ;
  }

  @Test
  public void test4276() {
    coral.tests.JPFBenchmark.benchmark55(97.54809870522439,-0.9200460818916127,0 ) ;
  }

  @Test
  public void test4277() {
    coral.tests.JPFBenchmark.benchmark55(97.55168749197601,-1.43115108101874,0 ) ;
  }

  @Test
  public void test4278() {
    coral.tests.JPFBenchmark.benchmark55(-97.5800734401598,-0.5090594355774698,-91.12729780769504 ) ;
  }

  @Test
  public void test4279() {
    coral.tests.JPFBenchmark.benchmark55(97.64855181186866,-1.4999999999091023,0 ) ;
  }

  @Test
  public void test4280() {
    coral.tests.JPFBenchmark.benchmark55(97.66402671092159,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4281() {
    coral.tests.JPFBenchmark.benchmark55(97.70150093954499,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4282() {
    coral.tests.JPFBenchmark.benchmark55(97.74751526997684,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4283() {
    coral.tests.JPFBenchmark.benchmark55(97.7615591416647,-1.1991977037328672,0 ) ;
  }

  @Test
  public void test4284() {
    coral.tests.JPFBenchmark.benchmark55(97.78601322460119,-0.287818021819319,0 ) ;
  }

  @Test
  public void test4285() {
    coral.tests.JPFBenchmark.benchmark55(97.79859669308036,-0.5812479559621302,0 ) ;
  }

  @Test
  public void test4286() {
    coral.tests.JPFBenchmark.benchmark55(-97.79986663584863,-0.996832412016423,-0.06255252567469938 ) ;
  }

  @Test
  public void test4287() {
    coral.tests.JPFBenchmark.benchmark55(97.84057241887871,-0.21727587846425278,0 ) ;
  }

  @Test
  public void test4288() {
    coral.tests.JPFBenchmark.benchmark55(97.95913295759792,-0.43107426780765934,0 ) ;
  }

  @Test
  public void test4289() {
    coral.tests.JPFBenchmark.benchmark55(98.0282963735763,-0.07631541525964902,0 ) ;
  }

  @Test
  public void test4290() {
    coral.tests.JPFBenchmark.benchmark55(98.03108606145338,-1.2464287323565149,0 ) ;
  }

  @Test
  public void test4291() {
    coral.tests.JPFBenchmark.benchmark55(98.03554774768777,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4292() {
    coral.tests.JPFBenchmark.benchmark55(98.07217890452978,-0.955931990647656,0 ) ;
  }

  @Test
  public void test4293() {
    coral.tests.JPFBenchmark.benchmark55(98.09873523728291,-0.57254180508086,0 ) ;
  }

  @Test
  public void test4294() {
    coral.tests.JPFBenchmark.benchmark55(98.09913637136896,-0.3495330253082045,0 ) ;
  }

  @Test
  public void test4295() {
    coral.tests.JPFBenchmark.benchmark55(98.12555936854477,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4296() {
    coral.tests.JPFBenchmark.benchmark55(98.14596009827451,-0.9761630742705307,0 ) ;
  }

  @Test
  public void test4297() {
    coral.tests.JPFBenchmark.benchmark55(98.15988427387947,-0.37058992908428134,0 ) ;
  }

  @Test
  public void test4298() {
    coral.tests.JPFBenchmark.benchmark55(98.22575196148536,-0.4538221251813867,0 ) ;
  }

  @Test
  public void test4299() {
    coral.tests.JPFBenchmark.benchmark55(98.22879008381898,-0.34912095640506413,0 ) ;
  }

  @Test
  public void test4300() {
    coral.tests.JPFBenchmark.benchmark55(98.29942706720803,-0.4506918035300629,0 ) ;
  }

  @Test
  public void test4301() {
    coral.tests.JPFBenchmark.benchmark55(9.832873403269481,-0.7221897184106718,0 ) ;
  }

  @Test
  public void test4302() {
    coral.tests.JPFBenchmark.benchmark55(98.3635573290415,-1.0745109001696074,0 ) ;
  }

  @Test
  public void test4303() {
    coral.tests.JPFBenchmark.benchmark55(98.48181930062964,-0.6288515747940333,0 ) ;
  }

  @Test
  public void test4304() {
    coral.tests.JPFBenchmark.benchmark55(9.849627103267212,-0.2849466890787298,0 ) ;
  }

  @Test
  public void test4305() {
    coral.tests.JPFBenchmark.benchmark55(98.51063923521676,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4306() {
    coral.tests.JPFBenchmark.benchmark55(98.55736560084937,-1.4846929047072288,0 ) ;
  }

  @Test
  public void test4307() {
    coral.tests.JPFBenchmark.benchmark55(-9.860761315262648E-32,-1.4855081169500977,0 ) ;
  }

  @Test
  public void test4308() {
    coral.tests.JPFBenchmark.benchmark55(9.863912730739683,-0.055580604186758364,0 ) ;
  }

  @Test
  public void test4309() {
    coral.tests.JPFBenchmark.benchmark55(98.67438599673955,-0.7437520846317085,0 ) ;
  }

  @Test
  public void test4310() {
    coral.tests.JPFBenchmark.benchmark55(98.68649089830274,-1.1551399756161624,0 ) ;
  }

  @Test
  public void test4311() {
    coral.tests.JPFBenchmark.benchmark55(9.87004112171455,-1.2681276194281423,0 ) ;
  }

  @Test
  public void test4312() {
    coral.tests.JPFBenchmark.benchmark55(9.875896395800197,-0.06685044315310584,0 ) ;
  }

  @Test
  public void test4313() {
    coral.tests.JPFBenchmark.benchmark55(98.76320180632757,-1.1894696436841343,0 ) ;
  }

  @Test
  public void test4314() {
    coral.tests.JPFBenchmark.benchmark55(9.881254210791981,-1.9607828739570665E-8,0 ) ;
  }

  @Test
  public void test4315() {
    coral.tests.JPFBenchmark.benchmark55(98.83613311691953,-1.78968828094761E-4,0 ) ;
  }

  @Test
  public void test4316() {
    coral.tests.JPFBenchmark.benchmark55(98.88032684288476,-0.80105282736218,0 ) ;
  }

  @Test
  public void test4317() {
    coral.tests.JPFBenchmark.benchmark55(9.892287803167505,-0.013415749861636073,0 ) ;
  }

  @Test
  public void test4318() {
    coral.tests.JPFBenchmark.benchmark55(98.92393083619694,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4319() {
    coral.tests.JPFBenchmark.benchmark55(98.92657572392395,-0.08996768039787817,0 ) ;
  }

  @Test
  public void test4320() {
    coral.tests.JPFBenchmark.benchmark55(98.9273777752883,-0.02810346575108319,0 ) ;
  }

  @Test
  public void test4321() {
    coral.tests.JPFBenchmark.benchmark55(98.9660735751682,-0.39626224915405894,0 ) ;
  }

  @Test
  public void test4322() {
    coral.tests.JPFBenchmark.benchmark55(98.96968760274291,-1.4999999999998934,0 ) ;
  }

  @Test
  public void test4323() {
    coral.tests.JPFBenchmark.benchmark55(99.00983577253871,-0.18454919456173258,0 ) ;
  }

  @Test
  public void test4324() {
    coral.tests.JPFBenchmark.benchmark55(99.0250101239566,-0.13141083347543203,0 ) ;
  }

  @Test
  public void test4325() {
    coral.tests.JPFBenchmark.benchmark55(99.03246472006364,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4326() {
    coral.tests.JPFBenchmark.benchmark55(9.908109745528918,-0.9816603920110314,0 ) ;
  }

  @Test
  public void test4327() {
    coral.tests.JPFBenchmark.benchmark55(99.09647201375054,-0.2500571094812899,0 ) ;
  }

  @Test
  public void test4328() {
    coral.tests.JPFBenchmark.benchmark55(99.12696657996952,-1.1837349034026106,0 ) ;
  }

  @Test
  public void test4329() {
    coral.tests.JPFBenchmark.benchmark55(9.914172000997851,-0.6213033154048491,0 ) ;
  }

  @Test
  public void test4330() {
    coral.tests.JPFBenchmark.benchmark55(99.14528623314962,-0.8655877144005153,0 ) ;
  }

  @Test
  public void test4331() {
    coral.tests.JPFBenchmark.benchmark55(-99.17109107549356,-0.23935852045076392,-1.0 ) ;
  }

  @Test
  public void test4332() {
    coral.tests.JPFBenchmark.benchmark55(99.2113441176794,-0.9385221001861059,0 ) ;
  }

  @Test
  public void test4333() {
    coral.tests.JPFBenchmark.benchmark55(99.21590868350219,-0.1934694944735602,0 ) ;
  }

  @Test
  public void test4334() {
    coral.tests.JPFBenchmark.benchmark55(99.24012787051981,-0.13571292219783776,0 ) ;
  }

  @Test
  public void test4335() {
    coral.tests.JPFBenchmark.benchmark55(99.30098519006708,-1.4698562494905074,0 ) ;
  }

  @Test
  public void test4336() {
    coral.tests.JPFBenchmark.benchmark55(99.38817657575112,-0.9778685041207105,0 ) ;
  }

  @Test
  public void test4337() {
    coral.tests.JPFBenchmark.benchmark55(99.40577941311494,-0.8354515317872835,0 ) ;
  }

  @Test
  public void test4338() {
    coral.tests.JPFBenchmark.benchmark55(99.513368599539,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4339() {
    coral.tests.JPFBenchmark.benchmark55(99.56739519195531,-1.4598008924133552,0 ) ;
  }

  @Test
  public void test4340() {
    coral.tests.JPFBenchmark.benchmark55(99.61450665836333,-1.143744963244263,0 ) ;
  }

  @Test
  public void test4341() {
    coral.tests.JPFBenchmark.benchmark55(9.96200410351824,-0.47601071093034864,0 ) ;
  }

  @Test
  public void test4342() {
    coral.tests.JPFBenchmark.benchmark55(9.962078013541191,-0.21258848095981958,0 ) ;
  }

  @Test
  public void test4343() {
    coral.tests.JPFBenchmark.benchmark55(99.85502138245849,-1.4999999999999698,0 ) ;
  }

  @Test
  public void test4344() {
    coral.tests.JPFBenchmark.benchmark55(99.855110490257,-0.3130182028270614,0 ) ;
  }

  @Test
  public void test4345() {
    coral.tests.JPFBenchmark.benchmark55(99.95694210904102,-1.0255786173065502,0 ) ;
  }
}
