import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(0.0035212801346338474,-24.486712892462293 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(0.00644845917389425,16.365203748539983 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(0.007522513532513975,-37.821858228043645 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark01(0.02867813644326267,-83.84087713795073 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark01(0.03402792986626113,66.0272759988398 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark01(0.03865493868339955,1.5707963267948966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark01(0.05917076215347672,-38.62699243147288 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark01(0.07227479591644947,82.28443558703908 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark01(0.09821500685104922,-31.56248681695955 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark01(0.12368824749148177,-0.5019898500142227 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark01(0.14098851884294897,4.712601439331376 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark01(0.15335937940735284,-24.492113990842252 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark01(0.2096731130407371,-1.5707963267948961 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark01(0.2538743574986371,0.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark01(0.25697223904480015,1.5707963267948948 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark01(0.2588357796935239,44.20466434058392 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark01(0.28735827140944536,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark01(0.29302265837536395,1.5707963267948968 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark01(0.30176449200623146,1.5707963267948217 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark01(0.32043976753691084,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark01(-0.36169694897513693,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark01(0.41397212688531676,1.571029514072274 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark01(0.45433568338202807,-72.75898660032763 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark01(0.4545944478054804,-1.5707963267948968 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark01(0.49253346296392087,2.220446049250313E-16 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark01(0.5264565932464103,0.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark01(0.5628496293413123,0.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark01(0.5789072197664787,-45.016892468832005 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark01(0.5891515040173054,-1.5707963267948966 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark01(0.604362343342494,88.3525298997347 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark01(0.6140458205333417,2518.3465253594322 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark01(0.6162349114300355,-61.69674369351981 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark01(0.621748518463719,42.84224007936232 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark01(0.6241444489292955,-1.5707963267948966 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark01(0.6515166506107342,-18.932772040953054 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark01(0.6735936715124019,38.884215263617925 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark01(0.7258855383220078,-20.296953462884744 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark01(0.7361421241006951,-94.14729122951711 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark01(0.7638603903837163,-1.5707963267948966 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark01(0.79478567862016,199.78148235757683 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark01(0.8384069033033299,67.79046348420408 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark01(0.8528761915587462,-0.11728248152269316 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark01(0.8640936846170935,44.147903268205766 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark01(-0.8732006399145433,30.52395746524624 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark01(0.8749306853659107,29.400723110209867 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark01(0.8830328745394831,19.461639903962862 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark01(0.9085997565449547,-54.38467390609176 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark01(0.9286130599738343,67.37636137047078 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark01(0.9315036302472816,-36.327104218799256 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark01(0.9333290876403757,-9.030744491748678 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark01(0.9547060325845046,1.3858883515835854 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark01(0.9762590161280102,75.35952719881072 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,0.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark01(100.0,0.3272735431579777 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark01(100.0,0.49998817761827136 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-0.501353724193352 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark01(100.0,100.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-120.55217200115854 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark01(100.0,131.23850683078 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-135.24509974298957 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark01(100.0,14.481937453681315 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,1.5707963094755604 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-1.5707963267945086 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-1.5707963267948557 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-1.5707963267948948 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.5707963267948983 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark01(100.0,1.5707963267948983 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-19.91157389315981 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-1.9990576266678504 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-21.797798752542885 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark01(100.0,2597.9080664603384 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,2627.107309212037 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,27.47878976440481 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark01(100.0,-31.8267585715178 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,46.13530452800357 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark01(100.0,49.261402269691246 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,7.200951413584023 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-7.3388463150486665 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-7.591652611828653 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,78.7407624053304 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,-88.2044300541039 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark01(-100.0,96.10154107034828 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark01(-100.14236384565778,-74.16733365997301 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark01(-100.52196406710162,0.11690364299696641 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark01(100.52749302326102,-18.849555921538418 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark01(100.52923945050271,-37.6991118847709 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark01(100.53088545272018,1.5707963267948981 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark01(-100.53101756872894,56.54868813299284 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark01(-100.53353099409112,64.40313768668726 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark01(-100.546589933856,6.224593063750352 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark01(-100.74747377113272,-88.47015144157348 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark01(1.0166906613290372,-1.5707963267948966 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark01(-10.189328799922421,0.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark01(10.190021057191531,-138.81709632970689 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark01(-10.267668973029362,1.5707963267948966 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark01(-10.26804224345862,4.440892098500626E-16 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark01(-10.27849434731391,-0.4555442570875279 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark01(-102.81980709891468,95.41227822111944 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark01(10.2845308135079,67.01858013664986 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark01(-10.286886710747638,67.41714037538354 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark01(-10.334631706309612,1.3586219397355783 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark01(-103.67067461006008,-0.0036196989806519513 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark01(-103.67239197403264,42.41150082151719 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark01(-104.11901169572297,-11.235284608195286 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark01(104.19859542785971,-47.13042379495378 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark01(-10.424777813192017,89.53563476793411 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark01(-104.65955565253185,15.048933604981073 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark01(10.47189844863665,0.38527288442518565 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark01(-105.24200424218623,-1.5707963267948966 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark01(105.30761395143887,-268.6061753977102 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark01(10.532428686517648,-80.20938115309586 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark01(10.533490776086012,-84.93797727514702 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark01(10.577400470896226,11.13190927006184 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark01(10.595390484190673,65.53671196030741 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark01(106.81414582875205,125.66370602032977 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark01(106.8141474819655,-5.328075753093927E-4 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark01(-106.8152610845012,70.68583565956605 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark01(106.81786381419211,0.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark01(107.15950722696273,-26.62428983727444 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark01(107.20408298621689,49.189192663199826 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark01(-10.787814386089448,1.5707963267948948 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark01(-10.793875022022855,45.53282043775557 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark01(10.794686260920443,89.86243062992497 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark01(-108.03586957720296,16.382335068431377 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark01(-108.10291844315937,-1.5707963267948983 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark01(-10.821294192041535,-57.22264627490588 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark01(10.828217570928269,-9.720018591492334 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark01(108.60791096018676,2603.220314211436 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark01(-10.951069091090098,44.42219220863748 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark01(10.957765625105736,-53.48377738155992 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark01(-10.995509666795655,98.9601650695176 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark01(-109.95574287538949,-136.6592803844145 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark01(-10.995574288982572,-102.10182230707548 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark01(10.997888152236527,82.83674955672963 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark01(-110.23288791377989,93.67216818293662 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark01(1.1058919665164488,1.2779621394412715 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark01(11.075506073288139,-3.862556184459088E-12 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark01(-11.097504936216396,-1.5707963267948966 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark01(-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark01(1.1102230246251565E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark01(-111.04384749865093,0.5344091703253632 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark01(111.58129733067115,-7.41086729916851E-15 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark01(111.58817030044025,-24.821898443310047 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark01(111.80303221535185,-1.5707963267948968 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark01(-111.88567195271082,71.38638148211805 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark01(-111.95591333651971,-32.805895819189814 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark01(-112.54849845400096,0.02587007138398356 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark01(-112.75984340365827,-0.6295854269741201 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark01(-112.96233409093875,41.7550933115063 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark01(113.09707410582266,87.96459477487092 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark01(113.09732988615814,-17.278757485484533 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark01(113.09733157426136,-6.027448254404761E-7 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark01(113.0973353058737,67.54424114363864 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark01(-113.09733552908916,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark01(1.131196381215394,0.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark01(113.13709167941613,17.775334545530868 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark01(-113.16507284881774,-12.771607971730077 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark01(-11.331707948703269,88.13276015980273 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark01(-113.37874250623065,-49.8737718432832 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark01(-11.36407474190564,78.75883934072036 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark01(11.470751622605718,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark01(-114.933165207861,15.9792603360345 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark01(11.541620740282024,-0.4054565935222981 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark01(1.1579196784388524,-130.21418812540105 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark01(-116.77787116932328,-88.62111936429977 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark01(11.690892794303512,-100.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark01(-11.742340512875842,-28.108496047215198 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark01(-117.54702062904116,1.5707963267948983 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark01(117.67004424639406,-58.851727769292 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark01(1.1779728722796372,0.059933035098053054 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark01(-117.80972450965723,161.79201813767676 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark01(-117.88589456882332,1.820136795854421 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark01(117.93353661906067,74.21254505077218 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark01(-118.1361414082831,54.96625500630904 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark01(-118.29408081959957,-4.83738898154702 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark01(-119.08451742387064,22.14577648253251 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark01(-119.08517227836677,-10.690667826160597 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark01(1.1921018865698312,66.47048079356162 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark01(-119.21904642164561,0.26078148108106763 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark01(119.37799461299626,-18.84955593356005 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark01(119.38052070919005,105.24335389349608 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark01(119.38052083641212,0.002629840738473088 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark01(-12.00418552859811,-45.067239426427605 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark01(120.40005996932788,-26.55485713541696 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark01(120.94868732256879,1.5707963267948983 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark01(120.9513170786524,-73.82742602237914 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark01(1.2128249736166208,0.0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark01(12.160142548468073,62.522728373032066 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark01(121.91444360269489,99.69713654066439 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark01(122.45590166494583,-9.33756184639509 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark01(122.52310719344428,50.265482460772645 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark01(122.52601974097743,-37.69911729680327 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark01(122.52608807242619,58.15071409141856 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark01(-122.61052278656047,-18.671406875287182 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark01(-122.7963699947205,78.9003244809249 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark01(123.80875525321284,31.576043298083277 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark01(-123.88626636519999,-3.32821789847919E-25 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark01(-124.06334251764092,4.743638987337549 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark01(-124.09101343646512,14.137175044872803 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark01(12.524134316019797,-57.74060531772294 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark01(-125.5435835472194,24.638156758725756 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark01(12.566344422137936,-10.995574287564253 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark01(12.5663706143586,10.994666619793806 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark01(12.566370614359172,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark01(-12.566419209001612,-29.8451302090091 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark01(-125.665575388158,-3.9026140460656985E-6 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark01(-125.67441531634746,24.92753919344483 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark01(-12.667020613724016,-1.5707963267949054 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark01(-12.725538927088266,1.5707963267948966 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark01(12.737466335096713,27.80187940950026 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark01(12.741891894506779,72.68728468288637 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark01(12.77774869422245,77.44512503273339 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark01(-12.811838416438926,-1.5707963267948966 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark01(12.816910163268737,36.10742635564591 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark01(12.842306340446742,-67.5437888901721 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark01(1.2865887219793282,27.3727121595253 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark01(12.86984759450774,-33.996659774362726 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark01(12.91799506707865,2637.545855201385 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark01(-129.18853304930224,-6.603522348743017 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark01(12.937752974257762,3.7563878841812226 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark01(-12.944292237337038,-44.48387673156971 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark01(12.945960637745273,-97.15408939574252 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark01(1.2949027422914179,-255.8360234294416 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark01(-129.51772252220127,-0.10937318666848339 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark01(1.29664271239947,45.80434177284636 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark01(12.970412698641347,-32.69396983169074 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark01(-12.982914874537423,-3.266531823556079 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark01(13.032236785128555,-58.66278291353246 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark01(-130.5525878601957,4.743639578490507 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark01(13.066370614359117,-1.5707963267950178 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark01(13.082118602555756,227.30466701582753 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark01(-13.097157436071072,-12.417590257335931 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark01(13.133797914074762,7.003540663529975 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark01(13.221768432465296,60.40398253592022 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark01(-132.37028019063493,1.3509603476917391 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark01(13.333244461734013,-3.615080717794148 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark01(-13.334796594360128,-1.5707963267948968 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark01(-13.34500944233909,-85.00469467192619 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark01(1.3345305060618868,0.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark01(13.381159430826024,-1.2948898315091608 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark01(-133.97241283449074,1.5707963267948966 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark01(1.3415928096714391,76.95583469214324 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark01(1.3479805882154596,1.2390537782546134E-5 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark01(13.497740845372217,-10.589213278013645 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark01(135.08881380154747,4.11305437379321E-12 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark01(1.3509217400841265,-70.66175786214325 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark01(135.60371719312803,89.53539062730911 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark01(-13.56358290408976,-1.3858055506832976E-6 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark01(-136.27422841057134,99.89790100208074 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark01(136.42171651596243,46.33964003141577 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark01(-13.73086351410035,-74.01513787345732 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark01(1.3748496779986192,1.5707963267948968 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark01(13.79345537425801,53.80465457291396 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark01(13.798374591866974,-226.75447264064218 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark01(-138.02199164724303,88.61899428101327 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark01(138.23006527538845,-50.265482222903415 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark01(-139.39992947446726,72.5542362642144 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark01(-14.000692110456669,-97.28473221354604 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark01(14.007541494183684,-88.7084145252498 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark01(14.00953830893134,-62.60118067819225 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark01(1.403427098892717E-4,18.866495404215826 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark01(-14.061368266209158,0.9118937958904643 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark01(1.4077393486992464,1.5707963267948966 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark01(14.078462214532621,64.68686851156541 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark01(-14.085742549708797,-60.7453156535114 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark01(141.11523754786788,-61.448582746785235 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark01(-14.12783809800176,0.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark01(-141.33402163333153,-4.307392492820614E-25 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark01(14.134537100515505,-1.5707963267948974 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark01(141.34789350369184,-0.2374805598721382 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark01(14.137139951243535,92.676980074026 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark01(14.139796781792919,1.5707963267948966 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark01(1.4165044460265475,0.5281797952845669 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark01(141.95349417575397,53.44205787247006 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark01(-14.20182223888962,10.309718054598264 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark01(-142.0897156698843,-23.911080218227692 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark01(1.423978928362917,0.023104258966820723 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark01(-142.73178483760975,88.56036255351427 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark01(14.283908163034733,107.55632930193465 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark01(1.4283998103058346,68.60513714345765 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark01(143.40737446211037,85.14049992705498 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark01(14.359352418310964,-1.2114549963196424E-10 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark01(-144.51404239683873,31.41592653682092 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark01(-144.52897282095785,45.55333836606695 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark01(1.4465130601366643,57.765679334379286 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark01(145.803758955569,61.7297962186016 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark01(14.608888746147699,-23.36898917490757 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark01(1.4612130794117322,-1.1730936605240703 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark01(-146.41161374059476,77.93088871101185 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark01(-14.652151589533705,-44.43061130017678 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark01(147.16051599914925,-5.265750864714029 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark01(-147.24864643735302,41.78658786968464 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark01(-147.48703120318572,-45.040062413290144 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark01(-147.6509081186393,43.98229652156626 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark01(147.8484124627903,17.27875959494801 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark01(14.798241646860374,0.4251304213528589 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark01(-14.845186173946317,-37.77905419316588 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark01(-14.853154106067564,-67.30328268982502 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark01(1.485551344269202,0.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark01(-148.7906004813615,48.78797254112414 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark01(-14.889604866891375,-14.429228346449548 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark01(-14.906238213303201,-1.5707963267948968 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark01(-149.22524618433144,-10.995570857236224 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark01(-14.92989205499208,1.2859618272204836 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark01(14.94923855517105,-17.06203556362884 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark01(14.99316996446342,32.57070395586951 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark01(15.013069247753322,-66.3930787118897 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark01(150.7883025944762,4.630008187959739E-12 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark01(15.125067845250385,32.833528026303455 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark01(1.5193018203664925,1.5707963267948966 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark01(15.228825088971497,0.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark01(1.5242927766495242,0.20982708460045718 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark01(-153.93420144411968,-75.39822368615678 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark01(153.93853354449377,-1.57079701282986 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark01(154.3740879381133,0.7885850748082746 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark01(-154.97549211502584,0.0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark01(-155.00271051827843,-31.779622710478876 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark01(155.08797381414433,90.2906086124488 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark01(-15.530832516174115,67.54424205218055 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark01(1.5532416899732269,1.5707963267948966 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark01(15.58279718541877,-72.25359744117449 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark01(-156.43198196299818,136.3243111778833 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark01(1.5646857607459381,37.615400048533544 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark01(1.56524338962704,0.4441874008695679 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark01(15.657983290566207,34.16147578636614 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark01(1.568166486155963,1.5707963267948966 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark01(1.5681664861560187,-1.5707963267948966 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark01(1.568166486156683,-1.5707963267948983 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark01(1.5682104390496763,1.5707963267948966 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark01(1.5687630181868815,45.55309488238073 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark01(1.568788358905763,4.712387523235627 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark01(1.5691945291580474,1.5707963267948983 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark01(1.570244875280846,-67.54423896317076 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark01(1.5703658901333795,-1.5707963267948966 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark01(1.5703756122500732,136.65928029483547 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark01(15.704300327244974,-6.368824972647958 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark01(1.5705702427940718,-14.429203681117443 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark01(1.570737491929206,-23.561941382864095 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark01(1.5707794179661025,-152.36725146486822 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark01(1.5707872169196955,86.3937944517456 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark01(-15.707958818416133,10.995574287564269 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark01(1.5707960744246177,-14.137170463387312 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark01(1.570796262842989,-1.5717728914788465 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark01(-15.707962664263244,31.418318236098425 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark01(1.570796323333862,-38.60257783777683 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963263301994,-136.65923080228666 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark01(-15.707963264845807,-6.2044502258335115 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267912746,-56.07099610386946 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark01(-15.707963267947752,1.5707963267948966 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948735,-27.21629816328533 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794877,11.065443014595518 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948841,39.26991004448504 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,29.845127367732264 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-37.92848667838496 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,-67.31959227715487 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948912,95.81857945672819 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794893,0.009580846338158422 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-23.56194137968396 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,24.087515322427606 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-2639.7870336125416 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,27.02445052956651 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-44.53942175757498 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-49.475809978415434 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,68.04504885694718 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,-80.1106524298635 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948948,82.33745965839192 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948948,-86.08105139342734 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948952,36.18049359379485 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-0.23236428734279296 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,100.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,-56.16235644052887 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948957,7.5443167950985135 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948961,2573.0448248542343 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948961,-74.60767407505797 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,2440.8654685681972 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,30.743204177667838 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-44.268870884384555 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,53.69804607365813 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,58.02501826277898 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-6.407434458853307 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,78.47528856878577 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,90.04217171134675 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948963,-97.69417931352872 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.006433000791361492 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.05499033482699429 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.06215963370744791 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.06370960704601503 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.20024488882111247 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.20118154846024272 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.22643403312542476 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.28625179144592316 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.31185532578027525 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.3211592581314632 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.32147575742221435 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.35266091667746446 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.3537932995276959 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.38706310697776847 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,0.42769342559967394 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.44706092423125743 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-0.49077061015058404 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.4997956880867192 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-0.5515898391189468 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,0.5678638227439589 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,10.21006613633277 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,102.10176219898631 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-106.81415022204865 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,10.918572955075888 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.097426563553193E-4 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,10.99557428756426 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-10.995701161175589 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-11.38084062932628 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-11.41533082788429 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,11.915001073719907 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.2335136896993952 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,12.566370614356973 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.2925282931792867 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-13.316203792205325 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.353230060111572 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-135.4509345121375 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.3573120542096633 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.3834773512448537 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.3889162989808783 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.4029404671077182E-15 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-14.137170463368667 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,14.429204418266444 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.4695370132490275 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-15.68981665486966 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.569189180131742 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267939105 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267946417 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948521 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948832 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948912 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948957 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.570796326794897 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948972 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948972 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948974 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-1.5707963267948977 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948977 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.570796326794898 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5707963267948983 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5707963267950802 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-1.5708001414921624 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,1.5708001414921624 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,15.975130747065736 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,16.252242636655012 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-17.2296230105757 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-17.279247875996546 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-174.35810542872684 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,17.486914558735393 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-19.041839033198528 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,19.350434221379494 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-21.189540571776064 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-21.80172336749075 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2.220446049250313E-16 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-22.707329175416646 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-22.89684731346692 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2.3050107646797215 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,23.56194137973569 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-23.5623042485577 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,23.81238260366416 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-24.118713618336812 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,24.387583886358247 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2526.0824619636323 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2540.7330121616264 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2540.836420970015 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2546.116563262591 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,2590.484150771772 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2595.8888960401255 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-2604.3794252118514 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-2.6130795554016366 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,26.619139390159916 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-26.945256612267187 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,2.8375349589991754 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.845130209433965 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,29.845618490353036 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.415926535905133 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,3.177839572216243 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,31.887866667031716 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.2270204773189173 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-32.98672286269282 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,32.98672286269282 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,32.98673812148189 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,34.59002986822956 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-34.99862848711653 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,35.33763943276396 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,35.897775623083305 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-35.939086511612835 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.12831344722115 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-36.86350876951976 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,3.7826027930361477 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-37.86918381216221 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-38.35999992560766 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-38.7333477757867 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,38.73594804897894 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-40.84222561287205 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-42.411497301222724 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-42.42712582346221 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-42.6581210148955 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.266828126109587 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.3120843661932575 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.523955354734944 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,43.9822971502547 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-43.982297151599084 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,44.02409159031349 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-44.08618303026265 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,44.23526082789734 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-44.46856025866925 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,44.50471797161896 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.5271432237731695 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-45.34115436123996 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-45.47830259268182 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-45.48839639167066 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,45.55309347926664 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-45.55309359626137 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,45.553337617711485 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-46.63685164380833 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,4.71238549295024 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.712388980375384 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-47.59820963340006 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,48.69468616044412 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,4.921365914474933 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-4.982184161742083 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,50.26548245743982 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-50.48033254697373 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,51.836278784231574 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-52.11281705193225 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,52.46584463191314 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-52.55563941274715 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,52.67923871706212 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-52.86043689853426 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-53.86183779277733 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,54.985192141757686 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-55.63748949367677 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,56.075989291279456 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-56.54866776461995 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,56.89849751474086 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,57.99251437671371 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-60.05554564847093 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,60.52400185223664 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,60.831814006390715 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.129902032899717E-17 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-61.438274218719776 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,61.91263699212342 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.283185307179121 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,62.831853071792054 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.283185307184007 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-63.2907555642724 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-63.31421443177648 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,64.12691854280395 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,6.42928906531488 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.429719071670967 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-64.40264939859074 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-64.41542434042897 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,65.39611088119605 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-67.54423852994107 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.54423852994107 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-67.54423857797863 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,67.54424208247572 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,6.776263578034403E-21 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-69.18846363917814 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-69.5868479458982 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-69.72823087365984 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,70.32468074561729 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-70.68583470562692 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-70.68632298702038 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,72.29667879282866 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,72.7840563660653 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-73.29043496471782 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-73.82742735935979 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-73.82742735936013 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-75.39822368615175 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,76.29838478867097 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,78.37895433360123 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-80.23342660860875 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,80.62464645696292 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,83.2522053201295 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-83.2522091348377 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-8.32836070764766 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,83.83112665301657 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-84.42655060803064 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,85.85993499988213 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,8.618036247045396 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,86.3937979737193 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,86.66551668498644 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-8.716746291381657 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,87.40697068466996 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-87.96459430050797 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,88.48672048002999 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-89.16646175023352 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,89.17449349541226 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,89.74585164356469 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,90.08539009036907 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-90.51394512812598 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,9.11518595127363 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-91.53084888710937 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,92.67697975865941 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,-92.67698329583239 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,92.67893657114419 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,93.62945263027092 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.24777960769492 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,94.24777960769728 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.3727796076938 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948966,94.39533245644134 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-94.68955222513587 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-9.568194347862985 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-95.81857593448869 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,98.96016858807847 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,99.07623949074156 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948966,-99.31820474465339 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948968,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948968,-105.2433538952532 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794897,-28.699019769971024 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-0.563642789888955 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,100.5309649139831 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,10.632044259204028 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,136.6340683129026 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,1.5707963267948948 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-1.5707963267948966 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,24.9890745225688 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,26.50079796651046 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,3.832415408185168E-5 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,3.8624759182205306 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,42.411497322335784 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-4.406388751482709 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-4.712388980384661 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,-52.113656199224465 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-52.69466848655836 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,55.39073920050771 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267948983,58.87127349233771 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,-70.40293619236027 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267948983,72.5019999858224 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949019,0.0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,0.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-100.0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,10.733902262277354 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,1.570796326794914 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,21.922818701338528 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-39.714386257736535 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-4.712385474040131 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949054,-61.26105323304026 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,6.4296026731611855 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-7.033015651702563 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,73.43870444976501 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949054,-96.90667854865049 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949125,-0.21319141463072733 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949197,0.5707963183853916 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949197,-2623.5393482531663 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark01(-1.5707963267949268,-11.541552596837576 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949268,4.714342108776465 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267949308,4.712385541968631 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326794948,1.5707963267948966 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark01(-1.570796326794992,-1.5707963267948972 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267950227,-51.62514349324836 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267950895,0.0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963267952252,171.21680080316156 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark01(1.570796326795616,-86.57981193884807 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963268811305,-10.995570765324791 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963269113872,-36.12831199404314 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark01(1.5707963283479613,0.005543502669794815 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark01(15.7079642720119,-8.959726186529128E-4 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark01(15.707965175297598,0.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark01(15.708024303110601,-100.530961663716 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark01(157.08252145370201,14.4314672076748 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark01(1.570931061393596,-1.5707997673138365 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark01(15.723588267948971,-1.5707963267948966 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark01(15.723588340807023,-2.6512601264881236E-4 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark01(1.573291301958788,117.80972416076534 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark01(1.5733381194134304,-89.53539085711736 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674143295,-1.570796326794948 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark01(1.5734261674337258,-1.5707963267948966 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark01(157.3730749296535,95.5544311742971 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark01(-1.576041463698175,-136.2246478796539 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark01(15.776558319920213,1.5707963267948948 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark01(15.78686156665465,-19.50145937372831 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark01(15.800608158296043,0.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark01(-15.803631879255107,-58.795844029456255 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark01(-1.5827066591823125,6.429203701433331 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark01(15.881954805427053,-2512.006589341097 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark01(15.918418456634118,1.5707963267948963 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark01(-15.960421303878134,-72.71883379520888 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark01(15.997655459851757,-1.5707963267948966 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark01(16.010159372099785,3.975192089477545 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark01(16.014149432894087,65.96480177930263 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark01(-16.015332179809114,18.6392095959375 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark01(-16.031019299449014,1.5707963267948972 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark01(-16.058405943535245,-87.11021452674805 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark01(16.108155295608423,-74.87267146467356 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark01(16.157580925341577,0.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark01(-16.175443787434705,-135.36291286730506 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark01(161.76922984646905,122.53088024878517 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark01(-16.201215301851477,-13.636101459932746 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark01(-16.23132561570684,1.5707963267948966 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark01(163.35929336595214,0.01876482108611962 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark01(-163.36288773862938,-100.53087891708472 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark01(-16.337620849190507,-0.33841812437091506 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark01(-163.378487723655,0.0046322724878261464 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark01(-163.65799839602286,2495.6681724207856 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark01(16.370761527780026,-61.69491307985497 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark01(16.38935730392072,-40.70691003732341 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark01(16.394420235874552,-42.41167807683443 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark01(16.408422016808856,100.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark01(16.4121977105851,-59.088355622104565 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark01(-16.421989604660325,-20.666821170713348 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark01(-16.4691015101416,25.58198045137881 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark01(-1.6541437898390967,-1.5707963267948966 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark01(16.54427253055477,-1.5707963269930652 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark01(-16.546277265952284,-1.5707963267948593 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark01(-1.6579333212480638,-17.278759607592008 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark01(-16.708139500290173,1.5707963267948966 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark01(-16.714928193591902,79.35860092503685 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark01(167.38074848641872,172.41305132846162 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark01(-167.51503996267655,31.539045296211228 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark01(-16.79475455591345,67.6281455056735 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark01(16.81397835247897,7.491682224409596 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark01(-16.830408750942723,48.15697950481237 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark01(-168.3155116889874,-8.398259020334578 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark01(-16.84855132769279,64.87908720836026 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark01(-168.51811843120996,8.828993919844629E-15 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark01(16.93028587078058,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark01(-16.935991830754887,75.02741923740146 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark01(16.95130248650089,19.409138041544292 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark01(169.6409878019612,18.84955592154013 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark01(169.64127981765847,-39.26990816989185 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark01(169.64598701626443,-1.5707963267912903 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark01(16.971370272266885,0.5150888212056063 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark01(16.98092856106024,0.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark01(-169.84545001358708,36.37067477661458 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark01(16.996074548277363,0.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark01(-17.05212727070216,99.13342282939126 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark01(-17.09597541809282,45.37129338058067 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark01(17.231063448888676,-1.5707963267948966 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark01(-17.276281669299408,4.712388974431678 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark01(-17.276423575380733,-60.018173304520175 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark01(-172.78239381867618,4.71238898037409 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark01(-17.281389435382756,-1.5707963267948966 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark01(17.293066024328965,-54.55704007398741 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark01(-173.21078429506701,-2535.6929448358796 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark01(-173.64341240425867,2.2610096959919446 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark01(-1.7392880825458263,0.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark01(17.4535085260986,0.16277951484325634 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark01(17.460970993982144,-3.328734437849974 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark01(17.463421798628985,-1.7038839311902763 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark01(175.92902050313424,-62.83185306725457 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark01(1.7763021943100057,-16.505579166790188 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-11.60508157746014 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-2519.179544623814 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-33.92832675586332 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-38.92054168428396 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark01(1.7763568394002505E-15,-87.626973997923 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark01(-17.780516424541972,67.39419013814839 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark01(-17.80523585206106,0.0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark01(178.96178113603844,95.51660929078342 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark01(17.904719296803975,-1.5707963267948966 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark01(179.0707812536911,-1.5586830057954813E-20 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark01(-179.2480031510159,0.35290440667338885 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark01(17.983055678447172,-98.56957831385522 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark01(-18.01072068656015,-8.963256471654859 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark01(-180.64488079667782,4.712388980384297 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark01(18.06538555102164,-0.013911740450401505 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark01(-180.72231071077533,11.5876721139348 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark01(-18.079334358550227,-3.312461756337285 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark01(18.15255914741472,73.58682833811437 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark01(-181.778307250107,-66.13567042851672 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark01(-182.03198251681974,-36.177726420059166 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark01(-182.11542380415372,-1.5707963267948966 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark01(-182.22092540319514,-45.55642863019159 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark01(18.22585709773574,-44.88134110934159 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark01(-18.296773748307587,0.003922387027767433 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark01(-183.24049350337225,79.97925355230424 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark01(-18.32986041484517,-1.570796326794896 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark01(18.35730874349562,39.547311528839145 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark01(-18.397414062350894,-0.28605099086299834 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark01(-18.411394498415973,-78.96036317595085 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark01(-185.35325316693235,-87.96459429994184 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark01(-185.80167064968327,0.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark01(185.94218383270893,-79.70330040427692 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark01(-186.51718948837762,-32.83158216088785 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark01(-1.866673536528304,-0.23765053874322117 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark01(-18.674040475833678,0.0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark01(-18.711295456282333,44.932176078065176 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark01(-187.22658149445303,4.8373889803846915 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark01(18.759717115412002,1.5707963267948966 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark01(-18.844524250988503,-0.15643513017594046 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark01(18.84955592153425,54.977871332351135 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark01(-18.849555921538755,0.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark01(18.849555921538755,-73.82742729807903 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark01(-18.849557741475596,-1.5707963267948966 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark01(-18.849559399358554,81.68113451980498 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark01(18.849710096252092,0.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark01(-18.849800062163762,-23.561925392738686 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark01(18.859382633462424,100.3906513087875 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark01(-18.920559882845744,37.88151345164076 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark01(-18.96012953290078,55.695465913648434 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark01(18.966289517857476,-94.7598787231956 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark01(18.974537493821426,-0.5046505223140808 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark01(-18.979405966923494,15.391445286938165 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark01(19.015813824673828,55.1495398121304 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark01(19.145127241272625,29.246522435482024 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark01(1.9174937004135444,-22.365884856188416 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark01(19.299703695327764,-0.9779952009411123 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark01(-1.9349905078658907,-49.19657343287896 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark01(-19.375720513090698,-75.84482409740096 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark01(19.41632732498146,-25.986805340499203 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark01(19.418813174100812,64.34670654768432 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark01(19.42044490092738,-59.63824396905151 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark01(19.458775374276463,0.0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark01(19.467827518012335,-66.4662837240815 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark01(19.5643531783822,-1.5707963267948972 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark01(-196.03027276441634,2.5083539842399247 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark01(19.612995436436435,63.43976798005494 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark01(196.16652984062227,0.028276003761741393 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark01(19.657142792737865,-6.012916351596687 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark01(19.673562262728012,-1.5707963267948966 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark01(-19.6741289166938,0.0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark01(19.700549350775916,-95.56789433185841 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark01(19.715504879821037,-72.5887363258604 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark01(-19.811099379832058,0.0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark01(-19.824207733855673,-136.17589826645417 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark01(19.888700270169007,-0.5464307958939251 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark01(19.94610793502597,11.74551403804145 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark01(19.947095297933345,-65.50322591751771 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark01(19.980474340457377,-0.2950974594156411 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark01(-19.983928887150498,95.35637838840051 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark01(20.027667338218656,-0.14900416791458695 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark01(-20.046731104119225,-44.40306712325284 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark01(20.14150210539205,78.21460228611784 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark01(-20.154441576584983,1.5707963267955982 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark01(20.170419593550392,-0.5707137479293812 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark01(20.264211156286876,-71.61272404545741 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark01(-20.3007499737152,0.33873015001923956 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark01(20.356241254108255,-0.06514885713484897 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark01(20.41772240769473,-1.5707963267948966 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark01(20.417722407695454,1.5707963267948983 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark01(20.41986565257164,4.712385591157819 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark01(20.420357362439244,-4.71238545828419 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark01(20.457440598034793,65.8340779841507 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark01(2.046430096949166,89.28648624617063 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark01(20.475213109946434,100.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark01(20.485096385690994,-1.5707963267949019 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark01(-20.503672536483723,-86.39379842812475 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark01(-20.535926651053543,-1.5707963267948966 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark01(-20.550255010017636,-0.1512190384689468 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark01(20.555900947341428,1.570796326794877 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark01(-20.559291881708177,88.59687139863985 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark01(-20.615065639869012,6.431286386654251 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark01(-20.693644998221657,0.09779193975672228 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark01(-20.708138829671817,-73.47804214291878 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark01(20.718786151306126,-1.5707963267948966 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark01(-207.34560341817638,-1.570796326794897 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark01(-20.74242160635777,0.5680287818459121 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark01(20.769722861319185,0.0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark01(20.85100671798499,1.5707963267948974 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark01(20.854989679785547,0.31648939506831164 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark01(-20.855824544458017,87.96838521928689 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark01(20.880755984654883,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark01(20.88207967900692,-1.5707963267948966 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark01(-20.901991012275943,136.32038424884047 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark01(-2.091546531663397,20.793011303120515 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark01(20.924442381636055,-54.159702255540026 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark01(-20.955229501070832,-0.4424438589709331 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark01(-20.966319608058594,45.328487711978056 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark01(21.034014678820817,-75.04160435078855 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark01(21.163240055501788,0.0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark01(21.313637387669925,-1.5707963267948966 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark01(-21.32108045226695,0.0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark01(-213.63065561903917,-6.712430857653189 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark01(-21.444693545540474,14.57250996458788 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark01(21.45469265343334,-1.5707963267948963 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark01(21.468445349508343,-90.86373456753928 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark01(-21.49953633267488,8.14590094788052 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark01(-21.502275421517126,4.734596193760868 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark01(215.19646693026266,-1.5707963267948963 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark01(-21.53268843737777,-62.22476090723438 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark01(21.54953178373043,-0.40188166113235013 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark01(21.562460196696716,-57.202250235840324 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark01(-21.621193621045663,64.74195366653132 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark01(-21.672836018174856,-37.65490858570577 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark01(-21.683361291723067,-91.01210448382686 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark01(21.727379760095403,1.5707963267948966 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark01(21.763070421259975,-40.26405952976465 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark01(-21.76317003055088,0.00794754067728915 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark01(21.791106264983284,62.8724804478 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark01(-21.79554115593707,-14.429606300464187 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark01(21.81534067541138,93.64735597774984 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark01(21.863120337184554,16.228887947830238 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark01(-21.879288693409535,91.07506691079362 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark01(21.879805691435223,-10.836448403377798 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark01(2.191346529654396,-105.24383606058336 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark01(21.930808561681612,88.3136491803827 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark01(-21.96451334895744,1.5707963267949054 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark01(21.973575541166937,-87.99405809316873 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark01(-21.99114505295495,-2.1910109365306297E-16 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145109672942,75.39791040793232 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark01(-21.991145703257885,-12.565569268690723 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148237121013,0.0024992741552524247 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark01(-21.991148574902457,25.135394672897696 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark01(-21.991392715753555,0.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark01(21.991392793052462,-3.2169459387561684E-4 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark01(-22.05803525540901,1.5707963267948974 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark01(-22.129268400372055,100.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark01(22.13209317357925,1.5707963267948966 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark01(22.203700676081397,-23.239978313447835 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark01(2.220446049250313E-16,-0.5707624555158756 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark01(-22.335020091106188,58.0961530868837 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark01(2.234957237679967E-10,93.37413608049953 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark01(22.369497591087267,-0.017295415200810765 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark01(-22.4849815010349,45.39170467566424 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark01(-22.504307562613974,100.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark01(-22.5088326061389,-2541.225396265217 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark01(-22.52110602694937,1.5187518612272584 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark01(-22.542293287853752,98.85484497245966 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark01(-22.571208632385947,0.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark01(22.587669798182127,0.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark01(-22.666245300427775,-91.5762690557674 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark01(-22.793390578485386,-0.36725617426705626 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark01(-22.840527188210885,0.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark01(-22.866358744979976,37.72837571402869 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark01(2.2922185665789527,83.27378445840074 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark01(-23.004978723966047,-93.69985659493163 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark01(-23.01692460600391,-70.391594446669 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark01(-230.9070597077122,130.37609169811907 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark01(23.141129156202503,1.5707963267948966 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark01(23.23927206429649,-6.127221545247181 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark01(23.279450574218078,-0.011030394533812321 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark01(23.348440858166445,-1.5707963267948966 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark01(-23.373550286731664,-42.60558323141847 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark01(23.42218726924671,-93.1731096082366 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark01(-23.457544565531308,-94.56575239084597 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark01(23.555051966171803,-1.5707963267948968 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark01(-23.559314954032534,58.11946409112652 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark01(-23.559315061284536,-1.5707963267948966 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark01(-23.55995720531809,1.5707963267948966 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark01(-23.56048290429992,-1.5707963267948966 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark01(-23.564574742559,1.5707963267949054 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark01(-23.708266061479037,67.39613035470367 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark01(23.710760972256082,-27.85488904463365 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark01(-238.59350865659022,37.11327477275206 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark01(23.951130376223677,6.123234031171636E-17 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark01(24.032234538994985,0.0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark01(24.065717602735248,15.514754220918894 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark01(-2.4089681578792153,18.896190273430705 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark01(-24.22699871971679,0.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark01(24.25435005478297,0.032783684449066416 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark01(-24.255590121365245,-13.67199459314061 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark01(24.309318497771308,0.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark01(24.397198211880337,2661.6556666576917 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark01(2.445493596538711,-14.643743930245208 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark01(-24.458820491975853,55.363288498290345 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark01(24.491685155130725,46.13528984452691 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark01(-24.501088505990214,-13.171924582538582 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark01(-245.04544988401685,3.539046881402578E-5 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark01(2.465190328815662E-32,0.0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark01(-24.699302183949275,0.9520606452447832 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark01(-24.73252405938338,-18.105133210492767 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark01(-24.750297570626827,-17.465955465676398 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark01(-24.77767150682422,-0.6657212059736736 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark01(24.81934338053631,66.36325056072238 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark01(-25.057501131631284,1.5707963267948966 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark01(25.132739152211638,-69.11342341283347 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark01(25.132741209863045,-105.24334801098452 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark01(25.13274122871777,1.5707963267950191 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark01(-25.132741660242374,0.0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark01(-25.132802576472763,6.224576121291729 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark01(-25.289054943693785,-38.713698691422834 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark01(25.39270390206037,58.83580830436773 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark01(-25.419310517530686,-1.5707963267948968 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark01(25.565448010555997,100.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark01(25.58493000480114,-136.59690154822948 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark01(25.59338791374455,163.67766977298203 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark01(25.617828674705756,1.2287981832966588 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark01(25.689078929474142,-32.298526184447866 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark01(25.71156486804827,1.5707963267948966 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark01(25.77241183660894,-1.0346293266009539 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark01(-25.774120385237687,118.65061069964244 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark01(258.10817901892347,45.17682107465626 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark01(25.812170334598907,162.1728084188451 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark01(-2.589919100735159,57.52744413101007 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark01(-25.912089195846846,72.99199889263781 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark01(-2.603766890883932,-57.504799161127586 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark01(26.12200702548103,-73.30785991664281 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark01(26.127725661989576,-0.03951905722387845 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark01(2617.6011429868618,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark01(-2620.9558647779454,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark01(-26.249374676271216,77.9531147981351 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark01(26.250278167448272,40.73743916025444 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark01(-26.279213569021692,73.82742735959464 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark01(26.28370335390489,-4.837403366111121 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark01(-2633.036350977886,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark01(-26.34083739756699,0.0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark01(2.6341709064437993,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark01(-26.37597282589053,-2621.6548266563045 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark01(-26.396099659104607,36.250280893104986 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark01(-26.41344865828863,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark01(26.41762453648147,-47.705176646565135 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark01(-26.424641261995802,-24.805515691905455 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark01(26.452924708556953,4.7436389803846915 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark01(-26.471440882442167,-6.617845843108277 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark01(26.522370183254537,33.104758301238974 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark01(-26.544103535346068,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark01(26.579053082554438,-91.91029064203155 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark01(26.617871740769885,-5.7517401580560374 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark01(26.677383011980698,86.39413705511765 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark01(26.70090915243547,80.1106126627254 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark01(-2.6701205336075304,-44.696494284827736 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark01(26.703510215740195,58.11946427950115 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark01(26.703567376027088,80.1106092443005 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark01(26.704202579954316,70.68583799037859 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark01(26.70573919062763,1.5707963267948966 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark01(26.740312109317998,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark01(26.823909484740387,6.462893775295556 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark01(26.85670264788564,1.5707963267948966 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark01(-26.859223361393674,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark01(-26.871952949217864,-1.5707963267948966 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark01(26.872693989986228,-1.1182095456405774 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark01(26.947905482975386,36.12831551633592 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark01(-26.953006149019515,-3.6861713993294813 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark01(26.959118741413825,-37.146318360192424 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark01(2696.8230905739356,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark01(26.979566594270203,43.07046825515735 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark01(-26.983443824920503,-31.957499100506112 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark01(26.99643598776333,-4.45383142066521 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark01(27.06059569655868,-83.189092750594 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark01(-27.067467304093043,-40.59244961104294 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark01(27.0952479128388,-0.24500549488370732 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark01(2.7134389740598275,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark01(27.168688291264665,0.0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark01(27.19118593581356,-95.70174756343579 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark01(27.203285604972177,0.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark01(27.308777709076228,1.5707963267949054 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark01(27.509797966863598,4.439460090450339 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark01(27.532924766890197,122.28530099099319 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark01(-27.60942705777213,0.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark01(27.626836860997006,92.8629722790237 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark01(-27.64702528363911,86.52418895277128 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark01(-27.65064854463357,-1.5707963267948948 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark01(27.653494312094068,20.056982948601473 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark01(27.67752462552251,46.90611236219959 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark01(-27.705697615955806,-1.5707963267948966 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark01(27.74668155944054,0.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark01(-27.753364893474448,31.16347763052559 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark01(27.77270002177403,1.5707963267948968 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark01(27.849051594802447,0.9429266536474933 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark01(27.85168481197489,0.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark01(-27.87968193153732,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark01(27.88109772248187,-2547.1782048266577 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark01(27.903469175566364,0.009847885664689384 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark01(-27.931972144443417,32.23909720478623 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark01(27.958530684572786,36.71915865888144 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark01(27.99736753615907,0.003702335873825352 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark01(2.801175314290197E-10,53.524124127061484 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark01(28.012558188938822,-1.5707963267948968 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark01(28.01917594231621,17.025472480670288 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark01(28.045586165661376,14.029047106454946 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark01(-28.059319439204334,-56.54871836095372 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark01(-28.09142041592966,1.3747086369373624 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark01(28.098318115645053,-80.11061429577431 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark01(-28.098863130591624,48.08975871063188 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark01(28.10116859727296,162.9780882482009 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark01(-28.127895242308803,-10.291152613789642 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark01(28.148755859735104,-100.81066651124667 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark01(-28.171917367891595,-1.5707963267948912 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark01(-28.18761521373127,-96.52747464170561 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark01(-28.190416579566126,-43.44581417166709 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark01(28.24200178581525,-100.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark01(28.264645498391488,-14.429330339885759 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark01(-28.273117401172897,0.023243339071850375 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433036427501,7.035126507151985E-5 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark01(-28.274330527924892,-6.282629956437193 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark01(-28.274331015630004,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433208797147,23.561942799806033 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433233971065,43.98238994587411 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark01(-28.27433380564801,31.418527333704546 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333834218947,6.224326489820672 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333879607585,-6.224002057361399 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark01(-28.274333882308134,1.5707963267948966 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark01(28.27433559977596,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark01(28.276287054960864,-1.5707963267948966 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark01(28.32580429809761,0.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark01(-28.338532363076865,-84.29691489227964 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark01(-28.345217136544846,-70.09312185656069 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark01(28.373848865651013,1.5707963267948966 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark01(28.381410347547146,51.35235554520199 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark01(-28.391498740340598,74.55480676997983 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark01(-28.574325549013963,2565.365122520957 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark01(28.596737649490215,-74.80497174876042 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark01(-28.61640714048454,-2632.0253822394807 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark01(28.77312496907814,-1.5707963267948966 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark01(-28.802300781893052,0.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark01(2.8919743610451546E-9,-21.984855579186966 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark01(-28.944091256675655,-1.5707963267948966 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark01(-29.087753691238134,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark01(29.11797325077405,-59.28577912078513 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark01(-2.912167895425341,-29.6640128998106 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark01(29.139847870501825,15.22668291099805 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark01(29.26028991575714,-97.37977234564272 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark01(29.299385132724705,-0.5705065632669625 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark01(-29.369411115637973,96.25028474442286 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark01(-29.39293187283278,1.6332972042631686 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark01(29.408288766634925,93.37186984573046 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark01(-29.439523102882916,0.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark01(-2.9462343953101424,-52.48408773304922 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark01(-29.530662020297015,0.039099137037987036 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark01(-29.547618632633117,-1.5268514446147412 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark01(-29.56491228287709,43.300944615179304 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark01(29.6583368223495,16.768295735180857 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark01(29.66266807759186,1.5707963267949054 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark01(29.688192092430036,-45.29979768686871 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark01(29.701256825217474,-73.28228208875029 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark01(-29.722311707970164,-31.80633900311807 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark01(-29.844773532283366,4.71238553052606 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark01(-29.845156554690433,-73.82742383812271 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark01(-29.84615366160726,1.5707963267948966 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark01(-29.846502452101124,-29.845127689442876 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark01(-29.848100920937014,71.65980757169999 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark01(2.991289344971679,0.4999753534827583 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark01(-29.947272103684796,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark01(30.0392334757569,84.94411118719717 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark01(3.012768770386188,0.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark01(30.14237215493231,-1.5707963267948966 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark01(-30.15600357870356,2604.0090466302336 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark01(-3.052197120603651,-43.58398301781036 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark01(-30.616100431947913,58.275247809813905 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark01(-30.75915326439811,157.3348943870029 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark01(-30.865422947487616,-2659.6394577528386 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark01(-30.87342980997174,120.01074723269967 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark01(30.901152285449825,90.78625148105166 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark01(-30.916683357324032,71.92522128733964 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark01(3.1035329788316715E-5,-6.712388980384697 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark01(3.1179522021686212,-75.18035832734171 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark01(31.22952276639731,-69.11503837897546 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark01(-31.24570838895336,-32.74861309980006 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891313503055,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415891317576485,75.39823676018008 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark01(31.415903762606312,-7.716406296978376E-7 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark01(-3.141590919883521,-94.24964660447277 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark01(-3.141591034546885,12.564813060423747 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark01(-3.141592008803669,31.415926549607466 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark01(31.41592301487376,81.6814057292914 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark01(-3.1415926535896057,-48.69457710384917 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark01(31.415926535897928,1.5707963267948966 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark01(31.415926535897928,-23.56194490192002 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark01(-31.415928031114444,-50.26541985138312 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark01(-31.415929238614172,37.69894976001432 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark01(-3.141601863730732,81.68643108694158 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark01(-31.41650006030692,0.0016198976824027423 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark01(-3.1417272807883965,25.132702310629416 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark01(31.42729381451212,0.5705708083113264 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark01(-3.1435457785903207,69.06174563313235 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark01(-3.143547882023557,43.992836773204594 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark01(-31.44717653594877,-106.81420769326365 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark01(-31.447177128849273,-12.56636923771629 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark01(31.48194514826697,-42.94965442855465 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark01(-3.1494051535897936,-43.871470532813625 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark01(-3.150685947414903,-68.9800905071117 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark01(31.54417716530313,1.5707963267945608 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark01(31.61274878598951,185.45967131046 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark01(-31.625386557939066,13.154545437167656 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark01(-31.62619336243897,-1.5707963267948966 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark01(31.80937594647054,1.5707963267948948 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark01(-31.829438686505412,0.2402192300411506 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark01(-31.849987845342255,94.34153468692713 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark01(-31.859200629931436,62.040709778649074 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark01(31.91457230038983,-31.82937747388233 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark01(31.941716256444572,-0.556672365764885 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark01(-31.958971382391184,94.01647462390278 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark01(32.08509539805366,-14.429206335160437 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark01(32.28483535982238,15.089483171863325 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark01(32.29694828768906,0.0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark01(-32.302756026354245,-82.36578509587481 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark01(-32.3104235166342,1.5707963267948966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark01(-32.32900356623118,75.12086321970764 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark01(32.3386235748867,0.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark01(32.352605947421516,64.24260281791805 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark01(32.3709628069781,-2584.6140010265167 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark01(32.43382594270392,0.0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark01(-32.44189401500436,-36.12831551628418 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark01(-32.48844804018718,61.06904390231017 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark01(32.66310456261186,-34.81697938966247 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark01(-3.2665927975638174,-93.99398810086254 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark01(-3.266661417782513,-63.125025445240034 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark01(32.667608559829375,0.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark01(-32.679267950877396,-1.5707963267948966 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark01(-3.2688115699988707,0.0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark01(-32.72233919565219,14.43186945545149 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark01(32.73264033007905,-11.225413733321679 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark01(-32.75422765075879,1.5707963267948966 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark01(3.2756488674302897,-0.3063344551233852 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark01(-32.7752351546074,-88.04511674422835 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark01(-32.80132472650649,-98.3981084660716 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark01(32.88678650317067,22.17203122713576 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark01(-32.98038639129457,0.0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark01(32.98589547060721,-1.5707963267948966 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark01(-33.01069082139887,-45.08658540575241 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark01(33.175412998233355,34.03993949679608 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark01(33.25785302313783,36.16485437535171 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark01(33.323697181468845,75.66190661183612 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark01(-33.37393110853317,68.13092019373825 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark01(-33.53672491186455,-27.579172726754123 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark01(33.53926505785815,-6.59383009072188 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark01(33.70308792864196,-52.1347597515899 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark01(33.71995621009461,-1.5707963267948966 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark01(33.72393753611385,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark01(3.3984806664834935,107.61046556471177 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark01(-33.99095561093294,58.48340253704444 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark01(34.05039394481798,0.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark01(-34.20928659418358,0.17961543989426182 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark01(3.4299053017943013,1.5707963267948966 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark01(-34.3087090104988,66.5440158118652 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark01(-34.31062592080913,1.5707963267948972 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark01(34.403529744924725,-44.543494679728944 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark01(-34.49903809571005,-1.5707963267948983 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark01(34.5567228365546,-0.04003852122587345 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751566730222,138.23007465527152 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751566885673,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751569873448,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark01(-34.557515880569795,81.6820380630202 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751669941444,102.13301153308461 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark01(-34.5575186975743,-69.1174470132335 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark01(-34.557519100870586,-1.5707963267948966 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark01(-34.55751942799641,0.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark01(34.557522335360616,-43.98314054481887 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark01(-34.56533168948773,0.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark01(-34.59676562433174,95.56537800773688 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark01(34.62655513257501,0.0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark01(34.664411797308645,1.5707963267949228 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark01(-34.68118636225377,25.681432449974267 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark01(-34.75505264406871,-2.7575594272409774 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark01(34.75740394500764,-71.52062279842568 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark01(-34.77179854514083,0.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark01(34.84922892316237,71.46663402225717 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark01(-34.93089665492208,72.32791385900853 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark01(35.049389151942144,-1.5707963267948966 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark01(-35.11542448459355,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark01(35.131221253548425,26.11748345254196 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark01(35.13352154628163,1.5707963267948963 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark01(35.207160239073616,-66.99999922586444 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark01(-3.539051970989276,5.372143663919981 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark01(-35.415643297092075,1.0739071391835384 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark01(35.46898237833304,-0.44362494475340514 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark01(-35.50144195275919,-3.198329956589064E-6 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark01(3.552713678800501E-15,-1.5707963267948974 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark01(35.53170644854123,0.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark01(-35.532574811614055,39.09677767695226 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark01(-35.609924231317464,-0.37703644106519363 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark01(35.6264139551877,0.1682211014089603 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark01(-35.72543100804021,0.0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark01(35.74843427094572,-28.70327835274746 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark01(-35.78384840444295,-17.28169429502156 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark01(-35.810418638503805,-1.5707963267948966 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark01(35.83712668222768,0.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark01(35.91155952705614,0.49999999892666996 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark01(-3.5957330541427917,-5.3083568036459114 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark01(-35.99732109521143,-71.00819088926427 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark01(36.01547363084313,19.542347730190926 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark01(-36.09542010057689,0.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark01(-36.12568567564372,1.5707963267948966 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark01(-36.125685675644384,-1.5707963267948983 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark01(-36.125685675647155,1.5707963267949054 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark01(-36.125945575271125,61.261056547025376 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark01(-36.12831540990315,-51.836282273620625 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark01(36.36089455716029,-12.598532269883052 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark01(36.47267810482242,50.62047851388371 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark01(36.48224502625942,29.845130209103036 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark01(-36.588000594370484,-81.91642387920731 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark01(36.589363698375905,0.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark01(-36.62080409726522,100.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark01(3.6635427804815066,-107.3229714835782 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark01(-36.64848331116176,-5.2474107321318195 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark01(-36.70638492165541,-1.570796326794813 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark01(-36.8225183537631,-61.494610291120935 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark01(36.9894077511904,0.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark01(37.05707117712069,-1.5707963267948972 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark01(37.09200959829428,-24.933243377067456 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark01(37.16486163586984,31.5175746256149 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark01(-3.736261318277669,-63.947311654575316 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark01(37.371811611795266,31.41592653589793 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark01(-37.41812232520026,74.73770980237956 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark01(37.436081097737855,91.1732059227636 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark01(-37.49239307188851,14.429972460285086 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark01(-37.49824751960497,-92.84289282119278 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark01(37.65305802837667,1.5707963267948966 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark01(-37.699111843077375,0.0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark01(37.69911184307751,1.5707963267948972 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark01(-37.69911196659381,-12.507325788389279 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark01(-37.69911411041507,6.281625380653274 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark01(-37.69911412043614,0.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark01(-37.70106506099658,-0.005187442684508958 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark01(37.70721185873344,0.1273756700706645 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark01(-37.714736852340465,-100.53109062955738 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark01(37.82644888546628,-1.5707963267948966 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark01(37.89425300192397,59.19550110019199 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark01(37.91937587052183,1.3122605760176071 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark01(-37.94343231635442,-51.22802091097323 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark01(37.94480759118895,37.36206352242982 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark01(38.02808323342886,-95.60829326542961 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark01(-38.03058036545936,1.570796326794898 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark01(38.04188466285524,44.1396115737891 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark01(-38.05255494772626,-1.2147569452627636 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark01(38.122115230067806,36.405195925003966 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark01(3.8129795296830196,2560.4810604381337 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark01(-38.204236900689594,0.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark01(-38.262564069584656,38.612901639943715 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark01(38.26617267476525,-13.655965214622979 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark01(-38.27424015464405,1.5707963267941594 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark01(38.285071292977904,-20.87744668537141 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark01(-38.31527993043224,-0.3977500611869831 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark01(38.33613428548179,-42.808030019588884 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark01(-3.834081352041192,36.498240393375 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark01(38.39830373990098,0.0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark01(-38.41278968069284,-58.00940114701134 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark01(-38.44545995650657,-1.5707963267948966 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark01(-38.45875759543955,68.18983130212789 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark01(38.53069673668724,1.5707963267948983 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark01(-38.65424654524165,-2.7104327886799515 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark01(38.76196264286342,0.8024516557950534 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark01(38.82169206695993,0.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark01(-3.8888701843551288,60.808550424089624 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark01(38.9188151708895,-88.25505215414577 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark01(-38.936485499965826,58.791063826200876 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark01(-38.938806351760455,39.95448346228477 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark01(-38.96430300265741,134.9301099903733 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark01(39.061624137900786,73.84456474454817 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark01(39.066332603899895,-2.0669169994354917 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark01(-39.168901968836686,-41.574685446610985 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark01(39.23561164315963,-100.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark01(39.26990816928146,205.77405320144055 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark01(39.283705703694295,-24.632455732549246 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark01(39.36747567152028,91.08140610898023 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark01(-3.9614775718260375,0.6329578193837531 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark01(-3.9646208871281488,-2618.992760420276 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark01(3.9712270896502644,5.910745524936928 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark01(39.81575042696257,-1.5707963267948966 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark01(39.830979772400866,-31.54570994980439 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark01(3.9875755825422345,0.002573210104814877 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark01(-40.03464932553355,48.69546811307723 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark01(-40.06985244685613,-38.23951606028619 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark01(4.017200527545044,-92.6769832810088 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark01(-4.036210956355163,0.0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark01(-40.469793650325286,-0.15729818135832013 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark01(-40.47286167371355,2618.9797764313016 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark01(-40.49395234042357,-100.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark01(-40.54466636290015,75.58466178841559 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark01(40.591602222726834,0.0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark01(40.71151641481519,0.0744124509281251 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark01(-40.84070449666277,174.35752061444364 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark01(40.84070452646967,6.2240791309549826 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark01(40.840705410031404,43.98455707638513 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark01(40.84070799905029,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark01(40.84070801552168,0.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark01(40.84071975545638,-1.5707963267948966 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark01(40.84071978649509,-1.1078186098400529E-4 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark01(40.8407263360255,-2.0588177053299092E-5 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark01(4.085774498746602,-14.486489480646139 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark01(-40.968206889893025,0.0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark01(40.98587141891133,0.1553434375997398 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark01(41.02031181949986,-1.5707963267948966 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark01(41.0258992828696,99.71194709919541 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark01(-41.02884015432282,32.037484546250795 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark01(-41.04777347548458,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark01(-41.136863293625765,31.399707136353385 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark01(41.14179834035529,-1.5707963267948966 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark01(-41.17040380262991,-6.4310924494279655 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark01(-41.183332963858454,35.16574830302528 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark01(-41.25785621521572,39.19983835175767 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark01(-41.26440081682033,1.9453744519889682 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark01(-41.27903366511761,-33.34150521531072 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark01(-41.29856486258596,-17.247354083182586 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark01(-41.307645935888765,1.5707963267948966 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark01(-4.131761937695458,95.6975180875733 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark01(41.364456434917884,-81.72501107747068 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark01(-4.141206647908875,-14.137166941155371 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark01(-4.141507226388021,-149.22565102969364 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark01(-4.141585413209749,29.84512977023739 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark01(-4.1415877169211015,67.54424205108984 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark01(-4.141589451376601,-32.986846307444125 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark01(-4.14159121705404,-10.99555780667755 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark01(-4.141591451597427,4.712388980384688 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592472901642,54.97785864251514 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653586669,-10.99557397319474 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589222,1.5747027122199073 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark01(4.141592653589794,30.909179049560638 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589795,43.20035402845231 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653589828,-95.19515420160718 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653590038,32.6423233043543 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark01(-4.141592653591591,76.74178261084819 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark01(41.42791344326061,1.5707963267948966 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark01(-41.49052309152634,-7.622086427400909 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark01(-41.495203965488756,1.5707963267215244 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark01(41.5508601635747,43.81624839760579 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark01(41.61227363988468,-32.94072370959749 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark01(-41.635031031572424,-1.5707963267948966 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark01(-41.74530893030055,1.5707963267948968 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark01(-41.77515663101805,-81.44924098689677 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark01(41.87401492979302,55.00108631393053 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark01(41.88013878310579,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark01(41.90232569436279,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark01(-41.932875329573186,-81.59077422292884 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark01(42.049346802566646,-16.87283858564838 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark01(-42.09505959355893,29.845130278046526 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark01(42.12376666429367,55.48019844991489 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark01(-42.12822527049771,-43.30617552681474 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark01(-42.18582216381073,-1.5454367189185167 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark01(42.18656231856244,-59.690260418206066 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark01(-42.18976634500545,100.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark01(-42.193683852244135,59.38205452785205 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark01(-42.202927007298996,1.5707963267948966 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark01(-42.23582041191192,61.276448549769725 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark01(-42.269900724542836,-1.5707963267948966 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark01(42.281500454578236,100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark01(-42.29930392907768,-90.98563939432505 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark01(-42.30672611760495,-4.8373889803864705 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark01(-42.394545778659534,-79.89820526119429 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark01(42.404146372887,-24.401516382386617 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark01(-42.40892948403969,-36.12831536272838 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark01(-42.41001788917076,-73.82742497300694 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark01(-42.41028652684875,-42.41149816960257 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark01(-42.41050791636458,67.5442390472424 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark01(-42.41148113676725,-89.53547029669662 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark01(-42.411495100327514,45.55309532182053 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark01(42.533795252693295,-18.640847396677145 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark01(-42.53650082346221,-1.5707963267948966 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark01(-42.54897461762681,91.55068118155594 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark01(-42.56284109743157,136.55369634000482 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark01(-42.5652354043921,0.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark01(-42.57102810398103,48.26067974933832 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark01(42.57931577629164,1.5707963267948974 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark01(42.59550924445793,-37.62314269755518 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark01(-42.630961867027615,-83.31063452077201 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark01(42.632126459022075,-16.63434649516436 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark01(-42.632720976655335,-1.546425028285989 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark01(-4.263845940279314,2208.437463331342 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark01(-42.65069026432356,46.66766978969613 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark01(42.66771666673671,-15.304416164832048 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark01(-42.68153765610669,0.016881112380733837 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark01(-42.70822101081584,0.0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark01(-42.71071822359462,2577.8496996363187 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark01(-42.728570064796955,4.837388980384691 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark01(42.73303211689114,94.10923781861351 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark01(-42.73397363429588,70.04777226517675 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark01(42.75213251133043,49.35349244735755 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark01(42.78291107820679,-7.125136138910364 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark01(-42.789848953468955,-92.80838655528045 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark01(-42.83215276415037,1.570796326794973 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark01(-42.84589035256364,-1.5707963267948966 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark01(-42.84720620341318,-8.135217387659781E-6 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark01(-42.85611607106266,-53.40707511102649 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark01(-42.86627643625698,-72.94490056106622 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark01(-42.875790872685386,1.2423634533504782 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark01(-42.87849898922788,-42.1916102457891 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark01(42.89657529239565,-1.5707963267948983 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark01(-42.89662063674869,88.29834613403202 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark01(-42.90444561563946,-8.524716126821389 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark01(-42.91840222592924,-0.006480597150115113 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark01(42.93464625555324,-1.5707963267948966 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark01(-42.94016247428907,-24.96128160693472 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark01(-42.94805588259038,-0.5785185779908915 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark01(43.12106226796706,-77.00825810428545 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark01(4.336570108617849,76.22591111184283 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark01(-4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark01(-43.41004082665992,0.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark01(-43.47105209525821,18.615627856819273 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark01(43.498275946306705,8.306090883150247 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark01(43.61200199827016,-75.39652815540558 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark01(-43.63702143842676,-1.5707963267948966 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark01(-43.66152706516414,-88.18546769787486 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark01(-43.66603935604405,167.31362577400552 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark01(-43.782006690882255,-2604.914396302266 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark01(-43.799600798546805,0.468793217158448 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark01(-43.80469897170596,21.85477650495895 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark01(43.82165973240538,-1.5707963267940137 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark01(43.98229362803631,144.5132613174275 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark01(43.982297149757045,6.201474986827144 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark01(43.982297150256564,-1.5707963267948966 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark01(43.98229715026665,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark01(-43.982300646056466,-4.152623980835246E-15 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark01(-43.98230477965646,4.712388916896553 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark01(-43.98281137485037,1.5707963267948966 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark01(-44.04311715636793,98.42214714831516 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark01(-44.04479715027291,-1.5707963267948966 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark01(-44.12780288320721,-8.27659466244694 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark01(-44.13155120976933,-5.231292491272072 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark01(-4.413379310482874,-1.5707963267948966 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark01(-44.164907096516124,41.16633702292927 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark01(-44.17673828741999,-1.5707963267948966 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark01(44.247364181314246,-47.23133477905215 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark01(-44.27254069732223,-1.9313721101827764E-7 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark01(-44.39321824641894,17.279027060975523 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,-14.429338624691646 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark01(4.440892098500626E-16,-16.859754814271554 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark01(44.44802119054603,18.207400734807905 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark01(44.50523857775494,0.5402522720499845 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark01(44.64500660763138,-11.390505774517395 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark01(44.66045447991268,-1.5707963267948966 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark01(44.69461418239973,13.728042818470712 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark01(44.69579477456898,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark01(-44.77462754259433,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark01(-44.80665845752142,0.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark01(44.814102797070085,0.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark01(-44.87012992318891,-1.5707963267948966 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark01(44.89923844050516,-114.75967054901338 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark01(44.926636495288776,1.5707963267948966 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark01(-44.93780696666154,-78.50950412616854 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark01(-44.955143103066405,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark01(-4.5032423368647585,23.583737444623296 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark01(45.03731382662112,38.31696832681553 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark01(-45.09930873010746,2.6011831894458908 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark01(45.12428140003503,0.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark01(-45.16278979052038,1.5707963267948966 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark01(-45.17307242131443,-90.40750238117188 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark01(-45.238923721831796,-74.80421301662446 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark01(45.25805912266832,94.13876133974348 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark01(-45.26642367827306,1.5707963267948966 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark01(-45.27070242958339,74.62188627216973 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark01(45.271188087549405,68.07440315815614 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark01(45.275325386326855,79.94383291816686 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark01(45.30556284765325,90.77937556950747 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark01(-45.35108305874068,54.70095427733315 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark01(4.540254301963316,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark01(45.50454220806691,-32.534999497363756 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark01(45.54958362262404,0.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark01(45.550673150111905,73.82742693150175 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark01(45.552515288706694,136.19839579858674 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark01(45.553093345901495,-130.3760931307949 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark01(45.55309337309557,14.137170463390992 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark01(45.589393684538635,0.5585425647735965 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark01(45.63221226732941,70.6853275264297 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark01(-45.6585342813416,-0.14852295497980494 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark01(-4.572043379645374,10.995520733469585 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark01(-45.73248296915431,-1.5707963267948966 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark01(45.89947682261578,25.813391592585333 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark01(45.92782504873111,87.10091557965524 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark01(-4.613035838627993,-4.717318746596468 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark01(-4.613144958313626,0.0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark01(46.300926985249845,1.5707963267948972 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark01(-4.632852507522753,61.26105674500096 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark01(-4.632939385615427,10.995574287276593 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark01(-4.633286633052972,95.81869800480456 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark01(-4.633383280522823,-73.8274273590366 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark01(-4.634020826659714,-80.11061188906469 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark01(-46.35980982450296,-0.48078497094593803 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark01(46.37281550783942,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark01(-46.50465372588313,98.53736894050974 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark01(-4.652637512666051,-73.82742611906876 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark01(-4.6528623459680345,-45.55333761791469 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark01(-4.653197381232648,80.11061266653971 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark01(-4.653765680719335,-23.561944901904752 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark01(-4.653848727232707,-1.5707963267948977 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark01(-46.61269620700929,-92.15861522029824 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark01(-46.62388330817623,0.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark01(46.76346685760075,-96.48149939796289 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark01(46.80686218183173,0.0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark01(-46.82627974494512,0.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark01(-4.691850207483582,37.17796879203445 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark01(-4.6935050456060186,-16.748175354840065 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark01(47.00134524547466,0.499625863340941 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark01(-47.01000341743489,-96.95367602807612 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark01(4.710497304730282,-1.5707963267948948 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark01(-47.12357621912147,-86.3937979737193 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark01(-47.123886356794785,-87.96423033190392 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark01(47.12389202977719,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark01(47.1248663663469,-1.5707963267948966 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark01(-4.713022724424908,29.845126905506934 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark01(-4.713449714989325,-1.5707963267948966 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark01(47.13951496857472,-6.223896630252415 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark01(-47.14250647780524,-31.754234097529952 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark01(-4.714778140867796,-23.561944292105128 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark01(47.157555122484204,1.5707963267948966 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark01(47.16230917054653,30.05244905544997 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark01(47.16274218030682,1.5707963267948968 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark01(-4.734483924498761,87.73306615237323 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark01(-47.4419081110271,135.5839192539417 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark01(-47.493373915973876,-42.64560561541793 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark01(-47.519968881094826,-56.07771431978339 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark01(-47.53413591612621,1.5707963267948966 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark01(-47.55422301259395,10.941370212452568 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark01(47.723758018191376,-70.26416696626828 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark01(47.83417003840388,32.52120983185726 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark01(-47.86354461397984,-35.08175767132316 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark01(47.870829056537005,47.565662330953245 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark01(4.788943870127852,44.04852871088437 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark01(-47.940460405516056,-3.253973071492196E-4 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark01(-47.96526377564208,-1.5707963267948912 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark01(-47.987746513173605,-38.50655344965197 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark01(-48.08872981995596,-93.51815308776183 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark01(48.11781901587457,2508.180353558256 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark01(-48.132185874734375,63.88988795271763 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark01(48.19407457771341,95.3739289130057 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark01(48.23066795548468,66.59706190814089 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark01(-4.824472537130745,-43.328647161801385 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark01(-48.26276558908078,-0.017439552459427583 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark01(48.3435319271689,-84.1255625471376 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark01(-48.42518393040358,-1.5707963267949054 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark01(48.43773884189568,-18.446009464390528 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark01(48.45681929356354,-90.54387166662465 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark01(48.46716370451139,-79.95506903014874 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark01(4.853123954823218,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark01(-48.5848783653178,-17.016594203473296 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark01(48.593053720522704,-33.2084670377877 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark01(-48.601498969797056,0.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark01(-4.861211783215832,3.0690287472693717E-6 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark01(48.619342664892656,-0.017550704884987972 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark01(-48.62656620400465,1.5707963267948983 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark01(-48.631612823571615,-6.979178833861109 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark01(-4.866584325702448,1.5707963267950094 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark01(48.681469156276194,-6.431709507817257 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark01(4.868746339644559,0.0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark01(-48.69205694263976,98.96016858634657 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark01(-48.69468614826818,124.09260322724398 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark01(-48.695170740535964,-4.712386528704348 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark01(-48.69522464833458,-58.119467166053866 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark01(48.70921725301619,54.31969717962072 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark01(-48.71222425262533,-1.5707963267948966 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark01(-48.735048039966,43.20344225667401 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark01(48.74234584483867,0.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark01(48.77652229938109,-44.28054312928992 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark01(-48.77953474874015,31.738886606803987 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark01(-48.84056334011218,-0.49990283621116266 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark01(-48.869615307247926,1.1039876915805675 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark01(-48.928890514204085,-28.345468556235616 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark01(49.01999847924671,0.5382247007569095 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark01(-49.077594811175196,0.0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark01(49.07828425064144,66.14050393082587 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark01(49.089067994270806,-54.56464389674458 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark01(-4.911153973609311,-47.78095107733162 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark01(49.13218648847482,0.014129041440236582 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark01(-49.31807645685375,-87.80294586148216 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark01(-49.37838802165622,-53.08609424647924 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark01(-49.41922239170274,55.135992746316134 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark01(49.59552276677056,1.5707963267948974 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark01(49.60600497917292,-94.4493949361246 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark01(-49.61334956533409,19.648367993797468 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark01(-49.7209680463591,43.10596414254652 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark01(-49.72971568866406,-0.07382509677325248 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark01(49.73623986333906,-1.570796326794897 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark01(-49.75850389920093,0.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark01(-49.77595693569303,63.60298490685461 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark01(-49.80484505155343,-1.5707963267948966 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark01(-49.82345484823667,-68.90253156719189 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark01(-49.824077491324346,120.73099061762181 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark01(49.824124894323305,0.0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark01(49.82433381593156,0.0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark01(-49.849868636654264,-45.40862143364637 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark01(49.85283021531498,-1.4908016315753922 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark01(-49.85586691202003,-79.88665221338763 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark01(-49.86667654982266,53.94027566090031 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark01(49.87120353065802,41.05904089993555 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark01(49.88401684267507,-73.70188124636617 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark01(49.885679213943845,-1.5707963267948966 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark01(49.90549144869908,45.00401367632591 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark01(-49.90837338921248,-3.2507987549474002 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark01(-49.91738278396844,-87.43547643009086 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark01(-49.92168167732502,-113.85618384085328 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark01(49.96515120468473,-6.284821326789274 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark01(-49.96964460591392,-1.5707963267948966 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark01(49.97190971193547,2622.5358087674504 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark01(50.02260499615512,-12.74509743302697 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark01(50.02288976582676,-0.0130620161532365 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark01(-50.02529933042947,-64.23075909678315 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark01(-50.0280620423811,-39.182992490414776 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark01(-5.002947786318316,62.81699124724315 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark01(50.03394419230303,1.5707963267948966 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark01(-50.04167079594337,-74.00160037833027 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark01(-50.048354967801714,-182.20886768031244 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark01(-50.05735632100885,22.826460961896373 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark01(-50.06374891739009,0.06288125516963246 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark01(-50.09639981699638,0.0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark01(50.09991523292507,0.26282220025615577 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark01(-50.14453978003651,-0.8721548363035151 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark01(-50.147715943357674,-19.18177747969429 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark01(-50.15613841235585,-88.43612580932222 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark01(-50.163899547865775,17.326976584616645 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark01(-50.16896266825596,-38.0911862358168 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark01(-50.17298072873082,-6.429958929041452 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark01(-50.177751549724064,-62.410121427435776 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark01(-50.19433086320355,50.644825115521776 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark01(50.19931999536875,-5.122044550188028 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark01(50.2088736214603,-10.255181162794784 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark01(50.20945097404535,48.99745764125126 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark01(50.21739098150047,-40.29786278800245 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark01(50.21838704312674,-6.429240178332262 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark01(50.22735960554951,0.0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark01(-50.22799459369971,-44.26364754872855 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark01(50.24615009467078,82.71814929729538 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark01(50.24670580828342,26.415523325664353 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark01(50.25411381511482,0.0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark01(-50.25483672115167,0.5308021396009481 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark01(-50.256152865621964,-2528.488662487463 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark01(50.26243774616387,-31.81427506868536 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark01(50.26547316206518,-0.001105733211654276 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark01(50.2654789351972,50.26548245743302 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark01(50.265479062784294,18.849074759122253 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark01(50.26548139544727,-87.96240039521011 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark01(50.26548185687017,-61.26105674468743 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark01(50.265482110938706,-6.223020048941072 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark01(50.265482453927454,-6.282310691511927 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark01(50.26548245742265,1.5707963267948974 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548543825105,12.567386963287628 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548627216306,7.915319048570397E-7 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark01(-50.26548774288232,-10.995033571385648 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark01(-50.26560455033779,-6.223881336407533 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark01(-50.2664590199367,80.11060503909161 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark01(-50.29673245746371,-100.53096491454214 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark01(50.307706421008554,0.5538759304975783 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark01(50.324942808502946,0.0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark01(50.36845471338852,0.9709688073151823 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark01(50.5828531532207,18.707719102146683 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark01(50.611024411969424,1.5707963267948972 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark01(-50.71805660768912,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark01(-50.77334415120648,-2476.958843068775 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark01(-50.822521195616254,0.0019113214504036893 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark01(50.82860460394054,95.3336180045706 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark01(50.83259406025433,0.8744621826372464 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark01(-50.84014616332482,2671.8681680509617 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark01(50.85501429850009,1.110707107611072 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark01(-50.85607090411399,-37.352196915458165 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark01(50.87333130457222,79.52884107210369 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark01(-50.89225068325476,1.5707963267948968 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark01(50.90640087826458,1.2887290210340805 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark01(50.93688683726475,-1.5707963267948963 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark01(50.94853813087626,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark01(-50.96051166372369,13.859615405697667 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark01(50.98512289023441,-98.37922861002902 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark01(51.012058323185926,-46.65497917706239 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark01(-51.041885024385806,0.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark01(5.104429479204683,-31.744441223767566 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark01(51.08136061705471,-57.62902282024365 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark01(-51.15960148854744,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark01(51.17562938216784,103.35406794376473 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark01(-51.21772377194003,-1.261546120817453 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark01(51.30760508897495,67.54424205218058 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark01(5.131496679329487,-25.37835362937355 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark01(51.31748142697262,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark01(-51.38951386131152,-0.1962118596190493 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark01(51.40061445811142,7.685718079669968 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark01(-5.141592653589795,17.278759594733476 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark01(-5.141592653589913,-108.30762685301937 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark01(-51.42709731567689,47.829318003471705 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark01(-51.45215027701214,1.2814822516191864E-15 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark01(-51.4903784448125,5.43112451509333 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark01(51.68358418432271,30.250062417481928 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark01(-5.170730698026603,-1.5707963267948966 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark01(51.83366175652774,-92.6769832469748 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark01(51.834834760481044,1.5707963267948966 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark01(51.83615918034652,73.8274238472168 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark01(51.89718254859898,-4.714342105384691 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark01(-51.917998922506605,1.570796326794897 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark01(5.193655780686282,85.36316731739296 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark01(52.139603218227876,-0.48498684671097797 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark01(52.345308863842924,32.85959837478508 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark01(52.381254357319136,77.18908886135654 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark01(-52.39070308126195,-88.50061897757084 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark01(5.249737929428335,58.598993539685125 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark01(-52.50034712011799,44.345847229641215 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark01(52.55142227178772,17.780200623683303 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark01(-52.66176421165727,1.5707963267948966 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark01(-52.763209062170205,1.5707963267948966 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark01(-52.92762500588988,1.8617366579563903 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark01(-52.976471710289744,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark01(-5.2979347053952015,-61.80808446025206 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark01(5.310900165704716,-16.16406142602699 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark01(-53.12366382679101,21.32301060571787 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark01(53.12571666409599,-3.9763207489782353 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark01(-5.312796377335539,-51.660480199498885 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark01(-53.148350493248685,45.38589904131021 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark01(53.27804058790396,-11.258135123422548 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark01(-53.33433602466337,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark01(-53.343292764383634,59.352878733446914 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark01(53.399345510893994,-31.8874191535889 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark01(53.4006741926579,-6.169966342384653 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark01(-53.407071588787,0.0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707494811098,31.41335880563073 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark01(-53.40707511102647,-1.5707963267948966 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark01(53.407075588397426,-158.66605403177812 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark01(53.407075621381615,88.08959441569041 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark01(53.42685899341692,-65.79349641193829 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark01(-53.486097314747184,1.5707963267948966 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark01(-53.507472671182256,-0.010060416227528563 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark01(-53.53725274914134,-54.79667583806555 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark01(53.55397982181839,-81.12988586283154 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark01(-53.56341909481075,58.015641309078006 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark01(-53.581523378135955,-19.578330426549456 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark01(53.765984913593,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark01(-53.78576300513451,-73.34949081743429 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark01(5.395502338868965,-2.631682099684255 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark01(54.140063799229615,1.5707963267948983 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark01(-54.14116874909876,-5.2123889803846915 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark01(54.16879532564505,0.056264102879909496 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark01(-54.18886377408265,-46.82142663596336 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark01(-54.19769632491336,84.18890624839182 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark01(-54.20187237321259,-1.5707963267948968 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark01(-54.25399496275084,-1.5707963267948966 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark01(-54.31969070912257,-29.308586796361453 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark01(-54.367680976051446,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark01(-54.40194889253838,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark01(54.44482405795114,-1.5707963267948968 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark01(54.465595330070954,0.162134001984927 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark01(-54.49820689589095,19.797870074540896 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark01(54.5358165377811,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark01(54.56669896485367,-92.4476472903009 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark01(54.57297312600841,-122.92770886549725 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark01(5.462253640808299,6.37401151333863 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark01(54.80940307746266,19.915213535404902 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark01(54.81236542721689,-2.126623205535097 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark01(-54.83987770587473,-1.4178956792199946 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark01(5.488037309521655,0.0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark01(54.88202332404941,-98.84215567638338 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark01(-54.90210116534761,0.0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark01(5.4918799369933495,-14.429203673207283 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark01(-54.942124437384344,89.53579837149158 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark01(54.972490291193424,-1.5707963267948968 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark01(-54.97589046752327,-1.5707963267948983 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark01(-54.97787981116692,-10.995570765565997 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark01(-54.9778942052204,36.128311994916984 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark01(-54.97859159141603,-1.5707963267948966 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark01(-54.97917130375682,45.553095345081125 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark01(-54.97971054241967,-42.41149906159502 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark01(-54.979853150764946,-92.67698177073717 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark01(-54.9804908071055,1.5707963545315826 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark01(-54.98049958930542,-1.570796331276572 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark01(-54.98050127832307,1.5707963267952607 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark01(-54.98050127845963,-1.5707963267948983 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark01(-54.98576266904459,-1.2807084303141538 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark01(54.99100299285266,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark01(-55.04127536430717,-1.5707963267948974 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark01(-55.05437696271799,1.5707963267949 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark01(55.064645024411874,86.10059226717038 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark01(-55.09120555638722,1.4108978942780812 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark01(-55.091268494067094,0.5707962204279619 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark01(-55.09556761902235,18.908081704634625 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark01(-55.099790857317245,1.5707963284532938 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark01(-55.108952947669195,-64.98626460661349 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark01(-55.11564393741919,-0.540565685343677 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark01(55.116215726997105,-48.92030207434779 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark01(-55.119613967214356,0.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark01(55.14453441299625,0.0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark01(55.14525031460782,4.502226565082205 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark01(55.149783500027,-1.5707963267948966 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark01(-55.17892383862991,96.53216133352066 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark01(55.18742136181435,8.787375882209929 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark01(55.20247684344841,5.908790442459207 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark01(-55.202858332017676,1.54559133362651 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark01(-55.20751706156277,0.0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark01(55.209338416623574,-2178.2971277973597 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark01(55.212742674154896,61.79554980238814 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark01(55.21558868628516,-54.5154783405016 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark01(55.21616503161833,14.084473188357958 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark01(55.219615996084286,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark01(-55.22737828588939,-73.53982180720465 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark01(-55.229488248643975,2559.953648075716 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark01(55.233508163113214,-1.5707963267948966 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark01(55.24266362179574,93.60741957149153 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark01(-5.5243946500348216,52.41418212984675 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark01(55.24520194364416,-12.157782737339577 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark01(55.31168338582748,-83.99917662588545 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark01(55.32337318944587,68.74503811831741 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark01(-55.32464527910237,-78.97925057644638 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark01(-55.38021398831323,0.0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark01(-55.40286922901103,-1.4817183230055058 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark01(-55.40740387600754,71.73889900892374 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark01(55.41589279040626,1.5707963267948983 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark01(55.421328998797144,53.96255398780307 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark01(55.42497836335326,2606.2622937136093 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark01(-55.42509838109034,1.5707963267948968 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark01(55.453498926171505,-1.5707963267948912 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark01(-55.460972837444245,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark01(55.46569858416018,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark01(-55.47843398478807,43.31554073605221 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark01(-55.48206625496077,1.5707963267948966 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark01(55.511604450904336,2.465190328815662E-32 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark01(55.52264121650927,-65.2298881465485 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark01(55.54499685570667,-1.5707963267948966 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark01(55.578225945572996,-45.0827303830516 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark01(-55.693416932934895,1.5707963267948968 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark01(-55.98598275775152,95.33320008210346 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark01(55.986725285669706,1.5707963267950102 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark01(-56.00073240140616,17.739648202748853 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark01(56.0079224198572,-75.3982176671471 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark01(-56.016172474734226,100.0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark01(-56.01943701674996,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark01(5.604039587287161,97.40517440284529 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark01(-56.059763716181116,4.713990415727555 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark01(56.08015037248543,0.9446380478878648 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark01(-56.082822685011564,-19.975092946627644 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark01(56.110899495828285,-4.712389208558904 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark01(-56.113331153974976,-74.75281317130519 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark01(-56.11420352260092,67.00142891279265 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark01(56.12083141479826,19.468312024484135 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark01(56.12212860479981,-69.66870904227463 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark01(-56.131413720406655,0.0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark01(56.13377202589746,98.71964800602206 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark01(56.166378139680944,-16.52987214480217 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark01(-56.1666777860799,-114.17265154915776 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark01(56.17003048044995,34.399235778283824 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark01(-56.17569649533706,0.0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark01(56.177871482141555,-76.29380467704225 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark01(56.183461698527736,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark01(56.18541449471289,-2125.5224849305937 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark01(56.18860754622446,-87.56381226145717 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark01(56.19732309914112,-5.420049977184377 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark01(56.205652786385,-0.2429507064876936 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark01(-56.2135382455927,90.16056396093691 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark01(56.21512589443254,-1.5707963267948968 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark01(-56.21889961185676,0.0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark01(56.238807549723106,5.594225898226451 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark01(56.254243881046115,30.76790195401735 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark01(56.28698171938768,1.5707963267948974 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark01(-56.28829554891772,-80.17222635909414 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark01(56.29231306565442,95.92190124643739 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark01(-56.31343585961961,1.5707963267948966 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark01(-56.31520967581998,-2682.823281786779 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark01(56.342213668826176,45.27026100169972 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark01(-56.36138147530594,-54.09143693203659 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark01(-56.381810534361776,-1.5707963267948983 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark01(56.40263017675844,24.99474471761212 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark01(-56.410547939372776,-100.0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark01(-56.43325573532941,44.33272188692147 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark01(56.436833843599885,-18.319198542904118 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark01(-56.4537204202765,157.77889324879948 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark01(56.487292476747214,1.5707963267948968 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark01(56.49327636010512,0.4286305160170894 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark01(-56.50279335478019,1.5707963267948966 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark01(-56.50588381491103,-2.472816399096706E-5 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark01(-56.50692150405408,44.28849207996609 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark01(-56.51725213044328,-9.294457571612366 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark01(56.53434405829091,-28.56322538095864 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark01(56.54863294806747,23.56122927131449 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark01(56.54865724506742,-0.014358981112966364 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark01(56.54866424237913,43.982297140875396 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark01(56.54866424237946,2.9708044659001494E-17 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark01(56.54866424239553,-31.415925788043833 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark01(56.5486643626915,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark01(56.5486670041938,-75.40054961533126 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark01(56.54866776461427,-5.21238850489053 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866776461591,0.0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark01(56.548667764616205,73.82736294965724 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark01(56.54866776461627,-1.5707963267948966 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark01(-56.54866954371942,0.0018428385664387061 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark01(-56.54867123203482,-3.074378244395356E-4 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark01(-56.548676995565806,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark01(-56.56743001243784,6.205251898649567 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark01(56.578607939847245,24.329989840847404 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark01(56.57900389917543,0.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark01(56.60097938178339,62.34554117391693 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark01(-56.606926787381816,73.98151102300672 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark01(-56.665507488122266,-77.57805085136182 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark01(56.69211479242579,-0.5237707667725326 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark01(56.73319331534708,-30.53214662106167 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark01(56.76663664716164,-27.613062482435538 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark01(-56.785398678909594,0.484161825285396 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark01(56.79548662449121,1.5707963267948966 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark01(56.84289255694544,-1.5707963267948966 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark01(-56.97081753802875,1.1974005253272604 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark01(57.04025802119648,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark01(57.05725867222583,-1.5707963267948966 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark01(57.06705384601452,-1.5707963267948966 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark01(-57.07935376116435,-48.372189762850454 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark01(57.14299378546977,1.5707963267948968 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark01(57.146998626647246,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark01(-57.20187084886624,1.1129384554076505 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark01(57.213231015477575,1.5707963267948966 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark01(-57.22416721897192,0.0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark01(57.251190550841855,-14.42926966542506 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark01(-57.326405216940636,98.90074945216844 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark01(-57.35172067761762,-0.8910676813647298 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark01(57.46276423399493,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark01(57.479229293872066,165.1986156254324 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark01(57.54174604552662,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark01(-57.54417235487179,0.0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark01(-57.61095527320391,-14.429581072999767 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark01(57.63919740894064,63.52280146575508 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark01(57.660139979294655,-90.36014388845717 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark01(-57.70634976980653,67.12038644768654 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark01(-57.71118949501704,1.5707963267948968 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark01(-57.7931695965355,-20.815369941221192 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark01(-57.796132740762076,-1.5707963267948966 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark01(-57.798228548561895,1.5707963267948966 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark01(57.813540357868916,2.070796326794976 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark01(57.82603540443688,-9.228215508344022 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark01(57.84824357885955,41.26558860241593 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark01(57.919696496988415,-1.5707963267948963 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark01(58.0239869135325,2483.3814197332586 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark01(58.05720478472669,1.5707963267948966 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark01(58.084192955597416,-50.28627540782611 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark01(58.09811387823356,-2716.6111591907843 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark01(58.116834250772285,1.5707963267948966 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark01(58.11766845188637,1.5707963267949054 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark01(58.119463262973724,36.128312097843896 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark01(58.119464082718906,-80.11060914430053 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark01(58.19900987362732,16.343031267281845 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark01(-58.213951349011396,0.0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark01(58.52131848554487,47.340181510604964 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark01(58.55971203141527,-68.33639009120122 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark01(-58.609519375011395,63.11601661736063 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark01(58.69873002232106,-1.5707963267948841 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark01(-58.762115782451104,-98.44399281901124 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark01(58.98469108211613,1.5707963267948983 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark01(59.01554341631493,-59.135743600414514 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark01(59.37482262488726,-30.60629782445926 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark01(-59.38061167875803,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark01(59.39353085370303,0.16834488829691452 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark01(59.56132773702737,-100.0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark01(-5.963385960965482,18.84955592153876 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark01(59.63820682483606,-98.4403400649687 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark01(-59.67852405346608,-13.522462288928125 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark01(-59.69025613528296,-6.223872595005008 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark01(-59.69025779732207,-56.54735431341528 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark01(59.69025835007831,0.0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026041820282,1.5707963267948966 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark01(-59.69026041820606,-73.82742735228969 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark01(59.69026194193559,31.41395159791454 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark01(59.6902631743861,-12.567584119273375 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark01(59.69416666841993,-56.548649776479174 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark01(59.70588667994811,0.0021012909729968025 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark01(59.709035915978234,3.872142402958275 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark01(-59.71469768941314,30.917641817894634 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark01(59.72741171298475,69.8494710814559 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark01(59.749585464097976,1.5707963267948983 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark01(59.93016070823202,1.5707963267948912 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark01(59.97391310533569,1.5707963267948983 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark01(-60.04075398754222,-1.5707963267948966 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark01(60.09672131989426,80.858380889105 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark01(60.12660261196495,-1.5707963267948966 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark01(-60.140788800002525,54.45954949807151 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark01(-60.19476029936151,0.36162427245275863 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark01(60.20321226021795,95.98691029052452 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark01(-60.31691754182613,0.4628700978875331 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark01(-60.37241829924025,-74.51294636640229 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark01(-60.422706761478295,-1.5707963267948968 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark01(60.45660529176098,0.0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark01(60.49868914118916,-0.27464038016534487 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark01(-60.55632938751261,-205.9653767809698 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark01(6.056847042997376,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark01(60.574621110568415,-2638.8193683512727 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark01(-60.641029528338606,-50.21082891842879 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark01(-60.711272432321536,-12.427480147074448 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark01(60.72588242435734,-2593.615147406824 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark01(-60.79914447818396,-136.76427122253864 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark01(-60.836054971714645,1.5707963267948966 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark01(-60.85754863197844,-1.5707963267948966 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark01(60.894997728422055,2495.2882558423885 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark01(60.95071906653391,-95.32110484022056 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark01(-6.095756846224346,-71.6230475149375 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark01(-60.99385242676747,0.0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark01(-61.0556086136484,14.430798660403411 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark01(6.1086703588551075,37.882361863718444 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark01(-61.119696461997464,-1.5613240585067296 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark01(61.16440480942447,-1.5707963267948966 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark01(-61.17710173962047,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark01(61.18736854707109,-96.77898132461429 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark01(61.21476366096613,0.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark01(61.22262779489151,-0.5674642004791571 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark01(-61.26105673507864,-67.54423853533062 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark01(-61.26203567415557,10.995573432586243 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark01(61.279496025095206,0.011728277169704098 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark01(-61.36220500062006,-72.3552407937482 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark01(61.4105676841279,54.977871437821385 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark01(-61.438312521802345,-4.743638980412005 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark01(-61.44145711283369,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark01(-61.519528001875855,1.5707963267948966 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark01(61.61619518577487,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark01(-61.70854460970101,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark01(-61.82316922009154,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark01(62.086917479256385,0.0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark01(62.2119953896709,42.50215093242032 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark01(-62.22243557505388,-9.114216440832678 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark01(-62.296160134650314,-14.669600702228747 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark01(-62.35352566797966,0.0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark01(-6.236464336756614,-0.2964047998581133 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark01(62.484729754429935,-45.10539874210049 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark01(-62.490555385645735,-1.5707963263948659 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark01(62.56887002491626,-1.5707963267948966 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark01(62.58065584633056,-73.63323958878769 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark01(-62.64807774414227,-53.06981508647397 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark01(-62.66772471029047,32.42114770889237 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark01(-62.68897495131526,11.835012731683468 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark01(62.723967735106655,23.93328358328033 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark01(6.283181786158872,37.699111843096055 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark01(6.283181940953883,-81.68087443747905 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark01(6.283181950567574,-75.39877518061371 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark01(6.2831820847423705,-94.24852977641073 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark01(62.83184100192537,1.57080134709168 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark01(6.283184954793619,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark01(62.831849549556374,0.0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark01(6.2831853067180505,67.54423947862624 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark01(6.283185307179056,-1.570796326795068 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark01(-62.83185556100301,37.70052492283081 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark01(62.83204566957964,0.2780111624314916 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark01(6.283246346400264,-12.57265615118288 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark01(-6.283307377492087,-73.82741778529224 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark01(6.283446142834936,113.0905226827897 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark01(-62.845301793124904,94.24777960176202 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark01(-62.85340997747075,-62.69800919888631 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark01(-62.85422127966316,-79.86757797099597 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark01(6.28784990458102,0.09688385066458645 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307179587,0.0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark01(62.89435307179587,0.0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435307179924,75.39814735055155 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435328372968,163.36555436088807 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark01(-62.89435474039127,-0.030354145034409474 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark01(6.291231970810241,-12.652632519938052 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark01(62.91511422460736,68.63094577513533 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark01(-62.92053291012842,-33.85695511803061 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark01(62.96729544464847,22.500988954006672 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark01(62.99552248420853,7.659844973288068 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark01(63.016188238485086,-84.9664092315687 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark01(63.062322311876045,30.087037126994755 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark01(-63.085004136301855,-1.5707963267948966 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark01(63.12030183107947,-8.811333329050385 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark01(-63.130657070700366,-91.30069179889158 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark01(63.17850811246578,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark01(6.327397185303654,-0.2984201439256241 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark01(-63.32860571024479,1.5707963267948966 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark01(-63.38407679583982,-0.7888948823180328 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark01(63.404750209143685,1.5707963267948966 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark01(-63.44685555566705,0.0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark01(6.3456853075434365,-44.31028315554744 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark01(-6.347317965046687,-1.5707963267948983 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark01(63.478593443843785,1.5707963267948966 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark01(63.48582411121739,46.83540173943485 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark01(63.530959751839724,-73.82748842134507 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark01(63.56530361263856,-1.5707963267949054 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark01(63.56570320487692,-19.025671963714046 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark01(-63.57771613552772,-64.70989275840877 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark01(6.364904313849891,-6.429204740790007 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark01(63.65014916813741,-32.58951280949229 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark01(63.66160872786452,56.4733449995164 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark01(63.725122449792394,-16.082696854126894 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark01(63.737849122470806,88.75898850428302 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark01(63.73850786049863,48.696799805009015 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark01(63.75581099960098,198.15681830181146 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark01(63.81099282820375,-21.61527056587778 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark01(-6.3831606398283895,64.71935125922278 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark01(63.87787410284933,1.5707963267948966 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark01(64.03559505713542,61.546769056237196 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark01(-64.04641056333259,66.68040070762501 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark01(64.06782140079491,-16.88435310390143 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark01(64.17595957561156,0.006330511059080182 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark01(-64.2251095400756,99.17939261293577 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark01(64.33186313520709,-36.13081769773278 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark01(64.36082576561483,-70.67140292244441 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark01(-64.36689783444466,-6.42957895269068 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark01(64.40018722778528,-4.712388633545014 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark01(64.40527670256229,1.5707963335241222 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark01(6.442259880250468,0.0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark01(64.51724765032924,6.798161593573312 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark01(6.45915668542862,-5.682476854222353 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark01(-64.66355960501019,-29.173155696823798 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark01(-64.73719859560566,87.85944216644324 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark01(64.7427366852518,-24.129346863982292 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark01(64.75957581189093,1.5707963267948966 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark01(6.482202599649597,-106.94922851169451 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark01(-64.86999250745342,-27.859255299224813 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark01(-64.93189385998448,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark01(64.94141867557951,4.567916116780852 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark01(-64.98232638210027,-2673.4083743615097 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark01(65.01201336803328,-2614.745413857885 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark01(65.04263094393997,-64.18435862523542 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark01(-6.505753863735443,6.4509074970570595 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark01(-6.50867869089388,83.47785032638278 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark01(6.517003083021251,-75.92629873981815 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark01(65.2440785441515,1.5707963267948968 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark01(-65.29884221268456,0.0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179587,-31.42954896995427 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307179602,100.0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark01(6.5331853071808546,-100.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark01(6.533185307181502,69.53797241755397 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark01(6.533307168085546,-44.7012770659184 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark01(65.34469379090956,-39.726825899083764 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark01(-65.43950347575142,-43.405994585562404 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark01(-65.4586084699362,73.32246103524375 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark01(-6.546423815850178,81.3474406642068 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark01(-6.551360093749963,0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark01(-65.62049182740944,48.478743728399564 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark01(65.74112277006572,-0.3919865613812892 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark01(-65.75713224028459,-1.5707963267948966 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark01(-65.79031921069151,-27.00662777793204 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark01(65.82266750311209,5.302951067552721E-7 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark01(65.86845428160743,4.5164459065329225 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344130196137,-139.80087348738766 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344221040997,-43.98239026837203 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344222185325,94.24761077951224 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572268503,6.204474526470907 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark01(-65.97344572464806,14.137197497366698 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark01(65.97344681787933,-12.56419050385013 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark01(65.97344698032472,-0.0021051442558689825 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark01(65.97344924762352,-87.96459423459093 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark01(-66.00465545388298,-60.96683615616062 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark01(-66.01252182527799,0.0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark01(-66.0551103224857,-0.4067132055480479 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark01(-6.606094694269899,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark01(-66.16243060686497,-55.118914429873136 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark01(-66.20928660820292,-138.92774958502363 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark01(-66.25805935940055,7.999064129810193 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark01(66.49252413365733,64.07425312672501 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark01(66.55219656638667,-86.2117193940104 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark01(66.60773516055401,-1.5707963267948966 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark01(-66.62470447137558,50.29157601846569 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark01(66.670952475497,0.0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark01(6.679921026801884E-11,-28.882201658705515 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark01(67.00575957224409,96.17355629983084 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark01(67.02471934996507,139.3880136842429 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark01(67.07110252399838,-6.832334669727786 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark01(-67.09947269430941,25.09833911492834 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark01(67.13719609060294,0.5702185052283261 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark01(-67.15095904194183,1.5209153728950064 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark01(-67.18027988845492,-27.99610010253504 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark01(67.25025622216506,101.09562887314374 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark01(6.726100043796663,5.320630493820453 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark01(67.29936642529617,42.4241478388015 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark01(-67.34182058295654,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark01(67.35045664335559,-137.98380822621843 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark01(-67.4284843050484,-1.2583842892655077 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark01(67.49746965581224,2608.0932124908877 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark01(67.5080832705293,44.432089683811064 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark01(-67.51921101531445,0.0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark01(-67.54161221154168,1.5707963267948966 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark01(-67.54392561487353,-4.7123872517503465 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark01(-67.54435883343035,45.55309469163052 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark01(-67.54687189281873,-1.5707963267948983 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark01(67.63896316643566,-1.5707963267948966 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark01(67.74506766001703,14.429459145711014 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark01(-67.81257449865996,99.08304930483402 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark01(67.83246480764521,-93.97795577193897 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark01(-67.87666991346495,-34.62494262376032 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark01(67.89334549688482,0.0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark01(-6.794694380347124,-76.56686059228545 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark01(6.813704621864505,-5.229094759104579 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark01(-68.14887851239521,66.15165728508043 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark01(-68.17743536268989,0.7395751355139772 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark01(68.19182907684998,-1.9965994862894547 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark01(68.25132174372484,1.5707963267948966 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark01(68.30225841117314,-1.5707963267948966 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark01(-68.36204336666563,88.63479383880127 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark01(-68.58256195465006,13.814027474687736 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark01(6.859472648473599,43.68074690006097 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark01(-68.81741173170835,-0.7859054671599753 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark01(-68.85602387515846,-22.857867597923374 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark01(69.11503541682413,0.0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark01(69.11503837897543,80.11028916962493 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark01(69.1150383789754,6.223564686622119 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark01(-69.1150388847561,-56.54653937305639 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504189287913,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504189868882,50.26548245742717 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark01(-69.11504189871796,-18.849555920108426 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699150397546,-1.5707963267948968 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark01(-69.11699151774683,4.712388978622081 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark01(69.17459690919233,-11.641564587188839 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark01(69.27419186115323,31.98663670794868 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark01(69.33386828556371,-0.4802203014755917 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark01(6.938893903907228E-18,81.6084475036709 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark01(-69.44114838233313,-9.494107596574928E-16 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark01(-69.49072767060059,1.5707963267948983 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark01(-69.58946474629181,4.235913691860077 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark01(-69.641040895017,19.980645535637336 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark01(-69.65291715671574,59.22953250275765 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark01(69.7867672433523,-2640.1665533370315 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark01(69.79206340230847,1.5707963267948983 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark01(-69.81156301754582,94.44271763209079 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark01(-6.985879806215165,-17.27876490987742 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark01(-69.96580359405768,1.5707963267948966 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark01(69.96670852586952,-100.0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark01(-69.99631995969034,1.570796326794897 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark01(-70.06525518787569,14.207141444926805 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark01(70.11411245013468,81.27599267405193 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark01(70.14014003101835,-6.437209301478784 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark01(70.14187059279378,0.0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark01(-70.17849610999744,0.0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark01(-70.17935655915615,24.232384419333496 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark01(-70.19433577532436,-6.238647064475994 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark01(70.1976329058659,95.00239855092039 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark01(-70.2408702888367,89.85415624747353 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark01(70.3034748890618,0.0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark01(-70.33611134592229,0.0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark01(-70.35783678588513,2518.4097980144948 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark01(7.03595221270983,-1.5707963267948968 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark01(-70.50767470087217,52.330776502073974 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark01(70.52475116715934,0.0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark01(-70.53980959869135,-42.01753436975555 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark01(70.54300321329117,-51.65923919124691 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark01(70.61618165816587,1.5707963267948968 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark01(70.68320486513174,1.5707963267948974 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark01(70.68342089513774,-61.261056194977286 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark01(70.68566238190427,67.54423854902923 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark01(70.70443166251016,-108.04450157449536 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark01(-70.72030165802632,38.52039302346677 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark01(70.93047619094091,2625.8946069943995 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark01(7.102694426372267,-50.2631207847961 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark01(7.105427357601002E-15,-12.461728567717174 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark01(7.105427357601002E-15,-1.5707963267948966 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark01(-71.11339570286283,78.15947187303402 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark01(-71.17026424116703,-1.5707963267948966 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark01(-7.127661161670872,-1.5707963267948966 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark01(71.2819559782883,-1.5707963267948966 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark01(71.31112807987549,-70.68273761211825 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark01(71.42910330823523,7.291203789442861 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark01(71.5256141377202,-137.4628068079476 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark01(71.53870892287006,67.89347687395147 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark01(-71.59223961378166,31.770813579692117 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark01(71.61628506600223,-10.917264713704043 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark01(-71.66842271503846,-81.39153758166655 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark01(71.68553670358399,-14.430913615642261 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark01(71.79449429107413,0.0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark01(71.93455881754906,74.36071034517747 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark01(-71.98456652022244,1.5707963267948966 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark01(7.2149976773652895,2616.2821925181834 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark01(72.23381313049043,-90.43356768484212 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark01(-72.25661838521319,-32.98673814541304 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662794691942,0.0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark01(-72.25662846575507,-0.001358040769144491 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663083806221,6.224209150404975 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark01(72.25663103256548,1.5707963267948966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark01(-72.25663117501179,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark01(72.2569038250528,232.4778561076811 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark01(72.30823513614224,-6.4431335394975155 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark01(-72.31972481493558,-38.838218893065346 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark01(-72.33976358612067,0.4103956475036231 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark01(72.34312953183594,-88.3468398545856 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark01(-72.43419856043022,-67.93168922637541 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark01(72.51435834755401,99.33606691600372 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark01(7.273594819997427,-1.5707963267948966 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark01(72.77886795819168,-1.1243716991343496E-7 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark01(-7.290503284899614,-7.758157367839345 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark01(-72.92623811400627,-1.5707963267948968 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark01(72.96747706297523,-24.419143394303546 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark01(72.97544253369028,0.0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark01(73.00250063609138,17.13624931505681 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark01(-73.01680016287082,-77.75239537365275 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark01(-73.13790948149881,-95.6494473592831 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark01(-7.314512118580723,1.5707963267948966 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark01(73.14672315423647,81.21583620113583 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark01(-73.16862728105578,-65.95729882252348 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark01(73.19504095578681,1.5707963267948966 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark01(-73.20226456130547,-92.18952328713634 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark01(-73.24081002475697,90.91451820000071 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark01(-73.24255591813575,55.5938664688535 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark01(-73.2684217107987,-53.77981482814774 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark01(73.28422940686264,-135.37881550653935 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark01(73.28947915276254,58.18987512948311 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark01(73.3136135868692,45.42343382898383 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark01(-73.35294949792191,74.51820265950619 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark01(-73.42401060356276,87.16572270045609 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark01(73.56106841772981,66.51113919543843 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark01(-73.61287334237265,89.01956170286121 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark01(-73.61557101997857,72.5674378254918 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark01(-7.361909730512747,-0.14829342280628097 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark01(-73.63475412306602,-7.885533902538455 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark01(7.370444921284827,0.0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark01(73.75133113531209,1.5707963267948966 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark01(73.76833410737379,30.12269123826158 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark01(73.77246004303545,9.609361472516838 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark01(73.78088041063292,-0.32563467312246847 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark01(-73.82417330342105,4.712396609797165 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark01(-73.82689412761304,14.13717025311787 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark01(-73.82741078274579,-17.27875612683108 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark01(-73.8274273600243,130.37608690229507 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark01(-73.8283957167715,-10.995555181458444 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark01(73.91041087231599,-10.664268126656552 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark01(73.92210145217786,-95.84047517298745 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark01(-73.92400819479374,-50.555584551274166 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark01(-74.12165614483659,36.164816777978054 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark01(7.413715287314801,-76.70406775285763 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark01(74.14377304591466,44.45364208878013 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark01(-74.1534136901671,-87.81691187239923 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark01(-74.17996620062706,89.20095883764847 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark01(-74.18584353436243,-67.60783110315771 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark01(-74.23580177051072,29.213806635009206 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark01(7.434589463583196,51.7495066712889 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark01(-74.4531511522242,0.0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark01(-74.45523180603072,-15.785984709684925 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark01(74.79278093231784,130.35598031399525 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark01(-74.89822414854272,-100.0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark01(-75.1600193118397,-80.11061266887694 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark01(-7.5211806516484865,-14.429204058188482 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark01(75.26726101291428,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark01(-75.2821755679795,1.5707963267948966 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark01(-7.531473159028577,-0.01352008784920094 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark01(75.39822016391555,81.68140899346514 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark01(-75.39822420087994,-6.28075706101452 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark01(75.398238945323,0.0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark01(-75.39823907862207,1.534005878970874E-6 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark01(-75.42947368615505,1.5707963267948966 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark01(-75.46943750214338,0.03976864259653607 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark01(-75.52361847646667,0.0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark01(-75.56309892267801,-2660.7422086282813 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark01(-75.56825275870536,-18.86433577041195 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark01(-75.61391198150264,84.89525743483043 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark01(75.64775738413643,-0.08166675846384028 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark01(75.65633557881891,-1.570796326794894 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark01(-7.565759205306776,-72.43692755605758 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark01(75.67579532908414,0.0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark01(-75.69697733369865,-1.5707963267948974 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark01(-75.7149671726027,-2.6165148796530246 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark01(-7.574910440356362,-17.314304095054077 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark01(75.88791840060243,0.0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark01(75.92032153156686,-2.2710178866302613 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark01(75.98504921128836,79.58708566481002 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark01(-75.98926002800073,98.28740317939904 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark01(-76.13614747029513,-98.49510699710574 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark01(7.615266767761902,-1.5707963267948974 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark01(76.21228813197595,2525.858247247095 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark01(7.622595445800968,-1.5707963267948966 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark01(-76.22687276677644,-122.9689349575076 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark01(76.23669017613278,69.21768082261752 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark01(-76.26272563685902,44.11034589433721 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark01(-76.26415836576605,88.36149532913137 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark01(-76.29070679012565,48.696844088453815 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark01(-7.646190500111942,-29.844720080101325 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark01(76.55996440999806,-38.19896715939763 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark01(-76.62299763005555,-2630.3158220412774 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark01(-76.64685361607113,0.0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark01(76.70049069079312,-8.499297324645497 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark01(-76.84723835785486,-0.13649665889806484 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark01(-7.684765254050821,-0.13574346053384773 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark01(76.9022230936408,-14.261903927083836 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark01(76.96644877971094,-1.5707964806247392 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark01(76.969020390615,-89.53545166281332 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark01(76.9690774240671,4.712385461206463 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark01(76.9711935734832,-1.5707963267948966 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark01(76.97164985358889,1.5707963267948966 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark01(76.9921359053046,1.639599283783351 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark01(-77.03828761170078,-108.93103415047759 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark01(-77.07505384974752,-2490.2983818112148 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark01(-77.10036925624529,-87.89037986892053 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark01(77.11263125121675,-62.36585556797996 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark01(-77.1329150093976,131.32662459795117 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark01(77.14186765250616,93.86363074805067 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark01(-77.16400865249551,37.72658293068087 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark01(-77.16719509735701,-6.874189292710792 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark01(-7.719897480867218,-34.41161524256263 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark01(-77.20751295326158,-22.893565046602177 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark01(-77.20862414294069,-1.570796326640654 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark01(-77.2294618250768,-1.5707963267948968 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark01(77.24434549445475,-17.316431317459543 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark01(77.26829452299333,-1.5263326572039562 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark01(-77.27120760603748,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark01(77.27776199541121,0.0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark01(77.29432861668454,-33.422779698839754 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark01(77.31133859895868,19.57487118737515 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark01(-77.3269577442878,2508.7772648977098 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark01(-77.33050339014054,45.530979783466094 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark01(-77.34205018873773,-1.5707963267948966 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark01(7.743096669264077,17.27875959120506 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark01(77.43466896805685,43.31608817319047 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark01(-77.46104771565548,49.95223017024938 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark01(77.47213938666115,45.54107410052775 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark01(77.47896107365838,88.85467378224646 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark01(77.51008232796741,-14.533402161708892 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark01(77.52974388727267,-8.9252947166963 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark01(7.77110395357923,-23.56194490172173 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark01(7.774771040852683,-73.8274273460037 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark01(7.775292443175623,73.82742735887473 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark01(-77.790301961064,7.105427357601002E-15 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark01(77.79318357219142,0.0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark01(77.90365828172858,-80.22591955503253 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark01(-77.9183009917414,1.5707963267948966 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark01(7.79370492391369,67.54424205217663 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark01(7.7938168864454855,-4.712388980384308 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark01(7.795021199311776,120.95143975194084 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark01(7.7950259751843465,-54.977870275179896 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark01(77.99439621527563,61.97360356924605 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark01(-78.00279572257558,99.53044347801972 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark01(78.02120408848351,-38.80733815183854 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark01(-78.0293513558984,-59.176106672119346 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark01(-7.803661271692125,-16.202356305906648 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark01(78.03863281409475,0.0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark01(78.0737317192553,41.98238230058732 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark01(-78.12685645368947,1.5707963267948966 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark01(78.20378558170012,0.1876902017198817 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark01(78.24513459820412,-1.5707963267948966 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark01(78.2888348168367,94.29523472706295 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark01(78.31820408378425,-1634.7350922837304 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark01(78.40649504961814,76.81387822812323 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark01(78.45453970260138,-1.5707963267948966 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark01(78.47030751518429,0.0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark01(-78.47449463316842,90.27852532621093 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark01(-78.5088357531437,-1.5707963267948983 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark01(78.51595807113071,17.85417225826214 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark01(78.52459595055275,66.26425268901605 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark01(7.853041826066889,1.5707963267948966 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark01(7.853458883473693,-1.5707963267948966 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark01(-78.53980823554133,-5.212388979637512 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark01(7.853981168486225,-80.11060914431181 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981429415825,-87.9629000960253 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981437378668,-31.41766646653088 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981565924276,-56.54898995410996 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981610274678,-0.0025389891577375025 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark01(78.5398163381932,0.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633831951,-89.53545166246538 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633949523,199.49102708574898 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark01(-78.53981633974482,1.5707963267948966 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974483,1.5707963267948966 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark01(-7.853981633974483,44.420483869759934 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633974485,-21.22667723473205 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark01(-7.853981633974725,17.276044914374417 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark01(-7.853981633975036,7.173822302614616E-17 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark01(7.853981633975785,100.0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark01(-7.853981634100141,0.0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark01(7.8539816353944705,102.06711970605352 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark01(78.53981638729348,-6.282713534057435 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark01(78.53981765067887,0.007240217623264302 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark01(-7.853981871366009,-0.17338735345265915 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark01(-7.854040283986895,1.5707963267948966 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark01(-7.854703894048343,-147.4466616151362 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark01(78.65604153337868,-1.570796326794897 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark01(-78.73928107448147,-1.5707963267948966 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark01(78.74899763275235,-14.671799602015795 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark01(-78.76639064256408,-0.14833644856571093 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark01(78.79609161392113,-93.0181601918789 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark01(78.83641632193873,1.570798106408363 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark01(78.83741044735294,68.60436642713404 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark01(78.92572669505877,-24.027463321393736 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark01(78.93864734837129,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark01(78.97164237571707,95.6694243339696 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark01(-78.98674730964487,54.726174775061594 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark01(-78.987481347914,43.20514551423411 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark01(-78.99235592258023,-61.28617767545458 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark01(-78.9930247101381,42.70624756185802 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark01(-7.906382500626023,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark01(79.079484349394,7.087145114761412 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark01(-79.08233309604707,-62.07716052890324 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark01(-79.10442047610196,-0.2500716861080108 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark01(-79.16804995861715,-97.03749185653334 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark01(7.917162342749037,-37.76931577298802 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark01(-79.25862061275097,0.0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark01(79.28431060671988,-68.4304315960542 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark01(79.35293719182383,-34.65414826824929 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark01(79.52259933661136,-68.50693408980592 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark01(79.52974329168677,0.0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark01(79.63117863657374,0.0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark01(79.7189841892139,26.48672649890291 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark01(-79.82387103817663,-221.4414416359946 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark01(-7.984382883132838,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark01(79.84494864349742,-51.03786500318936 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark01(7.995597329475302,79.90355920715632 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark01(79.98181517388431,-45.18291324097715 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark01(80.0427550299431,-32.490579896283926 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark01(80.07776803729365,0.0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark01(-80.10798282590147,-1.5707963267948983 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark01(-80.10973434460368,-54.97786832287125 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark01(-80.11061266653266,1.570800146519302 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark01(-8.012525356625574,-1.5707963267948966 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark01(-80.18871755236239,-48.00568346573244 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark01(80.1898662687336,-65.72827396800061 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark01(80.20214722883426,78.56332854235296 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark01(-80.51068279217743,79.84207858308378 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark01(-80.5262419985287,0.11776964695588366 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark01(80.53763763550108,44.01869997918175 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark01(80.54306859857942,0.0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark01(-80.66075890943938,0.01778120954915214 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark01(-80.79661688914067,40.028899761149944 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark01(-8.087483812714026,50.133353698826994 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark01(-80.96351893493308,-4.513505935669677 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark01(-81.0092184228883,70.25946007009625 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark01(8.103981633974485,1.5707963267948968 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark01(8.103985007806765,4.837403844342839 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark01(81.08016283387262,-14.32413897468166 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark01(81.11378372912975,1.5707963267948968 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark01(-81.179649899617,-23.905356629402448 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark01(8.137517106735807,-47.62098166977067 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark01(8.146225795899039,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark01(81.46325370052284,0.0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark01(81.48570214476251,-2.8626665624849323 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark01(-8.15345531951381,12.44153780207659 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark01(8.162390328741042,-135.28793837064 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark01(81.68140589142057,-125.66445279706512 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark01(81.68140670726038,18.848535233290395 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark01(81.6814089933346,-1.5707963267948966 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark01(81.6814089933346,1.5707963267948966 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143951091275,3.894775970001011E-15 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark01(-81.68143952252687,92.67698328026049 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark01(-8.169176238751241,-89.24386756635295 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark01(-81.69692490074534,-94.2493985424088 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark01(81.73476360678958,0.24854338699132433 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark01(-81.7546385124462,1.5707963267948974 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark01(81.8110209891104,80.17500380732824 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark01(8.183132670164795,20.950789366842827 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark01(-81.85279519038905,0.0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark01(8.192283362175798,79.7066351242809 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark01(81.952844655662,-1.5707963267948966 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark01(-81.96253838394969,-34.113894035283195 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark01(81.98267632529829,0.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark01(82.02105924468077,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark01(82.03162226581034,-65.86256479805058 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark01(8.20430927955509,69.85732500678606 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark01(82.05007762617265,-100.0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark01(-8.212000419350094,-94.36176588405984 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark01(8.22084869281167,32.814221767908506 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark01(-82.24215128822169,-38.70096998099289 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark01(82.29141964612558,-7.853981633974483 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark01(82.31404929193104,1.5707963267948972 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark01(8.231815001339111,64.45648026156945 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark01(82.35928750559074,-100.0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark01(-82.3593779428017,-85.44474366543787 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark01(82.36739799403259,-2706.2023399617037 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark01(82.37128767763886,-62.5796750496376 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark01(-82.39817767498647,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark01(82.41072021455376,3.2166109511535295 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark01(-8.242948592692414,0.408432973617602 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark01(82.45343646924269,1.5707963267948966 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark01(82.47224290513465,-78.09000377705121 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark01(82.47553994808459,44.137300481893945 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark01(-82.47617920176033,-94.30425803395177 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark01(82.57886066345404,107.15876693782384 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark01(-82.58253523765487,0.0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark01(-82.58368705153849,0.23288240794951115 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark01(82.60692900372888,1.5707963267948966 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark01(8.260926295814338,-4.1649655003283925 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark01(8.262087816156175,-96.74678174583478 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark01(-82.65036593452659,21.017320790765567 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark01(-82.78322354486926,-18.51269303870089 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark01(-82.80248991525244,0.0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark01(82.84308712479745,0.0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark01(-82.84410527855883,38.32696250744246 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark01(8.286234900211525,0.0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark01(-8.286562482444118,95.64935499581199 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark01(82.94387366807437,-4.674971375483029 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark01(-83.00300384473383,60.97086294995347 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark01(83.12638438919825,-1.5707963267948966 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark01(8.313031049393203,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark01(83.14760776613429,1.4089612792181376 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark01(-83.18531711921074,0.0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark01(-83.1971512831421,2591.6857554651224 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark01(83.25220369903981,-10.995570765366015 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark01(83.2524852455337,-67.54423857600601 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark01(83.25434612345481,-45.55309465542167 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark01(83.25463174741736,-29.845129689919016 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark01(83.27407243478342,-4.712633121085343 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark01(8.327938570485031,11.632686726182044 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark01(83.2914749355739,-1.5707963267948966 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark01(-83.30393714272277,-32.71152319460323 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark01(83.30869528334335,-20.166486165648465 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark01(83.32270089239307,0.002215163771165435 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark01(-83.39258125531725,-1.5707963267948983 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark01(-83.40671829183945,53.67965179659616 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark01(83.44134358578023,-1.5559204546475944 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark01(83.45167730253277,29.442461714959535 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark01(83.46164828809519,1.5707963267948968 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark01(83.49861182450006,0.0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark01(8.350802676579555,45.33219594422246 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark01(83.52690888700202,1.5707963265708236 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark01(83.54898394612414,62.35895365427402 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark01(83.58074604317306,-63.19116902999462 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark01(8.360133497857674,1.5707963267948966 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark01(-83.60807199602829,78.08669394570182 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark01(83.73014377597289,1.5707963267948966 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark01(8.393153339211553,2599.5777181648755 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark01(-83.93217911387363,-2567.927964882802 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark01(-8.396576850366301,73.28134474860553 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark01(83.9902721376961,0.0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark01(84.03507344189572,-46.4215559898057 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark01(-84.07581548277413,2608.930720218517 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark01(8.409980853878935,88.55025335067191 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark01(-84.13305926973831,0.5153054506119812 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark01(84.16985815130442,91.96945362327256 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark01(-8.418102073862357,96.07623270773075 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark01(8.418305110864495,36.42162568965168 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark01(84.19789312135165,65.24709587597974 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark01(84.25124954927372,-1.3951834179599698 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark01(84.25677577505252,12.06307160668807 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark01(-84.30453403778985,16.48992760531 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark01(84.31926228031148,1.082547079684284 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark01(84.33418163279296,51.277188072282684 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark01(-84.34609833316863,-1.5707963267948966 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark01(84.35499885230743,-9.36730340698378 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark01(-84.38975147935403,-1.2662437689395825 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark01(-84.39284832900394,-41.80340588702691 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark01(84.40585215334008,80.74768419048064 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark01(-84.45852904648336,47.65209567884432 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark01(-84.46257159615642,-79.38750783502212 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark01(84.48280237381546,0.0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark01(-84.48404526413889,1.5707963267948966 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark01(-84.49689382082194,-9.754526685123217 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark01(-8.450143691583918,49.69309667933865 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark01(84.52336282708376,-95.18000610982045 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark01(-84.55311656231986,-19.26979059249983 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark01(-84.577211181156,0.0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark01(84.58309403315722,-5.774404402870283 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark01(84.58670895665236,-14.334083263086512 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark01(-84.59480306667993,-83.14817403008601 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark01(84.67092606635649,-74.98142669691589 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark01(-84.68639839574716,0.0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark01(84.6864399287559,0.0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark01(84.69375364440545,-97.85967481874471 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark01(84.71073441419523,-5.694351061776336 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark01(-84.77269285126941,100.0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark01(84.77532406968339,0.5202212301193773 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark01(84.79455851840441,2611.072438610084 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark01(84.8229198510352,0.30566697142399424 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299161252273,-51.836294143385025 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark01(-84.82299876038127,81.68038274454986 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300057372345,125.66151729851151 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300158723193,-67.54406683806985 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300161948561,6.204478164168414 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark01(-84.82300164692433,-4.712388811831053 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark01(-84.8230016469244,-1.5707963267948966 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark01(84.82300409559268,0.0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark01(84.82300927631896,1.5707963267948966 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark01(84.8230092763335,18.849555921516444 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark01(84.82348992817442,1.5707963267948966 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark01(84.82495477192442,1.5707963267948966 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark01(-84.8317765463862,0.0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark01(-84.8409996664772,-88.1546056181964 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark01(-84.87478183128336,-26.354995000690906 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark01(84.93470834059495,18.5880270257463 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark01(84.94201598773313,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark01(85.01187824823103,-21.965221515637907 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark01(85.01292200340843,-38.96131510412453 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark01(-85.02059997655205,-3.118774550470416 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark01(-85.05559267707694,0.44161443901441594 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark01(-85.09966023730648,-43.4886161125833 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark01(-85.11130377336163,0.7732060188515906 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark01(-85.2459059750038,9.30256027513295 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark01(-85.26880984619696,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark01(-85.27584651136173,72.10424596655344 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark01(-85.30730361501979,-45.19819283675949 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark01(85.31306473888648,-3.835896662838195 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark01(-85.5097331510323,-1.5707963267948983 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark01(85.52023617296099,-1.5906529278953893E-4 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark01(-85.74065652192705,1.5761501660150426E-5 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark01(85.78462214647509,170.6484805223605 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark01(-85.85313280113195,1.5707963267948966 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark01(85.9126527007212,0.0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark01(85.97415925330401,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark01(85.99062765417924,1.5707963267948968 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark01(86.00961853088683,-66.14422108512275 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark01(-86.04470573179998,-1.871037846629946 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark01(-86.05658429145639,73.1898968828827 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark01(86.05929446510552,-82.36720197871713 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark01(86.10573702446399,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark01(-86.14625038251522,0.0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark01(86.25394524977438,-0.6309270770803472 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark01(-86.39566690237604,1.5707963267948983 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark01(86.44787104478581,97.5628064715932 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark01(86.45731853175644,0.0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark01(-86.49260727869618,1.5707963267948966 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark01(86.63976627916153,32.699253696193814 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark01(-86.8250430633686,-100.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark01(86.96988592554973,-5.768816577326348 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark01(-87.08451893316938,-1.5707963267948966 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark01(-8.730547086705855,-53.809971366600685 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark01(87.34719204315925,99.50364960896295 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark01(-87.5947468610931,99.7015353499988 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark01(87.74813212001578,-2666.190882259218 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark01(87.96459101730062,75.39755640544716 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark01(87.96459137476066,50.26654680858606 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark01(87.9645935212808,50.26498134256287 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark01(87.96459427783134,10.995574287564274 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark01(87.96459429647481,88.08959430051908 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark01(87.9645943005142,-1.570796326911312 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459753298456,-7.107025367958449E-4 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark01(-87.96459811533524,0.0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark01(-87.96460955930328,-1.5707963267948966 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark01(87.98479804369424,37.81947354986657 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark01(88.13516100086568,63.42307697058534 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark01(88.13726177204276,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark01(88.14882831191491,1.5707963267948968 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark01(-88.1724438188004,-10.976960547124449 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark01(-88.17425311583943,-56.57510601785496 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark01(-88.22756474697495,-18.5804761865094 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark01(88.2576246109295,0.0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark01(-88.27985627098589,95.35191670775053 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark01(-88.33855354962235,81.843580135933 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark01(88.42229730388884,0.0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark01(88.46189615793494,-11.358121028682632 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark01(-88.46341102766954,0.4999995405902736 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark01(88.47032131991855,-1.029139431530934 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark01(88.51933485652948,-0.012398562615467618 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark01(88.59076620807407,5.139181040647939 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark01(88.60206657942253,-10.995574287669644 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark01(88.66253773749945,5.212388980384929 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark01(-88.66545001527881,94.52041763021941 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark01(-88.6825758249182,-1.5707963267948948 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark01(-88.72690585714193,-135.56214343930196 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark01(-88.73851082650673,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark01(88.7404963397426,-44.300023323763085 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark01(-88.7988667209409,-96.61200940725385 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,23.22302498213506 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-49.73370722796089 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark01(8.881784197001252E-16,-96.39573129121138 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark01(88.81946312072232,-168.32325805820452 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark01(-88.91669900238817,0.14638405058424375 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark01(-88.91934433766613,79.47869680538761 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark01(88.92069734215306,34.823014723778215 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark01(-89.01399318738063,0.0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark01(8.902492403735437,-1.5707963267948966 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark01(89.05566038669039,-55.897378858851894 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark01(-89.22343173398436,9.825404065989886 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark01(-89.25019012999348,15.8231248285094 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark01(89.2700863148019,29.235322601134328 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark01(8.938545029509656,-30.405612687243526 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark01(-89.46532382708105,29.92474416545909 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark01(89.53276078667028,1.5707963267948966 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark01(89.53539062749785,67.544238536583 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark01(89.53555083016704,-61.26105507502482 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794726,1.5707963267948983 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794728,-1.5707963267948983 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark01(89.53802046794802,-1.5707963267948966 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark01(-89.57655894600147,99.83342561577453 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark01(89.59955284775093,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark01(-89.65576520035512,0.0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark01(-89.7379429123003,0.1910512073777618 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark01(89.7475052935663,94.0692624158254 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark01(-89.81315375482339,-0.3314958904905026 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark01(-89.81424394615206,1.5707963267948966 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark01(-89.89565309347509,-1.5707963267949019 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark01(89.89769711033347,-26.464262107778254 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark01(-89.92901489855106,188.70286546531122 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark01(89.93061464725224,-45.22526533881877 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark01(89.96542396458264,-1.5707963267948974 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark01(89.97103366901496,-44.07407473443557 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark01(89.97795904357906,0.1322712173163865 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark01(90.03288926882698,-1.381282314830669 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark01(-90.05577952930017,-1.570796326794897 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark01(-90.06245230366432,1.5707963267948966 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark01(-90.06397191164844,-2588.5160548198487 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark01(-90.09934880674551,99.63385027328974 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark01(-90.11875813504736,0.0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark01(90.18449036653016,-49.30949142439594 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark01(-90.2191541517538,5.727412116221004 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark01(90.31403168711833,-1.2785214164876806 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark01(-90.3362905331152,60.83425882855178 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark01(90.45890487424063,-1.5707963267948974 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark01(-9.056946925457432,-16.140847988648304 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark01(-90.58506245814789,-45.54144469465282 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark01(-9.063754347965556,45.476082092711415 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark01(90.65621755899002,1.5707963267948966 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark01(-90.73367846946559,-37.04141917989487 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark01(90.753247991139,7.877286340704004 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark01(-90.77679341087192,2568.0640131142286 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark01(-90.77884021036945,-10.32616008439085 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark01(90.77956068382139,33.217522324865584 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark01(90.77960452836419,1.5707963267948983 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark01(90.78649402260928,44.91027636581802 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark01(-90.7902764795742,1.5707963267948968 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark01(90.83505808995673,3.0808940215097778 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark01(-90.86949904764262,-15.788360178322378 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark01(90.8715515138443,-67.8115680729948 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark01(90.90986130474016,1.5707963267948966 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark01(-90.93498383778785,1.5707963267948968 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark01(91.02392541591578,42.17993158576801 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark01(91.04874404077158,-0.34049812054264417 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark01(91.0649438786376,89.80275953199299 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark01(-91.07260906540733,-26.07781623321796 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark01(-91.10594648306699,-174.3580504578279 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark01(-91.10604917098658,-17.27875959466949 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark01(-91.10614542714237,10.995574287562032 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark01(-91.10615229727233,164.93368692558954 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618343213491,-9.246467703216182E-6 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618513090833,-94.24959868173535 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695189689,-0.0020068671825482624 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695380035,-6.204702139391079 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark01(91.10618695410399,0.0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,-106.81402709480163 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark01(-91.10618695410399,-1.5707963267948966 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark01(91.10618695497662,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark01(91.10618721860097,-31.418454774217203 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark01(91.10619042630061,9.272763264671368E-6 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark01(91.10619047634349,8.298489306924687E-16 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark01(91.10620221298767,-6.222767964743948 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark01(91.1066753419947,-163.36298788436628 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark01(-91.15615586722869,0.01796552490203209 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark01(91.27406483572844,0.49945907055950883 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark01(-91.28590953368112,1.5707963267948966 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark01(-91.45408451470159,0.10084114202507537 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark01(-91.48240639464962,18.55347714963733 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark01(-91.55057293978939,66.20226432724758 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark01(91.56973591686865,-0.4763514438364941 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark01(91.60637667307682,-20.75557375227467 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark01(91.6334009199733,16.44703030321992 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark01(91.63854168962251,0.0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark01(91.97602222308983,93.88018676914604 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark01(-92.03273719147053,-1.5707963267948966 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark01(92.06747875380353,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark01(92.07275964511084,72.62334383891647 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark01(92.12207921409922,-2597.572483535652 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark01(92.16187282347629,-92.08730584266237 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark01(-92.30754241461231,2.1526189995918816 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark01(92.31828662988677,0.4659545184441162 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark01(92.3389866526432,0.0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark01(-92.50602647888046,0.049775631070269784 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark01(92.57800418493147,-26.1795041183057 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark01(92.5943497882997,123.79309981207162 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark01(-92.59742138959537,-6.049014748177263E-16 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark01(-92.61038653616814,0.0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark01(-92.6186101836597,67.26053164303977 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark01(-92.66933501753999,16.323482208373363 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark01(-92.67435344035465,-1.5707963267951477 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark01(-92.67683823063078,80.11060915919032 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark01(-92.69386272375483,27.43463270418856 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark01(-9.273128021786547,97.77304888532825 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark01(-92.78728521160731,1.5707963267948966 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark01(92.87157194501955,-24.191877889601372 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark01(-93.06362379064936,74.09747675228246 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark01(93.06907044539011,-2616.428268280038 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark01(93.23380847951489,-1.5707963267948963 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark01(93.34144676377682,72.26015600364708 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark01(-93.4878034568736,-0.18351621653902217 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark01(-93.8562196169379,-60.849165858589195 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark01(-93.89338236421996,-1.5707963267948948 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark01(-93.983509768638,-91.85972483438852 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark01(94.11818379977252,1.5707963267948966 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark01(-94.14264847432273,-30.180204017628597 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark01(94.21775756426518,-76.27363127617886 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark01(94.2477760854543,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477785998418,-6.280593716232002 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark01(-9.424777946691375,12.566370613799858 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark01(-9.42477795584935,6.224021418084617 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark01(-9.424777961700704,0.0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778151517259,1.5707963267948966 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778154362244,-0.0017568703218536293 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark01(-94.24778176824039,69.11666433413468 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark01(9.424781413433317,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark01(9.424781483008868,0.0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark01(-94.2479016780063,29.845123033487845 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark01(9.424793219684933,-48.69468613064177 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark01(9.424931231277217,69.1154263934244 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark01(9.426811133993269,20.65379393862534 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark01(-94.2790296076938,1.5707963267948966 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark01(-94.27902961062392,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark01(94.31640765322122,-91.15575484281368 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark01(-94.32381795809623,-65.50894541122133 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark01(-94.37281917979416,1.5707963267948966 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark01(94.39920126194403,-44.53870772952581 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark01(94.42801560817341,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark01(94.70887215033099,118.39817545396164 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark01(-94.75445500134938,-97.98018303775436 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark01(-9.477488863604862,52.02646806317142 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark01(-94.94976351054106,-1.5707963267948968 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark01(-94.97312243544785,-87.42804451566819 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark01(95.10944182627952,-55.53308296866386 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark01(9.516850345477181,0.0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark01(95.22189081481496,4.886058038876368 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark01(9.525692457279849,-0.7621249770444907 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark01(95.26108905669258,95.18886190729143 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark01(95.26183525402851,-0.505991076202177 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark01(95.32279397271559,1.2301119484757699 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark01(95.38841487579799,-99.05139637438656 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark01(-95.51655740080733,17.053654104743607 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark01(-95.53864616947061,0.0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark01(-95.54455529211573,-31.619995928704625 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark01(95.55769069899577,24.41587593469248 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark01(95.56820687317955,38.85167580421838 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark01(-95.60758073177927,0.0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark01(-95.61392460772831,-20.245871651978604 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark01(-95.65916278644893,-8.639130827908279 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark01(95.6593690023613,-47.20250256130802 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark01(-95.70699168855576,-6.429203785828833 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark01(-95.78433381278253,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark01(95.81594609385039,-1.5707963267948981 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark01(95.8166240361734,-1.5707963267950902 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark01(95.81715699730022,70.68583713666229 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark01(-95.97219708648387,-89.06904482298663 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark01(-95.98385261879328,-0.16361667994212592 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark01(95.98414192321516,-1.5707963267948968 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark01(96.0456002666426,-88.493221317603 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark01(9.610206581992367,107.46627972418096 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark01(-96.28848859885119,1.5707963267948966 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark01(96.51887164256328,6.466587729468858 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark01(96.54671327194377,1.5707963267948966 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark01(9.655143869049269,6.0591779611656875 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark01(-96.61122370946087,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark01(-96.62262828242983,0.0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark01(96.67257365761165,4.732766137966971 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark01(-9.674777984261464,37.69615243165482 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark01(96.76312805864211,0.0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark01(-96.88054786658405,0.049427040387680705 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark01(96.90227527838327,1.8599541810783958E-5 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark01(96.92757742236628,54.880418672214546 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark01(96.9551623389527,2.220446049250313E-16 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark01(97.01398473078345,1.5707963267948948 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark01(97.0970191566968,5.069387660822684 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark01(97.10074991300336,-0.7740522550681137 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark01(97.15575984081062,54.977894497382096 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark01(97.21459030666949,37.67438460388405 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark01(97.22770133007705,0.28285199669629435 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark01(97.25388793193129,-0.5257859573753151 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark01(-97.29001163165354,-157.26797147158203 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark01(-97.3608917838249,0.0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark01(-97.53434126625206,1.570796326794923 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark01(-97.62290237262467,-76.51224957470804 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark01(-97.62986436226507,-72.50040931723443 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark01(-97.68109764607821,44.69397070516919 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark01(97.7052910919415,0.0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark01(-9.777149912992797,-17.99277681709208 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark01(97.77575706977548,0.12032915755449722 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark01(97.83593697575604,12.113163124962718 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark01(-97.89438961547525,0.23430332913382956 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark01(-97.92654399658126,95.10207217435755 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark01(98.12841725550275,0.0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark01(-98.18985978655775,2528.2763900353852 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark01(-98.20282744846864,-76.69216185508938 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark01(-98.30424161796165,15.885138961073977 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark01(-98.35462857429818,-60.19031834782076 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark01(98.43672739585418,63.87301345605175 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark01(-98.57706942295975,1.5707963267948966 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark01(98.70540108585759,41.11531135084898 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark01(98.76932754658537,-1.5574752109461796 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark01(-9.88326710991948,1.5707963267948968 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark01(-98.85331519824425,12.891708198561858 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark01(-98.90265862864148,92.6769832808989 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark01(-98.9319555651006,-147.55281200912626 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark01(-98.93796026916064,2666.4616686501076 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark01(98.9481100260443,0.0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark01(-98.95753874743956,-1.5707963267948966 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark01(-98.95916491409935,1.5707963267948966 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark01(-98.96269468461992,36.128315246321144 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark01(-98.96279842871739,1.5707963267948966 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark01(99.0767107850073,0.31415890637542776 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark01(-99.08270924518554,12.990650108650968 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark01(99.35239092183389,-54.92119122860413 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark01(-9.936384420897761,-44.13216916239558 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark01(99.47006686174657,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark01(99.48762283569503,73.84275472220568 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark01(99.82645039826855,-58.950206232947956 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark01(99.8979163320287,1.5707963267948841 ) ;
  }
}
