import org.junit.Test;

public class Sample04Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark04(10.587940025645779 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark04(-1.2018066138946466 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark04(-1.4941406249999991 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark04(-1.4941406250000002 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark04(30.233952618717296 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark04(-31.160384758177045 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark04(-3.6611440641387105 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark04(-40.11028040602621 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark04(-40.191406249999986 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark04(-40.19140625 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark04(-50.89865889766034 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark04(57.706147059363786 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark04(-57.89826030295819 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark04(6.014721998216416 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark04(6.9385450144373095 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark04(-709.0290920954568 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark04(-709.0338775827453 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark04(-709.2999173200608 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark04(-709.3132767856756 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark04(-709.3975842353831 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark04(-709.4542729127857 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark04(-709.5551836477297 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark04(-709.6395905065065 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark04(-709.6629907715832 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark04(-709.8732222226488 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark04(-709.995356265637 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark04(-709.9980078463025 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark04(-709.9999946919487 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark04(-711.9650972535052 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark04(-712.6968582052104 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark04(-714.398955888274 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark04(-71.8982831834608 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark04(-720.0025993196468 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark04(721.2746442288944 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark04(-726.7198697819977 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark04(-729.1975191879927 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark04(-735.0962754692039 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark04(-744.3981240391864 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark04(-745.6085907350679 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark04(-745.8792869284963 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark04(-745.9999999999999 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark04(-746.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000000058644 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark04(-746.0000045987347 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark04(-748.1914062503212 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark04(-748.1914062511765 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark04(-760.8024164925101 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark04(-89.22374457317738 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark04(96.00720491714279 ) ;
  }
}
