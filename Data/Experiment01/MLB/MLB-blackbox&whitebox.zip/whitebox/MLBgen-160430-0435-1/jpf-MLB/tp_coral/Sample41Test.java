import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999964,1.9999999999999893 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(-0.9999999999999999,2.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,1.9999999999999998 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark41(-1.0,2.0000000000000004 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark41(1.2410277131186684E-34,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark41(-1.6888723710498534E-30,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark41(-2.7620628554020366E-5,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark41(2.9445386091013,5.7257690113869195 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark41(-30.63053304401066,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark41(3.4470746586049308E-9,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark41(4.222043304071769,13.60360635738549 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark41(-4.807796131949132,93.2005797395322 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark41(-4.826694841510189,28.123677934571262 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark41(5.382324183873877,23.587089436439715 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark41(-54.549296179171414,41.16589457027578 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark41(72.38612348886434,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark41(-7.608021842660002E-9,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark41(76.95230310610788,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark41(-9.232644537112764E-40,0 ) ;
  }
}
