import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(-0.01606217844958735 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(-0.06565388451838317 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(-0.10344184588990402 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark30(-0.21565343520921942 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark30(-0.22928578560808432 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark30(-0.2413045778689309 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark30(-0.37463532351982565 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark30(-0.3824218167845146 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark30(-0.396243812470118 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark30(-0.39827666387695615 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark30(-0.40648208118881257 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark30(-0.4249212615612237 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark30(-0.4788791805422079 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark30(-0.47948030525219565 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark30(-0.5217052197378678 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark30(-0.6074344583837643 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark30(-0.6344814246759967 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark30(-0.6633185073216481 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark30(-0.6946878794514788 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark30(-0.6954722306043521 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark30(-0.7225673229832807 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark30(-0.7305159646503938 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark30(-0.874533308563997 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark30(-0.9481524994553467 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark30(-0.9586618663615099 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark30(-0.9720442099081055 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark30(-0.9736239561485718 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark30(-0.9787346135245798 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark30(-0.9856858882599795 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark30(-10.032563036798607 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark30(-10.048052235006935 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark30(-10.066559673201581 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark30(-10.148187493712356 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark30(-10.1554905540943 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark30(-10.159088302570922 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark30(-10.166510317821476 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark30(-10.167712447733578 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark30(-10.24879516732912 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark30(-1.0330886117714897 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark30(-10.334839477464158 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark30(-10.368623788683067 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark30(-10.3805584723018 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark30(-10.391419881364044 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark30(-10.436479642552783 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark30(-10.443518399022153 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark30(-10.444336951733817 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark30(-10.463143436421916 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark30(-10.470538280176456 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark30(-10.486064664399962 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark30(-10.50287128336737 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark30(-10.50755690101468 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark30(-10.512556915890812 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark30(-10.544562862515889 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark30(-10.552661197606298 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark30(-10.55880564059845 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark30(-10.56738339733944 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark30(-10.608671365315388 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark30(-10.62340533661768 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark30(-10.686542651507352 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark30(-10.722471036667699 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark30(-10.727018476020334 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark30(-10.775368482305936 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark30(-10.837091295535942 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark30(-10.847214808426457 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark30(-10.867298008161512 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark30(-10.869917373543615 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark30(-1.0877085405164735 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark30(-10.882007211070132 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark30(-10.889071680146742 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark30(-10.961340879291726 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark30(-10.975691904556982 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark30(-11.036190680298617 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark30(-11.076590347864254 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark30(-11.112926564329229 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark30(-11.120923909517472 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark30(-11.126246468816106 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark30(-11.186416066548162 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark30(-1.1188380837265726 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark30(-11.191008876782064 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark30(-11.198406538771195 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark30(-11.20402779593843 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark30(-11.212302647285767 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark30(-11.214579027009577 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark30(-11.24525350607206 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark30(-11.310444462415646 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark30(-11.31046499587869 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark30(-11.31667700690464 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark30(-11.34348647500471 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark30(-11.364181147640949 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark30(-11.367228457131347 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark30(-11.40445648149111 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark30(-11.418639696251077 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark30(-11.432434528114527 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark30(-11.448829930099407 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark30(-11.455691264364404 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark30(-11.4726538178123 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark30(-11.485903127613597 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark30(-11.519091021278925 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark30(-11.59095772532801 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark30(-11.604875096991904 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark30(-1.1642646440827633 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark30(-11.708481185844704 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark30(-11.71430665714827 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark30(-11.75166050959966 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark30(-11.779473402804342 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark30(-11.807301962940599 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark30(-11.873068836914172 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark30(-11.873445109067177 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark30(-11.878932335232179 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark30(-11.880781362686605 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark30(-11.911494821335666 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark30(-11.92434454043429 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark30(-11.931675800626465 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark30(-11.935400091766496 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark30(-11.961176571618793 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark30(-11.964353875235716 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark30(-12.007899765606652 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark30(-1.2020297943674763 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark30(-12.031511695429401 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark30(-12.05084774290144 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark30(-12.052234291929679 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark30(-12.092879292611784 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark30(-12.094594021194595 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark30(-12.104659680290524 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark30(-12.150908492412384 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark30(-12.159876946191673 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark30(-12.242034435044886 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark30(-12.249515886582813 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark30(-12.260244582434282 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark30(-12.266359023261671 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark30(-1.2267723739057317 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark30(-12.355636002665605 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark30(-12.35810432809707 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark30(-12.358716105640838 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark30(-12.414436985874346 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark30(-12.431411206158543 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark30(-1.243589522161443 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark30(-12.440249190077651 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark30(-12.485227049097986 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark30(-12.511151113206793 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark30(-12.519591554276204 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark30(-12.52633838788617 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark30(-12.544534052372413 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark30(-12.592280529645251 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark30(-12.662475381641798 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark30(-12.689114839156986 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark30(-12.693236104484058 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark30(-12.706294041658168 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark30(-12.718232611654486 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark30(-12.725697562834014 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark30(-12.73072839960112 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark30(-12.758618274711608 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark30(-12.764648974864485 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark30(-12.78428798323445 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark30(-12.808397705825115 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark30(-1.2813620767836653 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark30(-12.818794210409052 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark30(-12.870526740022697 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark30(-12.885218267107803 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark30(-12.902207001018056 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark30(-12.916707417341058 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark30(-12.958861927251093 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark30(-13.009987837881184 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark30(-13.028187562885194 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark30(-13.060381376035153 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark30(-13.081924197684486 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark30(-13.086111160762258 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark30(-13.09886171173585 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark30(-13.12810538614562 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark30(-13.144773396011061 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark30(-13.199225613868634 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark30(-13.266027940129817 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark30(-13.278323848405435 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark30(-13.300967212973248 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark30(-13.311678737015114 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark30(-13.320074744110116 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark30(-13.32193202839376 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark30(-13.337866711121166 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark30(-13.340994574918554 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark30(-13.35332742095163 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark30(-13.354619745918654 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark30(-13.410017006736524 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark30(-13.488013447217469 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark30(-13.53979123727089 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark30(-13.554610334134438 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark30(13.60578909811376 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark30(-13.62420585275217 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark30(-13.625460289309402 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark30(-13.635690316218117 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark30(-13.658977711033643 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark30(-13.678286914983758 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark30(-13.735158809923604 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark30(-13.77959466641083 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark30(-13.86791262232461 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark30(-13.884312235958006 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark30(-1.3899620338367384 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark30(-13.92990863645855 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark30(-13.933403596884347 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark30(-13.951809251053547 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark30(-13.966072098551521 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark30(-13.967512689429086 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark30(-14.051832303024142 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark30(-14.060663385001376 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark30(-14.078641255138336 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark30(-14.11717816724969 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark30(-14.146394283648547 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark30(-14.147800158573403 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark30(-14.149449935529063 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark30(-14.15610931860489 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark30(-14.225099521712693 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark30(-14.226644475215863 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark30(-14.23366252988329 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark30(-14.24404985898218 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark30(-14.256316118137107 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark30(-14.26002351093048 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark30(-14.291398907410809 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark30(-14.29882823508946 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark30(-14.329984873865456 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark30(-14.337781953446978 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark30(-14.437532500270038 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark30(-14.450657984717125 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark30(-14.47107269685175 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark30(-14.484302392207752 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark30(-14.583854928379807 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark30(-14.585067208558371 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark30(-14.59392786942071 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark30(-14.620757698173577 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark30(-14.6327816374924 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark30(-14.702779547726095 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark30(-14.707209783974974 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark30(-14.711520192416373 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark30(-14.713006681780996 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark30(-14.71850225181268 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark30(-14.730244140899785 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark30(-14.772264120888678 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark30(-14.814352503573588 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark30(-14.81514422789158 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark30(-14.818768763855743 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark30(-14.82703872521671 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark30(-14.841063927893103 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark30(-14.86004256889413 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark30(-14.873257052117822 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark30(-14.873435806404075 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark30(-14.940011533357776 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark30(-14.969239612328948 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark30(-1.5058257738844247 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark30(-15.102540406155995 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark30(-15.121485297462314 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark30(-15.137563033738559 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark30(-15.144688047875988 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark30(-15.173795196704319 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark30(-15.214071354285608 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark30(-15.239136504689597 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark30(-15.24139060991881 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark30(-15.260630618795673 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark30(-15.32128114443951 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark30(-15.3452940185649 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark30(-15.348151327996135 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark30(-15.349204272796541 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark30(-15.36123958778228 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark30(-15.385469780658028 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark30(-1.5491002150828166 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark30(-15.495973492025897 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark30(-15.552904498525265 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark30(-15.605500734138445 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark30(-15.605624758491672 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark30(-15.660456630486252 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark30(-15.684226320407873 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark30(-15.694817803329869 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark30(-15.70459290833604 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark30(-15.737238683118932 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark30(-15.755333478336112 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark30(-15.763469883078457 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark30(-15.777846706610205 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark30(-15.80851001576616 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark30(-15.817301734378901 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark30(-15.821166735195206 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark30(-15.823919356034935 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark30(-15.824623990662772 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark30(-15.83226237732211 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark30(-15.842196912767875 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark30(-15.939817568737652 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark30(-15.953792456536547 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark30(-16.01275370855663 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark30(-16.04914923920957 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark30(-16.153976080307487 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark30(-16.185118748396604 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark30(-1.6245262050810254 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark30(-16.31323164617062 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark30(-16.322615600250984 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark30(-1.635303532601057 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark30(-16.38015231489625 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark30(-16.413315828280787 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark30(-16.44553378862004 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark30(-16.486369654266284 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark30(-16.52622096700243 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark30(-16.53209864517264 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark30(-16.53283875321989 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark30(-16.59851656398095 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark30(-16.602671090215452 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark30(-16.634229851026333 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark30(-16.698575097302708 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark30(-16.72742327308245 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark30(-16.79217063634968 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark30(-16.796738112733124 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark30(-16.862072263971342 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark30(-16.865583167813767 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark30(-16.92442542381491 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark30(-16.928842570458684 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark30(-16.939988933479526 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark30(-16.94623204716565 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark30(-16.986576218108326 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark30(-1.6994777307656221 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark30(-17.012645954350262 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark30(-17.02161181800706 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark30(-17.068694212712956 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark30(-17.081364184673703 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark30(-17.09634326528233 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark30(-17.10659067876523 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark30(-17.114337712306323 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark30(-17.14318182822035 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark30(-17.191983957100888 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark30(-17.256527136321537 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark30(-17.257207139757895 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark30(-17.294536879792304 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark30(-17.31757863419044 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark30(-17.32119135946384 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark30(-17.32893773241186 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark30(-17.3640557166364 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark30(-17.38316618027011 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark30(-17.43813596931787 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark30(-17.476807728833137 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark30(-17.47883586138606 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark30(-1.7488917649603337 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark30(-17.500958221846346 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark30(-17.5071855165682 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark30(-1.753733238041221 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark30(-17.53992640591784 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark30(-17.56447444569156 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark30(-17.565521286799154 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark30(-17.572313830057354 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark30(-17.59037884168862 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark30(-17.611590699758906 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark30(-17.635602970854137 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark30(-17.663565524015553 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark30(-17.67088460879509 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark30(-17.67398288908835 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark30(-17.68017215578371 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark30(-1.7705426236741744 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark30(-17.709384483537647 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark30(-1.772654743457565 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark30(-17.774455366369523 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark30(-17.820695535483694 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark30(-17.87116214950784 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark30(-17.922125178821233 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark30(-1.7925495978082182 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark30(-17.94147321330408 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark30(-17.951533257681746 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark30(-17.96140735182354 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark30(-18.059890368896262 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark30(-1.8127065854100692 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark30(-18.134215230447936 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark30(-18.207427653290836 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark30(-18.231878327362864 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark30(-18.27544463928264 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark30(-18.2775220465996 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark30(-18.344071996720274 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark30(-18.396418173171853 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark30(-18.467303222157724 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark30(-18.47634013206303 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark30(-1.8502627091386188 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark30(-18.535166576936703 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark30(-18.558970605865042 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark30(-1.8563698692226183 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark30(-18.5958997399984 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark30(-18.617386287979315 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark30(-18.667777735185666 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark30(-18.6879579235234 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark30(-18.721210231139082 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark30(-18.723040175920104 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark30(-1.875278614207204 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark30(-18.777584435488052 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark30(-18.781420845180932 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark30(-18.801365308258156 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark30(-18.81040818568968 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark30(-18.832716877856683 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark30(-18.846473202729655 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark30(-18.860330523492095 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark30(-18.87173314857951 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark30(-18.879424722578747 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark30(-1.8881670894840568 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark30(-1.8909898569573755 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark30(-18.923366590962516 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark30(-18.967738442678524 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark30(-19.002398933884336 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark30(-19.01550859976892 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark30(-19.01708392971966 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark30(-19.058388622850387 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark30(-19.068593382382275 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark30(-19.079772371899082 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark30(-19.109061782746622 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark30(-1.911680451697137 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark30(-19.15671693863999 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark30(-19.165701397570587 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark30(-19.195151969108622 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark30(-19.202511088273994 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark30(-1.9215922445022073 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark30(-19.32793072646028 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark30(-19.362824194139904 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark30(-19.389635409422624 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark30(-19.430700320768594 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark30(-19.4791323194694 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark30(-19.52582440092705 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark30(-19.535732349583412 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark30(-1.959151687973943 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark30(-19.591642596380936 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark30(-19.598367402639738 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark30(-19.61766113429772 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark30(-19.639455062727308 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark30(-19.73514460102183 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark30(-1.9782532570170588 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark30(-19.783743083451697 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark30(-1.9813113284747885 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark30(-19.858737350608124 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark30(-19.878194597405624 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark30(-19.928707609470024 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark30(-19.930006512108278 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark30(-19.933068136547277 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark30(-19.948798534586814 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark30(-19.99262559122417 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark30(-20.006944740811633 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark30(-20.025428084211413 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark30(-20.0667247906905 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark30(-20.06942647062189 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark30(-20.113923605925407 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark30(-20.116076438834682 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark30(-20.14638093706293 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark30(-20.14679499066669 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark30(-20.16545884925543 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark30(-20.185706230664465 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark30(-20.19708675815373 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark30(-20.206176496593457 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark30(-20.221637225819933 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark30(-20.245541830252222 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark30(-20.25090787653869 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark30(-2.02821013907311 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark30(-20.338413515201708 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark30(-20.353737114939378 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark30(-20.385974396837227 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark30(-20.405217299051003 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark30(-20.411748612066134 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark30(-20.429976989129514 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark30(-20.475112940028765 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark30(-20.483257296677152 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark30(-20.52182593637974 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark30(-20.546543262971 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark30(-20.55981155404791 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark30(-20.57261644361894 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark30(-20.59348003538956 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark30(-20.597902497176207 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark30(-20.604386227129638 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark30(-2.06605524319086 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark30(20.697547377908762 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark30(-20.739010564900283 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark30(-20.74018867125602 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark30(-20.74248916038613 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark30(-20.774416107642196 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark30(-20.812770706868548 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark30(-20.833588423759636 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark30(-2.0867378192270536 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark30(-20.871785259534192 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark30(-20.886107946862282 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark30(-20.927309257015352 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark30(-20.970458607959273 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark30(-20.970919841311 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark30(-20.99165254189252 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark30(-21.002345775747486 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark30(-21.013972265784474 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark30(-21.03499135216434 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark30(-21.083449109692538 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark30(-21.08831695429396 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark30(-21.095784700950432 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark30(-21.102044798919394 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark30(-21.12698499242029 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark30(-21.143742402898027 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark30(-21.173183631823477 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark30(-21.228477882992507 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark30(-21.292107265796048 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark30(-2.1312714981938257 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark30(-21.317744769834164 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark30(-21.342348720114117 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark30(-21.348363337871263 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark30(-21.361880035914865 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark30(-21.408852259656655 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark30(-21.42825895154236 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark30(-2.1450459867528053 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark30(-21.549963178587134 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark30(-21.563359688507376 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark30(-21.575311605590613 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark30(-21.624253331542164 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark30(-21.713442164000398 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark30(-21.715579144814527 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark30(-21.76574045099322 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark30(-21.77705479702385 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark30(-21.811138997226777 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark30(-21.820167240426883 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark30(-21.88581064196393 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark30(-21.928652528204623 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark30(-21.961016290530353 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark30(-21.982210406186155 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark30(-21.987739988057854 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark30(-22.025085727656048 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark30(-22.03166129013627 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark30(-22.048169182529236 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark30(-22.07777004379517 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark30(-22.080249031235894 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark30(-22.094900485817632 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark30(-22.102960057873574 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark30(-2.2119057077354114 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark30(-22.215538585480715 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark30(-22.228023915120957 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark30(-2.222952060286019 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark30(-22.267129585568156 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark30(-22.26856253709242 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark30(-22.27296335964843 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark30(-22.280962401619874 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark30(-22.33955977779047 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark30(-22.355786546423445 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark30(-22.39839462586953 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark30(-2.240484995635896 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark30(-22.44907289344846 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark30(-22.457965278244558 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark30(-22.483169161208366 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark30(-22.513219660755766 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark30(-22.51613638976184 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark30(-22.569804712343554 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark30(-22.573382938457513 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark30(-22.578869995462924 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark30(-22.63561620014862 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark30(-22.63884501472539 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark30(-22.651629519772527 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark30(-2.2679599154564585 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark30(-2.268502850707236 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark30(-22.69672839895385 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark30(-22.730823355571232 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark30(-22.746122076834595 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark30(-22.749712564533482 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark30(-22.767818547113762 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark30(-22.810794430761334 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark30(-22.813432551184505 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark30(-22.906254934894093 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark30(-22.909082208779026 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark30(-22.93673224559194 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark30(-22.974730716624777 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark30(-22.976552156954554 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark30(-22.9904578400115 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark30(-22.99328863189851 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark30(-23.028878726129292 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark30(-23.030878525708573 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark30(-23.062409776828048 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark30(-23.064213579415423 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark30(-23.080704461163194 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark30(-23.087304687240476 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark30(-23.105083365468843 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark30(-23.115479483571335 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark30(-23.1394608467225 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark30(-23.165162064505623 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark30(-23.20791931620616 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark30(-23.21473987514247 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark30(-23.242992795885755 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark30(-23.303307662134927 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark30(-23.332445652137096 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark30(-23.379683942979185 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark30(-23.405238199943184 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark30(-23.425218207059345 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark30(-23.44926287269456 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark30(-23.478150030492117 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark30(-2.3586678993146677 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark30(-23.589131308790527 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark30(-23.592053311889003 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark30(-23.603842261415934 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark30(-23.633608650781724 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark30(-2.3638897322979773 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark30(-23.694573156519212 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark30(-23.705935391071336 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark30(-2.373791307884062 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark30(-23.73870498332566 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark30(-23.740204696400255 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark30(-23.75972026163882 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark30(-23.760971614745813 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark30(-23.76529678258234 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark30(-23.78200095209118 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark30(-23.80360160319796 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark30(-23.82112214134014 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark30(-23.83128018284711 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark30(-23.88850180605347 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark30(-23.935723163884106 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark30(-23.953579371843077 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark30(-24.021406867007926 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark30(-24.07761305420415 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark30(-2.42060226857717 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark30(-24.22837129414775 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark30(-24.247694907653326 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark30(-24.251021344738376 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark30(-24.27653190615611 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark30(-24.27898610690997 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark30(-2.430862758951875 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark30(-2.432390248620038 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark30(-24.388530489966513 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark30(-24.400545885524537 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark30(-24.413178298136827 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark30(-24.422685040211192 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark30(-24.469588120438672 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark30(-24.51791610111509 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark30(-24.526427601269745 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark30(-2.4541974660609185 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark30(-24.542298223572033 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark30(-24.56865880079704 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark30(-24.579220065653857 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark30(-24.597263767245693 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark30(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark30(-24.677679719249056 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark30(-2.470191911057171 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark30(-24.702125305016125 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark30(-24.711595991583394 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark30(-24.718269320862362 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark30(-24.74023321190863 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark30(-24.75880521400488 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark30(-24.822063618506164 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark30(-24.83105120929156 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark30(-24.854400219665422 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark30(-24.86324362368626 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark30(-24.898213068038274 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark30(-24.908145539645773 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark30(-25.017540451143617 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark30(-25.031776549610328 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark30(-25.05632285772994 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark30(-2.505881516562397 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark30(-25.06782898288759 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark30(-25.096358041269085 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark30(-25.152883842427215 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark30(-25.156796323227354 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark30(-25.210981774765926 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark30(-25.25134311482155 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark30(-25.251546858300088 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark30(-25.255129612325916 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark30(-2.528948238491523 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark30(-25.3136953121315 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark30(-25.433523425837663 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark30(-25.43620358520701 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark30(-25.448426986770457 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark30(-25.46015734787808 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark30(-25.468639202474947 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark30(-25.564662400141174 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark30(-25.5882522470299 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark30(-25.676362579339155 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark30(-25.710822852855884 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark30(-25.718926466775898 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark30(-25.734333812852213 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark30(-25.734852235702817 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark30(-25.770278627565332 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark30(-25.80214261911125 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark30(-25.808147471806237 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark30(-25.862916794693433 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark30(-25.8736200193229 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark30(-2.5927888696483734 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark30(-25.946042382178376 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark30(-25.984526444707726 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark30(-25.985841811830852 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark30(-26.016955043663884 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark30(-26.061446726479545 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark30(-26.063980353134397 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark30(-2.617107306439223 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark30(-26.174604556145994 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark30(-26.212104421068886 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark30(-26.219551374925814 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark30(-26.338149069045258 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark30(-26.373248434300663 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark30(-26.37925829625256 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark30(-26.428292562533812 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark30(-2.6445516164120164 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark30(-26.45014585953909 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark30(-26.45393754820597 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark30(-26.491684171923936 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark30(-2.651837984639414 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark30(-26.597096848717342 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark30(-2.660308997809693 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark30(-26.629314498671192 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark30(-26.651080918941688 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark30(-26.7402397456665 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark30(-26.75231689064161 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark30(-26.78751966859258 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark30(-26.81442810288685 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark30(-26.832569540945002 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark30(-26.86069999984892 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark30(-26.878416047511195 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark30(-26.925219203883998 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark30(-26.932411563696547 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark30(-26.96143565493341 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark30(-26.981409421180032 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark30(-26.996081566320512 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark30(-2.705608360618726 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark30(-27.064051612498034 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark30(-27.128768711379664 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark30(-27.14043074929988 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark30(-27.165598464276172 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark30(-27.197441420292208 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark30(-27.207971883762212 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark30(-27.246562005103783 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark30(-2.7295043319874708 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark30(-27.376867542064986 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark30(-27.429646363406277 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark30(-27.43789732919464 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark30(-27.47179686740155 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark30(-27.477099072528446 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark30(-2.751665905188432 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark30(-27.538113496382152 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark30(-27.550165207107398 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark30(-27.577729935098546 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark30(-27.59591436106423 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark30(-27.622994323545385 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark30(-27.630337822400392 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark30(-27.633720465238994 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark30(-27.694234117646104 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark30(-27.713789256442922 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark30(-27.751392102706404 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark30(-27.762485322122714 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark30(-27.76332774030537 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark30(-27.77661155367403 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark30(-27.804232648673178 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark30(-27.812627140140904 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark30(-27.858770777083123 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark30(-27.91101299550789 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark30(-27.919588939809344 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark30(-28.048554350404117 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark30(-28.057149915116526 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark30(-2.8101390438871334 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark30(-28.112471736168956 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark30(-28.140199544972972 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark30(-28.15810314009002 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark30(-28.171067747093744 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark30(-28.179975054505093 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark30(-28.198624579368598 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark30(-28.21017106706654 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark30(-28.211207009028556 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark30(-28.271207378198255 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark30(-28.288592970010583 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark30(-28.317325812734936 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark30(-28.32329838410061 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark30(-28.37184597921845 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark30(-28.3802491303381 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark30(-28.400846671596454 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark30(-28.44359962302741 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark30(-28.452636216684198 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark30(-28.485470612897146 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark30(-28.49310574177541 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark30(-28.512187801073125 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark30(-28.597944205822373 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark30(-28.668657924857442 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark30(-2.871087091227338 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark30(-2.8712041255566163 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark30(-28.712750494282815 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark30(-28.758295596484928 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark30(-28.77901683837429 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark30(-2.880431468120136 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark30(-28.855462149005334 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark30(-28.85954671576316 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark30(-28.885237537876037 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark30(-28.90461959596506 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark30(-2.8928520953213592 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark30(-28.945679131545916 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark30(-29.003123093641264 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark30(-29.032121316458486 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark30(-29.03944848162952 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark30(-29.08996511423571 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark30(-29.100572027595135 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark30(-29.106191188802995 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark30(-29.111663659007462 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark30(-29.171498741670916 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark30(-29.214750358613855 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark30(-29.21585129885375 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark30(-29.229889071742576 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark30(-29.271062648743126 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark30(-29.28821676633588 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark30(2.932770380528396 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark30(-29.370475810105262 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark30(-2.9378869763115887 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark30(-29.384202751730925 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark30(-29.4067304873395 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark30(-29.41712520415787 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark30(-29.444475993412 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark30(-29.447861590061635 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark30(-2.9457884414013193 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark30(-29.458742825744494 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark30(-29.468426311146175 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark30(-29.502377307220584 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark30(-29.509004376530413 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark30(-29.510825194890515 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark30(-29.512031864473443 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark30(-29.526531414530766 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark30(-2.952765299871075 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark30(-29.531589753325278 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark30(-29.534465993293963 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark30(-29.540364380201382 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark30(-29.558251051588385 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark30(-29.56174667644889 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark30(-29.587362547394093 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark30(-29.587883157288616 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark30(-29.63636558747305 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark30(-29.652060848065815 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark30(-29.655222430905724 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark30(-2.9656768021230278 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark30(-29.711663063990883 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark30(-29.71837445074587 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark30(-29.77160227565345 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark30(-29.786125788481897 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark30(-2.9793001998318402 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark30(-2.98092503018448 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark30(-29.85920137459435 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark30(-29.884206897769317 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark30(-29.88892304454089 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark30(-29.938681664786444 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark30(-29.950184371814274 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark30(-30.030363982773082 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark30(-30.0369543916631 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark30(-30.048295359311567 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark30(-30.06569013401284 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark30(-30.09203918890276 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark30(-30.200668950063786 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark30(-30.223683680006246 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark30(-30.23004753879242 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark30(-30.243081256269974 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark30(-30.24613245743717 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark30(-30.26578523442302 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark30(-3.0269752593574424 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark30(-30.293619441054574 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark30(-30.320516682273364 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark30(-30.33231020030007 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark30(-30.44917206558388 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark30(-30.51538627713093 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark30(-30.522618964637886 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark30(-30.56335796706813 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark30(-30.598122739970933 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark30(-30.632257876631414 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark30(-30.695787784676227 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark30(-30.724788628207023 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark30(-30.75165870337861 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark30(-30.779982971066545 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark30(-30.78411314112421 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark30(-30.79813508044991 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark30(-30.817759866959832 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark30(-30.82793715490493 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark30(-30.877663745132594 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark30(-30.97619952966855 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark30(-31.037276600563587 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark30(-31.06117678908933 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark30(-31.07743214319369 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark30(-31.077927123246482 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark30(-31.142089786680515 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark30(-31.200136355037415 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark30(-31.201327983848003 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark30(-31.222993060165464 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark30(-31.228922592182528 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark30(-31.25108632469795 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark30(-31.262544004287136 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark30(-31.2739795524261 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark30(-31.27527959242326 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark30(-31.380617983489785 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark30(-3.138464440797307 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark30(-31.38713521838234 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark30(-31.43116482031732 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark30(-31.474078022558103 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark30(-31.47587793712465 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark30(-31.48220862967021 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark30(-31.486394790111902 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark30(-31.519881426523554 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark30(-31.52934373437597 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark30(-31.54053096960297 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark30(-31.57596601659327 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark30(-31.631851375808594 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark30(-31.63748542670477 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark30(-3.1667640376145982 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark30(-31.677810356872357 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark30(-31.697663302601512 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark30(-31.72833668620467 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark30(-31.776140417206776 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark30(-31.885277240742326 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark30(-31.957538621197543 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark30(-31.957924790925944 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark30(-31.965821926402953 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark30(-31.96691178521462 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark30(-32.000224577911425 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark30(-32.018023113046425 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark30(-32.03500035635571 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark30(-32.03799670307707 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark30(-32.105767821653686 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark30(-32.10741710018294 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark30(-32.149876833100976 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark30(-3.2150211530730815 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark30(-32.19394195620255 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark30(-32.20128676194784 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark30(-32.22112489842131 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark30(-32.22396902522644 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark30(-32.232132160508314 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark30(-32.2821556899884 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark30(-3.2326151694569205 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark30(-3.2389144003556822 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark30(-32.41361053176182 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark30(-32.41872846777048 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark30(-32.43366455613625 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark30(-32.434992594921994 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark30(-32.46402765795955 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark30(-3.252860082770283 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark30(-32.53014268322735 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark30(-3.2532243213550487 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark30(-32.56003798003131 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark30(-32.561051910761975 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark30(-32.57363097651684 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark30(-32.574273102436905 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark30(-32.65388951227064 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark30(-32.66757093095538 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark30(-32.699149508137054 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark30(-32.714404651514826 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark30(-32.7157201073893 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark30(-32.73899848626715 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark30(-32.78359519897663 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark30(-32.808450143435735 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark30(-32.82519720428408 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark30(-32.83163712742265 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark30(-32.837759432818146 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark30(-32.83974689459714 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark30(-3.2855306698500897 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark30(-32.91681883311195 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark30(-33.00484022887704 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark30(-33.066309532910694 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark30(-33.09204482503894 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark30(-33.104042002915506 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark30(-33.168046341286 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark30(-33.18671657112708 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark30(-33.206169040989735 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark30(-33.224855371916576 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark30(-33.242476722077384 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark30(-33.24932292906426 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark30(-33.30514682612031 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark30(-33.364114551499924 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark30(-33.38122761770195 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark30(-33.38282359430586 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark30(-33.41972901360073 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark30(-33.47577504719345 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark30(-33.486511416003054 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark30(-33.512598424812154 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark30(-33.51554424863876 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark30(-33.56775822756923 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark30(-33.579168979201455 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark30(-33.60794248880343 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark30(-33.62893163479221 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark30(-33.66720139435493 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark30(-33.699431581460544 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark30(-33.715776769715845 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark30(-33.77929740843963 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark30(-33.8344972771868 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark30(-33.8598816239911 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark30(-33.86839766121254 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark30(-3.386893505366203 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark30(-33.90350203072113 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark30(-3.3930662233665743 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark30(-33.9701580515178 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark30(-34.01147883441507 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark30(-34.041089473947466 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark30(-3.40492419770311 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark30(-34.08390413628072 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark30(-34.095729433601434 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark30(-34.15228788641677 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark30(-34.29493856497639 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark30(-34.3303617180232 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark30(-34.332837619222786 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark30(-3.434201014489929 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark30(-34.34361612809913 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark30(-34.34463835142884 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark30(-34.40303242557606 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark30(-34.41304179753229 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark30(-34.44660322749564 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark30(-34.45127515552866 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark30(-34.466685593146124 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark30(-34.47435992489201 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark30(-34.48755892098512 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark30(-34.50038994646238 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark30(-34.52850086796579 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark30(-34.55489127678331 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark30(-34.60693918013847 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark30(-34.61694793221601 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark30(-34.65761755911436 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark30(-34.659389079112415 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark30(-34.66513160464366 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark30(-34.69910282549063 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark30(-34.71820133819972 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark30(-34.740433110874875 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark30(-34.75802892053579 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark30(-34.80083434794314 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark30(-34.83045759389489 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark30(-34.83914504931451 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark30(-34.840013355499295 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark30(-34.86109696971435 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark30(-3.4887585390970486 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark30(-34.91325799769956 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark30(-34.91829893700758 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark30(-34.960447715187584 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark30(-34.97535506844898 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark30(-34.9758774884061 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark30(-3.500242893181067 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark30(-35.074152216058735 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark30(-35.11398499309712 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark30(-35.11568081439765 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark30(-35.123221105270545 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark30(-35.12368796564719 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark30(-35.14620748038095 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark30(-35.30112046334963 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark30(-35.317332925932604 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark30(-35.320697709238246 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark30(-35.336896657613636 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark30(-35.39815526310419 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark30(-35.400336090966775 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark30(-35.44184965525625 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark30(-35.516720778763315 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark30(-35.5458710992675 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark30(-35.57237171682442 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark30(-35.594959013361915 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark30(-35.62739620991296 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark30(-35.64418111077721 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark30(-35.68214440035487 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark30(-35.697338890977576 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark30(-35.7286091765459 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark30(-35.73735633181319 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark30(-35.74572745845377 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark30(-35.75378637191761 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark30(-35.79409374769273 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark30(-35.819587254157994 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark30(-35.870636430308295 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark30(-35.90501720505932 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark30(-35.920695873173926 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark30(-35.93768165077613 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark30(-35.943644488985086 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark30(-35.9558666293554 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark30(-35.95819416325202 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark30(-35.9654245355121 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark30(-35.990867113470216 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark30(-36.04344945122584 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark30(-36.10273997849567 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark30(-36.131403036338526 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark30(-36.16727784882128 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark30(-3.616965430933533 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark30(-36.21787807014223 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark30(-36.272279082305744 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark30(-36.3028662141667 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark30(-36.30678948093706 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark30(-36.32048350230206 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark30(-3.6344835891339216 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark30(-36.34668300333643 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark30(-36.371836248102674 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark30(-36.38745962751848 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark30(-36.39737981821833 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark30(-36.43570774144598 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark30(-36.44222817010267 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark30(-36.456043829709195 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark30(-36.46383401768638 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark30(-36.50043383718333 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark30(-36.50374034391823 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark30(-36.51392092804717 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark30(-36.52230015479767 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark30(-36.54132045911665 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark30(-36.5445060796815 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark30(-36.58676813585453 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark30(-36.61678614621784 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark30(-36.623548174920195 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark30(-36.634441998654424 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark30(-36.63751880046833 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark30(-36.65127153504375 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark30(-36.655827709938585 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark30(-36.72383473663749 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark30(-36.762566245191074 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark30(-36.77081581474846 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark30(-36.79004728076685 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark30(-36.80590499670296 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark30(-36.8382610368579 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark30(-3.6906687465624515 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark30(-36.96116220054495 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark30(-36.97814285155685 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark30(-36.980281598857715 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark30(-36.998230687282366 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark30(-37.01103400137286 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark30(-37.01996974124808 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark30(-37.02146367945656 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark30(-37.100303374769325 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark30(-37.10355140834598 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark30(-37.11269521618492 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark30(-37.12348780063366 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark30(-37.123845224371735 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark30(-3.714215654037872 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark30(-3.7149276122922856 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark30(-3.7149868956253016 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark30(-37.17565457739494 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark30(-3.7243784671972264 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark30(-37.269011724126955 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark30(-37.28298549721447 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark30(-37.28940027551613 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark30(-37.31733715155918 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark30(-37.349705147667535 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark30(-37.36234452881837 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark30(-37.36788477282118 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark30(-37.392758559441994 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark30(-37.424845116919236 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark30(-37.45165257402423 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark30(-37.45528654335899 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark30(-37.46091425462228 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark30(-37.485293563227096 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark30(-37.4879427409754 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark30(-37.512056282681236 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark30(-37.51927710461223 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark30(-37.5496868780492 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark30(-37.57547504822381 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark30(-37.59101342052602 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark30(-37.617215706160145 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark30(-37.70296029830309 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark30(-37.71300524451975 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark30(-37.72273633742347 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark30(-37.759107099577925 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark30(-3.7765290434728485 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark30(-3.7809018880509626 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark30(-37.811612260091884 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark30(-37.812315508582415 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark30(-37.81474111718863 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark30(-37.823593459911734 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark30(-37.841567465830984 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark30(-37.877400347222846 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark30(-37.90430454637832 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark30(-37.946827383404866 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark30(-37.989958215004705 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark30(-38.005341573000976 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark30(-38.04033791939185 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark30(-38.07766993501107 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark30(-38.09016832128083 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark30(-38.12390722133894 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark30(-38.13038996904488 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark30(-38.13952264234608 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark30(-38.14854664152667 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark30(-38.17100024311553 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark30(-38.17458399139999 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark30(-3.825080632310133 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark30(-38.26974977444466 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark30(-38.272487626416016 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark30(-38.29496881174812 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark30(-38.29592098043146 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark30(-38.3989823074915 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark30(-3.8450708367294055 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark30(-38.493117528402784 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark30(-38.521958915492014 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark30(-38.53049478498001 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark30(-38.532521843127654 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark30(-3.8542014442904957 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark30(-38.546035096166385 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark30(-38.56237053320075 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark30(-38.56912431876432 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark30(-38.58588877912157 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark30(-38.62297894014137 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark30(-38.625234244478854 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark30(-38.62542990610003 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark30(-38.62665166089365 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark30(-38.647515685862246 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark30(-3.865733660807848 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark30(-38.6606770735191 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark30(-38.68917523208913 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark30(-38.697279883484036 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark30(-3.871607341507314 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark30(-38.71883264984528 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark30(-38.758814886356795 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark30(-38.79076207587233 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark30(-38.815530156115166 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark30(-38.82240566384094 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark30(-3.8826845539551726 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark30(-38.871908145382776 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark30(-38.8776505787031 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark30(-38.921884379542874 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark30(-3.8937145439294625 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark30(-38.942726678958465 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark30(-3.9039668331029276 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark30(-39.0543257540513 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark30(-39.077268568223424 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark30(-39.11676623637119 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark30(-39.16558683318123 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark30(-39.17099716386683 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark30(-39.17293080231994 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark30(-39.18220481059036 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark30(-39.1825322151161 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark30(-39.2824720853105 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark30(-39.33500559077847 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark30(-39.34507657348145 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark30(-3.936532401730844 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark30(-39.36715653591396 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark30(-39.39396179440975 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark30(-39.444590520259105 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark30(-39.45759334851113 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark30(-39.47289392034825 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark30(-39.510268612551954 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark30(-3.954170101693876 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark30(-39.59973250164283 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark30(-39.613713477012126 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark30(-39.62031533488264 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark30(-39.62052189028227 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark30(-39.63936627828319 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark30(-39.65164460357518 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark30(-39.69732311907188 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark30(-39.7356316406938 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark30(-39.75398308342912 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark30(-39.777928830523955 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark30(-39.79365440636964 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark30(-3.9816035769322298 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark30(-39.87583224188938 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark30(-39.88677587478515 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark30(-39.9448168862103 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark30(-39.952834541938984 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark30(-39.96698601722615 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark30(-39.97845231033856 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark30(-3.9979203669918917 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark30(-39.98483312323309 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark30(-39.98603948566397 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark30(-40.01504050937581 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark30(-40.03124033232843 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark30(-40.05310154794246 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark30(-40.07701931329968 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark30(-40.095961178452065 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark30(-40.14189425603645 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark30(-40.20507611131761 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark30(-40.21517179801679 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark30(-4.029877022539097 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark30(-40.326854584187274 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark30(-40.35356378757777 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark30(-40.37460156995367 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark30(-40.377101936146545 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark30(-40.40051520283847 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark30(-40.410390194658795 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark30(-40.412557358151126 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark30(-40.45674897943148 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark30(-40.46734345964165 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark30(-40.47741810733045 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark30(-40.51973784494385 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark30(-40.55097914185393 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark30(-40.558061997756376 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark30(-40.573806522532976 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark30(-40.61056672821108 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark30(-40.636630499476546 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark30(-40.636732058045254 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark30(-40.66257067557262 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark30(-4.074929780809697 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark30(-40.7507340994806 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark30(-40.776311322385 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark30(-40.847826780363164 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark30(-40.84977632551365 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark30(-40.97490665904353 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark30(-41.003069485195034 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark30(-41.04525464283191 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark30(-41.067340777752335 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark30(-41.07313216162298 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark30(-41.08436051711904 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark30(-41.114730658784346 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark30(-41.1829876060428 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark30(-41.22656743271813 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark30(-41.2389561511836 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark30(-41.258463518238564 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark30(-41.30442313447025 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark30(-41.331133643363785 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark30(-41.35943821771224 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark30(-41.370432345934674 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark30(-41.373956051646665 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark30(-41.374367674681054 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark30(-41.3748431485665 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark30(-41.37667676752168 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark30(-41.41330716728289 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark30(-4.141669739110327 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark30(-41.42211132985292 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark30(-41.44723824404086 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark30(-41.4610796700988 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark30(-41.47058939301953 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark30(-41.48126868085018 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark30(-41.54115415169635 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark30(-41.54914443180318 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark30(-4.159466107732541 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark30(-41.59558216003008 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark30(-41.61167114052482 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark30(-41.61441222813635 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark30(-4.163150814821549 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark30(-41.65307920148822 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark30(-41.66790499210424 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark30(-41.67087336859219 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark30(-41.71127643919477 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark30(-41.76807211881892 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark30(-41.80842803365212 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark30(-41.8875911896929 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark30(-41.89198786228445 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark30(-41.897596922181044 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark30(-41.90571903324876 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark30(-41.93321868970577 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark30(-41.96383450638672 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark30(-4.201211994898017 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark30(-42.05756033280541 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark30(-42.06969377493004 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark30(-42.0989596769493 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark30(-42.16351334288382 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark30(-42.233765497719 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark30(-42.24346279295255 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark30(-42.25573572027772 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark30(-42.28234456988831 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark30(-42.32601185806539 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark30(-42.34275637125362 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark30(-42.381024646559 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark30(-42.44686091073086 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark30(-42.47538669052899 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark30(-42.48971025486967 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark30(-42.52590559452103 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark30(-42.53001102377745 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark30(-4.259987531611074 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark30(-42.6167200594405 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark30(-42.62340582812223 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark30(-42.631265752533885 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark30(-42.63517567657209 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark30(-42.63904353766805 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark30(-42.65354989580925 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark30(-42.730093793210536 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark30(-42.73531943566302 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark30(-42.77128005152191 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark30(-42.77796171112751 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark30(-42.7882160408545 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark30(-42.82939762490754 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark30(-4.284682260091401 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark30(-42.85408122665086 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark30(-42.86887519778448 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark30(-42.923685048782076 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark30(-42.927997590210445 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark30(-42.95708507091407 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark30(-43.00409681705932 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark30(-43.063876209181196 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark30(-43.09254539389757 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark30(-43.142654673338264 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark30(-43.162372244306766 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark30(-43.16534192944299 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark30(-43.1656825741858 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark30(-43.200576877624044 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark30(-43.21122256994667 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark30(-43.23921668263721 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark30(-4.32417603855157 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark30(-43.24308634990474 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark30(-43.25841442419425 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark30(-43.2925750902712 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark30(-43.29790538929177 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark30(-43.38108775800933 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark30(-43.43177762271002 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark30(-4.345275513931199 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark30(-4.346028216056652 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark30(-43.468866118258084 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark30(-43.48483343974701 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark30(-43.539978445794226 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark30(-43.56165100878939 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark30(-43.57991276959563 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark30(-43.60486441185636 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark30(-43.643308015638226 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark30(-43.682739007348026 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark30(-4.368340148355614 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark30(-43.72674038099511 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark30(-43.76988065748522 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark30(-4.38092247740957 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark30(-4.383724078453781 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark30(-43.85258012953892 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark30(-43.88545885065691 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark30(-43.91906098522007 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark30(-43.92403754306453 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark30(-43.931748015483166 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark30(-43.94763794790828 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark30(-43.98483453841073 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark30(-43.98754084721581 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark30(-44.007294530548414 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark30(-44.01964390789095 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark30(-44.040740898361676 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark30(-44.081896721426105 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark30(-4.409224902835859 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark30(-44.09596581383739 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark30(-44.107490200973906 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark30(-44.111146353800024 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark30(-44.14461520786131 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark30(-44.14574817875945 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark30(-44.17535248722295 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark30(-44.19715747054831 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark30(-44.19768843136562 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark30(-44.22196218010151 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark30(-44.23401754657406 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark30(-44.237707054833606 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark30(-44.26702004677634 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark30(-4.427953607295748 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark30(-44.28107596709956 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark30(-44.31609042684994 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark30(-44.360696087321294 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark30(-44.3722228812609 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark30(-44.40459496858822 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark30(-44.41336432113911 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark30(-4.441923953062826 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark30(-44.43169593097485 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark30(-44.44491170918254 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark30(-44.45749034358477 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark30(-44.46687700771792 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark30(-44.52692826714657 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark30(-44.53562622561744 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark30(-44.601250870339506 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark30(-44.60601547196779 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark30(-44.611043017438234 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark30(-44.6406351032284 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark30(-44.6736729443467 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark30(-44.703447352409185 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark30(-4.47253739075299 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark30(-44.74320288301232 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark30(-4.475393509924757 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark30(-44.76021133390071 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark30(-44.76312432187879 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark30(-44.801050178724225 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark30(-44.82901596489101 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark30(-44.83574593096029 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark30(-44.849239466265914 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark30(-44.85776768000627 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark30(-44.92349489718901 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark30(-44.931945186755115 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark30(-44.93668135168561 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark30(-44.97149253576882 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark30(-44.972370731799714 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark30(-44.9742188933306 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark30(-44.97519066939262 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark30(-4.5065711946873535 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark30(-4.516437857266055 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark30(-45.178944261859314 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark30(-45.19018691158827 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark30(-45.233327485213096 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark30(-45.250103595768486 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark30(-45.30477910606054 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark30(-45.31520650290095 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark30(-45.33715267912892 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark30(-45.35361739941961 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark30(-45.35996525709214 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark30(-45.365520056285625 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark30(-4.536833424458322 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark30(-45.39041401441914 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark30(-45.41488841192558 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark30(-45.417647284618745 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark30(-45.421498634823166 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark30(-45.44932153749275 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark30(-45.48090521112449 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark30(-45.482547732329714 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark30(-45.4887540874962 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark30(-45.505258530344996 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark30(-45.57575288891864 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark30(-4.55857440116678 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark30(-45.58785699916834 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark30(-45.612908885422996 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark30(-45.62672422068328 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark30(-45.6429701468819 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark30(-45.64652926222077 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark30(-45.65047474170674 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark30(-45.687977909465815 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark30(-45.69003659191644 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark30(-45.74664186772761 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark30(-45.810547141524125 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark30(-4.5882404412323865 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark30(-45.948946653111136 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark30(-46.000584591432634 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark30(-46.03107201825591 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark30(-46.09901274065849 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark30(-46.12425896339833 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark30(-46.13105798946755 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark30(-46.134453935776484 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark30(-46.15526961531056 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark30(-46.17647825933779 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark30(-46.24691000906742 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark30(-46.27590187267838 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark30(-46.315698402763616 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark30(-46.337516854181196 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark30(-46.35777976722941 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark30(-46.38192430993027 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark30(-46.403838729939785 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark30(-46.40978474954991 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark30(-46.44029241599368 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark30(-46.45843967116243 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark30(-46.47792897826164 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark30(-46.49786530140629 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark30(-46.52514845963158 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark30(-46.58078484260073 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark30(-46.595705992199974 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark30(-46.598523513662386 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark30(-46.61451905785978 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark30(-46.61537343577989 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark30(-46.634884414412305 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark30(-46.63989028271918 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark30(-46.733224425377664 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark30(-46.779555880425775 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark30(-46.82378640104656 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark30(-46.841848908854054 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark30(-46.87451052182172 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark30(-46.89068290655158 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark30(-46.903921747304466 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark30(-46.90975760680338 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark30(-46.97558669725434 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark30(-46.987995692925445 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark30(-46.99608483378568 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark30(-47.01900878000793 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark30(-47.03475234765983 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark30(-47.083906198055224 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark30(-47.11972632631438 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark30(-47.18664518361058 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark30(-47.217515693075754 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark30(-47.217532545389496 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark30(-47.22844208646082 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark30(-47.25426020482723 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark30(-47.273452993097884 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark30(-47.34241858478505 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark30(-47.35583254931475 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark30(-4.747467287886423 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark30(-47.51984377160956 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark30(-47.533911627947575 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark30(-47.53681374337822 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark30(-47.58020887790244 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark30(-47.67612236929668 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark30(-47.72477895251115 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark30(-47.72939787887596 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark30(-47.734115746999464 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark30(-47.75219122821572 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark30(-47.827972636656455 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark30(-47.838910236878476 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark30(-47.87334336062201 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark30(-47.880760670360445 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark30(-47.891641003833094 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark30(-47.9583397042751 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark30(-48.0377133166843 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark30(-48.08497879557512 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark30(-48.11118069385736 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark30(-48.14128033213172 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark30(-48.14327751683363 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark30(-48.15438872735274 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark30(-48.18631951222145 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark30(-48.187556573119636 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark30(-48.20464114344729 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark30(-48.24045527740619 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark30(-48.241501732520284 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark30(-48.25118856829034 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark30(-48.289452211017036 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark30(-48.32637367205519 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark30(-48.354572484101446 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark30(-48.36725089869525 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark30(-48.38030161327187 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark30(-4.838219221031665 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark30(-48.40353182196506 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark30(-48.509470544100886 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark30(-4.85130003598735 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark30(-48.513719887551375 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark30(-48.518303081443136 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark30(-48.52636443772986 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark30(-4.854085957768703 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark30(-48.57068906479738 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark30(-48.57871255153485 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark30(-48.60284428080463 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark30(-48.6123182315106 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark30(-4.862222394280138 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark30(-48.720793578013996 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark30(-48.7247980926786 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark30(-4.874374354878782 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark30(-48.86209950936544 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark30(-48.87586335663927 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark30(-48.887632860162796 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark30(-48.906851228739654 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark30(-48.91163765056579 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark30(-48.91528890109589 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark30(-48.963057012716725 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark30(-4.902109772015976 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark30(-49.03289832841313 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark30(-49.03604062136138 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark30(-49.10532774397931 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark30(-49.156010063030855 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark30(-49.15848587516434 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark30(-49.27506549727152 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark30(-49.294189506290145 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark30(-49.29829091886209 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark30(-49.304306633770764 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark30(-49.30531276655612 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark30(-4.938327209154949 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark30(-49.439799494664506 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark30(-49.46288996088541 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark30(-49.465297963038246 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark30(-49.47392557708217 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark30(-49.490846875425866 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark30(-4.949978872161992 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark30(-49.517503802417416 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark30(-49.53074351019286 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark30(-49.580082871071404 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark30(-49.59158148300406 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark30(-49.6051301561663 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark30(-49.60771422667365 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark30(-49.630515411785666 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark30(-49.64565606958693 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark30(-49.73012424653591 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark30(-49.74549925011611 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark30(-49.77023139434107 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark30(-49.80356512188049 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark30(-4.981181219669423 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark30(-4.986170032217927 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark30(-49.94560127743222 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark30(-49.96338421356079 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark30(-49.98669280924648 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark30(-49.99510307444153 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark30(-5.000033398514773 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark30(-50.06580951054313 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark30(-50.08636491328762 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark30(-50.09522275238736 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark30(-50.099344960601776 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark30(-50.10525596769915 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark30(-50.10776095433496 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark30(-50.12069651720166 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark30(-50.12318967800289 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark30(-50.188611986037856 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark30(-50.19316768436883 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark30(-50.19442368094036 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark30(-50.2148129715654 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark30(-50.22114090011938 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark30(-5.02492013683937 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark30(-50.275288381042046 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark30(-50.33153076233112 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark30(-5.03431582352529 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark30(-50.39406829241386 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark30(-50.410261789185505 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark30(-50.43213431642442 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark30(-50.433027255417365 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark30(-50.45674550621848 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark30(-50.47184202571682 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark30(-50.488232423388865 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark30(-5.05044356372855 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark30(-50.537533356415686 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark30(-50.58251388400081 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark30(-50.59790463656595 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark30(-5.06023729983383 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark30(-50.63322581433161 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark30(-50.64139089410371 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark30(-50.64710739328644 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark30(-50.65509542015554 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark30(-50.667955097338655 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark30(-50.70657440566087 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark30(-50.73006770038921 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark30(-5.075703831711763 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark30(-50.777510889110225 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark30(-50.78316757690138 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark30(-50.80699135827844 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark30(-50.81958682379035 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark30(-50.866547876947024 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark30(-50.886463763125555 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark30(-50.89343908381916 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark30(-5.091366004493295 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark30(-50.95360183789155 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark30(-50.978235105221636 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark30(-50.982185472512256 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark30(-50.99267625544825 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark30(-51.01137444103141 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark30(-51.01720896269506 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark30(-51.02570690256976 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark30(-51.03575046940891 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark30(-51.0603782565888 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark30(-51.069674077562446 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark30(-51.10148875832537 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark30(-51.13047182638142 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark30(-51.199998836322 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark30(-51.242254413481604 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark30(-51.25348167820081 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark30(-51.277524889036094 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark30(-51.28268546294619 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark30(-51.28427801067381 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark30(-51.3854539575916 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark30(-51.38741804875622 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark30(-51.400222134283744 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark30(-51.427579537717214 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark30(-51.469066688352584 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark30(-51.47852496383254 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark30(-51.48927166219344 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark30(-51.499882815716624 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark30(-51.505510396798 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark30(-51.51886063458571 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark30(-5.156744930234197 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark30(-51.572377988534356 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark30(-51.59276455783986 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark30(-51.643599747424695 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark30(-51.668446706316765 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark30(-51.7263249808505 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark30(-51.741739503320176 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark30(-51.80776151250566 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark30(-51.81512116006868 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark30(-51.854059000005506 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark30(-51.862364232957184 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark30(-51.864856847784615 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark30(-51.955395714063826 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark30(-51.96835536385331 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark30(-51.99114169716863 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark30(-52.007766473155435 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark30(-52.08104555521176 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark30(-52.08668713939959 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark30(-52.092541324322816 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark30(-52.0958087596362 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark30(-52.121306353161636 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark30(-52.15350790941875 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark30(-52.160118058505645 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark30(-52.16516377736582 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark30(-52.16563761780644 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark30(-52.202520058256184 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark30(-52.24631313796595 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark30(-52.25835455330375 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark30(-52.26201466776086 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark30(-52.28931318877146 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark30(-52.300430613770786 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark30(-52.31456143410613 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark30(-52.34123779610738 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark30(-52.35474136920626 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark30(-52.35871405690335 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark30(-52.39158114022473 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark30(-52.394261575440446 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark30(-52.43019473500332 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark30(-52.43542982857268 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark30(-52.45451994700885 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark30(-52.51374690243917 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark30(-52.54581927448931 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark30(-52.6004399279343 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark30(-52.63382605205314 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark30(-5.263501771188373 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark30(-52.63969136417024 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark30(-52.66030495252467 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark30(-52.67712696340254 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark30(-52.73682630945875 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark30(-5.274454496125514 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark30(-52.744817160986535 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark30(-52.84599436303337 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark30(-52.88980232196252 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark30(-52.88999895677235 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark30(-52.89936171538354 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark30(-52.9014755866485 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark30(-52.9422180263877 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark30(-53.01592311405585 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark30(-53.03374791144613 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark30(-53.04549941525871 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark30(-53.080719848481905 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark30(-53.09593945097619 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark30(-53.10559712128145 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark30(-53.10801704713561 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark30(-53.18214465735325 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark30(-53.19148398510642 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark30(-53.391904600179394 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark30(-53.393966366499555 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark30(-53.43548872249122 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark30(-53.4453609202705 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark30(-53.44732441123949 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark30(-53.452347345213425 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark30(-53.477486780987405 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark30(-53.497075769828164 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark30(-53.50539950865787 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark30(-53.52723017659433 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark30(-5.359674747234223 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark30(-53.60889870274317 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark30(-53.639785417405285 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark30(-53.64276316335355 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark30(-53.69242298835395 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark30(-53.69322049404228 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark30(-53.704813405861444 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark30(-53.72376738193625 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark30(-53.74271801490453 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark30(-53.74424338812285 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark30(-53.75741484742771 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark30(-53.78008421284339 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark30(-53.79329504196415 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark30(-53.808191822781424 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark30(-53.85631879769206 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark30(-53.86850250003419 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark30(-53.92326557409199 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark30(-53.94360840861068 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark30(-53.963128388984515 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark30(-53.99214877432483 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark30(-54.005261427041276 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark30(-54.05161613734401 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark30(-54.05662427539877 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark30(-54.067774511106734 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark30(-54.07802827132981 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark30(-54.103519587384156 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark30(-54.115360772628684 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark30(-54.154537623290324 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark30(-54.1847143514864 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark30(-54.209445186976524 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark30(-54.215835178414 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark30(-54.27441975107068 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark30(-54.35713288386601 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark30(-54.4026167330685 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark30(-54.51429011020363 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark30(-54.535729342673655 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark30(-5.454543363261848 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark30(-54.57648908742121 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark30(-54.59736553312455 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark30(-54.6035319083054 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark30(-54.627344534355075 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark30(-54.640952103887706 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark30(-5.46558230158098 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark30(-54.65642100210428 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark30(-54.66039956790561 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark30(-54.691360247560404 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark30(-54.69618192503405 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark30(-54.727362062524065 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark30(-5.475099925505816 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark30(-54.75580025734325 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark30(-5.4765029082220735 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark30(-54.81315030605751 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark30(-54.82373273887462 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark30(-54.84489103086574 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark30(-54.8470651473119 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark30(-54.87623173024823 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark30(-54.890198406989185 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark30(-54.91291090237929 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark30(-54.91445423780776 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark30(-54.922381107526675 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark30(-54.95705312500603 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark30(-5.496297942613154 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark30(-54.963623528319516 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark30(-54.97976922957506 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark30(-54.988209196513374 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark30(-54.9974730111465 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark30(-55.090025927021415 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark30(-55.10410608643721 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark30(-55.1073805397529 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark30(-55.1165249522785 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark30(-55.12535969063619 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark30(-55.129398036242286 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark30(-5.518237557669465 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark30(-55.20913297218266 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark30(-55.21884251187692 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark30(-5.524682152832256 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark30(-55.252607867951674 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark30(-55.27038627592569 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark30(-55.2757223527377 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark30(-55.30600345154013 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark30(-55.318957773157074 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark30(-55.325891890525945 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark30(-55.32961527177207 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark30(-55.33824575347217 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark30(-55.34090583651328 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark30(-55.35270126726044 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark30(-55.3735958662599 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark30(-55.39652815793281 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark30(-55.40046541360803 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark30(-55.404958038252474 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark30(-55.41885083323452 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark30(-55.43236495667876 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark30(-55.436545404602185 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark30(-55.447085799536836 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark30(-55.500239012904196 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark30(-55.51698559999403 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark30(-55.536018312348865 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark30(-55.57256233372119 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark30(-55.614390848781255 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark30(-55.630847753883586 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark30(-55.63167211261866 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark30(-55.641581565582655 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark30(-55.69302672472867 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark30(-55.70121657033673 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark30(-5.570803170811516 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark30(-55.74101739168891 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark30(-55.74653356105463 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark30(-55.81147389037899 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark30(-55.815884341444686 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark30(-55.82084012591635 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark30(-55.83163029553309 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark30(-55.862740287974646 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark30(-55.86980163601014 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark30(-55.87007457626398 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark30(-55.90380745637646 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark30(-55.93641908166296 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark30(-55.94286191774061 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark30(-55.96847186747582 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark30(-55.974542293298214 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark30(-56.01312997137147 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark30(-56.027504743508196 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark30(-56.05417394188865 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark30(-56.074694242097614 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark30(-56.074966768420694 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark30(-56.07501950001197 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark30(-56.08749563522868 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark30(-5.610307366389762 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark30(-56.11384009480076 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark30(-56.14521824670182 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark30(-56.17813332804742 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark30(-56.186069111702764 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark30(-56.19671718393142 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark30(-56.274242772743335 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark30(-5.629721573329391 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark30(-56.31113997836936 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark30(-56.36340693928001 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark30(-56.39980732178431 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark30(-56.40794914489249 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark30(-56.4180321505368 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark30(-56.42251134883789 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark30(-56.434828050897835 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark30(-56.47057833328213 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark30(-56.481715753160856 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark30(-56.484924963400914 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark30(-56.51307789911011 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark30(-56.527736966400276 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark30(-56.55656187307962 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark30(-56.58158170178129 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark30(-5.658410486869499 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark30(-56.61842549999718 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark30(-56.62942494393137 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark30(-56.64675468206437 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark30(-5.670665095254378 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark30(-56.80681771118652 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark30(-56.84141032339169 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark30(-56.848994777594996 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark30(-56.89542805899619 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark30(-56.938416545282976 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark30(-56.962757331293986 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark30(-57.015850217842925 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark30(-57.07270992914146 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark30(-57.10828582449088 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark30(-57.161616779440024 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark30(-57.17608783512491 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark30(-57.180472005095396 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark30(-57.199616716912494 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark30(-57.245714918541424 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark30(-57.25246396769121 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark30(-57.26700611020681 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark30(-5.728050594316699 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark30(-57.30337127310803 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark30(-57.30483704530131 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark30(-5.730921400126803 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark30(-57.319122696741665 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark30(-57.35786793973743 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark30(-57.36596180453586 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark30(-57.400293656763424 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark30(-57.409707958123704 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark30(-5.7470252146408285 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark30(-57.515430856149564 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark30(-57.56098664728344 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark30(-57.64028816235624 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark30(-5.770946845903779 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark30(-57.72038068318699 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark30(-57.724037925921444 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark30(-57.74416765434349 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark30(-5.777842338695137 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark30(-57.85138624337451 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark30(-5.787914156978985 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark30(-57.8997005625725 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark30(-57.90133038926217 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark30(-57.90389594439893 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark30(-57.91369444673846 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark30(-57.9274709106681 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark30(-57.942711902263454 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark30(-57.94867916704043 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark30(-58.047878988980074 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark30(-5.8084537931 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark30(-58.108212518870594 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark30(-58.12433593373578 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark30(-58.12672566747354 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark30(-58.18608057438974 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark30(-58.241099994676794 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark30(-58.252357088152415 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark30(-58.25446612793381 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark30(-58.272674494853625 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark30(-58.27739761015047 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark30(-58.34061199051239 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark30(-58.36678338865726 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark30(-58.38662855840171 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark30(-58.386977782134444 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark30(-58.39400384290989 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark30(-58.40452825241089 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark30(-58.43758946695799 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark30(-58.44328577823592 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark30(-58.457339600587076 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark30(-58.45736667753583 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark30(-58.56428953643362 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark30(-58.60555867968769 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark30(-58.63380565820795 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark30(-58.6496007842521 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark30(-58.66439641987582 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark30(-58.669700765461876 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark30(-58.67431724748249 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark30(-58.67832441056968 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark30(-58.69500665273597 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark30(-58.73891461801153 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark30(-58.805715695366814 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark30(-58.84245569587003 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark30(-58.88342114437464 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark30(-58.908207990421026 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark30(-58.9119242936297 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark30(-5.892202265003803 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark30(-58.95054656438279 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark30(-58.973942738665876 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark30(-59.04797432281181 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark30(-59.06908971956746 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark30(-59.08235814822591 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark30(-59.139108213589545 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark30(-59.15189708407353 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark30(-59.16687696671363 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark30(-59.174625868402806 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark30(-59.17811694969765 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark30(-59.187832743530386 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark30(-59.23223303822971 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark30(-59.2393054708368 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark30(-59.24061155774427 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark30(-59.24726253685824 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark30(-59.24962832227556 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark30(-59.278152065410474 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark30(-59.28108994774877 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark30(-59.31473105635852 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark30(-59.3288527695782 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark30(-59.332444162954204 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark30(-59.33741522922069 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark30(-59.3757043315559 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark30(-59.41785769870904 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark30(-59.4387621858411 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark30(-59.46278220704133 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark30(-59.49389822584577 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark30(-59.53473044518105 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark30(-5.953672666831537 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark30(-59.55989547011276 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark30(-5.9562134784057434 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark30(-59.61646488126884 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark30(-59.61957371710027 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark30(-59.650395307980865 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark30(-59.66935777621287 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark30(-59.68007668673692 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark30(-59.6858832215305 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark30(-59.763404729700255 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark30(-59.77939052422649 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark30(-59.805433403794225 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark30(-59.85294965622696 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark30(-59.85303245429052 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark30(-59.85611823108237 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark30(-59.87833312515243 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark30(-59.9452990230789 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark30(-59.95613658410812 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark30(-60.024428130093725 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark30(-60.06900326543776 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark30(-60.06951087750707 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark30(-60.08219755266664 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark30(-60.08284204858809 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark30(-60.08324419653079 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark30(-60.08426510074483 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark30(-60.12829944516558 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark30(-60.13173143779791 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark30(-60.13541847290562 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark30(-60.150074865715375 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark30(-60.20083858173892 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark30(-60.22076411997328 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark30(-60.22179197630875 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark30(-60.30126466016259 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark30(-60.33070051408129 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark30(-60.33903171861705 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark30(-60.348429005271306 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark30(-60.38557697627016 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark30(-60.3937818296872 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark30(-60.42604039910031 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark30(-60.43735470282652 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark30(-60.442501457268214 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark30(-60.4561669768273 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark30(-60.46912602344081 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark30(-60.480154854072474 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark30(-60.503527589705186 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark30(-60.56029583987759 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark30(-6.056350321470177 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark30(-60.56522391136401 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark30(-60.58437816191833 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark30(-60.628956154997304 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark30(-60.640705492738725 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark30(-60.69290740551128 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark30(-60.70442808929493 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark30(-60.761261812695125 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark30(-60.846616083998754 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark30(-60.84936629028137 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark30(-6.08681271439626 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark30(-60.86992194303236 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark30(-60.89152099298971 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark30(-60.89493213052049 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark30(-60.954386864362654 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark30(-60.989385895823965 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark30(-61.001287461617636 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark30(-61.07237805344028 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark30(-6.1077036995350795 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark30(-61.09559741710706 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark30(-61.10916118190026 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark30(-61.13138025037892 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark30(-61.241968422433125 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark30(-61.24279737236791 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark30(-61.283868964203215 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark30(-61.28866315465154 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark30(-6.132179066653549 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark30(-61.33412780229133 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark30(-61.33466033063011 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark30(-61.38175072492875 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark30(-61.44699589112563 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark30(-61.44982044847642 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark30(-61.4977534377088 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark30(-61.5129872021571 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark30(-61.547888126345285 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark30(-61.55422256845742 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark30(-61.58804472554928 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark30(-61.595243742735775 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark30(-61.599128228110885 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark30(-6.162975822039155E-33 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark30(-6.162985982814305 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark30(-61.63538286488976 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark30(-61.66182390225352 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark30(-61.69272591820065 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark30(-6.170830776796549 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark30(-61.71210163594472 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark30(-61.73133587070707 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark30(-61.74128450953145 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark30(-61.748331748223784 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark30(-61.86201359527548 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark30(-61.881815976224686 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark30(-61.885810461849154 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark30(-6.191331971168438 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark30(-61.943822827946214 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark30(-61.97263187522155 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark30(-62.00013123532426 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark30(-62.01470308085688 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark30(-62.01643041390324 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark30(-62.03761106259249 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark30(-6.204958364768245 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark30(-62.06582285496789 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark30(-62.08746586061731 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark30(-62.131156312114946 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark30(-62.17773387477441 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark30(-62.19528480213856 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark30(-62.19755467632824 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark30(-62.23117165877314 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark30(-62.24399016036606 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark30(-62.274880868956075 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark30(-62.29680295985818 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark30(-62.307096116186635 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark30(-62.317748047637565 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark30(-6.232880585344276 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark30(-62.38189143388904 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark30(-62.39677510898407 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark30(-62.450792340357154 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark30(-62.46970328336046 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark30(-62.476271438382305 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark30(-6.247775505262808 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark30(-62.52192117231823 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark30(-62.6195132069772 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark30(-62.6297782903821 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark30(-62.69713378759953 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark30(-6.277347249747606 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark30(-62.7754662641606 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark30(-62.78433614541079 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark30(-62.818096161679705 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark30(-62.83128300662324 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark30(-62.862552441773744 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark30(-62.874322553072524 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark30(-6.291455733940296 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark30(-62.92266059392468 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark30(-6.294975367575688 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark30(-62.959260206194976 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark30(-62.994055686786155 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark30(-6.3006671725946575 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark30(-63.00906391180745 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark30(-63.019286559317614 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark30(-63.03469096378811 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark30(-63.08020983371423 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark30(-63.146866962180326 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark30(-63.16363643464922 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark30(-63.17729637684379 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark30(-6.321960195294281 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark30(-63.232473644602536 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark30(-63.23267095702256 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark30(-63.23359795493353 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark30(-63.234614616671415 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark30(-63.25986913496524 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark30(-63.26378602158245 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark30(-63.28356967322249 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark30(-63.30815632876858 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark30(-63.31065508290177 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark30(-63.3237314014746 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark30(-63.32454562984127 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark30(-63.352701355474906 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark30(-63.375910261750114 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark30(-63.37615395530716 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark30(-63.460642343056506 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark30(-63.476291612849444 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark30(-63.48378635486187 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark30(-63.489485740185245 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark30(-63.50891266147467 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark30(-63.556459087846484 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark30(-63.59039713599044 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark30(-63.609814148577804 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark30(-63.62323207578553 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark30(-63.66332266790691 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark30(-63.69251977187058 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark30(-63.69908642729987 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark30(-63.73910005849008 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark30(-63.752659114609656 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark30(-63.76623575025289 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark30(-63.819780984060934 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark30(-63.825169675469965 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark30(-63.827496778851646 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark30(-63.82780096709473 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark30(-63.87278921265238 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark30(-63.90321411317077 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark30(-63.913861118754234 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark30(-63.978600998061744 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark30(-6.401802857169088 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark30(-64.07299709674656 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark30(-64.09861661091603 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark30(-64.11982248599087 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark30(-64.12871930055866 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark30(-6.415036830866455 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark30(-64.18814515416405 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark30(-6.419184640850517 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark30(-64.33726117690966 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark30(-64.3689201101842 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark30(-64.50147156363606 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark30(-64.54007772021598 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark30(-64.55589824775998 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark30(-64.59508372364269 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark30(-64.59717733392283 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark30(-64.6015140907052 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark30(-64.60176685011211 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark30(-64.64131176995127 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark30(-64.66084211535726 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark30(-6.468571748364042 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark30(-64.69554178612728 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark30(-64.72347264272636 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark30(-64.72602405598376 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark30(-64.74926776765267 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark30(-64.74962112498244 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark30(-64.75289413938899 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark30(-64.76584509937837 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark30(-64.7888129031928 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark30(-64.78926243779034 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark30(-64.79086587176454 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark30(-64.79335180397561 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark30(-64.80230670476371 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark30(-64.90442600625097 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark30(-6.491846784065089 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark30(-64.95619530120369 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark30(-64.96536365250323 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark30(-64.9930874051659 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark30(-65.0490439994656 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark30(-65.05991555233194 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark30(-65.063291146859 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark30(-65.10458948845314 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark30(-65.14704768454249 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark30(-65.18274818304607 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark30(-65.22612151748018 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark30(-65.24059614158331 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark30(-65.25235798628803 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark30(-65.29190405322817 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark30(-65.29400655928791 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark30(-65.31098643937429 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark30(-65.33571938646054 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark30(-65.34288289335342 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark30(-6.534932195972402 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark30(-6.535828460879301 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark30(-65.38140108010816 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark30(-6.539376848828567 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark30(-65.41256967682072 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark30(-65.41733896426965 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark30(-65.42400630383514 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark30(-65.45511871257807 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark30(-65.46175737865912 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark30(-65.50578374218925 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark30(-65.51492752223753 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark30(-65.63430190476392 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark30(-65.66199517161382 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark30(-65.66246536865853 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark30(-65.682703036543 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark30(-65.68642727156822 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark30(-6.569223626516546 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark30(-65.80597167093005 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark30(-65.81606001800361 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark30(-65.82978783988239 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark30(-65.83722733783834 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark30(-65.85802150505808 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark30(-65.89748615833943 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark30(-65.9321543498857 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark30(-65.9570879819689 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark30(-65.96644760630846 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark30(-65.98411287574936 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark30(-65.98905167774589 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark30(-66.04745444562454 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark30(-66.09836559807704 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark30(-66.12241485262275 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark30(-66.19540565279692 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark30(-66.20231975954411 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark30(-66.20273298313853 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark30(-66.25968776230513 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark30(-66.28798937576686 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark30(-66.29644596155484 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark30(-66.35075879691877 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark30(-66.36114657617617 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark30(-66.39672168463031 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark30(-66.40138063865004 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark30(-66.44358762939856 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark30(-66.45349332126071 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark30(-66.4549219743705 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark30(-66.53948022680922 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark30(-66.58234851572355 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark30(-66.5867664631912 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark30(-66.59297749586108 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark30(-66.5951023642641 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark30(-66.59623292387751 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark30(-6.660171012301831 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark30(-66.61316552882334 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark30(-66.61907707456582 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark30(-66.65012470707467 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark30(-66.65016861706269 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark30(-66.6570329920364 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark30(-66.68733397884922 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark30(-66.74639123062798 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark30(-66.74930642854322 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark30(-66.75759456334097 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark30(-66.77280755430557 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark30(-66.77587620966898 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark30(-66.78955287332518 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark30(-66.83116782760554 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark30(-66.84315733697024 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark30(-66.89093634902412 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark30(-66.91508769288049 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark30(-66.94645320440301 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark30(-66.94768825692881 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark30(-67.05151121266226 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark30(-67.09683804789353 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark30(-67.10409630927359 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark30(-67.1397472814667 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark30(-67.15022701544112 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark30(-67.15756047725247 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark30(-67.26010710093266 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark30(-67.26513279499807 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark30(-67.27709071221844 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark30(-67.28774717394002 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark30(-6.729095743201924 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark30(-67.30233217025636 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark30(-67.33280003576694 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark30(-67.4213467484592 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark30(-67.42830167088835 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark30(-67.4293100689514 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark30(-67.4359582167916 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark30(-67.45481992129443 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark30(-67.45910536165226 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark30(-67.50905350510068 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark30(-67.50913144556594 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark30(-67.52473025593767 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark30(-67.52506027716363 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark30(-67.68032490563385 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark30(-67.68088794657798 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark30(-67.71579271102505 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark30(-67.82849116159264 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark30(-67.87784574099187 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark30(-67.89714492581976 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark30(-67.90205118512173 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark30(-67.92844854961639 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark30(-67.93537031725131 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark30(-67.93994682946817 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark30(-67.94136611374431 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark30(-67.94399995311466 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark30(-68.02097602859448 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark30(-68.05524068145161 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark30(-68.10179789948887 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark30(-68.15430383862078 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark30(-68.211524618294 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark30(-68.21294875164543 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark30(-68.22838458190476 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark30(-68.32738058549947 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark30(-68.34876397986997 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark30(-68.35634393680105 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark30(-68.38323189266977 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark30(-68.38587831590195 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark30(-68.39762876538691 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark30(-6.841569488547151 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark30(-68.41585648969253 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark30(-68.47570042877663 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark30(-68.48501874733957 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark30(-68.50805338939895 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark30(-68.51001803880483 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark30(-68.52676285356227 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark30(-68.53467464489975 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark30(-68.56150470854836 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark30(-68.56697276922665 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark30(-68.61651706229644 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark30(-68.61885546956188 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark30(-6.862073944146857 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark30(-68.63948288037687 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark30(-6.864268539201632 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark30(-68.66939508327962 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark30(-68.68177282662225 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark30(-6.86957407354636 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark30(-68.75566394420278 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark30(-68.76985085740873 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark30(-68.77391793125618 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark30(-68.77698646701754 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark30(-68.7817144802974 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark30(-68.78831568041628 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark30(-68.79158732982921 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark30(-68.79267120416091 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark30(-68.802159631867 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark30(-68.80301439871005 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark30(-68.81117452688494 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark30(-68.87303598321336 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark30(-68.97354260194481 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark30(-69.03402707097261 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark30(-69.06104813648074 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark30(-69.07587028989892 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark30(-69.09207028373679 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark30(-69.10287199628837 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark30(-69.10358709846076 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark30(-69.1525492892845 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark30(-69.15300672681153 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark30(-6.917854889172361 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark30(-69.19179657190301 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark30(-69.20950752290219 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark30(-69.2158318213056 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark30(-69.22717145922368 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark30(-69.24636882809259 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark30(-69.25164923631633 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark30(-69.2566719582102 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark30(-69.3487654305311 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark30(-69.35181835568234 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark30(-69.3574263592504 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark30(-69.36975458847601 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark30(-69.37112849700382 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark30(-69.38446034892263 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark30(-69.44976840932443 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark30(-69.49813237813393 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark30(-69.51466291721103 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark30(-69.53594563144986 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark30(-6.9566093998831775 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark30(-69.56864992979123 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark30(-69.57164614126661 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark30(-6.957788689216841 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark30(-69.63191547085977 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark30(-69.67474466016772 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark30(-69.69377451236367 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark30(-69.6974082965493 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark30(-69.7033975651097 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark30(-69.70711583072391 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark30(-69.73433114695762 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark30(-69.79078847694132 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark30(-69.81209303845435 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark30(-69.83727582818793 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark30(-6.9866576299204155 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark30(-69.87094548276882 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark30(-6.989588801175302 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark30(-6.992368858931755 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark30(-69.98036192679614 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark30(-70.02448393623726 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark30(-70.03680932003873 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark30(-70.23132130443798 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark30(-70.2620662438272 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark30(-70.27206071380297 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark30(-70.2939174485228 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark30(-70.29892619095807 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark30(-70.3259913504067 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark30(-70.34466977633625 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark30(-70.35202415521506 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark30(-70.38919023157027 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark30(-7.04115712165283 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark30(-70.41405652254377 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark30(-7.043040076616734 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark30(-70.43732760173799 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark30(-70.43861803874324 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark30(-70.44912993210666 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark30(-7.052212680535888 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark30(-70.52520511460602 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark30(-70.55840302953473 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark30(-70.57248157224944 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark30(-70.62296844250722 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark30(-70.62528376642445 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark30(-70.66760358414956 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark30(-70.67236503590371 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark30(-7.068737648182676 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark30(-70.69774657153245 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark30(-70.70568218899564 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark30(-70.73909289380929 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark30(-70.75919183048096 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark30(-70.80325615125219 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark30(-70.84168810903002 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark30(-70.90821572742007 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark30(-70.93322651763224 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark30(-7.093781416215421 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark30(-70.95146862163979 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark30(-70.96024191564752 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark30(-70.97140335247624 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark30(-70.97657708934229 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark30(-71.096095205001 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark30(-71.09639348701577 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark30(-7.111994407470007 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark30(-71.1218805553198 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark30(-71.12218459957779 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark30(-7.113120172726255 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark30(-71.17698110595845 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark30(-71.18592487217617 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark30(-71.22507934806568 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark30(-71.2523030356905 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark30(-71.26861485669792 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark30(-71.29155537339307 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark30(-71.31180521771212 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark30(-71.31731087097037 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark30(-71.325569992821 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark30(-71.36336924277948 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark30(-71.37177133323745 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark30(-71.3968985993663 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark30(-71.39968541187727 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark30(-71.42115483833786 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark30(-71.43460715081531 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark30(-71.45121878040537 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark30(-71.54127199593904 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark30(-71.59633213163166 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark30(-71.62611260182499 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark30(-71.64184027195301 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark30(-7.165876178946888 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark30(-71.72999777264626 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark30(-71.7418849001372 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark30(-71.74593247076848 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark30(-71.75039830375025 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark30(-71.75482434189712 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark30(-71.79504570855966 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark30(-71.83159271502255 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark30(-71.87050028997604 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark30(-71.88733212131999 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark30(-72.05498769223304 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark30(-72.08274469844942 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark30(-72.08586523402285 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark30(-72.10904132827622 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark30(-72.13205168772718 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark30(-72.1440119959089 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark30(-72.1773462973305 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark30(-72.18024207058804 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark30(-72.19327221427903 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark30(-72.19396972872754 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark30(-72.20465288276243 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark30(-72.21487807985704 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark30(-72.21742154429933 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark30(-72.2284047303612 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark30(-72.2349108498368 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark30(-72.2429548061809 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark30(-72.27260371435898 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark30(-7.228252300648407 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark30(-72.31173233580297 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark30(-72.32961727530034 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark30(-72.34874996935383 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark30(-72.3661063280721 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark30(-72.37353688695968 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark30(-72.4621623518596 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark30(-72.46417718300162 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark30(-72.51369166751797 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark30(-72.5251492831809 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark30(-72.54350237973956 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark30(-72.56270370884421 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark30(-72.576867763564 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark30(-72.70364524414575 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark30(-72.73723243317531 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark30(-72.74139635798761 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark30(-72.79844290443785 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark30(-72.80581907646058 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark30(-72.82052998891541 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark30(-72.86855566390574 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark30(-72.86890389715583 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark30(-72.875860594199 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark30(-72.97169145625935 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark30(-72.98994629481894 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark30(-73.08648645265994 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark30(-73.10570799451955 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark30(-73.10869615026672 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark30(-73.12923037340204 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark30(-73.16914526636589 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark30(-73.25036544151527 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark30(-73.31214335520019 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark30(-73.33146945030012 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark30(-73.34360062750132 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark30(-73.35492330853646 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark30(-73.36322909082666 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark30(-7.336485263012804 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark30(-73.36599126990934 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark30(-73.38276440006959 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark30(-73.46454909058231 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark30(-73.54599634463315 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark30(-73.54616088950303 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark30(-73.55356296581931 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark30(-73.56654764865722 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark30(-73.58010318520132 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark30(-73.63487997389406 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark30(-73.64958419436651 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark30(-73.72530018155189 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark30(-73.72756107517841 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark30(-73.75216837470724 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark30(-73.7527985689338 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark30(-73.77265212450263 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark30(-73.79322107419932 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark30(-73.79939285060313 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark30(-73.85416000693041 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark30(-73.91240892716905 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark30(-73.92667006356 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark30(-73.93130148222662 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark30(-73.97244660840896 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark30(-74.01209097117129 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark30(-74.01524218621178 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark30(-7.40388533567608 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark30(-7.404903264270473 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark30(-74.05666766679322 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark30(-74.06840590391164 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark30(-74.07115163099034 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark30(-7.4077641849443125 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark30(-74.2111693043918 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark30(-74.25637217732955 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark30(-74.2899447061576 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark30(-74.32601448540896 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark30(-7.434701526713013 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark30(-74.36632429185224 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark30(-74.38954045846431 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark30(-74.40044924411052 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark30(-74.4047976421157 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark30(-74.41572996863226 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark30(-74.47609689075676 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark30(-74.53099545320516 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark30(-74.55045226900921 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark30(-7.456357199052462 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark30(-74.61088872774648 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark30(-74.6115554038717 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark30(-74.64321807374583 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark30(-74.67188588875575 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark30(-74.67482617626567 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark30(-74.71367750412199 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark30(-74.71879672235687 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark30(-74.73662142168516 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark30(-74.7787864945517 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark30(-74.80133138493296 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark30(-74.84198275757268 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark30(-7.485665661647417 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark30(-74.85686227208284 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark30(-74.89651809901805 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark30(-74.91525877517864 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark30(-74.97085500321162 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark30(-74.97195403545652 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark30(-74.99217408212249 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark30(-75.00225517825683 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark30(-75.01096853899423 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark30(-75.01532197911038 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark30(-75.04479193978162 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark30(-75.04761648293837 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark30(-75.08302948966636 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark30(-75.0851598198029 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark30(-7.509019112215199 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark30(-75.09665837292175 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark30(-75.15245792057061 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark30(-75.2466259281352 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark30(-75.25191001301978 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark30(-75.2847333520345 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark30(-75.29055234278201 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark30(-75.29844926307867 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark30(-75.31842705099186 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark30(-75.33994221600096 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark30(-75.40092202351491 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark30(-7.543090680710037 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark30(-75.4524049906947 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark30(-75.49125684677777 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark30(-75.54096484185501 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark30(-75.56177723547705 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark30(-75.61702356455693 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark30(-75.72070405272868 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark30(-75.77500897575558 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark30(-75.81277222096068 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark30(-75.85134190104444 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark30(-75.90287192368197 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark30(-75.94142542646765 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark30(-75.9431731961524 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark30(-75.96073725059816 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark30(-7.601560424772558 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark30(-76.0747960177931 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark30(-76.14416681166942 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark30(-76.15372887765454 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark30(-76.17549628478972 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark30(-76.17663879013755 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark30(-76.18495847110896 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark30(-76.22092471679349 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark30(-76.25425434155207 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark30(-76.26840082596698 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark30(-76.26978504104767 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark30(-76.34363627934351 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark30(-76.37884457052007 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark30(-76.42105889216155 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark30(-76.48535801867409 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark30(-76.52627189603211 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark30(-76.54581566572429 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark30(-76.57064709010426 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark30(-7.657980037754953 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark30(-7.663606609070101 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark30(-76.64079203185142 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark30(-76.64624578666081 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark30(-76.64643269061486 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark30(-76.65213863064555 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark30(-76.69708248399479 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark30(-76.70156348405683 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark30(-76.7182423458186 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark30(-76.74649534540099 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark30(-76.75722081917402 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark30(-76.77420916272806 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark30(-76.78505962053445 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark30(-76.79381458197265 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark30(-76.81422022745002 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark30(-76.83711095943045 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark30(-76.83901744618797 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark30(-76.90941588565241 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark30(-76.91210400594142 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark30(-7.692550710642138 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark30(-76.93718029054746 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark30(-76.94246460296799 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark30(-76.99266829904565 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark30(-77.0251419371774 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark30(-77.04504108810255 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark30(-77.07698014480151 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark30(-77.09752796573927 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark30(-77.22957754154211 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark30(-77.24891368822868 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark30(-77.24914018501543 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark30(-77.260035823295 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark30(-77.26276430454448 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark30(-7.726439996348589 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark30(-77.28678447122198 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark30(-77.34487541347288 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark30(-77.35844961205996 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark30(-77.36909282330015 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark30(-77.40708649741164 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark30(-77.42562646283461 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark30(-77.43711533507252 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark30(-7.745742101162392 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark30(-77.57602137044245 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark30(-77.57921678091766 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark30(-77.59981059598803 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark30(-77.61396369000045 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark30(-77.65754737859362 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark30(-77.71543701164762 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark30(-7.772923700926086 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark30(-77.80521862929102 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark30(-77.84617373165247 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark30(-77.85498882071863 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark30(-77.9115166640488 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark30(-77.92990588855358 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark30(-77.94358710729894 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark30(-77.95512639789132 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark30(-77.96298294116582 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark30(-78.0499288949966 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark30(-78.06154466339738 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark30(-78.0832704105493 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark30(-78.09935663421975 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark30(-78.17906545336388 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark30(-78.20568075597419 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark30(-78.20934366810668 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark30(-78.21294287622518 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark30(-7.8244338481834035 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark30(-78.41618505793716 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark30(-78.42128121143143 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark30(-78.43519922057753 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark30(-78.46645157012419 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark30(-78.47421879232465 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark30(-78.49506666997819 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark30(-78.50186375419767 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark30(-78.50888412041992 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark30(-7.8529241632959526 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark30(-78.61188894027302 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark30(-78.6433271403059 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark30(-78.64795022841233 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark30(-78.6979083574006 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark30(-78.72553427931285 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark30(-78.75221095263858 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark30(-78.78097704787046 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark30(-78.78209826430052 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark30(-78.78709115593907 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark30(-78.83553658309854 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark30(-78.85328000551877 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark30(-78.85730396342628 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark30(-78.86466767058617 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark30(-78.8971188163284 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark30(-78.9149513838523 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark30(-78.92731711960363 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark30(-7.898129621875768 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark30(-78.98667672174606 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark30(-78.99593273643416 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark30(-79.03169216974888 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark30(-79.04026594790511 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark30(-79.05281007015657 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark30(-79.10890457691933 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark30(-7.917065447339411 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark30(-79.23548351235796 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark30(-79.23647820367455 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark30(-79.23725539843127 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark30(-79.25595000135581 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark30(-79.28712677513528 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark30(-7.929154907798036 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark30(-79.29632696750788 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark30(-79.30741805618042 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark30(-79.46321696887242 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark30(-79.47827863973845 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark30(-79.48896333141431 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark30(-79.5753208659616 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark30(-79.61050281556723 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark30(-79.616039590762 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark30(-79.61663611278257 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark30(-79.65782431088277 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark30(-7.967387150583278 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark30(-79.67980979162077 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark30(-79.68001369883552 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark30(-79.7105712679008 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark30(-79.72390023913874 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark30(-79.74006310309642 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark30(-79.80686503427148 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark30(-79.8249810389255 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark30(-7.985107684078983 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark30(-79.85419397825845 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark30(-79.88559245918256 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark30(-79.90165996993824 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark30(-79.95694341178081 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark30(-79.97744115971956 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark30(-80.05332821529416 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark30(-80.0886064393655 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark30(-80.11608034194953 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark30(-80.12666665631781 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark30(-80.19630795778379 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark30(-80.22693140879574 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark30(-80.24275305620151 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark30(-80.27017404516066 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark30(-80.31273670339479 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark30(-80.3130007112732 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark30(-80.32424235258979 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark30(-80.33772927543637 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark30(-80.43449259623972 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark30(-80.46905385688481 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark30(-80.47864194659584 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark30(-80.5394653273714 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark30(-80.54652195810013 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark30(-8.0558272393191 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark30(-80.58328247474769 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark30(-80.58484898043574 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark30(-80.5851832380981 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark30(-80.59394262221062 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark30(-80.60617223919529 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark30(-80.64766313235985 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark30(-80.70423637479756 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark30(-80.71130033404346 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark30(-80.71366202340855 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark30(-80.74063562726054 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark30(-80.75892760811554 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark30(-80.79516671133325 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark30(-80.83926946053984 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark30(-8.088642371913906 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark30(-80.89381915297523 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark30(-80.9449404568817 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark30(-80.98222781332763 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark30(-80.98525773175238 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark30(-81.00437621026546 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark30(-81.01189165658292 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark30(-81.11294469308412 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark30(-81.11827956478447 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark30(-81.14740625483456 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark30(-81.1670442188692 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark30(-8.117246291851202 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark30(-81.18433759118528 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark30(-81.30464673175186 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark30(-81.36656807009928 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark30(-8.139310253948935 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark30(-81.39874342934061 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark30(-81.42823577612559 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark30(-81.45799083439226 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark30(-8.147112689435176 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark30(-81.48263978804458 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark30(-81.4828306681104 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark30(-81.48808272116177 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark30(-81.57615997140446 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark30(-81.577650724763 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark30(-81.64650667811733 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark30(-81.67115914306513 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark30(-81.69687920317024 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark30(-81.72606077329135 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark30(-81.76430510127544 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark30(-81.79836220020886 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark30(-81.81079238005344 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark30(-81.82625041896799 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark30(-81.84023171493331 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark30(-8.18584495772798 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark30(-81.87375364440821 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark30(-81.87865765099542 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark30(-81.93406191399085 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark30(-81.99747906066386 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark30(-82.00934030443072 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark30(-82.01001874762488 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark30(-82.02413681428223 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark30(-82.02439013163726 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark30(-82.02994706223109 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark30(-82.046184089721 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark30(-82.06272805366834 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark30(-82.09384876634284 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark30(-82.10581044871037 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark30(-82.17690284943504 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark30(-8.218913366220278 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark30(-82.20837521461578 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark30(-82.23816373414854 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark30(-82.26698609163617 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark30(-82.26921567364266 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark30(-82.29350645192488 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark30(-82.31110617138108 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark30(-82.32009704371461 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark30(-82.32212702114683 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark30(-82.37867836736501 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark30(-82.40910307598512 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark30(-82.42432002957074 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark30(-82.42985377698322 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark30(-82.47793732499625 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark30(-82.49994196821137 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark30(-82.54871035253919 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark30(-82.56311029073584 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark30(-82.59715563128776 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark30(-82.6101318396328 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark30(-82.6164064302451 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark30(-82.66280424309699 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark30(-82.66386590636577 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark30(-82.66664634352641 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark30(-82.76144189822534 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark30(-82.78326663666763 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark30(-82.79333925887195 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark30(-82.79910044541015 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark30(-82.80636119428222 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark30(-82.80779070394225 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark30(-82.8091646859435 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark30(-82.83200247938136 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark30(-82.83530695725041 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark30(-82.85841904929443 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark30(-82.87380296991181 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark30(-82.93368907074182 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark30(-82.95231717847469 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark30(-82.96255876122989 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark30(-83.00740402173683 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark30(-83.0122159753089 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark30(-8.302381737313368 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark30(-83.05075085487937 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark30(-83.07503118698514 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark30(-8.307753761487518 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark30(-83.11532936981216 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark30(-83.17846154214669 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark30(-83.1956892348339 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark30(-8.322327531486991 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark30(-83.23603271066122 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark30(-83.25690368191502 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark30(-83.29450085510322 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark30(-83.30926621399293 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark30(-83.30983884826142 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark30(-83.3169961350623 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark30(-83.33400218149983 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark30(-83.3396368666829 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark30(-83.35938008550603 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark30(-83.38252380966097 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark30(-83.40092395310833 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark30(-83.42474787329209 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark30(-83.42491546839554 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark30(-83.43682112489248 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark30(-83.4408346469269 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark30(-83.44472451487255 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark30(-83.48748808153545 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark30(-83.57254953955348 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark30(-83.59863740078819 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark30(-83.60283077358865 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark30(-83.62140842612288 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark30(-83.62684568805182 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark30(-83.68305647993427 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark30(-83.7412684145232 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark30(-83.7723126110291 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark30(-83.78892959405238 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark30(-83.82294828720549 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark30(-83.875996568839 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark30(-83.91441563589419 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark30(-83.93713727028214 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark30(-83.95199774677633 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark30(-84.02746687397892 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark30(-84.06347406324221 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark30(-84.09337486459194 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark30(-84.15638264541141 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark30(-84.17510611702224 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark30(-84.21657733934984 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark30(-84.21709640757902 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark30(-84.23763603872439 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark30(-84.28771049994724 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark30(-84.32100792996471 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark30(-84.34489718819745 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark30(-84.36756365392509 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark30(-84.3881404637524 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark30(-84.3945012599718 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark30(-84.40213969024954 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark30(-84.43802506682087 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark30(-84.44790007871777 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark30(-84.46058028570079 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark30(-84.46179376690395 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark30(-84.46317802570711 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark30(-84.49287541280901 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark30(-84.50693160241246 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark30(-84.57266119834873 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark30(-84.57359663435685 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark30(-84.58749430541303 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark30(-84.59658747605583 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark30(-8.460268382120503 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark30(-84.61155081236578 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark30(-84.62423870927698 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark30(-84.62872819478433 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark30(-84.6465084842585 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark30(-84.66874039675658 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark30(-84.69732187383143 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark30(-84.70561433891979 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark30(-84.74399066161804 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark30(-84.75193789798692 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark30(-8.47522930556633 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark30(-84.77135200563872 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark30(-84.80652799145953 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark30(-84.95005739096607 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark30(-84.95048729720496 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark30(-85.02861142291593 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark30(-85.05175320239945 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark30(-85.05523937060164 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark30(-85.10855480245397 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark30(-85.11014627873689 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark30(-8.5115249596017 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark30(-85.12847698492916 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark30(-85.13520750718526 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark30(-85.14333674296854 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark30(-85.16112352618256 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark30(-85.19309680693556 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark30(-85.20640554731412 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark30(-85.20949593907582 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark30(-85.27496842633246 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark30(-85.28064134001538 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark30(-85.28639537952314 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark30(-85.30135015155517 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark30(-85.33615133177008 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark30(-85.35027525681365 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark30(-85.3887147895427 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark30(-85.42131935420845 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark30(-85.42691393897444 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark30(-85.4420912282925 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark30(-85.44737240452514 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark30(-85.60339969020174 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark30(-85.61452145577681 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark30(-85.6320144137303 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark30(-85.66121684480699 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark30(-85.66568071267362 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark30(-85.66982507353396 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark30(-85.67357412812966 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark30(-85.73080674877022 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark30(-85.74294987747521 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark30(-85.77000005739774 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark30(-85.77675131716447 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark30(-85.84182776299096 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark30(-85.86120552832286 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark30(-85.87970848245648 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark30(-85.90619227872172 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark30(-85.91418077846753 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark30(-85.92452303782063 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark30(-85.92657131265938 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark30(-85.9546730114447 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark30(-85.97799228885881 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark30(-85.98209768582514 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark30(-85.99245694587403 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark30(-86.03774569439899 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark30(-86.06086365335716 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark30(-86.07523807011313 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark30(-86.08208082552831 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark30(-86.0875066748219 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark30(-86.09068164194122 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark30(-86.13610240091695 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark30(-86.22138331214437 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark30(-86.22409405574847 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark30(-86.24532141554668 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark30(-86.24980444915677 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark30(-86.25959120316786 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark30(-8.629549906265893 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark30(-86.31941144582815 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark30(-86.3361682873351 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark30(-86.34367845040028 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark30(-86.34838527638271 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark30(-86.35756528134382 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark30(-86.36616522021396 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark30(-86.3678593896052 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark30(-86.3780392092103 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark30(-86.38077740625762 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark30(-86.38994418311606 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark30(-86.45496644775639 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark30(-8.64925898793534 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark30(-86.50787941780467 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark30(-86.52459288721724 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark30(-86.5423969038817 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark30(-86.55158593771029 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark30(-86.55946412020134 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark30(-86.57384557754366 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark30(-86.57441280386551 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark30(-8.66264822860802 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark30(-8.662695361011004 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark30(-86.62782267472053 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark30(-8.66376583303827 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark30(-86.6380277436759 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark30(-86.64923719450962 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark30(-86.68239171900971 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark30(-86.69497499536844 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark30(-86.71957736068256 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark30(-86.78263358676593 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark30(-86.80317826977497 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark30(-8.682723640464232 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark30(-86.85395207582813 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark30(-86.85674587565238 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark30(-86.87444711240244 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark30(-86.91913366965498 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark30(-86.92067029566384 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark30(-86.94218891825099 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark30(-86.95993933982888 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark30(-86.98984807576284 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark30(-87.005865237056 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark30(-87.03817317495893 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark30(-87.04421102842392 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark30(-87.04621321927554 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark30(-87.05222877850767 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark30(-87.08950899100765 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark30(-87.10736554053733 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark30(-87.11657480224906 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark30(-87.1392499532698 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark30(-8.7161348136392 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark30(-87.18280827950184 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark30(-87.21064566351035 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark30(-87.21088836482609 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark30(-87.24625602175115 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark30(-87.31017082370889 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark30(-87.3261773977628 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark30(-87.39530228847306 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark30(-87.40973140728931 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark30(-8.744498929777336 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark30(-87.44693242739334 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark30(-87.46056725778129 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark30(-87.47881897730079 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark30(-87.5075037689071 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark30(-87.50926333399798 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark30(-87.5358871018201 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark30(-8.757763115202039 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark30(-87.60672163288419 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark30(-87.61166514061534 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark30(-87.61694653669865 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark30(-87.63130409636838 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark30(-87.64603347075098 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark30(-87.65774519542117 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark30(-8.766801134652098 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark30(-87.67039472692582 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark30(-87.67130212840027 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark30(-87.67424434552436 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark30(-87.68215803705395 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark30(-87.68461670785526 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark30(-8.769376552780386 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark30(-87.76017647140844 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark30(-8.777045011039945 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark30(-87.77476115514594 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark30(-87.79282014203707 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark30(-87.8505115107715 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark30(-88.01864416303984 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark30(-8.803735583766553 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark30(-88.04553473128252 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark30(-88.04896346835271 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark30(-88.11084978143566 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark30(-88.12137127869181 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark30(-88.12804321841415 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark30(-88.1486841276112 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark30(-88.15005368058053 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark30(-88.17970952808851 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark30(-88.20522772872246 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark30(-88.26462159180298 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark30(-8.828103771957771 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark30(-88.30042607399926 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark30(-88.32499439148107 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark30(-88.3254609179464 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark30(-88.3324935760313 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark30(-88.36565717523355 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark30(-88.39520610835203 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark30(-88.39823343547772 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark30(-88.45440663291934 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark30(-88.46125571285248 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark30(-88.46188117403644 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark30(-88.47101765803731 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark30(-88.48197450635014 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark30(-88.50180843435824 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark30(-88.51926099313117 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark30(-88.527821047613 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark30(-88.57973331634659 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark30(-88.58670876685673 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark30(-88.62348062014338 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark30(-88.64920749543053 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark30(-8.867039260706619 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark30(-88.71229969345575 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark30(-88.71359523897344 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark30(-88.7152577285609 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark30(-88.73755449966703 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark30(-8.874679239134494 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark30(-88.77515849365662 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark30(-8.878694774805254 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark30(-88.79242832420415 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark30(-88.80683729717853 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark30(-88.82032103096292 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark30(-88.85318332413219 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark30(-88.91006165095652 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark30(-88.96692151547299 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark30(-88.96749413180831 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark30(-88.96964137307211 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark30(-88.98555871096123 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark30(-88.99486987410552 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark30(-89.07191321100896 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark30(-89.11526301191196 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark30(-89.14317240009923 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark30(-89.15684273776623 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark30(-89.1759922268151 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark30(-89.24095790592861 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark30(-89.24302704850584 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark30(-89.25283909131315 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark30(-89.2697123195677 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark30(-89.28382536042072 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark30(-89.29502914631821 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark30(-89.31883138417625 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark30(-8.932643714472462 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark30(-89.37106938718826 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark30(-89.37850021563673 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark30(-89.38682786841179 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark30(-89.44281972117649 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark30(-89.4585952916591 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark30(-89.46586366501903 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark30(-89.46983397376744 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark30(-8.947134285799024 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark30(-89.4833979410744 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark30(-89.4888447213697 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark30(-89.51070056499839 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark30(-89.51427194588881 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark30(-8.954635698209728 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark30(-89.57523973729411 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark30(-89.57871270217427 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark30(-89.62299520745798 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark30(-89.62467063977127 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark30(-89.62820040097694 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark30(-89.63297042016407 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark30(-89.63721286503696 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark30(-8.967869766645691 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark30(-89.71117768036241 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark30(-89.7756595090782 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark30(-89.81832345000736 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark30(-89.8299073121006 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark30(-89.84890589775321 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark30(-89.864832531077 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark30(-89.87408892820399 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark30(-89.91383878803882 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark30(-89.95648468361146 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark30(-89.97582638758558 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark30(-89.99557921907892 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark30(-90.04453044348399 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark30(-90.04553752937426 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark30(-90.09333335684227 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark30(-90.11039300626047 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark30(-90.143755895055 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark30(-90.14914792718523 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark30(-90.1609288284942 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark30(-90.18088456348832 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark30(-90.2390225294898 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark30(-90.25366688875265 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark30(-90.26305340116983 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark30(-90.2784913910402 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark30(-90.32097682240672 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark30(-90.32540978125267 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark30(-90.35201431830535 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark30(-90.4040630712045 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark30(-90.40858337733708 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark30(-90.41240952320722 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark30(-90.42816600345039 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark30(-90.4485303706269 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark30(-90.48289793809197 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark30(-90.48851815851575 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark30(-90.49603413324377 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark30(-90.50778346586634 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark30(-90.5262714416454 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark30(-90.52634017464081 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark30(-90.54302642715216 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark30(-90.55635943705673 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark30(-90.59668952020394 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark30(-9.060600238286767 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark30(-90.61927710483361 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark30(-90.66170991035078 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark30(-90.76428466154162 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark30(-90.79343776061796 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark30(-90.80936968765616 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark30(-9.090695054767608 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark30(-90.93746877222026 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark30(-90.94267235944247 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark30(-91.03867831177352 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark30(-91.04017600043757 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark30(-91.07053961986375 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark30(-91.0916711632459 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark30(-91.1123590365298 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark30(-91.16992551357546 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark30(-9.118107901367154 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark30(-91.18476967131946 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark30(-91.19194688216068 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark30(-91.19603660205541 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark30(-91.20789164841239 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark30(-91.26274862820443 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark30(-91.28693046980645 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark30(-91.36312972127703 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark30(-91.36661325237657 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark30(-91.36668059462399 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark30(-91.40651632358217 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark30(-91.40899350666429 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark30(-91.46117046119866 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark30(-91.5971028430135 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark30(-91.61412879199871 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark30(-91.62119702902123 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark30(-91.67364647947677 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark30(-91.68217901505872 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark30(-91.69510773083343 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark30(-91.69795806893109 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark30(-91.70587632619309 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark30(-91.76185533822905 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark30(-91.76226478626666 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark30(-91.9093363319392 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark30(-91.92773569872399 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark30(-91.9413302035541 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark30(-91.99495366881112 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark30(-91.99943004732359 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark30(-92.00158293057382 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark30(-92.01182051344752 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark30(-92.01292642973297 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark30(-92.02201017626459 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark30(-92.07127767401289 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark30(-92.09934504696741 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark30(-92.12391810987735 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark30(-92.12447849377945 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark30(-92.1684810381108 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark30(-92.19207791628172 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark30(-92.22507776276447 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark30(-92.23615270118147 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark30(-9.223615714131526 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark30(-92.27531351424678 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark30(-92.41702220924716 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark30(-92.41753982419512 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark30(-92.42440164773653 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark30(-92.44812059339705 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark30(-9.244923441777857 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark30(-92.47936173050408 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark30(-92.50502160149085 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark30(-92.54525034189042 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark30(-9.256142898455437 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark30(-92.60253714451161 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark30(-92.63889452195986 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark30(-92.63942149572335 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark30(-92.63995457093523 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark30(-9.264221488331216 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark30(-92.65732453136788 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark30(-92.67900504598532 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark30(-92.73306335771933 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark30(-92.75829026657101 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark30(-9.284627043227943 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark30(-92.88019930008089 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark30(-92.8963356565774 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark30(-92.90348747077215 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark30(-92.91681217870962 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark30(-92.92342507550582 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark30(-92.95435460357938 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark30(-9.296864208380313 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark30(-92.98150831641398 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark30(-93.03176879693822 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark30(-93.0684735307766 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark30(-93.07492106414415 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark30(-93.10114566384757 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark30(-93.12935136124536 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark30(-93.14434133798999 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark30(-93.14693864254635 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark30(-93.17942812867672 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark30(-93.20802249951498 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark30(-93.22104833339984 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark30(-93.22492247921845 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark30(-93.23234562773901 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark30(-93.2594863597325 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark30(-93.268299464098 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark30(-93.29189058367977 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark30(-93.32186052445076 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark30(-9.341456119327233 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark30(-93.4169182392911 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark30(-93.42904157283279 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark30(-93.44846409536194 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark30(-93.45159665037181 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark30(-93.48041712501838 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark30(-93.51890474448992 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark30(-93.59142040190851 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark30(-93.59746227436725 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark30(-93.60228261469032 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark30(-93.63073364294571 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark30(-93.67106248195422 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark30(-93.67893997763271 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark30(-93.6990854100048 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark30(-93.70739477030645 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark30(-93.75913344921096 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark30(-93.79011235676775 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark30(-93.82106941150849 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark30(-93.82554852804708 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark30(-93.99058114176755 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark30(-93.9957374517149 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark30(-94.00287577916883 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark30(-94.02351699286113 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark30(-94.03477632244905 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark30(-94.06595119840348 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark30(-94.10234847711214 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark30(-94.13065172711035 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark30(-94.15866421204538 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark30(-94.18662614990083 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark30(-94.18917442195405 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark30(-94.19953685012091 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark30(-9.42192772576172 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark30(-94.22503725913333 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark30(-94.22923932005078 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark30(-9.429785776445414 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark30(-94.32819134654045 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark30(-94.34192322231016 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark30(-94.36971769085855 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark30(-94.4185136334236 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark30(-94.42201495697063 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark30(-94.43679802921423 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark30(-94.45474790577981 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark30(-94.53258838416814 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark30(-9.454422181952978 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark30(-94.58728979265929 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark30(-94.65072915477425 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark30(-94.6650069991281 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark30(-94.68423487459722 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark30(-94.68430125076132 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark30(-9.468984204451147 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark30(-94.70522023159174 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark30(-94.73895431184893 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark30(-94.77230740594196 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark30(-94.79688872679233 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark30(-94.80307439992346 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark30(-94.8034356769956 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark30(-94.84684449054932 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark30(-94.87542616183977 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark30(-94.89055753898066 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark30(-94.89353295692844 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark30(-94.92164242127816 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark30(-94.93403835145828 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark30(-94.93607551006082 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark30(-94.99170088291355 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark30(-95.00139409709483 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark30(-95.01623429449748 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark30(-95.04296218245503 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark30(-95.04583764476233 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark30(-95.12924369505609 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark30(-95.150549957205 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark30(-95.16269552762884 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark30(-95.20773562356916 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark30(-95.22545495226579 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark30(-95.24902298361675 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark30(-95.27450094914927 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark30(-95.33433823836015 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark30(-9.536078672321139 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark30(-95.38147825511156 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark30(-95.39130935574171 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark30(-95.43755034338311 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark30(-95.44317530707576 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark30(-95.45164826015444 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark30(-95.46180831648566 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark30(-95.50706123036205 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark30(-95.51054339021712 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark30(-9.55455337232587 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark30(-95.55118177989893 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark30(-95.55655401918506 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark30(-95.57626378656884 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark30(-95.60675765700633 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark30(-95.62951675333213 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark30(-95.64005565650571 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark30(-95.66378206675043 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark30(-95.69346511610202 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark30(-95.69964647963127 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark30(-95.71693892129211 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark30(-95.73103634607708 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark30(-95.73977349114082 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark30(-95.74754824090917 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark30(-95.75194518418535 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark30(-95.81732890899173 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark30(-95.91250531214375 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark30(-95.93670198656913 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark30(-95.9399512854331 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark30(-95.95258345716191 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark30(-95.95297748220058 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark30(-95.95432478449248 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark30(-95.99691823811125 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark30(-96.00713074916278 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark30(-96.02365849773552 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark30(-96.05005274737618 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark30(-96.0855324529113 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark30(-96.09332263603095 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark30(-96.09949246970845 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark30(-96.16416352145434 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark30(-96.24250435082813 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark30(-96.24717632191297 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark30(-96.27116013839007 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark30(-96.2932425795463 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark30(-9.637532977528522 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark30(-96.38293983737975 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark30(-96.38984853560764 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark30(-96.3911717976097 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark30(-96.41401860137879 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark30(-96.4360837254665 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark30(-96.49284533339669 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark30(-96.5046700549842 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark30(-96.51877876584282 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark30(-96.54741034557239 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark30(-9.657589744736072 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark30(-96.61452804886461 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark30(-96.63005001634907 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark30(-96.64861898160335 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark30(-96.72061110437203 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark30(-9.673493924118588 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark30(-96.7537147752344 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark30(-96.75729663169983 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark30(-96.76479280256376 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark30(-96.77183291404397 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark30(-96.78064890640456 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark30(-96.78381126705737 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark30(-96.78857050266258 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark30(-96.81909844896077 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark30(-96.8348432487714 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark30(-96.8511254518424 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark30(-96.86513572072559 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark30(-96.87437082900425 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark30(-96.87607016543207 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark30(-96.88536664508472 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark30(-96.90647111429267 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark30(-9.693943859130627 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark30(-96.94509459549492 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark30(-96.94577450324284 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark30(-96.9598947250535 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark30(-97.00297801647525 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark30(-97.03995421542939 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark30(-97.05192695993814 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark30(-97.05716392150447 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark30(-97.08759361239404 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark30(-97.10632071285517 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark30(-97.15543118919653 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark30(-97.15567922835923 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark30(-97.1767353908673 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark30(-97.19449510080902 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark30(-97.22911496430633 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark30(-97.25359767704266 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark30(-97.26411392034333 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark30(-97.27180457198214 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark30(-97.29087412902713 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark30(-97.30289025330725 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark30(-9.731049340562919 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark30(-97.31686555321211 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark30(-97.40295187708357 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark30(-97.44773999469199 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark30(-97.46235669500074 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark30(-97.4716622677653 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark30(-97.47509739640475 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark30(-97.49994430227511 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark30(-97.54583099404005 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark30(-97.55198320837013 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark30(-97.55911696566658 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark30(-97.5666744926031 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark30(-97.58054654582338 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark30(-97.58633663636884 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark30(-97.65485444955868 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark30(-97.65929164931997 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark30(-97.67636342485228 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark30(-97.71272006780569 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark30(-97.73962715851656 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark30(-97.76504898836438 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark30(-97.83011822193886 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark30(-97.84083933783192 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark30(-97.84990592154898 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark30(-97.93087473447677 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark30(-97.95565897459639 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark30(-97.999226938367 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark30(-98.04453442036677 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark30(-98.05196324248709 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark30(-98.0693289832278 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark30(-98.0703567742407 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark30(-98.07886336873881 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark30(-98.10531521169403 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark30(-98.11690480809551 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark30(-9.815273795678124 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark30(-98.15898180529929 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark30(-98.16792961404437 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark30(-98.1731200629489 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark30(-98.21393073082203 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark30(-98.22511781178827 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark30(-98.27366752499951 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark30(-98.27726032304295 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark30(-9.829098524561132 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark30(-98.29749004146866 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark30(-98.3341234562283 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark30(-98.34029376911965 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark30(-98.35518523123228 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark30(-98.38752019150488 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark30(-98.39563962711391 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark30(-98.41921503393705 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark30(-98.46735932030369 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark30(-98.47584292624161 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark30(-98.48356383047634 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark30(-98.49309059492988 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark30(-98.50590546055614 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark30(-98.52405031324002 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark30(-98.52488245209807 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark30(-98.5304905737503 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark30(-98.53770804780149 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark30(-98.57770993647365 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark30(-98.58391021766413 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark30(-98.61362744375583 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark30(-98.62443533865215 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark30(-98.65719231356663 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark30(-98.68106767546925 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark30(-98.68401023680688 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark30(-98.684147669502 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark30(-98.71855526974306 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark30(-98.77667690785307 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark30(-98.78734491924656 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark30(-98.81555807657382 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark30(-9.884155310683624 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark30(-98.87762685833674 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark30(-98.91108296954097 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark30(-98.93090743931998 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark30(-98.93380446650497 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark30(-98.97402249328667 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark30(-98.99990461697456 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark30(-99.03512477518464 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark30(-99.03763195302014 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark30(-99.04982840191023 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark30(-99.06976423004407 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark30(-99.07371666392703 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark30(-99.10755557017123 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark30(-9.914082282340388 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark30(-99.23865618356989 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark30(-99.26660082034368 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark30(-99.28977971761535 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark30(-99.29821275561103 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark30(-99.29956337131355 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark30(-99.33500750380763 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark30(-99.3442942939994 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark30(-99.35056415726405 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark30(-99.39022050955046 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark30(-99.42323843278929 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark30(-99.43132899678484 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark30(-99.47271708279952 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark30(-99.51594809969792 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark30(-99.51769178603847 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark30(-99.52805251540784 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark30(-9.954971263642193 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark30(-99.56725187913484 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark30(-99.70384679415699 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark30(-99.7079409556177 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark30(-99.72622336017002 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark30(-99.74117465028354 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark30(-9.975174857999619 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark30(-99.75455051468303 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark30(-99.79573243408137 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark30(-99.79689096749075 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark30(-99.80604452207018 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark30(-99.84967010539239 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark30(-99.94703654343402 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark30(-99.98777109982771 ) ;
  }
}
