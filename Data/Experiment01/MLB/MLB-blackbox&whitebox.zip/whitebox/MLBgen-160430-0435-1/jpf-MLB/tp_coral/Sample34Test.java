import org.junit.Test;

public class Sample34Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark34(0.6385052907659912 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark34(-10.01317472489734 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark34(-11.142654258426916 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark34(-136.08848410421484 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948923 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark34(-1.5707963267948966 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark34(-16.134143041938785 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark34(-161.56915611567294 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark34(19.021823627006015 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark34(21.438637959874725 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark34(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark34(-2714.777135720572 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark34(-2.736661001250539 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark34(-2754.1459964528403 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark34(-3.1415926536474146 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark34(3.1415926536480043 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark34(-3.141592892008375 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark34(-3.141593080940679 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark34(-3.2665926535897936 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark34(-33.96826621643645 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark34(-35.30731121543782 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark34(-3.5480156474132087 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark34(-35.90481918669121 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark34(-38.05361953205115 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark34(-3.857373833436185 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark34(-4.178057169879338 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark34(42.23305916292844 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark34(4.477242438338223 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark34(-48.38247617432068 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark34(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark34(4.955625735969704 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark34(-54.72770858745071 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark34(-569.1282702996308 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark34(-6.162975822039155E-33 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark34(63.566584936827496 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark34(-67.44574451448817 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark34(-72.42300664807131 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark34(-73.08949268203165 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark34(-7.853981633974483 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark34(-82.9370696954583 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark34(-84.82300164704085 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark34(-84.91151146115644 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark34(-85.66160273542003 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark34(-87.7848271713844 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark34(-97.39377998016248 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark34(-97.93051584059218 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark34(-98.17403082152909 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark34(-98.21854912948376 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark34(-98.7339046547453 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark34(-98.74492745934677 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark34(-9.929811441707898 ) ;
  }
}
