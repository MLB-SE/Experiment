import org.junit.Test;

public class Sample38Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark38(-0.445300952880892,-83.89735743213762 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark38(-0.689288934424539,-35.00264120806331 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark38(0,-83.37034282550802 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark38(0,-96.3476376544507 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark38(0,9.766718404323214 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,-100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark38(-100.0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark38(-1.0118E-320,-75.80160713923442 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark38(-10.874204911938834,173.84118181808535 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark38(1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark38(-116.04043488372447,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark38(-11.840663644429062,1.83E-322 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark38(-1.24E-322,0.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark38(-12.709101118500456,21.98926565690016 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark38(-1.2717765548116056E-307,-5.715659954159179 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark38(-12.783006508986935,5.2031185398247434E-259 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark38(-13.249570666070554,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark38(-1.331055591989516E-76,-2.4074124304840448E-35 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark38(-13.326252480426675,-19.41200211028216 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark38(-1.379079300836555E-308,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark38(-14.294192433390833,-55.61668980461108 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark38(-14.386184833953592,16.54585366567423 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark38(-1.5631940186722204E-13,68.5416779034972 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark38(-1.567926655900423E-306,70.46627463199546 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark38(-15.77901953562197,19.520376554397075 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark38(-1.5876231537717018,-93.47287570005658 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark38(-1.5E-322,4.9E-324 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark38(-16.66445572189093,26.03933231477589 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark38(-16.683248392604234,0.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark38(-1.6853174047349914E-8,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark38(-17.000611802343357,92.73830673863833 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark38(-1.7337257129419597E-306,-77.91767029725042 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark38(-17.438221429899656,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark38(-1.7763568394002505E-15,-93.08680411470623 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark38(-1.8622954545514073E-306,83.69589384330877 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark38(-1927.8712555993043,-1.2819826627728358E-5 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark38(-19.57906056419658,2.2250738585072014E-308 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark38(-19.879118806060188,-19.879118806060184 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark38(-2.0402583855908853E-14,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark38(-20.94846242332038,0.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark38(-2.1175823681357508E-22,92.1480507246231 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072014E-306,-100.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark38(-2.2250738585072014E-306,100.0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark38(-2.225073858507202E-306,100.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark38(-24.014961960850997,2.225073858507206E-308 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark38(-2.4254322805643085,50.839533005360295 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark38(-26.11222935768218,-26.112229357682175 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark38(-2616.7259627524513,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark38(-2628.736962790207,0.28887146760210003 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark38(-26.76464992069252,3.469446951953614E-18 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark38(-26.87288724714297,-8.0948E-320 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark38(-28.266662138355585,-56.08907867907291 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark38(-2.8789620682888445E-308,-19.509506883741153 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark38(-2.93726746163E-313,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark38(-29.454276947869033,-67.41358188503744 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark38(-3.0E-323,-2.341863996930868E-14 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark38(-31.074668591526304,-52.903800839497016 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark38(-3.165472837719932,100.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark38(-31.98456262203748,2.2250738585072014E-308 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark38(-32.4494455050762,-69.78172736221018 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark38(-34.46574459975773,-60.34874754655362 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark38(-34.78048543304833,-97.4403011810069 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-2.2250738585072014E-308 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,23.81507715652961 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-56.46310808808632 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-68.50395206188358 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-70.66309518403585 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark38(-3.552713678800501E-15,-83.38210741322014 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark38(-35.624217894237134,-13.928441353097938 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark38(-3.5E-323,0.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark38(-36.19509760411137,-73.24910561426323 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark38(37.683300972950775,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark38(-37.79083942957053,-1.8485190408855855E-273 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark38(-37.9190098532854,-9.583896984210895 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark38(-38.50637962015089,40.75894506696932 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark38(-3.8725919148493183E-121,-2.6727647100921956E-51 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark38(-38.73271690689164,39.82781808425119 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark38(-39.3850264856358,-0.5263381275622692 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark38(3.944304526105059E-31,-90.75879305092995 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark38(-3.970948293816738,-63.48182234249745 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark38(-42.559514336895646,-4.254276205733291 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark38(-42.87956545694942,-59.79720422438846 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark38(4.3368086899420177E-19,0.0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark38(-4.440892098500626E-16,52.0176167957117 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark38(-4.440892098500626E-16,54.53685963919514 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark38(-4.440892098500626E-16,70.54101985009211 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark38(-4.440892098500626E-16,9.231830189529006 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark38(-4.5569512622227484E-305,-100.0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark38(-47.28445387015856,-24.033155697065084 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark38(-47.36198863618617,48.503049556145754 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark38(-48.302375495381476,-35.17799187631256 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark38(-48.33352498356258,-97.46073716020356 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark38(-48.459115194782456,-3.3299958654878358E-257 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark38(4.930380657631324E-32,0.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark38(-49.52188536998232,24.810039227608428 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark38(-49.70639032375394,-50.02123455458758 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark38(-4.9E-324,-2.2204460492503136E-16 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark38(-4.9E-324,-7.402800437776934E-161 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark38(-5.1306710016229703E-290,-100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark38(-51.41552728813261,83.41987204989744 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark38(-51.467150811273996,-84.8409481161315 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark38(-52.48310486042993,64.52526172030895 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark38(-52.541900366061455,-48.146827952234396 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark38(-52.766310809425306,-53.48977573788027 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark38(5.543697086075767,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark38(-55.85927067389207,-55.85927067389206 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark38(56.86072650119206,-66.47992992569999 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark38(57.0790431242211,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark38(-57.42268950337306,-2.2250738585072063E-308 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark38(-57.841470880493894,-33.73064828199006 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark38(-59.68586915629448,-99.9164304410713 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark38(-61.190502394599974,-61.190502394599974 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark38(-61.848386028178524,80.1085413245417 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark38(-62.59170571825536,-54.936078820571744 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark38(-65.20227220781909,72.34947784588459 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark38(-66.77997941940302,-19.80802323126092 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark38(-67.13201572791101,-67.13201572791101 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark38(-6.714556500511051,55.114585891632686 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark38(-6.753811000430914,-107.97023741955383 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark38(-68.11995591614608,-65.01400519508624 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark38(-6.938893903907228E-18,100.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark38(-69.85864954394074,-69.85864954394073 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark38(-69.96740379728749,0.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark38(-70.43422017670267,-70.43422017670267 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark38(70.69662593344376,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark38(-70.9104385748332,-5.9697348166073 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark38(-7.105427357601002E-15,-100.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark38(-7.105427357601002E-15,-70.62077548521142 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark38(-73.30600684228712,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark38(-73.43732444196003,-81.41404745812613 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark38(-74.50675571257773,-21.34065009295547 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark38(-7.498168829125092,187.58899178085926 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark38(-75.49572325449437,43.6165766205155 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark38(-77.27464637684179,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark38(-7.76113075195686E-294,-197.1447372402305 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark38(-77.96303478126913,-1.4582244039112795E-303 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark38(-78.77300486831602,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark38(-79.12816927503067,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark38(-79.43711589744956,95.1376029839121 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark38(-79.91922355732638,57.132495545989144 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark38(-79.99500848627106,-15.60137632884333 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark38(-80.3475109973892,-9.076125586057728 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark38(-80.51716618112863,-80.51716618112863 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark38(-81.08316040594521,-37.20365384214344 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark38(81.36888032447126,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark38(-81.5272174481488,-81.52721744814883 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark38(-81.90396362774766,-98.29891257573769 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark38(-82.75760279149951,-80.56116853024827 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark38(-83.79259499942123,10.54343426949336 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark38(-86.6514730567598,-30.99181753482192 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark38(-86.70922926263586,4.930380657631324E-32 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark38(-8.74614480060086,-139.82081088153532 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark38(-87.81610613123001,87.81610613123001 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark38(-87.97084972216977,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark38(-88.12043183833545,72.14354750592139 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark38(-88.6612135224895,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark38(-8.881784197001252E-16,13.702631372236823 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark38(-8.887451890527818E-16,-2.2250738585072014E-308 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark38(-89.25354161348861,-64.38999333872526 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark38(-89.71148825611928,94.21619567082558 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark38(-89.85232823803014,-7.701274698262651 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark38(-90.49549229207186,-96.06561457303016 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark38(-90.9979937743413,96.23402686227723 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark38(-92.4659557864834,-92.46595578648343 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark38(-9.257116337622492,-43.155000320560724 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark38(-93.22195973532293,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark38(-93.373803756137,-15.304827837376948 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark38(-93.57149684504469,49.55693570041876 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark38(-95.64162556061197,47.78041719873892 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark38(-95.72929688698683,-93.59942876542975 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark38(-96.20469174636372,-28.531454795303077 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark38(-96.21616341074113,82.81550220052162 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark38(-96.43683274611988,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark38(-97.22380046324153,-97.22380046324155 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark38(-97.41605048880382,-81.99693419674716 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark38(-97.69729237120903,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark38(-98.34924372072365,-75.6669816840849 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark38(-99.61539915037181,-97.1431435845748 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark38(-99.6378748694739,-75.715174559486 ) ;
  }
}
