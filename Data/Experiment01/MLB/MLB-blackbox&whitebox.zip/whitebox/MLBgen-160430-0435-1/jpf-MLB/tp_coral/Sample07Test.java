import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(-0.0010466941848435202,-5.551115123125783E-17,0.1473224777432334,56.99110941633224 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(-0.0012034900571886583,-2.2204330803486364E-16,-0.7847964183688539,16.40830608678143 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(-0.0012771153925882942,-9.155005950212644E-7,-99.97776563034355,-36.569559461580155 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(-0.0013644751614236839,-0.0027289503228467016,-51.57718005487871,64.80978063442713 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-0.0016234237313380306,-3.552713678800501E-15,-64.82362771593613,0.78539816339745 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-0.0022421362589063465,-2.98100551231954E-15,0.7865192315269015,0.7853981633974497 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-0.0025656477238832354,-0.005131295447766434,79.61937269188512,0.7768430263935604 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark07(-0.0027772983027363534,-4.3945972273833233E-16,0.0013886491513681767,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark07(0.0029966794424573905,0.005993358914128253,-0.3168537129530392,-59.55096775480988 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark07(0.0030062525242279285,0.008238047625183598,-13.351952752691,-98.14844987168665 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark07(-0.0032338483094467296,-0.006467696618893437,80.04957953795942,39.50091335075314 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark07(-0.0033628690748965795,-0.006542618911209329,7.716673088218629,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark07(-0.0035727208400493995,-0.00714544168009879,-0.7836118029774236,-1907.1342023264224 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark07(-0.0036821410991845394,-0.007355872613101096,-82.64438655573522,0.0036779033630483303 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark07(-0.003932463475632864,-0.007864926951265698,-0.7834319316596319,-13.737957724531764 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark07(-0.003965627474060263,-0.007931254948120177,0.7873809771344784,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark07(-0.004643620146008776,-0.009287240292017284,-89.08387818812642,15.781839748906535 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark07(-0.004927041420212691,-1.1102230246251565E-16,-94.86257101317617,-0.289826967414732 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark07(-0.005203410394715815,-9.447997939560082E-14,0.7879998685948062,100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark07(-0.00623092599462205,-3.6726665529698756E-13,0.4965434408397565,-20.26828145330666 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark07(-0.007230552836367737,-2.6194003149588327E-11,-69.83842203306934,56.610364741214475 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark07(-0.007501934530743937,-2.220446049250313E-16,0.0037509672653719683,-64.1813657326037 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark07(-0.00771873599584616,-0.015437471991692318,0.7892575313953714,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark07(-0.007926053735742622,-0.01356620352730965,-48.54863800973237,-0.7786150616337935 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark07(-0.0084810876902231,-0.01696217538044618,-30.626287826313934,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark07(0.008516433498166569,0.9154112604383627,-0.7896563801465316,-119.83813665322701 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark07(-0.008900138036038868,-1.1601471624049072E-12,10.689840742902293,5.800735812024536E-13 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark07(-0.009678354841252889,-0.016934108566193887,-0.7805589859768218,0.008467054283096909 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark07(-0.00995085108336678,-0.019901702142812783,0.7903735889391317,-16.319741931861355 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark07(-0.010005372824386415,-0.020010745648772827,0.7904008498096415,53.98210949241697 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark07(0.01042127666778217,0.3037804219384478,-0.11115924426093589,-25.239219117618564 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark07(-0.011080654799897123,-1.0621559630701791E-13,0.0055403273999485615,-0.7853981633973952 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark07(0.0,1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark07(0.0,1.1102230246251565E-16,99.98368771709673,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark07(-0.01396886295232562,-0.023181747138681985,-43.135504243153775,0.6699941525102437 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark07(-0.014490196527008333,-0.016442285139927848,-0.7781530651339441,46.58484955326 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark07(-0.015190239640474168,-0.03038047928094756,-77.55769995787989,0.8005884030379217 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark07(-0.015480101898225249,-0.030960195961359984,0.0077400509491126245,33.11185363112489 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark07(-0.01605084121402316,-6.938893903907228E-18,-0.7342578208280407,3.469446951953614E-18 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark07(-0.016394513960235974,-2.220446049250313E-16,-143.6115273738328,-0.7853981633974428 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark07(-0.017397082772003566,-6.685503203744602E-7,-0.7766996220114465,3.3427516018744163E-7 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark07(-0.017572835148398025,-0.03514567029679588,-20.97182120127661,-96.80307881171883 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark07(-0.01806889999538688,-0.0026318939253810653,19.987948475478987,0.7853991900407236 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark07(-0.01836121783214412,-0.012684784243759423,0.782555588503034,-0.7790557712755686 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark07(-0.01881954096214019,-0.016383509273384434,-45.88033453732769,79.74537955617755 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark07(-0.01966905142154987,-2.7755575615628914E-17,-0.4031426693218388,-53.27713424874706 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark07(-0.020069023552623917,-0.011340229744429086,-8.60781243980783,70.83060495661054 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark07(-0.020947434142961588,-0.04181741891906745,-11.768960086069349,30.661479315539992 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark07(-0.021506706727075085,-8.888776455735883E-5,80.9067634812317,-0.7853537195151696 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark07(-0.022605289131229153,-1.3234889800800296E-23,-0.33440478739989377,6.617444900400147E-24 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark07(-0.023636143443252083,-1.3877787807814457E-17,-36.32430917829935,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark07(-0.02487684939345581,-2.7755575615628914E-17,-0.018005718361735118,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark07(-0.025247738360585997,-0.05049543242839115,-0.7727742942171553,97.12736417048255 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark07(0.025385247546201764,0.05077054279570964,-0.16365139313567895,-85.08842972088979 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark07(-0.026651665980863184,-5.6066262743570405E-15,-78.39563426268059,85.33763783331867 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark07(-0.027732312375805646,-1.9827741463987945E-13,-0.7351813806747917,14.789933499336481 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark07(-0.027849377261250585,-1.1102230246251565E-16,-32.171641446633004,120.4615750804924 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark07(-0.0278777406606321,0.3823287942425906,0.01393887033031605,-22.68201785801736 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark07(-0.029187913659262443,-0.024647840274362693,-0.7708042065678171,-0.773074243260267 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark07(-0.030185895117763373,-0.06037179023552632,0.015092947558881686,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark07(-0.030243901413081038,-1.039640184306544E-5,0.015121950706540486,165.7413168807772 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark07(-0.030914937287589872,-0.06182987457517954,21.12748136468147,87.98411069177828 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark07(-0.03162129944961675,-0.018145023279478346,-87.17254656305363,-56.44512669230029 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark07(-0.0320493861150688,-8.216828599407302E-4,0.01602469305753429,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark07(-0.03290734186827326,-1.31968068832906E-12,96.62411876675735,-28.262670901685496 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark07(0.033301087919748576,-0.05364280212192185,3.9104117388221065,-100.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark07(-0.03379597654279384,-0.03555514164178125,64.65556021405622,2007.2248984209264 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark07(-0.03381604765209367,-0.06763209530418722,0.8023061872234951,92.9465733824889 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark07(-0.03463572888880468,-2.3477039238641106E-20,-23.47226542662359,1.1738519619320553E-20 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark07(-0.035358015372938034,-0.07071603074587607,0.6639676377065805,1.1786996465569 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark07(-0.037199778957440977,-0.058533813573671094,0.8039980528761683,-0.6663880213920517 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark07(-0.03778531871126071,-0.0755706374225214,-0.13158835477514788,-2050.8636147377283 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark07(-0.03841465854484306,-0.07682284877194653,-0.7661908341250268,-14.097362156578644 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark07(0.03863136058379432,0.12721197480953836,-0.5000470329091931,-0.6999220618495269 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark07(-0.03906980418594497,-5.551115123125783E-17,-90.97012981528783,100.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark07(-0.039295027325938175,-0.05191444539704233,0.8050456770604173,25.92733067149875 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark07(0.0,4.013385382185068E-17,0.48070744621637207,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark07(-0.04018486893571288,-0.014494805220946625,-0.7572465399663066,-24.83261772934743 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark07(-0.04053976962044929,0.21648276400615182,-0.7257870826901712,0.6771567813943733 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark07(-0.04068882923778201,-0.008987296282553923,0.8057425780163393,40.42309877001961 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark07(-0.04092145249910316,-1.8399607298156138E-29,-2.7554058488983926,9.466330862652142E-30 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark07(0.04103882401085013,-0.451081948584642,-64.07804096328456,100.0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark07(-0.04401651735473607,-0.08768888387781872,14.944568124899552,-1.8063668670675126 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark07(-0.0449749796832342,-0.019498561513545273,0.02248748984161788,9.943098672486471 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark07(-0.04527975297012288,-0.05106078875313326,0.8080380398825096,3.945559263602778 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark07(-0.04666295139733649,-0.05781926573190144,36.18802953933172,34.195155391391495 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark07(-0.04755871901972697,-0.09511743803945392,-40.029395300678544,-91.7440076940157 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark07(-0.047680167328001795,-3.4601168979196093E-18,0.8092382470614492,0.7853981633974483 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark07(-0.048610682728037355,-0.002621728343983773,0.024305341364018677,0.7853941072499928 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark07(-0.049538485192258876,-0.021396622655314307,0.024769242596129438,33.45376525043 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark07(-0.049596132900021406,-1.7763568394002505E-15,-0.7606000969474376,0.7853981633974492 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark07(-0.050536229502154306,-0.10107245900430796,-6.726808291328821,36.66831242890703 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark07(-0.05125354173831648,-3.9790972839172367E-14,-99.99999999999993,45.3364508187123 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark07(-0.05149244454508597,-0.10298488909017167,35.64331813368653,0.8368906079425341 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark07(-0.0535076540197752,-0.10701530803954985,0.0267538270098876,0.8389058174172224 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark07(-0.05369270321036835,-0.10738540572341167,-14.895242176044672,0.06747117688215085 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark07(-0.05386429042362284,-0.11996593646856346,60.5353538038093,177.89791692469993 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark07(-0.05398090031726533,-1.1672206342351173E-14,100.0,-100.0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark07(-0.05416297802033058,-2.7755575615628914E-17,0.21843532635795376,37.48377500690864 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark07(-0.05418435980368255,-1.1102230246251565E-16,8.186969559867695,19.69467906376747 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark07(-0.054483026303940196,0.04110883393907903,0.027718526337832863,109.93500328965592 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark07(-0.05499969625418061,-0.1099993925083611,-85.98050777527322,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark07(-0.05515519081911929,-0.03232262315541234,0.8129757588070079,-0.7692368518197421 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark07(-0.057157431881816045,-0.01758186737561082,68.40588576644205,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark07(-0.05985939756313252,-1.1102230246251565E-16,-0.2792707347201022,-41.72147938674105 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark07(-0.060476650468396516,-9.488587443431077E-11,0.7983547455307072,1985.299212447574 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark07(-0.06087648278634284,1.0633158905350402,-0.7549599220042769,99.99930696960585 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark07(-0.0619480749684148,-7.787183515174526E-17,0.8163722008816556,-79.48329950583953 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark07(-0.06283943696770566,-1.941604588241401E-16,0.816817881881301,0.7853981633974484 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark07(-0.06469921408899282,-4.8072310576697414E-8,80.45199866219329,2.4036155288342798E-8 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark07(-0.06587097700512956,-0.1317419540102586,0.8183336519000131,-0.6794083991121718 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark07(-0.06641154443259113,-0.10785997237453948,-99.50598085244295,0.05392998618726974 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark07(-0.06736554519844078,-2.7755575615628914E-17,0.8190809359966686,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark07(-0.06793702057482552,-0.0026331285909056267,-21.129338095342376,0.7853981633974483 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark07(-0.06951670082965267,-3.552713678800501E-15,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark07(-0.06970487453087988,-0.13940021685503745,49.51469180779196,-33.0063676736421 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark07(-0.07230880503399739,-0.02951338804500095,0.5023563109000898,82.80586691568539 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark07(-0.07239830770822686,-0.022085634832813825,0.8215973172515617,85.61812770741884 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark07(-0.07405648086241932,-3.469446951953614E-18,100.0,-89.59743021990406 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark07(-0.0744739525264162,-0.1489297014360203,87.21643293735195,100.0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark07(-0.07538052428005572,-0.0048810571417410775,-27.45018450348338,-83.5633422109315 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark07(-0.07541461699760926,-2.55351295663786E-15,0.8231054718962529,42.33651532033958 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark07(-0.07574460737786648,-0.15148921475573185,-55.27385528165698,12.230930317440276 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark07(-0.07625784660807435,-8.080882184489651E-14,0.8235270867014854,4.04121180963557E-14 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark07(-0.07648398844136538,-0.14669707164675777,-64.15808069286824,0.07334853582337875 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark07(-0.07896965167147814,-0.06340539198671308,0.8248829892331875,1862.3688126262855 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark07(0.07906168497869537,0.15812336995739748,0.7458673209081006,-0.07906168497869874 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark07(-0.07913012119357349,-2.1684043449710089E-19,0.039565060596786744,-85.58159758819518 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark07(-0.07917448046742138,-3.3306690738754696E-16,0.19412812375577893,39.88424626102182 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark07(-0.07984801083705212,-0.1596960216741042,-0.7454741579789222,-50.123978986297125 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark07(-0.08005317420693972,-1.3724482232799207E-4,0.040026587103469874,57.100971140884695 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark07(-0.08095947153149993,-0.16191894305814736,0.8258778991631982,-34.67328692455747 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark07(-0.08550523332547133,-1.351808683839107E-10,-27.91203589152063,73.82581439762954 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark07(-0.08590316464329412,-0.10010458715911094,0.8283497457190954,-0.48294540516782214 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark07(-0.08779966848946474,-0.02783993515051894,1.2527546929388396,0.7993181309727078 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark07(-0.0903664547117971,-8.881784197001252E-16,0.6382512013106739,-0.7853981633974478 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark07(-0.09138672917635848,-1.7763568394002505E-15,-90.50558621258583,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark07(-0.09340390387053721,-0.1868078077410744,55.80997155297389,-0.6097785932211074 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark07(-0.09416151757411004,-4.3368086899420177E-19,75.21316795671106,0.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark07(-0.09421195462887375,-0.0037261577675962035,0.8325041407118852,0.10679955874527991 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark07(-0.09507317048045527,-8.881784197001252E-16,-69.83061102431465,100.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark07(-0.09621591686256976,-0.19243183372513784,-0.7372902049661634,-0.6891822465348791 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark07(-0.09660256970576098,-0.19320513941152184,0.5898958176776434,0.4104880253563859 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark07(-0.09923375069879634,-0.004076383086230827,-98.05791061771887,-3.5950538846382045 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark07(-0.10160798941143856,-5.551115123125783E-17,-76.75852438730746,0.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark07(-0.10224333916037923,-0.20448667832075842,-6.657284814431225,-28.95176200677955 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark07(-0.102345055463554,-0.011137725500946924,0.8356885523806303,0.005568862750473469 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark07(-0.10295296633673819,-2.9609839914669676E-16,0.8368746465658177,0.7853981633974484 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark07(-0.10307460588090266,-0.03807633442570403,0.05153730294045133,-0.7670654307521558 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark07(-0.10406650270885631,-1.3877787807814457E-15,-28.973586151166828,0.7853981633974487 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark07(-0.10466168233659291,-0.0921283259334853,-48.461271931156986,-0.7393340004307056 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark07(-0.1046640173888091,-0.04933020816218155,100.0,-59.599885692453995 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark07(-0.10588073409025348,-0.21176146818050692,46.39142417128053,40.948517097202306 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark07(-0.10672053746365595,-0.04714981888245114,0.8387584321292763,-28.85798028502299 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark07(-0.10716775798588007,-0.20997294216768791,-23.710705837577862,-34.711778431441616 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark07(0.10863913323889118,0.5862731988848519,-0.11212714877611585,-1.0785347628398745 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark07(-0.110999741656123,-0.22173007679782647,-8.949477160337558,0.11086503775907852 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark07(-0.11151137161744518,-1.716269730167611E-14,0.5646784361091515,65.20503620729733 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark07(-0.11154973228266869,-0.06824384703198724,0.7701399488726731,-0.7512762398814546 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark07(-0.11160631001825072,-9.318707043649486E-15,0.8412013184065736,36.31209303633092 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark07(-0.11246408646468423,-0.2067459632322485,-97.43033985801922,0.8887711450135726 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark07(-0.11250318062564736,-0.21852228542433444,-0.7291465730846246,-7.326740219684252 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark07(-0.11259699291335629,-1.0408340855860843E-16,-0.7290996669407699,5.204170427930421E-17 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark07(-0.11324510531758541,-0.16852826653176578,0.7270138543064295,-23.66957281956566 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark07(-0.1157557727416254,-0.23151154548325073,0.0578778863708127,0.9011539361390737 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark07(-0.11603196580036154,-1.1073636006771007E-16,0.8434141462976283,0.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark07(-0.11676782937347906,-0.23286748483444378,0.8437820780841876,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark07(-0.11731523100582375,-0.23463046201164459,58.11652046404107,0.11731523100582229 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark07(-0.11732986748817828,-0.19557004000368203,-3.583861956280826,-16.78823990896844 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark07(-0.11780595708620624,-6.953812553647333E-19,0.05890297854310312,-0.785063320567332 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark07(-0.11834470883788839,-0.2366894176757767,-62.94627520375258,100.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark07(-0.11879827315859615,-2.1649348980190553E-15,-50.60634620759017,0.7853981633974494 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark07(-0.11889416233606034,-2.465190328815662E-32,95.13180184059401,0.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark07(-0.12006835489074816,-1.856582768962322E-8,-36.916001502880434,-0.7853981139290406 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark07(0.12260828567921601,0.2858541475310889,-10.656110582717588,94.8801879096708 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark07(-0.12443109911658796,0.9522564073348856,-0.7231826138391543,-118.53252866145618 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark07(-0.1269076212340876,-0.2538152424681751,-83.54674433189685,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark07(-0.12776719473641981,-0.2555343894728396,0.0653328794781714,38.50628171532514 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark07(-0.12889033505954706,-0.257780669976557,-30.566079665325795,-0.6565078284091697 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark07(-0.13029043249545502,-0.004712993523040129,-0.7202529471497208,0.7877546601589683 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark07(-0.1307479964977132,-0.19226747880281564,0.8507721616463049,16.02110406262006 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark07(-0.13183957436973748,-1.3481774281116352E-14,0.06591978718486846,-1941.5073874215616 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark07(-0.1320547271636484,-5.551115123125783E-17,0.06602736358182422,0.7853981633974483 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark07(-0.132314041264229,-0.2646280825284572,-0.7192411427653338,-99.35021178860252 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark07(-0.13344155543756775,-8.515939474182246E-19,0.06672077771878387,-38.49101405529723 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark07(-0.13347293363753293,-0.19108562713537774,58.18836660709823,0.09554281356768887 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark07(-0.1341127406911766,-0.26822548138235314,-0.1334905537109159,-89.01772592234565 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark07(0.13513966528431975,0.5088919536599528,-0.06756983264215999,-100.0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark07(-0.13527044288921708,-0.2705408857784306,-0.7177629419528397,-30.97758556297103 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark07(0.13564816034628802,0.3648601846563069,-17.669819020273565,-48.87711613387529 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark07(-0.13708414264892338,-0.23254016275551717,-0.7168560920729866,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark07(-0.13815251907310255,-4.440892098500626E-16,-0.716321903860897,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark07(-0.13834767768417194,-2.2204497852243838E-16,-0.6139811933493555,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark07(-0.14075535751793442,-0.039940272888085965,-26.66597097412884,-28.745986348123605 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark07(-0.14142975126543547,-0.27377307218271457,-0.7146832877647306,-31.789458030330916 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark07(-0.14411501458781995,-0.2506539964301181,-6.979680186755184,61.6784908595115 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark07(-0.14418921802811646,-0.1837222904965478,36.56854818550147,-76.17564195919704 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark07(-0.14494788397815683,-0.2898957679563135,-84.83109430570018,39.629658416610496 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark07(-0.14532532762789652,-0.2906506552557929,67.11364086280739,0.14532532762789652 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark07(-0.1455491846066393,-0.2910983692132785,100.0,-40.90156191783957 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark07(-0.14650028117988967,-0.08515934664770727,-43.13541577051033,0.8279778367213019 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark07(-0.14670935295818657,-0.003571870387828234,-0.712043486918355,-90.91090279953917 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark07(0.14855732867590338,-3.5321745528449355E-12,-0.321260929557463,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark07(-0.1490713448579708,-0.1927096866535114,0.7197712037607293,0.881753006724204 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark07(-0.15141472960191127,-0.23109770510805316,-7.969040524465839,-38.378047310323254 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark07(-0.15232452836013444,-0.27903058108737105,-83.95010006668448,0.13951526470791775 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark07(-0.15240742758947223,-0.2910279915488986,0.8616018771921844,0.9309121591718975 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark07(-0.15355014210917567,-0.0013878785832804055,-0.4044764106169729,-72.01808724052147 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark07(-0.15371977650061508,-0.30000895652452336,-0.7085382751471396,38.26475854134003 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark07(-0.1557617794839864,-0.31152355896797274,-42.36252915265997,-97.49154670500148 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark07(-0.15627037275905042,-0.3125407455181008,0.8635333497769735,226.15364865665913 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark07(-0.15639331275020485,-0.27841920215784743,-0.7072015070223459,100.0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark07(-0.15735172528209718,-1.4210854715202004E-14,13.553445914018731,9.74758005152134 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark07(-0.1579305970110991,-0.2992181915273436,-0.7064328648918987,0.1496090957894158 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark07(-0.15882907207942765,-0.04341030268957601,93.59905132376178,0.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark07(0.15924455688092273,0.3197636711136095,30.396752464612305,0.6255163278406435 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark07(-0.1602411983201562,-0.32048239664031236,73.14911403720716,46.48202217546735 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark07(-0.16254349416663116,-1.3877787807814457E-17,64.73566304618521,-14.873100912516975 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark07(-0.16423408966018674,-0.23775289244132428,52.176785243956395,0.9042746096181105 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark07(0.16440309629644362,0.32933558275823815,0.6674614759702986,-0.1646677913791174 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark07(-0.16466853625799568,-1.29431191696446E-16,17.45608508423617,-36.1537458404969 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark07(-0.16491204431790418,-0.14130080222851696,-140.47616717954895,54.9530125034255 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark07(-0.16523501366854776,-0.030513177100474374,100.0,-75.52909749998358 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark07(-0.1660779923947139,-0.332155984789426,-27.038333012975663,-48.54765124253652 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark07(-0.16724111310953324,-4.594067851997961E-13,-58.87758931252311,0.785398163397678 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark07(-0.16756825706342315,-0.3351365141268456,-0.7016140348657367,-100.0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark07(-0.16812530820759797,-0.3362506164151959,-16.636695888359956,15.075197894926314 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark07(-0.16931167072858377,-0.33862334145716705,-69.62899279188034,-0.3808474979224891 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark07(-0.1697546125920095,-0.2951875578650724,0.847348228946002,37.466454499920275 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark07(-0.16983911395382978,-0.001411324293452143,-100.0,75.38824313702739 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark07(-0.16990725135144213,-0.11931987531330712,80.7862054276568,5.923455589899632 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark07(-0.1735457532756144,-0.05022643741461547,0.08677287663780714,0.025113218707307736 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark07(-0.17581120759733063,-0.002137882994537965,-0.697492559598783,0.7864671048947173 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark07(-0.17685604391517526,1.4162778502674647E-14,-0.6969701414398607,-0.7853981633974554 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark07(-0.1768594652983847,-0.35371893059676923,2286.374379120232,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark07(-0.17772696174791733,-0.3554539234958345,0.874261644271407,-0.34269829463711216 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark07(-0.17796962212207568,-0.3559392442441512,0.08898481106103784,13.939750173072044 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark07(-0.17814906872633415,-0.35030162383360164,-0.6963236290342812,24.31395378847681 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark07(-0.17915373421853786,-1.7763568394002505E-15,-0.6550864089410489,21.860101087828852 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark07(-0.1793861739802011,-0.0034082604410167645,-68.78003756314159,0.0017041302205083825 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark07(-0.18046505566235055,-0.3609301113246907,-0.695165635566273,2009.1779499553743 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark07(-0.1826373418613354,-0.3652746837226707,100.0,-30.682502625830242 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark07(-0.1828210443161798,1.0230814207309216,18.01609787067985,-28.00028967790337 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark07(-0.1830675591736156,-0.3661291114031372,0.876931942984256,0.18306455570156865 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark07(-0.1830927713244204,-0.011175645776000664,-100.0,1776.3042582960672 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark07(-0.18341323628098424,-0.36682591712187934,-46.246773177614,4.84626021780754 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark07(-0.18438418519610877,-0.0058008193580816325,0.5030820703562711,0.7882985730764891 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark07(-0.18470104352635186,-5.551115123125783E-17,0.09235052176317593,116.24475902550833 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark07(-0.18511792049657633,0.2664549383707873,0.8779571236457364,16.44181054547643 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark07(-0.1852057191905385,-0.3704105175120295,0.8780010229927175,38.374377888134845 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark07(0.1854163999274772,1.5124858685964475,-0.8781063633611869,-153.4957428430921 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark07(-0.18603807710518794,-0.3488797892327992,-0.6923791248448543,-62.573630832288664 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark07(-0.18668929911973445,-9.804073050663926E-12,-0.6920535138375807,42.59660702896713 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark07(-0.18888634692217815,-0.21277985036708996,-49.385143995759755,68.4350258956646 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark07(-0.18899760440866387,-0.2006545353512694,0.8798969656017802,-0.6850708957218136 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark07(-0.18936056640102056,-0.37872110758203636,-77.65972702020754,63.03915819605294 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark07(-0.1905031514260326,1.0944098701209264,-35.21021412606307,0.22103838961230746 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark07(-0.19130690167044406,-0.3826138033408877,-45.48117954486309,37.31466322420015 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark07(-0.1926475613078939,-0.2322321182494202,-25.74527456427115,-4.159052527889167 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark07(-0.1927970479920275,-0.3218441742872779,0.09639852399601374,-6.53096995848605 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark07(-0.1948375562196183,-0.38967511243923647,-0.6879793852876391,-94.34660554714114 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark07(-0.19586526232027093,-0.3917305246405413,-57.105532947416535,0.19586526232027066 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark07(-0.19626098390003377,-0.3841046827840105,-0.6872676714474314,22.985066314332595 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark07(-0.19668327453153842,-0.3896268289195326,-100.0,-0.590584748937682 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark07(-0.19694421168080994,-0.05218510319102815,100.0,-0.7501114168084644 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark07(-0.197677707933544,-4.643878578013123E-16,0.8842370173642202,76.38265947979318 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark07(-0.1978677840181291,-0.3957355680362581,59.76787664977865,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark07(-0.19853896600289467,-0.394645609727646,-0.686128680396001,-77.71187915059663 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark07(-0.19854361379149998,-4.0671170124562724E-14,0.8846699702931983,2.0344836926255994E-14 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark07(-0.20032094078217733,-0.4006418815643544,-49.324732088290496,-80.67477716230749 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark07(-0.2040842402301101,-0.16107521479354725,0.8874402835125031,0.8659357707942219 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark07(-0.2043445136463305,0.04833305602054231,-0.595253082050777,43.95797420183964 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark07(-0.2054558530978169,-0.3876032907391195,0.8881260899463568,0.9791998087670081 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark07(-0.2060036276042233,-0.41200725520844644,-27.385928264198487,-91.63601813833876 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark07(-0.20728654996711704,1.154493107384241,0.4427045549440156,-0.7046412460120759 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark07(-0.20733809936419156,-1.615448204416459E-8,-81.83908190554578,13.714561828500143 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark07(-0.21013224033227296,-0.4202644806645455,0.8904642835635848,45.920115394052026 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark07(-0.21056855988619,-0.19275339343711112,-100.0,-27.106266618550624 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark07(-0.2111735020612756,-0.3017530448246387,-0.0656511144668226,2.158168531875824 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark07(-0.21193100145997334,-0.4238620029199452,0.20070171865410558,31.91531374716838 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark07(-0.21194910699290403,-0.34749727830876526,-115.16577935674844,-75.35998233157517 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark07(0.21336938362510693,0.4267387672502147,0.6787134715848993,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark07(-0.21404719535497052,-0.06388619440771569,-35.97200792594128,26.73644650963794 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark07(-0.2146982011787233,-0.42939640235742627,0.10734910058936165,-53.822465579978555 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark07(-0.2147445653931448,-0.39397243391987025,-31.355126310077306,29.52009639121296 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark07(-0.21530202917379804,-0.07291178280140831,0.8541404296539932,60.999588096057 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark07(-0.2157914260047119,-0.02069700127309093,0.8932938763998042,0.3059918254096814 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark07(-0.21606214324772768,-0.14659064688250742,-29.604392997004084,-0.7121028399561947 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark07(-0.2160773454142618,-0.033391342227586884,0.8934368361045791,-0.7687024922836548 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark07(-0.21644223441717703,-5.551115123125783E-17,42.54846456570801,66.60871893137204 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark07(-0.21664584315555047,-0.3033850735153172,89.07343197319011,37.209578403086425 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark07(-0.21691680969963345,-0.014147518471421604,-0.6769397585476318,0.792471922633159 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark07(-0.21710175244860785,-0.4284709994673586,-99.16517655101364,-0.5711626636637689 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark07(-0.2171681385982788,-0.1370892363407924,30.173259451438526,100.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark07(-0.2177322002342108,-0.43546440046842144,-102.76525817993145,-153.72023934466705 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark07(-0.22061607110938197,0.06829856473516284,0.8957061989521393,-11.029722609553325 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark07(-0.2223227883341053,-0.44464557666821053,-0.20771780469949275,-16.453307641924358 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark07(-0.22249197509170182,-0.44498395018340325,0.11124598754585091,100.0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark07(-0.22274437472283282,-0.44548874944566275,0.11137218736141641,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark07(-0.22392716613932695,-0.4478543322786534,-0.046168312184335786,0.2239515743720129 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark07(-0.22486632845676047,-0.44973265691352077,71.37314711836314,-92.01539916446333 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark07(-0.22922299782507846,-1.4057770988235715E-12,0.11461149891253923,-25.762020044128498 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark07(-0.2300211346442458,-0.06026665420246374,100.0,-1336.00898188213 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark07(-0.23010273393120298,-0.10211535176655787,0.9004417579808399,-118.66803141592395 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark07(-0.23035745894430332,-0.010038147237641345,-0.6702194339252965,0.790417237016269 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark07(-0.23159846353260782,-0.46319692706521554,-0.15689308073552688,-0.5537996998648406 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark07(-0.232628441514001,-0.46525688302653534,-20.824695464472782,-63.384622793680045 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark07(-0.23324493662793722,-0.4664898732558743,55.06619215387967,0.23324493662793716 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark07(-0.23342057379632397,-0.46684114759264717,100.0,0.23342057379632308 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark07(0.23351814908089824,0.4670383904297921,-0.2547289933757422,126.41779613539364 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark07(-0.23561310822792336,-0.4712262164558461,-0.6675916092834866,0.785398163397449 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark07(-0.23696892917823237,-0.18140306455705435,-0.6669136988083321,17.734230562269268 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark07(-0.23744293464706256,-0.005172494562497874,-109.71516288299486,0.7879844106786972 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark07(-0.23810241612949667,-0.4762048322589876,-22.371359987919543,-26.882189035746322 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark07(-0.23900542280322123,-0.47801084560644075,0.19161219278598507,88.53602060582203 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark07(-0.23977399356193113,-0.47933522530180966,0.11988699678096557,0.016844428414440893 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark07(-0.240123061535211,-0.07847293762892199,0.1200615307676055,0.8246346322119092 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark07(-0.24045667897316272,-1.727914889823554E-12,-44.6479579326527,-0.7853981633965843 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark07(0.24228864736814984,0.48631444624841946,-100.0,-80.94817091608448 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark07(-0.24230432953534448,-0.34153035849435265,-116.45180652396616,-90.1488136065441 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark07(-0.24292028364147,-0.4858405672829291,0.9068583052181832,10.397095843082452 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark07(-0.24337024443200714,-2.967364920549937E-67,-0.6637130411814447,0.0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark07(-0.24557649558067066,-0.10799441936858757,-3.2466844251489437,-14.869882815186656 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark07(-0.2455778639756032,-0.49115491129448646,-153.0020631347736,0.24557745564724343 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark07(-0.24583170733075654,0.0,0,0 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark07(-0.24878331580808766,-0.45956920759801867,0.9097898213014921,-47.76103645055251 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark07(-0.24985291861082715,-0.44257471769961354,0.12492645930541357,-14.34044753234667 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark07(-0.2509917239383177,-1.1102230246251565E-16,-100.0,-66.43336303939529 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark07(-0.2519153439820216,-0.4831486101823863,0.9113558353884591,-57.15844564445211 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark07(-0.25415048343182256,-0.508300966863645,0.9124734051133597,0.256891054321912 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark07(-0.2547595324968077,-0.5095190649936152,0.06179536000667596,2117.6642290016275 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark07(-0.2576684455580389,-0.5153368911160775,-0.6565639406184288,-70.59781622539482 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark07(-0.2576911304347576,-1.7763568394002505E-15,-0.6565525981800695,-22.549743529020034 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark07(-0.25963336658138186,-0.5189117803150414,-27.322403930886843,107.09186023981428 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark07(-0.25967229651925794,-0.5193445930385155,0.5413138689285494,-73.57132544522757 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark07(-0.25987423460648174,-0.4957457784503242,0.9149813644680679,38.6228756680305 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark07(-0.25992838537119534,-0.5198567707423227,-100.0,-30.67597837225741 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark07(-0.26045448809583593,-0.5209089761916715,-35.202428142144655,-41.39726738465346 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark07(-0.260498620798179,-0.5209972415963579,-37.60776962969774,-31.598918690442304 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark07(-0.26070338283505107,-0.48379829526783247,-0.6550464719799227,0.24189914763391623 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark07(-0.26081509212671783,-0.1689223314048146,-18.56729384464029,0.8698593290998556 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark07(-0.26083064483193874,-0.17935740520369528,0.13089969389908343,0.08967870260184763 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark07(-0.26108903871011274,-0.4797134619726463,-100.0,2.2435274568704826 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark07(-0.2611683730404539,-0.5223367460809076,52.75225156171783,-50.00415597109502 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark07(-0.2613782227612918,-0.5227564043849443,15.553936956522092,-98.16583710090954 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark07(-0.2614479182131165,-0.5101043133164075,0.13072395910655826,0.2550518297909133 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617576839525135,-0.5234854266022461,-39.43663856398622,1.0471408766985713 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617712089779087,-0.5235319588030688,-1.84132966985662,0.26179938779911893 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617973758802812,-0.5235947517605622,-44.44031245444931,31.171862750343713 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617990116625556,-0.4598490611618148,0.9127077697145785,-18.521584095336504 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179933377007764,-0.4274001734958165,-66.20494616560906,0.2137000867479082 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993875820682,-0.41330940803620686,-7.701685898102553,0.9933677877349628 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877971969,-0.5235987755943854,0.4873819463882856,76.4961926935872 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779906564,-0.5235987755981157,-0.6544984694979155,-199.00525734414737 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877990843,-0.09014265935030903,100.0,-100.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991438,-0.5235914492180243,-0.6544984694978764,-70.46853273787198 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991447,-0.5235987755982859,58.8137767471637,-25.266461297341365 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914536,-0.5235987755982906,0.13089969389957268,14.069507116633059 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991469,-0.5235987755982937,0.5860141822587611,0.2617996544936818 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.28886983724304616,-24.784736636199376,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.481011032663241,68.16068443891832,0.24050551633162048 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5030493323890054,11.136056317981073,-97.64554357868253 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914735,-0.5235987755982935,-55.441637863879315,78.8667074893452 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914746,-0.5235987755982947,0.5235987755983,-100.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914824,-0.5235987755982955,-17.5775287491465,38.815604700944306 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991488,-0.5235987755982975,-0.15881264389490157,-0.5235987755922474 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.43808037148326895,-0.6544984694978737,-44.21284388715167 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5219352150354337,-40.60456038666777,98.2917969381214 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982947,-100.0,-4.03777090168177 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982953,-20.373065536357988,-35.50018398759701 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-0.5235987755982979,-0.6544984694978737,0.7391628879322695 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914913,-1.1102230246251565E-16,-12.253610636049952,65.60489853547817 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914924,-0.5235987755982984,-100.0,-39.29359213803273 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914935,-0.523598691269468,36.55948224972722,0.26179938779914935 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.4087795032549261,-7.075088675169315,0.9826341005112527 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.5235987755982987,0.13089969389957473,19.095133465225754 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.5235987755982987,0.6801657110622136,93.88684658726 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.5235987755982987,-37.771874343754654,-0.5235987755982989 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779914946,-0.5235987755982987,58.121390008856224,0.261799490372669 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982967,0.1308996938995748,1.0471975511965965 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982983,-77.50619660319185,0.07935651584801251 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982986,-100.0,100.0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982987,100.0,-100.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991496,-0.5235987755982987,-36.886446176565954,92.13658739195829 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991498,-0.5235987755982987,-0.6544984694978734,16.455832291717037 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991499,-0.5196095882215945,-41.44240733342978,14.351039682367501 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5172597171411437,-0.6544984694978733,-67.00345777633994 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915,-0.5235987754036467,0.130899693899575,59.59021913807071 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915074,-0.5235987755982967,-46.71730744057665,1.0471975511965965 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.14203286150259575,100.0,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.49278310541792136,0.1308996938995729,-8.329275664104848 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5210914284033434,100.0,-0.5248524491957767 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982912,0.13089969389957545,90.24624093426141 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982929,0.13089969389957545,-0.5235987755983018 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982947,0.9162978572970228,-60.35323009462897 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.523598775598296,0.13089969389958733,-82.36284838494427 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982983,0.9162978572970228,-44.62119578919855 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991509,-0.5235987755982986,-16.025657043299546,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915096,-0.18230991595685597,-0.611419434785337,80.86426413088883 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617993877991527,-0.523598775598299,0.9162978572970246,1.0471975511965979 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915435,-0.5235985546484545,68.0532831568905,-0.523598886073221 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915446,-0.5235987755982947,-100.0,68.82931557797326 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779915624,-0.10938122220882524,-3.411050111944347,91.24612203887128 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark07(-0.261799387799158,-0.2808831234935868,0.37835404941760964,-100.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779917933,-0.5235987755982983,0.9162978572970379,0.26179938779914913 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779920187,-0.5235987755693842,0.13089969389960093,1.0471975511821403 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938779944845,-0.1343410533354769,-45.38528708136662,40.38673549748502 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938780448786,-0.18160914325440558,63.83558978659211,58.60791828745217 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938782484924,-0.5213417147312948,-85.20231215997252,22.343311797546136 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179938811758435,-0.5235987755926843,0.9162978574562405,22.681648736883034 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark07(-0.26179945262579424,-0.48882338610510556,0.9162978897103453,9.669189653193378 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark07(-0.2617994899574978,-0.5235987755982983,-99.61626755495348,1.0471975511965974 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark07(-0.2622543846840049,-0.5035573618016129,-49.42273944903284,0.25177868090080646 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark07(-0.2629730049919807,-0.5235987755982419,-27.32907222976597,100.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark07(-0.26371465612061934,-0.5235987755982983,-0.6535408353371386,-83.7744891728304 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark07(-0.2648806483904178,-0.5235987755982965,-100.0,-6.489453528905379 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark07(-0.2651428312046681,-0.5235987755982947,0.6389146720075529,-100.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark07(-0.26533599302535893,-0.5235837210446984,0.13266799651267946,-100.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark07(-0.26577163008546073,-0.5235987755982987,80.44093994522018,0.26179938779914935 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark07(-0.26580348111775187,-2.2204465154501845E-16,0.9182999039563242,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark07(0.2661075278753836,2.0933972561390837,-99.97465879370255,71.98602225238463 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark07(-0.2669181703862407,-0.5235987755982394,0.9188572485905686,-51.89145819071837 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark07(-0.2671365047106363,-0.5235987755982965,0.13356825235531816,30.562413704129625 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark07(-0.267303272690965,-0.3231968963393257,15.376142336924325,-1904.9065116020663 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark07(-0.2676389906348344,-0.5235987755982983,-91.67068761345688,0.26179938779914913 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark07(-0.267994121867108,-0.09175929885067914,-100.0,-77.52978187581438 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark07(-0.2684714191511994,-0.3619851965724793,0.1342357095755997,-0.6044055651112087 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark07(-0.26943999508724126,-0.5388493850225277,0.9201181609410689,0.14611505480770137 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark07(-0.2705324476693539,-8.881784197001252E-16,0.9206643872321252,66.41569202011596 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark07(-0.2706248473892645,-0.5235987755982983,-50.578416375308294,-65.10447060007104 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark07(-0.2707166126148997,-0.49433567608666157,-0.6500398570899985,-94.98499663977528 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark07(-0.27079537352816463,-0.5235987755982983,0.13539768676408226,77.07606990088676 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark07(-0.27086106310510966,-0.5235987755982983,0.9208286949500031,-33.94859161567033 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark07(-0.2715008839283721,-0.2580202159372369,0.9211486053616345,-1858.4929925100878 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark07(-0.27159795963373456,-0.5235986705057274,-0.6429655947506563,0.4262399727177329 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark07(-0.27260784330096577,-0.5235987755982987,-0.6490942417469654,-94.53759244078888 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark07(-0.2754180368156045,-0.13443987433885546,-66.0833854651759,-38.17447071278248 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark07(-0.2758094578412944,-0.5235987755982947,0.1379047289206472,-16.976311691529844 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark07(-0.2758445684040683,-0.5235987755982947,0.13792228420203415,-13.141856803623803 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark07(-0.27673264287715255,-4.440892098500626E-16,-0.5653008470570683,-36.33114072367904 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark07(-0.27674949304532515,-0.5193511507906362,0.625322206260189,-42.93921068634096 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark07(-0.2774493089390363,0.9844898984365823,0.9141704886113322,-38.220666914522376 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark07(-0.2780504971610102,-0.5233895552578459,0.9244234119779533,-4.085221890887225 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark07(-0.27838644556729836,-8.881784197001252E-16,-42.12870057924572,1934.8749968829516 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark07(-0.27913791244799085,-0.206189199422252,82.81371244743099,8.4246277576271 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark07(-0.27925985964978445,-2.710505431213761E-20,-94.70210130314503,0.7853981633974483 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark07(-0.27926720062152943,-2.7755575615628914E-17,-100.0,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark07(-0.27985325215150003,-6.123233995736762E-17,100.0,-0.7853981633974483 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark07(-0.2798758116189397,-0.5235987755982985,-0.6454602575879788,100.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark07(-0.2817993485710995,-0.5235987755982978,-0.6402949632176587,-27.052029316422022 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark07(-0.28235711918960027,-0.5235987755982976,0.9214283443752427,0.26179938779914874 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark07(-0.282477103846806,-5.551115123125783E-17,1.1537037933360863,-6.789212209503737 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark07(-0.2831208654814098,-2.0281503660687993E-5,0.9269585961381532,1.0140751830343997E-5 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark07(-0.2843160859278397,-6.998061019259974E-10,-0.6432401204335283,3.4990305097792884E-10 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark07(-0.2848124934778298,-0.4651747543470591,2.427266150743244,-21.910854042857856 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark07(-0.28565236046009157,-6.86223259203841E-14,0.14282618022923518,0.7853981633974826 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark07(-0.285981417994726,-1.1102230246251565E-16,-75.95924568032032,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark07(-0.2860178807077982,-0.08988784605424202,0.4666220245832272,-86.4494495226286 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark07(-0.287594329874537,-0.09354389409745749,-2.4837818952348565,0.8308551901267406 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark07(-0.28764070511605444,-0.4998646240871467,-89.9774409604883,-63.36779137562338 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark07(-0.28766562402704476,-0.4980597942539946,-59.73184607535404,-44.82635791878529 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark07(-0.28770621859440193,-0.5235987755982678,0.916297857297014,1.0471975511965823 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark07(-0.28894707960811084,-0.5235987755982983,-12.693320197975225,0.26179966567325164 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark07(-0.2890658824861234,-0.5235987755982984,-97.28963291206536,0.26179938779914913 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark07(-0.2913807957669608,-0.020226782624726602,0.14569039788348048,-2.315033113492184 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark07(-0.29173983563942657,-3.552713678800501E-15,0.5524106749571916,-100.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark07(-0.29347083893796166,-0.517553881325939,0.03573515929349036,-100.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark07(-0.29362355804295615,-0.07764650367100182,98.79494474112984,98.99899214640718 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark07(-0.2979040730148966,-0.5235987755982983,-42.898306087715156,-4.620732842493618 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark07(-0.2980750902117612,-2.7755575615628914E-17,-0.051445055243608095,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark07(-0.29814298861107275,-0.021313659516639938,-137.4007397265375,65.57006106344596 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark07(-0.29990664484734375,-1.004211870963096E-14,-48.89826375359992,-100.0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark07(-0.3005197682531758,-0.19477209778006527,-25.551494420072707,-0.5235987755983011 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark07(-0.3005414621067226,-0.4817900357269377,-21.882282815487727,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark07(-0.300942736530537,-0.2582510471936765,-19.7701421886222,-0.65627263980061 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark07(-0.3013622944105112,-0.5087530770117374,0.9360793106027039,-38.98933534729329 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark07(-0.30194414959981364,-0.28399833528963947,0.15097207479990682,-86.25180076720784 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark07(-0.30437733889625795,-0.5235987755982979,-61.49497955302519,100.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark07(-0.30720971023467997,-0.5087123860743925,43.70702686341336,-78.32484835748431 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark07(-0.3076345003952454,-0.5235987755982947,0.1538172501976227,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark07(0.3096197584110266,-2.5243548967072378E-29,-0.14035844594581848,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark07(-0.3098990174299896,-0.04894794950914569,-0.6304486546824535,0.8098721381520211 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark07(-0.3108816846794444,-0.5144344700092153,51.91731651508696,0.25706681676612453 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark07(-0.3117584612335289,-0.21740459475557317,-79.90940641064643,0.10870229737778656 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark07(-0.3126782955982321,-0.5235987755982983,0.43075913922453424,-24.938368523126663 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark07(-0.3130173035828858,-0.290722942530278,0.9419068151888912,-80.45854860084525 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark07(-0.31317310576633506,-0.5235978486067367,-0.6288117911395101,1.0471941784232497 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark07(-0.3133298115032288,-0.5235987755982965,-6.536194379568116,-0.5235987755983 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark07(-0.31628037095154304,-0.002936214187137008,100.0,-0.7839300563038798 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark07(-0.3181643277185386,-5.626984933106793E-31,0.1590821638592693,-0.7853981633974483 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark07(-0.3186181317433592,-1.1102230246251565E-16,-100.0,1908.8947455889563 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark07(-0.32063929209594827,-2.220446049250313E-16,1.0283430698344076,40.13099548948525 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark07(-0.32237237839118876,-0.5235987755982885,0.9465843525930426,-28.5036828016912 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark07(-0.3227489414767569,-0.5846419317416847,-41.161769426637086,-86.1014770054621 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark07(-0.32386341607133007,-1.1102230246251565E-16,0.01312292859644515,41.942305386544 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark07(-0.3247895684931686,-0.03996466680621792,-0.44095696775908266,99.11328071109148 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark07(-0.32569948851019515,-0.4438958216685343,-0.6225484191423507,37.526028402904615 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark07(-0.3259536366341413,-2.3288615667296408E-8,-12.723135676402833,49.1351160246656 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark07(-0.3260828953350309,-0.10260093634462919,-40.487903226961805,-0.7340976952251337 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark07(-0.3265062007473183,-6.561868813151571E-13,0.16325310037365914,3.280934406575786E-13 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark07(-0.3284658548876259,-2.7755575615628914E-17,-0.5753340207515203,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark07(-0.3288495152360833,-0.002114808654222422,-71.62618492171957,-76.17924205010473 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark07(-0.3291885817858897,-0.5020854593159054,-100.0,100.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark07(-0.3299644484741544,-0.5229707107869037,-48.97026157167221,0.26148535539345186 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark07(-0.330294437852718,-0.5235976945174459,99.92251041857726,-0.5235993161387252 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark07(-0.332727659596508,-0.5235987755983017,-23.302659335949116,1.0471975511965992 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark07(-0.33324337295177514,-0.5235987755982987,0.893941177570746,-22.326655617632156 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark07(-0.33331172477904414,-0.505434075526442,-15.984909155227795,0.2527170358415406 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark07(-0.3356640782201132,-5.915318369579571E-31,-0.3529994409833062,2.9582283945787943E-31 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark07(-0.3360609459063716,-0.5235987755982947,-81.31098005405318,-0.45474203714453754 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark07(-0.3379748340788565,-0.1461885605864242,0.16898741703942824,0.6208280542394303 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark07(-0.3388436076456074,-0.19606664405844526,-64.60210169365315,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark07(-0.34080514083435054,-0.523598775502424,-6.325774618141775,0.26179938779914913 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark07(-0.34199286596260237,-0.5235987755917635,-0.5458051928005091,-83.76892738713545 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark07(-0.34234071986127446,-0.5235987755982983,-0.4672278453867833,-0.8396618473122434 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark07(-0.3429493208409282,-1.9536086429363685E-12,0.06944610464359013,-2022.0459624568855 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark07(-0.3434981018883484,0.8665797268959352,-72.19459170074347,206.89413899137014 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark07(-0.343606088551314,-0.523598775598297,0.8753945069209401,0.26179938779914746 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark07(-0.3437327853957165,-6.938893903907228E-18,-38.113857308628845,49.68197315665945 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark07(-0.3437666728704323,-8.881784197001252E-16,0.17188333643521614,37.541063245811046 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark07(-0.34397777744214164,-0.5235987755982983,0.957387052118519,52.98095906363415 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark07(-0.3458860834016922,-0.5235987755982983,74.16411003821037,-81.98117677545068 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark07(-0.3470163946140552,-0.002582614661910841,-93.32800102659839,-17.639197750339715 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark07(-0.34743507868657897,-0.5235987755982983,131.28171744695052,-0.465043163106003 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark07(-0.34957205133155966,-1.1102230246251565E-16,-8.149510045689876,0.06406737849967978 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark07(-0.3503468290410342,-0.5235987755982947,-58.9310069706698,89.24860909028266 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark07(-0.35144506671479986,-0.45550022831577136,-0.6096756300400514,98.48364148053061 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark07(-0.3518652070295293,-0.06721669640051399,0.9613320712510197,-168.04101100499665 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark07(-0.3518853946043832,-0.5235987755982987,-0.6094554660952696,-0.5235987755982988 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark07(0.35320358972457855,2.1564467837857704,0.6087963685351591,-100.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark07(-0.3533782222188569,-0.5235985442707438,0.9620872745068767,-0.5235988912620765 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark07(-0.353453343478887,-0.179792978283496,100.0,0.08951271402568411 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark07(-0.353804709542608,-0.5235987755982947,-18.292510667955263,1704.6020990868851 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark07(-0.35502690318397256,-0.47759893519931856,-2289.7860636498704,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark07(-0.3594065039289398,-0.5235987755982978,52.63943795440102,-0.5235987755982994 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark07(-0.35967793484150856,-0.26354892258589446,0.9652371308182026,2176.6652440906064 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark07(-0.36030769136329366,-0.44182350192096537,40.25473875860489,-42.977302153698936 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark07(-0.360349131797783,-0.004221368591136985,0.9655727292963397,-1.1574576561917524 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark07(-0.3618098059971458,-0.5235987755982839,30.725215882114515,-68.01413668058933 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark07(-0.3625244047349119,0.27972539136021973,0.9666603657649042,-0.13957552559787256 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark07(-0.36333169216342054,-1.1102230246251565E-16,0.18166584608171027,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark07(-0.3649678942171022,-0.5196331324678409,0.9666450621984095,100.0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark07(-0.36774604137008793,-0.5232384807604157,-30.484270261188552,36.82254607518671 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark07(-0.36824645150509,-0.4163760912603155,-93.29272253679034,72.54288683492207 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark07(-0.36938079412896435,-5.303810033336681E-7,0.18815300972025806,-93.92346344918242 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark07(-0.37164050835368734,-3.5470780058201945E-15,0.971218417574292,-0.7853981633974465 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark07(-0.37207083441335914,-0.5235987755982965,0.2038791736962416,17.503434794289845 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark07(-0.3744945217782552,-0.4016155372902587,-100.0,0.2008077686451293 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark07(0.3760455410214816,1.1700789513888334,-13.466390060902382,-1.3704376390918651 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark07(-0.37880505390866825,-0.5235987755982987,-13.933884784700616,90.36233180317915 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark07(-0.3792860006935661,-1.1102230246251565E-16,7.348339148491537,1156.018538269976 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark07(-0.3805528382417087,-0.02321570280584127,0.9756745825183026,-29.787526653976997 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark07(-0.38286870798823847,-2.446763170429205E-14,-0.593963809403329,-24.300213805031156 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark07(-0.38341802105177575,-0.4983493599716837,-57.072681740097565,-167.58313459611566 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark07(-0.38485373874569434,-4.440892098500626E-16,0.19242686937284717,2.220446049250313E-16 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark07(-0.38488564910033496,-0.5235987755982975,0.9778409879476158,100.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark07(-0.38621740870186755,-0.4645185204363175,-55.69516090147657,0.23225923636838391 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark07(-0.3878281060373824,-0.031072933775544858,-0.0796705751123701,0.015536467722052612 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark07(-0.39045458044778414,-2.220446049250313E-16,24.823456806718603,-0.14803611201701017 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark07(-0.3943165689687578,-0.2840715355579266,-38.60072834842006,0.14203576777896335 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark07(-0.39435874527691195,-8.673617379884035E-18,0.19717937263845597,-0.7853981633974492 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark07(0.3943895170750417,0.7887790341500835,-44.638576076707565,0.39232359646781323 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark07(-0.39463149278613985,-6.891124768712177E-16,0.3926990816987246,-39.73545052733992 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark07(-0.39493337602126743,-3.155443620884047E-29,-77.9844770430436,0.7662290429157192 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark07(-0.39523261626565426,-2.0194839173657902E-28,-94.7570966149272,-0.7853981633972005 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark07(-0.3952508047830312,-0.5235987755982986,-148.29550263990095,44.45857909964593 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark07(-0.4014951990000583,-0.5235987755982947,-60.221452748959294,44.57404658097635 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark07(-0.40217143572562175,-0.4201038875644738,-146.66855260498275,0.9954501071796852 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark07(-0.40415836341481853,-0.6312076863907802,0.5049849345499076,-130.059777127477 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark07(0.4052931961206476,1.0931798710057707,-0.07364918630550135,100.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark07(0.4078536336076764,1.2380610860875638,0.3625406392104864,121.11981749351492 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark07(-0.40879927121449056,-0.5095761315825602,-87.92337896973464,100.0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark07(-0.4093327191098889,-0.4226897719631007,-0.21640142995069572,-0.574053277415898 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark07(-0.40970741358737867,-0.1361473578122079,-8.793879343228589,-0.7173293502485159 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark07(-0.41084683501235303,-0.5235987755982947,-100.0,-0.5235987755983018 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark07(-0.4111985047231128,-3.121298314932787E-13,0.9909974157590047,49.055416001218425 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark07(-0.4135306327274674,-0.3409198619849252,-49.06101421710876,21.152437376250163 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark07(-0.41547141937255816,-0.5235987755982947,-37.471149879363836,0.26179938779914735 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark07(-0.4201054302174594,-5.9299343440827355E-6,-122.65135058793172,-51.85453288381845 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark07(0.4201738603509362,2.2137972440727287,-0.9954850935729164,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark07(-0.42121883430885987,-0.5235987755982987,100.0,-28.507047195196193 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark07(-0.4220248453825051,-0.4568529142154517,-0.5743857407061957,54.38279295067744 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark07(-0.42361581323721165,-0.4679866101415647,14.626314885760905,52.28781740337761 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark07(-0.4246713231484499,-0.008104550676703227,-0.5243861245505196,-82.75136849590511 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark07(-0.42513108667666216,-0.0012437434628186524,0.9030119745468492,15.24753898263813 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark07(-0.42535789389614015,-1.5634344887405784E-13,0.9980771103455184,7.817172419676774E-14 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark07(-0.4309520445961432,-0.5081668351916688,21.969209438253735,-0.07289818613002663 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark07(-0.43262622309952253,-0.5235987755982987,-48.985585306825534,-100.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark07(-0.43288651089156427,-0.30286136897447746,-78.29994269889073,-19.15677215829446 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark07(-0.43298295028151645,-0.5234573546311942,45.539992942095324,1.0471268407130454 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark07(-0.4331420058230102,-1.3865355421638696E-11,-99.99999999997522,-99.99999999996234 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark07(-0.4347644935005306,-1.1102230246251565E-16,-61.46752263471097,5.050289230635613 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark07(-0.4361467387216327,-5.11498097658152E-14,-168.54831572486532,2.5837404243447847E-14 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark07(-0.4386063283294051,-0.3403447757289688,1.0047013275621508,-48.86806175561569 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark07(-0.4390692130904752,-0.5235987755982947,-100.0,-6.988261045969946 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark07(-0.440216056429791,-1.0463474833686044E-14,1.0055061916123438,5.231737416843021E-15 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark07(0.44096504700826006,-2.5849394142282115E-26,91.22222913905543,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark07(-0.44231155895316443,-0.5235987755982983,1.0065539428740304,-0.4997823518452522 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark07(-0.44260198171904186,-0.4573914730465777,-0.5640971725379273,-0.5567024268741594 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark07(-0.4427701989434021,-0.3633841748713539,-91.25676310152713,-47.595139291446785 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark07(-0.44323363134679383,-0.29428600438148894,-75.25004482749155,-70.87841916183638 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark07(-0.4455385837570933,-0.3916051696552292,0.22276929187854577,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark07(-0.447366116777423,-5.551115123125783E-17,-100.0,55.15038924906704 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark07(-0.44754640628829545,-0.3675308986076787,43.131203024924126,4.100253975450291 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark07(-0.4487389758926452,-5.099792824354117E-4,34.79692585357336,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark07(-0.4488085947421645,-0.02176764185681279,-0.5609938660263651,-0.7745143424690419 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark07(-0.4508427004684637,-0.5235971680440201,-0.1447433831647352,100.0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark07(-0.4533643561594103,-8.881784197001252E-16,-0.10198982163518844,-32.2513296404029 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark07(-0.453405806598698,-0.2965173848816174,1.0121010666967973,0.9187006196463824 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark07(-0.45614135161217106,-5.626629951024139E-4,-144.87620550655225,85.60748696520788 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark07(-0.4595074056038917,-0.06533254098146457,-1968.1525939362343,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark07(-0.4616528398696814,-2.7755575615628914E-17,-0.23259615308762838,-50.325154603154324 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark07(-0.4621434985224152,-2.7755575615628914E-17,-46.852260556077646,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark07(-0.46403091110574046,-0.46316840419762806,109.38109236239886,-98.2215743415594 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark07(-0.46442043166542035,-0.16343196851472022,0.23221021583271018,76.85497403836851 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark07(-0.46564643775388775,-0.26960885610415647,-0.5525749445205044,-86.17980521096266 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark07(-0.46750473808591897,-0.5235987755982987,32.992074787777184,0.26179938779914935 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark07(-0.4684939178852434,-0.5235987755982987,0.23424695894262174,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark07(0.4706351822343211,0.9412703644686429,-1.0207157545146088,-21.633417835198042 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark07(-0.4725020435491368,-0.5235987755982987,-10.499589141047869,91.10407227021905 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark07(-0.47275463838010234,-0.06115151495077948,0.23637731919007895,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark07(-0.47678070020446683,-0.5235987755982966,-100.0,100.0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark07(-0.4777824428681535,-0.5235987755982983,1.0242893848315249,-0.5235987755982991 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark07(-0.47809996551707806,-0.5235987755982987,-44.81398285180592,91.97617061800955 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark07(-0.4806325552727895,-6.982642980061072E-9,20.054349838302475,17.303902233709767 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark07(-0.4811230180360818,-0.3666292038083921,0.914779007246759,-0.6020835614932594 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark07(-0.4814448233013218,-1.4387662992390325E-8,-0.5446757517467874,-14.437972916408256 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark07(-0.48234231814015804,-0.15315985823129297,-0.5442270043273691,-0.7088182342818018 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark07(-0.48254626123396493,-0.26036661131278316,-55.280162173685056,-67.52994252578678 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark07(-0.4842138328922218,-0.8436127711113549,-0.5432912469513411,60.897063669063265 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark07(-0.4870481918643744,-0.48573435343314775,-0.5418740674652611,96.27982803533551 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark07(-0.48897162490111296,-0.5235987755982014,0.552872737634336,0.2617993877991003 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark07(-0.4895803218816054,-0.46533122616104844,-100.0,90.57977390314143 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark07(-0.4915948696087557,-0.2617406812224927,-0.5396007285930704,-40.23108333026055 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark07(-0.4918753087769783,-0.5235987755982983,46.61697371956504,-88.79821539888877 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark07(-0.4957362106152127,-0.5235987755982988,0,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark07(-0.49636286296760157,-0.4934484014399379,-91.48875525225634,0.24672420062899236 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark07(-0.49683119621436256,-3.899220829037985E-9,0.24841559810718117,-10.168629016545882 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark07(-0.4983862252310832,-0.5235987755982987,20.189369119723402,687.7268508152118 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark07(-0.49932213857443225,-0.3649650611082142,-70.71100437024774,12.748843265714143 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark07(-0.49942681273065603,-0.23350130981450123,21.75100664826991,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark07(-0.501385718961753,-0.04214283664160434,-0.5347053039165717,52.51971141065906 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark07(-0.5022551110016709,-0.5214503317175271,1.0365257188982837,75.76962910331413 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark07(-0.5023622767139149,-4.135194178671677E-8,-0.5342170250404908,-54.46362032933225 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark07(-0.5036802355241289,-0.11416457655578685,1.0372382811595129,98.65389242689055 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark07(-0.5038246381635001,-0.2553272545360342,-100.0,0.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark07(-0.5044635285196842,-0.22677053896637495,0.2522317642598421,42.84335867027808 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark07(-0.5055353722185651,-0.15734473476532568,0.7153893335227761,6.4542345594726305 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark07(-0.5058187866610098,-0.02913184034474381,-44.81590931415845,3.331376834972309 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark07(-0.5061776658363278,-0.17549843717066535,0,0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark07(-0.5073665423690972,-4.71669463676312E-13,99.99895423009171,-60.45969096331488 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark07(-0.5076732580333443,0.49887922305188065,-0.007125680782432586,-100.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark07(-0.5077230619541844,-2.7755575615628914E-17,-80.34788908203471,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088666212117916,-1.0651779393967345E-14,100.0,-158.70994429873448 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088666688392092,-0.25519214840310994,100.0,-0.6579076775337849 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088674852820942,-0.20402063777428692,100.0,0.102398656341033 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088681674169306,-0.523587534196734,100.0,1.0471919304958153 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088744258750436,-0.20321881153753943,100.0,124.98844046698909 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark07(-0.5088749495691219,-0.06782153237383226,100.0,-54.15855788284053 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark07(-0.5090291770399108,-0.20952668521161746,100.0,25.33089953200417 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark07(-0.5097416088448021,-0.3046360746100707,1.0402689678198493,44.91869843064015 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark07(0.5100473805780712,1.0204466308477973,-0.2551984210840368,20.92778251347903 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark07(0.5105744338191576,-6.87770376259683E-4,-100.0,27.3673694618819 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark07(-0.5115829862549334,-0.5235987717694613,-100.0,1.0184019634051156 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark07(-0.5121464196701659,-0.5210411683205238,-72.14862576768691,-0.5248775792371864 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark07(-0.5121640568269761,-0.5235987755982987,-119.75130892400249,-0.46343457387231385 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark07(-0.5141037347376383,-0.5074338266570377,0.25705186736881913,35.337428208173975 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark07(-0.5163270050007763,-7.934833507803241E-15,-92.17761452099519,82.51767568622257 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark07(-0.5166607064557873,-8.881784197001252E-15,-94.68995095814259,99.84700844563135 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark07(-0.5171178161826058,-0.4395290310141498,1.0439570714887512,-25.241183040140125 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark07(-0.5183365283987902,-0.23635308514243863,91.00792550589713,-89.61538323651217 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark07(-0.5191192139931875,-0.5235987755982969,-72.11102364762017,99.93136278470851 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark07(-0.519222316778733,-1.2267474600198962E-12,-0.025619990485138737,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark07(-0.5199553392695709,-0.5235987755982947,0.2599776696347855,-100.0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark07(-0.5205769980304258,-0.5235987755982986,0.18558556850315736,30.918047035143783 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark07(-0.5213712264398734,-1.3877787807814457E-17,0.2606856132199367,162.57253672110585 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark07(-0.5219185923088557,-0.5235987755982902,-100.0,24.988690579176343 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark07(-0.523626935941931,-7.148942056086931E-14,0.2618134679709655,143.72730999401776 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark07(-0.5236673543613258,-0.36579274573130544,1.0537656060659792,19.686707405882082 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark07(-0.5241693614395672,-0.5235987755982164,-0.5233134826776646,100.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark07(-0.5261412725430279,-1.1102230246251565E-16,-83.02707224333452,-100.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark07(-0.5272084484336796,-7.006492321624085E-46,0.273450720115375,3.5032461608120423E-46 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark07(-0.5274748412307853,-0.3722625047246723,1.049135584012841,-71.28378669648605 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark07(-0.5279656284671401,-0.9493525358432676,-52.037418885494205,136.3535489313332 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark07(-0.5279987402428377,-1.7593572292999968,13.69310283087715,-4.6044211326674365 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark07(-0.5288350718434596,-2.7755575615628914E-17,0.705652176032307,-20.62968505147069 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark07(-0.5302954893063727,-0.48997067908270836,-100.0,0.24498533954135418 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark07(-0.5303555194389915,-3.630453722653813E-4,0.26517775971949564,0.7853981633974494 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark07(-0.531028122331854,-0.5186699953163317,-12.971159185647188,0.26179938779915 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark07(-0.5329164440147245,-1.6921946901498244E-18,-0.518939941390086,53.75420397922581 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark07(-0.5344152047622044,-0.5235987755982983,0.2672076023811022,-40.07320034317505 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark07(-0.5347124298778115,-1.1941599085098765E-6,1.0134228388506277,84.85021850189796 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark07(-0.5350622303124829,-0.479040139564279,1.0529292785536897,-63.482717942225165 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark07(-0.5354722517048782,-0.5235987755982987,0.26773612585243933,-16.027321228920528 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark07(-0.5360167840062627,-0.5235987755982983,0.522278221636517,-0.36951464785742216 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark07(-0.5373386180610357,-1.7763568394002505E-15,-40.59215412336681,-64.17233966008463 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark07(-0.5381307481730582,-0.2548887700240264,-100.0,-47.319680743209396 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark07(-0.5388312399764883,-0.2099606224495646,-100.0,0.10498031122478231 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark07(-0.5401944733205188,0.0,0.2927734137867257,-19.452664177611357 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark07(-0.540469935971906,-0.331133794575849,-49.460236906356016,0.5951043883962899 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark07(-0.5425685539516536,-7.087540729991625E-17,-100.0,-36.17410604059582 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark07(-0.5430258249977377,-0.5165060466260354,1.0569110758963172,87.70794065209412 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark07(-0.5431969948797155,-0.5235987755962258,0.27159849743985776,0.26179938779811296 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark07(-0.5432843009621049,-0.5235987755982947,-100.0,96.2908447677805 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark07(-0.5433846655399979,-0.5226085684881688,0.27169233276999893,0.2613042838414418 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark07(-0.5435578188214254,-0.5235987755982978,-9.402258870020633,100.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark07(-0.5477164840412758,-0.06806470829967459,2385.618481542836,0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark07(0.5494925177455993,1.0989862327801427,-1.0601444222702479,-93.22476871376594 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark07(-0.5507250837801161,-0.5235987755982985,-32.38392840716066,0.08403168394530125 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark07(-0.5516926480641545,-0.523598775598298,0.27584632403207726,21.19881640928138 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark07(-0.5523502532136635,-1.0719599584199229,-100.0,-100.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark07(-0.5537593129889751,-0.5235987755982983,1.0622778198919358,100.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark07(-0.5538697646800236,-3.677058154186406E-12,0.27693488234001173,1.8385293287792592E-12 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark07(-0.5545634216859785,-0.2585370885721129,1.0626798742404375,31.148222363137034 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark07(0.5548339974872336,-2.1684043449710089E-19,0.507981164653832,82.17011524643345 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark07(-0.5568732866330213,-2.4053820295463276E-7,-100.0,89.03295765881634 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark07(-0.557524214860418,-0.009439511632078517,-0.5066360559657719,100.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark07(-0.5592308361187057,-1.3371058989615214E-8,0.27961541805935286,-13.378554700787442 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark07(-0.5620727606576164,-0.51253367080944,-50.3097483898939,62.86487152819305 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark07(-0.5625646837538728,-0.21566238565056833,-100.0,-0.6775669705721641 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark07(-0.5639401268957135,-0.07743671614468911,-27.460168530041983,-0.7466798053251037 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark07(-0.5647513840310618,-0.5010467385409452,100.0,-72.00928372303997 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark07(-0.5682920598332515,-1.1827205881331793E-12,80.47940682578867,-45.263169033180944 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark07(-0.5683333715043868,-0.04088673823999738,0.2841666857521934,-156.2745128579627 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark07(-0.5706644120834583,-0.5235987755982983,-0.5000659573557265,-0.5235987755982991 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark07(-0.5715875453132261,-1.7763568394002505E-15,35.09506280574203,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark07(-0.5754028602652534,-1.3681410889797064E-5,-0.49769673326482144,0.7854050041028932 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark07(-0.5772539644089747,-0.5235987755982947,1.0740251456019356,51.32779836754355 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark07(-0.5785384728396542,-1.18620254834105E-13,-15.52882718961137,98.94872610775555 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark07(-0.5791169431434273,-0.1644657880615264,-0.4958396918257346,0.08223267293490522 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark07(-0.581010408745978,-3.9271055639746156E-14,-46.255982365423655,80.17304837532261 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark07(-0.5826091458372461,-3.602608512174162E-15,0.29130457291862305,2190.4087545293687 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark07(-0.5844106288894148,-0.5235987755982987,20.620254264784275,0.9835758835998523 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark07(-0.5846803127981126,-0.2822971527274258,-3.0337355928392284,-0.6442495870337354 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark07(-0.58592104575335,-0.5200990038818386,0.292960522876675,1.0454476653383675 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark07(0.5859824538671395,1.1870975380709834,-0.6317677080937241,-0.5935487690354917 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark07(-0.586771169902265,-0.08593454824366202,30.79312876205171,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark07(-0.5900676460801222,-0.4727427534887812,0.2950338230400611,-43.847777594694286 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark07(-0.5906446573704842,-7.921137100656169E-11,0.2953223287942469,6.877823755208572 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark07(-0.5912443392474286,-0.5235697389406544,0.2956221696237143,56.5250544746114 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark07(-0.5917034242518113,-0.5235987755982976,-0.4895464512715426,2.5956653271463095 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark07(-0.5921888061876359,-0.7038319178444544,-45.568924507999185,-27.13702013839472 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark07(-0.5926826831939509,-0.48065309167497877,0.8277286344939968,-90.17475739862579 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark07(-0.5934438767842164,-0.5235987755982947,100.0,-0.5235987755983009 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark07(-0.5934685662103416,-0.14187662063226258,0.29673428310517086,65.12822636421532 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark07(-0.5935176029614695,-0.5235987755982974,-69.10083886295678,1818.4336492472835 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark07(-0.5942943038776576,-0.3586961682450588,-0.48825101145861943,-0.6060500792749188 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark07(-0.5951114615652415,-0.5235987755982947,-41.66920868551476,-2152.8528030732614 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark07(-0.5963381743088689,-0.4552746143161038,-0.8622034934757038,1.0130354705555 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark07(-0.5979745904297125,-0.4742398656874953,-0.051194136416711444,1.0176331808948562 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark07(-0.5984641761959715,-0.06254316539995874,0,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark07(-0.5985109798370992,-0.2837210647332622,0.29925548991854956,0.9272586957640795 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark07(-0.6001206450454287,-0.5051575270767835,-0.4853378408747339,54.10606040392034 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark07(-0.6002454023178679,-0.10279238123728485,1.0855208645563823,3.5789746378499956 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark07(-0.6007818194302019,-0.5235987755982983,1.0446846375271661,1747.8536714185113 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark07(-0.6035534305214942,-0.1138858009077622,-0.48362144813670227,18.988902253090558 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark07(-0.6035705465102714,-0.11387329127105063,-0.48361289014231285,0.05090328874849568 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark07(-0.6062516003758127,-0.5235987755982985,-0.4822723632095419,-0.523598775598299 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark07(-0.6065496780023738,-0.6516197941586477,100.0,-56.227409531949746 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark07(-0.6094371886918405,-0.4807832065752868,1.0901167577433686,1.0257897666850917 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark07(-0.6102970365278342,-0.39515585672949305,0.3051485182639171,-6.864836938289097 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark07(-0.6105601921865826,-0.11308860225593986,77.80824734118758,100.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark07(-0.6122075068597592,-0.28629332295410753,1.091501916827328,-90.39337780706175 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark07(-0.6128828760593392,-0.5235987755982983,-0.4789567253677802,0.26179938779914913 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark07(-0.6148163562115219,-0.024730882102817153,-0.239418460256808,-20.795944420661474 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark07(-0.6163233251640658,-0.5212846883531849,-0.47723650081541535,155.63289995551654 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark07(-0.6163472000689032,-0.5213135271407238,-122.33286908642813,-100.0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark07(-0.6193868876706468,-0.48452606591391056,0.9281940872961877,-24.43699979077518 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark07(-0.6199804350360727,-0.1018345777070291,-0.47540794587941193,47.16841779467235 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark07(-0.621237961562572,-0.08744778798744801,-100.0,0.8291220573911723 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark07(-0.62219735461747,-0.5230838486422182,0.4438688465491431,-98.46610997809366 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark07(-0.6225077950509834,-0.11289789740160333,0.9669079074083546,0.8405321917788127 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark07(-0.6244575897772255,-0.5213567683805705,0.31222879488861277,10.469131459664212 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark07(-0.6246068870715592,-0.4455261900237646,0.3123034435357668,83.93597984006072 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark07(-0.6258384088215431,-0.5181576208228752,56.38571946662747,-24.813963687824494 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark07(-0.6266561508330584,-1.7763568394002503E-15,-9.26182166971192,0.7853981633974492 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark07(-0.6271854899389626,-0.31395848926855185,-0.471805418427967,-0.6284189187631724 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark07(-0.6293854973069579,-2.7755575615628914E-17,-1188.3277436788228,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark07(-0.6303763294671552,-0.5235987755982983,-88.0078123105919,90.13770666086818 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark07(-0.6311850250155331,-0.05070695592830532,0.31559251250776654,15.821271955814623 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark07(-0.6329778862389787,-0.2655728233529673,-60.56885307668414,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark07(-0.6329983514371463,0.16542039775423864,-55.78622390636952,-0.8681083622745677 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark07(-0.6331227962265221,-5.551115123125783E-17,-89.6035051460699,0.0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark07(-0.6338731527852663,-0.48070978888503024,100.0,-3.0414794822083397 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark07(-0.634125290862543,-0.9696150506232761,59.22898487263462,-232.32002521334582 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark07(-0.6359305609161865,-0.01756187760337379,-0.44863541331504786,0.008780938801686889 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark07(-0.6361232280743262,-0.038980094346045824,1.1034597774346113,-77.05681816235963 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark07(-0.6372771992854697,-8.46422977744301E-10,1.0810816653909423,-0.7504688816509978 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark07(-0.6372875053939983,-0.5235987755963977,0.3186437526974822,17.782671621698316 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark07(-0.6404868734444142,-0.5235987755982983,-99.3351985090488,100.0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark07(-0.6414053597617917,-2.8421709430404007E-14,1.1061008432783441,-55.6538414007955 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark07(-0.6425046379875777,-3.6865672815746734E-10,-100.0,-0.9791109409101324 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark07(-0.6430155998208997,-9.64295623393147E-4,1.1069059633078981,-27.21338909081231 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark07(-0.6439853476285904,-0.5235987755982489,74.23863915149663,-0.5235987755983239 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark07(-0.646564266297105,-0.21670006096886568,23.65771997411764,34.75320513852205 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark07(-0.6468245245226346,-9.933197866744878E-11,-94.2180542709416,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark07(-0.6479998316920096,-0.5235987755982983,-0.46139824755144354,-48.37368603388114 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark07(-0.6490152077951252,-0.5235987755982987,-6.587847805759004,35.95579308232081 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark07(-0.6508195071190634,-0.2868142750826814,-0.45998840983791556,45.542896746505846 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark07(-0.6541336257332899,-0.47844678581958766,-25.885614450081366,58.23284476295223 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark07(-0.6547118859675474,-1.1102230246251565E-16,0.017669351275000432,-90.83530972317118 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark07(-0.6551313844805534,-0.46772858684611357,45.76137770321845,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark07(-0.655969499340897,-8.881784197001252E-16,-55.622888369184345,0.2173974694904561 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark07(-0.6585689425135767,-0.12116103577879415,-16.432280880255448,0.8446637609674262 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark07(-0.6594438069597223,-0.15645309784462305,0.600931156206283,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark07(-0.6599179989324142,-0.5235987755982947,100.0,-52.82236956551416 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark07(-0.6602237439089884,-6.432186092343652E-15,-0.2098964609660752,-73.84094927569292 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark07(-0.6604878918168393,-0.5080375107852888,1.115642109305868,31.682240669797743 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark07(-0.6610845572264871,0.1407396003752202,0.4009060481397108,-84.1112881033411 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark07(-0.6616746998607659,-0.3933126101027373,-8.163085050309082,-41.97722578951621 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark07(-0.6627963266147312,-2.1316282072803006E-14,0.3313981633073656,-4.756248614885642 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark07(-0.6635762045971658,-0.3777816262153702,1.1171862656960312,89.19677984428068 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark07(-0.6659999208094962,-0.5209112924942072,0.46718602033384127,-0.5249425171503446 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark07(-0.6662873984469755,-0.5235987755982987,-103.92073020324361,-0.6243546998394969 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark07(-0.6663432244519545,-0.050122166493348115,1.6619569711393836,94.27600212851897 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark07(-0.6665701223203819,0.2376560821541088,0.33328506116019097,90.98735718661105 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark07(-0.6681901183638193,-1.1102230246251565E-16,1.119493222579358,-28.812238123761784 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark07(-0.6682673511824684,-0.4874852189264977,-94.4735316057533,-82.12957450638828 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark07(-0.6694595196086475,-0.5235987755982987,0.33472975980432373,-82.97585665248509 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark07(-0.6695876553337191,-0.5235987755982964,-85.28469051050986,0.2617993877991487 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark07(-0.6698032969873288,0.2296198546848392,-100.0,3.804922747595293 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark07(-0.6703681331798057,-1.250181498517547E-13,-0.31500406765655964,48.6950561908395 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark07(-0.6712119051982057,-0.04644062950886774,80.98602890319458,0.7853981633974152 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark07(-0.6726816877987289,-2.078337502098293E-13,1.1217390072968128,-0.7853981633973444 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark07(-0.6751389393565427,-1.734723475976807E-18,-55.69761822711079,-2.2792390604909966E-16 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark07(-0.676322694166987,-1.8474111129762605E-13,100.0,100.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark07(-0.6789412358230544,-0.46049988581452816,100.0,1.0156481063047123 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark07(-0.6819321915606374,-1.0200746946294789E-11,0.3409660957803187,4.774183573341332 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark07(-0.6852928017770576,-0.17932452960110234,1.128044564285977,-17.25913143136195 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark07(0.6855475084473444,2.1613840316150137,-0.3294351571377758,-35.95603138278698 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark07(-0.6900536387453399,-0.20324282046642494,-70.74624519997266,-36.81077734912743 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark07(-0.6907506441619232,-7.748779009378702E-14,-83.86406541270661,-73.2985388949646 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark07(-0.6910439714832997,-0.5235987755982947,0.34552198574164983,13.216724830394504 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark07(-0.6918521929044125,-0.5235987755982983,-0.439472066945242,1774.8093244580903 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark07(-0.6919003245957869,-0.5235987755982985,0.34595016229789344,-63.958203543525215 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark07(-0.6931528674312375,-8.881784197001252E-16,37.18802505890973,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark07(-0.6969483861978736,-0.5235987755982947,8.730136649806902,100.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark07(-0.6972107365460223,-0.051429446426344845,-0.43679279512443714,-14.600940919221467 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark07(-0.6975007328413594,-1.0255181741189723E-4,-67.33192348382978,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark07(-0.6983799415193215,-0.1429961055018209,0.34918997075966074,0.07149805275091045 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark07(-0.6985132782903372,-2.7755575615628914E-17,84.22850944893534,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark07(-0.6991410957220715,-0.2265342250093475,-30.29456093643188,-100.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark07(-0.6991518948417124,-0.45942064839238733,142.6593648185645,0.23041545975626454 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark07(0.700368807931735,2.3350577965094614,-100.0,-3.523684725148951 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark07(-0.7006251998306842,-0.2629010680476595,0.5622592452645074,-0.6539476293736186 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark07(-0.7022051452108915,-0.5183428766358945,70.49597492225371,0.2591714383179472 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark07(-0.7060174511055234,-9.65023865734899E-16,-0.09715621265904509,0.7853981633974487 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark07(-0.707409386347047,-0.4627554130635426,-100.0,-1.1233393497693869 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark07(-0.7082338570633058,-0.13876616904545178,27.658848530793456,-24.111786076625314 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark07(-0.7091689232062923,-0.3443240356649232,-100.0,-44.61958056961443 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark07(-0.709944774735614,-0.5235987755982974,-59.77956964414465,77.13387189173133 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark07(-0.7106841090715418,-0.010440195889536347,28.027523036294145,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark07(-0.7114600322035516,-0.5235987755982983,1.141128179499224,45.86660580815112 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark07(-0.713536392241642,-0.008858111521610562,-54.11934448163732,82.88428795798043 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark07(-0.7147088122512137,-0.26679621443312773,100.0,-42.88941850265877 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark07(-0.715365655825805,-6.938893903907228E-18,1.1430809913103508,49.918912763122506 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark07(-0.7167637900887165,-0.11886053410552051,100.0,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark07(-0.7174056357816299,-0.379763016354804,-36.084577534133345,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark07(-0.7182039126210281,-0.0371576483464245,43.555915548106476,1.588496959926496 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark07(-0.7183279709444861,-0.012142407543753637,0.35916398547224304,57.48769560015802 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark07(-0.7190993677382966,-0.5235368808898767,-58.25917703604215,1.0471666038423866 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark07(-0.7223028172436496,-0.5213876770444414,100.0,-80.6366319117344 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark07(-0.7223629686437579,-0.5235987755982987,100.0,0.26179958720300067 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark07(-0.7232097353362026,-1.0469050849888832E-15,0.3616048676681013,13.206712586382737 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark07(-0.7233988579829512,-0.4974924889707944,0.6011398595301123,6.409442263478086 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark07(-0.7259848457648423,-1.1102230246251565E-16,-26.79075288299436,20.00818553295086 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark07(-0.7276282665866263,0.09350869646360774,1.1414751652364659,-0.8321525116292522 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark07(-0.7276882175162911,-1.659816280109796E-5,0.7853981633974483,-1848.390877595811 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark07(-0.7284488999457855,-0.17040823968536567,0.35256978938463623,69.72586736640167 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark07(-0.728643858395543,-0.01602146853849424,-0.42107623419967666,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark07(-0.7288295538028237,-1.1102230246251565E-16,1.1498129402988602,37.77724643747735 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark07(-0.7290630441586043,-0.3725340625132208,0.5038430232629785,0.18626703125661037 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark07(-0.7293795435914063,-0.34729929425290607,0.3646897717956996,-86.97440206831526 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark07(-0.7317664224917296,-0.5235987755982972,0.36588321124586987,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark07(-0.7320125833334551,-0.10995234282463118,-81.03542175095991,67.55089160536565 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark07(-0.7325720474444162,-6.359604723779885E-15,-94.23942014811082,-1599.9244468719753 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark07(-0.7325878966347903,-2.2216054197839545E-16,0.9510589524355558,0.10806616572842737 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark07(-0.7326386456826639,-0.5235987755982987,0.36631932284133195,-30.712001011249757 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark07(-0.7328438111875011,-0.006305427060783068,-0.08064984257556969,100.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark07(-0.7335527495889745,-0.034539502578169845,100.0,-17.250517226997424 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark07(-0.7350577288914175,-1.7763568394002505E-15,100.0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark07(-0.7361337508639477,-0.05986546984532427,-56.88507957773618,-1665.8667558086204 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark07(-0.7363513550456977,-1.0078330108424844E-35,0.36817567752284885,5.0391650542124214E-36 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark07(-0.7367370356698518,-0.09608771051405253,-24.21032388903976,37.80180293017097 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark07(-0.7381509667572086,-0.5235987755982974,0.3780561286231092,-72.44460507433615 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark07(0.7384659865465077,1.564164027865806,0.41609910217431073,175.94345199554908 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark07(-0.7393515309770823,-0.3377652122407509,1.1550739288859895,63.133814131565735 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark07(-0.7395969793000503,-0.002200492860857416,100.0,22.89797834666317 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark07(-0.7402070742705585,-6.938893903907228E-18,-100.0,68.76625907477975 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark07(-0.7404350484348536,-1.1112020146356545E-11,1.1556156876148749,-45.69633955415028 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark07(-0.7414014988648656,-7.105427357601002E-15,-91.4426842677994,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark07(-0.7423366142162844,-0.5235987755982983,0.36320554094774526,72.46953855866414 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark07(-0.742779338106877,-0.5235987755982983,43.03863309414766,0.2617993877991509 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark07(-0.7430687283440324,-0.31409301547919666,-0.4138637992254321,54.296136841961555 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark07(-0.7431254228370754,-0.5235987755982987,100.0,-0.4701701114700978 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark07(-0.7432684086161765,-0.024160331992304714,1.1570323677055365,61.5461363966326 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark07(-0.745076631814305,-0.24234655718974096,-76.81954861457841,27.103888012466406 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark07(0.7483887751948299,2.352133269935865,-0.9334982184876804,-1.1760666349679312 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark07(-0.7496186137355387,-0.014267194699185201,-47.72253774676534,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark07(-0.7507524559942231,-7.327471962526033E-15,82.84218425364415,0.7853981633974519 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark07(-0.7522710327279534,-0.5222954903450184,-21.071009700320563,1.0465459085699576 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark07(-0.7534042055235182,-0.061036188356872204,-100.0,-0.7548800692190122 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark07(-0.754556047686036,-4.440892098500626E-16,0.377278023843018,2.2204460492503128E-16 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark07(-0.7549402518362189,-1.2616648507300841E-14,0.834361311872394,84.97152643967479 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark07(-0.7570185402709404,-0.016246762425709584,1.1639074335329185,-33.49227589217823 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark07(-0.7574011403924306,-0.5235987755982947,0.8035481246179579,48.42027240827978 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark07(0.7595222577088883,2.0005996556287746,0.4056370345430042,-0.21490166441693895 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark07(-0.7622120128036917,-0.4547250686461544,1.0960528279418245,0.22736253432307724 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark07(-0.7668338199568874,-0.5235987755982974,-74.53945692534467,0.26179938779914874 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark07(-0.7694150682427296,-0.8861176526695979,-87.69121274984579,1.2284569897322473 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark07(-0.7694673742340545,-1.750841914584063E-11,-0.4006644762804209,-52.584414813665205 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark07(-0.7696971992579418,-3.1858904586904877E-12,0.39269908169870504,28.322862890298694 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark07(-0.7699014648569406,-0.21311008690937372,0.3848792823607968,-0.6788431199427615 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark07(-0.7705768096212425,-3.035780926898371E-14,-0.39269908169872547,61.61473079940038 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark07(-0.7714968082734751,-7.105427357601002E-15,-0.39964975926071067,-9.9139238523912 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark07(-0.7718938431533817,-0.2021072750357244,0.4175298616308755,0.7287789446815744 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark07(-0.7721526309326471,-2.220446049250313E-14,1.1049497841900622,100.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark07(-0.7725805560528748,-0.5207375143931972,1.1716884414238857,-0.5250294062008497 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark07(-0.773523999777117,-0.5235987755982987,1.1721601632860068,12.50414362953337 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark07(-0.773929828940499,-1.7763568394002505E-15,100.0,13.461275874129724 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark07(-0.7741466369914549,-1.0097419586828947E-28,0.11889527900444818,0.7853981633974483 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark07(-0.7752491292208177,-0.004740608346727925,-0.39777359878703944,30.633816476259195 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark07(-0.7770823061923307,-0.0975826659230985,-18.318373081994473,-100.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark07(-0.777394385518515,-3.0375701953744283E-13,1.1738175918867602,52.31407187459996 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark07(-0.778899516128258,-0.5428863520075164,-35.54671881316902,158.90178618720023 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark07(-0.782018303145751,-0.19653360261469596,100.0,-61.63544456113924 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark07(-0.7823338747874298,-1.3467240176391194E-7,-9.705638998714335,-24.84132718584267 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark07(-0.7827032515069208,-2.1345731951967484E-4,-9.055253612859751,0.7827032515069163 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark07(-0.7843338783517988,-0.5235987755982981,8.668712392384968,-35.92802359504264 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark07(-0.7847787611267529,-0.5235987755982494,1.1390730888859912,0.9045489826704314 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark07(-0.7847797670018304,-4.150679254305921E-7,-66.75839485149537,2.0753396271638858E-7 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark07(-0.7848741966921597,-1.6026794527266101E-12,0.3572170633032931,8.013397263633051E-13 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark07(-0.7848871081234033,-0.2637974790925628,-132.39376626788285,31.296927825197596 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark07(-0.7850803144149873,-4.440892098500626E-16,-98.977116657306,1576.4074874861562 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark07(-0.785117631371555,-1.032609386613937E-15,0.39255881568505263,136.66653528187095 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark07(-0.7852802454071021,-0.12959353200379659,-77.43456566694026,39.40206869693014 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark07(-0.7852906550360264,-1.8795218873205396E-18,0.3926453275180132,0.7853981633974483 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853175240885887,-2.2241245162897295E-15,48.369821726180916,0.7853981633974494 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853327373171337,-1.3552527156068805E-20,-100.0,91.10598749678509 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853701243598284,-1.7763568394002505E-15,99.99950451353062,-21.483989482624338 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853967432723599,-4.87281237613857E-22,-6.782921757711598,80.2170818111501 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398162974226,-0.11233392271428393,0.392699081487113,-77.69693629467082 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981631930477,-4.6269639999452886E-9,-0.19075375046668666,-46.50462144726741 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633285694,-5.0487097934144756E-29,100.0,20.7719151057051 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633954337,-7.888609052210118E-31,-77.33828462486063,-61.26300988178131 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633958149,-5.865594463097395E-11,-100.0,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163396823,-2.220446049250313E-16,100.0,0.7853981633974484 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633970789,-2.0093995545551684E-14,-0.39269908169890877,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633972928,-2.0455361979958788E-11,-0.39269908169880097,54.88194542492192 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397435,-1.5718362949899525E-14,-72.30253154554241,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974438,-1.1102230246251565E-16,-92.59436592622943,75.0039249848212 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974448,-0.2261356186667923,-0.39269908169872597,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-0.001536223841371186,5.828752295035628,39.06177374156985 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-0.16149214013404878,0.3926990816987228,59.490048337894606 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-0.3194165902733549,56.610924895924654,0.15970829513667745 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.0658141036401503E-14,-39.701349083008665,-2246.7376289212452 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.1102230246251565E-16,-10.454649466759008,66.55684401203706 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,1.1102230246251565E-16,1.178097245096171,-5.551115123125778E-17 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-1.5178830414797062E-18,-20.81304833235051,-23.574050354885046 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974456,-5.373938352730558E-15,-0.3926990816987228,1.0907226698788435 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974461,-3.7813041210341945E-15,-61.21646984569125,4.166910213943773 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974463,-5.945582883757653E-16,-100.0,2.972791441878827E-16 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974465,-0.16627607537612735,0.7440341866790217,-64.42869097047675 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974473,-3.223482158945423E-15,100.0,-100.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-1.6064359532561654E-14,0.3926990816987237,-23.729658752688337 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-3.0476129702346057E-16,-87.94343861259368,94.04079088059643 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974474,-6.595790108596442E-14,-0.1481340159346256,43.53192850263427 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397447,-7.620041528788169E-14,0.3926990816987235,32.67231747994072 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974478,-8.881784197001252E-16,-0.11882087250030349,-65.54019941428504 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974481,-3.0357660829594124E-18,0.39269908169872403,-3.3219030302061863E-7 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.03641187919893503,-83.71628759740112,-95.46761657350716 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-0.2706848829210257,0.39269908169872414,38.93479370560062 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-3.5599782657315045E-14,1.178097245096172,25.964631192569072 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-4.0285395044215557E-10,100.0,-20.50157115446888 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974483,-4.440892098500626E-16,0.4619490597277047,79.50009374100327 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163397448,-5.347695185029807E-49,-29.18954422401552,2.673847592514903E-49 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974485,-4.669281035191766E-10,-48.5011386325522,2.334640518018502E-10 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974485,-6.409674137832656E-16,86.29394397608445,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.007951282093559569,-95.56899737803077,0.003976147993983136 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.019864107768384306,-60.57770567066745,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.07841359839539014,-2.9587869141251346,-7.421399498629693 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.13174413284791098,-79.35610349521178,-6.299623594110898 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.49777691223638565,100.0,56.32889425338914 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.5082510456232627,49.09908624005836,1.0395236862090798 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.5170025648032144,0.3926990816987246,2009.1947723433545 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-0.5233896457271048,0.3926990816987237,-0.5237033405338958 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-3.366423301438191E-11,-100.0,-11.478861412035982 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974492,-8.669060944656215E-15,45.9870866646657,85.7683808301546 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974495,-1.0133177538242075E-12,100.0,-10.833498361221075 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974502,-7.0999495567439796E-15,0.3926990816987251,3.552713678800501E-15 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974515,-1.1319721327007233E-14,-52.228977809031605,-91.0794461873487 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974517,-7.105427357601002E-15,-48.82449226800048,59.60916440818311 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974522,-7.993605777301127E-15,0.8203875910658167,10.395765839351045 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974545,-0.5235987755982985,0.39269908169872725,-373.57761385040436 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark07(-0.78539816339745,-5.381038695266335E-15,-8.336482432983388,-0.7853981633974456 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974615,-2.8421709430404007E-14,100.0,-0.3041860217156511 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974617,-5.929565104541192E-14,-18.56245420202091,13.834925273204327 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633974687,-0.09360250752457648,-100.0,87.76659089830582 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633976267,-7.864858693112611E-13,-10.630243975926257,64.55466978775549 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981633976899,-7.406538588831174E-11,1.1780972450962932,-29.138704292544954 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981634030144,-1.1132341854755443E-11,-74.54846405297721,5.5661709273777214E-12 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark07(-0.785398163424138,-7.233275708321197E-10,0.4662890237485605,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981638060588,-8.215193040703766E-10,100.0,1704.6018365825587 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981643029897,-1.811994617823752E-9,-100.0,48.83438799080197 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853981714343412,-1.607378608289895E-8,-26.978699553282354,-1.8563129285166644 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark07(-0.7853982246033664,-1.2241183797411366E-7,-97.14620076183135,-51.465459950127084 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark07(-0.7854506627349281,-0.0016488573991959572,0.39272533136746407,-44.938302237742676 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark07(-0.7855730685040535,-3.498102132117903E-4,-0.3926116291454216,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark07(-0.786095935702928,-0.001395544610959601,1.1784461312489123,-65.18866471000217 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark07(-0.7861068181621578,-0.0014173095294191182,-100.0,-81.94198310296206 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark07(0.786556602298785,1.5796682656083167,-7.4225505708672825,-100.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark07(0.7868420821109644,3.1277453007356497,-0.39099670403865433,74.61977764744697 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark07(-0.7871686280493897,-0.0035409293038829565,-11.060940501701987,16.20688060551258 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark07(-0.7874694595798934,-0.5235106060249775,-78.50719575991909,85.73834577281247 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark07(-0.7874932742705469,-0.5235987755982985,-0.3916515262621748,0.3069748731806459 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark07(-0.787767976485688,-0.14815053996224417,-0.2617993877779625,0.8581585130591285 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark07(-0.7879927289694848,-0.16255867567852958,0.3939963644847424,69.19633521321751 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark07(-0.7882603588983907,-0.005724391001885282,-70.55825944572152,-13.389463652231669 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark07(-0.789427369312775,-0.008058411830654701,0.3947136846563875,-5.877914733219541 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark07(-0.7900809009712639,-0.0399862145855877,1.1804386138830802,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark07(-0.7913846143242267,-0.07120094748961023,-53.231229054165645,7.130222930410852 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark07(-0.7919315298982386,-0.5235987755982987,100.0,1.0471975511965939 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark07(-0.7924983639957428,-0.9951003494243705,-1.1654070733935984,180.28111613966274 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark07(-0.793458313735016,-0.5235987755982983,0.396729156867508,70.31438246245938 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark07(-0.793873050151203,-0.5235987755982983,-115.28608543988403,-39.26538469945085 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark07(-0.7943165964922798,-0.017836866189666067,-0.3882398651513075,-44.81522442558612 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark07(-0.7947322382482125,-0.09273311619235725,1.17426993105486,-0.7390316053012697 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark07(-0.7954830489392449,-0.020169771083593448,-0.38765663892782576,107.61106401419138 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark07(-0.7965981488024134,-0.5235987755982974,83.86476528690577,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark07(-0.7971142817308581,-0.41727785559104047,1.1839553042628772,-31.898018197281598 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark07(-0.7975477589699639,-0.4610424725286638,-71.95568854850715,-65.8871669252885 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark07(-0.7979373450660994,-0.025078363337303983,1.184366835930498,0.012539181668651991 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark07(-0.7982183729685794,-0.025640419142262835,100.14466915443785,-116.22567954735888 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark07(-0.7988388033285241,-0.5235987755982947,-11.188621061436862,-22.236865952512147 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark07(-0.7991338554591786,-0.027471384123463397,-0.385831235667859,0.013735692061731697 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark07(0.7992280810292942,-7.402179103409567E-4,-100.0,10.485087336402216 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark07(-0.7996177183086612,-0.028439109822429316,-0.38558930424311766,13.36462688432291 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark07(-0.8009526784218312,-0.5235987755982965,-54.79640773007036,0.2617993877991509 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark07(-0.8014212616492372,-0.4635216867781264,-0.3846875325728296,-45.57974119422852 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark07(-0.8016013621593653,-0.03508798506352647,-0.3845974823177657,0.017543992531763232 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark07(-0.8023102818573172,-0.23083026873027687,99.98971188879239,-0.6699830290323098 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark07(-0.8037044750401332,-0.0386051589985089,-0.24725375782707215,29.886231336588324 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark07(-0.8057667871560676,-0.04073724751724,2.400778771196805,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark07(-0.8058969659499393,-0.04099760510498293,-0.3824496804224786,-0.7648993608449568 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark07(-0.8060131177607732,-0.2570638760771092,-133.66825040501715,-0.16393666086320535 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark07(-0.8060746875785268,-0.04136799653291323,0.4030373437892634,0.9167192690742643 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark07(-0.8060808873932506,-0.42177105931784786,-0.3823577197008229,-1433.307296662173 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark07(-0.8067443225030267,-0.34846940247224684,-0.38202600214593485,-18.32611316169183 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark07(-0.8068113216444154,-2.983724378680108E-16,-0.3819925025752406,59.675875418121066 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark07(-0.807480154258158,-0.4332939161552224,39.62005818509064,-17.83914521289279 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark07(-0.807891877024998,-0.04519361682683497,-0.38145222488494923,42.43429388549293 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark07(-0.8086433390634796,-0.05056573491995309,1.189719832929188,0.025282867459976544 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark07(0.8090413675523439,2.603089068720496,-52.08205824002056,1.0546637657131526 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark07(-0.8092282634310806,-0.0476602000672659,1.1900122951129886,0.8092282634310812 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark07(-0.8094558444820731,-0.3175545024125028,0.28131639992606616,0.15877725120625139 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark07(-0.8096464419852811,-0.3254814206571907,-66.35402025288364,0.9481388737260437 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark07(-0.8097234256602364,-0.06140259117456212,0.4048617128301182,-13.164765257322102 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark07(-0.8099557768557548,-0.04911522691661324,100.0,71.69375172288167 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark07(-0.8102669458348855,-0.049737564874874574,-34.18120709923897,13.368147209162558 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark07(-0.8124101113285889,-0.054023895862304994,55.481956440254805,-2193.039938082963 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark07(-0.8128999478508792,-0.3077618935885176,0.40644997392543963,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark07(-0.81348894226692,-0.5183710921096437,-129.10066373155183,-98.79484227267426 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark07(-0.8137180823739314,-0.056639837953173726,2365.3050578030206,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark07(-0.814481300585371,-0.37897650971378655,-0.37815751310476275,0.18948823791624606 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark07(-0.8167266403552125,-0.06265695391552895,42.91597921674282,-54.63602349650413 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark07(-0.8172150939147884,-0.10361458696338917,-2116.345760494778,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark07(-0.819795709305824,-0.5232666918655862,-0.9523881636473988,100.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark07(-0.8197977247660493,-0.35348173808197947,0.40989886238302375,0.17674086904098976 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark07(-0.8199096651465022,-0.5202235362203779,21.519755148646883,28.0123072410229 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark07(-0.8202343802583267,-0.0696724337217571,-0.30853136964522887,-46.70337223222777 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark07(-0.8206509263849499,-0.5110722340896654,-0.3750727002049733,1.040934280442281 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark07(-0.8211848800672508,-0.5235987755982983,26.37308713891358,-94.88023575294184 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark07(-0.8233833171205571,-0.5235987755982983,-0.3737065048371697,41.79421826288541 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark07(-0.8263613566553367,-0.08192638651577956,0.41318067832766836,-25.327307542298758 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark07(-0.8282341875121596,-0.523598775598293,-100.0,80.40953896263794 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark07(-0.8285536807198843,-0.08651290504852843,-0.3711213230375061,-69.91941313927953 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark07(-0.8287440708149169,-0.08672634192702097,49.894448397072296,-0.7366120120109723 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark07(-0.8306304550439546,-0.09706498814839142,0.4153152275219773,-0.7368656693232526 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark07(-0.831312219662929,-0.523580051094083,67.57149735332283,0.2617900353070737 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark07(0.8315801689776705,1.7366866764626632,-46.54469599165122,100.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark07(-0.8317206079341788,-0.09264488908937296,-0.3695378594303589,7.1302434976907225 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark07(-0.8325064931260125,-0.09421665945714276,67.23824508845492,0.8325064931260195 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark07(-0.8326112714632217,-0.09442621613155133,-95.5798051207991,0.04721310797567244 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark07(-0.8334589803992059,-0.09670385785400559,-0.30584750165915037,0.8337500923244511 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark07(-0.8335613741908787,19.453582737396076,16.930509676088377,-73.7914509921238 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark07(-0.834664358493462,-0.521690573800925,0.6889392941339144,1.0462434502979108 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark07(-0.8350708442908368,-0.09934536178677716,-21.35765075143555,13.151742918184434 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark07(-0.8354608981583224,-0.11463951038780688,-0.36766771431828704,0.8427179185913517 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark07(-0.8363258286088038,-0.5195503560321456,-97.64966226796231,-93.14650782261295 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark07(-0.8365950976174865,-0.20945458500676065,0.3930251607500249,-0.37344131020451893 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark07(-0.8383275307446609,-0.10585873475700307,-79.92781962409816,0.05292936737850151 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark07(-0.8393575188278608,-0.4845165248986443,1.2050769228113785,13.03054665855963 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark07(-0.840834351246234,-0.5235987755982987,-76.84168370938426,1.0471975511965976 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark07(-0.8413619487613972,-0.34590636729198354,0.4206809743806986,0.7853981633974471 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark07(-0.8424816389229205,-0.11416695105094884,-77.97325278873883,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark07(-0.843142963497218,-0.5235987755982987,0.8641186522817094,17.70288590794364 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark07(-0.8471967621824419,-0.5087465599524044,-50.23443363948411,86.56139938205285 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark07(-0.8474251304674567,-0.5235987755982983,1.2091107286311766,1.0471975511965972 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark07(-0.8475272245312624,-0.44899555015906545,-100.0,0.22449777507953272 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark07(-0.8479680805214923,-0.12513983424811617,-59.96115745852143,-97.06757510537206 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark07(-0.8488138197743423,-0.12772843289859281,0.42440690988717117,0.8492623798467447 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark07(-0.8518396801282648,-0.5185800241581142,-60.38410532324002,6.569894430315284 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark07(-0.8520334264760532,-0.1533941068039626,-100.0,57.25317369529989 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark07(-0.8527008748753526,-0.4759715484150322,-0.35904772595281,163.83380885180873 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark07(-0.8535546514773888,-0.5190172612104588,-10.866800586973863,-1790.4177485432347 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark07(-0.855579688914474,-1.7111593778289482,3.173280787371386,-82.64024292990051 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark07(-0.8556685606582402,-0.5235987755982983,17.936170286194482,-156.01235980378587 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark07(-0.8576576825010801,-0.5235987755982983,-31.036029713824796,0.26179938779914913 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark07(-0.857794373920462,-0.22545316995445575,0.428897186960231,74.81027796434542 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark07(-0.8586975914004802,-0.5235987755982974,100.0,73.48622476756569 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark07(-0.8609972548358829,-0.45579028939683613,95.90108434048925,0.22787988373949375 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark07(-0.8625940425250889,-0.3739430974265979,1.2166951846599927,11.967247897120066 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark07(-0.8632160763729466,-0.5235797177843696,-0.35379012521097497,-71.73589138656749 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark07(-0.8659746262707722,-0.1715223956069667,-42.526999989190834,0.08576119780348335 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark07(-0.8670769200418641,-0.5235987755982983,1.2022466335201005,-1.6765058130047095 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark07(-0.8681733879379592,-0.4207215310499418,12.79153793159978,37.29421937555611 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark07(-0.8704469051745497,-0.17009748355420543,0.8865871212842208,73.1498070231056 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark07(-0.8734051228311456,-0.1806728778670006,1.2221007248130207,0.2640124311642218 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark07(-0.8735870633679159,-0.217377467999485,0.43679353168395796,-0.6767094293977057 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark07(-0.8746110814917302,-0.17842583618856522,0.43730554074586436,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark07(-0.8748825757662213,-0.5235987755982945,-49.04460888236413,1.047197551196596 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark07(-0.8753056246700227,-0.17981492254514908,37.676752278189994,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark07(-0.8764836881402878,-0.3982873104420359,-11.629960734431672,0.9845418186184662 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark07(-0.8770323844465224,-0.5235987755982947,0.32458377255091175,-29.06971864901368 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark07(-0.8778178215155851,-0.18483931623627378,0.931454209217148,0.09241965811813689 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark07(-0.8778810154171505,-0.5235987755982987,1.2243386711060236,100.0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark07(-0.8784228785172447,-0.5235987755982983,108.78041742993511,0.26179938779914913 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark07(-0.8786345171130137,-0.18647270743113184,-0.34608090484094145,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark07(-0.8795068621889942,-0.2931845837710578,-26.561081222186687,91.00732866060852 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark07(0.8811737909227091,1.7623496628919966,-0.44058689546135454,40.746236752146544 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark07(-0.8813237591530918,-0.5235987755982983,-96.42969438996056,0.26179938779914913 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark07(-0.8825429188879147,-0.19478831752902304,-48.29180586360215,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark07(-0.8844550720977069,-0.1981138174005228,1.2276256994463017,93.98577672603741 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark07(-0.8845744129347968,-0.1983524990746972,-13.760155898786993,-0.4897181271358352 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark07(-0.8850817154724524,-0.5235987755982943,1.015905718243748,0.26179938779914713 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark07(-0.8857343522409503,-0.5235987755982734,83.27210416350135,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark07(-0.8867792761852668,-0.20284528828266943,1.2287878014900817,45.72709457191721 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark07(-0.889143123149175,-0.5233126636759823,1.2299697249720358,-2.0780453318221253 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark07(-0.8906648300543134,-0.3022217761523995,1.0339739352126998,0.15131501148512427 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark07(-0.8917029204572017,-0.4959256135289191,0.44585146022860084,0.869936745840119 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark07(0.8922322443837116,2.2230375787642513,0.25461993760796375,-1.1214079132768133 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark07(-0.8938276450497267,-0.5048597634041398,-0.338484340872585,2.0930960186648804 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark07(-0.8949792524326632,-0.5235987755982947,0.4474896262163317,-88.93288314162795 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark07(0.8962722736295617,1.7925445806269769,-42.06528670659391,-29.95061099678488 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark07(-0.8991845303417644,-0.2552019745879833,0.39350624835934234,62.759534543008876 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark07(-0.90296583082817,-0.23513535174877953,100.0,0.9029658392718396 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark07(-0.9034448610767534,-0.5235987755982983,1.237120593935825,-14.143249709285143 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark07(-0.9060347602919909,-0.4222769998630582,100.0,0.2111384999315291 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark07(-0.9064570234234632,-0.5235987755982983,-46.43594916991508,0.297647949941323 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark07(-0.9066275683865173,-0.320463644285163,0.45331378419325863,-62.671627710015194 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark07(-0.9069511068492719,-0.5235987755982947,24.2131742255752,94.6715081230079 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark07(-0.9075602457733791,-0.5235987755943388,-34.55569389496104,100.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark07(-0.9086443756110929,-0.5009979096711185,-34.41091789318515,1.034582197913561 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark07(-0.9091290212619084,-0.5235987755982983,0.4545645106309542,-98.98565253046299 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark07(-0.9099590306623053,-0.523595791285472,0.788022952229476,-42.2575089184454 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark07(-0.9099798620931416,-0.2625902987897211,81.21147822625656,-17.14442131724174 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark07(-0.9104535928205328,-0.2501108588461694,-14.218396636082886,9.268559466402458 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark07(-0.9116393795585165,-0.5235987755982987,0,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark07(-0.9124741443555346,-0.2541519619161731,-25.01058272478168,23.81389305525808 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark07(-0.9130239507879312,-0.5235987755982983,56.2183447804964,-6.288277938185971 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark07(-0.9141223519230506,-0.5231016659200466,-19.94538768481968,2053.6767842232307 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark07(0.9143997928383675,2.6620736569289027,-0.7075709649092529,-1.331036828464451 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark07(-0.9160784011812346,-0.5235987755982947,0.4580392005906173,0.2617993877991474 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark07(-0.9184538616906639,-0.33188018366443817,-98.90066505394593,0.9513382552296674 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark07(-0.9189634369263353,-1.0937999546530999,-77.3611151080175,-100.0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark07(-0.9198265069868804,-0.4086107547213415,1.2453114168908885,0.20430537736067075 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark07(-0.920297140862083,-0.39164876811231497,-30.370526545235244,0.19582390716082584 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark07(-0.9217182289254698,-0.27264013105605,0.460859114462735,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark07(-0.9222950130977243,-0.347457838810244,-42.035954364876986,-1617.1378805835784 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark07(-0.9233982380140162,-0.2760001492331401,-86.29981838069037,0.9220833176945754 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark07(-0.923600546174547,-0.5032156212861829,1.2278226574370756,-2017.6815890761334 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark07(-0.9237179019565893,-0.5235987755982983,-39.113477095524885,100.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark07(-0.9251960506653311,-0.5235987755982987,0.6162094772671102,-87.69393099273942 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark07(-0.9255420014301434,-0.5199501773157285,-51.23421120754628,-1813.8696378359832 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark07(-0.9267405429729658,-0.28268475915123853,19.127316576665855,-28.577241181312644 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark07(-0.927660161967547,-0.5235987755982983,-0.18084911810120108,-87.31805451875294 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark07(-0.9278369862847158,-0.4332229830687394,-75.15945450770482,-30.745552371186747 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark07(-0.9296848935094595,-0.5235987755980599,90.78562774053323,-0.5235987755984183 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark07(-0.9307522571961115,-0.5235987755982986,-0.3200220347993925,11.88733456858758 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark07(-0.9311049062442702,-0.29141348569364417,1.2509506165195834,0.9297899859248643 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark07(-0.9314274928663331,-0.5235019870995766,40.37299680315053,-34.88027561211903 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark07(-0.9328543072873693,-0.4902415996307871,-0.1539347842728479,-24.305190029360656 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark07(-0.9341519875282633,-0.2975076482616304,-0.16335610094498776,0.1487538241308152 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark07(-0.9346585943989012,-0.30777455516337243,27.564443136727903,0.9346585943989011 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark07(-0.9356067511311077,-0.5235890665251522,0.46780337556555385,-65.941951923407 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark07(-0.9361010116178077,-0.3134941731618861,-71.86162378570722,-32.90192871784217 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark07(-0.9366612852647807,-0.30252624373466475,-100.0,-96.42053964278297 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark07(-0.9382033668518103,-0.31644873171687277,-44.305388488190864,0.2632385730840887 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark07(-0.9383825841350324,-0.523563991063685,-0.31620687132993197,-20.7535468560949 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark07(-0.9392305749258402,-0.3076648230608127,0.4696152874629201,21.96982761748633 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark07(-0.9392862573511197,-0.30777618790734323,-0.31575503472188843,0.9392862573511198 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark07(-0.9410638794314766,-0.31133143206805974,-46.38870602646013,-0.6543565682605816 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark07(-0.9411664017720796,-0.3115364767536919,-77.51470854154283,41.950697021047716 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark07(0.9424841550512724,-1.1782895693646269E-14,1.1194549887162626,83.08308349590206 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark07(-0.9435647204999333,-0.5235987755982983,1.257180523647415,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark07(-0.9445944483207087,-0.5235987755982987,-15.512997020837552,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark07(-0.9451843621972933,-0.3683338491304808,-136.39227639410626,31.680022999099304 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark07(-0.9464448633587343,-0.3999365932310589,1.1870914288198249,49.38539969473856 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark07(-0.947153586519927,-0.4986842770781541,-74.92652850340646,24.602481770854023 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark07(-0.9514136642470765,-0.4714409242548188,44.34788669929719,0.1660111347592145 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark07(-0.9536725966983797,-0.5235987755982976,1.2621881881581833,-61.76205299847625 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark07(-0.9540448364602507,-0.5180617523066322,-26.63154791692565,44.81956230449609 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark07(-0.9550446676278727,-0.46302924790578004,-63.811105430737584,16.334148485358256 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark07(-0.9552103694283023,-0.43337087772560756,1.2630033481115994,-44.57201188099063 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark07(-0.9557723473011119,-0.4515968924922009,74.99111230867415,-7.4951696400036525 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark07(-0.9563328035270777,-0.5231186574241959,-80.21457245488655,1.0469574921095464 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark07(-0.9569924728368049,-0.4039915563158709,9.11904307601171,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark07(-0.9599895349320478,-0.5212087072569827,0.48323290450980616,-32.22321131428725 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark07(-0.960327787694131,-0.5040732656311446,-0.3364444270322944,-0.533361530581876 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark07(-0.9612497043976493,-0.523592276376086,-162.71809348257284,146.31696039642105 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark07(-0.9620482833490993,-0.45062755656688613,-86.57417697533117,1749.807964700215 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark07(-0.9630312574251468,-0.35526618805539967,-29.436587692442835,-54.80862546886594 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark07(-0.9638546681846947,-0.3569130095745159,0.48192733409234734,-87.73908916265968 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark07(-0.9658254577783578,-0.5235987755982987,58.9709206379893,25.42086725619053 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark07(0.9659835801385636,2.9600493776494936,-99.99999999999363,5.582611829658332 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark07(-0.9668129472717536,-0.5235987755982885,-69.99753331623512,16.56796078472631 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark07(-0.9677603700233192,-0.36472446070553444,-0.30151797838578887,140.55207961723528 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark07(-0.9682780208588748,-0.5235987755982983,-61.3044976142082,-100.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark07(-0.9688274160689148,-0.49300475562474033,-0.2144336322127829,-99.64128655829883 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark07(-0.970064409770822,-0.446005788416087,100.0,0 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark07(-0.9704332158150438,-0.5235987755982987,1.2706148430099375,0.2617993901944637 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark07(-0.9708247822073826,-0.37085631822116916,-0.29998577229375695,0.5753835695068406 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark07(-0.971563418261567,-0.5235987755982979,0.04584271965118214,20.919343054516148 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark07(-0.9732898121048885,-0.4112823587091096,1.2720430694498925,-68.99574668423708 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark07(-0.9734708632286326,-0.5235987755982876,56.01540153804137,14.190850722561947 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark07(-0.9740633548197882,-0.3880309230216439,0.4870316774098928,0.19401548331526877 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark07(-0.9759172557359417,-0.421681461450674,23.806922221811625,18.25476690974913 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark07(-0.976256425448689,-0.42872090607228625,-100.0,-2051.2690034886828 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark07(-0.9765007418356805,-0.38220515687647416,-0.297147792479608,79.72892128489153 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark07(-0.9776145476751023,-0.5198211499230221,-100.0,99.99999999999997 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark07(-0.9784813334051885,-0.40316074474470787,5.693733232236295,-38.450014401434515 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark07(-0.9792087324037313,-0.5199024986812092,0.644924410929333,-89.826338941032 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark07(-0.9794462055570601,-0.3880960843192233,-99.66704668708435,23.9356206408405 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark07(-0.9808654569354189,-0.39093458707594153,-0.138925531097275,0.9808654569354189 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark07(-0.9825822413516322,-0.5235987755982983,0.47128002836262567,100.0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark07(-0.9826204754045911,-0.5235987755982985,-3.068620414248281,-27.062340878298258 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark07(-0.9829045696970589,-0.3950128125992294,100.0,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark07(-0.9834521965154391,-0.43990537862715257,-0.29367206513972866,-0.565445474083872 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark07(-0.9844377823239646,-0.5223172383579351,-100.0,-37.542805645900756 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark07(-0.9847284971829335,-0.47918159289872986,-30.34409261749201,-37.83481036735859 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark07(-0.985224088566005,-0.3996594237940154,-64.9434689451686,0.985227875294456 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark07(-0.9860800038758005,-0.5028192686932983,100.0,4.177085531014436 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark07(-0.9886472749696277,-1.945377533372282,-72.4764847221081,99.93285735845781 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark07(-0.989274995745738,-0.5015611889102233,-0.2907606655245793,1.0348638375331134 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark07(-0.9905700729822122,-0.4103438191695291,-40.43166947728174,-19.99247602474911 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark07(-0.9906341882861907,-0.5235987755982987,100.0,7.628709446145997 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark07(-0.9914006712159917,-0.41200501563708825,1.2810984990054441,0.20600250627296454 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark07(-0.9916072904793004,-0.6909736427752958,-99.56587556629096,48.254773187133026 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark07(-0.99262353722537,-0.4144507476558446,-0.24931845118373613,0.20722537382792217 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark07(-0.9927507210146258,-0.5235987755982983,-77.32820465304381,-100.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark07(-0.9963566594446007,-0.5221799228112048,-12.709758575610302,-15.38746941430558 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark07(-0.9967847662069289,-0.5226910685916804,-43.40729851979323,1.0467436976932885 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark07(-1.0010777553124772,-0.7853905262405352,0.46335883788084153,1.1780934265177159 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark07(-1.0016963954128908,-0.4325964640308853,0.5008481977064454,0.8589356023711663 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark07(1.0023467258644352,2.004700732934296,-88.06531780591823,151.02860247410248 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark07(-1.0023814701780807,-0.5235987755982987,-134.65786315124933,-0.5235987755982989 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark07(-1.0024979541985986,-0.46529752471235464,0.5167890358672099,-8.18257454615005 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark07(-1.0035711650012031,-0.43634600320750994,-36.79153638005138,69.97406310050259 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark07(-1.0038457664405098,-0.5235623941062096,1.2873210466177032,-100.0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark07(-1.0041591558226213,-0.6323536882855423,-100.0,1.1015750075402195 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark07(-1.0047229029394487,-0.5210268102392619,-35.52752511851902,83.32994810320969 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark07(-1.0048243026556993,-0.4388522785165023,46.010942694616894,0.21942613925825116 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark07(-1.0064340684978852,-0.4571318886912518,-80.70909718658972,0.2285659443456259 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark07(-1.0083845753798382,-0.5197431357652247,-106.40913763157305,-42.19522351924595 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark07(-1.0094316126099296,-0.5235987755982983,1.290113969702413,-52.89517448212994 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark07(-1.0107602781886111,-0.5235987755982965,-76.32656418233488,105.38344497981535 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark07(-1.0113960806124367,-0.4791216374053789,1.1115701460738745,-16.596818155994878 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark07(-1.0116144750490679,-0.5235987755982987,-0.21533915957474048,97.28162074904918 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark07(-1.0120674331070767,-0.523598775598102,-11.503277043557691,17.753351618217394 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark07(-10.13056834935329,-18.76509844605087,5.537121145125998,22.73719399913372 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark07(-1.0134310464857434,-0.4679013729171331,59.37368706252664,1.0193488498560148 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark07(-1.0136795822133466,-0.45656283983475443,-0.27855837229077496,0.22031442606160012 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark07(-1.0139685317926328,-0.4571407367903692,-0.9468566705075018,97.30454087003497 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark07(-1.014358021376276,-0.4579197159576558,1.1698755804608112,100.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark07(-1.0143633571045305,-0.4579303874141652,0.11555978089043649,-0.5564329696903657 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark07(-1.0146234220540198,-0.5235987755982983,-74.96556867955903,-100.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark07(-1.0149370774322142,-0.5235987755982909,0.5074685387161071,1.0471975511965939 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark07(-1.0152067887180805,-0.5235987755982987,100.0,-187.67937879972231 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark07(-1.0159869267424173,-0.5211220324884069,0.5079934633712081,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark07(-1.0161203285780689,-0.46144433036124144,-76.41153857972562,-93.29047535326553 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark07(-1.0168594837018354,-0.5235987755982965,-0.2769684215465306,1.0471975511965965 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark07(-1.0170612419933902,-0.5235987755982983,-0.2768675424007532,16.871447547041583 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark07(-1.0170755760862729,-0.5074261966768693,-78.76671977454387,0.25371309833843464 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark07(-1.0175481128335626,-0.506950895223781,0.4643300392952915,0.2883204247598265 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark07(-1.0183600179188241,-0.46592370904275354,1.2945781723568603,0.23295039622396294 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark07(-1.019305338464812,-0.5235987755982947,43.605686493079276,-58.572032855479804 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark07(-1.0195205503760776,-0.509927870007431,1.295158438585487,0.2549639350037152 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark07(-1.0206272684571278,-0.47045821011935934,-0.02328071122151565,100.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark07(-1.020710927784385,-0.48113167540220286,0.5103554638921926,0.22967907069981855 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark07(-1.0218800983950178,-0.47296387041123533,-21.305360699985265,5.168072484081269 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark07(-1.0218946469454355,-0.5235987755982309,0.5109473234730992,-43.17410875119493 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark07(-1.0232381015446164,-0.4756798762943368,1.2970172141697565,0.2378399381471683 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark07(-10.238353901164695,-18.905911475534495,-73.8167924144565,10.238353901164695 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark07(-1.0247523380421515,-0.5235987755982983,-87.0859761773851,-100.0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark07(-1.0252037071270403,-0.5235984901181092,-50.205306657396754,49.556971404561736 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark07(-1.0253605637060612,-0.5190550593877878,100.0,-100.0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark07(-1.0255167407074368,-0.5047488002275672,-0.2726397930437299,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark07(-1.0257561873624935E-14,-4.203895392974451E-45,-12.290177721085838,0.7840832430779912 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark07(-1.0274468221045283,-0.48409731741416023,-0.11902815855338135,-8.686023127918675 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark07(-1.0281250881908905,-0.5231188523251207,0.5140625440954453,44.673821121569766 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark07(-1.0283646115506357,-0.48593289630637554,-0.2712158576221304,100.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark07(-1.0296787154015052,-0.4928013383121972,0.08111519403077239,100.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark07(-1.0301417562743498,-0.5113646891812045,-0.27032728526027344,-17.211525326024642 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark07(-1.0303639500677955,-0.4899315733407462,1.300580138431346,-42.953248123540035 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark07(-1.0306644088865373,-0.4958637242979722,1.300730367840717,0.24793186214898613 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark07(-1.0315299577204113,-0.4989704615781965,100.0,0.24948524683304404 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark07(-1.0316594831698982,-0.5235987755982987,1.3012279049823974,-0.5235987755982989 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark07(-1.0322250647925753,-0.4936538027902542,1.301510695793736,-43.79953619599273 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark07(-1.0323223694125958,-0.4938484120302953,0.5161611847062979,7.5201766084517825 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark07(-1.033378778137633,-0.49596122948048504,12.284196491157505,1.0333787781376909 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark07(-1.0334142523108156,-0.5235987755982983,-24.68408726203973,99.70966145261117 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark07(-1.03343252652653,-0.5235987755982987,-100.0,-86.77919836812225 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark07(-1.0336321035892704,-0.49646788038364503,100.0,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark07(-1.0339964251158875,-0.4971965234368808,91.09370473195918,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark07(-1.034430502522711,-0.49806467825054357,80.50230351477968,0.8201392714264334 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark07(-1.0350300048975107,-0.4992636830001263,30.64182817364174,-100.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark07(-1.0350930703031198,-0.5044934595929516,-17.73480896420847,46.06743924826821 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark07(-1.0351782181490847,-0.503835330468719,-81.3103229397516,-68.33675639036409 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark07(-1.0354869526532142,-0.5001775785115321,-36.80633432057752,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark07(-1.0361758620722048,-0.5235987755982962,-71.96709847711779,0.3131160013563944 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark07(-1.0364773273375198,-0.5043226615953983,24.495937473704142,1.0362445738756854 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark07(-1.0367098861035315,-0.5262019334800799,-89.96020266680897,0.2631009667400399 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark07(-1.036893638533521,-0.5049400416883472,1.303844982664209,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark07(-1.0374768982748401,-0.5232676291009426,71.61589846257881,-3.280108098079559 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark07(-1.037865110047575,-0.5226240205309436,-4.894148112043283,0.26131201026533424 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark07(-1.0381067966894875,-0.5235987755982983,-42.70313000198567,0.4903277169867869 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark07(-1.038400567036815,-0.5235366595584581,-0.24684953451520028,-0.523629833618219 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark07(-1.0384473289705005,-0.5130355002583814,-207.50471152656655,1.041915913526639 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark07(-10.390121872010013,-19.209447638862965,-49.97354807831536,-0.6935719138795093 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark07(-1.0391687510491465E-13,-2.0747940198411793E-13,0.5826511974176405,-19.51118327124336 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark07(-1.0405345375612207,-0.5235987755982983,-18.086522350503373,-76.31986265252654 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark07(-1.0406602625331562,-0.5161497631233267,-99.50158154607779,99.60658047084254 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark07(-1.0415774769909552,-0.512358627187014,-55.1374882798367,0.26152982241478384 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark07(-1.0422792392234448,-0.5231465063250337,0.5211396196117224,1.0471975511965979 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark07(-1.0426439413300195,-0.5144915558651436,-100.0,48.470484348985536 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark07(-1.0429461886772575,-0.5159026056049758,100.0,-0.5274468605949604 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark07(-1.0430216380387194,-0.5235987755982983,-100.0,-3.5242423148634714 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark07(-1.0430493231171,-0.5235987755982987,-24.621357928206322,57.536636493791306 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark07(-1.0430543993356312,-0.515312471876366,-19.12040436142318,100.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark07(-1.0431097368521618,-0.5154231469094274,0.5215548684260809,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark07(-1.0432132505984164,-0.5159119685722421,0.5216066252992082,-44.7119490118256 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark07(-1.0437091889643633,-0.5235987755982946,-0.2635435689152667,-0.5235987755982876 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark07(-1.0439472083605301,-0.5235987755982983,0.5219736041802651,1.0471975511965974 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark07(-1.0441914227980191,-0.5175865188011419,45.36518845880799,12.045813206216673 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark07(-1.044711084897449,-0.5235987755982974,-90.65060310774602,-0.5235987755982996 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark07(-1.0447184912821303,-0.5235987523400958,-32.026477000400064,0.030200832340356865 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark07(-1.0450624208696175,-0.5235987755982983,0.09285274211621575,-32.69270366268248 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark07(-1.0454866463774355,-0.5201769659725022,-95.30002486253457,0.2600884829862511 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark07(-1.0456289059594586,-0.5231377983162427,1.3082126163771777,35.02333488357087 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark07(-1.0458683167708829,-0.5226184029816924,20.687370920012174,0.2613092014908462 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark07(-1.0459246844636683,-0.5235987755982987,-53.04724174473273,-0.5235987755982989 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark07(-1.0459697210602703,-0.5235959621445799,95.90685045585441,0.26179938779914913 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark07(-1.0459887835055426,-0.5235987755982983,1.3083925551502196,-58.124723169683804 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark07(-1.0460069162953658,-0.5214340560567382,37.14400848645971,64.1243866688256 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark07(-1.0460533161448393,-0.5213641150647795,1.0203134713000503,1.0473946033938228 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark07(-1.0461072111515142,-0.5224892655398955,1.3046143730463982,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark07(-1.0461284682982486,-0.5214606098016061,-48.21341832112353,100.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark07(-1.0461816877476071,-0.5215670487013317,0.5230908438738034,-0.11720372101636659 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark07(-1.0466285347120734,-0.5235439981021408,2.439192049490657,0.26177199410538127 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark07(-1.0466495626690173,-0.5235987755982987,-0.26207338206293956,-0.5235987755982954 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark07(-1.0467472558168147,-0.5235987755982987,0.5233736279084074,-1.3089969491183644 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark07(-1.0468624837237321,-0.5229286406525697,15.43798584315888,-0.4641077809647767 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark07(-1.0470457100603485,-0.523571216796746,1.3089210184276225,-100.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471184693297704,-0.5234700583188281,14.925471076190355,31.644298224624162 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471735109868308,-0.5235893034165908,-18.084658640570403,43.20983550037718 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark07(-1.047196478574386,-0.5235966303538776,-100.0,-0.5235998482205095 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471974360866405,-0.5235985457483111,0.5235987180433203,121.21825273890587 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975406167617,-0.5235987755982987,-6.595203879137,-16.86048224648675 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197544650471,-0.523598762568539,-0.2617993910722127,16.75647573295444 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975495546582,-0.52359877231442,100.0,90.84591075421122 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975510433646,-0.5235987755982987,-8.364026469490973,47.348968394167834 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551157006,-0.5235987755191156,-44.806232513526666,1.047194784806326 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511817468,-0.5235987755982987,0.5235987755908734,-33.91706858395541 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511841505,-0.5235987755982983,0.5235987755920752,100.0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551190358,-0.5235987755982948,-0.2617993878022702,0.26179938779914735 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511960574,-0.5235987755972239,-61.10005663219847,97.58154594901444 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511960774,-0.5235987755982987,-100.0,-30.16242300647749 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964784,-0.5235987755980605,-0.2617993877992091,17.88329135513121 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964864,-0.5235987755980764,-13.790597530838657,31.17528225543031 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511964877,-0.5235987755980791,1.3089969389956921,31.554541774636988 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196516,-0.5235987755981355,-97.57547343085064,-67.87683944955607 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965468,-0.5235987755982947,0.5235987755982805,-0.5235987755983009 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965539,-0.523598775598245,0.5235987755982769,-0.3896194381013033 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965677,-0.5235987755982859,-0.26179938779916445,-61.62036382563729 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965788,-0.5235987755982645,8.412213897150991,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965805,-0.5235987755982983,1.3089969389957385,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965876,-0.523598775598284,0.5235987755982939,-48.95983515447058 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196589,-0.5235987755982988,-102.36583250654962,-48.54505476331389 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982876,-26.03436359984174,100.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982947,-28.597009407101496,19.185683708732356 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982947,-47.07405690276842,-73.44777441323035 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965894,-0.5235987755982983,-100.0,-8.356951540407346 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965912,-0.5235987755982947,-0.15966438022683271,2076.6646138811716 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982896,0.5235987755982965,91.33758017870184 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196593,-0.5235987755982947,-0.2617993877991518,28.940626759130716 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965934,-0.5235987755982987,-100.0,-57.05571252698089 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965939,-0.5235987755982915,-0.11858532930151,57.4264825506554 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965943,-0.5235987755982935,49.14892923601393,52.430425248774775 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965943,-0.5235987755982974,-54.26407984103498,-86.15200052046846 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982932,-40.856906726053495,27.836796626732795 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965947,-0.5235987755982947,1.1748450408095605,-45.16902811741225 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965954,-0.5235987755982947,0.5235987755982965,-0.5235987755983009 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982956,-76.28292302265032,16.56946989586703 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.5235987755982983,0.5235987755982983,-10.874786719673594 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965956,-0.9636511851130203,0.5235987755982978,1.2650749205974614 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965959,-0.5235987755982967,0.5235987755982979,14.399944399350305 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965963,-0.5235987755982983,-0.26179938779915013,-2.59438368260839 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.48504294516495844,0.2617993877991496 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.5235987755982983,-2192.4786996532657 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,0.5235987755982987,-6.7914650288481475 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-100.0,1.0471975511965965 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,1.3089969389957465,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,1.3089969389957465,-65.17911974114743 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,40.33646805981323,62.2439577264034 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-7.014236032360781,0.26179938779914913 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982983,-80.41091590984627,100.0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982986,1.3089969389957465,23.58053582546814 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982986,49.97142491313546,0.26179938779914935 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982987,-100.0,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.5235987755982987,89.91928026644723,0.2617993877991493 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965965,-0.764894611930924,0.5235987755982983,-1.688348912015014 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965967,-0.5235987755982972,0.5235987755982984,-36.58607412965327 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965967,-0.5235987755982981,1.3089969389957468,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982983,-0.2617993877991498,0.26179938779914913 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982983,0.5235987755982998,0.26179938779914913 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982987,-35.174294119043225,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark07(-1.047197551196597,-0.5235987755982988,1.0079696086355114,100.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.523598775598298,-0.26179938779914974,76.67733018384402 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.5235987755982983,0,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.5235987755982983,-11.803615623002,-42.05016235819142 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965972,-0.5235987755982984,78.26889387215179,78.55521289737523 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,-0.2617993877991496,-2.095710022712637 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,1.308996938995747,1.045882630451912 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982985,1.308996938995747,-98.56033187723848 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982986,-21.965435861043087,0.26179938779914924 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-21.637509545283073,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-64.14068735711682,-4.9863053401466875 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-7.114756527529846,-49.75844741186999 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511965974,-0.5235987755982987,-97.74295227145902,70.5908571889885 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark07(-1.0471975511967484,-0.5235987755986014,100.0,-6.021385919380285 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark07(-1.047385192824727,-0.5239740588545582,-0.06351673341917285,0.26198702942727903 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark07(10.585835347867018,91.6399429105717,81.88417289124507,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark07(-1.0602446987249718,-0.5496930706550474,-0.24430705601427596,-25.432279206148763 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark07(10.618029303379133,-1.3837819778927951E-11,-5.910624762149253,-0.8427846864745092 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark07(-1.0624998342033765,-0.55458244926894,-100.0,57.2395412418791 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark07(-1.0678584919229501,-1.2049602399278818,-0.2514689174359731,-100.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark07(-1.0691447727140257E-13,-2.135821008813098E-13,-69.74241826981441,0.4510960201054699 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark07(-1.0729262816090805,-0.5750562364232648,-64.01779141342986,-70.91226178693326 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark07(1.0753173223742727,3.111065856844399,0.24773950221031185,54.418998575184816 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark07(10.77065652676338,21.759760627172724,-170.95751475013037,-56.4329651581227 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark07(1.08079290883864,2.1616024228788513,-0.5403986789647682,2.2296517180372426 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark07(-10.856149691677311,-20.141503056559728,4.64267667974502,7.72149352800665 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark07(-1.0871296232687928,-1.1723851257791722,-22.874479078252364,0.5861925628895861 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark07(-10.938857820776859,-20.306992636945772,-26.578533301835154,-51.89137897520999 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark07(-1.1021017308988197,-0.8981124471325007,0.7511111736215551,-11.285484482127103 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark07(1.1046405048729717,3.763969638844981,-1.3377184157990576,-38.797309299436975 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-15,-2.206620174814137E-15,-0.7853981633974481,11.857662531162905 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-1.1102230246251565E-16,-99.33637095003454,-54.08061928840864 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark07(-1.1102230246251565E-16,-2.193889302232918E-16,-0.7853981633974483,-1.8739295054594962 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark07(11.110008025984001,24.46964299409626,-61.573887703113115,10.776391940906109 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark07(1.1387647559267182,2.2775295118534364,-0.06105489432011493,-13.317726151676633 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark07(-1.1443993765811307,-0.903341463100097,0.5719545619279174,-5.0308193928204155 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark07(1.1453827511916757,3.361028022457737,-1.3154786892956265,-12.676087477291425 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark07(-1.1696053091301533,-0.5235987755982977,29.894534699969192,100.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark07(-1.184328523576029,-0.7978607203571617,47.1787859877484,-78.19250184908998 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark07(11.880491817896218,25.30084920340646,-11.06018572833641,-2.7256466442809426 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark07(-11.964394315067219,-0.5235987755982987,5.196798994136159,-100.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark07(-1.2023275870520824E-16,-1.232595164407831E-32,-65.8052770052601,0.25287590641327873 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark07(-1.231951184219755,-0.5235987755982983,2.038748746817779,122.23256423047758 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark07(-1.2391048044207018,-0.9074132820465088,-0.16584576118709715,9.876227236804269 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark07(1.2413979517652867,-3.469446951953614E-18,-69.7313427643797,-52.20606595275476 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark07(1.2481919124837284,2.5050425204450506,-44.934800047375724,-2.0379194236199734 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark07(-1.2490009027033011E-15,-3.944304526105059E-31,-8.95362606200544,0.0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark07(-1.2511335841818978,-0.9314708415688993,-0.1598313713064994,15.276154762387371 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark07(-12.54120409487676,-4.263256414560601E-14,7.056000210835828,-42.17948791969849 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark07(-1.2553559612865912,-1.097118467360161,1.377586537947372,100.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark07(-1.2591320989885426E-12,-9.10223132163886E-13,-62.69879767711178,6.0477614966105335 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark07(-12.715368055465959,42.45242567275545,0,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark07(-12.751795053796453,-23.93289471527968,-100.0,-26.687797699958566 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark07(12.769559592511403,25.522888592263044,-100.0,-26.898418167226666 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark07(-1.2848867610489512,-1.1648321052639572,81.44091925543053,43.00953947090371 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark07(-1.291456212846843,-1.4967529794316592,-158.47363961463194,57.073687091858815 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark07(-1.293964111705172,-0.19891365644686856,-0.1384161075456447,0.8848549916208825 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark07(1.3009528990649657,3.4707207759114986,-19.651627304296593,57.16966931645412 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark07(-1.3059584164856077,-1.0524904473290446,0.6529792082428039,-1.0375572263530302 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark07(-13.29078968463682,-26.364208419836505,0,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark07(1.3311166250658615,3.3411124978787914,-1.3219517764761721,-19.7338498347884 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark07(-13.353070861303502,-25.13534539581211,-25.021853106007132,-99.99983923869779 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark07(1.3459952156680177,3.9450326807170493,0.11240055556343904,-23.16479565722933 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark07(-1.3500311979441904E-13,-2.6645352591003757E-13,0.7853981633975158,-100.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark07(-13.61497534753471,-24.480922048185462,0,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark07(-13.629174079714454,-0.5182339392053524,-100.0,-100.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark07(-13.631373126535705,-0.5235987755982983,-100.0,-1353.0928172415581 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark07(-1.3721626655633428,-1.1735290043317894,90.95118515457551,26.486100289061792 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark07(-1.3803954908871923,-1.1923652384926064,-13.53506373203876,1.3815807826437516 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark07(-13.872919499592712,-26.175042672390532,100.0,13.087521336195266 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark07(-1.3873311640955226,-8.326672684688674E-17,8.11869882011456,85.68677046519515 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark07(-1.3877787807814457E-17,-6.938893903907228E-18,-6.214174888979185,74.7864979230205 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark07(-13.987829032809529,-26.40486173882416,0,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark07(-1.4042309221042053,-0.20555392301800038,-45.09361323204738,100.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark07(-1.4058641657024444,-1.255272488671139,1.0076780139145043,-1.4431600787063679 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark07(-1.4072928807076093,-2.7686008933732724,1.4775483867407653,1.3843004466866362 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark07(-14.086448341936043,-26.620360807336912,-14.787580236158846,-66.80043224267119 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark07(-1.4210854715202004E-14,-7.105427357601002E-15,-0.7853981633974412,-51.846222891597705 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark07(-1.463705508579178,-1.3580332454347677,0.731852754289589,46.22410844398309 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark07(14.794669969582912,67.0919119742137,-15.494440383994473,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark07(1.481020874708457,-2.518510235416353E-14,-26.63624115619825,-61.975592763923224 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark07(-1.4883414035942344,-1.4058864803935724,1.5295688651945654,100.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark07(-1.491479375342203,-0.5235987755982989,0.6332632298847348,18.050742836777758 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark07(1.4983693735610513,2.9967388325912196,-38.34322425994604,-1.4980882620806348 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark07(14.992668962151559,-8.673617379884035E-19,53.76472229140918,97.92680843420885 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark07(-15.063041606935926,-9.991342982236603,94.02302815108459,-22.617361737680582 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark07(1.507896941352734,3.6149575938733354,-16.364016121721974,-54.433958263414546 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark07(-15.081016419625685,-17.799426039613074,-32.52035601343356,100.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark07(1.5266101586352183,3.054634850858325,-0.7633050793176092,-57.08910329528224 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark07(-1.5292717996132784E-4,-1.546277142873876E-13,-38.33866062606002,2058.3401402745153 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark07(1.5392854245234808,3.3956842366184334,-29.631359142166495,43.06985319534767 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark07(15.416346806170234,32.3868418826412,-7.386194584326355,6.57262290719863 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark07(-15.441093108024102,-29.31138988925331,8.53781360597115,14.623434361339944 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark07(-1.5563302399145258,-1.577704543118595,-45.23966702100116,71.48193805764708 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark07(-1.5621103220332557,-0.5235987755982987,-100.0,-93.0939733206364 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark07(-1.5744983769204173,-0.523590445316265,85.07222213828051,-0.5236029407393158 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark07(-15.863603649435575,-31.603628836993593,100.0,15.801814418496797 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark07(15.870718106466377,-1.4210854715202004E-14,-15.81584854301018,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark07(-1.611098716200992,-2.4116171858479043,-87.79453385570764,58.539874236562376 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark07(1.6200310439193737,2.7911647434544102,-66.8435507885162,-0.610184208329753 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark07(-1.6379878906910144,-3.236856806182005,-36.153514173087096,-0.7211444648543247 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark07(-1.646819653295939E-4,-3.2040851733569463E-4,-99.0077801530644,-69.53110088684731 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark07(1.647322485233736,3.2946507871679227,-0.03826307921941974,72.19452153443191 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark07(-1.6490180995800667,-1.7272398723652371,0.03911088639258509,0.07822177278517017 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark07(-1.6535770671874745,-2.3072620060459226,-148.9569426027713,-93.88051182774336 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark07(-1.6639564617950597,-0.424182634186474,18.096572597877092,100.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark07(-1.6711281487916871,-1.7716950018172601,-52.31677030167163,65.05668015615663 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark07(-1.677022203129357,-0.5235987755982965,-3.213480087509211,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark07(1.6779518269198377,3.8696277387065554,-44.060870587697615,-1.9348138692255625 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark07(-1.6789459612516384,-2.8909667367132763,0.08388979006744862,-25.2580542247099 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark07(1.681317049654498,4.86123131387762,-0.17649310453690248,-2.430568579458181 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark07(-1.695191410332723,-2.5652590158646302,1.1030181145119389,37.465815667931636 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark07(-1.6999338388313753E-5,-4.440892098500626E-16,8.499669194156876E-6,-0.7853981633974481 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark07(17.17530497340957,35.85357805802371,-8.565833860725368,-14.006395968751697 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark07(-1.7208456881689926E-15,-3.381609698692386E-15,-0.7853981633974474,52.38465768175017 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark07(1.7276838741213956,4.810012239320831,-0.8709412203785104,-2.405008262750549 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark07(-1.7441195860420606,-1.9174428452892291,0.08666162962358182,0.9587214226446146 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark07(-1.7684621539151473E-18,-3.5369243078302845E-18,-18.390548149091238,352.7037748235589 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark07(-1.7745019325530815,-2.0216827574787377,0.8980915997187195,1.0108413752814167 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark07(-17.748513335103148,-0.10642414247952783,1.6590287576204332,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark07(1.776078698392642,3.5535410712439486,-0.22793025745782905,-65.13381988049524 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark07(-1.7763568394002505E-15,-3.5527136788005005E-15,0.7853981633974492,-1875.3622527505338 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark07(1.7806869857935652,4.80973482403662,-79.1843303327793,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark07(-1.7840179661478552,-3.251000187565542,0.20279404552188804,-56.49396331632744 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark07(-1.795732395402404,-2.0323314771941527,-100.0,-4.475970202575171 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark07(-1.8058895666735495,-2.040983145390237,-24.28042002420002,-91.75969375797841 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark07(1.8064638205757007,4.831288396853338,2128.456291769788,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark07(-1.8164605832566667E-14,-1.17837178801329E-15,99.99999999999993,-37.07688272960262 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark07(1.8361296758037131,-6.071532165918825E-18,-19.48222234071603,1.1814957566833244 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark07(18.37869710710281,-5.081001243886681E-14,-1.956596684053725,-5.721756488264124E-5 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark07(1.8422361007652697,4.809907480033679,-0.9211180503826455,-49.9501848127462 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark07(1.8435247860440054,-5.551115123125783E-17,-139.8565131390053,56.815097764975235 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark07(-1.855647957709627,-2.261912480600847,0.1424258154573652,70.24794772306964 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark07(-1.8802067680988127E-14,-4.440892098500626E-16,100.0,2.220446049250314E-16 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark07(-1.8867492618370942,-0.5235987755982987,48.63578402707144,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark07(1.9262684440837676,4.395635387159349,72.91448630393774,7.7269602649311055 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark07(-1.9443400747106925,-2.3605930838133493,1.2806610780129986,-25.52322383430934 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark07(19.594562969981617,40.166397616900184,-30.762937397713053,-20.083198808450092 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark07(-1.9639455897913332,-0.5235987755982983,-14.726011764283685,-100.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark07(-1.9721522630525295E-31,-2.0434663397513514E-31,-4.484943742698995,-0.5727427649948957 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark07(19.789088234780294,40.655760533728085,-10.679942280787596,-22.398669749053465 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark07(-2.007283228522283E-13,-4.008690217246399E-13,-82.18143742909875,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark07(-20.348253953426315,-0.00573548373807116,17.389820445405523,0.0028677418690355727 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark07(-20.426872864223455,-39.28294940165202,0,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark07(-2.052866300136054,-3.958942967560122,-8.23848719128066,-47.49070678068056 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark07(20.606816014828503,-14.89308810620683,29.072864650975077,49.57596081912513 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark07(2.0609555863407425,-0.2234624153285637,65.79332721099536,6.5759124217471125 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark07(-2.071003832414621,-2.60352446945261,0.5706498374049083,-158.09930991056876 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark07(-21.056193693406698,-36.213355789774894,25.69858859705721,39.46606835617098 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark07(-2.1198112709619465E-12,-4.239619141511051E-12,1.0599056354809733E-12,-76.73731370025888 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark07(-2.1321831278119916,-3.2130627294007583,0.2806934005085475,2.3877138626570877 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark07(-21.36182567382268,-33.398372343837465,1.0274193202332924,-86.1221506486054 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark07(-2.1371416495778846,-2.703935747106508,31.632270004546537,-99.98694085455794 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark07(2.1630178527835664,-8.116377882033248E-15,-99.9999999999991,0.7853981633974527 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark07(-2.1658539050436887,-5.176083443885236,49.7793082113857,21.430995659198256 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark07(-2.189003278145134,-3.095877667086161,-38.184784049204964,-45.591954395987244 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark07(-2.19000363207239,-4.342083414699716,0.3096036526387467,18.663668670964952 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark07(-2.1926904736346842E-14,-4.3798298321462426E-14,-0.6793493097941508,54.24502025046538 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark07(-2.197427778756717,-2.8249156145695924,138.13909859019725,-125.9850424159532 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark07(-2.208643129614179E-4,-1.838327846592466E-4,77.23440940224911,9.191639232962321E-5 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark07(-22.12866697361279,-44.23437707040493,-79.74252626008324,22.117188535202466 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark07(-22.130298221095977,-43.939943219477605,180.6423683682944,-33.79329799561779 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark07(-2.220446049250313E-16,-4.930380657631324E-32,1.1102230246251565E-16,-38.63425377800555 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark07(2.2207866990155978,4.455508000317166,16.793692257813554,100.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark07(-2.230993167984252E-12,-4.4618184446253435E-12,1.115496583992126E-12,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark07(-22.32318245433516,-44.64636490867032,0,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark07(-22.41326966676172,-33.69199959846169,0,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark07(-2.254539351210842,-2.9943048102223946,-51.380581686060935,2.2855521705063215 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark07(2.2553754223271207,6.005619928499182,-61.20605780831086,3.2803749599909864 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark07(2.2607454826257394,4.52149096525148,-1.6478113576091526,-47.148912180954895 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark07(-2.263629098875989,-0.5235987755982987,71.81762697491064,-27.354054406332004 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark07(-2.291352631059948,-3.0166425214516477,78.77174463082821,9.973827516436529 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark07(23.499664994408818,-1.3877787807814457E-17,-17.106124695334596,0.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark07(-2.362149442091692,-0.028644223482559746,-67.14856893221702,0.7997202709320366 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark07(2.3811230879534833,59.91555767995564,33.47743868393539,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark07(-2.4031439805033283,-3.2354916342117632,13.381692528830563,-25.34321822462657 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark07(2.4080112920272088,5.571355307365164,-100.0,60.12320422792809 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark07(2.4153543484945033,4.831117543988681,-88.66326684620962,-93.4927760130538 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark07(-24.15515732256415,-46.73951831833385,0,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark07(-2.4336979757383284,-0.5228146276683453,-199.84669857587937,18.753984809773232 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark07(-24.3923874485648,-47.25152570455533,-21.177871344248064,-78.47599632501816 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark07(2.441949630210978,4.889264063341781,-0.4355766517080409,-2.439064429370484 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark07(2.4688177928673096,6.200111204184975,-2.0185609717385535,-5.449851010798057 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark07(-2.495781359357352E-13,-4.991504157257578E-13,-0.09282516867091964,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark07(2.504003031297106,5.045392502341647,73.00945991052055,-215.91097934903112 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark07(-2.505324559366769E-4,-2.6853316000190707E-4,-7.851689737380507,-38.74054522433627 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark07(-2.532170638063641,-3.498472726338152,0.48068715563437225,99.92400674620824 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark07(25.475098406495363,-10.465648912036045,39.28757041727556,96.1600061714069 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark07(25.56501840255541,-59.26171234474602,22.61992981468886,-35.80693172075556 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark07(-2600.729372728056,100.0,0,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark07(-2.6084112705498113,-3.957075874682652,1.1534456496711119,7.1909232416585045 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark07(2.625227704557974,-8.881784197001252E-16,-0.07165620446743813,0.644463373921748 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark07(-2.6423876420267334E-9,-5.284770989721709E-9,17.468521702673165,-22.81016566171887 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark07(-2.64959003194892,-5.185133203447531,1.2826867989247408,2.5925666017237656 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark07(-2675.019728703345,67.67119097177331,0,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark07(-2.6755682116421244,-4.285470373855248,0.5523859424236122,72.97988153912623 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark07(-2.683577651077181,-0.5232816248604262,-77.19844414632114,-24.595230294335984 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark07(26.900974040117134,22.176933013946893,67.33038391954716,-18.50372416723883 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark07(27.131286756048638,-90.52977590031813,0,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark07(-2.7224224396389767,-3.874048552490714,99.99999999998111,92.0927971284324 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark07(-2.7361022131301214,-4.5999329676114975,0.5826529431676124,90.21759554327976 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark07(2.775531767907418,7.03326779656883,-2.1731640473511575,-5.866624098581414 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark07(-2.7755575615628914E-17,-3.944304526105059E-31,16.78896079708332,26.1183080855117 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark07(-2.775639951373946,-0.3391386572295147,-47.3704423748364,-83.39206467968965 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark07(-2.7786721119451983,-43.970826129713856,69.65566386339907,76.26352731769614 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark07(-2.806000385465168,-5.187665819728026,2.0657764514148482,6.516693867189268 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark07(-2.81419440817304,-5.092433132524854,0.6216990406890716,16.683362159601497 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark07(-2.8262004128844787,-0.5235987755982987,2.1984983698396876,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark07(-2.8633758596322094,-4.54178602775849,-76.16901221085911,2.2708930138792445 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark07(-2.864545695689533,-4.203522608411653,-38.27268375964482,-100.0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark07(28.936168012089922,-38.840746609658595,31.209867995162853,-77.68810865158105 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark07(-2.9531208762456886,-3.1738331909815076,-85.01271370550427,-51.03812587137026 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark07(-2.9731649023527353,-10.347316111486322,97.44430430551705,11.884878439047085 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark07(2.987359381381814,6.016401187592925,97.46862223350739,-7.720589237104971 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark07(29.96090446840219,-31.639183408462017,75.89293905621437,7.274248610570851 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark07(-3.0052106177417404,-0.5209156710418146,-37.773797188691915,1.047301174556912 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark07(3.018449878850639,6.079576180076532,-13.175304029064847,-94.1459704003876 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark07(-3.0387373580086536,-4.50667874312889,0.7300868925719344,-141.4692073365988 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark07(-3.068810382330133,-6.0050072268574,16.160442244120308,62.687501084654535 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark07(-31.073750299809817,36.227848240649564,0,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark07(31.223729046484817,62.45507061854093,63.78658616052393,-31.227535309270465 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark07(3.2296348932305166,-4.6147656009021265E-14,-2.400215610012707,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark07(-3.2424974266635473,-6.329249932759296,0,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark07(-32.50146382778189,50.88580382612841,-56.00329266201527,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark07(-3.2576745389533643,-6.515349077906728,2.120839657463116,15.82404389416576 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark07(-3.2719140910659337,-0.5235987755385743,-29.244572629191428,0.2617993877991722 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark07(-3.290942227246463E-5,-6.581884454491172E-5,-0.6157877298155126,-13.334257363616528 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark07(-3.319384211941667E-10,-6.638767677984171E-10,1.6596923835265898E-10,3.319383838992166E-10 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark07(-3.344546861683284E-15,-6.678694190174975E-15,-69.8761016549383,3.3393470950874877E-15 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark07(33.55998005942396,68.6907564456428,0,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark07(-3.3625436529928754,-6.671958544152124,2.25751706891207,13.260756890301927 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark07(-3.405269249159329,-1.6715428629508295,-28.93943714518759,1.621169594872864 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark07(-3.435513302545822,-0.5235987755982987,98.32086572430089,-0.6223338988674457 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark07(3.4605141858242945,14.091362104549802,8.758061248358544,-40.97786280135058 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark07(3.5028223897918793,8.27162278052918,82.28492050254086,142.7337094727018 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark07(35.053459538580775,70.14363009215346,50.411318969334246,-6.79748116746606 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark07(35.197412613016624,-0.0013660632163277314,-10.38410446035298,6.830316081638532E-4 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark07(-3.528033957341262,-6.094971889441545,1.764016978670631,-20.51445891039228 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark07(-3.5297965146809247,6.5641797771989445,-42.87693807049104,-13.37319726770518 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark07(35.454635062018355,72.4800664508316,-55.41078003227102,-36.2400332254158 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark07(-3.564826435525642E-13,-7.129201064125188E-13,0.7853981633976257,-1.347705784457606 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark07(-3.5714232249911836E-4,-1.7976768205303957E-11,1.7857116124941896E-4,0.7853981634064368 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark07(3.5785976859030115,7.157195375054682,-1.0039006795540575,-93.17107237839924 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark07(36.18653539451108,4.913052816321674,-10.87866579491375,-2.456526408160837 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark07(-36.79532742839815,-22.4714247407761,0,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark07(3.7234745270648943,7.676626941318424,-242.92747109841298,-3.2303927839467064 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark07(-3.727672517714374E-11,-1.209448380152721E-13,0.7853963345198842,131.99802064860435 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark07(-3.7707376567073E-4,-3.7009129441242566E-5,0.37907411546558456,97.86594638736184 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark07(3.7805306439396844,7.619324295051058,100.0,27.60626438837241 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark07(-3.8315731004331903,-7.210679596686514,-1.9758667472278195,-32.52882499009044 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark07(-3.8769206306876353E-13,-3.6698088006873925E-13,-0.586340935173228,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark07(3.911109574995018,-5.551115123125783E-17,-20.517332069347987,0.17741882302517845 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark07(-39.258765004992036,79.5999624611749,-59.62286410509314,37.79427382965116 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark07(3.9481152668139017,8.767758563411181,-2.759455796804399,-3.5984282234801834 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark07(3.9717964023545886,-7.888609052210118E-30,-1.2005000377798458,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark07(-3.9851561893137704,-7.941199978794738,60.21342381612418,4.7573492638074155 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark07(39.97085407493515,-11.293765034033925,-40.90878341593365,-38.25716821796134 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark07(4.009617995826889,8.019240738945104,100.0,-0.5463063918925558 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark07(-4.012822390115941,-0.5235987755982987,-38.385018231813696,-68.85466012893562 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark07(40.29010060228323,81.70290045679037,-19.36038182171525,-46.341439680904976 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark07(-4.037918046581193E-6,-6.164367353257327E-7,-49.43005509383482,3.0821836766286633E-7 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark07(4.049691172617827,38.113455661172026,0,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark07(-40.91446122183902,73.3620863274183,11.266759749445015,90.8858580815265 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark07(41.175175541338575,-15.748022365651465,-35.13898136377631,-14.903712147423477 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark07(-41.23789263038692,-80.90498893397896,0,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark07(-4.157411696581579,-0.5235987755982983,-76.57720885048982,0.2617993877991509 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark07(41.62796656674071,84.81126318983067,-20.028585119972906,-39.320626610754246 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark07(4.165078847462536,8.9489288878096,-57.753476901309945,-94.79457441168039 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark07(-42.05390065581065,-42.084074227651925,0,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark07(42.091490764434326,84.81656605688076,-20.43771058550214,44.989027903552895 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark07(4.219647112835533,9.827235370071056,-78.98735401346845,61.90778634593042 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark07(-4.237902908455624,-0.044630536292349136,0.3451753536565092,-117.78486649928746 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark07(-4.2558017295741965E-15,-3.2546241020206633E-15,2.1279008647870982E-15,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark07(-4.343815594549441,-0.5235987755982987,39.08562037159864,-97.42108806596255 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark07(-4.345264426053319E-10,-8.690527856046539E-10,-0.23198703177325436,1.4501489715756009 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark07(-43.69024706742406,41.198208512815,94.53470438844815,46.52240710535523 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark07(4.381175486318436,9.963116257348728,-2.9020951682615674,-96.08570527142683 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark07(4.390453189578269,9.004818303400674,-34.23005897057334,-4.502409151700337 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark07(-44.36187458000469,-63.75044270169412,-1.5862099650065318,-86.80787958241103 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark07(-4.440892098500626E-16,-4.440892098500626E-16,2.0895542011887605,0.07740488197543982 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark07(-4.440892098500626E-16,-4.593814036176984E-16,0.6699096059281973,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark07(-4.440892098500626E-16,-6.768222249118846E-16,2.220446049250313E-16,84.04969089606298 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark07(4.492210604037895,4.164717580414134,-3.031503465416396,22.04649055266551 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark07(4.517802840963569,96.44232234572851,90.34341802499233,-66.62872908045934 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark07(-4.538309232942342E-13,-8.690305685082678E-17,-48.079849445012215,100.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark07(4.538368179265863,10.214347897171956,-51.921091003374094,5.132863762224503 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark07(-4.5407066125086795,-5.978360634322378,-37.79049992286875,-98.3346436197326 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark07(-4.605343945318791,-6.354197074934018,3.053312131159666,53.88239100428428 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark07(-4.619728226666486,-7.668660126538075,4.706177187890274,-14.146627950743488 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark07(-4.621350003793121E-18,-3.0814879110195774E-33,-0.7853981633974487,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark07(-46.32050246433956,-91.07020860188423,0,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark07(4.671511115610842,9.343022232813649,-2.335755557805421,79.53037458915553 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark07(-4.696295180936802,-8.136243317438982,1.7262425547465303,4.068121658719491 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark07(-4.709968121311064,-32.649831058087585,88.94807440593752,21.067138052169128 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark07(-4.726967550965802,-0.5235987755982987,56.55466651190271,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark07(4.732839117980702,10.613534053184848,-99.99269017196916,-23.361611578590974 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark07(4.733771759573218,3.689316061446638,-84.04767265054075,-92.94255532953267 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark07(-47.355467220691395,-56.41206600815725,-64.01891858736988,0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark07(-47.72039475159641,-93.86999317639793,0,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark07(-4.8158072750367085,-9.597677769251245,2.6337794171977604,-6.979743320241451 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark07(-4.82103246213228E-12,-9.640229426715158E-12,-75.81718979488905,-9.153486424866536 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark07(48.2497074382337,98.07021120326229,0,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark07(4.84969251713558,9.699395110858784,-102.00647699893584,254.14081457816968 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark07(48.615646506824845,40.11385540132551,17.185210575864488,92.50324405884669 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark07(-48.844934403738534,-96.11907248068218,0,0 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark07(-4.890539458856922,-0.13797368526829012,5.708080195248347,-84.1764686157568 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark07(-4.896528061487659E-16,-9.792815750021018E-16,0.7852279010410194,0.7853981633974487 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark07(-4.9465786429576457E-14,-8.881784197001252E-16,0.785398163397445,-136.67726685298177 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark07(-4.966216388762794E-4,-8.881784197001252E-16,-0.7851498525780102,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark07(-4.976955426764217,-2.43855104035831,2.700618492202154,-9.23079581134354 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark07(-50.546235474444664,-101.09247094850552,0,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark07(-5.128489002599271,-0.5220220021870886,130.58392576882815,0.2617993877991496 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark07(5.182081336180022,8.801265259102047,-197.34355580227867,31.727736984559215 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark07(5.200361014465335,-3.281661365719409E-28,-1.385571200210242,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark07(53.22982739942941,-18.0796237935306,-6.155070575686963,12.655608956822533 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark07(-53.483435034016345,-0.5235987755982985,19.527111973046736,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark07(5.470036819624425,11.215938429094072,-2.7291368181434716,-65.29822923295269 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark07(54.73538886430126,24.00411380692556,-84.15914291636801,52.56320112060939 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark07(-5.551115123125783E-17,-9.442564829413299E-17,0,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark07(-5.573701871650611E-17,-2.465190328815662E-32,-80.48223557354402,-100.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark07(-5.61605972516401,-9.661323123921566,2.808029862582005,-37.58238952566664 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark07(-5.692451795957202E-13,-1.13849035912455E-12,2.846225897978601E-13,-68.33091539454311 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark07(-56.983895126709584,-25.479199454642853,60.996412665853285,43.29628782664025 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark07(5.7105103209718315,11.421020655805998,-3.640653323883364,-51.235306234878024 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark07(-5.724587470723463E-17,-1.1329938161475903E-16,2.862293735361732E-17,-90.64193220123262 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark07(-57.83245656312461,-70.11024466277003,87.41529621423035,87.34269159622602 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark07(5.795525189666007,1.0851756136521118,199.20762565613222,0.24281035657139663 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark07(-5.8369468754326865,-11.664934683945859,3.7038716011137915,5.832467341972929 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark07(-5.852273237559894E-5,-7.890597606048678E-13,2.926136618779947E-5,67.47473847509735 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark07(-5.88418203051333E-15,-1.175990263336464E-14,2.942091015256665E-15,-20.280926159085446 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark07(-5.960513703573388,-9.280498154635913,-111.0612300129554,32.8532229641653 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark07(-59.6436186657882,-46.680126714717105,-90.69689394768173,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark07(6.002718678172166,13.315980934615173,52.498678593346945,-81.2707406595634 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark07(-6.035891332610009,-10.970199895846077,2.908856136311942,-0.8137103711447082 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark07(-6.039613253960852E-14,-1.204170891757246E-13,-77.27984306002061,-25.005635387847036 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark07(-6.140608631926381E-4,-3.099483480145784E-4,4.0633025093548923E-4,1.5497417400728918E-4 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark07(-62.0854664366074,27.72458773549542,-75.68523398106062,49.55960316696215 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark07(-6.215824688976938E-10,-2.0022830590222687E-10,0.4878738794481797,51.16162360304963 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark07(-6.266310742855303,-12.111989227974972,3.480601335523217,97.16213628987093 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark07(-6.282786533897491E-6,-2.220446049250313E-16,109.15643033596753,-38.43362439458184 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark07(-6.364017804299531E-9,-5.551115123125783E-17,0.0056920930221705385,31.055980211283718 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark07(6.396903592062046,-21.725202863578147,21.010486437548124,22.44706940337278 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark07(-64.36041213255766,-97.80850519191983,26.146670944147047,-34.653210093643125 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark07(64.39971983832338,-0.0015953207342317374,-24.985238378645374,100.0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark07(65.10309122240619,-57.68385516405421,-3.3414949522539956,-46.584981937437256 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark07(-6.519427796310264,-0.5235987755982987,-89.41810488653279,0.2617993877991227 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark07(6.542864776512471,13.91373983045035,-52.9741536436331,-21.093936968984966 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark07(-6.549052633189833E-8,-1.0851692938017067E-7,-66.71650632250721,100.0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark07(65.6988472463861,94.71305831489309,50.03892327935799,-98.45248533953085 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark07(6.578176222286669,13.595175064493828,-45.64237558637254,27.759904044125104 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark07(-6.617882189092093,-0.5235987755982986,99.85479824891993,0.2617993877991512 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark07(66.6311865324422,70.20283147183031,6.777623190533049,68.82913869014021 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark07(6.6866424148656725,13.494567025467864,-4.128719370830284,31.737226528837557 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark07(66.97887836551607,4.827718876170479,-26.274837346127345,-2.4138594380852396 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark07(-6.737015133983977,-12.417424893344839,3.3685075669919886,-67.61871346777578 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark07(-6.761258219967203E-14,-1.3500311979441904E-13,-53.58603462252852,44.906645283394425 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark07(6.768671977939217,13.537343955878432,0,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark07(-67.90960974060681,-69.60166909451158,13.437988104016483,-14.21242628327353 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark07(-6.809047258736007,-8.612041148314942,-141.60957471682528,32.53059655619005 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark07(-6.82797869523597,35.41712048133425,-46.566993893678465,63.47075532384429 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark07(-6.892206827695035E-11,-2.643042832821082E-11,9.759811357890788E-11,48.361799849914476 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark07(-69.34025665969799,90.41138184494432,72.37313390180162,91.64371062841988 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark07(-6.977428066869962E-4,-0.013508302643629238,-33.624983512982,0.0067541513218146165 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark07(-70.11107248696133,52.25745155532482,0,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark07(7.060430922495377,14.120861844990756,0,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark07(-71.00911795387863,82.83632281988588,-14.052594434622634,-17.68370245126995 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark07(-7.105427357601002E-15,-1.1102230246251565E-15,36.54133826925528,21.334827826777783 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark07(71.50595993448081,70.39006643110085,14.124037876053592,-95.95145504041156 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark07(7.200275569701151,14.426712007065303,35.68155161248167,-34.98768986644842 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark07(72.75991744664415,94.15505744280654,26.008710853014932,-99.83207835809526 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark07(72.96195919195853,67.19199230305708,-93.09031240179752,-8.45830076675989 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark07(-73.02252213790595,-14.476128350819621,-29.3868155219093,-50.51624632878264 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark07(73.21552451388632,42.376476969145614,94.56409549226055,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark07(-7.405487628448042,-14.25694696839881,4.488436311163911,21.265097793265003 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark07(7.432746926427993,-1.3877787807814457E-17,-40.58769770915338,100.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark07(-7.458826684209306,-13.34689086361415,100.0,4.3310799046562005 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark07(-75.0145520607472,-4.04322350427195,83.54722888237086,-80.30429076318978 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark07(7.576687774044272,15.333420796356577,-3.505379200394427,30.81779960829813 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark07(7.597595612420297,16.76598755163549,-3.9857799270756025,36.387149071918934 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark07(7.651047309688976,15.305448687061023,76.78075937404891,-6.867326180133063 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark07(7.654207565041872,27.193648111655236,1.3796255933836505,23.469566244842312 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark07(-77.70287057158119,65.98777732926422,88.90243378717273,-79.24955756270238 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark07(-7.813858449168265E-10,-1.5627716825934052E-9,-90.3203828764202,-0.785347776771655 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark07(78.21500648480614,-82.43297589403093,-98.40556083728482,-67.09268339945712 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark07(-78.23523142269116,45.56813386800172,-79.060952894102,17.68165972159521 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark07(-7.826249265627386,-14.105578758993095,3.913124632813693,6.2673912160990985 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark07(7.9239491824828026,15.847987027795806,-38.789922606064394,-81.74250951557828 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark07(-80.06016192378074,-79.82206334173836,-74.72290598978455,-52.55308601777819 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark07(8.098556355025066,9.836391272492492,-60.297937546089436,96.39818051747963 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark07(-8.111531735849848E-11,-3.292525618606401E-11,47.068820803339314,-0.7853981633809857 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark07(-8.136149383741188,-16.272298767482372,-11.287991084485862,22.27334711843341 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark07(81.5993244108752,74.21523793583557,95.54780618360587,66.31844790607781 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark07(-8.16893603239628,-14.83262371863518,4.869866179595588,-10.64730059956592 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark07(-82.27444858211857,-7.32555118785001,0,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark07(-8.288154039235968E-4,-1.4241836621519597E-11,-0.7849837556954865,7.120914968794523E-12 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark07(83.70362453158933,55.004344806193586,0,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark07(-84.63930868640676,-66.86884490220437,-81.36404627600156,-25.540226842413176 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark07(-84.71676379064715,47.448972765143424,-53.77623306312324,95.65471154627153 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark07(8.507176749303563,-2.185990321217246E-28,-26.50595474052073,-5.0487097934144756E-29 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark07(8.515101087508844,17.894181028202084,-3.472152380356974,-8.161692350703593 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark07(85.58151147364768,71.59818160793861,11.559029480414765,-27.535783784277925 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark07(-8.62024917686577,-27.988660724653982,-76.90311528746324,-22.603904521975537 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark07(88.36331529035905,20.431430434813237,-17.505393111653092,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark07(-8.881784197001252E-16,-1.6653345369377348E-15,0,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark07(-8.881784197001252E-16,-1.9721522630525295E-31,4.440892098500626E-16,100.0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark07(-8.881784197001252E-16,-8.881784197001252E-16,45.91413460225783,16.21261052028501 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark07(-8.90849977772784,-16.96474229140676,-17.993267406389563,22.61953808516902 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark07(8.915572669175667,19.06745762921382,-4.4577863345878335,-9.53372881460691 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark07(-89.21910738506729,57.5184504673648,0,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark07(-8.937438984275247E-5,-1.1653962201031874E-5,-49.50208159215482,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark07(9.01537873634156,19.39101290816821,-62.964063293524134,-9.695506454014364 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark07(9.032481719248622,19.63575976529214,100.0,-9.81787988264607 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark07(9.06347551841842,18.321296682979206,-5.09061229896934,46.62943050947052 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark07(-92.05240265938357,24.900642342668974,4.016691060679037,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark07(-9.292841542493736E-10,-3.755285387677119E-10,-7.773685070860661,-0.7853981632096839 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark07(-9.49995637711254E-11,-1.8998922253712695E-10,1.2761610829794279,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark07(-96.13878949752855,31.030328071058335,29.437524042209816,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark07(-9.616570849037544E-15,-3.1554436208840472E-30,-97.96887412030958,99.99999999999999 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark07(-98.10001593596857,-33.82823336735383,0,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark07(-98.56110587996032,25.48048805753662,-14.070741130948178,26.397665490597234 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark07(9.872424351390963,-1.1102230246251565E-16,-27.677360265937537,53.668463376510694 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark07(98.85943972033823,-52.90095013513878,36.69378872829523,-27.83990149041277 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark07(-9.943994178893203E-13,-6.224665622395896E-13,-0.7853981633969511,-0.20257447681915466 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark07(99.94516467669858,-3.1554436208840472E-30,-42.75798050174528,0 ) ;
  }
}
