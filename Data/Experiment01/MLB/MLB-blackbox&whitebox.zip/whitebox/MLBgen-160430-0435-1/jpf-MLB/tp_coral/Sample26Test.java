import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-0.0014055413141653775,97.11042522745501,100.0,-2.262048886796194,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(0.0016688410247253285,-7.626970293857264,-21.03703757678945,-4.592108088869449,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(-0.002812458364466558,20.84734752962827,11.841223199586643,-37.84534978972793,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(0.002816558310630414,-202.6572718621485,0,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-0.0034847682849704466,85.15316576889995,161.39414545264174,17.962957730258594,-170.30252782358207 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-0.00489027667870576,8.32512557037142,8.89443788189671,-19.759797939834517,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(0.005279123298163181,-65.10192134118853,-297.54870805974525,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(0.006329989641556991,77.39999245712042,-14.75247239374508,-5.857460008129871,-154.80002106567855 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(-0.00721704182100924,2.9602744823095914,2.7000228037777987,72.62228826352793,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(0.007406501268936494,-1.4210854715202004E-14,-31.49371725818456,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark26(-0.007692840693074424,26.569676204116675,7.631965401386726,-95.4206222022657,-53.13935240823335 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark26(-0.011334639056110075,-0.13915273842442633,11.071739417073502,-121.91248800992426,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark26(0.011701986613518622,42.60989942429201,-17.13402121778061,-100.0,-75.6037211488916 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark26(0.011940141560058359,-42.45320840096966,-46.51239974137631,-51.994840357052404,99.95223357959577 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark26(0.012412116022451306,-8.297131537071007,-15.255989041748009,-63.82019411256769,-62.749411151555705 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark26(0.015012881993138785,-14.140184603944427,-9.71882734183989,-92.52480563759175,100.0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark26(-0.015547845596845406,36.71217685188096,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark26(0.016918922798273322,56.812406369946714,-6.661037279109728,28.136177106807168,-135.3863064216643 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark26(0.017328034439076795,52.464557390191096,-2.1962345001260712,1.3613316544192742,-173.66600349239462 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark26(0.020123566660253243,-2.410790743435041,-1.4210854715202004E-14,-2122.1052273944533,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark26(-0.020682800929549217,3.268496584496461E-13,0,0,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark26(-0.021005058485757386,1.9300542223555084,9.859294736070368,-88.65118027011208,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark26(0.02264940719820885,-20.934593117879512,-25.71468799287149,-56.8043600851943,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark26(-0.02278549048828077,12.80095678741381,68.93844692973929,0,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark26(-0.022818093473219392,3.5436923255461306,42.43768372016466,0,0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark26(0.025877935273749986,-3.552713678800501E-15,46.77903763225766,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark26(0.026003774585248607,-4.504863916129054,-8.308601900209997,-69.9595324563845,9.009727832258108 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark26(0.027488756683972992,-57.14322931566896,0,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark26(-0.027835926588345796,3.164069010908049,51.0723464780512,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark26(-0.02893748044403921,16.72490605423988,14.950534816256056,-31.485165683834992,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark26(-0.030142359441042044,0.03442515717813086,20.153424477962137,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark26(-0.03101236020325611,-86.20189431798921,0.6805836386550265,-99.61599490772944,205.8107735340381 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark26(-0.03138811017736187,5.815163642983779,50.0443103429592,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark26(-0.03341302048971545,2.8421709430404007E-14,4.482549152824248,-100.0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark26(-0.043573692653516835,13.093599269025049,2031.3088264294101,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark26(0.0628843416219875,-0.27852909821145444,-1.7408297026122455E-13,-100.0,-13.577700692090238 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark26(0.06668030181438706,5.60430538356934,-8.739675649849232E-13,-87.79774394439623,-11.20861076713868 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark26(-0.08413504013388862,8.631616506776147E-4,19.265851776833603,0,0 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark26(-0.08510353248425283,1.3800891477269939,0.03436573836309923,-64.99112918937732,100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark26(-0.09160219519693247,6.223529679749319,0,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark26(0.10092014369247693,-1.4210854715202004E-14,-13.037328332956378,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark26(-0.13822923311844942,-3.661074877232071,0.004544858000758953,-85.83541194847672,7.322149754464142 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark26(0.3065661055583533,47.95710711085543,-1.7763568394002505E-15,-182.71992843235407,1797.088645814232 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark26(0.3329767682787564,-0.9923829169848908,-0.3369612045749264,-11.747526655307432,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark26(0.3586081413821489,-5.897504706808832E-13,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark26(0.6153195491415744,-1.4210854715202004E-14,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark26(0.7281976008219582,-2.157101760596092,0,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark26(1.0172743457034689E-7,-45.568042560735506,14.223702390159394,-100.0,-81.92160179389927 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark26(-1.0390664058896752E-14,17.960530989414078,10.652365628866376,-60.78313845670273,-35.9210619788282 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark26(1.0408340855860843E-17,34.67438177080557,-6.520598489896452,-57.59349924738018,-69.34876354161113 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark26(-1.0658141036401503E-14,13.363069669776642,4.508302092198377,-23.81949620012027,-26.726139339553285 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark26(10.747085735280798,-2.7755575615628914E-17,-2.7755575615628914E-17,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark26(-1.1102230246251565E-16,42.95919672744509,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark26(1.1497737629345194E-15,17.891086331868706,-12.808695502398649,-75.28873601208655,-173.72979300465022 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark26(-1.1501212885853036,0.27018241419435185,0.15979800694715712,-5.143660463868173,-14.975315352952023 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark26(11.804426086539621,-5.329070518200751E-15,-0.1330684198688843,0,0 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark26(1257.5785579077742,-1417.3562048178153,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark26(-1.2789769243681803E-13,91.86534066926333,9.398304638686497,-29.066265278880323,1869.6588160514523 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark26(1.2859923854574978E-17,-5.701802715231735,-1.819110603483315E-180,0,0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark26(-1296.8444076559272,1378.4423654189109,0,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark26(-129.82197321336983,0.004394300018222757,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark26(-13.12499968420751,0.0,0,0,0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark26(13.281351771164978,4.581937529567497,0,0,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark26(-1.3877787807814457E-17,20.553876523754877,71.59124797976637,-89.5463795294451,-18.2438091561596 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark26(1.3877787807814457E-17,9.401139495299418,-7.9203634947083295,-28.714949995481156,-1.2238077279208808 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark26(-1.402659008590097E-15,10.966535690842123,0,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark26(14.147874636634652,-5.35657220564166E-4,-0.0031450998040659303,-100.0,0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark26(-1.5543122344752192E-15,0.4695561996716435,100.0,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark26(15.691390559423951,-6.767919558114954E-13,-66.5735537156976,0,0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark26(15.709380570162196,-3.552713678800501E-15,0,0,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark26(-1.6247743761029637E-4,0.1723339130843043,100.0,-100.0,-63.784009733562975 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark26(-1.6877278217813294E-6,49.80524478267975,37.12251902564756,-43.767215983970466,-29.828328564258335 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark26(-1.734723475976807E-18,50.117506618584045,75.26633643056715,0,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark26(1.7763098255371509E-15,-20.795552289720682,-14.534855428981027,0,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-15,107.93455951590009,7.6670275768699625,-36.47907602182842,-31.229861179667154 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-15,24.55828402038302,18.2945718333242,-100.0,-100.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-15,26.546532249556133,164.91264979667864,-14.958532372474195,62.31265359456077 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark26(1.7763568394002505E-15,-60.7884167952382,-32.663472236694645,-100.0,13.934601406827035 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark26(-1.7763568394002505E-15,7.804021136173844,0,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark26(-1.8569382836002002E-4,62.47424694376883,54.877877425616546,29.28688887494348,-13.924280608229544 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark26(-1.8834644352022584E-16,78.16945484286308,0.39387964224358996,11.709919611629005,-154.76811279585488 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark26(19.963034979788617,-32.859633472033295,0,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark26(2.220446049250313E-16,-0.40269124999453826,-74.05152507920708,0,0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,131.32006434528483,87.45952305158654,-82.39232155384802,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,24.400012268965984,7.424186755450001,-87.82486928403732,-48.80002453793197 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,46.33128044200262,4.921382307958638,0,0 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,80.41282564812343,0.27978547536352494,0,0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,88.32843914446471,96.30203239713117,43.37882140883491,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark26(-2.220446049250313E-16,96.36041958761855,1.5013622026914106,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark26(2.2780389602461426E-8,0.09049262076268519,-36.30209749346315,-11.73724490328419,100.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark26(23.965992333652153,-0.06068361666811595,0,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark26(2.3987019201650306E-6,63.26770714589124,-9.769999432535108,-52.63615369813498,1910.1679620278994 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark26(2.725924246870387,-0.20939331618274828,0,0,0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark26(-2.7755575615628914E-17,-13.391921610187428,10.206127547320197,-6.695960805209702,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark26(-28.853025995490867,-27.804018722525285,57.67308123411277,45.46946143331462,-10.938859547424016 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark26(2.913918635199997E-6,0.5775422688640685,-31.780230693145075,-99.99999995905286,-1.1550845054504875 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark26(-3.0772696842969425E-17,60.07917617278812,53.19479911905813,-2113.077481878452,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark26(-3.1003842436625655E-16,41.08984216862712,3.9154461430202048,3.133345875284965,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark26(3.1020137162267645,-0.033702747010597514,-0.5063795555055037,0,0 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark26(-3.122502256758253E-17,9.25446024808832,17.031462399064132,-91.54002197743714,-18.508920496176643 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark26(-3.127500808385382E-15,-2.5282728330532778,99.84526014439308,-2.0495345799240874,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark26(-3.1535859798331126E-7,-28.184510360034587,0.2808026869673621,-42.25060931234429,37.60950080949252 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark26(31.7620808070398,1.8474111129762605E-12,-9.24415628186727E-6,-0.7853981633965246,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark26(-32.713230137983956,84.73493573451256,88.29471256683169,-36.59763159564111,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark26(-3.346791155728077,3.552713678800501E-14,0.0015176195037377438,-100.0,-7.127631818093505E-14 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark26(33.70256305287944,-55.79383407866341,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark26(3.469446951953614E-17,-15.771038378621354,-52.996173473764216,-31.91219173315784,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark26(3.469446951953614E-18,-18.77686749846691,-94.94805393015699,-17.87908709147787,37.65659897507977 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark26(-3.469446951953614E-18,93.4815226341199,23.469435279192126,-130.75978144211604,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-14,-86.01492956340915,-78.35249031590146,-45.95880768473211,-77.01440660531517 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-0.08279653824254751,-62.21023818873586,0,0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark26(-3.552713678800501E-15,16.768529776569473,3.9662732621745036,-47.37910486259504,16.123921189779068 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-3.089377093926556,-13.968575651034705,-57.50527995424578,31.448037189634455 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-98.14627252523094,-79.80894312869205,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark26(3.552713678800501E-15,-98.96717326488141,-23.33752862709497,-76.8440226964652,100.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark26(-3.6987399160401613,7.105427357601002E-15,0.42468417959935323,0,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark26(-3.717054894664829E-4,4.422265845791465,0,0,0 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark26(-38.83599224114668,-3.255484894454627,0.012769173554150455,-49.17955057962704,0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark26(-3.924301920629711E-18,81.67997238810682,-18.449041008875653,0,0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark26(-39.48730048347304,18.736437707269488,0,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark26(-3.9838848601471284,-46.678235138148196,45.12699377501539,71.60667999750513,75.26003750387014 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark26(-4.123483690438843E-4,41.52870808314901,8.188591850778813,-8.000986291785765,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark26(4.263256414560601E-14,-0.03374335166987789,0,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark26(42.99420867947302,-95.54411948639665,-36.41251316275786,-19.280874361040006,50.657537161669325 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,12.736368652047638,29.73687585430605,1.0678377532642287,-25.472737304095276 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,26.714641849950596,0.0,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark26(4.440892098500626E-16,31.802869048596193,-68.19887070371131,-61.4613279464642,-63.60573809719241 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,39.69945822108215,26.23480816339898,0,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark26(-4.440892098500626E-16,4.233393379916393,22.68177620282262,-47.197216940108234,18.96154921060834 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark26(4.506377076485256E-17,7.768557269483619,-1.4568937796465518,3.8512811338675776,-15.537114538967238 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark26(-4.511552722427679E-18,22.82001650893507,2.1316282072803006E-14,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark26(45.19517590321689,10.498312598689566,12.824298033485633,-92.39011727928737,-68.26611886884895 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark26(-46.211847293704594,3.552713678800501E-15,24.045879081700235,0,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark26(46.21805287931133,38.15647674326161,-4.577046652909786,0,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark26(46.78682038894746,52.178257209693925,0,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark26(4.682712555419084E-5,-6.23446873878472,-33.60891641030893,-3.11723445601291,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark26(47.542049522322,54.03079119274648,63.83325467524875,63.510654976213715,70.878162031236 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark26(-48.02742060068658,1.5631940186722204E-13,0,0,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark26(4.832612605783562E-6,-100.0,-42.94217275401033,-54.91016351827524,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark26(-48.50069435903259,-75.60044433578963,-41.75847498309573,3.6626390455974303,-30.215109646065017 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark26(-48.60377343598918,8.902196534972902,0,0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark26(-4.884981308350689E-15,25.1060853362396,0,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark26(4.907545331722222E-14,-34.854835093096725,-177.95745241106636,-73.69792521171064,1939.9337439768342 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark26(-49.169687367137094,-18.495817529356046,12.726758615440929,-45.217697356119004,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark26(-50.193467163271066,-56.39852314488969,-47.06583347985838,43.186982238804916,-71.38463628646991 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark26(53.01632981751422,23.764459000063496,-38.983930843307405,-48.86291470053159,-47.378941286140844 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark26(-58.18025138665842,0.0010777766826107898,0,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark26(58.56644396898253,-2.7755575615628914E-17,-1.734723475976807E-18,-78.92573549092238,-18.68338367351886 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark26(58.65314793414609,-56.00967287121206,0,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark26(-63.613986389376144,47.70692421588274,0,0,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark26(-6.536993168992922E-13,0.780356041684314,10.414849269382444,0,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark26(-6.661338147750939E-16,87.11408751062532,28.782245037743422,0,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark26(-6.767940799785805,-4.440892098500626E-16,5.329070518200751E-15,-20.83194381912599,31.635984288427153 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark26(6.786823198153735E-15,14.549991464418413,-75.35641854872263,-0.6613576481571786,78.51626256588446 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark26(68.19056783357183,0.0596013553374064,0,0,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark26(6.974184381038746E-14,-36.255560867307516,-73.26086811495838,-140.0853105794877,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark26(-70.89062839720069,8.26768189049973,-73.25160257965905,49.54694487247713,88.18446388784207 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark26(7.105427357601002E-15,212.73679583291732,-80.32346152315297,-21.63845604506939,1815.5586646524503 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark26(-7.105427357601002E-15,34.859105064429485,38.73338967008377,-38.57042305223042,-40.77698302212789 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark26(7.206063102055751E-4,-35.34967122499258,-92.22653747599952,-20.834536798367846,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark26(-7.288571627051158E-16,70.4997625937622,85.69054965587796,-26.697495117513753,-46.89044632970207 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark26(-76.51716363822278,4.440892098500626E-15,-4.1174214154474954E-4,-100.0,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark26(-77.03033163576427,31.73360129527711,0,0,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark26(-8.012547664529982E-4,27.754172720972676,61.17590952677268,-7.441962655887167,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark26(-8.015531012214922,79.28328682921665,88.60058599164603,0,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark26(-8.041247449519034,-87.48138965531757,0,0,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark26(81.5215333365168,-6.938893903907228E-17,0,0,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark26(-838.337568959272,-0.0015314447712779858,1473.7191498071256,0,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark26(87.85713409173727,55.404600228622684,-70.64579938833245,0,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,10.120098664729014,18.32748727397886,-41.18371082595648,-20.240197329458027 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,117.35644687962504,15.588188595116975,-50.977379313432095,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,22.093537965137724,19.365154552617014,-9.834676991203523,-44.18707593027551 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark26(-8.881784197001252E-16,415.09448393463646,71.08513658669376,-51.64231243621825,1418.326374589318 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,-42.8215049364851,-18.02459089721205,0,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark26(8.881784197001252E-16,67.42075417809043,-27.82730754450924,-21.908888821002435,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark26(90.53958445086738,-79.63127183773624,0,0,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark26(9.089217285472593,27.992484183117625,-8.326672684688674E-17,13.210843928161363,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark26(-9.213904683101998E-19,85.17301982061285,4.6663180925160944E-302,0,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark26(-9.260485244593717,7.105427357601002E-15,7.105427357601002E-15,-68.29669100103692,24.882790069077405 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark26(95.00861160962697,-36.599403601436144,-57.59923783727465,0,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark26(98.56580620415838,-63.50659661107745,92.54163290063943,-55.206418608337174,17.58326324998383 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark26(9.91826629774046E-18,34.47921556552624,-53.18967502534528,16.870110877349962,-59.25754304316939 ) ;
  }
}
