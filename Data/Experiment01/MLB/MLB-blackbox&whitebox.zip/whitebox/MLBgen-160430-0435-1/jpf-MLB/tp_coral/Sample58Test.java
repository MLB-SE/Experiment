import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.00655580193885253,-2.2742857192231096E-174,6.451969180494426E-64 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.022826715725833585,12.40269930682763,-49.06845130228997 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.022891721048831082,5.775095687318927,-65.04856040456747 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.024781065606655668,-9.466330862652142E-30,-24.09518314412098 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.041233522876515966,9.237055564881302E-14,-21.688345732328855 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.04686957985209622,-53.870480412669096,27.347170677738298 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.048390645892662204,100.0,-76.46969646979443 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.05069677354477364,37.60704578083332,-7.326083039901249 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.05396370586433553,26.031716864395147,-0.060341633822214455 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(0,0.014358393326132483,-0.021319443203939303,-0.780660748954896,-11.785709865674285 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.3939102473858296,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.5923558310938972,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-0.8226324698038142,1294.9709545169007,-1214.758913594771 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.04239638051055582,-19.10472297713832,0.05066603994408769 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.04336546355794091,-13.2567827445367,0.10523446584228204 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-0.044852826484931885,0.05628860391197803,-12.718057925060975 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.05023336908391908,-6.474702953154277,0.18637693424181603 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-100.0,-0.16137924341740184,0.07284433040415883,-3.890504569466281 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark58(0.0,100.0,-1.1102230246251565E-16,6.031326064430902E-4,-65.98398071712188 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.1102230246251565E-16,-5.551115123125783E-17,27.208299965389998 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.232595164407831E-32,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.232595164407831E-32,-8.170300693382702E-13,0.020826201592701023,-75.42404311236986 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-126.60472951803769,-0.05557211698745115,-13.721723084591096,0.00241701091320062 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.3877787807814457E-17,-66.45221919154125,0.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1.3877787807814457E-17,-93.26839697237887,100.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.6249952804464711,-0.046198557079637936,0.095916978354237,-16.37662438055041 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-17.123978798508492,-0.1695247295443048,-0.903301528160015,-2.2563889421056 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark58(0.0,1.826100363927576,-0.025960533946841335,-6.84342893171857,0.024950984647734487 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-1830.463643447848,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.220446049250313E-16,-10.254134410407374,32.141340326678005 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.220446049250313E-16,1382.2459960851274,-1171.2678845915223 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.220446049250313E-16,-45.79863701442486,-11.205121557734094 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2234.1274100158744,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-23.47682002897843,-6.106373533311144E-32,-1.6642675774734768,-1.4773600282953454 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-23.516891049972173,0,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-24.851169883927184,-0.0057623407864727605,0.06082249448755434,-25.713823189393747 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-25.640714110868206,-1.3877787807814457E-17,-2.767039638496016,-1.3803323748405825 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-27.65228104433279,-0.009024794041434109,0.15711703840811708,-9.99761924428996 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-2.7755575615628914E-17,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-29.301553333310032,-1.5978291858285032E-4,-7.844291972499391,0.19839067713393188 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-29.995155245952652,-8.54179922738085E-14,-69.37933687886108,0.022640693864479644 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-3.3881317890172014E-21,-0.15920310939073612,0.12677999894474615,-6.775055506202214 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark58(0,-0.4354685294149191,-0.01158939793078897,-3.831082050275156,0.32362637215159257 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-4.440892098500626E-16,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-44.863375434528955,-0.02618604909141499,2.3108608855722432E-42,-20.052134279678114 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark58(0,0,45.40014512901601,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark58(0,0,4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-49.31397774732741,-0.04814907237923117,-35.97305034487846,0.006242918695228417 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-51.66478259528328,-0.02713983010741361,0.02936658424452432,-53.48924184424935 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-51.85429823048683,-0.03060148600816301,-4.3290821528960315,0.3628474284656571 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-5.287778108119468,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-5.293955920339377E-23,-0.3900322333662562,3.1554436208840472E-30,-76.32979465533322 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-53.20526339461533,-0.05007608022670064,0.03820690055211515,-41.11289594538766 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-53.65202205339649,-1.6825477853727707E-34,-7.351230848201445,0.08885426491935172 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-5.6366403077314065,-0.04536962128226217,-3.9889507651380636,0.2063851545681915 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-5.690748715297644,-0.006541757054548153,0.01101057658595362,-32.474467608555564 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-66.03474077286351,-1.1875519746440643E-16,-4.817887735854767,0.7044377185072094 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark58(0.0,6.683546421743004,-0.013145290166394796,7.346505659246553E-37,-7.406956652270116 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-67.45308899904414,-0.05072296481668336,0.05210612711382468,-16.37769938442857 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark58(0.0,70.03392863014814,-0.37673499409713307,-3.851826332182269,0.5563982786003383 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-73.14575047326736,-0.016612355125302472,1.2698228484637309E-5,-51.301732397129385 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark58(0.0,75.47575209442225,-0.049454298487187416,-2.6567541828042476,-0.48499200911564255 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-75.7249422631117,-1.1102230246251565E-16,0.02155088878620859,-72.88777471674821 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-7.63805836648821,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-80.27454215182226,0,0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark58(0.0,81.38864841052191,-0.012577266405062675,0.21289390462345636,-7.364431998124161 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-81.99031314877928,-5.965145381379197E-17,-19.012745406795368,0.0712635025637044 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-84.23653113956651,-49.87712515327027,55.23194401305179 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-86.2267722805749,-0.015594369958711107,0.03711300003587781,-42.32469283745262 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-92.8096239793351,86.43629681361944,-4.102145958768659 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark58(0,0,-96.84294724981316,0,0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark58(0.0,9.790903312195914,-5.197334779936694E-5,-7.7152340289558445,0.049037249901611624 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark58(0.0,-98.27299026339323,-1.1102230246251565E-16,-13.782569331016965,9.713589853113103E-4 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark58(0.0,98.60636373649778,-0.045452907954622035,-23.032393541339236,0.06060482190936786 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.37389635069756,-0.045923197334219665,0.15134686760977578,-4.781513283326253 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.72162342470783,-0.3594157349398941,-4.895482256933525,0.32086651413559114 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark58(0.0,99.98619851974539,-5.421010862427522E-20,-3.5810958216127218,0.43863565931823956 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.011627599330866989,-4.161657001119675,0.3612386332231282 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.02566566399889958,-3.315452230092248,0.47378041298189544 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.04588985644735795,2.4161145782661357,-3.916114262951737 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.052508839096526844,-21.518919547953747,0.06958786794464779 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-0.05637761142043944,0.005501153521912894,-10.958771613698923 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-0.11398621956415192,-0.8683162756793666,0.8683162756793666 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark58(0,-100.0,-1.1569098371814563E-16,2.9965877568122927,-4.567384083607189 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-2.495424929317286E-4,2.0091750689177346E-5,-52.91763140415599 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-3.0918491543068966E-15,-4.575912180991175,3.0051158541962777 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark58(0,100.0,-4.7979128408224635E-12,-2.1469879310368123,0.6469879310368122 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark58(-0.10733917834152573,62.261229410125935,-0.042001595114617984,-4.883613485010457,0.32164632430805895 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark58(0,16.885930231616697,-0.16863026443288953,-2313.0291083668126,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark58(0,17.947989731978453,-0.02206256112175503,-17.407590462406016,0.09021352003674643 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark58(0,20.46156908563503,-0.029986127729201895,-84.69859734988079,3.944304526105059E-31 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark58(0,-27.53225172108249,-0.0461215577691948,-5.990551857760601,0.24644751706330226 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark58(0,-28.503844870203913,-0.042156509077972235,0.005713587458455252,-84.34107719653282 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark58(0,32.6413379628277,-0.033598175855400925,-10.609702930572553,0.04818373607437687 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark58(0,-37.63167509529913,-0.04131692415705658,0.07601853356056232,-11.73675234955229 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark58(0,-38.72035051354609,-8.881784197001252E-16,0.0327980149368301,-47.89303041114798 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark58(0,43.56456465949115,-0.023831881304143043,-46.07089563784588,2.220446049250313E-16 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark58(0,-43.68443488650897,-0.04162264141764916,0.30655188389841265,-0.3065518838984127 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark58(0,47.246776732993055,82.63015696245623,50.370563435903705,27.452831816224858 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark58(0,-54.185859272510974,-0.9999999999999989,-6.05341428399191,6.0536264470531105 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark58(0,-57.04423822211064,-8.502158667883378,-83.0203221628557,42.69159544173755 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark58(-0.5794158095729214,3.5085233834025757,-0.05825822193327962,0.07861786949336333,-19.980143660945913 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark58(0,62.1469614413722,-0.048472332690892544,0.01632544566437517,-34.86594948311317 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark58(0,74.93844399669865,-2.7755575615628914E-17,0.03746228129406681,-12.74484344499734 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark58(0,76.75252806396284,-0.030508574302878212,0.45966710218668577,-2.0304634289815824 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark58(0,76.83062627196958,-5.551115123125783E-17,-0.0807303188157178,19.4573284217975 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark58(0,-77.19429447006452,-0.059024637768420235,-1.7547976260218061,0.18400129922690955 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark58(0,81.58069818030617,-0.06230542041780902,-0.08035930722331841,0.08035930722331404 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark58(0,83.0333005106481,-0.9999999999999998,3.466164472377231,-4.347087298556117 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark58(0,-84.62587153782967,-0.03770745518031082,-29.36843021700149,0.037973398308850076 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark58(0,89.26975579225562,-0.47907796097085237,-2106.3703318038692,1.8110513089197866E-15 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark58(0,-89.81625160633786,-6.936990169713699E-15,4.478959247364828E-16,-55.25538883633906 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark58(0,90.70238851583659,-0.023213775727469965,0.3786475636274025,-4.148439017398758 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark58(0,-94.76651955591201,-1.1102230246251565E-16,-5.429959491141455,2.3591631643465583 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark58(0,-95.6675329780845,-0.013647928311625923,-3.7537524153592554,0.11690454621409757 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark58(100.0,77.49942060895117,-6.7888457219761674E-15,-22.734411619684458,0.05140876191368586 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark58(-100.0,-97.36859379425998,-1.3877787807814457E-17,-3.2070989640965712,0.03894085936649305 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark58(-11.657759984311001,-36.004503645306166,-0.014793719254452727,-29.120034622200073,0.030602127226873943 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark58(-1.3408305575585137E-21,-100.0,-2.7755575615628914E-17,0.11603107022998588,-13.537721609232868 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark58(1.426480579841095E-18,-50.9228846894667,-0.020945895976819638,0.3824157422344066,-4.107561884395572 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark58(-1.660490766209632E-55,-100.0,-0.0964535033668206,0.03486636693718763,-13.981105604339605 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark58(1.801976371730889E-31,-99.21191457572361,-7.93790074023431E-14,-16.195519151934715,0.09406125410692558 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark58(-22.871177070618913,-74.84283342091649,-0.0048658792639516,0.08001695058561499,-19.614788746412653 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark58(-22.956228307644164,2.2845764810715177,-0.007130793481717329,-35.84113741221944,0.01839184524640492 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark58(2.6901888600076463E-17,99.77612710859039,-0.04021740938859657,-2.4318795959093467,-0.7098149130631293 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark58(-2.7755575615628914E-17,7.850703942476842,-0.04064258578471602,-57.55302731817447,0.027051926887153854 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark58(-29.257159246748536,-82.40384791694109,-0.02230193836899628,-0.8666582580616469,-2.2768936258209287 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark58(-33.475247204747774,-100.0,-6.007433121111687E-12,-7.650887050494647,0.024597613795765083 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark58(-33.8681484964708,92.73546578686324,-0.04010280644729916,0.0692161233204102,-22.631186449806115 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark58(4.176766483047377E-19,-1.607194967476829,-0.03336811487287028,-0.6384242034339731,-5.648802731049092 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark58(-45.77191764616136,17.799476565755647,-9.542318889846827E-30,0.024436097144754143,-64.281800710227 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark58(-49.8916652157003,100.0,-0.004835728577794851,-23.089652083324907,0.06730551510038814 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark58(5.293955920339377E-23,-93.66440151012995,-0.060500270943038226,-4.428795765402136,0.35467797782872257 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark58(-53.72314647617679,-100.0,-0.04731710348628221,-13.904695478777901,0.11296876865748118 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark58(-57.22186740226828,24.050727346194257,-1.4987832089110511E-29,0.06001618390078889,-26.172879125262746 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark58(57.76425830779698,2.9158081947336996,-29.334407471484482,56.86683054996905,72.07624843722175 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark58(71.12567805665863,64.72098685865811,-0.18401796273136573,-1.0260988972055098,-2.1154939948415943 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark58(-76.61894205296959,10.42910820113271,-0.12898980675237978,0.7743420794727461,-5.41593473306254 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark58(-84.59352888448858,100.0,-0.04839079686048514,-6.892928330182731,0.1566055209525549 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark58(95.04477243633121,-8.486122001251516,76.88063752595619,13.371044991622611,-93.77647012141071 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark58(-98.29911860353546,-67.2063269549326,-2.7755575615628914E-17,0.08007857000079366,-19.288644131881053 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark58(-99.14678569435203,4.267441308249187,-0.0031302522844719426,-7.429966983644995,1.3228201819855059E-8 ) ;
  }
}
