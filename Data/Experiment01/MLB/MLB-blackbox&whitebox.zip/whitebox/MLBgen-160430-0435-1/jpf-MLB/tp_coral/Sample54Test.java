import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
//    0.8350707695939024;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.0025471539931404704,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.004413948653227393,13.953108716580418 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.010318108444644314,-1.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.017601445173489078,1.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.0298476883173997,-1.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.03698022371046705,0.6337580411557648 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.04273148631770319,1.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.04880299101403902,5.0758836746312984E-116 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.04881355000796685,-0.33584488467558105 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.06062777343337378,0.6762942478408713 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.0843522548433753,-78.6798070971195 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.12192267131142397,-1.402757983365378E-191 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1235862158905216,1.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1283546723826862,0.06255252536687125 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.12888310187844654,-66.73402166179949 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.1450505436046551,-100.0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16416906130545228,1.0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.16748746640095988,-100.0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.18617935036812128,-58.67755016490199 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark54(0.0018914428983149859,-0.8368555865332445,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.20369409104228442,7.888609052210118E-31 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.21326192231173724,-1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.23419718620000984,0.9999999997486462 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2524787297574189,100.0 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.25422057447780566,77.0238186897806 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.2715918815719687,1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.28607657352832816,1.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.29254182912613785,92.26654319652299 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3266745988951044,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.33328680272408523,-0.9999999999999929 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3367751850515657,-1.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.33727790691044734,-0.3377197124818945 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3454258679687872,8.63004658664454 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.35419030991424383,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3678684740186551,-0.04808807185832997 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.3771180099853524,-38.813299247271324 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.40084251196443094,84.15202457373304 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4064684310331472,1.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4477618087269922,1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.45870648057116625,-1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.4824310717934477,-1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5139464406313345,21.55736871523735 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5149553949919061,2149.181938067814 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5256076594355363,-72.90000554248469 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5256488508057624,-100.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5398484776545789,-1.866252401384966 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark54(0.005456366832700964,-1.20849102232841,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.5506526826192482,0.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.559910087490961,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.56385549097112,0.4588714353344824 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6581918637381572,-17.38606276686257 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6832617967599885,-1.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.6862753825903437,-1.0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7006442359412695,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7065698214414926,0.38539187131485164 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.7336337135986521,39.03040567517357 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.754901569983759,-0.016420086535328213 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8050290880697162,0.0062737006055880035 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8138918551825256,56.960376840491975 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8220377164899726,0.01564311463510326 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.832841867626622,1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.8655852487334481,-38.95901115061139 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9036928904503598,-1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.908875618825196,-5.061081568684102 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.947323210650284,-0.0625525254381645 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9591957145984393,1.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-0.9684125036460206,0.0014695857530830929 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0118215919067717,1.0500596222943174E-8 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0135583271054698,-0.8885522971201416 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0299531918869511,-1.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.0765454026848853,14.925722672243614 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1102230246251565E-16,0.04377696226656587 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1231958216491293,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1234977257652483,-2315.6386249499965 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1276183874467243,0.0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1607225516909683,67.58863345186974 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1611666507793514,-0.941205139470222 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1643900266601666,-28.84906940997377 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.173851203626602,0.10192387664632019 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1749601888807923,-44.30611702008789 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.1809909150136233,0.9999641544984955 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2022993521320529,0.9999999999999999 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2249466148400221E-8,1.2423500409676401E-11 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2593024749119084,1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.269897978396032,-1.000000017647893 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2831344260134776,-0.17352956761093985 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2837991726188704,-0.605659253681949 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.2945343003896908,1.0000001734561959 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3133887588131585,1.0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3173695487837591,0.2763784432427915 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3175456900365445,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.33135471655731,-1.0 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3454245057036276,-96.2587283563574 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3464528296335583,-63.79224525701262 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3792955215503468,1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.3838655015053383,59.00159018276369 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4268392772897684,-1.0000000000000018 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4295294529264435,-0.8190954204583332 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4495182469785173,16.69015281292395 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.454905863430882,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4579776532727875,0.9795718086887854 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.469304974918461,-0.06539443726149052 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4748962545869984,1.0000000337135138 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.476021712387409,-0.3330712087305647 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.483079671087495,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.493567343166771,-0.9212665006182055 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4941001641606197,3.021163932015641E-17 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4992823200467522,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999114008210876,58.50990310569406 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999996425585418,100.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999901869874,-3.4451472571287334E-10 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999995077982,0.1563353328440269 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999853,-1.0000000000000002 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.499999999999992,2375.1658912935873 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,-0.2809548976236415 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,-0.7305572997508278 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,-0.9614910268639534 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999982,45.85263681944963 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999998,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-1.4999999999999998,94.06718047633503 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark54(0.018238586306102533,-0.0920424771763878,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark54(-0.018293871571545328,-1.4999999996767341,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,-0.04115455823241469 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-2.220446049250313E-16,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark54(0.024679452652520695,-0.29224663443340937,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark54(0.03547032012259521,-1.288955453202874,0 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark54(0.03638219398500553,-1.3224491285412845,0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-4.440892098500626E-16,18.728410797553465 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark54(0.044976333086224084,-1.163397220269422,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark54(0.04773767013499253,-1.4999999999998508,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark54(0.04777799601405315,-0.37266205112222306,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark54(0.04794443265325832,-0.7548520486803767,0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark54(0.05311624393564333,-0.8614451091829867,0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark54(0.05571078872790736,-1.0525649968890942,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.5606698900631031,0 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark54(0.05640596804515852,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark54(0.06191141560256788,-1.0913363039359831,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-6.6599917309756716E-257,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark54(0.0,6.938893903907228E-18,0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-7.931629256498692E-10,-71.34812100163406 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-8.881784197001252E-16,0.6211145263694613 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-8.881784197001252E-16,-97.18068241141779 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark54(0.09364927316080479,-0.21611482578533625,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark54(0.0,-9.552576358388328E-16,-1.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark54(0,-0.991579910253094,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark54(0.11809660274656775,-0.6066498607113004,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1880315965920403,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.1911636288969305,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark54(0,-12.069065342296994,0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark54(0.12421479423983328,-0.03695992880578558,0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.260223340338178,0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark54(0.13156986672595394,-0.7974313878690111,0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.3388065612010536,0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.3812681278185792,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark54(0.14190469656139726,-0.5208695890728245,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4399519132008294,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.548433291410503,0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark54(0,-1.5E-323,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark54(0,-17.285899433821058,0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark54(0.1901273844489193,-0.023543687587649798,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark54(0.19508052629108263,-1.4999999997638607,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark54(0.22000602544902392,-0.18272121715543221,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark54(0,-22.392316841800252,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark54(0.23572193247211715,-0.3297245227490295,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark54(-0.2379553988097456,-4.440892098500626E-16,1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark54(-0.24458708303935595,-1.3557245727020426,3.531921151179037 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark54(0,-2628.7915893053546,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark54(0,-2634.751969885268,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark54(0.2654989750463428,-1.496895527420008,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark54(0.2656546034722229,-0.04600200815060873,0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark54(0.28012365043814214,-0.17546823696943648,0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark54(0.28327667716324095,-0.6414388220699634,0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark54(0.29677640079596745,-0.1815123621662451,0 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark54(0.29755607543158646,-0.29870214442935605,0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark54(0.3022179182718494,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark54(0.30266078907985294,-0.10822663602962646,0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark54(0,31.284317026455795,0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark54(-0.33091486669062253,-4.2215084380911875E-10,-0.3682108292336359 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark54(0.3337832391300355,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark54(-0.3489399305404691,-0.20044218973402383,5.0463136952005385 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark54(0,-35.09578835468972,0 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark54(0.3687913940500336,-0.148178665067363,0 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark54(0,4.2351647362715017E-22,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark54(0.43227600798878996,-1.2680691643624762,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.381188513870953,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark54(0.44540825133661477,-0.16382104442446185,0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark54(0.4520401796150395,-0.5395719023265055,0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark54(0,-4.735734049278449,0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark54(0.4841941675125998,-1.2831436780223988,0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark54(0.4954100476521416,-1.3376503775450015,0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark54(0.5067646263382102,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark54(0.5196718916876901,-0.23824471127429536,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark54(0,-54.895011002445294,0 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark54(0.5540119805823558,-0.3159418223436199,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark54(0.5637668601769636,-0.5820920889185309,0 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark54(0,-56.41217955123374,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark54(0.6028461293414269,-0.9202440420004704,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark54(0,-61.26383717187773,0 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark54(0.6170753671820614,-2.5541681090597075E-8,0 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark54(0.6231836322227984,-1.3977462560406828E-9,0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark54(0.6595454052542689,-1.1043479222433632,0 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark54(0.6861960264907607,-0.12672939372320713,0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark54(0.6920053080192425,-0.007785043619444432,0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark54(0.7155208723147801,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark54(0.7203934584739344,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark54(0.7227984639249598,-0.5404011869389839,0 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark54(0.7374091681497248,-0.6900872014252926,0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark54(0.7661741166554208,-0.47813696546486195,0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark54(0.7684322024946226,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark54(0.8099814589722425,-2.5920268853835288E-9,0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark54(0.822753470516137,-1.0728953025654508,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark54(0,-83.87939705948611,0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark54(0.8473986735748582,-0.581043150254327,0 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark54(0.8636644954337139,-0.7855582095711249,0 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark54(0.8754423248046379,-1.1096511806394744,0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark54(0.8820009941022491,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark54(0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark54(0,-91.46873420226677,0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark54(0.927350552741369,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark54(0.9323414852949565,-1.4999999515084703,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark54(0.9384019507438381,-46.373841898065685,6.951662109783825 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark54(0.9414324209450768,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark54(0.947888098813408,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark54(0.9600842145122357,-0.1916405910390392,0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark54(0.9755047518240371,-0.10394283013744673,0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark54(-0.98073208936697,-1.1637949922548136,0.7767854435128393 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark54(0,-9.823455228303118,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark54(0.9952878958442906,-0.9380953849820901,0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.001050205819744249,0 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0026083355605315273,0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0072172453324304,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.010462938118476123,0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.015206966600073923,0 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.02544309905840947,1.0 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.03771926753715915,0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.040451572437633955,0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.056602866686080944,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.07735794738485963,0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.08064491278517494,0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.08191251042393148,0.9668273102706836 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.0956543420504713,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.12196597632778583,1.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1233318762424483,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1272892978149907,0 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.13044105241873183,0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.13414491820458146,0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.14549819944404127,-0.020186811817309414 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.15325625074188223,-1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.16016955537749178,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.18176090127322864,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.1878786512683881,0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.19970095488552042,0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.20224535443772695,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.21891238113565925,0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2470643255955549,0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2674719618078547,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2701381376050511,0 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.27028417191927706,-0.9974280811521136 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2708284760182096,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.2815990663840372,0 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3133830083200272,0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.32227493614575853,0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3407801558323875,0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.37376221233341766,0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.3828436074628041,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.38505390584385485,0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.389691501392732,0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.40358802783020986,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.41201760353816574,0 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.42270905626300936,0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.45234880817726,0 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.45939699119182453,0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4644653524207276,0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4667503354139713,0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.46724953562436267,0.9999999999999982 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.47149130888745816,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.47278485285192806,0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.47456779234527774,0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.4801224824890734,0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.48711092777417886,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.49678460732570096,0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5034904928167796,0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5106321900056652,0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5132693729287903,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5189320540992394,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5192008785446143,0 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5367511219404244,0 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5674536745130967,0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5743939375362517,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5771646641212519,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.5784566825414812,0 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6050190021086927,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6053320365330688,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6063873255896967,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6322260322671118,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6750583149036705,0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6830491622806132,0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.6908667174566601,0 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7045449567003628,0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7050096755110928,0 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.719987676749694,0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7272852195953339,0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7324657777999064,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7467479842579111,0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7522996294054126,0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7533437753416947,0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.7747154859309171,0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8179568501034805,0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8204873079286152,0 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8434368670185561,0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8623307024243055,0 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8755547938211715,0 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8887080088991524,0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8900655079907178,0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.8915863995558386,0 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9072934848940581,0 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9150289467983048,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9212891624169188,0 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-0.9292902374061005,-2263.376322019909 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9381951969101117,0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9463830860964207,0 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9497681540539489,0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9814629478474941,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9829109212677993,0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9966273289199394,0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9971069367295803,0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.997966057557149,0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-0.9980419685154208,0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0024509414962577E-7,0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0061753833231544,0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0146210134912828,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0162768980096115,0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0218943715704047,0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.057137884213507,0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0668825215417232,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.0703560011311488E-9,0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1222715091594608,0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1549885258089572,0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1622721433129155,0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.1980823961577052,0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2082367250136774,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2107503104006678,0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2610062756666252,0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.292897441129929,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.2958345253170582,0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3097136833801608,0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3177729490060563,0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.3209608207103127,0.9999999978647651 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3284112357421682,0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.347469521045908,0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3590189313584442,0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3702799147906503E-8,0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.3956064558948366E-6,0 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4415480784822468,0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4417972504044447,0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4431856487227805,0 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.444713276485075,1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4468274052421368,0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4522838910159153,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.480170365882534,0 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4811662937442456,0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4845290665383146,0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4919967514410226,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.494000778684918,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4967815881700002,-1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4999874781829552,-0.36209343683713513 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499994240565893,0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499996658140196,0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999997940544556,0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999598041625,0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999784162452,0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999983134171,0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.49999999896817,0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.499999999602135,0.6050333123647693 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999831,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999999999993,0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.499999999999996,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4999999999999996,-0.5623823336207104 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-1.4999999999999998,46.4212572197529 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5492157310308155E-9,0 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.5932479136340134E-7,0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.1105249779390034E-8,0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.2230430439480298E-8,0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-2.366274772495495E-8,0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-3.69685505565126E-5,0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.1268428359939305E-10,0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.182840240956398E-9,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.305230317726807E-7,0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.361262513531527E-4,0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.665332575302607E-10,0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.685597082993117E-5,0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-4.858267940967989E-9,0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-6.014045689999336E-9,0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark54(-100.0,-6.981860242391373E-18,-0.9800267744777318 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.154360301686317E-10,0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.588257533499819E-8,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.682525267657828E-6,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark54(100.0,-9.211615638594863E-10,0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark54(10.083543574491193,-0.4808069865165181,0 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark54(10.162167072583912,-1.043366025567451,0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark54(1.020454206551463,-0.07074581428049598,0 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark54(-1.0205070215567158E-18,-0.6245562848728952,0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark54(10.296950413020607,-0.9535745647624039,0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark54(10.305006238294993,-0.23137121511161202,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark54(10.382372138587385,-0.3096789535914155,0 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark54(10.390924968355321,-0.9493572577552456,0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark54(10.393564695661947,-0.22795510597322277,0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark54(10.3994612070547,-0.8409269795810275,0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark54(10.409746370190051,-8.0898831168148E-9,0 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark54(10.44261603428427,-1.0111410600155366,0 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark54(1.0445773873418887,-1.4952622002802585,0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark54(10.466374857592935,-1.3724469540820319,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark54(10.566210241522256,-0.47515361731322336,0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark54(1.056809614595378,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark54(-10.57149896711418,-0.6290014814888185,0.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark54(1.0574358163918713,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark54(10.59215144276105,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark54(-10.611816370721986,-1.4551500946141116,-1.0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark54(10.64246434656365,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark54(10.644017223982443,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark54(10.651979295241524,-1.3610366550618913,0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark54(10.663637837825533,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark54(10.676356131302839,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark54(1.068883349277438,-1.0254257608478887,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark54(10.706695507525254,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark54(10.724732668760993,-0.11027091639035902,0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark54(10.73029833631899,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark54(10.838359594377508,-0.15376796668852866,0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark54(10.842743165691042,-1.4999702194230564,0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark54(10.845320943885966,-0.42684766493328574,0 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark54(10.862980489432472,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark54(10.865132754953805,-1.0049601048759627,0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark54(-10.885646754066315,-0.449356466427566,1.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark54(10.88980937459037,-1.0075632061307545,0 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark54(10.973295916974692,-0.7977139964279161,0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark54(10.981763455346965,-0.9341701497935544,0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark54(10.983424338939951,-1.831526580428691E-7,0 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark54(10.98484039387732,-1.1026138364551628,0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark54(1.0986943572978802,-0.3789519980660936,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark54(1.1002238087230731,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark54(11.005837109054674,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark54(11.028887284607752,-1.1452727645030123,0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark54(11.030841263003545,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark54(11.043604473503848,-0.4413907973966915,0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark54(11.064883001293998,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark54(1.1073362846672978,-0.11466640382435678,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark54(11.109514056267457,-0.19654775223711363,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark54(11.22575489794579,-1.499999999999968,0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark54(11.239622292302911,-0.2570030926843998,0 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark54(11.254981591714653,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark54(11.273447655657236,-0.48177568226102707,0 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark54(11.27619614765112,-0.6826123138726388,0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark54(11.278996915442008,-1.10924287055491,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark54(1.1291012532718803,-0.8237587168069386,0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark54(11.338849987047078,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark54(11.367510486365617,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark54(11.3730791604621,-1.8418115691068034E-7,0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark54(11.424250807639185,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark54(11.43070480786534,-0.30716543051213147,0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark54(-11.471724261744281,-0.40803648030572504,-93.65573333077164 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark54(11.475801183662242,-0.781578915260944,0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark54(11.501515476615396,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark54(11.518471238118536,-1.4999999999993463,0 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark54(11.527007621728838,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark54(11.571196462110052,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark54(11.596775087586302,-0.19876235296307543,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark54(11.601952103726559,-3.0532765985831805E-7,0 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark54(11.608298279098662,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark54(11.610491928834328,-1.3578577875400857,0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark54(11.618347910257569,-0.617490245648649,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark54(11.649337589721071,-1.3589102105331845,0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark54(11.674093645000319,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark54(11.738723147631418,-0.21331765034181238,0 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark54(11.751948983452237,-0.14807370902798844,0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark54(11.770583817523915,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark54(11.792847256434479,-0.023537904496284432,0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark54(-11.810107152980912,-0.8049978089530612,0.9575691235780205 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark54(11.836003694993337,-0.32449391480797374,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark54(11.907480961759532,-0.3790219109600126,0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark54(11.920152928601468,-1.2403733807355874,0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark54(11.923966479264973,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark54(1.1925288328827577,-1.349985951377616,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark54(11.930442640300228,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark54(11.939447836984373,-2.2055875899444668E-7,0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark54(11.95780989316735,-1.0823370235158922,0 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark54(1.1980855011277654,-0.1439117536364023,0 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark54(11.984854246601785,-0.10591783548408695,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark54(12.003039460247287,-0.3003104657768838,0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark54(12.031926185414617,-0.7384196581596747,0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark54(12.045941516109515,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark54(1.2125184497216281,-0.7466830118767283,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark54(1.2145555724718649,-0.43675804600273693,0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark54(12.147029369982725,-1.1969636953630989,0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark54(1.2189007617837273,-0.7082719757149765,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark54(12.193503017910684,-0.1743452226622738,0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark54(12.203409958799838,-1.3330267045591557,0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark54(12.208392562696591,-1.0548003389458716,0 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark54(12.259841453638252,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark54(12.31056643455695,-1.3501754581329546E-8,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark54(-12.318233496711393,-2.220446049250313E-16,-48.43244829129635 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark54(12.318748632337304,-0.21838601535901503,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark54(12.338835323004245,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark54(12.363433550184993,-0.8365349056999207,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark54(12.378159621493174,-1.499999999914087,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark54(12.388977140235141,-0.7542329329540962,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark54(1.240781976890574,-0.9347163188703718,0 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark54(12.425815039659966,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark54(1.2429533386984404,-0.17315238096739627,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark54(12.489746629034954,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark54(12.514074682233627,-0.08861825048872818,0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark54(12.55275993649939,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark54(12.57874077452865,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark54(12.588956826506577,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark54(12.600090537433445,-0.5720835858163262,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark54(12.60518559000785,-1.499999999999865,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark54(12.625268014368539,-0.8155168656563645,0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark54(12.625517902379968,-0.09594679090065039,0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark54(12.631070497266379,-1.0044616230667307,0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark54(12.636113555032807,-0.07983505001164137,0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark54(12.710312497448541,-0.703646210225302,0 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark54(12.717570230909388,-1.07576322642554,0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark54(12.742853845219642,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark54(12.75026430681227,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark54(12.76653830145898,-0.520307979005394,0 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark54(12.788373485728613,-1.285234902265493,0 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark54(12.800422175582291,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark54(12.81615866580244,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark54(12.820686336305045,-1.0771933565962755,0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark54(1.2838948191855248,-0.4356501384976337,0 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark54(12.862502735246764,-1.312941255022963,0 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark54(-12.869117752899148,-0.5686573659104993,0.7468180790630945 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark54(1.2924084301718946,-0.8504664762654193,0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark54(12.934154896247364,-1.0434371247384067,0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark54(12.938157058068748,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark54(12.938518212273717,-1.2720901915427199,0 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark54(12.946533080865796,-1.4995002068880627,0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark54(12.95373949633725,-0.9496123213367063,0 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark54(12.959524084383956,-0.6938662834457745,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark54(12.979516560958388,-0.7889985610008825,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark54(13.013599186267225,-0.2513875174075366,0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark54(13.029887674261115,-0.5760975592031227,0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark54(13.03450361709983,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark54(13.03551814959215,-7.924414411279168E-10,0 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark54(13.081168327189289,-0.6656506550446513,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark54(13.086473084751788,-1.483953109174971,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark54(13.118865443748135,-1.151275517480213,0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark54(13.12190559980965,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark54(13.158861709529134,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark54(13.191176396374443,-1.0603111879369707,0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark54(13.194216980328907,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark54(1.3199791276339958,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark54(13.20659814328262,-0.6183349484394783,0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark54(13.207170902084634,-0.03908445322000874,0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark54(13.216536383511809,-1.3686706556102368,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark54(13.284637707777275,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark54(13.299231706570993,-0.23132328437733896,0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark54(13.305169740953232,-0.3827369454743996,0 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark54(13.339837191252407,-0.18602357007006387,0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark54(13.388705541457847,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark54(1.3425476176928157,-0.6918718756941113,0 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark54(13.442896128294151,-1.1511177017523835,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark54(13.455154532573971,-1.499719355031637,0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark54(1.3466943603138163E-17,-1.458972775652654,-1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark54(13.475798116661023,-1.1774219666891454,0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark54(13.515809260316473,-0.5346908953117239,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark54(13.558696767418919,-0.17276920644454985,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark54(13.57385346256332,-0.6719450975872121,0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark54(13.587880634948107,-0.7099950739234284,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark54(13.663253782054241,-0.0997877070684865,0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark54(13.66752267892571,-0.9489683266473286,0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark54(13.67618978193434,-0.5736333024286819,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark54(13.68011512484199,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark54(13.70122812327159,-0.7585807002441394,0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark54(13.704259230068743,-0.7239075339848791,0 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark54(13.71873806457063,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark54(13.76333459950282,-0.21920786843543283,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark54(13.76949970414016,-1.2098858334792306,0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark54(13.792768076014289,-1.4999999999699853,0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark54(13.795231453900852,-1.4999999998594282,0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark54(13.79858929524417,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark54(13.880008171412356,-0.6842063153766897,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark54(13.894589075792013,-0.2152237299924975,0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark54(13.902448759869003,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark54(13.910548310701245,-1.3076741327210186,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark54(13.910993076777231,-0.26996454776142365,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark54(13.925130625654432,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark54(13.927281744607242,-0.44794872101325556,0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark54(13.958806250725898,-1.5121656117209762E-6,0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark54(13.991714178754549,-0.37345604635429375,0 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark54(14.00524683072814,-0.04156916760802343,0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark54(14.047433305754637,-1.4391264246052913,0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark54(14.087460324319267,-0.7016389954225417,0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark54(14.091258485614222,-0.0772884589246754,0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark54(14.108085352731251,-1.091760760758003,0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark54(14.108270331601357,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark54(14.180952936484033,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark54(14.209586047791205,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark54(14.217359163024486,-1.0151523189413139,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark54(1.422294801610093,-0.8255061037917959,0 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark54(1.4223458801725855,-1.0965550936382709,0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark54(1.4273788924349873,-1.2631716186326258,0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark54(14.273841224052138,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark54(14.276515428156248,-1.4999999911750217,0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark54(14.281978479504497,-1.050971790856586,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark54(14.285398746048685,-1.0477379588023297,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark54(14.300570485784945,-0.28579698178943147,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark54(14.330863243114436,-0.31963458883796836,0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark54(14.345297290748178,-0.10390418248213779,0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark54(14.374194840861179,-0.008995452167282814,0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark54(14.376232273515017,-4.135774900501616E-5,0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark54(14.39254773975303,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark54(14.428868337734158,-0.5200933455643594,0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark54(14.43424681416101,-1.3699437548202946,0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark54(14.436499596113794,-1.3035551467461886,0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark54(14.450002862528507,-0.005170407100811181,0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark54(14.453061946375882,-1.2891235991270662,0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark54(14.490923440398701,-0.2038854636000485,0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark54(14.59836518520899,-0.06717836619855219,0 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark54(14.599379169216093,-1.1509040014877172,0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark54(14.603842604583178,-0.033947358963660745,0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark54(1.460585990743283,-0.056567558491479986,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark54(14.625208907319887,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark54(14.642254196379014,-1.1070857003129784,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark54(14.676128512273252,-0.12495662636705754,0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark54(14.686671271690242,-1.4069120649835598,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark54(14.689534469415044,-1.0357961192360727,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark54(14.69539411394149,90.79131133313712,-53.422750509380165 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark54(14.699516085732686,-0.3104553892952192,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark54(14.700590086068864,-0.2455191714251268,0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark54(14.746520757951487,-0.7512397201230385,0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark54(14.791085596534487,-0.5135710078121747,0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark54(14.815231048949109,-1.3929747256278975,0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark54(14.819597227332324,-0.11769893368227713,0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark54(14.829527332282197,-0.08935045069031862,0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark54(1.4847434180712327,-1.3407616272179261,0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark54(14.860757332809298,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark54(14.886231491613586,-1.0535273606147655,0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark54(14.915638416042171,-1.1793094689385082,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark54(14.950809461305287,-0.5676857448432031,0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark54(14.961003333298326,-0.05768573250492581,0 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark54(14.969225020854964,-1.0560254038822308,0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark54(-15.005441444865312,-1.0720397131447394,75.49604815391024 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark54(15.056204211173101,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark54(15.143816369427938,-1.168564256546253,0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark54(1.5147571358533014,-0.4963818168670646,0 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark54(1.5151897357915404E-4,-1.2934895371474457,0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark54(-15.154395811974908,-0.9803447378467212,91.67007520924236 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark54(15.195214882623858,-0.4178415877855315,0 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark54(15.228398409019643,-1.0661321380978022,0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark54(15.258528033359546,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark54(15.259184576522117,-0.08102182952811354,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark54(1.5315347394525816,-0.6666430856287651,0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark54(15.328658748116379,-0.7084845992373746,0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark54(15.329247064649918,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark54(15.368759757991517,-0.3712823409461774,0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark54(15.419219097307518,-1.0065044385955149,0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark54(15.441592850315303,-1.3687424346369053,0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark54(15.478831670953966,-1.3716962779286273,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark54(15.519175587773873,-1.3367042900709265,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark54(15.538762004537233,-0.47404336005626035,0 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark54(1.556510796417148,-0.9022499472073172,0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark54(15.574154401074795,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark54(15.580135325243077,-0.611297465810213,0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark54(15.583467390346845,-1.4954237111226762,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark54(1.559603305073348,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark54(15.607861578485952,-1.373151324425109,0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark54(15.651237510002375,-0.7164454698783178,0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark54(15.656029667571957,-0.9463379259388758,0 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark54(15.69225292365806,-1.4673374711097202,0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark54(15.702354663008379,-0.28799801953634585,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark54(15.714114300168063,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark54(15.724843261539206,-0.6252537134718903,0 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark54(15.736786019368475,-2.1665679498340955E-4,0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark54(1.5777218104420236E-30,-0.6844205633066593,1.0 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark54(15.782663414020965,-4.876287136774064E-9,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark54(-1.5797584558376059,-0.4680813903170234,-1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark54(15.821094092825284,-3.923599915275889E-9,0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark54(15.841820244719138,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark54(15.851453650178527,-0.10629084532656385,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark54(15.860889155435288,-1.0061253180075065,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark54(15.875356219178414,-0.11289693581923221,0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark54(15.877272653047214,-1.0959327284511788,0 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark54(1.5905946355385514,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark54(-15.912724932936046,-0.5226313031022923,1.0 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark54(15.931799513445014,-0.6074082504978928,0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark54(15.935306488436439,-0.17862606766572897,0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark54(-15.937940867862821,-1.1135898644039885,-61.31321052099472 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark54(15.943909526519786,-0.07531958538419836,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark54(15.94626091136237,-8.661824541059276E-9,0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark54(15.95511522939853,-0.33610308646577347,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark54(16.002774399922586,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark54(1.607446891341425,-0.17805033318765595,0 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark54(16.076997998386037,-0.8761298919625569,0 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark54(16.093348301689005,-1.3969678204025042,0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark54(16.150727286591554,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark54(16.171956501487884,-0.6772202711781805,0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark54(16.19270062813708,-1.4962896864285897,0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark54(16.193316632939958,-0.22347501329348063,0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark54(16.193531285834567,-0.0923847520768919,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark54(16.230381045910633,-0.8931787406073726,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark54(16.24071984521705,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark54(16.24090184026282,-0.2599047967946129,0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark54(16.249556679436516,-1.1198296818253013E-6,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark54(16.258394452592384,-0.23177184470388956,0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark54(16.339876730541675,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark54(16.34595623127487,-0.008287621569061529,0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark54(1.6352585547244445,-1.1260823357523866,0 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark54(16.418341673741594,-0.8895919150847498,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark54(16.422813993278027,-3.9975418567186926E-8,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark54(16.438143482236867,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark54(16.51176011529037,-4.600848418173807E-10,0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark54(16.511935433142682,-0.2050357099713409,0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark54(16.525818393389663,-0.10448672602900899,0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark54(16.558423250895473,-0.29460847959946607,0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark54(16.572381075778296,-0.9822690013536886,0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark54(1.6599810996457194,-0.46078634705018473,0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark54(16.600857009460547,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark54(1.662369224102596E-26,-1.4716965845519858,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark54(16.62468692420815,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark54(16.633338069179487,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark54(-16.68034300163137,94.91115270778693,70.9575528941808 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark54(16.689903802708542,-0.24485362182886047,0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark54(16.714845268625282,-1.2924783038811611,0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark54(16.77350917555532,-0.6230135557325025,0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark54(1.6801587383251055,-0.8985223999781624,0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark54(16.837911311370362,-0.9238998900186018,0 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark54(16.858420788893994,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark54(16.904971218148418,-0.5449144407696895,0 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark54(16.93170266852346,-0.8536846201010979,0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark54(16.93750317540899,-0.6756740128973133,0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark54(16.940942569887035,-0.11517030140608549,0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark54(16.95751281755618,-0.2497212460970612,0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark54(16.960875619045183,-0.577604614977627,0 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark54(16.980393048117744,-0.7047481212483264,0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark54(16.984125873845116,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark54(17.019465760316635,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark54(17.060992725151053,-0.10366297446225836,0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark54(17.110710439171314,-1.13497904619081,0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark54(17.175676391508652,-0.9098007718274346,0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark54(17.204221469423572,-0.19214071561006563,0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark54(-17.24558543710596,-0.2091788706092259,1.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark54(17.28681571095539,-0.8895516293186216,0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark54(17.29756287913378,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark54(17.302330276451002,-0.07933836111249226,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark54(-17.311352007683663,-2.5265238131492084E-9,-100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark54(17.31758453506012,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark54(17.346600648600358,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark54(17.36790996726695,-4.793020188133192E-9,0 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark54(17.404613815095715,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark54(17.41478432155367,-0.001074176032688974,0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark54(17.443922901517524,-0.7321605595098482,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark54(17.482395277736984,-0.5746603921903018,0 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark54(-17.490909421234967,-0.8036462388276719,1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark54(1.7492216979518247,-0.08772473213754484,0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark54(17.49728368095375,-1.092843548642789,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark54(17.49882204845532,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark54(17.513504155431804,-0.3625533075764622,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark54(17.51538156649438,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark54(1.7529942807843248,-1.0664591928872096,0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark54(17.5553832048236,-0.01567969275025405,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark54(1.759733569209999,-0.06217614829593998,0 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark54(17.604980563147947,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark54(17.60502250360591,-1.4999999999483606,0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark54(17.639488458595704,-1.4999996939735822,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark54(17.647260081372632,-0.7521871661276176,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark54(17.671616266243745,-0.031352865263627905,0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark54(17.711266611041943,-0.4047561302454066,0 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark54(17.71235825289945,-0.3625399911901401,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark54(17.71319004071168,-0.42846350007081124,0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark54(1.7713797087747278,-0.8033570614832527,0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark54(17.72074006033266,-0.3975912945116846,0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark54(17.72520263123147,-0.3378845674447941,0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark54(17.742885759426564,-6.573921368131397E-4,0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark54(-1.7763568394002505E-15,-0.9991372300991247,0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark54(-1.7763568394002505E-15,-1.0973154250035668,-2264.2344430220796 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark54(1.7763568394002505E-15,-1.203009867473613,0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark54(17.768972454597893,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark54(17.777152074953378,-0.4072172097979738,0 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark54(17.79861482345998,-0.6540899741445291,0 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark54(17.85385167930985,-4.911370644425525E-7,0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark54(1.7857250264890823,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark54(17.873129412067,-0.3047097961907923,0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark54(17.92225350915947,-0.912569084234417,0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark54(-18.00725079394468,-1.4999999999999991,-1.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark54(18.048269265412834,-0.27390418052674637,0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark54(18.049383877627868,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark54(1.805308978582874,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark54(18.06843721321099,-1.0756343707321103,0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark54(18.10158255556275,-0.37811974234420376,0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark54(18.189125604350046,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark54(18.192042702415144,-4.939919032994145E-6,0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark54(-18.240232332509358,-0.19355661565660975,-0.2996872328169179 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark54(18.24096034951421,-1.0772578266700763,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark54(18.308416843926054,-0.9620557812826466,0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark54(18.31643390238706,-8.364340173150287E-5,0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark54(18.329972180154876,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark54(1.8333119611280075,-0.6744213382738025,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark54(18.337632945429874,-0.057455563635958384,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark54(18.368887781277635,-0.0967596549723595,0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark54(18.369325347986518,-0.03450534362762403,0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark54(1.84245821002655,-3.6561883990977355E-8,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark54(18.467454957525607,-0.6999141797236357,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark54(18.473658849683304,-2.6914113132244047E-7,0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark54(1.8481273677824586,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark54(18.52371641463067,-0.6699474113486272,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark54(18.581714601306572,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark54(-18.598087021000264,-0.921511016080552,-0.06255320476554711 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark54(18.658658594536263,-0.5144150560479309,0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark54(18.70488567056606,-0.28377311651375126,0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark54(18.70955909430998,-0.2742003791775822,0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark54(18.70962190878441,-0.563105994094973,0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark54(18.719038892952938,-0.19905328598686,0 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark54(18.72080336981942,-1.128178451827389,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark54(1.872425380157332,-0.006125073765891331,0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark54(18.790381874708203,-1.117216234406335E-8,0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark54(18.819455783391618,-1.3810575777233396,0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark54(18.86561573972014,-0.4235828280971532,0 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark54(18.86909190248885,-1.4999999991382997,0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark54(18.928862842043557,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark54(18.96772959114999,-1.499999999999769,0 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark54(19.057277533358686,-0.5871746992906854,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark54(19.09778596363605,-2.2699636102679776E-9,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark54(19.147042237573604,-3.3918161683641975E-9,0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark54(19.154338046656562,-1.495966498143945,0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark54(19.170592534853355,-0.5046805263142886,0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark54(1.917755962104418,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark54(19.179140678398404,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark54(19.216080568339095,-0.999387533321943,0 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark54(19.235846714597287,-0.3805448492271963,0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark54(19.250684821004093,-1.4999999883976354,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark54(19.289124688846783,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark54(19.29583940574017,-1.4999999998865976,0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark54(19.322412662970734,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark54(19.361268490849113,-0.41800721055867684,0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark54(19.36821733360425,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark54(19.412244665638212,-0.8851429917735771,0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark54(19.428449815007717,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark54(19.451548582198235,-1.4999999993157285,0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark54(19.453707839825384,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark54(1.9467102283930284,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark54(19.47640328354568,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark54(19.48396656499267,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark54(19.506964049236203,-1.4999999999998668,0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark54(19.53015613398918,-1.200627562690212,0 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark54(19.532045123341476,-0.9321165149437969,0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark54(19.594343016292775,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark54(19.595878566433385,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark54(19.601525940515955,-0.392292570049021,0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark54(19.60251989056394,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark54(19.623539579949735,-1.3208954175699574,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark54(19.642892519124146,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark54(1.9704445446605376,-0.2728582404040756,0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark54(19.75250277512393,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark54(19.808238186977746,-6.6590933148183274E-6,0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark54(19.81007196129687,-1.217706561809055,0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark54(19.8153959336267,-0.7032332178486213,0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark54(19.847912680433325,-0.011235666996098015,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark54(19.853985062487055,-0.04005751714759764,0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark54(1.9860506211828834,-0.3086619033643103,0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark54(19.887779834412136,-0.15546870803947854,0 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark54(19.944777108362743,-0.7223737628567699,0 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark54(20.000495388381538,-0.17104159411732378,0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark54(20.000967489649803,-0.885984379732522,0 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark54(20.001991346580223,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark54(20.020843250906424,-1.4999999999995746,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark54(20.045119523891238,-7.816710171679955E-6,0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark54(20.046933342283552,-1.448139021665742,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark54(20.053294191547003,-1.499999999999999,0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark54(20.065103386584312,-1.117004834948517,0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark54(20.085406480667928,-1.3795121785055358,0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark54(20.08601965319781,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark54(20.100825978145714,-0.552298251386433,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark54(20.12807679086626,-0.13568558348369208,0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark54(20.136695544858686,-0.5617976026311187,0 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark54(20.146690361865353,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark54(20.154948938211163,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark54(20.176572782282108,-0.8465597234267364,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark54(20.18513229663685,-0.06764295682287966,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark54(20.18533103703453,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark54(20.20633738904766,-1.499999999998888,0 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark54(20.26389732888489,-0.34597087715051755,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark54(20.275090269304975,-0.1792017525482521,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark54(20.30453270147574,-1.499999999967421,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark54(2.040365594991343,-1.4999999978520884,0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark54(20.408131243282185,-1.0031314820130504,0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark54(20.41078383855192,-0.672210174315353,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark54(20.429126873794388,-1.4926183761227776,0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark54(20.45615149425622,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark54(20.473163513980182,-0.9173406907521429,0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark54(20.515416698083342,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark54(2.0519780109111423,-1.4654574456139642,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark54(20.523859410497824,-8.815382268319227E-9,0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark54(20.543028987863014,-1.4999999993436517,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark54(20.54739599787851,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark54(20.5571549147527,-0.9470163496141177,0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark54(20.561107349561894,-1.238571744852182,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark54(20.61543383446596,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark54(20.623507793680865,-3.5725767669364766E-4,0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark54(20.6346716134866,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark54(20.706612074426047,-0.508267410605468,0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark54(20.712296210089804,-0.03811038192744931,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark54(20.783289637405204,-0.6490110329339984,0 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark54(20.78362252108272,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark54(20.88123803649941,-0.5103177226539126,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark54(20.88988459498809,-1.1666022927323354,0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark54(2.093330210768284,-1.5387099096025736E-7,0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark54(20.962016403281336,-0.47643838036419117,0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark54(20.965704390881015,-0.763636666339198,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark54(20.968716992841195,-3.2819394068540315E-7,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark54(21.056995992615903,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark54(21.127455577128273,-0.20145444838641424,0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark54(21.142763394931812,-0.7381300158827877,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark54(21.148337850159308,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark54(21.16749833465513,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark54(21.17814883655536,-1.658768783521458E-16,0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark54(21.21296828045864,-0.7272618197004976,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark54(21.237398831773007,-1.3213357399767887,0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark54(21.246557166785898,-0.2386531071325012,0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark54(21.2524309394921,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark54(21.25427304406908,-1.157935051017816,0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark54(21.295409066140465,-0.8886402567733935,0 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark54(21.32737340702002,-0.8487592825898562,0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark54(21.33661253143398,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark54(21.35798043937894,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark54(21.363095613061773,-1.1431893641846669,0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark54(2.1370238020201024,-3.276542466558326E-7,0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark54(21.417197721644214,-1.4999999997731852,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark54(21.475207629892722,-0.07734872179509922,0 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark54(2.1490411705619508,-0.0033989749882442984,0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark54(21.509361682883956,-0.41372648147426805,0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark54(21.520459820796262,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark54(21.52902988722149,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark54(21.532850772427228,-0.4011548879509359,0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark54(21.535493949994503,-0.7242106368273227,0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark54(21.54219584749842,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark54(21.590932336270868,-1.0768296934312787,0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark54(21.65404921637964,-0.22583466042487044,0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark54(21.723248369622304,-2.9756942366542856E-9,0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark54(21.799697981989606,-0.4231528615525024,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark54(-21.807940908849464,-0.9054857954467347,1.0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark54(2.1812616974145556,-0.3282561101727026,0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark54(21.853030095312704,-0.6474462844178714,0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark54(21.859384885503673,-0.6553582467559522,0 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark54(2.1922483892880686,-0.04129578649269893,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark54(21.935547115703173,-0.0882439084358819,0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark54(21.9392076140411,-0.39282486774860115,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark54(21.939634433418,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark54(21.983585632878576,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark54(21.997500191811344,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark54(2.2004562629824544,-1.4999997093448172,0 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark54(22.004823791357836,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark54(22.019181649691163,-0.21188295091548132,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark54(22.0319383534263,-0.6507296504266975,0 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark54(22.036480071369382,-1.1038656559432862,0 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark54(22.06898086553359,-0.7447019430860671,0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark54(-22.07677921316211,-1.058552405634031,-1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark54(22.076899021432013,-1.0158980746291206,0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark54(22.104365391374145,-1.0170965401363714,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark54(22.111469213321303,-0.05795314240092986,0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark54(22.12743993162278,-1.4155812207009637,0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark54(22.137259769895508,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark54(22.138922665380107,-0.40164810602623113,0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark54(22.152578092724013,-1.110560585178007,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark54(2.2155153169629003,-0.7575605706669108,0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark54(22.175527014583654,-0.7883744940466277,0 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark54(22.178802714441588,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark54(-2.220446049250313E-16,-0.07441107356602654,-1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark54(2.220446049250313E-16,-0.2611747645316824,0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark54(2.220446049250313E-16,-1.0864297902985867,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark54(2.2238460839932372,-1.030639352684389,0 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark54(22.313196124813402,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark54(22.323301237602863,-0.9618677759418418,0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark54(22.333128884650264,-0.07223557514130619,0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark54(22.344121265314087,-1.3068558596806883,0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark54(22.36913465042167,-0.8519259651369238,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark54(22.378967253770227,-0.9578686817534106,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark54(22.424558007613232,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark54(22.43860486610035,-0.5459038489692356,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark54(22.46629884366058,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark54(22.49137255086157,-1.244282431343052,0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark54(22.501255488116698,-1.3852895513015682,0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark54(22.502847766759643,-0.3474676843291915,0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark54(22.50454973207383,-0.16226058411656985,0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark54(22.53219649091301,-0.01963557452686402,0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark54(2.2560145944255225,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark54(22.583419766207683,-1.2385250251016595,0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark54(22.5889481641171,-1.026001629391935,0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark54(22.690239771548498,-1.4131211049981869E-9,0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark54(22.726897764332193,-1.2447056983828062,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark54(22.739735737432625,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark54(22.783336283101036,-1.153822267657859,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark54(22.783682334456664,-0.8148526717693203,0 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark54(22.802110903476887,-0.5504667849075602,0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark54(22.806038078980137,-1.3537397433425058,0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark54(22.8135986861554,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark54(22.827170972473752,-7.681383765276076E-16,0 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark54(22.848341460833026,-0.57887926971231,0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark54(2.2852589078319934,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark54(22.855073236784136,-0.8010055273356113,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark54(-22.85815596297298,-1.4999999999999996,-1.0000004050856983 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark54(22.8638478270528,-0.9219499066902392,0 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark54(22.87762848950088,-1.4774085888429482,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark54(22.88683284585342,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark54(22.894953454100232,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark54(22.906962496819077,-0.4019459420302951,0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark54(2.2912321037426864,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark54(22.92229358886746,-0.5344200338746248,0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark54(2.293896811015147,-1.497392177575124,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark54(22.939316973100148,-0.9304722977584969,0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark54(22.94283057562029,-1.0942943057111172,0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark54(22.943454430406575,-1.4999999999236326,0 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark54(2.2949577255321856,-0.3444474233501751,0 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark54(22.953994616803215,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark54(23.025928559740287,-5.012584444180315E-9,0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark54(-23.047285225356006,-0.3021679936897256,-34.989067732060306 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark54(23.049929131788275,-0.7235416187880039,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark54(23.059108622622393,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark54(23.066698027299992,-0.10963608792671664,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark54(23.092575984613163,-1.0420161978324698,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark54(23.174505440151734,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark54(23.19317150097094,-0.7547967037783092,0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark54(23.211421784673902,-0.3685551848591473,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark54(23.21971209605576,-0.7352736932153917,0 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark54(2.322363581553466,-0.3039710945471358,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark54(23.24394090203321,-0.44960972799357535,0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark54(23.271464159312416,-1.011300511528125,0 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark54(23.319710849564377,-0.7543836404425868,0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark54(23.358420282228593,-1.399844771343183,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark54(23.36911239114778,-0.26916447699169277,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark54(23.385326139369525,-0.9225499294106498,0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark54(23.411597193146207,-0.01444105008631813,0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark54(23.470498512665852,-0.48512188198339645,0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark54(23.472889115637525,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark54(23.47937857799414,-1.2508218916977683,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark54(23.577628261434526,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark54(23.586482144289793,-1.2166056852112657,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark54(-23.59585431270277,99.5224887294531,71.11145414867914 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark54(23.646211262376895,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark54(23.711411308096544,-6.9339517193121714E-9,0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark54(23.73538325862296,-1.3739638648584016,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark54(23.736914164709717,-0.5267846506806535,0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark54(23.76965773280142,-0.4447971537244584,0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark54(23.821490593361688,-0.10392858012775186,0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark54(23.8240576292672,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark54(23.837686961161122,-5.2104715044538826E-5,0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark54(23.838016170619156,-0.02087937300287715,0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark54(23.86824003543242,-0.4268532806986949,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark54(23.921800615540675,-1.0333475413603075,0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark54(23.95459913323492,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark54(-23.972444231322925,-1.3089044460221548,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark54(23.985029116851784,-0.3782723638772334,0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark54(24.010310085578936,-0.27347229080389024,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark54(24.05254753771797,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark54(24.058723746003068,-0.9381934147015425,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark54(24.0654558326663,-0.1363610674978648,0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark54(24.067874885546473,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark54(24.071973078692622,-1.0464038962643725,0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark54(24.124795995263117,-1.1839588784751696,0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark54(24.127942648759515,-0.03367320596898066,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark54(2.4142976234546882,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark54(24.15931658701707,-1.3201036058917435,0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark54(24.166041013474523,-4.937669960150301E-10,0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark54(-24.177886463368868,-3.876425650188198E-9,-33.182880773590696 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark54(24.186450244043527,-1.4999999999999938,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark54(24.249911357989134,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark54(-24.262474503512564,-0.5818881498778268,1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark54(24.26848710415762,-0.4154118749779413,0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark54(24.26867281101444,-0.6360268055822756,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark54(24.272735795504236,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark54(24.28443001251582,-1.1991608588816076,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark54(24.28988803269925,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark54(2.4301233150590775,-0.3057590553048704,0 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark54(24.340021259373227,-6.514909669635433E-10,0 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark54(24.344436092019226,-1.4763505464513669,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark54(24.35773117100658,-1.095751237044908,0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark54(24.389117002354183,-0.4737162683892956,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark54(24.412142879606982,-0.2764759351273186,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark54(2.441677804461648,-1.1570488292034469,0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark54(24.42450244184053,-0.2546307357232043,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark54(24.462917508114245,-0.6481759339498581,0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark54(24.463244737497945,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark54(2.449321932634687,-1.080621080329498,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark54(24.499481197523373,-4.307584658007381E-9,0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark54(-24.515508145056344,-0.7457324668488209,-1.0 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark54(24.522958682588808,-1.3290600461734527,0 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark54(24.528788966087347,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark54(24.535021764287826,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark54(24.540622073664643,-5.759626774931993E-8,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark54(24.575594694295972,-0.8429259396260989,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark54(24.583585558735294,-0.12547859745392148,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark54(24.598804768731178,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark54(24.62281742152625,-1.1329533467522506,0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark54(24.668908404701178,-4.2775649052996475E-10,0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark54(24.67667401809244,-1.456508389685677,0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark54(24.72380800674115,-1.4947126188992255,0 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark54(24.750019678676694,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark54(24.839845029698935,-1.4999997051796166,0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark54(2.484889693074834,-0.945706824195109,0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark54(24.893609923167865,-0.1323734509903458,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark54(24.91519764815967,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark54(24.920024439015158,-0.09582778853922935,0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark54(25.02328571753054,-1.3600454006789897,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark54(25.027429085137506,-0.5223902513553946,0 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark54(25.073210786980525,-0.2332871141811701,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark54(25.08192457662425,-1.376510426756349,0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark54(25.091910092993743,-3.974812295768748E-17,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark54(25.104423529162457,-0.6710220753102281,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark54(25.107196248974198,-0.36285683945312996,0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark54(25.133019178429322,-0.5388130388739056,0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark54(25.17144118166472,-1.3559007618831438,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark54(25.173984008707222,-0.10587187845894164,0 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark54(25.181092937095677,-0.03179605102722064,0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark54(2.5198292057900744,-0.8721388950713281,0 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark54(25.208154017830523,-1.2437402129757257E-7,0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark54(25.237918279311344,-0.16590641337467915,0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark54(25.28979208318529,-1.4705955869593987,0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark54(25.34936122674635,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark54(25.368479617561835,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark54(25.38483175582536,-1.4999999999999307,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark54(25.409094748752082,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark54(25.423184705979637,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark54(25.456359221917708,-0.07367661014850113,0 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark54(25.468846205456703,-1.4072949510974695,0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark54(25.523003952523275,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark54(25.52803579087321,-0.8226762219557813,0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark54(25.535082282096635,-0.9676368442146376,0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark54(25.552711900890856,-0.4953145685311966,0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark54(25.568086929836994,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark54(25.56969953842303,-1.0464049012358665,0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark54(25.61491178162902,-0.8038949326239049,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark54(2.5627206338143083,-0.24325453796557017,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark54(25.62979317154644,-0.5452707838484148,0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark54(25.66383055491019,-1.1425806244248156,0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark54(25.7352200082956,-1.4344982033489226,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark54(25.818944408056836,-0.8666638710778218,0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark54(25.822317200479716,-1.135319830393371,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark54(25.898383367410396,-1.499999929917964,0 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark54(25.904639345383835,-1.4953944282844147,0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark54(25.92448567763151,-1.2662486436097034,0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark54(25.935367037065404,-0.28569623375289055,0 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark54(25.969862931953642,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark54(25.973847537136123,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark54(-25.98088488514447,-0.9529489672009306,25.497733012946135 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark54(26.016836441472954,-0.47326703266596715,0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark54(26.026547549747406,-1.4925090813141342,0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark54(26.053366648664266,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark54(26.067027723294473,-0.48913706275412683,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark54(-26.067758299319628,-0.1771256997642161,1.0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark54(26.072513564664717,-0.6205485495532059,0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark54(26.119360778612656,-2.1620247759086995E-9,0 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark54(26.120096545138694,-0.5121352480981045,0 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark54(26.12948225695478,-0.2923949760411979,0 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark54(26.131747848385473,-0.5591917815851726,0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark54(26.147725800436675,-0.7469441621034583,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark54(26.20269389365251,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark54(-26.21644046349793,-1.7015230957233828E-6,0.7273292295887851 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark54(26.220110298177772,-0.23014459727199998,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark54(26.22969486306568,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark54(26.24493757923362,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark54(26.264102029762462,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark54(26.305307579922747,-1.4999999997756555,0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark54(2.634143889865541,-0.03238019695174588,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark54(26.429943051225905,-1.2755809051466154,0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark54(26.4379287552826,-0.6557599918213315,0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark54(26.460624742603486,-0.5946820314565757,0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark54(26.46883239675958,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark54(26.510053196349116,-3.1012857506272533E-7,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark54(26.54173560345805,-0.23811417496223974,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark54(26.54190574708312,-1.258102446393682,0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark54(26.548627772786276,-0.17344716391781834,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark54(26.596675493584243,-0.9052821220380407,0 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark54(26.660551239095625,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark54(26.720048862932323,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark54(26.724134432332043,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark54(26.729090942717363,-0.3108617756528531,0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark54(26.812507977275587,-0.1435080859062623,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark54(26.830014872344577,-1.4999999999995843,0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark54(2.683131386970473,-0.4071153286243909,0 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark54(26.858941415713232,-1.3232818453632866,0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark54(26.865553206049317,-0.21886123197205093,0 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark54(26.87023390127679,-1.3521170720505875,0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark54(26.871209829064895,-0.35866999879694106,0 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark54(26.87984659430353,-1.3891856800572633,0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark54(26.89088285560551,-1.3130885079353016,0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark54(26.892983485608063,-0.07448706524574934,0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark54(26.915889238649847,-0.06479141163347957,0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark54(2.6919874070129737,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark54(-26.94087697087045,-1.3941101936403064,-2.3534373682645353E-184 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark54(26.944438579406224,-0.9309123929981495,0 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark54(26.94800036319978,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark54(26.968285142869277,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark54(27.008427357441136,-0.39017337831547394,0 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark54(27.02189367950472,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark54(2.7046308996738126,-0.1765789375163283,0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark54(27.066043330163247,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark54(27.076012685578803,-1.3094334234195526,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark54(27.12685044066734,15.793791927448837,66.09294200061905 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark54(27.228056764196324,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark54(27.230673905359556,-0.43840340992653126,0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark54(27.249108285906914,-0.8520055244112424,0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark54(27.274340695005023,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark54(2.7305168359362852,-1.1844894555352812,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark54(27.319697149784147,-0.8844645367331054,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark54(27.326845637849928,-0.0506256887975951,0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark54(27.36407569120434,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark54(27.37366306049843,-0.222681933680966,0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark54(2.738388781655928,-0.017700604977738434,0 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark54(27.411483034748933,-0.0035084450101607128,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark54(27.417848089692825,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark54(27.423641282462484,-0.8499461641104231,0 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark54(27.442026349285257,-0.989878957243306,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark54(27.44827144373835,-0.14881140747451438,0 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark54(27.44914457474564,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark54(2.745746691810183,-1.49250358173475,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark54(27.51430904749258,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark54(27.517529757191824,-0.013431147432698753,0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark54(27.528891174861883,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark54(27.565449966129677,-0.5611323044713206,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark54(27.585874074762156,-0.25063008736879716,0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark54(27.586612631233486,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark54(27.601595972206255,-0.967205513787798,0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark54(2.7611191514340447,-1.2361853861698844,0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark54(2.761422909543299,-1.2175005009822648,0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark54(27.652793919875563,-1.377394860360301,0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark54(27.677351523373034,-0.29146751204916654,0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark54(2.7679207294315322,-1.4999999808633204,0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark54(27.70520317510797,-0.03059796942300319,0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark54(27.70620997314025,-0.46106027385403603,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark54(27.719640285893504,-1.3599114984974268,0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark54(27.734236761313888,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark54(27.748044820111087,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark54(27.756778519731768,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark54(27.76979043845104,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark54(27.77649655268884,-0.9002219420907238,0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark54(2.7791301910249206,-0.5009152263355762,0 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark54(27.843138227593418,-0.9948381247337785,0 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark54(27.862039186048463,-1.0826229645034862,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark54(27.873911879123938,-0.21382408011834197,0 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark54(27.92911005150249,-0.38135361684382474,0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark54(27.9554279431932,-0.30318823546629536,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark54(27.972565004227505,-0.5485486657129881,0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark54(27.98022546323797,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark54(2.801468901866315,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark54(28.01596874951602,-1.195921194045951,0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark54(28.016867369888388,-1.4210324514733934,0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark54(28.026619217511097,-1.2165140461923158,0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark54(28.050515636463246,-0.46530005619628234,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark54(28.053826899509026,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark54(28.076701995996192,-1.4994464206253018,0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark54(28.092238724085547,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark54(28.10500198372469,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark54(28.110120911822435,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark54(2.8166751267428207,-0.16138886576399614,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark54(2.818258409592171,-1.46279788549337,0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark54(28.198344580586642,-3.031847966603484E-8,0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark54(2.824619627172029,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark54(28.276274121371017,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark54(28.311279944992734,-5.071708727781465E-7,0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark54(28.3347089896875,-1.3579728907837838,0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark54(28.34099120255111,-1.0512252699178541,0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark54(28.345634462358802,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark54(28.45097407399178,-0.7644254276090714,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark54(28.475805760991165,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark54(28.5050776015172,-1.218013673555232,0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark54(28.57574645447818,-1.499999999999988,0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark54(28.582102638417297,-1.0429056174838243,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark54(2.86591898108,-0.4971854963956609,0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark54(28.688113246977366,-0.955690630327601,0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark54(28.69256127889099,-1.325484165826822,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark54(28.700336347265818,-0.309418920623322,0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark54(28.71054679651295,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark54(28.754966873220752,-0.21906966634301828,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark54(28.781457346440874,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark54(2.88038942359721,-2.7585929517086563E-9,0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark54(28.804878027853817,-1.476579577569626,0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark54(28.810395441504824,-1.4999999970575273,0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark54(28.813750005324508,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark54(28.884312008211225,-1.480714382811411,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark54(28.886292676977853,-5.928127956430571E-9,0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark54(2.8895420701676926,-1.0054137726411403,0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark54(28.93493515004336,-0.8957993827334221,0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark54(28.950684448210087,-0.2437052311049397,0 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark54(28.96920065829316,-1.4999999999999467,0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark54(2.8977652863047467,-0.6697609375476645,0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark54(28.978058030395403,-1.2235513565104292,0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark54(29.015403952979995,84.15216693560049,68.61520830629894 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark54(29.016318006159203,-1.4999999920936449,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark54(29.01802420621769,-1.2258328058172954,0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark54(29.053625779201894,-0.33764185537809493,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark54(29.067915197529977,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark54(29.06839408488392,-0.41873435977204565,0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark54(29.088080155191875,-0.16522126822057837,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark54(29.09514751217509,-0.11175780062912422,0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark54(29.128193217232536,-1.0633472502161191E-9,0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark54(29.141222446666216,-0.7542543685296073,0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark54(29.163969707412775,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark54(29.166290824397777,-1.287903456164134,0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark54(29.178749776731706,-1.0658879327052517,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark54(29.238096500635066,-0.5798303473626447,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark54(2.9248627956632873,-0.21902672196048378,0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark54(29.262937225326883,-0.2766253356188724,0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark54(29.347026209955516,-1.036407208826149E-4,0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark54(29.34857756267766,-0.6700782719389113,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark54(29.36324595318959,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark54(29.377576964308957,-1.3150343033333343,0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark54(29.378152018683636,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark54(2.93818632802936,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark54(29.414787929967957,-0.9924047145089199,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark54(29.451175242369402,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark54(29.457434782136666,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark54(29.457947523945588,-7.682561159390733E-10,0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark54(29.54854284858854,-1.038507354049429,0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark54(29.568936407177517,-1.4999999999999796,0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark54(29.615571950573667,-0.0658258943583796,0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark54(29.63238353832684,-0.47000082358995354,0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark54(29.63537760740318,-0.4408763965777496,0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark54(29.636077324457432,-1.4094329931440046,0 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark54(29.671318194708807,-0.15269729214972894,0 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark54(29.69307998369491,-1.499999999999993,0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark54(29.70848473635826,-0.4490834316351122,0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark54(29.73233052938578,-0.3126977946352447,0 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark54(29.758533560193115,-1.499999999837942,0 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark54(29.76761119435535,-0.28212625350859843,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark54(29.818660084802058,-1.1342352697510192,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark54(29.88916060902406,-1.1184422545786914,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark54(29.935750751946564,-1.7631177679820151E-9,0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark54(29.940356844522952,-1.0645930628452764E-8,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark54(29.99945694805095,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark54(30.002900988904656,-0.3536494464601743,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark54(30.023623977487794,-0.6848252359662964,0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark54(30.038299585127593,-0.4507281708113595,0 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark54(3.004411665427426,-1.3457988749611642,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark54(30.09514740126258,-0.11490772379646608,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark54(30.105059095990367,-3.560355837439264E-4,0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark54(30.109643993543017,-0.332647475356751,0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark54(30.124308813676862,-1.024408240018694,0 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark54(30.131853080952506,-1.2665853035212162,0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark54(30.162008547063486,-1.307853217869684,0 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark54(30.182497678145182,-0.09700275233768885,0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark54(30.213779377959384,-0.09908978067427654,0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark54(30.218095552008393,-0.8742038263897944,0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark54(30.220451834865813,-0.13141956447624636,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark54(30.2209799608007,-7.060347602734326E-6,0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark54(30.239566518276774,-1.2652595803317297,0 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark54(30.246923701513005,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark54(30.265440864935645,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark54(-30.27916872642158,-0.1407429257690796,-1.0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark54(30.328622885170148,-0.41363425698951384,0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark54(30.391166635152185,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark54(30.403455218417488,-4.23833707748232E-9,0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark54(30.411855568208836,-0.9337025805186219,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark54(30.43688570655695,-1.489260485740445,0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark54(30.472486023857726,-1.1319188530188593,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark54(30.497255064348344,-1.4257118227984547,0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark54(30.504067320910906,-1.1621008359227005,0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark54(30.507732576206497,-0.4044929259442194,0 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark54(3.0508353837052455,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark54(30.554432440995146,-0.4734739526863099,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark54(30.571761953673896,-0.3914204551612054,0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark54(30.583121243732897,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark54(30.63763883162963,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark54(30.657970686848444,-0.3530142200136329,0 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark54(30.66387494319872,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark54(30.721351464857435,-1.1753794243409459,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark54(30.728424911393375,-0.4452441258771387,0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark54(30.729162635630644,-0.3098812438370002,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark54(30.748079179287345,-1.1503069175556737,0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark54(3.076314221056693,-1.3960951147788154,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark54(3.077891959403745,-1.4999999998776485,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark54(30.79627941178387,-0.03258540384312525,0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark54(30.8121158232631,-1.0851078655269788,0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark54(30.81411365831201,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark54(30.9024371378293,-0.7441941361554996,0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark54(30.908602612797722,-1.0185102994963557,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark54(-30.941897355980743,-1.4959532668052744,-0.7972070734060877 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark54(31.00053104271055,-0.8914754223238672,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark54(31.018082102593638,-0.7298889075538995,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark54(31.022408603397622,-0.37490086955831714,0 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark54(31.024378238220095,-1.4822867029125764,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark54(31.03512250240835,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark54(31.05062900823941,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark54(31.061461193719936,-1.3532355391242392,0 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark54(31.061539785198644,-1.3033018930672369,0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark54(31.095131448712493,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark54(31.179462780644997,-0.8709964163517965,0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark54(3.1201523759307292,-0.7056496417193516,0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark54(31.218328871354647,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark54(31.22179897512835,-5.6875374399509235E-8,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark54(3.1256161342750204,-1.258952835657797,0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark54(31.257332081066522,-1.184092037014544,0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark54(31.30451168887032,-1.3585979667143135,0 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark54(31.30491444039683,-1.4576093429592056,0 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark54(31.323436433015864,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark54(31.353664431736327,-0.177545192415763,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark54(31.361857662871472,-0.3877928697713138,0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark54(31.36740573323047,-0.44018160071752277,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark54(31.39182226198804,-1.3317091255865765,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark54(31.422414510102243,-0.6982725462387975,0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark54(31.46879208519786,-0.3420720991392736,0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark54(31.47402543412003,-0.9592025183939663,0 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark54(31.48057871494222,-0.9402330628728457,0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark54(31.487653876809503,-0.24795285776666276,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark54(31.49861918358431,-1.3476934996573418,0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark54(31.50357337138928,-1.4187813146038937,0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark54(31.53479697372354,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark54(31.543153638593957,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark54(31.562697283025557,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark54(3.1565372101690525,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark54(31.565626033230032,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark54(31.594382284509123,-1.213827163135221,0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark54(31.601325223642647,-0.004857726081056057,0 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark54(31.607657822024613,-1.4999999998089308,0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark54(31.60846437226904,-1.422068851296323E-9,0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark54(31.615079495358298,-1.3787979752308776E-4,0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark54(31.66195285280773,-0.5769105533938652,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark54(3.1684528748495495,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark54(3.1692923032960607,-0.657414352154845,0 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark54(31.695719606828217,-0.034220668855797116,0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark54(31.70226345953661,-3.181177511544539E-8,0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark54(3.172978593710597,-1.4685940370979727E-8,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark54(31.795156270695397,-0.8501401616347309,0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark54(31.79652216500162,-0.7199882568215124,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark54(31.804388625890823,-0.9617476945941235,0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark54(31.834314516224197,-1.3615273485894943,0 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark54(31.837305110338832,-0.6027413252843417,0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark54(31.86293301219925,-1.2453560377042279,0 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark54(3.1880316260050243,-1.4651102656225948E-9,0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark54(3.1889681414163196,-0.7261205706523643,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark54(31.945707676978543,-1.3565120458824156,0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark54(31.963209496035518,-0.27785541901066324,0 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark54(3.1967263757700835,-0.4748662849903888,0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark54(31.979157017852003,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark54(32.07255380683609,-0.48857035643105584,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark54(32.0792047614805,-0.4000329112670684,0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark54(32.08188015319914,-0.4194909192091254,0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark54(32.0858540722202,-0.7260531188003829,0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark54(32.09600703445,-0.1670256524767666,0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark54(32.10827636749292,-0.46037323821320086,0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark54(32.14484911265781,-0.023752421226436005,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark54(32.153435212156936,-0.34186528461767823,0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark54(32.18722587123938,-1.2612852577823657,0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark54(32.193354092100414,-2.0499449541252527E-6,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark54(32.25468429314972,-0.0635034306361959,0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark54(32.25876100578441,-1.3460767184908873,0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark54(32.259070221436986,-0.43620621666045367,0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark54(32.27176152477687,-1.0491059685925945,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark54(32.292687021052075,-1.2707608077249728,0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark54(32.2936787951717,-0.8408179270432483,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark54(3.234255399227381,-5.186916374904724E-7,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark54(32.35645742136286,-1.6912070090057263E-9,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark54(32.358678360878685,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark54(-32.37329813614596,-0.1225662414141322,1.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark54(32.378553303670046,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark54(3.2379E-319,-0.49178090891938864,0 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark54(32.38414617612989,-0.043630891813645226,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark54(3.2451498311050386,-1.0905863229603077,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark54(32.456639780740495,-0.42317540105066054,0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark54(32.51874395792805,-1.2855150030850666,0 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark54(-32.532842610572146,-0.20823986337435987,0.9999991421793774 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark54(3.255828510278974,-0.9444023971395126,0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark54(32.56747989235032,-0.6727018083764813,0 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark54(32.57295196257294,-0.00776749490886941,0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark54(32.5788400021044,-4.75235208055278E-10,0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark54(-32.62787477918693,-3.993671024609239E-7,-100.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark54(32.62841285826773,-0.6974068162015238,0 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark54(32.62886198817404,-0.5030790272312844,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark54(32.71385403930512,-1.499999999999929,0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark54(32.72264579701231,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark54(32.73178038305953,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark54(-32.758368615066956,-1.2239859625597234,0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark54(32.811823145291825,-1.4838740480042003,0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark54(32.840456682148016,-0.9651543498751014,0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark54(32.8807561523125,-1.2769033905204594,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark54(32.88195087119008,-4.772730857232127E-9,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark54(32.88489533379246,-1.21789565610122,0 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark54(32.89387916774718,-1.18038782553965,0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark54(32.930633836242485,-0.6049914182081837,0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark54(32.961536547265155,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark54(32.99703692762489,-1.299834199102774,0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark54(33.011655471227215,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark54(33.056549900851394,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark54(3.306109861337533,-0.26612999690005057,0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark54(33.069986543962244,-0.08480261905496844,0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark54(33.07652813374456,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark54(33.094220908526665,-1.499999999866987,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark54(33.134510842182095,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark54(33.15511954529131,-1.130940171621459,0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark54(3.3181992769697217,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark54(33.19324240502859,-3.968654218841466E-8,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark54(33.20402636690308,-0.705078727247955,0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark54(33.20655610503232,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark54(33.22684507002813,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark54(33.229544369768234,-1.2778449547625144,0 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark54(33.266703597195345,-0.14407330593869005,0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark54(33.26854645545774,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark54(33.27908368168164,-1.0320665339714026,0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark54(33.282754962207406,-0.10460320328394346,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark54(33.29465846756358,-0.019983169574585347,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark54(33.30777839662907,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark54(33.39468011287829,-0.7752170328795742,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark54(33.43259314327025,-0.7177586919687684,0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark54(33.435331669837694,-1.178697796866885,0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark54(33.452596495411655,-1.4999996010674437,0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark54(33.511873815079525,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark54(33.60986054097571,-1.4713607514160554,0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark54(-33.61127965073828,-3.8965409383649136E-5,0.5086543525222876 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark54(33.63812324606988,-1.091980745905488,0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark54(3.3642105187025244,-1.1325262518368273,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark54(33.72060345270381,-0.46939856412157477,0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark54(33.722756875782125,-1.2175957573208933,0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark54(33.733079439575164,-1.0670193691361984,0 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark54(33.76014191636045,-1.1921130627096517,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark54(33.76839831752339,-6.190612647393405E-10,0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark54(33.772065151555395,-0.6247060469674801,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark54(33.78292261237411,-0.32013436862170863,0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark54(3.3795185088096815,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark54(33.81064630777007,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark54(33.81764631306689,-1.2173887260942706,0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark54(33.839258868720876,-0.597392193991292,0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark54(33.857428590187745,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark54(33.872716807750386,-0.024966907095528068,0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark54(3.3899157786711935,-0.011861703665247155,0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark54(33.90926931253801,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark54(33.927733326946296,-0.09278974049503523,0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark54(33.929818959646894,-1.4098198479657462,0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark54(33.930360028964316,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark54(33.943598793607315,-1.3605884882866475,0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark54(33.94424009539455,-0.17012742062660058,0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark54(33.949077851162656,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark54(3.4000373383545224,-0.5001335763201293,0 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark54(-3.4007321111213815,-1.4999999999999998,-0.8810569327445705 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark54(34.0480601600171,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark54(34.07091441286464,-1.1182978042594793,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark54(34.092331135608845,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark54(34.120130549405076,-1.177069923920485,0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark54(34.165611439701244,-0.70015846722282,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark54(34.1732550634828,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark54(34.181533517550406,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark54(34.19276240277376,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark54(34.219310377737614,-0.7887079651113161,0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark54(34.22535684729496,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark54(34.28617919241319,-0.34544463563550565,0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark54(34.291129520868225,-0.9357799671353488,0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark54(34.297813159715666,-1.499999995696518,0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark54(-34.31525190379325,-1.4795825313052156,-1.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark54(3.434201324421096,-0.7184837357936175,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark54(34.39414755997059,-0.693006722295062,0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark54(34.44815275406938,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark54(34.48059274323549,-0.5026024183544848,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark54(34.53760018893962,-0.1197470855929268,0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark54(34.55975981461913,-1.0408004160969142,0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark54(34.56189437451858,-1.2471048701911707,0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark54(34.58159479025369,-0.6547405797968224,0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark54(34.661445649486154,-0.12461001699280222,0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark54(34.661653732628565,-1.405313824213002,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark54(34.71987205762434,-0.335809427739276,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark54(34.72515446068148,-1.4999999038344125,0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark54(34.7302398337676,-1.1768030292731027,0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark54(34.739427297899425,-0.7546121594822286,0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark54(34.740604392488706,-0.8729958927190644,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark54(34.794071752352664,-1.2934965782647794,0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark54(34.80809011865321,-1.4999999999999503,0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark54(34.841077559343056,-0.9580076257958815,0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark54(34.85515503693685,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark54(34.90459546394847,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark54(34.979453168101315,-0.3131880871629784,0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark54(34.980079622733584,-0.784665986826844,0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark54(34.9897234278678,-0.1682424932215656,0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark54(3.504401443860033,-1.272498945120773,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark54(35.06265352526718,-0.37457276864310673,0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark54(35.07862965130525,-0.16856292783083515,0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark54(35.09048612780812,-0.18127227153152353,0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark54(35.11093256821752,-0.45958219586350424,0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark54(35.11186249923068,-1.4181649267557077,0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark54(35.13555986940028,-0.12947092790551729,0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark54(35.13909997300167,-1.4419335208919533,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark54(35.14048974406879,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark54(35.15281925904591,-0.0012700371202605254,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark54(35.16010594294099,-0.08628273755417971,0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark54(3.5167273027343953,-1.1581271979924113,0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark54(35.18661357858897,-1.490920865945864,0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark54(35.238449477049,-1.4837048786417766,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark54(35.25773547748598,-0.937451149131955,0 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark54(35.264700690452514,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark54(35.266378395126,-1.047509869097638,0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark54(35.30957563468749,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark54(35.31638925551561,-1.1719985592602635,0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark54(35.32291716560529,-0.2704414470421319,0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark54(-35.34502211646096,-1.4999999999999998,-3.3004333291072454 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark54(35.355287817985094,-1.3240228990287024,0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark54(35.36451816311387,-1.2513330558432347,0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark54(35.374051625396675,-0.04692682147525161,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark54(35.4035950605074,-0.09692699104254321,0 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark54(35.41671314344467,-1.4392529459740098,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark54(35.436265091969,-0.3246695901851808,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark54(35.436716594248,-1.4077339344853215,0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark54(35.453033565011054,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark54(35.4784226139192,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-1.0523665496564567,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark54(3.552713678800501E-15,-1.412685089136537,0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark54(35.53293864672074,-1.002384021387087,0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark54(35.5333619102575,-0.5894256096832633,0 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark54(35.579754489602,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark54(35.58288943359105,-1.1675245750773735,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark54(35.5998595385592,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark54(3.560848649219267,-0.7292889892919021,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark54(35.61212578484819,-1.4910820093794994,0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark54(35.61998291508465,-0.15104542350964933,0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark54(3.563188068655571,-0.405603916752652,0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark54(35.655844617567176,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark54(35.667087655871455,-0.652161143715575,0 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark54(35.66754586733987,-1.4369345331658074,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark54(35.689847880415414,-0.7726101434157862,0 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark54(35.69617501496421,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark54(3.5701742889202057,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark54(35.76387356515207,-0.7981414226665391,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark54(35.76774522127564,-0.15142763528663572,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark54(3.5785223521750993,-0.35393901028022867,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark54(35.794318451148456,-1.32202043464483,0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark54(35.87253664729522,-0.4203389100714891,0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark54(35.87624793329053,-1.4999999999997975,0 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark54(-35.94496024388698,-54.006925384177286,89.50911021800172 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark54(35.95103382493397,-0.3947634458763929,0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark54(35.95646924796719,-1.48484923598103,0 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark54(35.96734267297364,-0.6736432783490525,0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark54(35.98816955675122,-0.7390906239863115,0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark54(36.02609651248872,-1.3396124163729297,0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark54(36.05918737569772,-0.5770036314093545,0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark54(36.07371280446321,-0.5903853054126671,0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark54(36.084773309318436,-1.2470478634746556,0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark54(36.12082959095611,-0.10056289651347405,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark54(36.15629506749494,-0.914489410561016,0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark54(36.1661748864114,-0.9362549887806324,0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark54(36.171198020737634,-0.11968778749182145,0 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark54(3.6216442414613628,-0.02555122873798584,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark54(36.237325111999255,-0.8582402326927969,0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark54(36.30473257721254,-1.0340686322597499,0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark54(36.31048631370345,-1.4683047281226465,0 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark54(36.32336549814187,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark54(36.334150970322156,-0.16572155532633825,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark54(36.33600418680339,-1.0617798866963915,0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark54(36.34987277568172,-1.1603207222169045,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark54(36.36119274375578,-1.3155649951559778,0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark54(36.411844580886026,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark54(36.41315093792774,-1.461197631326196E-8,0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark54(36.41318356711773,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark54(36.41378388566186,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark54(36.419299530138524,-0.7857366682917668,0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark54(36.426448225864846,-0.20021048446360623,0 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark54(36.450292526141496,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark54(3.646184470348743,-1.1611180795903886,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark54(36.47642325758659,-0.5856327013061806,0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark54(36.48480281054094,-0.8419674735953642,0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark54(36.49211752829203,-0.4261690287948916,0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark54(36.49568387762321,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark54(36.511191222438896,-0.4912417763636231,0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark54(36.53378833947136,-1.4742699143236384,0 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark54(36.57329148268124,-1.3789385040682411,0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark54(-36.60415316763419,-58.83498531152726,89.0513466915296 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark54(36.61103211801491,-1.4114867886518323E-9,0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark54(36.63915754928172,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark54(36.65818185465038,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark54(36.7176237916043,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark54(36.75045189633104,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark54(36.777870830876566,-0.5730103072253376,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark54(36.782517334321625,-0.028238819124486447,0 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark54(36.80050394528399,-0.5364382705377109,0 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark54(36.80138821663365,-0.2919854715526617,0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark54(36.82482818945206,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark54(36.828253502069344,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark54(36.831363771020136,-0.4379084526797641,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark54(36.83907422867912,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark54(36.904738822499304,-0.15937141298520818,0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark54(36.91688000366722,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark54(36.919526088873795,-1.310485624350585,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark54(36.96566635235919,-1.4048810657207442,0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark54(36.975303779292624,-1.392844449457798,0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark54(36.99612141244185,-1.0339935617888782,0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark54(37.01182267318049,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark54(37.01236061537776,-1.2562641010182745,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark54(37.029365150143725,-4.1470578244653553E-10,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark54(37.048793250361776,-5.2025645693680214E-8,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark54(-37.105054497990054,-1.4999999999999996,0.05510722857290449 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark54(37.11471382615835,-1.0739089431567548,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark54(37.12432856681186,-1.2488218619964342,0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark54(37.12902177525507,-0.6410362698618997,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark54(37.13274280820863,-0.2350543829734118,0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark54(37.13292586525038,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark54(-37.17930766934938,-0.5769198249117252,1.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark54(37.223804026352674,-2.3485003826612443E-9,0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark54(37.26013422125985,-1.0801977415660433,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark54(37.289344489458074,-0.6214511640607967,0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark54(37.29754659989695,-0.35518712400147834,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark54(3.7307536731441218,-1.2017122963698523,0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark54(37.31745441170263,-0.4826064838701445,0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark54(37.32305097913485,-1.1218538126541617,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark54(37.40763260908972,-1.19013596556524,0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark54(3.7423969883320893,-0.3840729948682977,0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark54(3.750524736265074,-1.0132061447460683,0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark54(37.51848498369702,-0.8137128518204981,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark54(-37.57127615064009,-81.11334172050474,49.54954558353876 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark54(37.578264760514315,-0.24871909942092785,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark54(-37.58922718707576,-1.4913975178005965,-1.0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark54(37.59745950660488,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark54(3.763315171809893,-0.3930202456781269,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark54(37.63677024047149,-0.759937383620024,0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark54(37.65123567588256,-0.07107527485994503,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark54(37.660372027095946,-51.28562623431978,3.6858053024564157 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark54(-37.668438654753814,-1.1102230246251565E-16,-66.38694618127776 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark54(37.748246725932546,-0.10593524274255306,0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark54(3.7751450257809616,-1.743843100186581E-7,0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark54(37.79638318296122,-0.5996471097431759,0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark54(37.800083511873595,-0.03324081619513308,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark54(37.81975234334555,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark54(37.84051000189319,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark54(3.7842951289965354,-0.671817824075517,0 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark54(37.85442546769413,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark54(37.88825903255753,-5.456136921023567E-8,0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark54(37.89668359219879,-0.28245556039143105,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark54(37.931282005591655,-1.161768311262278,0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark54(37.9748637937663,-1.4738900260854733,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark54(37.982747372315174,-1.2789374892606418,0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark54(37.986489060888374,-0.5108845704840292,0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark54(38.05314321381951,-1.208956660576861,0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark54(38.10642093305188,-0.7680813199682888,0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark54(38.10664343321588,-1.3967231359583394,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark54(38.143656607983104,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark54(38.16984731812645,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark54(38.178199799459804,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark54(38.18724960642944,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark54(38.28246063699356,-0.6160168258362385,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark54(38.28821997883288,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark54(38.289128222451936,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark54(3.829827615988819,-0.9630110298029733,0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark54(38.3332445339077,-0.02455951036590065,0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark54(3.8373014925884235,-1.4468151327366598,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark54(38.37619786643424,-1.4416882040394836,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark54(38.37694572405765,-0.09031558069465717,0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark54(38.37850540981913,-1.4252652555064174,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark54(38.3921351851819,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark54(38.397121494429186,-1.2443788759305796,0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark54(3.842383477617828,-0.8696700786796558,0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark54(38.42813856316091,-0.23726015170528253,0 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark54(38.45986287354745,-1.2990051744444688,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark54(38.465550824010656,-6.8820216084534875E-9,0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark54(38.475496372871504,-0.8678578952414568,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark54(38.47905494909023,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark54(38.510861060345405,-0.05464210332428365,0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark54(38.5870459324623,-0.4009227167244127,0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark54(3.8588987243195128,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark54(38.59733672871437,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark54(38.73041219009908,-0.9250278746501052,0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark54(3.873989993987525,-0.33859957300750065,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark54(38.74035662430822,-0.6082641706144463,0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark54(38.756720518521234,-0.5144165065460462,0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark54(38.76740535325956,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark54(38.79682078646297,-1.2288658850095988,0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark54(38.80232854041803,-0.8776134656121339,0 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark54(3.8816075960303063,-1.4989057721729324,0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark54(38.84058537872491,-1.2550348923040522,0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark54(3.8852505682747847,-0.8953461156223241,0 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark54(38.876240242985105,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark54(38.95643320732887,-0.8907037452016313,0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark54(38.980230539221594,-0.0963920026379439,0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark54(38.99722389240662,-0.08782511190644904,0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark54(39.04524625790438,-0.3718821982094056,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark54(39.05093263421509,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark54(39.11379648403408,-1.4835588895127296,0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark54(39.114090520193095,-0.44358226538433276,0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark54(39.1168748669245,-1.1672493380977937,0 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark54(39.1278788312693,-0.7729236507391537,0 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark54(39.128488040960576,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark54(39.14387902099298,-0.08154977934841146,0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark54(3.9169161968380233,-0.7404040951871962,0 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark54(39.20846862119634,-1.0559731648152182E-6,0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark54(39.29417147050148,-0.07022677135783528,0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark54(39.32011140070577,-0.7158245834310621,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark54(39.34515855928109,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark54(39.37980923896694,-0.794413552264865,0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark54(39.388140845930764,-1.3698194661494751,0 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark54(39.44185807532342,-6.764233425603698E-8,0 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark54(-39.456512974148175,-0.5149339333104863,49.29768912889382 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark54(39.46798764086569,-0.3897147228525353,0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark54(39.51398392180276,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark54(39.53507636784721,-1.3143260924737907,0 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark54(39.540959641030526,-0.5772628408144929,0 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark54(39.55694512903173,-1.2812297131405854,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark54(39.55784102246536,-4.248998526084502E-5,0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark54(39.633623290718205,-0.6975573608697208,0 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark54(39.66885706494728,-1.1944391770726894,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark54(39.67886431299735,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark54(39.679484407538354,-0.7940628846864694,0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark54(39.69551379854374,-0.8480315077147367,0 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark54(39.73993251315537,-0.5672278461056877,0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark54(39.77207239446304,-0.6037044933571849,0 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark54(39.80405932482463,-1.4999999999707907,0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark54(39.804603239997796,-1.0653849871409755,0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark54(39.85995221884872,-0.9166648429589094,0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark54(39.886315410943496,-0.9400495278904533,0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark54(39.896958359141195,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark54(3.994027286110901,-1.4745120373479748,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark54(39.96341692685818,-0.5684937230860472,0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark54(39.97342645869633,-1.00279385634264E-6,0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark54(39.986883126445754,-0.44712642530187985,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark54(40.01727245206209,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark54(40.0173921799815,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark54(40.018711660080236,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark54(40.02483648146747,-0.5077562269362415,0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark54(40.02655873954296,-0.6756451439367623,0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark54(40.03329368916343,-1.4244594142120794,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark54(40.04853114261715,-0.0895399629151239,0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark54(40.066148573738815,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark54(40.06944741906269,-0.6463151837626453,0 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark54(40.07635219534217,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark54(40.092384903694125,-0.20598363752240115,0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark54(40.09920939553111,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark54(40.10385026803488,-0.3735586073907456,0 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark54(40.11105542282363,-1.1991108630979097,0 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark54(40.13487756266568,-0.8164166479346839,0 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark54(40.14306416294926,-1.36496709855886,0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark54(40.15184999803183,-3.982324253667028E-6,0 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark54(40.15499575961971,-0.174325168776913,0 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark54(40.167566340957734,-1.498036511415082,0 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark54(40.184538085568285,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark54(40.2191798333414,-0.07242829897322167,0 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark54(40.27649608883104,-1.3160978663180192,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark54(40.3483647891768,-1.033730152208916,0 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark54(40.35084451674541,-0.16189675047248553,0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark54(40.38866831952207,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark54(40.46103043865093,-0.3096948746290641,0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark54(40.46310384184227,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark54(40.47924700732736,-0.2262273684158176,0 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark54(40.49530772614276,-0.0010329353978163949,0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark54(40.53037491455713,-1.0737165462306807E-7,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark54(40.53627705501675,-0.732942182846787,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark54(40.558115431009035,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark54(40.55878131184386,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark54(40.5776395247062,-1.3227078808064614,0 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark54(40.64119673125754,-1.130281705769518,0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark54(40.64738393601118,-0.3473352354547158,0 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark54(-4.064936359238081E-261,-1.492654797969991,0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark54(40.666762694927996,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark54(40.698258898819404,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark54(40.69904367540224,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark54(40.72446436451696,-1.121700508875643,0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark54(40.74616633620535,-0.27761252636494954,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark54(40.8260776620577,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark54(40.85559676653733,-0.025094975989617296,0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark54(40.86610744169999,-1.472603849049834,0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark54(40.87858507998672,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark54(40.88524041730369,-0.9658896242346473,0 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark54(40.94063580856351,-4.221817714675318E-9,0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark54(40.95471768091977,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark54(40.95505171690396,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark54(40.961908154550116,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark54(40.97833437663883,-0.9384700082680295,0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark54(41.00546786085513,-3.1288215513485857E-7,0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark54(41.013595646095155,-1.1280326028346703,0 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark54(41.024569785026046,-0.9213452671675044,0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark54(41.03124456276071,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark54(4.104707221140591,-0.5950580944757009,0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark54(41.06707046380521,-0.003727542901565073,0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark54(41.09249939150846,-0.44802066573257804,0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark54(4.111923572824669,-0.8785379409408107,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark54(41.12152575854751,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark54(41.12515747163937,-0.8950837905908635,0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark54(41.134048274879916,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark54(41.135631408413744,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark54(41.14809912280407,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark54(41.183992030201885,-1.176885481206693,0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark54(41.209409304879784,-0.39664853699790115,0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark54(41.24525275367097,-1.3195444467460558,0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark54(41.25147320377201,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark54(41.251474246720605,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark54(41.25720787260841,-0.590955374637781,0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark54(41.2693242721758,-1.132906369676592E-6,0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark54(41.27113202897644,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark54(41.29279635908475,-7.818085957458177E-7,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark54(41.307454088061014,-0.016781253211811595,0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark54(41.34448275889528,-1.3741249427861817,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark54(41.38301107906,-0.43967598418808507,0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark54(41.406404277759094,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark54(41.42016543427928,-3.4532842799824085E-5,0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark54(41.5839673345814,-1.0907439687620308,0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark54(41.65029164726635,-1.4999999861138418,0 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark54(41.67551734140755,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark54(41.6767698857812,-0.5521889634761976,0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark54(41.67970653231657,-0.700771125032988,0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark54(41.69426061256803,-0.6405325579442489,0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark54(4.174586848134211,-0.11946830542594067,0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark54(41.74723620365984,-1.268457053643053,0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark54(41.76876786510326,-0.03408445539645122,0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark54(-41.77151243333552,-1.3683208962396605,-0.7142174203070605 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark54(41.85720911122749,-0.5406641427980063,0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark54(41.9070935442671,-0.884680996222869,0 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark54(42.061565069671815,-0.45747212426188355,0 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark54(42.069506576907855,-1.372335698140545,0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark54(42.094602187101216,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark54(42.113759639807256,-0.9038643079415157,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark54(42.13194811747944,-1.3374533653347712E-8,0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark54(42.155032632211274,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark54(42.213907644712435,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark54(4.222039144957225,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark54(42.22388548497411,-0.5038255307897821,0 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark54(42.258652920498236,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark54(42.26728937744329,-1.480464637705275,0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark54(42.29692234759944,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark54(-42.3437452047103,-0.8771931092898019,1401.7383334222186 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark54(42.35095527730377,-1.109679843205921,0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark54(4.2351647362715017E-22,-1.499999999999618,0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark54(42.358443010671294,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark54(42.36435729573597,-1.4810070380239466,0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark54(42.38777506840208,-0.3199572681306896,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark54(42.38944527910785,-5.588007213185686E-16,0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark54(42.389623861506664,-1.4999999878112347,0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark54(42.440736955792346,-1.4999999999999911,0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark54(42.48540470715659,-0.19206218223033644,0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark54(42.5619701146384,-0.6783415007703724,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark54(42.574090087928795,-0.23777412438772672,0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark54(42.61220224971757,-0.04903062705545436,0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark54(42.6242152776355,-0.7188691253703166,0 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark54(42.633877475901826,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark54(42.6564311685916,-0.5236543183492706,0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark54(42.67567580515479,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark54(42.70111426258026,-0.35288682885870015,0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark54(4.271010096640765,-0.39246052642191565,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark54(42.74293764011739,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark54(42.74636777713911,-0.562004062860721,0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark54(42.753597414004496,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark54(42.75835797537231,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark54(42.76730275753535,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark54(42.852626665205584,-0.04185540294077136,0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark54(42.85569173129238,-0.8735207587523086,0 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark54(42.88232483965703,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark54(42.97352878844656,-7.317433219109044E-8,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark54(43.00072825663931,-2.597625676455727E-16,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark54(43.022733271415575,-0.18367794174036756,0 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark54(43.03167055921955,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark54(43.049757469152155,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark54(43.05634780926414,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark54(43.063065287958295,-0.12134943155268729,0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark54(43.06319926501256,-1.1189689924356185,0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark54(43.06449754724426,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark54(43.067374339157,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark54(43.14463161150129,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark54(43.16826314740331,-0.09362602792128845,0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark54(43.22111040622275,-1.4257928745730197,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark54(4.3235159375987,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark54(43.2443118409937,-0.30910958769421804,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark54(43.250348328013956,-1.3364477723676051,0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark54(4.327851484566054,-1.0841591963877306,0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark54(43.28755263834429,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark54(43.30766868736791,-1.2507602219953924,0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark54(43.339043784956715,-0.2966521927909205,0 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark54(43.36758774003161,-0.6570875043612716,0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark54(43.37098721366513,-1.4999999999999716,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark54(43.390135161411735,-1.4084855119107638,0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark54(43.406296099022,-0.2051366979060505,0 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark54(43.40756216464516,-0.6816955640978344,0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark54(43.42390717081598,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark54(43.470241760636554,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark54(43.496631927867185,-1.051156955378511,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark54(43.537929720532915,-1.432099610935862,0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark54(43.571766573089775,-1.609603693432472E-8,0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark54(43.63217775791398,-6.139202276229525E-5,0 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark54(43.6410958886691,-0.22698570618807767,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark54(43.66798845352214,-0.2568899167842038,0 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark54(4.376268967116232,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark54(43.764035940318536,-0.14327823674182127,0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark54(43.844008637064235,-0.5218654400054297,0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark54(43.91109930624148,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark54(43.911517278282844,-1.309008233114684,0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark54(44.02410349036933,-0.1806782285629709,0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark54(4.40310134740038,-1.418498549932744,0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark54(44.11132692608207,-1.3809478872522285,0 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark54(44.1464701514418,-0.5364721416030881,0 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark54(4.418561990957031,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark54(44.224405815975594,-0.3142689573787041,0 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark54(44.23512253728552,-0.6020309503872241,0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark54(44.252426808401175,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark54(44.25418107704451,-0.7647372640651469,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark54(44.26332613555546,-8.138345827241001E-7,0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark54(44.26344146548293,-1.6545440422949037E-7,0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark54(44.28732378261209,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark54(44.33998244167151,-0.06389290074039833,0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark54(44.34148443892692,-6.147855917219994E-7,0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark54(44.35536297320889,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark54(44.365031263333734,-0.7008243996647936,0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark54(44.39189553401596,-0.941273907588803,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-0.4796889523300374,0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-0.965694129444216,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark54(4.440892098500626E-16,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark54(44.50918736581036,-0.13467320416505357,0 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark54(44.52306386341027,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark54(44.53951031384088,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark54(44.55902907428426,-0.6479880879505728,0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark54(44.56001553792295,-0.5644842518604489,0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark54(44.568019910257505,-0.7883482114732914,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark54(44.57773757607171,-2.0341735972902403E-8,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark54(-44.69720755576086,-0.6211187882621088,-1.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark54(44.756075500893886,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark54(44.757265492337325,-1.0672744819227198,0 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark54(44.75867154051944,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark54(44.826627747546894,-1.496020793780406,0 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark54(44.83419057084545,-0.5503842805978723,0 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark54(44.848102847025814,-0.5272179455048995,0 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark54(44.84972017881743,-7.918390421859796E-5,0 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark54(44.855719567102824,-1.0667588578278355,0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark54(44.864205181952855,-0.27243989879199937,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark54(44.91154820401104,-1.2490286542600728,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark54(4.491228358643439,-2.3420365767824283E-4,0 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark54(44.923871503626685,-1.5696356535617826E-5,0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark54(44.964902223759054,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark54(44.987686284359214,-0.2607392356314483,0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark54(44.99832715504465,-0.766151822353432,0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark54(44.998337454926315,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark54(45.006088776761246,-1.1330254989943014,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark54(45.0103931888174,-1.3083565205099934,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark54(45.013260889940796,-1.4234264760469353,0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark54(4.5095284697744304,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark54(45.13129019745864,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark54(45.15163168217518,-1.4548542062582275,0 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark54(-45.15165678370408,3.823168013989715,-96.19864924198289 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark54(45.19000261682916,-0.3284616057301406,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark54(45.23189747724284,-0.14504090618729237,0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark54(45.23432933171527,-0.5615140881050964,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark54(45.2567746017325,-0.6809249972952642,0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark54(45.26220723789029,-1.295089293111376,0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark54(-45.293496733774184,-1.4978122174435748,1.6155871338926322E-27 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark54(45.29955066246842,-4.372783789879081E-8,0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark54(45.338049811296116,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark54(45.35207429058184,-0.17523820092655829,0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark54(45.43034681222309,-1.3295205669025338,0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark54(45.44796158968529,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark54(45.47200721949548,-0.9603909921929144,0 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark54(45.483283631338765,-0.5839849952796445,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark54(45.528808266858874,-1.448940270268448,0 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark54(45.55862770708811,-0.17989373195071762,0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark54(45.57635018869198,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark54(4.560202990366896,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark54(45.63038283298252,-1.4134115173632118,0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark54(45.658397537248874,-1.215508386782659,0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark54(45.718185523236606,-0.7477830981011948,0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark54(45.720426857192834,-1.1427296224215207,0 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark54(45.73017402486542,-0.8694033122966434,0 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark54(4.574801225266193,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark54(45.79366515421589,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark54(4.584460628490746,-0.10521304034790258,0 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark54(45.845083400671925,-0.1243762982301051,0 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark54(45.89362570885179,-0.41672133329292826,0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark54(45.897349474715206,-7.590319269119093E-9,0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark54(45.91136345202176,-0.03753321541655644,0 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark54(45.92461177959032,-0.8737242034597188,0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark54(4.59430192919929,-0.2928198555908361,0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark54(45.950063179389296,-1.8388150500850565E-7,0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark54(46.02131123558169,-1.1078219820432196,0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark54(46.06525074679644,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark54(46.09976453439535,-0.5688523308412887,0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark54(46.12024096671218,-2.889249673922453E-9,0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark54(46.18891964199922,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark54(4.619017732222915,-0.5213042181959322,0 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark54(4.6212976022139637E-274,-0.2554785948541508,0 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark54(46.21416696333996,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark54(46.25009259826756,-0.13336259652879967,0 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark54(46.40381234031591,-1.7597025070782717E-6,0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark54(46.42912178685172,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark54(46.478637544475504,-1.2497215915568773,0 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark54(46.498025826230005,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark54(46.51538960635985,-0.4253879893599267,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark54(46.5154353764442,-1.434777970029082,0 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark54(46.542661115117085,-0.2623343042805626,0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark54(46.5550147151786,-0.5906820491618991,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark54(46.56079903825784,-6.63073923879564E-9,0 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark54(46.578495355076996,-4.085142554176791E-4,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark54(46.63257421367872,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark54(46.666333686825936,-1.3999093815457968,0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark54(46.693478848840755,-0.1764953307640621,0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark54(46.7035605316496,-0.17137774049474225,0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark54(46.71956969725511,-1.2335654533726963,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark54(46.73705210658207,-0.8448874287327914,0 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark54(46.73994329568637,-0.3737184112995311,0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark54(46.74053491999858,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark54(4.676219175650292,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark54(46.77232663171833,-0.8012590164045577,0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark54(46.922629613673905,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark54(46.92421719205612,-1.3690579188061887,0 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark54(46.93689527149226,-1.3151771265478667,0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark54(46.93908744848244,-1.499999999999992,0 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark54(46.94092157825726,-1.1419114930629837,0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark54(46.96886697205766,-0.6035855536922972,0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark54(46.9916605075609,-9.201537137659353E-10,0 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark54(-47.03601211011939,-0.22774664851902587,1.0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark54(47.042794930382115,-0.5086393346181985,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark54(47.066976231303784,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark54(47.0743365100727,-1.1615740872966993,0 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark54(47.16165844029646,-0.5482790045221924,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark54(47.162015534476865,-0.6907767180259592,0 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark54(47.16773629447092,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark54(4.717008846167758,-0.715784120076356,0 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark54(47.17685204737499,-0.7033433076883333,0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark54(47.18331731350423,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark54(47.19141225497967,-0.03914084460879236,0 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark54(47.19458980514156,-0.8727724031366225,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark54(4.71991282009958,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark54(47.239526166456336,-1.1080647177611603E-9,0 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark54(47.24518917529446,-1.1938710371378463,0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark54(47.27462029233257,-0.8728625982661129,0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark54(47.276215329374224,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark54(47.29954704323694,-1.380513543330868,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark54(47.31140147143997,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark54(4.7318561809407385,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark54(47.32152938661167,-0.6367969752177913,0 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark54(47.35004120589261,-0.6664254477150668,0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark54(47.38285758310787,-6.260291148027109E-7,0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark54(47.38577916500219,-0.9032252721981555,0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark54(47.39315216769248,-1.1989188507223538,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark54(47.40843238153026,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark54(-47.45461087582125,-0.011111771376626686,23.05367904074118 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark54(47.45563904200335,-0.0012044982578705186,0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark54(47.48626798714869,-1.1251055844433608,0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark54(47.53663091307912,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark54(47.54383312968267,-0.5347530063437437,0 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark54(-47.54410195723111,-0.9289609221000693,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark54(47.56981542966241,-0.5321022307182817,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark54(47.56985601408409,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark54(47.5843459704156,-0.0818588871390662,0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark54(47.60625614027327,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark54(47.666963301471526,-0.2165476598741165,0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark54(-47.673767058870496,-8.884458717559616E-9,-0.018224934402416737 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark54(47.680427981728116,-0.7165049570725703,0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark54(47.68925698084366,-1.4570853037032763,0 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark54(47.753862788916905,-1.4455822652092678,0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark54(4.775696282498032,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark54(47.76057922521102,-0.10835574858938811,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark54(47.77526029287078,-2.1790562859162413E-7,0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark54(-47.7903605797954,-0.4840091448989554,-71.58168106470026 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark54(4.78055459491768,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark54(47.85900326952162,-0.43942238784630927,0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark54(47.874817042219476,-1.2805725134941532,0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark54(47.88030667127497,-1.3989203709522675,0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark54(47.9365176705294,-0.22566417998549615,0 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark54(47.997139610295,-1.4999999999999993,0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark54(48.01078471109875,-1.2277443363281737,0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark54(48.04870113025349,-1.0158646707136316,0 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark54(48.05612984584374,-0.7317645153953656,0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark54(48.06114226447218,-0.7845143407928443,0 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark54(48.083739421710135,-1.0662162716488126,0 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark54(48.096503401883695,-0.10982121612862805,0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark54(48.13029639468613,-0.14415871011510095,0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark54(48.1325292712294,-0.9123546163252882,0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark54(48.17106180372335,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark54(48.17975085405919,-1.158199408820579,0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark54(48.183629325997195,-0.5674163359607025,0 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark54(48.19838789589474,-9.081652041310843E-16,0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark54(48.279105049484855,-0.08689073364911071,0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark54(48.31463537924378,-0.5135085297512632,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark54(48.341702842503004,-0.8852644516141357,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark54(48.35165078678784,-0.40851458139295005,0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark54(4.8361483844556545,-1.4075298737955393,0 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark54(48.37360156214311,-1.4383473358188894,0 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark54(48.43970173507904,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark54(48.44366816617497,-1.2820511523949316,0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark54(48.46117509513664,-0.226520153574353,0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark54(48.489762528165954,-1.4677293790974808,0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark54(48.49244575235099,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark54(48.49401021529087,-0.2234431831859885,0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark54(48.512811682501905,-0.27651631381447705,0 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark54(48.52383070955594,-8.577672445182619E-8,0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark54(48.53500224066133,-1.0796479221261563,0 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark54(48.57208393537302,-0.4573490779665148,0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark54(48.5751023862866,-0.4446487040972833,0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark54(48.63377246039571,-0.9791665765372595,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark54(48.67825073233101,-0.05566840095024422,0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark54(48.70789634426339,-1.150329234456538,0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark54(48.73454733297813,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark54(48.749342445273896,-1.3998898618228264,0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark54(48.760641592933126,-1.0806922384770483,0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark54(4.8784284008165715,-1.4999999991618949,0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark54(4.878749862637789,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark54(-48.791646273547784,-1.2943042924755734,1.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark54(48.79249325704643,-0.23586183851726172,0 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark54(48.82379097461438,-0.21328486469904817,0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark54(48.83392200110623,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark54(48.83633660059397,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark54(48.88948897204642,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark54(48.90172060752644,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark54(-48.919594190941545,-1.1272176153144915,0.01728426139814787 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark54(-48.931677678472376,-1.1843703011896682,-51.093469421608596 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark54(48.93712476532275,-1.3021449627945683,0 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark54(4.896725580713258,-0.7082452839485976,0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark54(49.007738857574026,-7.953349880745619E-4,0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark54(49.06642446525322,-0.17743657768528853,0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark54(49.088779618711,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark54(49.090777460875984,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark54(49.092763957984594,-1.0558512728191818E-6,0 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark54(49.142761630682685,-0.4717644836926951,0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark54(49.15495788360781,-1.206823089044665,0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark54(49.23621959948592,-2.2864739837463335E-9,0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark54(49.241404545403384,-1.0035826068455644,0 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark54(49.268762712335835,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark54(49.273275860492326,-0.5232583334773423,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark54(49.274628703629574,-5.988017517337818E-10,0 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark54(49.28520629177331,-0.15407070750468083,0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark54(49.297121857582454,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark54(49.30840652519558,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark54(49.31227113257734,-0.9710554779304945,0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark54(49.3124221680757,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark54(4.93256700261105,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark54(49.34569245010343,-1.1520036472735216,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark54(49.34654614281973,-0.5515451617959064,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark54(49.35524949990396,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark54(49.37629452873807,-0.5443471371168922,0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark54(49.37737315129122,-1.3811711276875975,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark54(49.385500920473675,-0.7042914551183226,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark54(49.39236148037146,-0.9230067584801773,0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark54(49.47568303089588,-1.4146790806577947,0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark54(49.49498032289415,-0.11728536676374084,0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark54(49.504584855672434,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark54(49.51946570624642,-0.5635603143221175,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark54(4.95433726338113,-1.1531703735704888,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark54(-49.56748844889756,-0.4682187223249641,-1.0 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark54(49.59892574490884,-0.9992567350592667,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark54(49.6203736964745,-0.5741280892210388,0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark54(49.67248270016245,-0.7492000478810925,0 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark54(49.67906267414476,-0.013501386938872706,0 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark54(49.69458561033099,-0.29471296340552766,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark54(49.707514708907325,-0.31465164460755374,0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark54(49.729802325154395,-1.3714222796607498,0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark54(49.739797807716,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark54(49.76817165419584,-0.832098200495107,0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark54(49.80784597458627,-0.1799849984764399,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark54(49.844974002092215,-1.1004775406792828,0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark54(49.85270309489914,-1.1742856664245378,0 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark54(49.85585195569298,-2.190275716324218E-8,0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark54(49.86155193161669,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark54(49.94725132284478,-0.9825710020901113,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark54(49.97488291687267,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark54(49.994026616439804,-1.1273695607807332,0 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark54(50.01951462192082,-0.4782066005657662,0 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark54(50.05937595408491,-0.4409495911439194,0 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark54(50.06348497098048,-1.1630180385830755,0 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark54(5.00901014888945,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark54(50.099263790673234,-0.010909165831336387,0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark54(50.175225445425184,-0.7091146065108376,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark54(50.25446000791223,-0.9530980976787902,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark54(50.2791344210707,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark54(50.28332638242118,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark54(50.312444811758176,-1.4999985369322586,0 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark54(50.33687065495698,-0.42440264750771917,0 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark54(50.34398569826695,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark54(50.3623472902175,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark54(-50.36422568624602,-1.499999999945532,-11.188443943079477 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark54(5.04109120493093,-1.499999999951698,0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark54(50.45698232570706,-0.8436699530626441,0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark54(50.51087533863321,-0.6051216040730498,0 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark54(50.528358458918014,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark54(50.533174110829066,-0.8751677042167696,0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark54(50.53483856354663,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark54(50.56528672834218,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark54(50.566742339826654,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark54(50.59509579691709,-1.0255975515013533,0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark54(50.59914188731054,-0.3900744324507279,0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark54(50.62015113266628,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark54(50.625069367056426,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark54(50.63478574366047,-0.6540023376000619,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark54(50.643491667561655,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark54(50.69838957397087,-1.2410823445165704,0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark54(50.728320486513354,-0.20924724822642915,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark54(-50.73057557432919,-0.32747384880836716,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark54(50.73333723408521,-1.4518018812739393,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark54(50.75603478851184,-1.0772167675714401,0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark54(50.805840754767715,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark54(5.083539854262327,-0.9212581199097194,0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark54(50.88262432471271,-0.6214284815862596,0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark54(50.92839277128334,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark54(5.105716070766178,-1.18911382057306,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark54(51.059270432428576,-0.49873160763671365,0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark54(5.107045583531743,-0.36617295073168776,0 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark54(51.07747858423457,-0.6118214773734928,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark54(51.16489084765013,-0.9650683320249316,0 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark54(51.18476928949741,-0.05116830007052897,0 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark54(51.18655836706064,-5.434100560857005E-10,0 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark54(51.19422644547413,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark54(5.121095880375665,-1.4999999926742515,0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark54(51.22923862232965,-0.13623139567961573,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark54(51.25890824527048,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark54(-51.30620016443093,-0.17078801718139894,1.0 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark54(5.131347593393201,-0.04615956020615686,0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark54(51.36489792030472,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark54(-51.4488431682363,-0.05813006739976167,31.14065989184737 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark54(51.45147642122053,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark54(-51.45369240759435,-0.6563086980217133,-1.0000000000000004 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark54(51.464083269398316,-0.7303986351738407,0 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark54(5.1501829270563775,-0.31104362422810183,0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark54(5.151144980847903,-0.25134184632537426,0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark54(51.5198290806365,-0.5617353671188141,0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark54(51.52417306106375,-0.6899322868167985,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark54(51.54119083494615,-0.472141299029488,0 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark54(51.55094706692493,-6.533556092595767E-10,0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark54(51.56628428527003,-0.4262663502780537,0 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark54(51.56800857061235,-1.1913943556888467,0 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark54(51.58850950345888,-0.7125457954935648,0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark54(51.65653649070512,-1.3812772634199746,0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark54(51.6739531142201,-1.4795392200093493,0 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark54(51.75203029741289,-0.23505254416165577,0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark54(51.765165858185895,-0.8989878550534884,0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark54(51.785281097963065,-0.010031071252290136,0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark54(5.1786514896163864E-11,-0.8701523579265029,0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark54(51.789010340236736,-0.11201079873523534,0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark54(51.79628618144372,-0.9116962005234939,0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark54(51.84343090034781,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark54(51.864530350078454,-0.04258769806487511,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark54(51.91329412137759,-0.346553651802731,0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark54(51.917195958973224,-0.1253067981749782,0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark54(5.191907093038452,-1.47477445677049,0 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark54(51.923959624745606,-0.03688688362954906,0 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark54(51.927852195170935,-0.26473408609051785,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark54(51.9908591694479,-1.0125646163718685,0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark54(52.00861304408579,-0.04067242884218514,0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark54(52.040692076753004,-1.150588207125156,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark54(52.070824871546336,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark54(52.07501396633171,-0.5422111203008679,0 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark54(52.090109577567176,-1.0207679613919822,0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark54(52.103417154507795,-1.0574969345962053,0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark54(52.11909247608858,-0.3113203492318086,0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark54(52.13863088074902,-1.4132590974909025,0 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark54(52.14005420129129,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark54(52.141090790491944,-0.665670231328436,0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark54(52.216289780737384,-1.0171872096924857,0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark54(52.25674942996463,-1.1149646755598326,0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark54(52.31563253487158,-0.3702857232197374,0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark54(52.349901341023354,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark54(52.38326312431113,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark54(5.242277982280584,-0.16394802527345842,0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark54(52.43872538634059,-1.302643210581067,0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark54(5.243999512588545,-1.0466134394334108,0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark54(52.454494114172945,-0.6624910235337147,0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark54(52.47056389800014,-0.39803657176368945,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark54(52.476213614536704,-1.1312194844068095,0 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark54(52.59818285727188,-0.6110851807966018,0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark54(52.61181428773202,-0.32761924426616273,0 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark54(52.646272573207646,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark54(52.73860201350453,-1.359247774301748,0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark54(52.778883504142236,-1.8544566106886453E-6,0 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark54(52.78902697388861,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark54(52.83036699157401,-0.3294144210367861,0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark54(52.85585693730341,-0.016786848168697466,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark54(52.856811279919555,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark54(52.881211549698975,-0.09543620808170772,0 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark54(-52.889230415901395,-0.38544349307797243,-0.07624709787530393 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark54(5.2906147702161945,-0.5913149267001714,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark54(53.03506751985483,-0.6761292729765587,0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark54(53.0805471693094,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark54(53.106235715327045,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark54(53.16605153469632,-1.0647153603086692,0 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark54(53.17042059586191,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark54(53.25341782831446,-0.49461057362354743,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark54(53.26451958980459,-0.30106692602321283,0 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark54(5.327993384780537E-256,-0.015818507465494017,0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark54(53.300810164703705,-0.7208255975299664,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark54(53.317653772146805,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark54(53.32430687285162,-1.0994413151055253,0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark54(53.3362724342324,-0.7280739666995144,0 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark54(53.35888309411604,-0.7873647494193818,0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark54(53.36502973640171,-0.5025680004874289,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark54(53.38131388524181,-0.3245323331128701,0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark54(5.339898771616205,-0.46925226928458863,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark54(53.41297430121688,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark54(53.42785588632469,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark54(53.49191282146248,-0.20247697353704197,0 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark54(53.50026821927233,-0.4311470599916145,0 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark54(5.355296400321393,-1.053786601005072,0 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark54(53.575284177214456,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark54(53.59992146510069,-1.4368175591934067,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark54(53.6332741824676,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark54(53.65309549401261,-0.026669009506516128,0 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark54(5.366034294817833,-1.1255432283617184,0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark54(5.367507470040337,-0.17405984271661623,0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark54(53.70497633081321,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark54(53.72772075631329,-0.28413342996053714,0 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark54(53.753714462426274,-1.0776405849788475,0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark54(53.76729296437343,-1.2646401368298452,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark54(53.76866532141793,-1.287052950600776,0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark54(53.78149459536925,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark54(53.7912331983444,-1.2963088990412952,0 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark54(53.79505121085188,-1.0643451988587955,0 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark54(53.83958313081399,-0.43359000425764815,0 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark54(-53.84161978701852,-0.38225026440363763,0.007028544772076463 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark54(53.85192867024654,-0.6347353289480591,0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark54(53.90638041831515,-1.4342765680278087,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark54(53.94116897217185,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark54(54.01745927224835,-4.523679312842035E-9,0 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark54(54.049466817107486,-1.3275617763706863E-9,0 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark54(5.4080236664072885,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark54(54.121224149899966,-0.3747050052287797,0 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark54(54.137947226505595,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark54(54.16605108228708,-0.04697214361126556,0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark54(54.18153942987402,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark54(54.3157204023679,-0.211523740635279,0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark54(-54.35628307823404,-0.36515979439352086,-0.3997025965307801 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark54(54.37724116496243,-0.0233249053008997,0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark54(54.38813704742341,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark54(54.419023641656295,-0.3567239349042116,0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark54(54.42943001036369,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark54(54.43801593312719,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark54(54.46020307131428,-1.156402206858412E-16,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark54(54.469037111405676,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark54(54.469926674946265,-0.45302980948012816,0 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark54(54.48122800902035,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark54(54.483086308573775,-0.4553368866436498,0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark54(54.48482433208841,-1.114213591567659,0 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark54(54.498708771934304,-0.36031883250303887,0 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark54(54.52951696057506,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark54(54.57958103485993,-0.7089806412558559,0 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark54(54.59623035196175,-0.9358827016041856,0 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark54(54.598224580026745,-1.241418338242131,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark54(54.5991613948369,-1.3342545991778598,0 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark54(54.62221478633748,-0.8128873793269884,0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark54(54.624480627910486,-1.390923008051784,0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark54(5.463440623002826,-8.947398135250926E-9,0 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark54(5.466590077577905,-0.9010855269474947,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark54(54.68802335131062,-0.11047197055671631,0 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark54(54.699398449141455,-0.036891090705784224,0 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark54(54.73570411051736,-0.320767912545989,0 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark54(54.73807801220699,-2.1553627445730845E-8,0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark54(54.75268632633049,-0.06625700485101049,0 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark54(54.75959906564608,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark54(54.760257958175025,-0.35725890609311695,0 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark54(54.779094409392194,-1.2284722126670946,0 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark54(54.7830820839101,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark54(54.815238478096205,-0.0054483916867695825,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark54(54.83622921873331,-1.490703406897174,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark54(54.91073998611026,-0.8848948504959927,0 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark54(54.92332295183023,-0.2247673099487162,0 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark54(54.946365733974545,-0.6720537787577712,0 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark54(54.97350678843901,-1.043556487434164,0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark54(54.97993263346274,-1.4999999999999813,0 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark54(54.98817859274894,-1.137270576971062,0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark54(55.013251206631985,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark54(55.0191934892767,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark54(5.504640779200201,-0.17853129090341124,0 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark54(55.047440524740324,-1.4945815652322731,0 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark54(55.144749703220604,-0.08401014318859079,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark54(55.15259866028143,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark54(55.153872172922746,-1.306307800586211,0 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark54(5.516054276249633,-0.9569642951091168,0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark54(55.16262505937854,-0.5675510184466255,0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark54(55.163616930716266,-4.540110107136573E-10,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark54(55.205860782048006,-1.005384501310175,0 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark54(55.30076486734842,-0.2103783555754497,0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark54(55.339786356552,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark54(-55.34658433092123,-1.324555358894969,0.23153294842650377 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark54(55.35206457924349,-0.8661702439261008,0 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark54(55.39426890628894,-0.7057532970666784,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark54(55.405420651038355,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark54(55.4774886201335,-0.9450499486054664,0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark54(55.494955658538004,-1.2765738786535792,0 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark54(55.51247352581282,-0.27974538095128076,0 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark54(55.539791374391704,-0.2862059092650121,0 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark54(55.55345637302386,-1.2792435582151143,0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark54(55.6053352440335,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark54(55.615414700134295,-0.4475635445942667,0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark54(55.62693837551528,-1.4384193272254429E-8,0 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark54(55.64419838271405,-0.7274068206837807,0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark54(5.567139225559231,-0.372949969443777,0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark54(55.67445457056806,-1.2631495840153126,0 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark54(55.67924658792718,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark54(55.721305487942374,-0.8290004958611688,0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark54(55.729298846769495,-0.28418027257377787,0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark54(55.73908720445735,-1.4066415870738442,0 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark54(55.76117275294402,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark54(-55.83060771353878,-1.4703383484695225,-0.26340485803418523 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark54(5.583448185915668,-1.4999999998644322,0 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark54(5.584426971867003,61.70118392297388,0 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark54(55.85113860355986,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark54(55.858729429094495,-0.1451124883819821,0 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark54(55.8664358572739,-1.0072097502635162,0 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark54(55.89037077297084,-0.18526446540499109,0 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark54(55.90078966334309,-0.20893893464271684,0 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark54(55.934139371586525,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark54(55.96848106312552,-1.0193729910132419,0 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark54(55.97346506564139,-0.5459903883709112,0 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark54(55.974324883142685,-1.4999999999998401,0 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark54(55.984923725368105,-0.6559895077537901,0 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark54(55.99107957805322,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark54(56.02270871125893,-1.234972751664852,0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark54(56.04589713441739,-0.5737264314441763,0 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark54(56.05745335065649,-0.3013035929499468,0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark54(56.08052230814576,-0.009833082997005249,0 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark54(56.08324098247304,-0.9715749087484831,0 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark54(56.089023987511034,-0.12621993945944987,0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark54(56.089391439557986,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark54(56.10714005947355,-1.0811416949042227,0 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark54(56.1448273564007,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark54(56.222149203539786,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark54(56.23573300190771,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark54(56.25146108472647,-1.1455982999363856,0 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark54(5.628912921401707,-1.2489156678833515,0 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark54(56.3772458893755,-0.3231856315772371,0 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark54(56.394720045816314,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark54(56.41187534518953,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark54(56.43523984552627,-0.7345111108490272,0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark54(56.43530400569273,-0.5036236464662807,0 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark54(56.4368945303944,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark54(56.44480998956897,-0.49545168389019767,0 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark54(56.46039971485648,-0.7458534063359403,0 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark54(56.46543354532159,-0.55954634602699,0 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark54(56.49737962525518,-0.5946048753407647,0 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark54(56.498998135482196,-1.1020858564762221,0 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark54(56.54156023919819,-1.3108610869025483,0 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark54(56.583556220303166,-0.4211701415436133,0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark54(56.603538776382806,-0.3090649175178726,0 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark54(56.613128858294004,-8.17346194441626E-4,0 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark54(56.66568563243561,-3.7700303686232806E-9,0 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark54(56.66615355514256,-0.265692636965829,0 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark54(56.674598155170656,-1.0543808300070967,0 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark54(56.74590433073058,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark54(5.675659006214431,-1.090866018041905,0 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark54(56.78562458229848,-0.3030794226047453,0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark54(56.790146662552004,-1.2374545419930598,0 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark54(56.805055267957655,-1.221422532957697,0 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark54(56.81786234513652,-0.458592544721113,0 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark54(56.83380802474374,-4.494501001845251E-6,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark54(56.913207765025334,-1.2155016326035604,0 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark54(56.953827906135785,-0.16215981383174594,0 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark54(56.980355215578044,-0.7887879426353486,0 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark54(57.01839913483536,-1.0786942278971658,0 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark54(5.7078409994971215,-0.3157552063611748,0 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark54(57.21179147967277,-1.237989936460174,0 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark54(57.25100409442757,-0.49720760980951706,0 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark54(57.27667737768737,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark54(57.30384176753411,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark54(57.321259827478144,-1.476021838183128,0 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark54(-57.32777808607078,-1.0588188589842211,-1.0 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark54(57.45116535111396,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark54(57.46757272615412,-0.8207091124815076,0 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark54(57.4753243436316,-0.37628726723973216,0 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark54(57.48896157714694,-0.21296628162709852,0 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark54(57.492236048097276,-0.0011795401714637735,0 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark54(57.495428239896725,-0.5639871008482888,0 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark54(-57.54183558322835,-4.440892098500626E-16,88.57590399313095 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark54(57.58384193979531,-1.30644487225022,0 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark54(57.656658104156925,-7.094053041297471E-9,0 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark54(57.67676638415432,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark54(57.706697179001665,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark54(57.751485593725874,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark54(57.80204644759547,-0.3936629190071237,0 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark54(57.81393626186272,-0.04369795412374344,0 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark54(57.82835422910591,-0.6629540382748473,0 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark54(5.785775346452553,-0.9232029132227999,0 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark54(5.788507493179971,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark54(57.88919523841842,-2.29420733628448E-7,0 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark54(57.89878810404383,-0.8275917438177487,0 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark54(57.91339602943168,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark54(57.91774437278977,-1.0723643068192206,0 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark54(57.92279389969865,-0.6613852098448221,0 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark54(-57.92367510412696,-1.4999999999999991,13.983175201015298 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark54(-5.801366041998766,-2.0957849814779002E-7,-0.2903907219013029 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark54(58.016388270705846,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark54(58.02003147374103,-0.41992530583994747,0 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark54(58.024853727576385,-0.5255170422256512,0 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark54(58.03240819355589,-0.8478130675809629,0 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark54(58.049434646134756,-0.3342802052128846,0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark54(58.05290538012869,-0.8311499725248082,0 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark54(-58.05656647334712,-0.3446431259910787,1.0 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark54(5.810934956912136,-1.2746005615569502,0 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark54(58.13774160632719,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark54(58.18392020917765,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark54(58.24317831536684,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark54(58.24621458118861,-0.4008926830233728,0 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark54(58.24682144588018,-0.8677776715638823,0 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark54(5.825345706309723,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark54(5.825589925245339,-0.9201705621909619,0 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark54(58.2793864943869,-0.03235370028765706,0 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark54(5.828119769486435,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark54(58.29090506661473,-0.7142260374890865,0 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark54(58.30399421843498,-0.349160977250353,0 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark54(58.32365074900588,-0.026691914985217835,0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark54(5.8325288435274265,-0.5289666018754711,0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark54(58.37828652036609,-1.475298006654291,0 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark54(58.398184311131665,-5.002461822344859E-10,0 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark54(58.43373525419034,-0.7756585883396383,0 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark54(58.45166206866759,-0.3962133860407082,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark54(58.482953629396775,-1.3427184167838119E-5,0 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark54(58.497100607012975,-1.6130809682817018E-6,0 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark54(58.55576007593572,-0.054589275729412634,0 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark54(58.58018623255214,-0.10555037777898679,0 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark54(58.58910527145477,-1.4999999999999947,0 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark54(58.61084030871997,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark54(58.62350623728847,-0.871376340548494,0 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark54(58.627299517985776,-0.30544425386363283,0 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark54(58.65088371281211,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark54(58.655198491533014,-0.8870887885370706,0 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark54(58.66511791742953,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark54(58.77436794748728,-0.7952006991181821,0 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark54(58.77454346885841,-1.265373064723562,0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark54(58.779842506928595,-0.5037810102239249,0 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark54(58.82656294279539,-0.5350707758725406,0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark54(58.87317516442029,-0.9991358838158471,0 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark54(5.891817963979875,-0.7924507696861642,0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark54(58.92030757277297,-1.4084661955085789,0 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark54(58.9389573426199,-1.3997581949977254,0 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark54(58.9461098953486,-0.15972234933369145,0 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark54(58.968894489060524,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark54(58.991226933268734,-0.08224032827803518,0 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark54(5.903773336746028,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark54(59.09089258784343,-1.375328304252792,0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark54(59.158684152402664,-0.0059163177410255785,0 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark54(59.164383344877024,-0.6384353660885118,0 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark54(59.200859624795015,-0.6559264405421006,0 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark54(59.21272643277936,-2.8027616423233956E-8,0 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark54(59.228214665018136,-0.39621964768700435,0 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark54(59.268526132596875,-0.22846665519677234,0 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark54(59.2772207340204,-1.0227166456181789,0 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark54(59.31775166755799,-0.35100112216214896,0 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark54(59.34244331197638,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark54(59.348230314153625,-0.026019578410443556,0 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark54(59.34865676741495,-0.6589225535313092,0 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark54(-59.401603185460274,-0.0213215383665233,0.96381955266705 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark54(59.414485516506346,-0.1792180402916017,0 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark54(59.47813365654298,-0.36624895204182306,0 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark54(59.510589802682304,-1.4999999998629392,0 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark54(59.53285137019344,-1.231232501114119,0 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark54(59.54451253346713,-1.3772889175335328,0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark54(59.60453074959605,-0.7336260277906064,0 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark54(59.6114619979291,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark54(59.62491738421883,-0.9085008475733645,0 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark54(59.63372708527495,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark54(59.672223823053805,-0.5788421040058691,0 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark54(5.967513723440838,-1.167489685807054,0 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark54(59.80089188837097,-0.7055695547764849,0 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark54(59.803887428865295,-0.928639390575853,0 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark54(5.98160404909207,-1.2970585102580614,0 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark54(59.823110462089886,-1.380538327947022,0 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark54(59.823160357807325,-1.2101547097205025,0 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark54(-59.853680056356765,-0.006362931885853055,0.0 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark54(-59.918057223024405,-8.881784197001252E-16,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark54(59.97590928479303,-0.2025572843111334,0 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark54(59.98322852836506,-1.499999999999992,0 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark54(5.998939685425597,-1.3999145953900154,0 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark54(60.01345243776393,-0.8393087548224633,0 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark54(60.01582536530523,-0.21676594027323087,0 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark54(60.032235891724525,-1.4118409736416595,0 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark54(60.071852329475945,-1.316937113510475,0 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark54(60.090634655764106,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark54(60.11903599991811,-0.25077767182604305,0 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark54(60.13821015308963,-0.4137939699515223,0 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark54(60.14425921957255,-1.486044982360312,0 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark54(60.178682403094115,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark54(-60.1999025897674,-1.4999999999999964,-0.060141418703580196 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark54(60.28659824998702,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark54(60.29634784877024,-1.0954819997592438,0 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark54(60.32862481582703,-1.2584813672221768,0 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark54(60.361533299614976,-1.2816098241928229,0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark54(60.4010723784742,-1.410796052488223,0 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark54(6.040522246891996,-1.2776779928802995,0 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark54(60.44436427213222,-0.5511790789607574,0 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark54(60.500313901468076,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark54(60.51436995625582,-1.4999999999999902,0 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark54(60.52602826027734,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark54(60.545364213176256,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark54(60.55840444009581,-1.2103618572781794,0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark54(60.56619929374571,-0.9483405127156321,0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark54(60.583245506538184,-0.5188588474438309,0 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark54(60.63313232206792,-1.0793548313994767,0 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark54(60.6362168138972,-7.036504493504141E-8,0 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark54(60.66068679796203,-0.37402837927415544,0 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark54(60.66295924377147,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark54(60.66873318854789,-0.39436589995670523,0 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark54(60.67087128167711,-1.4999999999997602,0 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark54(60.6759063475021,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark54(60.68626907544956,-0.6404103018209049,0 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark54(60.69186254618012,-0.1274159803838873,0 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark54(60.771190528335495,-0.5337927658542245,0 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark54(60.776811670016116,-0.2804837552586121,0 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark54(60.777056530883215,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark54(60.78017178897245,-0.10155349678733971,0 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark54(60.78404884737856,-0.9761923286359888,0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark54(60.78683777351656,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark54(60.81589490791541,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark54(60.82197595270381,-0.20117752157732904,0 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark54(6.083030643019001,-1.077973033177333,0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark54(60.84592933661776,-0.30719995566291414,0 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark54(60.88116804395423,-8.91443950165344E-9,0 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark54(6.088944742261225,-2.109931063059919E-5,0 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark54(60.92748028442497,-0.7142255644102539,0 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark54(60.929075437617776,-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark54(60.936770456974315,-0.6338027514321523,0 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark54(60.965237796651394,-0.30619958894725663,0 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark54(60.978539422566826,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark54(61.01957543903784,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark54(6.1036282927088426,-4.952345943408762E-10,0 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark54(61.03811054731018,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark54(61.039311182870335,-0.25001845438717396,0 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark54(61.047110142617925,-0.6522230356341652,0 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark54(61.05183341223318,-1.3996605643643818,0 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark54(61.057413533084514,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark54(61.109160196775925,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark54(61.12089619048934,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark54(61.26399111736998,-0.24340899805457594,0 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark54(61.275792610337,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark54(61.28638270533979,-0.809607179307041,0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark54(61.28837489683039,-1.1984192964106914,0 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark54(61.2917167936439,-0.1878741858574608,0 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark54(6.1318150451240285,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark54(61.33085814676477,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark54(61.380018450881984,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark54(61.38981904295238,-0.7089583030564033,0 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark54(61.42943531970465,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark54(61.51420683790088,-0.04556720684820801,0 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark54(61.514872839391785,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark54(61.53769852146252,-0.022949046841914844,0 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark54(61.539231323628144,-0.23611206381777122,0 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark54(61.57215653922859,-0.7575366020448632,0 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark54(61.60847852073516,-0.1718277331968956,0 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark54(61.61839376569259,-0.47186963770703416,0 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark54(61.673755785934304,-2.1429162664702657E-9,0 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark54(61.704898741291004,-1.1546342086517143,0 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark54(61.719235744689115,-1.0738642229950108,0 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark54(61.72142849474138,-1.3200673802361327,0 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark54(61.77260016244543,-1.0233640190274755,0 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark54(6.177842984301236,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark54(61.7806421837805,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark54(61.79304484547254,-1.3704785348358846,0 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark54(61.80248062023739,-1.4523743066512045,0 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark54(61.814691841025905,-0.7530058844671212,0 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark54(61.839915579047,-1.2969218218691347,0 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark54(61.86491153587195,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark54(61.87314171116874,-1.089465542360557,0 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark54(61.90210596872279,-0.27476838115682267,0 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark54(61.941468506601154,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark54(61.96763518888981,-0.533140318672895,0 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark54(61.981064924698984,-0.5269688501694247,0 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark54(62.001266804433044,-1.2347697021121045,0 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark54(62.03000800211851,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark54(62.03327681305663,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark54(62.04610917748318,-0.8883312473662484,0 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark54(62.04890634561832,-1.4916564306598294,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark54(62.05561534195962,-0.8162451897963077,0 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark54(62.07386605065372,-0.5808393744375309,0 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark54(62.131447193917765,-1.065392988115394,0 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark54(62.180045438665275,-5.872420070376543E-10,0 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark54(62.18457032623685,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark54(62.20469754126819,-0.2643949771480436,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark54(62.273092917092285,-0.046728123229080334,0 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark54(62.301785347885016,-0.43300132740063524,0 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark54(62.350559196253045,-1.0350894492917493,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark54(62.353396852231356,-0.7415273980210793,0 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark54(62.36489770562165,-1.448237770196482,0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark54(62.370313726655866,-0.8948768318856164,0 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark54(62.40156126798095,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark54(62.40449314447915,-0.2697453345167271,0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark54(62.436578834491826,-0.6147249989509894,0 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark54(62.45348249896849,-1.3385766291478727,0 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark54(62.45954246484507,-1.4678377324114171,0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark54(62.4674982644745,-1.2125356375156282,0 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark54(62.49885387830088,-0.42072048535884005,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark54(-62.50610836935309,-3.552713678800501E-15,1675.2295747585374 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark54(62.510224836506694,-0.6234507140639347,0 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark54(62.556332271097006,-0.18887585503778315,0 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark54(62.577751818426265,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark54(62.59170793759205,-0.9244890838113378,0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark54(62.625264535775095,-1.8542416573156864E-9,0 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark54(62.659086194740325,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark54(62.674958894867956,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark54(62.67577012913082,-0.7520758806557097,0 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark54(62.68711822424645,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark54(62.72623246638088,-1.087054651850821E-4,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark54(62.7364046841309,-0.5266923063996956,0 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark54(62.79481627655164,-1.499999999999698,0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark54(62.82061113974166,-0.4989340681148713,0 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark54(62.84439573659358,-0.47190180393638226,0 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark54(6.285547335977142,-1.2434047800040702,0 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark54(62.85865384717161,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark54(6.28771729088594,-0.7011938543472098,0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark54(62.88379040480609,-0.6793735934993492,0 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark54(62.897128366319016,-0.7827895296038282,0 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark54(62.90696171923048,-0.2930829149806442,0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark54(62.94948078914244,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark54(62.9953560444647,-0.4340772860208233,0 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark54(63.07583998428166,-0.0894028715254025,0 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark54(6.310692148831809,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark54(63.10874596587564,-1.2005600114214854,0 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark54(6.3108872417680944E-30,-0.31008187788908415,0 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark54(63.1568473020503,-0.4449066645170774,0 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark54(63.166509650521135,-0.09326736118029544,0 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark54(63.17836073253372,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark54(6.317884462535119,-0.10500853769994478,0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark54(63.180418389344396,-0.8551796766869342,0 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark54(6.326303235455313,-1.3690572541758326,0 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark54(63.30001942529327,-0.891752013825013,0 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark54(63.31110944370454,-0.7381493708799096,0 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark54(63.35438734427649,-1.011641950935367,0 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark54(63.361328454674094,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark54(63.39254183147358,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark54(6.339412968918072,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark54(63.39786762136242,-0.005885907896631792,0 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark54(-63.402317710647054,-0.33656861015817974,-0.00645326871993368 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark54(63.42771690858344,-1.79242920593328E-6,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark54(63.45064760101066,-0.11224699180537812,0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark54(63.49003811211733,-0.02382971647247034,0 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark54(-63.49573160817184,-1.4999999999999982,66.44920653895323 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark54(63.51131589789796,-0.08618330450767608,0 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark54(63.52621544079017,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark54(63.54666636203038,-0.5310813045671772,0 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark54(63.548836515734365,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark54(63.610824841962646,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark54(63.639530133069144,-0.6446132314664941,0 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark54(63.71448394536844,-0.05207628543655071,0 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark54(63.737854224398546,-0.5544273162705213,0 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark54(6.3739947799866785,-1.44807746261734,0 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark54(63.79599717714652,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark54(63.797764748375876,-1.499999462760944,0 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark54(6.383749128880595,-0.7666004472961412,0 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark54(63.900472182271784,-0.9100503960886841,0 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark54(63.93761530414562,-0.304010831234232,0 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark54(63.9516192763111,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark54(63.952194702642345,-1.499999999999993,0 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark54(63.9805704021259,-1.3954852479582598,0 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark54(64.00990590196945,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark54(64.02667810799028,-0.6399454155502193,0 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark54(64.04150370964891,-0.489988188675909,0 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark54(64.06700206954454,-0.7160402444714888,0 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark54(64.07072151122918,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark54(64.073556054795,-0.18662767611672493,0 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark54(64.07780666373785,-0.6797757866826083,0 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark54(6.414794367885316,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark54(6.421702679965168,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark54(6.429314995768863,-0.12115549436489381,0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark54(64.31386704842416,-0.19959888899540346,0 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark54(64.3226619858369,-1.1118451241649723,0 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark54(64.33102751117308,-0.5892903365333961,0 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark54(64.33744814098347,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark54(64.37627329082966,-1.3200084451640777,0 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark54(64.42025823768162,-1.4999998108689883,0 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark54(64.44435636915144,-0.9561395645017026,0 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark54(64.49222455889596,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark54(64.49560122801213,-0.8407323515626555,0 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark54(6.449901627325122,-0.31113685783223155,0 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark54(-64.50475080548487,-0.7982293890389842,86.04476339346269 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark54(64.61857749231109,-1.3511796283832016,0 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark54(64.71789155811857,-0.8950890253661674,0 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark54(64.78202222330373,-0.8813016943260636,0 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark54(64.79617160056702,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark54(64.81317981968442,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark54(64.81322099239016,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark54(64.81745621169375,-0.3351387057177063,0 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark54(64.8187564866482,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark54(64.84781331336006,-0.5479685178816176,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark54(64.86865919702502,-7.637111531606977E-6,0 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark54(-64.88280750481844,-0.17455908646262674,-0.2748761752036821 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark54(64.8955628593323,-1.5847632656503755E-4,0 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark54(64.89793992505292,-0.307971324874887,0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark54(64.90151638359606,-1.4688678665872725,0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark54(64.91383135982576,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark54(6.492479273794686,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark54(6.492914615711303,-1.3435140439743236,0 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark54(64.97228707444121,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark54(6.497702775911478,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark54(65.00289459162767,-0.42911366827990216,0 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark54(65.00932252578428,-0.6760038940572324,0 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark54(65.02193686622887,-1.4085053480471252,0 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark54(65.0248418897005,-0.7148378192259912,0 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark54(6.50250292207445,-1.4573150809095485,0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark54(65.0327466895871,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark54(65.04696061218328,-0.06910216813066694,0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark54(65.07096227088066,-0.5111256621194689,0 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark54(65.0912974703215,-0.2965024029409218,0 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark54(65.09950099886149,-0.1961829105994468,0 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark54(65.10460325561982,-0.8422004660594098,0 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark54(-65.15246398359508,-0.0013046102652136047,1.000000000000007 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark54(65.16732734896053,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark54(65.1713231034322,-1.4999999999999751,0 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark54(65.17756908988852,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark54(65.21495871855385,-1.069254526591235,0 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark54(65.21597770663035,-0.6653747765580399,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark54(65.25367612724554,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark54(65.31126717851276,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark54(65.31830581139005,-0.2748192943862553,0 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark54(65.33923593612845,-9.285028049370643E-9,0 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark54(65.38774834734893,-2.3920088209116796E-9,0 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark54(6.540850006653059,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark54(65.46494472555003,-0.8226049067967551,0 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark54(65.5026054915163,-0.6761399885661774,0 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark54(65.57684497440135,-0.9725033900053847,0 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark54(65.59479765461222,-0.05626742584771094,0 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark54(65.61280383974277,-8.921511346809974E-8,0 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark54(65.62572881368723,-0.7242307583894738,0 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark54(65.65482568222293,-0.03275493062391366,0 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark54(65.65612630471018,-0.45388304498521664,0 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark54(65.74551440953604,-0.07738789107722255,0 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark54(65.78382330560439,-0.6839844546501208,0 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark54(65.79572900289352,-0.27930818113921224,0 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark54(65.79574944322394,-0.7811494998676995,0 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark54(65.79920927662934,-0.09962969186224768,0 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark54(65.83624597321881,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark54(65.83764846011306,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark54(65.88536641529689,-1.3339241469428487,0 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark54(65.89464366001408,-1.4721450884159282,0 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark54(65.90476786374003,-0.5082288111522288,0 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark54(65.90617895871102,-1.1489231510422009,0 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark54(65.91148880305485,-0.6304640693778351,0 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark54(6.592262818220968,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark54(65.94998385003852,-1.4999999974979707,0 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark54(65.9642446145514,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark54(65.97294122751424,-0.271115579173304,0 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark54(65.98193317732117,-0.8304263899475455,0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark54(6.600359020277946,-0.8328620429934619,0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark54(66.02562692724587,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark54(66.07788449936783,-1.1351411795574422,0 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark54(66.08923662713332,-0.4922948794132509,0 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark54(6.609949421731107,-1.4359205938460484,0 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark54(66.20733707815229,-2.254157064159604E-7,0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark54(66.21895002769065,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark54(66.24345054013727,-5.7182407856835034E-8,0 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark54(66.24549699209928,-0.3486264918332297,0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark54(66.27469283031874,-1.3381491794169733,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark54(66.29660319974698,-0.19476844430445794,0 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark54(66.30699882345081,-0.8298613744035253,0 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark54(66.33213836694071,-0.9279024253177282,0 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark54(66.33872835912084,-0.9274700696963284,0 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark54(66.355214199997,-1.474341060042015,0 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark54(6.6359200090265125,-1.4999999986151067,0 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark54(66.36406083135819,-0.7084014479864038,0 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark54(66.39596225135674,-1.2808766747850446,0 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark54(66.42417143347492,-1.4678753271079652,0 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark54(6.645963322311303,-0.005802746795444402,0 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark54(66.49692979951206,-0.33364646257146163,0 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark54(66.52167943920244,-0.04541423604627054,0 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark54(66.52947973955872,-0.16016299555526703,0 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark54(66.60451659599445,-0.9253266685401833,0 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark54(66.60614005233978,-0.10312223078426697,0 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark54(6.66346017295669,-0.5783219576681184,0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark54(66.63605138407601,-1.22810289122896E-6,0 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark54(6.664931515502886,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark54(66.65821966478686,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark54(66.68740984510484,-1.3979869839899752,0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark54(66.70278131635982,-0.1903192444737012,0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark54(66.75454602815044,-0.33842621799331596,0 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark54(66.79597802355056,-0.29969166687438553,0 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark54(-66.83146733354486,-0.42484135332559975,-5.11790717719164 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark54(66.85379256771857,-0.7606250379485829,0 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark54(6.685609067737985,-1.441101057762677,0 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark54(66.87078605527427,-1.0806385770877682,0 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark54(66.89765090083883,-1.499999999690275,0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark54(66.91983710571833,-0.8735669311768953,0 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark54(66.92146484658925,-1.062190843749296,0 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark54(66.94670369213378,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark54(66.95756007044852,-0.107182042635662,0 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark54(67.00954059422529,-0.3439409257446755,0 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark54(67.00998119800687,-0.005485597634233644,0 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark54(67.01169813222054,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark54(6.7016346542369,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark54(67.02306406273581,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark54(67.07732440577865,-1.1911539083704208,0 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark54(67.08923686747363,-1.296288741994574,0 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark54(67.0936052366591,-1.3245801247133784,0 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark54(67.10656788205401,-1.2257546297991206,0 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark54(67.12676694262026,-0.10442630328112656,0 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark54(67.14896510554533,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark54(6.717163196829734,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark54(67.22309474711291,-0.6135804361328283,0 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark54(67.2274462031231,-0.00391178607708862,0 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark54(67.2391027431731,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark54(6.730001185096597,-0.3852144803990285,0 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark54(67.3101197630335,-1.0537224411328217,0 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark54(67.34203084478307,-1.0425229823409392,0 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark54(6.737278712857422,-0.48755800886320344,0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark54(67.37820337610137,-0.07190301199683802,0 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark54(67.38611973641903,-1.1330998500788105,0 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark54(67.41859220116456,-0.8709971578098106,0 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark54(67.43906639096059,-1.0230693182367778,0 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark54(67.44231183504851,-0.8037325966084632,0 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark54(67.447178572061,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark54(67.45845011154819,-0.3382362878187406,0 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark54(67.46958546474272,-1.2543333546228723,0 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark54(67.48812881608896,-0.20504654572543757,0 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark54(67.50817568077505,-0.42219604464205085,0 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark54(67.52231983933669,-1.2791764599711029,0 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark54(67.5229379837944,-0.299081057111362,0 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark54(67.52619045648416,-1.3866435055185624,0 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark54(67.54308279643669,-0.012151500834351125,0 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark54(67.56885294783092,-0.4041342943724189,0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark54(67.59598397382987,-1.1080336206277508,0 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark54(67.62605662082618,-1.1756338640663075,0 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark54(67.63887887942855,-0.05756541830012907,0 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark54(-67.66437915083782,-1.0268791030267517,-77.00152971270138 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark54(67.6838869698297,-1.0724316914427843,0 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark54(67.74677409615462,-0.9646114957548759,0 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark54(67.76461291536917,-0.24904232901613077,0 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark54(67.77449676601336,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark54(67.78818143241989,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark54(67.79045307348534,-0.6402363596881457,0 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark54(67.84682126997498,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark54(67.93226385748267,-1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark54(67.95826727969842,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark54(67.98489627682766,-1.4727305687047834,0 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark54(68.044540090017,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark54(6.809419396628741,-1.49249955048154,0 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark54(68.10737116224642,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark54(68.12852527019261,-1.3243809379956277,0 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark54(68.13079959614552,-0.19435766634212825,0 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark54(68.1355285245343,-1.1539818856445105,0 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark54(68.20119058707297,-0.8881605701771775,0 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark54(6.821780168262243,-2.0218552532811222E-7,0 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark54(68.22881688490307,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark54(68.24262343538129,-1.2700035093129243,0 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark54(68.2950586104401,-0.32349212679834904,0 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark54(68.29758753893665,-0.7845339069851818,0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark54(68.32203776969898,-1.499839797728589,0 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark54(68.324121770042,-0.32968415747899393,0 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark54(68.37185502752203,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark54(6.838261801563123,-9.657166709555645E-9,0 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark54(68.3831794037529,-0.31755755667667884,0 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark54(68.38977674134594,-1.4999999999999805,0 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark54(68.4216519179567,-0.1161476191189597,0 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark54(68.45357758713138,-1.4999644640319052,0 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark54(68.48253224393116,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark54(6.853647360076437,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark54(68.54308197584683,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark54(6.860524877190002,-1.2422845138311942,0 ) ;
  }

  @Test
  public void test3044() {
    coral.tests.JPFBenchmark.benchmark54(68.6376643772769,-0.49622715981954,0 ) ;
  }

  @Test
  public void test3045() {
    coral.tests.JPFBenchmark.benchmark54(68.67074363212897,-3.0667706267425142E-9,0 ) ;
  }

  @Test
  public void test3046() {
    coral.tests.JPFBenchmark.benchmark54(68.67583327223228,-0.7720230816120736,0 ) ;
  }

  @Test
  public void test3047() {
    coral.tests.JPFBenchmark.benchmark54(68.72716221676177,-0.7531055813946983,0 ) ;
  }

  @Test
  public void test3048() {
    coral.tests.JPFBenchmark.benchmark54(68.73016698689048,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3049() {
    coral.tests.JPFBenchmark.benchmark54(68.74872698444823,-0.643950694501265,0 ) ;
  }

  @Test
  public void test3050() {
    coral.tests.JPFBenchmark.benchmark54(68.75092296162703,-8.55149662188191E-5,0 ) ;
  }

  @Test
  public void test3051() {
    coral.tests.JPFBenchmark.benchmark54(68.8104889637822,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3052() {
    coral.tests.JPFBenchmark.benchmark54(68.8406174702522,-0.07747643112315217,0 ) ;
  }

  @Test
  public void test3053() {
    coral.tests.JPFBenchmark.benchmark54(68.88914556436096,-0.2967073029577068,0 ) ;
  }

  @Test
  public void test3054() {
    coral.tests.JPFBenchmark.benchmark54(68.89891701256639,-0.08623773182185746,0 ) ;
  }

  @Test
  public void test3055() {
    coral.tests.JPFBenchmark.benchmark54(68.97159865139855,-1.2912989767704348,0 ) ;
  }

  @Test
  public void test3056() {
    coral.tests.JPFBenchmark.benchmark54(68.97749478341083,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3057() {
    coral.tests.JPFBenchmark.benchmark54(68.98170128047555,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3058() {
    coral.tests.JPFBenchmark.benchmark54(69.03826596921253,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3059() {
    coral.tests.JPFBenchmark.benchmark54(69.04145949017982,-0.0022233573462138168,0 ) ;
  }

  @Test
  public void test3060() {
    coral.tests.JPFBenchmark.benchmark54(69.05061868512405,-0.001062507290294852,0 ) ;
  }

  @Test
  public void test3061() {
    coral.tests.JPFBenchmark.benchmark54(69.06962584829387,-0.9126536472579883,0 ) ;
  }

  @Test
  public void test3062() {
    coral.tests.JPFBenchmark.benchmark54(69.07936417377564,-0.6939182887889928,0 ) ;
  }

  @Test
  public void test3063() {
    coral.tests.JPFBenchmark.benchmark54(69.09183105892606,-1.1170061316706423,0 ) ;
  }

  @Test
  public void test3064() {
    coral.tests.JPFBenchmark.benchmark54(69.09595747258754,-0.9541457075279389,0 ) ;
  }

  @Test
  public void test3065() {
    coral.tests.JPFBenchmark.benchmark54(69.12664457122878,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3066() {
    coral.tests.JPFBenchmark.benchmark54(69.17980426303038,-0.7592446262250938,0 ) ;
  }

  @Test
  public void test3067() {
    coral.tests.JPFBenchmark.benchmark54(69.19565083963101,-0.08991947247489684,0 ) ;
  }

  @Test
  public void test3068() {
    coral.tests.JPFBenchmark.benchmark54(69.20100390013405,-0.6663865532010087,0 ) ;
  }

  @Test
  public void test3069() {
    coral.tests.JPFBenchmark.benchmark54(69.21527610699076,-0.44659073891955003,0 ) ;
  }

  @Test
  public void test3070() {
    coral.tests.JPFBenchmark.benchmark54(69.2158295254099,-1.2640575149133042,0 ) ;
  }

  @Test
  public void test3071() {
    coral.tests.JPFBenchmark.benchmark54(69.24461972140611,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3072() {
    coral.tests.JPFBenchmark.benchmark54(69.2575455531316,-0.501203686858823,0 ) ;
  }

  @Test
  public void test3073() {
    coral.tests.JPFBenchmark.benchmark54(69.28248918501932,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3074() {
    coral.tests.JPFBenchmark.benchmark54(69.31410458742201,-0.6458630386257482,0 ) ;
  }

  @Test
  public void test3075() {
    coral.tests.JPFBenchmark.benchmark54(69.32799201978887,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3076() {
    coral.tests.JPFBenchmark.benchmark54(69.32908201593716,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test3077() {
    coral.tests.JPFBenchmark.benchmark54(69.37454779769452,-0.5157314207355121,0 ) ;
  }

  @Test
  public void test3078() {
    coral.tests.JPFBenchmark.benchmark54(69.41564158912139,-5.696160389839447E-9,0 ) ;
  }

  @Test
  public void test3079() {
    coral.tests.JPFBenchmark.benchmark54(69.44028613279791,-0.6265844811850991,0 ) ;
  }

  @Test
  public void test3080() {
    coral.tests.JPFBenchmark.benchmark54(-69.45052757766736,-1.2315927033629714,-0.02408137953312911 ) ;
  }

  @Test
  public void test3081() {
    coral.tests.JPFBenchmark.benchmark54(69.46509867912164,-0.6933682784556998,0 ) ;
  }

  @Test
  public void test3082() {
    coral.tests.JPFBenchmark.benchmark54(69.52063517848617,-8.302372540127048E-6,0 ) ;
  }

  @Test
  public void test3083() {
    coral.tests.JPFBenchmark.benchmark54(69.53511681074491,-0.3689920665274907,0 ) ;
  }

  @Test
  public void test3084() {
    coral.tests.JPFBenchmark.benchmark54(69.60339148753933,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3085() {
    coral.tests.JPFBenchmark.benchmark54(69.62570345768135,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3086() {
    coral.tests.JPFBenchmark.benchmark54(6.9631310014940855,-4.0552712922893566E-10,0 ) ;
  }

  @Test
  public void test3087() {
    coral.tests.JPFBenchmark.benchmark54(6.963848686919704,-1.1559394681956539,0 ) ;
  }

  @Test
  public void test3088() {
    coral.tests.JPFBenchmark.benchmark54(69.6871979481252,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3089() {
    coral.tests.JPFBenchmark.benchmark54(69.73995790114867,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3090() {
    coral.tests.JPFBenchmark.benchmark54(69.79344383428179,-1.1811296286190753,0 ) ;
  }

  @Test
  public void test3091() {
    coral.tests.JPFBenchmark.benchmark54(6.979646267262482,-0.5384368784211964,0 ) ;
  }

  @Test
  public void test3092() {
    coral.tests.JPFBenchmark.benchmark54(69.80072848812134,-0.08454215295794137,0 ) ;
  }

  @Test
  public void test3093() {
    coral.tests.JPFBenchmark.benchmark54(69.80232292406238,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3094() {
    coral.tests.JPFBenchmark.benchmark54(69.81479095116774,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3095() {
    coral.tests.JPFBenchmark.benchmark54(69.81839174628834,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3096() {
    coral.tests.JPFBenchmark.benchmark54(69.84042004025241,-0.19513704992744196,0 ) ;
  }

  @Test
  public void test3097() {
    coral.tests.JPFBenchmark.benchmark54(69.8499324209331,-0.3651209577961083,0 ) ;
  }

  @Test
  public void test3098() {
    coral.tests.JPFBenchmark.benchmark54(69.87647121886295,-0.7468574065078428,0 ) ;
  }

  @Test
  public void test3099() {
    coral.tests.JPFBenchmark.benchmark54(69.88027563185668,-0.8191102886027127,0 ) ;
  }

  @Test
  public void test3100() {
    coral.tests.JPFBenchmark.benchmark54(69.89814876013588,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3101() {
    coral.tests.JPFBenchmark.benchmark54(69.91094320208165,-1.1219090674899603,0 ) ;
  }

  @Test
  public void test3102() {
    coral.tests.JPFBenchmark.benchmark54(69.94131894898302,-1.0540837361029762,0 ) ;
  }

  @Test
  public void test3103() {
    coral.tests.JPFBenchmark.benchmark54(69.94151436042637,-0.5743453196745443,0 ) ;
  }

  @Test
  public void test3104() {
    coral.tests.JPFBenchmark.benchmark54(69.94232309462713,-0.9990701727262685,0 ) ;
  }

  @Test
  public void test3105() {
    coral.tests.JPFBenchmark.benchmark54(69.94632701003096,-0.516911507970903,0 ) ;
  }

  @Test
  public void test3106() {
    coral.tests.JPFBenchmark.benchmark54(6.994912615681585,-1.0081184211470382,0 ) ;
  }

  @Test
  public void test3107() {
    coral.tests.JPFBenchmark.benchmark54(69.99494191570552,-1.1450039702908419,0 ) ;
  }

  @Test
  public void test3108() {
    coral.tests.JPFBenchmark.benchmark54(70.04013262291139,-0.4463839915327922,0 ) ;
  }

  @Test
  public void test3109() {
    coral.tests.JPFBenchmark.benchmark54(70.05048541002421,-0.6229258202147854,0 ) ;
  }

  @Test
  public void test3110() {
    coral.tests.JPFBenchmark.benchmark54(70.08209726302195,-0.16271556186045327,0 ) ;
  }

  @Test
  public void test3111() {
    coral.tests.JPFBenchmark.benchmark54(70.11405289725623,-8.170923564966176E-9,0 ) ;
  }

  @Test
  public void test3112() {
    coral.tests.JPFBenchmark.benchmark54(70.12517519117925,-1.4999999954190821,0 ) ;
  }

  @Test
  public void test3113() {
    coral.tests.JPFBenchmark.benchmark54(70.12630440341624,-2.0417009539261026E-7,0 ) ;
  }

  @Test
  public void test3114() {
    coral.tests.JPFBenchmark.benchmark54(70.1269173567783,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3115() {
    coral.tests.JPFBenchmark.benchmark54(7.014830285896863,-1.4758604459181974,0 ) ;
  }

  @Test
  public void test3116() {
    coral.tests.JPFBenchmark.benchmark54(70.16166700602295,-0.7965146512794505,0 ) ;
  }

  @Test
  public void test3117() {
    coral.tests.JPFBenchmark.benchmark54(70.19277911489951,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3118() {
    coral.tests.JPFBenchmark.benchmark54(70.20353911455092,-0.13991129282979387,0 ) ;
  }

  @Test
  public void test3119() {
    coral.tests.JPFBenchmark.benchmark54(70.24134064056858,-1.244519651606025,0 ) ;
  }

  @Test
  public void test3120() {
    coral.tests.JPFBenchmark.benchmark54(70.27447761911984,-1.1208721481356854,0 ) ;
  }

  @Test
  public void test3121() {
    coral.tests.JPFBenchmark.benchmark54(70.28540032157866,-0.35504776706933683,0 ) ;
  }

  @Test
  public void test3122() {
    coral.tests.JPFBenchmark.benchmark54(70.33824234247155,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3123() {
    coral.tests.JPFBenchmark.benchmark54(7.0361933637836245,-0.9607233906095303,0 ) ;
  }

  @Test
  public void test3124() {
    coral.tests.JPFBenchmark.benchmark54(70.43846462237582,-0.019170588300001512,0 ) ;
  }

  @Test
  public void test3125() {
    coral.tests.JPFBenchmark.benchmark54(70.44096498917139,-1.2946568342541411,0 ) ;
  }

  @Test
  public void test3126() {
    coral.tests.JPFBenchmark.benchmark54(70.47390110925544,-7.62047889783111E-8,0 ) ;
  }

  @Test
  public void test3127() {
    coral.tests.JPFBenchmark.benchmark54(7.05402849837424,-0.5556466302361898,0 ) ;
  }

  @Test
  public void test3128() {
    coral.tests.JPFBenchmark.benchmark54(70.54161077860407,-1.2661016397217773,0 ) ;
  }

  @Test
  public void test3129() {
    coral.tests.JPFBenchmark.benchmark54(70.5418691018088,-0.6562551118486799,0 ) ;
  }

  @Test
  public void test3130() {
    coral.tests.JPFBenchmark.benchmark54(70.54719979440972,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3131() {
    coral.tests.JPFBenchmark.benchmark54(70.58629104199159,-0.20217633446228925,0 ) ;
  }

  @Test
  public void test3132() {
    coral.tests.JPFBenchmark.benchmark54(70.60773970702061,-1.0272309588962258,0 ) ;
  }

  @Test
  public void test3133() {
    coral.tests.JPFBenchmark.benchmark54(70.61270604626674,-0.33982460331793907,0 ) ;
  }

  @Test
  public void test3134() {
    coral.tests.JPFBenchmark.benchmark54(70.62955831616236,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3135() {
    coral.tests.JPFBenchmark.benchmark54(70.77566654803817,-1.3152956904042017,0 ) ;
  }

  @Test
  public void test3136() {
    coral.tests.JPFBenchmark.benchmark54(70.83196747596693,-0.677847956532645,0 ) ;
  }

  @Test
  public void test3137() {
    coral.tests.JPFBenchmark.benchmark54(70.85686061210637,-1.023059123855802,0 ) ;
  }

  @Test
  public void test3138() {
    coral.tests.JPFBenchmark.benchmark54(70.86568670682405,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3139() {
    coral.tests.JPFBenchmark.benchmark54(7.086901730082062,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test3140() {
    coral.tests.JPFBenchmark.benchmark54(70.88902111313313,-5.870962480488621E-10,0 ) ;
  }

  @Test
  public void test3141() {
    coral.tests.JPFBenchmark.benchmark54(7.093429979928537,-0.2707932293876414,0 ) ;
  }

  @Test
  public void test3142() {
    coral.tests.JPFBenchmark.benchmark54(70.93709441380497,-0.47864591975763116,0 ) ;
  }

  @Test
  public void test3143() {
    coral.tests.JPFBenchmark.benchmark54(70.97407121273176,-0.017617992440430275,0 ) ;
  }

  @Test
  public void test3144() {
    coral.tests.JPFBenchmark.benchmark54(-70.9742926793074,-0.005054104151093987,12.273969478470486 ) ;
  }

  @Test
  public void test3145() {
    coral.tests.JPFBenchmark.benchmark54(70.98283615851048,-1.7108967340628747E-9,0 ) ;
  }

  @Test
  public void test3146() {
    coral.tests.JPFBenchmark.benchmark54(70.99870150468107,-1.235542833391135,0 ) ;
  }

  @Test
  public void test3147() {
    coral.tests.JPFBenchmark.benchmark54(71.00064137160854,-1.4999999999178872,0 ) ;
  }

  @Test
  public void test3148() {
    coral.tests.JPFBenchmark.benchmark54(71.01357216360987,-0.9199393291720668,0 ) ;
  }

  @Test
  public void test3149() {
    coral.tests.JPFBenchmark.benchmark54(71.03928531434991,-0.9634474935226738,0 ) ;
  }

  @Test
  public void test3150() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.11232353700613729,0 ) ;
  }

  @Test
  public void test3151() {
    coral.tests.JPFBenchmark.benchmark54(-7.105427357601002E-15,-0.1865538889051912,0.706923468274059 ) ;
  }

  @Test
  public void test3152() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.29712707035162467,0 ) ;
  }

  @Test
  public void test3153() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-0.4787589017448113,-0.02204177412179742 ) ;
  }

  @Test
  public void test3154() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.2608304497248377,0 ) ;
  }

  @Test
  public void test3155() {
    coral.tests.JPFBenchmark.benchmark54(7.105427357601002E-15,-1.2868136499144693,0 ) ;
  }

  @Test
  public void test3156() {
    coral.tests.JPFBenchmark.benchmark54(71.0564013242222,-0.6208835311973188,0 ) ;
  }

  @Test
  public void test3157() {
    coral.tests.JPFBenchmark.benchmark54(71.06283787408776,-1.3887924661344657,0 ) ;
  }

  @Test
  public void test3158() {
    coral.tests.JPFBenchmark.benchmark54(-71.09542965977788,-1.3819324816845515,-3.2879033607147986E-6 ) ;
  }

  @Test
  public void test3159() {
    coral.tests.JPFBenchmark.benchmark54(71.12750497012203,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3160() {
    coral.tests.JPFBenchmark.benchmark54(71.16197262750629,-1.2576958928626891,0 ) ;
  }

  @Test
  public void test3161() {
    coral.tests.JPFBenchmark.benchmark54(71.19498973746481,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3162() {
    coral.tests.JPFBenchmark.benchmark54(71.20022598486062,-1.259603889208833,0 ) ;
  }

  @Test
  public void test3163() {
    coral.tests.JPFBenchmark.benchmark54(71.21722167448145,-0.702152101025425,0 ) ;
  }

  @Test
  public void test3164() {
    coral.tests.JPFBenchmark.benchmark54(71.22775556900604,-3.2633226227725526E-9,0 ) ;
  }

  @Test
  public void test3165() {
    coral.tests.JPFBenchmark.benchmark54(71.24319327303087,-1.4999999999999858,0 ) ;
  }

  @Test
  public void test3166() {
    coral.tests.JPFBenchmark.benchmark54(71.25877469452156,-1.2724020753299196E-5,0 ) ;
  }

  @Test
  public void test3167() {
    coral.tests.JPFBenchmark.benchmark54(71.28322847654802,-0.3023903327591456,0 ) ;
  }

  @Test
  public void test3168() {
    coral.tests.JPFBenchmark.benchmark54(71.28803673646466,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3169() {
    coral.tests.JPFBenchmark.benchmark54(-71.29404526227725,-2.220446049250313E-16,1.0000000000018798 ) ;
  }

  @Test
  public void test3170() {
    coral.tests.JPFBenchmark.benchmark54(71.33110430178024,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3171() {
    coral.tests.JPFBenchmark.benchmark54(7.137639025185891,-0.8471268399493712,0 ) ;
  }

  @Test
  public void test3172() {
    coral.tests.JPFBenchmark.benchmark54(71.39632499790996,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3173() {
    coral.tests.JPFBenchmark.benchmark54(7.143075151831653,-1.124610574368535,0 ) ;
  }

  @Test
  public void test3174() {
    coral.tests.JPFBenchmark.benchmark54(-71.43212124880097,-0.24620872424761325,0.06255252537450225 ) ;
  }

  @Test
  public void test3175() {
    coral.tests.JPFBenchmark.benchmark54(71.52207523381041,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3176() {
    coral.tests.JPFBenchmark.benchmark54(71.52704106349566,-0.13289946894380567,0 ) ;
  }

  @Test
  public void test3177() {
    coral.tests.JPFBenchmark.benchmark54(71.54940781761044,-1.1017845286509953,0 ) ;
  }

  @Test
  public void test3178() {
    coral.tests.JPFBenchmark.benchmark54(71.56960463867173,-1.2288843360830997,0 ) ;
  }

  @Test
  public void test3179() {
    coral.tests.JPFBenchmark.benchmark54(-71.57300183280807,44.09522215705158,0 ) ;
  }

  @Test
  public void test3180() {
    coral.tests.JPFBenchmark.benchmark54(7.159158583341622,-1.2761679058413673,0 ) ;
  }

  @Test
  public void test3181() {
    coral.tests.JPFBenchmark.benchmark54(71.61897553056798,-1.3066336293242387,0 ) ;
  }

  @Test
  public void test3182() {
    coral.tests.JPFBenchmark.benchmark54(71.62458749805168,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3183() {
    coral.tests.JPFBenchmark.benchmark54(71.64507969791369,-0.736787870221864,0 ) ;
  }

  @Test
  public void test3184() {
    coral.tests.JPFBenchmark.benchmark54(71.655844199955,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3185() {
    coral.tests.JPFBenchmark.benchmark54(-71.77600285400538,-0.04190373789109439,-0.9049399058623693 ) ;
  }

  @Test
  public void test3186() {
    coral.tests.JPFBenchmark.benchmark54(71.78326926141605,-1.3552730799562343,0 ) ;
  }

  @Test
  public void test3187() {
    coral.tests.JPFBenchmark.benchmark54(71.78971882003457,-0.41539061697798846,0 ) ;
  }

  @Test
  public void test3188() {
    coral.tests.JPFBenchmark.benchmark54(71.79431909353411,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3189() {
    coral.tests.JPFBenchmark.benchmark54(71.79836177806206,-0.3256346626951383,0 ) ;
  }

  @Test
  public void test3190() {
    coral.tests.JPFBenchmark.benchmark54(71.8685514741534,-0.3947271519786675,0 ) ;
  }

  @Test
  public void test3191() {
    coral.tests.JPFBenchmark.benchmark54(71.89529511185418,-1.4011957713624499,0 ) ;
  }

  @Test
  public void test3192() {
    coral.tests.JPFBenchmark.benchmark54(71.95412373250043,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3193() {
    coral.tests.JPFBenchmark.benchmark54(71.95730299538496,-0.9688346722275991,0 ) ;
  }

  @Test
  public void test3194() {
    coral.tests.JPFBenchmark.benchmark54(72.0705299736382,-0.2697419528467262,0 ) ;
  }

  @Test
  public void test3195() {
    coral.tests.JPFBenchmark.benchmark54(72.07333066540833,-0.9715212336932559,0 ) ;
  }

  @Test
  public void test3196() {
    coral.tests.JPFBenchmark.benchmark54(72.09667376756917,-1.2104964300993801,0 ) ;
  }

  @Test
  public void test3197() {
    coral.tests.JPFBenchmark.benchmark54(72.21004354699002,-1.100516612461158,0 ) ;
  }

  @Test
  public void test3198() {
    coral.tests.JPFBenchmark.benchmark54(72.21038698934336,-0.821873997274599,0 ) ;
  }

  @Test
  public void test3199() {
    coral.tests.JPFBenchmark.benchmark54(72.23232512821801,-1.2722132043025374,0 ) ;
  }

  @Test
  public void test3200() {
    coral.tests.JPFBenchmark.benchmark54(72.26127457298489,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3201() {
    coral.tests.JPFBenchmark.benchmark54(72.27091277701953,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3202() {
    coral.tests.JPFBenchmark.benchmark54(72.35166640987339,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3203() {
    coral.tests.JPFBenchmark.benchmark54(72.35545597345637,-0.27226327799893557,0 ) ;
  }

  @Test
  public void test3204() {
    coral.tests.JPFBenchmark.benchmark54(72.37622949408416,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3205() {
    coral.tests.JPFBenchmark.benchmark54(72.39291950915731,-1.2976985832575423,0 ) ;
  }

  @Test
  public void test3206() {
    coral.tests.JPFBenchmark.benchmark54(7.239790233513887,-0.0019074215180128196,0 ) ;
  }

  @Test
  public void test3207() {
    coral.tests.JPFBenchmark.benchmark54(72.44785785910705,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test3208() {
    coral.tests.JPFBenchmark.benchmark54(72.47861471605374,-0.6751305235876934,0 ) ;
  }

  @Test
  public void test3209() {
    coral.tests.JPFBenchmark.benchmark54(7.250844317502626,-1.214005594322785,0 ) ;
  }

  @Test
  public void test3210() {
    coral.tests.JPFBenchmark.benchmark54(72.51004284766896,-1.040234035779605,0 ) ;
  }

  @Test
  public void test3211() {
    coral.tests.JPFBenchmark.benchmark54(7.2570338736147875,-0.04802339584391152,0 ) ;
  }

  @Test
  public void test3212() {
    coral.tests.JPFBenchmark.benchmark54(72.57438377264103,-1.4999999999999831,0 ) ;
  }

  @Test
  public void test3213() {
    coral.tests.JPFBenchmark.benchmark54(72.57582470235285,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3214() {
    coral.tests.JPFBenchmark.benchmark54(72.63120252681426,-0.78976120425243,0 ) ;
  }

  @Test
  public void test3215() {
    coral.tests.JPFBenchmark.benchmark54(72.70361775300717,-0.35008674988075583,0 ) ;
  }

  @Test
  public void test3216() {
    coral.tests.JPFBenchmark.benchmark54(72.70560793828292,-0.4222578399198085,0 ) ;
  }

  @Test
  public void test3217() {
    coral.tests.JPFBenchmark.benchmark54(72.71889456501,-0.002635190008520083,0 ) ;
  }

  @Test
  public void test3218() {
    coral.tests.JPFBenchmark.benchmark54(72.72905321717809,-1.016949201576017,0 ) ;
  }

  @Test
  public void test3219() {
    coral.tests.JPFBenchmark.benchmark54(72.73300545599974,-1.3641345026214076,0 ) ;
  }

  @Test
  public void test3220() {
    coral.tests.JPFBenchmark.benchmark54(72.74500111541752,-1.4293536060345104,0 ) ;
  }

  @Test
  public void test3221() {
    coral.tests.JPFBenchmark.benchmark54(72.79196570481284,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3222() {
    coral.tests.JPFBenchmark.benchmark54(72.81162008816682,-0.7087640183401049,0 ) ;
  }

  @Test
  public void test3223() {
    coral.tests.JPFBenchmark.benchmark54(72.84978456947964,-1.4999974173751063,0 ) ;
  }

  @Test
  public void test3224() {
    coral.tests.JPFBenchmark.benchmark54(72.91528534323649,-1.4999999999999636,0 ) ;
  }

  @Test
  public void test3225() {
    coral.tests.JPFBenchmark.benchmark54(72.93679734268802,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3226() {
    coral.tests.JPFBenchmark.benchmark54(72.9527530629872,-0.04518087326121645,0 ) ;
  }

  @Test
  public void test3227() {
    coral.tests.JPFBenchmark.benchmark54(7.297335958340298,-0.029434976414882408,0 ) ;
  }

  @Test
  public void test3228() {
    coral.tests.JPFBenchmark.benchmark54(73.00267815703614,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3229() {
    coral.tests.JPFBenchmark.benchmark54(73.02190815320901,-0.40172770393262214,0 ) ;
  }

  @Test
  public void test3230() {
    coral.tests.JPFBenchmark.benchmark54(73.02619331497709,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3231() {
    coral.tests.JPFBenchmark.benchmark54(73.06153463929424,-0.8349565694649164,0 ) ;
  }

  @Test
  public void test3232() {
    coral.tests.JPFBenchmark.benchmark54(73.07068299032002,-0.11712466694671364,0 ) ;
  }

  @Test
  public void test3233() {
    coral.tests.JPFBenchmark.benchmark54(73.15444360011739,-1.4999999999999893,0 ) ;
  }

  @Test
  public void test3234() {
    coral.tests.JPFBenchmark.benchmark54(73.1652046755344,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3235() {
    coral.tests.JPFBenchmark.benchmark54(73.16721947034338,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3236() {
    coral.tests.JPFBenchmark.benchmark54(73.20203598255094,-0.1347275325316275,0 ) ;
  }

  @Test
  public void test3237() {
    coral.tests.JPFBenchmark.benchmark54(73.28340374373781,-0.02353376645208982,0 ) ;
  }

  @Test
  public void test3238() {
    coral.tests.JPFBenchmark.benchmark54(73.28924656202395,-0.4539614425726639,0 ) ;
  }

  @Test
  public void test3239() {
    coral.tests.JPFBenchmark.benchmark54(73.34417474562852,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3240() {
    coral.tests.JPFBenchmark.benchmark54(73.38843684395033,-0.4147448774934901,0 ) ;
  }

  @Test
  public void test3241() {
    coral.tests.JPFBenchmark.benchmark54(73.40012732914292,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3242() {
    coral.tests.JPFBenchmark.benchmark54(73.41242523490945,-0.05609277169609239,0 ) ;
  }

  @Test
  public void test3243() {
    coral.tests.JPFBenchmark.benchmark54(-7.341488503223156,-1.7763568394002505E-15,0.9874376833873798 ) ;
  }

  @Test
  public void test3244() {
    coral.tests.JPFBenchmark.benchmark54(-73.44904923161037,-1.3099299815325445,24.757391568751856 ) ;
  }

  @Test
  public void test3245() {
    coral.tests.JPFBenchmark.benchmark54(73.46236222245102,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3246() {
    coral.tests.JPFBenchmark.benchmark54(-73.46238789273087,-1.211019605960563,-65.02814217681947 ) ;
  }

  @Test
  public void test3247() {
    coral.tests.JPFBenchmark.benchmark54(73.4746580941618,-6.237051708800478E-7,0 ) ;
  }

  @Test
  public void test3248() {
    coral.tests.JPFBenchmark.benchmark54(7.347623268862733,-1.2719990955623275,0 ) ;
  }

  @Test
  public void test3249() {
    coral.tests.JPFBenchmark.benchmark54(7.350185570362271,-0.54398681881122,0 ) ;
  }

  @Test
  public void test3250() {
    coral.tests.JPFBenchmark.benchmark54(7.355238023686383,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3251() {
    coral.tests.JPFBenchmark.benchmark54(73.56358496214284,-0.5377653949130201,0 ) ;
  }

  @Test
  public void test3252() {
    coral.tests.JPFBenchmark.benchmark54(73.56651318480277,-0.3581767548277526,0 ) ;
  }

  @Test
  public void test3253() {
    coral.tests.JPFBenchmark.benchmark54(73.5789031557951,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3254() {
    coral.tests.JPFBenchmark.benchmark54(73.61256474901481,-0.1245981844825188,0 ) ;
  }

  @Test
  public void test3255() {
    coral.tests.JPFBenchmark.benchmark54(73.64726574548521,-0.980938243197652,0 ) ;
  }

  @Test
  public void test3256() {
    coral.tests.JPFBenchmark.benchmark54(73.6473203687917,-0.9300422425451851,0 ) ;
  }

  @Test
  public void test3257() {
    coral.tests.JPFBenchmark.benchmark54(73.6824533258241,-0.5756584717890707,0 ) ;
  }

  @Test
  public void test3258() {
    coral.tests.JPFBenchmark.benchmark54(73.68667531527458,-0.33761194889453394,0 ) ;
  }

  @Test
  public void test3259() {
    coral.tests.JPFBenchmark.benchmark54(73.7175833207432,-0.28178788623938544,0 ) ;
  }

  @Test
  public void test3260() {
    coral.tests.JPFBenchmark.benchmark54(73.72330524407374,-1.1753815918677384,0 ) ;
  }

  @Test
  public void test3261() {
    coral.tests.JPFBenchmark.benchmark54(73.76823693517142,-0.7692740394643547,0 ) ;
  }

  @Test
  public void test3262() {
    coral.tests.JPFBenchmark.benchmark54(73.79886468365518,-0.8257952553898207,0 ) ;
  }

  @Test
  public void test3263() {
    coral.tests.JPFBenchmark.benchmark54(73.80741358396764,-6.380578445157308E-10,0 ) ;
  }

  @Test
  public void test3264() {
    coral.tests.JPFBenchmark.benchmark54(73.81062776305697,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3265() {
    coral.tests.JPFBenchmark.benchmark54(73.86270505553742,-0.20713977620813218,0 ) ;
  }

  @Test
  public void test3266() {
    coral.tests.JPFBenchmark.benchmark54(73.88471434689731,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3267() {
    coral.tests.JPFBenchmark.benchmark54(7.3933251982369566,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3268() {
    coral.tests.JPFBenchmark.benchmark54(74.02139204106663,-0.9936022263236719,0 ) ;
  }

  @Test
  public void test3269() {
    coral.tests.JPFBenchmark.benchmark54(74.06501896265516,-1.254724510655767,0 ) ;
  }

  @Test
  public void test3270() {
    coral.tests.JPFBenchmark.benchmark54(74.08038175583442,-1.1495855295484745,0 ) ;
  }

  @Test
  public void test3271() {
    coral.tests.JPFBenchmark.benchmark54(74.09007620803146,-0.4971402611094435,0 ) ;
  }

  @Test
  public void test3272() {
    coral.tests.JPFBenchmark.benchmark54(74.09581664328235,-0.06345251297904042,0 ) ;
  }

  @Test
  public void test3273() {
    coral.tests.JPFBenchmark.benchmark54(74.12565560504942,-0.8702470390465736,0 ) ;
  }

  @Test
  public void test3274() {
    coral.tests.JPFBenchmark.benchmark54(7.413921558695165,-0.6144716779193078,0 ) ;
  }

  @Test
  public void test3275() {
    coral.tests.JPFBenchmark.benchmark54(74.14568484101673,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3276() {
    coral.tests.JPFBenchmark.benchmark54(74.27545801361,-1.317199804242989,0 ) ;
  }

  @Test
  public void test3277() {
    coral.tests.JPFBenchmark.benchmark54(74.29037871591407,-0.42395875600132626,0 ) ;
  }

  @Test
  public void test3278() {
    coral.tests.JPFBenchmark.benchmark54(74.30301955291799,-1.3232079505694765,0 ) ;
  }

  @Test
  public void test3279() {
    coral.tests.JPFBenchmark.benchmark54(74.31647601168748,-0.18646186606328286,0 ) ;
  }

  @Test
  public void test3280() {
    coral.tests.JPFBenchmark.benchmark54(74.32457572118173,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3281() {
    coral.tests.JPFBenchmark.benchmark54(74.38957073981678,-0.08805563455735123,0 ) ;
  }

  @Test
  public void test3282() {
    coral.tests.JPFBenchmark.benchmark54(74.41259108178673,-1.4999999999998828,0 ) ;
  }

  @Test
  public void test3283() {
    coral.tests.JPFBenchmark.benchmark54(74.42193675740737,-0.6209459436335372,0 ) ;
  }

  @Test
  public void test3284() {
    coral.tests.JPFBenchmark.benchmark54(74.45919432199483,-0.9539767173534678,0 ) ;
  }

  @Test
  public void test3285() {
    coral.tests.JPFBenchmark.benchmark54(74.50226544825526,-0.45805098906512143,0 ) ;
  }

  @Test
  public void test3286() {
    coral.tests.JPFBenchmark.benchmark54(74.51268663843175,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3287() {
    coral.tests.JPFBenchmark.benchmark54(74.51616462191058,-0.8434082248146808,0 ) ;
  }

  @Test
  public void test3288() {
    coral.tests.JPFBenchmark.benchmark54(74.56583296506142,-0.16519714190668322,0 ) ;
  }

  @Test
  public void test3289() {
    coral.tests.JPFBenchmark.benchmark54(74.59971986340327,-1.0315018148487842,0 ) ;
  }

  @Test
  public void test3290() {
    coral.tests.JPFBenchmark.benchmark54(74.60824248421528,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3291() {
    coral.tests.JPFBenchmark.benchmark54(7.463425373211294,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3292() {
    coral.tests.JPFBenchmark.benchmark54(74.63815741094555,-0.2666932120351877,0 ) ;
  }

  @Test
  public void test3293() {
    coral.tests.JPFBenchmark.benchmark54(74.6676804887523,-0.8556048584604952,0 ) ;
  }

  @Test
  public void test3294() {
    coral.tests.JPFBenchmark.benchmark54(74.67367156627665,-1.134457199593978,0 ) ;
  }

  @Test
  public void test3295() {
    coral.tests.JPFBenchmark.benchmark54(74.68417859674747,-0.9400836129152417,0 ) ;
  }

  @Test
  public void test3296() {
    coral.tests.JPFBenchmark.benchmark54(74.72219443578638,-0.24661040759310993,0 ) ;
  }

  @Test
  public void test3297() {
    coral.tests.JPFBenchmark.benchmark54(74.73007403812323,-0.5882787424070475,0 ) ;
  }

  @Test
  public void test3298() {
    coral.tests.JPFBenchmark.benchmark54(74.74319305014427,-1.0230501655578652,0 ) ;
  }

  @Test
  public void test3299() {
    coral.tests.JPFBenchmark.benchmark54(7.474637685176887,-1.4999999999999871,0 ) ;
  }

  @Test
  public void test3300() {
    coral.tests.JPFBenchmark.benchmark54(74.80246825044955,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test3301() {
    coral.tests.JPFBenchmark.benchmark54(74.84339366861695,-0.6524148551865636,0 ) ;
  }

  @Test
  public void test3302() {
    coral.tests.JPFBenchmark.benchmark54(74.86103803751882,-1.3421729588812212,0 ) ;
  }

  @Test
  public void test3303() {
    coral.tests.JPFBenchmark.benchmark54(74.86320003692114,-0.3824981956858262,0 ) ;
  }

  @Test
  public void test3304() {
    coral.tests.JPFBenchmark.benchmark54(74.89842234529377,-1.0150324192408382,0 ) ;
  }

  @Test
  public void test3305() {
    coral.tests.JPFBenchmark.benchmark54(74.93075767023271,-1.2131776358804736,0 ) ;
  }

  @Test
  public void test3306() {
    coral.tests.JPFBenchmark.benchmark54(74.95276134274971,-1.2425554044488365,0 ) ;
  }

  @Test
  public void test3307() {
    coral.tests.JPFBenchmark.benchmark54(75.0893334526431,-0.5771357832228767,0 ) ;
  }

  @Test
  public void test3308() {
    coral.tests.JPFBenchmark.benchmark54(75.18414609274956,-0.14076947737019552,0 ) ;
  }

  @Test
  public void test3309() {
    coral.tests.JPFBenchmark.benchmark54(75.1931360343508,-1.6973159821076953E-16,0 ) ;
  }

  @Test
  public void test3310() {
    coral.tests.JPFBenchmark.benchmark54(-75.19938687784284,-1.4999999999999996,-1.06425128967214 ) ;
  }

  @Test
  public void test3311() {
    coral.tests.JPFBenchmark.benchmark54(7.521503664852929,-0.6033539116256748,0 ) ;
  }

  @Test
  public void test3312() {
    coral.tests.JPFBenchmark.benchmark54(75.25496187606932,-4.992217408267802E-10,0 ) ;
  }

  @Test
  public void test3313() {
    coral.tests.JPFBenchmark.benchmark54(75.2565435538786,-1.0465478388102376,0 ) ;
  }

  @Test
  public void test3314() {
    coral.tests.JPFBenchmark.benchmark54(75.30092844347146,-1.4632939430582894,0 ) ;
  }

  @Test
  public void test3315() {
    coral.tests.JPFBenchmark.benchmark54(75.31283777610366,-0.17157579292581882,0 ) ;
  }

  @Test
  public void test3316() {
    coral.tests.JPFBenchmark.benchmark54(75.3310707876528,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3317() {
    coral.tests.JPFBenchmark.benchmark54(75.33699163889759,-0.8941969196984978,0 ) ;
  }

  @Test
  public void test3318() {
    coral.tests.JPFBenchmark.benchmark54(7.537031966246161,-0.9120755972569974,0 ) ;
  }

  @Test
  public void test3319() {
    coral.tests.JPFBenchmark.benchmark54(7.542092534656302,-1.499998002661968,0 ) ;
  }

  @Test
  public void test3320() {
    coral.tests.JPFBenchmark.benchmark54(75.47939871809842,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3321() {
    coral.tests.JPFBenchmark.benchmark54(75.50618316211816,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3322() {
    coral.tests.JPFBenchmark.benchmark54(7.561756570622671,-3.512009457507663E-9,0 ) ;
  }

  @Test
  public void test3323() {
    coral.tests.JPFBenchmark.benchmark54(-75.67344110820527,-1.3075807721643118,1.734723475976807E-18 ) ;
  }

  @Test
  public void test3324() {
    coral.tests.JPFBenchmark.benchmark54(75.67703652099472,-5.0096506160816084E-8,0 ) ;
  }

  @Test
  public void test3325() {
    coral.tests.JPFBenchmark.benchmark54(75.70329150156381,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3326() {
    coral.tests.JPFBenchmark.benchmark54(75.71217145960162,-0.37913531297878933,0 ) ;
  }

  @Test
  public void test3327() {
    coral.tests.JPFBenchmark.benchmark54(75.8313404737151,-0.42826398821504785,0 ) ;
  }

  @Test
  public void test3328() {
    coral.tests.JPFBenchmark.benchmark54(75.84284112945699,-0.28775581140759243,0 ) ;
  }

  @Test
  public void test3329() {
    coral.tests.JPFBenchmark.benchmark54(75.84319808716472,-57.817481261953944,78.38550826556568 ) ;
  }

  @Test
  public void test3330() {
    coral.tests.JPFBenchmark.benchmark54(75.8824077477297,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3331() {
    coral.tests.JPFBenchmark.benchmark54(75.89026492412297,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3332() {
    coral.tests.JPFBenchmark.benchmark54(75.9214563937349,-0.5583514991729572,0 ) ;
  }

  @Test
  public void test3333() {
    coral.tests.JPFBenchmark.benchmark54(7.592240302516046,-1.4555083669002011,0 ) ;
  }

  @Test
  public void test3334() {
    coral.tests.JPFBenchmark.benchmark54(75.92431683859186,-0.31726404625504756,0 ) ;
  }

  @Test
  public void test3335() {
    coral.tests.JPFBenchmark.benchmark54(75.98467600814743,-0.781557979547025,0 ) ;
  }

  @Test
  public void test3336() {
    coral.tests.JPFBenchmark.benchmark54(76.04185891373285,-1.4999995521132734,0 ) ;
  }

  @Test
  public void test3337() {
    coral.tests.JPFBenchmark.benchmark54(7.608053276683286,-0.17404510295537712,0 ) ;
  }

  @Test
  public void test3338() {
    coral.tests.JPFBenchmark.benchmark54(76.10572343092466,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3339() {
    coral.tests.JPFBenchmark.benchmark54(76.12387025290778,-0.39417498333225875,0 ) ;
  }

  @Test
  public void test3340() {
    coral.tests.JPFBenchmark.benchmark54(76.15612089685396,-1.126395185548236,0 ) ;
  }

  @Test
  public void test3341() {
    coral.tests.JPFBenchmark.benchmark54(76.162508138312,-0.2172360858056568,0 ) ;
  }

  @Test
  public void test3342() {
    coral.tests.JPFBenchmark.benchmark54(7.616930665621591,-0.3563973200048397,0 ) ;
  }

  @Test
  public void test3343() {
    coral.tests.JPFBenchmark.benchmark54(76.19636994199912,-3.8114361731357564E-9,0 ) ;
  }

  @Test
  public void test3344() {
    coral.tests.JPFBenchmark.benchmark54(76.21297609288936,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3345() {
    coral.tests.JPFBenchmark.benchmark54(76.24922153657471,-1.380127623456703,0 ) ;
  }

  @Test
  public void test3346() {
    coral.tests.JPFBenchmark.benchmark54(76.25214486284582,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3347() {
    coral.tests.JPFBenchmark.benchmark54(76.25887586049171,-1.3033118852817656,0 ) ;
  }

  @Test
  public void test3348() {
    coral.tests.JPFBenchmark.benchmark54(76.30279393890604,-0.07814522767155302,0 ) ;
  }

  @Test
  public void test3349() {
    coral.tests.JPFBenchmark.benchmark54(76.32588024233903,-0.24617022062555138,0 ) ;
  }

  @Test
  public void test3350() {
    coral.tests.JPFBenchmark.benchmark54(76.34474837750976,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3351() {
    coral.tests.JPFBenchmark.benchmark54(76.34726080066824,-0.8931324095407973,0 ) ;
  }

  @Test
  public void test3352() {
    coral.tests.JPFBenchmark.benchmark54(76.44778576711705,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3353() {
    coral.tests.JPFBenchmark.benchmark54(76.47103821827665,-0.8594851197181701,0 ) ;
  }

  @Test
  public void test3354() {
    coral.tests.JPFBenchmark.benchmark54(76.49291256922474,-0.12193764899702038,0 ) ;
  }

  @Test
  public void test3355() {
    coral.tests.JPFBenchmark.benchmark54(76.52486825681927,-0.037924228079944555,0 ) ;
  }

  @Test
  public void test3356() {
    coral.tests.JPFBenchmark.benchmark54(76.5702238067393,-1.4560014078405819,0 ) ;
  }

  @Test
  public void test3357() {
    coral.tests.JPFBenchmark.benchmark54(76.57325066031953,-0.6064518772845534,0 ) ;
  }

  @Test
  public void test3358() {
    coral.tests.JPFBenchmark.benchmark54(76.65253209292776,-0.8577455291359419,0 ) ;
  }

  @Test
  public void test3359() {
    coral.tests.JPFBenchmark.benchmark54(76.67178410956399,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3360() {
    coral.tests.JPFBenchmark.benchmark54(76.6806529711836,-0.7168025720876869,0 ) ;
  }

  @Test
  public void test3361() {
    coral.tests.JPFBenchmark.benchmark54(76.71887126850504,-0.6549841731549861,0 ) ;
  }

  @Test
  public void test3362() {
    coral.tests.JPFBenchmark.benchmark54(76.7201624308992,-1.1518250517444315,0 ) ;
  }

  @Test
  public void test3363() {
    coral.tests.JPFBenchmark.benchmark54(7.67531240804454,-0.005568309275271076,0 ) ;
  }

  @Test
  public void test3364() {
    coral.tests.JPFBenchmark.benchmark54(76.82074843439503,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3365() {
    coral.tests.JPFBenchmark.benchmark54(76.82243731638877,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3366() {
    coral.tests.JPFBenchmark.benchmark54(76.83238998266623,-0.35512978277749996,0 ) ;
  }

  @Test
  public void test3367() {
    coral.tests.JPFBenchmark.benchmark54(76.8950611562718,-0.1987406635510065,0 ) ;
  }

  @Test
  public void test3368() {
    coral.tests.JPFBenchmark.benchmark54(7.690583654235269,-0.18128650915687672,0 ) ;
  }

  @Test
  public void test3369() {
    coral.tests.JPFBenchmark.benchmark54(76.93424015627461,-4.5689412987307E-5,0 ) ;
  }

  @Test
  public void test3370() {
    coral.tests.JPFBenchmark.benchmark54(76.93450559411852,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3371() {
    coral.tests.JPFBenchmark.benchmark54(77.02506818051154,-0.09807869196051744,0 ) ;
  }

  @Test
  public void test3372() {
    coral.tests.JPFBenchmark.benchmark54(77.02875979289686,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3373() {
    coral.tests.JPFBenchmark.benchmark54(77.03393866247458,-1.4153477716966734,0 ) ;
  }

  @Test
  public void test3374() {
    coral.tests.JPFBenchmark.benchmark54(77.05127915314617,-0.8770600148936998,0 ) ;
  }

  @Test
  public void test3375() {
    coral.tests.JPFBenchmark.benchmark54(77.05550283424952,-1.1209700119797188,0 ) ;
  }

  @Test
  public void test3376() {
    coral.tests.JPFBenchmark.benchmark54(77.08111921254897,-1.2408523218141805,0 ) ;
  }

  @Test
  public void test3377() {
    coral.tests.JPFBenchmark.benchmark54(77.08615232387936,-1.018896078224456,0 ) ;
  }

  @Test
  public void test3378() {
    coral.tests.JPFBenchmark.benchmark54(77.10456224897345,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3379() {
    coral.tests.JPFBenchmark.benchmark54(77.11854595902008,-0.5204428207260037,0 ) ;
  }

  @Test
  public void test3380() {
    coral.tests.JPFBenchmark.benchmark54(77.1658156160207,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3381() {
    coral.tests.JPFBenchmark.benchmark54(77.19619168215775,-1.38671227137152,0 ) ;
  }

  @Test
  public void test3382() {
    coral.tests.JPFBenchmark.benchmark54(7.721799590385984,-1.3627387795640413,0 ) ;
  }

  @Test
  public void test3383() {
    coral.tests.JPFBenchmark.benchmark54(77.24635918187313,-1.0497698139751324E-7,0 ) ;
  }

  @Test
  public void test3384() {
    coral.tests.JPFBenchmark.benchmark54(77.25418865955453,-0.13241209848391122,0 ) ;
  }

  @Test
  public void test3385() {
    coral.tests.JPFBenchmark.benchmark54(7.726277942852249,-0.8871141404817422,0 ) ;
  }

  @Test
  public void test3386() {
    coral.tests.JPFBenchmark.benchmark54(77.28840372298805,-0.8031363937001572,0 ) ;
  }

  @Test
  public void test3387() {
    coral.tests.JPFBenchmark.benchmark54(77.29782732793666,-3.167680260464119E-7,0 ) ;
  }

  @Test
  public void test3388() {
    coral.tests.JPFBenchmark.benchmark54(77.30198999994424,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3389() {
    coral.tests.JPFBenchmark.benchmark54(77.30996780574358,-0.6250211742594729,0 ) ;
  }

  @Test
  public void test3390() {
    coral.tests.JPFBenchmark.benchmark54(77.31341835136126,-0.8730550462154282,0 ) ;
  }

  @Test
  public void test3391() {
    coral.tests.JPFBenchmark.benchmark54(77.32952414376416,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3392() {
    coral.tests.JPFBenchmark.benchmark54(77.40099127423292,-1.1152557668349816,0 ) ;
  }

  @Test
  public void test3393() {
    coral.tests.JPFBenchmark.benchmark54(77.41607628130802,-1.137128737376385,0 ) ;
  }

  @Test
  public void test3394() {
    coral.tests.JPFBenchmark.benchmark54(77.41813989505789,-0.25217455725082816,0 ) ;
  }

  @Test
  public void test3395() {
    coral.tests.JPFBenchmark.benchmark54(7.742053434099688,-1.0785405240943136,0 ) ;
  }

  @Test
  public void test3396() {
    coral.tests.JPFBenchmark.benchmark54(77.51333006389669,-0.13184722636690083,0 ) ;
  }

  @Test
  public void test3397() {
    coral.tests.JPFBenchmark.benchmark54(77.51951371250675,-1.382027221807885,0 ) ;
  }

  @Test
  public void test3398() {
    coral.tests.JPFBenchmark.benchmark54(77.52763345475259,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3399() {
    coral.tests.JPFBenchmark.benchmark54(77.58727723530023,-0.07612239643622765,0 ) ;
  }

  @Test
  public void test3400() {
    coral.tests.JPFBenchmark.benchmark54(77.60463769115445,-4.3560383061060364E-4,0 ) ;
  }

  @Test
  public void test3401() {
    coral.tests.JPFBenchmark.benchmark54(77.60645505239765,-1.4999999999999485,0 ) ;
  }

  @Test
  public void test3402() {
    coral.tests.JPFBenchmark.benchmark54(77.62912914563341,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3403() {
    coral.tests.JPFBenchmark.benchmark54(77.64433069215985,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3404() {
    coral.tests.JPFBenchmark.benchmark54(77.72454023459188,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3405() {
    coral.tests.JPFBenchmark.benchmark54(77.75109511111692,-0.8098662414403321,0 ) ;
  }

  @Test
  public void test3406() {
    coral.tests.JPFBenchmark.benchmark54(77.76958279634826,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3407() {
    coral.tests.JPFBenchmark.benchmark54(77.77141862419036,-9.175882054735409E-10,0 ) ;
  }

  @Test
  public void test3408() {
    coral.tests.JPFBenchmark.benchmark54(77.7814447634751,-1.0380648912201478,0 ) ;
  }

  @Test
  public void test3409() {
    coral.tests.JPFBenchmark.benchmark54(77.79761320432371,-0.15949500148148843,0 ) ;
  }

  @Test
  public void test3410() {
    coral.tests.JPFBenchmark.benchmark54(77.80601233028298,-1.3909801675563633,0 ) ;
  }

  @Test
  public void test3411() {
    coral.tests.JPFBenchmark.benchmark54(7.782458161482737,-1.1866106135892502,0 ) ;
  }

  @Test
  public void test3412() {
    coral.tests.JPFBenchmark.benchmark54(77.83896953385937,-0.7650096437293143,0 ) ;
  }

  @Test
  public void test3413() {
    coral.tests.JPFBenchmark.benchmark54(77.86441488816664,-0.8925434544541596,0 ) ;
  }

  @Test
  public void test3414() {
    coral.tests.JPFBenchmark.benchmark54(77.95728141519547,-0.0019616774233111737,0 ) ;
  }

  @Test
  public void test3415() {
    coral.tests.JPFBenchmark.benchmark54(77.97775107045378,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3416() {
    coral.tests.JPFBenchmark.benchmark54(7.799005409911516,-0.22621078458708133,0 ) ;
  }

  @Test
  public void test3417() {
    coral.tests.JPFBenchmark.benchmark54(7.80530727641171,-1.365544279345622,0 ) ;
  }

  @Test
  public void test3418() {
    coral.tests.JPFBenchmark.benchmark54(78.05525906877224,-0.10151239505951146,0 ) ;
  }

  @Test
  public void test3419() {
    coral.tests.JPFBenchmark.benchmark54(78.1001255304565,-0.677592714922246,0 ) ;
  }

  @Test
  public void test3420() {
    coral.tests.JPFBenchmark.benchmark54(78.11582058379796,-0.12080829038407614,0 ) ;
  }

  @Test
  public void test3421() {
    coral.tests.JPFBenchmark.benchmark54(78.12230627941267,-0.44275995927591794,0 ) ;
  }

  @Test
  public void test3422() {
    coral.tests.JPFBenchmark.benchmark54(78.1460578767022,-0.8860856167403841,0 ) ;
  }

  @Test
  public void test3423() {
    coral.tests.JPFBenchmark.benchmark54(78.17799994198123,-0.45550794677902706,0 ) ;
  }

  @Test
  public void test3424() {
    coral.tests.JPFBenchmark.benchmark54(78.19908752926759,-1.1619850021304252,0 ) ;
  }

  @Test
  public void test3425() {
    coral.tests.JPFBenchmark.benchmark54(78.23214838810313,-0.1602202794137371,0 ) ;
  }

  @Test
  public void test3426() {
    coral.tests.JPFBenchmark.benchmark54(78.30003520794466,-0.22114034101059588,0 ) ;
  }

  @Test
  public void test3427() {
    coral.tests.JPFBenchmark.benchmark54(78.33184376739057,-1.3014917555158494,0 ) ;
  }

  @Test
  public void test3428() {
    coral.tests.JPFBenchmark.benchmark54(78.3355361645443,-0.8226037647508049,0 ) ;
  }

  @Test
  public void test3429() {
    coral.tests.JPFBenchmark.benchmark54(78.34822824711915,-1.1968171299211718,0 ) ;
  }

  @Test
  public void test3430() {
    coral.tests.JPFBenchmark.benchmark54(78.39596488117016,-0.2390921639169168,0 ) ;
  }

  @Test
  public void test3431() {
    coral.tests.JPFBenchmark.benchmark54(78.42748641729463,-0.6192968913167505,0 ) ;
  }

  @Test
  public void test3432() {
    coral.tests.JPFBenchmark.benchmark54(78.46844903647937,-0.5025417458340542,0 ) ;
  }

  @Test
  public void test3433() {
    coral.tests.JPFBenchmark.benchmark54(78.47831480833221,-0.2283725594305528,0 ) ;
  }

  @Test
  public void test3434() {
    coral.tests.JPFBenchmark.benchmark54(78.54749932340354,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3435() {
    coral.tests.JPFBenchmark.benchmark54(78.56365000453414,-1.0835189482737873,0 ) ;
  }

  @Test
  public void test3436() {
    coral.tests.JPFBenchmark.benchmark54(78.61386727462576,-0.6144119460879844,0 ) ;
  }

  @Test
  public void test3437() {
    coral.tests.JPFBenchmark.benchmark54(78.6183272669577,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3438() {
    coral.tests.JPFBenchmark.benchmark54(78.68015170627274,-1.0572017119397241,0 ) ;
  }

  @Test
  public void test3439() {
    coral.tests.JPFBenchmark.benchmark54(78.72245956428782,-0.6801485269557386,0 ) ;
  }

  @Test
  public void test3440() {
    coral.tests.JPFBenchmark.benchmark54(78.7664835535833,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3441() {
    coral.tests.JPFBenchmark.benchmark54(78.78740714424265,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3442() {
    coral.tests.JPFBenchmark.benchmark54(78.80544426573925,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3443() {
    coral.tests.JPFBenchmark.benchmark54(78.83976524412444,98.75477730504772,97.19905846505881 ) ;
  }

  @Test
  public void test3444() {
    coral.tests.JPFBenchmark.benchmark54(78.87133778491295,-1.0545466468226774,0 ) ;
  }

  @Test
  public void test3445() {
    coral.tests.JPFBenchmark.benchmark54(78.87796965105768,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3446() {
    coral.tests.JPFBenchmark.benchmark54(7.890864584892185,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3447() {
    coral.tests.JPFBenchmark.benchmark54(78.91491079098742,-1.448538942069054,0 ) ;
  }

  @Test
  public void test3448() {
    coral.tests.JPFBenchmark.benchmark54(78.91884044038645,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3449() {
    coral.tests.JPFBenchmark.benchmark54(78.91892223248472,-1.1412316102458197E-7,0 ) ;
  }

  @Test
  public void test3450() {
    coral.tests.JPFBenchmark.benchmark54(78.93931023433029,-0.3139501633481092,0 ) ;
  }

  @Test
  public void test3451() {
    coral.tests.JPFBenchmark.benchmark54(78.9688717542691,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3452() {
    coral.tests.JPFBenchmark.benchmark54(7.898401036326603,-6.969339136542652E-7,0 ) ;
  }

  @Test
  public void test3453() {
    coral.tests.JPFBenchmark.benchmark54(79.00031045607726,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3454() {
    coral.tests.JPFBenchmark.benchmark54(79.000329912269,-0.023473478241730288,0 ) ;
  }

  @Test
  public void test3455() {
    coral.tests.JPFBenchmark.benchmark54(79.00570015480999,-0.48562577819572805,0 ) ;
  }

  @Test
  public void test3456() {
    coral.tests.JPFBenchmark.benchmark54(7.900866082574246,-1.4404796586277313,0 ) ;
  }

  @Test
  public void test3457() {
    coral.tests.JPFBenchmark.benchmark54(79.01153337565532,-1.150202051794568,0 ) ;
  }

  @Test
  public void test3458() {
    coral.tests.JPFBenchmark.benchmark54(79.02689857489172,-2.895241356068667E-9,0 ) ;
  }

  @Test
  public void test3459() {
    coral.tests.JPFBenchmark.benchmark54(79.09751671499353,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3460() {
    coral.tests.JPFBenchmark.benchmark54(79.11549465385838,-1.4338490316070862,0 ) ;
  }

  @Test
  public void test3461() {
    coral.tests.JPFBenchmark.benchmark54(79.13502779086966,-0.9352621573348117,0 ) ;
  }

  @Test
  public void test3462() {
    coral.tests.JPFBenchmark.benchmark54(79.16374907921573,-0.7554398288581297,0 ) ;
  }

  @Test
  public void test3463() {
    coral.tests.JPFBenchmark.benchmark54(79.2118928234714,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3464() {
    coral.tests.JPFBenchmark.benchmark54(79.26831438657223,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3465() {
    coral.tests.JPFBenchmark.benchmark54(79.2984325965966,-1.285697890032088,0 ) ;
  }

  @Test
  public void test3466() {
    coral.tests.JPFBenchmark.benchmark54(79.32197196520144,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3467() {
    coral.tests.JPFBenchmark.benchmark54(79.32682077981545,-0.7896816286695678,0 ) ;
  }

  @Test
  public void test3468() {
    coral.tests.JPFBenchmark.benchmark54(79.32720363243808,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3469() {
    coral.tests.JPFBenchmark.benchmark54(-79.33600638346776,-4.440892098500626E-16,43.50924131400228 ) ;
  }

  @Test
  public void test3470() {
    coral.tests.JPFBenchmark.benchmark54(7.936387623209334,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3471() {
    coral.tests.JPFBenchmark.benchmark54(79.37059649427809,-1.0044547273893691,0 ) ;
  }

  @Test
  public void test3472() {
    coral.tests.JPFBenchmark.benchmark54(79.37513474961577,-0.5978024468105745,0 ) ;
  }

  @Test
  public void test3473() {
    coral.tests.JPFBenchmark.benchmark54(79.39823110419343,-0.5350625660207022,0 ) ;
  }

  @Test
  public void test3474() {
    coral.tests.JPFBenchmark.benchmark54(7.941114250894103,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3475() {
    coral.tests.JPFBenchmark.benchmark54(-79.45360813668418,-1.4999999999999982,77.32764739420259 ) ;
  }

  @Test
  public void test3476() {
    coral.tests.JPFBenchmark.benchmark54(79.48607473603494,-1.4977989950970887,0 ) ;
  }

  @Test
  public void test3477() {
    coral.tests.JPFBenchmark.benchmark54(79.50035270823474,-1.4796759892777231,0 ) ;
  }

  @Test
  public void test3478() {
    coral.tests.JPFBenchmark.benchmark54(79.51771738243167,-0.8688888416274931,0 ) ;
  }

  @Test
  public void test3479() {
    coral.tests.JPFBenchmark.benchmark54(79.67260843228237,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3480() {
    coral.tests.JPFBenchmark.benchmark54(79.68808975136305,-0.27128405766214225,0 ) ;
  }

  @Test
  public void test3481() {
    coral.tests.JPFBenchmark.benchmark54(79.70251539630276,-1.4325592322227059E-8,0 ) ;
  }

  @Test
  public void test3482() {
    coral.tests.JPFBenchmark.benchmark54(79.70399348441023,-0.055923287591483344,0 ) ;
  }

  @Test
  public void test3483() {
    coral.tests.JPFBenchmark.benchmark54(79.70544994494833,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3484() {
    coral.tests.JPFBenchmark.benchmark54(79.70682181255592,-0.8925243035544989,0 ) ;
  }

  @Test
  public void test3485() {
    coral.tests.JPFBenchmark.benchmark54(79.71360767384728,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3486() {
    coral.tests.JPFBenchmark.benchmark54(-79.72284230564375,-0.15394910546704665,-0.01538563973395446 ) ;
  }

  @Test
  public void test3487() {
    coral.tests.JPFBenchmark.benchmark54(-79.75411033979564,-2.220446049250313E-16,-98.69175351800946 ) ;
  }

  @Test
  public void test3488() {
    coral.tests.JPFBenchmark.benchmark54(79.76781933075102,-1.214429299727454,0 ) ;
  }

  @Test
  public void test3489() {
    coral.tests.JPFBenchmark.benchmark54(79.78477716982579,-0.8015031367974075,0 ) ;
  }

  @Test
  public void test3490() {
    coral.tests.JPFBenchmark.benchmark54(79.81971411034613,-7.091748697607007E-10,0 ) ;
  }

  @Test
  public void test3491() {
    coral.tests.JPFBenchmark.benchmark54(79.82345195293351,-0.5596419435034248,0 ) ;
  }

  @Test
  public void test3492() {
    coral.tests.JPFBenchmark.benchmark54(7.982359636692035,-0.9325309239116456,0 ) ;
  }

  @Test
  public void test3493() {
    coral.tests.JPFBenchmark.benchmark54(79.83488969742362,-0.2091950595724285,0 ) ;
  }

  @Test
  public void test3494() {
    coral.tests.JPFBenchmark.benchmark54(79.89978286482129,-9.916504562066705E-6,0 ) ;
  }

  @Test
  public void test3495() {
    coral.tests.JPFBenchmark.benchmark54(79.92118620474253,-0.0738913790787521,0 ) ;
  }

  @Test
  public void test3496() {
    coral.tests.JPFBenchmark.benchmark54(79.92427562882324,-0.2557005721928505,0 ) ;
  }

  @Test
  public void test3497() {
    coral.tests.JPFBenchmark.benchmark54(-79.9331152138284,-6.964388539457112E-5,-0.9786666960277424 ) ;
  }

  @Test
  public void test3498() {
    coral.tests.JPFBenchmark.benchmark54(79.96116140947358,-0.4341968586272615,0 ) ;
  }

  @Test
  public void test3499() {
    coral.tests.JPFBenchmark.benchmark54(79.97854080639769,-0.762218287004595,0 ) ;
  }

  @Test
  public void test3500() {
    coral.tests.JPFBenchmark.benchmark54(79.98820845237924,-0.0789210901002223,0 ) ;
  }

  @Test
  public void test3501() {
    coral.tests.JPFBenchmark.benchmark54(80.01256488648029,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3502() {
    coral.tests.JPFBenchmark.benchmark54(80.02450951442424,-0.6773867775544837,0 ) ;
  }

  @Test
  public void test3503() {
    coral.tests.JPFBenchmark.benchmark54(8.004349494901476,-1.39576064773766,0 ) ;
  }

  @Test
  public void test3504() {
    coral.tests.JPFBenchmark.benchmark54(80.06192950631052,-1.2554653958868336,0 ) ;
  }

  @Test
  public void test3505() {
    coral.tests.JPFBenchmark.benchmark54(80.08696426235056,-0.27586398362149245,0 ) ;
  }

  @Test
  public void test3506() {
    coral.tests.JPFBenchmark.benchmark54(80.10065514899048,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3507() {
    coral.tests.JPFBenchmark.benchmark54(80.13747942640276,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3508() {
    coral.tests.JPFBenchmark.benchmark54(80.13906091830063,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3509() {
    coral.tests.JPFBenchmark.benchmark54(80.14792739822815,-1.0203023533158984,0 ) ;
  }

  @Test
  public void test3510() {
    coral.tests.JPFBenchmark.benchmark54(80.15005508269167,-1.1580594301903133,0 ) ;
  }

  @Test
  public void test3511() {
    coral.tests.JPFBenchmark.benchmark54(80.18189415830929,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3512() {
    coral.tests.JPFBenchmark.benchmark54(80.1926784429854,-0.9755049936826197,0 ) ;
  }

  @Test
  public void test3513() {
    coral.tests.JPFBenchmark.benchmark54(80.23537567949359,-0.8575999337421774,0 ) ;
  }

  @Test
  public void test3514() {
    coral.tests.JPFBenchmark.benchmark54(80.2648961017374,-0.30771598254608534,0 ) ;
  }

  @Test
  public void test3515() {
    coral.tests.JPFBenchmark.benchmark54(80.27684402910467,-1.320970918771323,0 ) ;
  }

  @Test
  public void test3516() {
    coral.tests.JPFBenchmark.benchmark54(80.39113586374296,-0.8530869344432404,0 ) ;
  }

  @Test
  public void test3517() {
    coral.tests.JPFBenchmark.benchmark54(80.4091963126573,-0.7839837656071658,0 ) ;
  }

  @Test
  public void test3518() {
    coral.tests.JPFBenchmark.benchmark54(80.41463200067521,-1.216157696114557,0 ) ;
  }

  @Test
  public void test3519() {
    coral.tests.JPFBenchmark.benchmark54(80.41900503283745,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3520() {
    coral.tests.JPFBenchmark.benchmark54(80.46454022880792,-0.12057938346664199,0 ) ;
  }

  @Test
  public void test3521() {
    coral.tests.JPFBenchmark.benchmark54(8.046765903226529,-1.0058385269849714,0 ) ;
  }

  @Test
  public void test3522() {
    coral.tests.JPFBenchmark.benchmark54(80.4794183250583,-1.162544014752001,0 ) ;
  }

  @Test
  public void test3523() {
    coral.tests.JPFBenchmark.benchmark54(80.51112004593428,-1.2413804946386477,0 ) ;
  }

  @Test
  public void test3524() {
    coral.tests.JPFBenchmark.benchmark54(80.5148005547438,-0.5110235407217524,0 ) ;
  }

  @Test
  public void test3525() {
    coral.tests.JPFBenchmark.benchmark54(80.64337499304621,-6.063877863135928E-8,0 ) ;
  }

  @Test
  public void test3526() {
    coral.tests.JPFBenchmark.benchmark54(80.65097809381152,-0.3080383912873419,0 ) ;
  }

  @Test
  public void test3527() {
    coral.tests.JPFBenchmark.benchmark54(8.069474394814385,-1.642208903072088E-8,0 ) ;
  }

  @Test
  public void test3528() {
    coral.tests.JPFBenchmark.benchmark54(80.77123888559672,-0.6381535088199115,0 ) ;
  }

  @Test
  public void test3529() {
    coral.tests.JPFBenchmark.benchmark54(80.79881390813415,-0.3277856894713125,0 ) ;
  }

  @Test
  public void test3530() {
    coral.tests.JPFBenchmark.benchmark54(80.852075203347,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3531() {
    coral.tests.JPFBenchmark.benchmark54(80.90449118705146,-0.18916751465106074,0 ) ;
  }

  @Test
  public void test3532() {
    coral.tests.JPFBenchmark.benchmark54(8.090486230950152,-0.9704658885336988,0 ) ;
  }

  @Test
  public void test3533() {
    coral.tests.JPFBenchmark.benchmark54(80.93556207661155,-1.4999999999999627,0 ) ;
  }

  @Test
  public void test3534() {
    coral.tests.JPFBenchmark.benchmark54(80.95345545462692,-0.4469634064153979,0 ) ;
  }

  @Test
  public void test3535() {
    coral.tests.JPFBenchmark.benchmark54(80.99742857361915,-1.0961290420523007,0 ) ;
  }

  @Test
  public void test3536() {
    coral.tests.JPFBenchmark.benchmark54(8.1002228404415,-6.094840939926817E-10,0 ) ;
  }

  @Test
  public void test3537() {
    coral.tests.JPFBenchmark.benchmark54(81.00694853529222,-1.278761842957808,0 ) ;
  }

  @Test
  public void test3538() {
    coral.tests.JPFBenchmark.benchmark54(-81.0223243067435,-0.06038341864572341,85.49084703956076 ) ;
  }

  @Test
  public void test3539() {
    coral.tests.JPFBenchmark.benchmark54(81.0615583689412,-0.5449841940636118,0 ) ;
  }

  @Test
  public void test3540() {
    coral.tests.JPFBenchmark.benchmark54(81.07829610027159,-0.2909049156273301,0 ) ;
  }

  @Test
  public void test3541() {
    coral.tests.JPFBenchmark.benchmark54(81.09025969539897,-1.4999999999567544,0 ) ;
  }

  @Test
  public void test3542() {
    coral.tests.JPFBenchmark.benchmark54(81.10250666528125,-1.3818964265429694,0 ) ;
  }

  @Test
  public void test3543() {
    coral.tests.JPFBenchmark.benchmark54(81.13592489888973,-0.9550630483743419,0 ) ;
  }

  @Test
  public void test3544() {
    coral.tests.JPFBenchmark.benchmark54(81.14921885613171,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3545() {
    coral.tests.JPFBenchmark.benchmark54(81.17636313568218,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3546() {
    coral.tests.JPFBenchmark.benchmark54(81.17645437217331,-0.4764038752662785,0 ) ;
  }

  @Test
  public void test3547() {
    coral.tests.JPFBenchmark.benchmark54(81.23363178171661,-1.1840644386243557,0 ) ;
  }

  @Test
  public void test3548() {
    coral.tests.JPFBenchmark.benchmark54(81.3669197809097,-1.920280556327233E-8,0 ) ;
  }

  @Test
  public void test3549() {
    coral.tests.JPFBenchmark.benchmark54(-81.37892781615808,-0.011440128941314874,-1.0 ) ;
  }

  @Test
  public void test3550() {
    coral.tests.JPFBenchmark.benchmark54(81.38600915635004,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3551() {
    coral.tests.JPFBenchmark.benchmark54(81.39084842550015,-2.9240514897817245E-8,0 ) ;
  }

  @Test
  public void test3552() {
    coral.tests.JPFBenchmark.benchmark54(8.140500866582087,-0.10015312771250251,0 ) ;
  }

  @Test
  public void test3553() {
    coral.tests.JPFBenchmark.benchmark54(-81.42954183238926,-1.4867615896242494,0 ) ;
  }

  @Test
  public void test3554() {
    coral.tests.JPFBenchmark.benchmark54(81.47664960238944,-1.4426249587323359,0 ) ;
  }

  @Test
  public void test3555() {
    coral.tests.JPFBenchmark.benchmark54(8.148181191855059,-0.08170419298586165,0 ) ;
  }

  @Test
  public void test3556() {
    coral.tests.JPFBenchmark.benchmark54(81.48868555380913,-0.20377638674477527,0 ) ;
  }

  @Test
  public void test3557() {
    coral.tests.JPFBenchmark.benchmark54(81.49463259655097,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3558() {
    coral.tests.JPFBenchmark.benchmark54(-81.5440292124911,-1.4999999999999998,0.0 ) ;
  }

  @Test
  public void test3559() {
    coral.tests.JPFBenchmark.benchmark54(81.56446813051025,-0.5195443342276533,0 ) ;
  }

  @Test
  public void test3560() {
    coral.tests.JPFBenchmark.benchmark54(81.59097352048865,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test3561() {
    coral.tests.JPFBenchmark.benchmark54(81.63704700266364,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3562() {
    coral.tests.JPFBenchmark.benchmark54(-81.64387975969177,-9.268057001857002,59.25986968024765 ) ;
  }

  @Test
  public void test3563() {
    coral.tests.JPFBenchmark.benchmark54(81.6510034168812,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3564() {
    coral.tests.JPFBenchmark.benchmark54(81.65467842364771,-1.0888716987479368,0 ) ;
  }

  @Test
  public void test3565() {
    coral.tests.JPFBenchmark.benchmark54(81.69829464897968,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3566() {
    coral.tests.JPFBenchmark.benchmark54(8.170049107564068,-0.5778095120436335,0 ) ;
  }

  @Test
  public void test3567() {
    coral.tests.JPFBenchmark.benchmark54(81.73631141445583,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3568() {
    coral.tests.JPFBenchmark.benchmark54(81.74473304656522,-0.8463139039114793,0 ) ;
  }

  @Test
  public void test3569() {
    coral.tests.JPFBenchmark.benchmark54(-81.75876469218662,-1.3793675078624377,2.6871504430268355E-138 ) ;
  }

  @Test
  public void test3570() {
    coral.tests.JPFBenchmark.benchmark54(81.8223232977808,-0.5142459797542358,0 ) ;
  }

  @Test
  public void test3571() {
    coral.tests.JPFBenchmark.benchmark54(81.83693621161689,-0.1482479882215273,0 ) ;
  }

  @Test
  public void test3572() {
    coral.tests.JPFBenchmark.benchmark54(81.87488477268778,-0.5327071651614261,0 ) ;
  }

  @Test
  public void test3573() {
    coral.tests.JPFBenchmark.benchmark54(81.89789313839327,-0.6479850064269861,0 ) ;
  }

  @Test
  public void test3574() {
    coral.tests.JPFBenchmark.benchmark54(81.94327713358928,-0.19904748668051297,0 ) ;
  }

  @Test
  public void test3575() {
    coral.tests.JPFBenchmark.benchmark54(81.96133970095721,-0.5786067254169467,0 ) ;
  }

  @Test
  public void test3576() {
    coral.tests.JPFBenchmark.benchmark54(81.96791320256096,-0.9169748997200884,0 ) ;
  }

  @Test
  public void test3577() {
    coral.tests.JPFBenchmark.benchmark54(81.98927742621271,-0.048670296005866476,0 ) ;
  }

  @Test
  public void test3578() {
    coral.tests.JPFBenchmark.benchmark54(82.02522105644148,-1.32416655363406,0 ) ;
  }

  @Test
  public void test3579() {
    coral.tests.JPFBenchmark.benchmark54(82.03161531983105,-0.3001456887414635,0 ) ;
  }

  @Test
  public void test3580() {
    coral.tests.JPFBenchmark.benchmark54(82.05974719249598,-1.4688810583366938,0 ) ;
  }

  @Test
  public void test3581() {
    coral.tests.JPFBenchmark.benchmark54(82.1264853183142,-1.3400067948924126,0 ) ;
  }

  @Test
  public void test3582() {
    coral.tests.JPFBenchmark.benchmark54(82.1483810279552,-1.080166020396689,0 ) ;
  }

  @Test
  public void test3583() {
    coral.tests.JPFBenchmark.benchmark54(82.1540529444105,-1.313212985371718,0 ) ;
  }

  @Test
  public void test3584() {
    coral.tests.JPFBenchmark.benchmark54(82.17751142677014,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3585() {
    coral.tests.JPFBenchmark.benchmark54(82.2949516298475,-0.17606033073597205,0 ) ;
  }

  @Test
  public void test3586() {
    coral.tests.JPFBenchmark.benchmark54(82.36823357202749,-6.345690609033613E-7,0 ) ;
  }

  @Test
  public void test3587() {
    coral.tests.JPFBenchmark.benchmark54(-82.40940236583111,-0.11025032983468797,0.8815608148804499 ) ;
  }

  @Test
  public void test3588() {
    coral.tests.JPFBenchmark.benchmark54(82.41358604823847,-0.44210759436458247,0 ) ;
  }

  @Test
  public void test3589() {
    coral.tests.JPFBenchmark.benchmark54(82.43466228968745,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3590() {
    coral.tests.JPFBenchmark.benchmark54(82.44212664143973,-0.8616369070569334,0 ) ;
  }

  @Test
  public void test3591() {
    coral.tests.JPFBenchmark.benchmark54(8.245488067821167,-9.402359491254337E-17,0 ) ;
  }

  @Test
  public void test3592() {
    coral.tests.JPFBenchmark.benchmark54(82.48024013118959,-0.5367750674736183,0 ) ;
  }

  @Test
  public void test3593() {
    coral.tests.JPFBenchmark.benchmark54(82.52467605595209,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3594() {
    coral.tests.JPFBenchmark.benchmark54(82.52967308808309,-0.08499433742857843,0 ) ;
  }

  @Test
  public void test3595() {
    coral.tests.JPFBenchmark.benchmark54(82.5395491848018,-1.017568615792806,0 ) ;
  }

  @Test
  public void test3596() {
    coral.tests.JPFBenchmark.benchmark54(8.254213398580157,-9.003122630447462E-6,0 ) ;
  }

  @Test
  public void test3597() {
    coral.tests.JPFBenchmark.benchmark54(82.57126762232679,-0.22677728531432662,0 ) ;
  }

  @Test
  public void test3598() {
    coral.tests.JPFBenchmark.benchmark54(82.58172707920875,-1.080296790442901,0 ) ;
  }

  @Test
  public void test3599() {
    coral.tests.JPFBenchmark.benchmark54(82.69627009486749,-0.1837957785328399,0 ) ;
  }

  @Test
  public void test3600() {
    coral.tests.JPFBenchmark.benchmark54(82.77059668242251,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3601() {
    coral.tests.JPFBenchmark.benchmark54(82.82921268632896,-0.3232332236813207,0 ) ;
  }

  @Test
  public void test3602() {
    coral.tests.JPFBenchmark.benchmark54(82.86112317394253,-0.10193301661270482,0 ) ;
  }

  @Test
  public void test3603() {
    coral.tests.JPFBenchmark.benchmark54(82.86326892168049,-0.6912771737314343,0 ) ;
  }

  @Test
  public void test3604() {
    coral.tests.JPFBenchmark.benchmark54(82.86903268831759,-1.2516870453117075,0 ) ;
  }

  @Test
  public void test3605() {
    coral.tests.JPFBenchmark.benchmark54(82.87993700906625,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3606() {
    coral.tests.JPFBenchmark.benchmark54(82.8916370565253,-1.465832836567472,0 ) ;
  }

  @Test
  public void test3607() {
    coral.tests.JPFBenchmark.benchmark54(82.95213146210351,-1.0165975362185864,0 ) ;
  }

  @Test
  public void test3608() {
    coral.tests.JPFBenchmark.benchmark54(82.95676111713477,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3609() {
    coral.tests.JPFBenchmark.benchmark54(82.98934799145559,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3610() {
    coral.tests.JPFBenchmark.benchmark54(83.00825904152536,-0.5618356551481156,0 ) ;
  }

  @Test
  public void test3611() {
    coral.tests.JPFBenchmark.benchmark54(83.00843057099894,-1.0443750100488856,0 ) ;
  }

  @Test
  public void test3612() {
    coral.tests.JPFBenchmark.benchmark54(83.0187038953411,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3613() {
    coral.tests.JPFBenchmark.benchmark54(83.02818170595594,-0.9406539279281647,0 ) ;
  }

  @Test
  public void test3614() {
    coral.tests.JPFBenchmark.benchmark54(83.04606295860609,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3615() {
    coral.tests.JPFBenchmark.benchmark54(83.08539870585284,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3616() {
    coral.tests.JPFBenchmark.benchmark54(8.309759871225125,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3617() {
    coral.tests.JPFBenchmark.benchmark54(83.10730837735503,-0.20568833951463983,0 ) ;
  }

  @Test
  public void test3618() {
    coral.tests.JPFBenchmark.benchmark54(83.12426623474886,-1.2874150807066442,0 ) ;
  }

  @Test
  public void test3619() {
    coral.tests.JPFBenchmark.benchmark54(83.13055364416249,-0.8940689339688284,0 ) ;
  }

  @Test
  public void test3620() {
    coral.tests.JPFBenchmark.benchmark54(83.14085742649823,-1.156606446805668,0 ) ;
  }

  @Test
  public void test3621() {
    coral.tests.JPFBenchmark.benchmark54(83.15958819394766,-1.1560823886324627,0 ) ;
  }

  @Test
  public void test3622() {
    coral.tests.JPFBenchmark.benchmark54(83.19055173204595,-0.6270256872350473,0 ) ;
  }

  @Test
  public void test3623() {
    coral.tests.JPFBenchmark.benchmark54(83.20938837351389,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3624() {
    coral.tests.JPFBenchmark.benchmark54(83.21027345195199,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3625() {
    coral.tests.JPFBenchmark.benchmark54(83.2422297022712,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3626() {
    coral.tests.JPFBenchmark.benchmark54(83.28226398007394,-1.0123822253205506,0 ) ;
  }

  @Test
  public void test3627() {
    coral.tests.JPFBenchmark.benchmark54(83.31587574836078,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3628() {
    coral.tests.JPFBenchmark.benchmark54(83.32266513084883,-1.1520076672433088,0 ) ;
  }

  @Test
  public void test3629() {
    coral.tests.JPFBenchmark.benchmark54(83.35278528063856,-0.41748567192873587,0 ) ;
  }

  @Test
  public void test3630() {
    coral.tests.JPFBenchmark.benchmark54(83.45280094989494,-0.5095037018712949,0 ) ;
  }

  @Test
  public void test3631() {
    coral.tests.JPFBenchmark.benchmark54(83.46513970885738,-0.02802900994038805,0 ) ;
  }

  @Test
  public void test3632() {
    coral.tests.JPFBenchmark.benchmark54(83.47351908573896,-1.1880740022502776,0 ) ;
  }

  @Test
  public void test3633() {
    coral.tests.JPFBenchmark.benchmark54(83.49366422285466,-1.0488505510075807,0 ) ;
  }

  @Test
  public void test3634() {
    coral.tests.JPFBenchmark.benchmark54(8.349927995633369,-0.3605089218563169,0 ) ;
  }

  @Test
  public void test3635() {
    coral.tests.JPFBenchmark.benchmark54(83.63104605066394,-0.9328128680874244,0 ) ;
  }

  @Test
  public void test3636() {
    coral.tests.JPFBenchmark.benchmark54(-83.63706171718748,-0.6777464646237377,-88.69464183369413 ) ;
  }

  @Test
  public void test3637() {
    coral.tests.JPFBenchmark.benchmark54(83.65002987472661,-0.3910369039080538,0 ) ;
  }

  @Test
  public void test3638() {
    coral.tests.JPFBenchmark.benchmark54(83.67675183449461,-1.4183623733320196,0 ) ;
  }

  @Test
  public void test3639() {
    coral.tests.JPFBenchmark.benchmark54(83.69941805389263,-1.168850159074359,0 ) ;
  }

  @Test
  public void test3640() {
    coral.tests.JPFBenchmark.benchmark54(83.74470915017298,-1.6724326182050815E-8,0 ) ;
  }

  @Test
  public void test3641() {
    coral.tests.JPFBenchmark.benchmark54(-83.76815002407204,-1.7763568394002505E-15,-0.9999999999999964 ) ;
  }

  @Test
  public void test3642() {
    coral.tests.JPFBenchmark.benchmark54(83.89192031681876,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test3643() {
    coral.tests.JPFBenchmark.benchmark54(83.95379249462945,-0.6693126888227292,0 ) ;
  }

  @Test
  public void test3644() {
    coral.tests.JPFBenchmark.benchmark54(8.39650081875854,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3645() {
    coral.tests.JPFBenchmark.benchmark54(83.96762427430757,-1.4169329138932003E-9,0 ) ;
  }

  @Test
  public void test3646() {
    coral.tests.JPFBenchmark.benchmark54(83.98068270744957,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3647() {
    coral.tests.JPFBenchmark.benchmark54(83.98688233929178,-0.7123721465437995,0 ) ;
  }

  @Test
  public void test3648() {
    coral.tests.JPFBenchmark.benchmark54(84.04036411535662,-1.0544215650537723,0 ) ;
  }

  @Test
  public void test3649() {
    coral.tests.JPFBenchmark.benchmark54(84.04349840060762,-1.188718552794756,0 ) ;
  }

  @Test
  public void test3650() {
    coral.tests.JPFBenchmark.benchmark54(84.06930225276909,-1.499999999669505,0 ) ;
  }

  @Test
  public void test3651() {
    coral.tests.JPFBenchmark.benchmark54(84.08053150753523,-0.6922763787728741,0 ) ;
  }

  @Test
  public void test3652() {
    coral.tests.JPFBenchmark.benchmark54(84.12176210163526,-0.5929158170465403,0 ) ;
  }

  @Test
  public void test3653() {
    coral.tests.JPFBenchmark.benchmark54(84.18506784740484,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3654() {
    coral.tests.JPFBenchmark.benchmark54(84.23367407842522,-1.2740529075801703,0 ) ;
  }

  @Test
  public void test3655() {
    coral.tests.JPFBenchmark.benchmark54(84.2589889765527,-0.2090492169186433,0 ) ;
  }

  @Test
  public void test3656() {
    coral.tests.JPFBenchmark.benchmark54(84.29060614637274,-1.489402263697059,0 ) ;
  }

  @Test
  public void test3657() {
    coral.tests.JPFBenchmark.benchmark54(84.32764891056686,-1.190953151556321,0 ) ;
  }

  @Test
  public void test3658() {
    coral.tests.JPFBenchmark.benchmark54(84.33756828261107,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3659() {
    coral.tests.JPFBenchmark.benchmark54(84.35117449059065,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3660() {
    coral.tests.JPFBenchmark.benchmark54(84.35514464525967,-0.021508737990528548,0 ) ;
  }

  @Test
  public void test3661() {
    coral.tests.JPFBenchmark.benchmark54(84.3687811282822,-0.06829831763144156,0 ) ;
  }

  @Test
  public void test3662() {
    coral.tests.JPFBenchmark.benchmark54(84.37064735379921,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3663() {
    coral.tests.JPFBenchmark.benchmark54(8.438893344281738,-0.9039267935474271,0 ) ;
  }

  @Test
  public void test3664() {
    coral.tests.JPFBenchmark.benchmark54(84.42239786962364,-1.4646093779662124,0 ) ;
  }

  @Test
  public void test3665() {
    coral.tests.JPFBenchmark.benchmark54(84.50826073404173,-0.9592932853574041,0 ) ;
  }

  @Test
  public void test3666() {
    coral.tests.JPFBenchmark.benchmark54(84.56919392153384,-0.6321033444188299,0 ) ;
  }

  @Test
  public void test3667() {
    coral.tests.JPFBenchmark.benchmark54(84.59015125456801,-1.1317582799177153,0 ) ;
  }

  @Test
  public void test3668() {
    coral.tests.JPFBenchmark.benchmark54(84.59596921200966,-1.083259812568173,0 ) ;
  }

  @Test
  public void test3669() {
    coral.tests.JPFBenchmark.benchmark54(-84.62657154789923,-0.4277691718275207,0.8756004371359464 ) ;
  }

  @Test
  public void test3670() {
    coral.tests.JPFBenchmark.benchmark54(84.65607800156423,-0.7933185464352732,0 ) ;
  }

  @Test
  public void test3671() {
    coral.tests.JPFBenchmark.benchmark54(84.66557040173839,-0.4604358424548991,0 ) ;
  }

  @Test
  public void test3672() {
    coral.tests.JPFBenchmark.benchmark54(84.68341857502006,-1.362505763979104,0 ) ;
  }

  @Test
  public void test3673() {
    coral.tests.JPFBenchmark.benchmark54(84.75211773839905,-0.27014875771070423,0 ) ;
  }

  @Test
  public void test3674() {
    coral.tests.JPFBenchmark.benchmark54(84.80452496249137,-1.369193635969907,0 ) ;
  }

  @Test
  public void test3675() {
    coral.tests.JPFBenchmark.benchmark54(84.81197446853798,-1.210233378164723,0 ) ;
  }

  @Test
  public void test3676() {
    coral.tests.JPFBenchmark.benchmark54(84.84425014641786,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3677() {
    coral.tests.JPFBenchmark.benchmark54(84.86900855992158,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3678() {
    coral.tests.JPFBenchmark.benchmark54(84.87566602091462,-0.014747243863374976,0 ) ;
  }

  @Test
  public void test3679() {
    coral.tests.JPFBenchmark.benchmark54(85.05571128661865,-0.9384780982920198,0 ) ;
  }

  @Test
  public void test3680() {
    coral.tests.JPFBenchmark.benchmark54(85.05750347173023,-0.4499486700369175,0 ) ;
  }

  @Test
  public void test3681() {
    coral.tests.JPFBenchmark.benchmark54(85.0592762780418,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3682() {
    coral.tests.JPFBenchmark.benchmark54(85.08649517239365,-0.013982832996027095,0 ) ;
  }

  @Test
  public void test3683() {
    coral.tests.JPFBenchmark.benchmark54(85.09137390085601,-1.2108495645000392,0 ) ;
  }

  @Test
  public void test3684() {
    coral.tests.JPFBenchmark.benchmark54(85.11717755132867,-0.5582910014442841,0 ) ;
  }

  @Test
  public void test3685() {
    coral.tests.JPFBenchmark.benchmark54(85.13885718428548,-0.9522435555129002,0 ) ;
  }

  @Test
  public void test3686() {
    coral.tests.JPFBenchmark.benchmark54(85.16193432524412,-1.2400283596267674,0 ) ;
  }

  @Test
  public void test3687() {
    coral.tests.JPFBenchmark.benchmark54(85.17617376205894,-1.4738777371499583,0 ) ;
  }

  @Test
  public void test3688() {
    coral.tests.JPFBenchmark.benchmark54(85.18090690377952,-1.041344978105822E-8,0 ) ;
  }

  @Test
  public void test3689() {
    coral.tests.JPFBenchmark.benchmark54(85.19199522150504,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3690() {
    coral.tests.JPFBenchmark.benchmark54(85.24260560465359,-1.0496897867585928,0 ) ;
  }

  @Test
  public void test3691() {
    coral.tests.JPFBenchmark.benchmark54(85.30670363344072,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3692() {
    coral.tests.JPFBenchmark.benchmark54(85.31333328884531,-0.6714033015159169,0 ) ;
  }

  @Test
  public void test3693() {
    coral.tests.JPFBenchmark.benchmark54(8.535615402870691,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3694() {
    coral.tests.JPFBenchmark.benchmark54(85.37685942516877,-1.499999999999993,0 ) ;
  }

  @Test
  public void test3695() {
    coral.tests.JPFBenchmark.benchmark54(85.40980755545863,-0.7172771640471751,0 ) ;
  }

  @Test
  public void test3696() {
    coral.tests.JPFBenchmark.benchmark54(85.44640945782453,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3697() {
    coral.tests.JPFBenchmark.benchmark54(85.49763532789117,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3698() {
    coral.tests.JPFBenchmark.benchmark54(85.53178163948562,-1.1080688505325895,0 ) ;
  }

  @Test
  public void test3699() {
    coral.tests.JPFBenchmark.benchmark54(85.5688988318878,-0.41095798862081523,0 ) ;
  }

  @Test
  public void test3700() {
    coral.tests.JPFBenchmark.benchmark54(85.62498165829965,-1.0926363358940492,0 ) ;
  }

  @Test
  public void test3701() {
    coral.tests.JPFBenchmark.benchmark54(8.563114663722892,-0.34881697692016544,0 ) ;
  }

  @Test
  public void test3702() {
    coral.tests.JPFBenchmark.benchmark54(8.564592991958655,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3703() {
    coral.tests.JPFBenchmark.benchmark54(85.67873857058045,-0.48847617422880435,0 ) ;
  }

  @Test
  public void test3704() {
    coral.tests.JPFBenchmark.benchmark54(85.72135326865873,-0.9123488116138243,0 ) ;
  }

  @Test
  public void test3705() {
    coral.tests.JPFBenchmark.benchmark54(85.72843803166796,-0.7937306736219654,0 ) ;
  }

  @Test
  public void test3706() {
    coral.tests.JPFBenchmark.benchmark54(85.74309297131651,-0.4857533744014084,0 ) ;
  }

  @Test
  public void test3707() {
    coral.tests.JPFBenchmark.benchmark54(85.77470605085753,-0.5796978564417872,0 ) ;
  }

  @Test
  public void test3708() {
    coral.tests.JPFBenchmark.benchmark54(85.80876129656602,-0.07783061836278193,0 ) ;
  }

  @Test
  public void test3709() {
    coral.tests.JPFBenchmark.benchmark54(85.83795573924834,-0.3076879009489861,0 ) ;
  }

  @Test
  public void test3710() {
    coral.tests.JPFBenchmark.benchmark54(85.88994199018583,-0.4310039272448716,0 ) ;
  }

  @Test
  public void test3711() {
    coral.tests.JPFBenchmark.benchmark54(85.92067563848431,-0.04665806622415669,0 ) ;
  }

  @Test
  public void test3712() {
    coral.tests.JPFBenchmark.benchmark54(85.95835778065425,-1.381973567788569E-7,0 ) ;
  }

  @Test
  public void test3713() {
    coral.tests.JPFBenchmark.benchmark54(85.96271450718359,-1.3632948227727724,0 ) ;
  }

  @Test
  public void test3714() {
    coral.tests.JPFBenchmark.benchmark54(-85.98336900841197,-1.2190053310872024,1.0 ) ;
  }

  @Test
  public void test3715() {
    coral.tests.JPFBenchmark.benchmark54(8.598646172182228,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3716() {
    coral.tests.JPFBenchmark.benchmark54(86.00399219740976,48.86060857345234,-69.3269856392156 ) ;
  }

  @Test
  public void test3717() {
    coral.tests.JPFBenchmark.benchmark54(8.60451926124486,-0.24029399622599404,0 ) ;
  }

  @Test
  public void test3718() {
    coral.tests.JPFBenchmark.benchmark54(86.07779703725822,-0.04580579183746103,0 ) ;
  }

  @Test
  public void test3719() {
    coral.tests.JPFBenchmark.benchmark54(86.09543715473251,-0.7579373852810196,0 ) ;
  }

  @Test
  public void test3720() {
    coral.tests.JPFBenchmark.benchmark54(86.1102896088588,-0.4959824496999929,0 ) ;
  }

  @Test
  public void test3721() {
    coral.tests.JPFBenchmark.benchmark54(86.11232200566008,-1.4596979224194002,0 ) ;
  }

  @Test
  public void test3722() {
    coral.tests.JPFBenchmark.benchmark54(8.61311039609518,-0.7869372522220957,0 ) ;
  }

  @Test
  public void test3723() {
    coral.tests.JPFBenchmark.benchmark54(86.14053965772123,-0.5416971357074232,0 ) ;
  }

  @Test
  public void test3724() {
    coral.tests.JPFBenchmark.benchmark54(86.16092147284819,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3725() {
    coral.tests.JPFBenchmark.benchmark54(86.20658774598758,-0.023668115488496,0 ) ;
  }

  @Test
  public void test3726() {
    coral.tests.JPFBenchmark.benchmark54(86.21345142938605,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3727() {
    coral.tests.JPFBenchmark.benchmark54(86.28646684607693,-0.23295195902539867,0 ) ;
  }

  @Test
  public void test3728() {
    coral.tests.JPFBenchmark.benchmark54(86.39331675718824,-0.7998283568664988,0 ) ;
  }

  @Test
  public void test3729() {
    coral.tests.JPFBenchmark.benchmark54(86.40871207999936,-0.7031011594254295,0 ) ;
  }

  @Test
  public void test3730() {
    coral.tests.JPFBenchmark.benchmark54(86.43219792720853,-0.28247287031422275,0 ) ;
  }

  @Test
  public void test3731() {
    coral.tests.JPFBenchmark.benchmark54(86.45270732937959,-0.5306243055434798,0 ) ;
  }

  @Test
  public void test3732() {
    coral.tests.JPFBenchmark.benchmark54(86.51411461735754,-0.8967325907657511,0 ) ;
  }

  @Test
  public void test3733() {
    coral.tests.JPFBenchmark.benchmark54(86.54169714306232,-0.3739990721447405,0 ) ;
  }

  @Test
  public void test3734() {
    coral.tests.JPFBenchmark.benchmark54(86.57020069335101,-1.4999999999999987,0 ) ;
  }

  @Test
  public void test3735() {
    coral.tests.JPFBenchmark.benchmark54(-86.57723845828292,-1.3664421501048098,-2412.191097025838 ) ;
  }

  @Test
  public void test3736() {
    coral.tests.JPFBenchmark.benchmark54(86.58005210038405,-1.1889314213744484,0 ) ;
  }

  @Test
  public void test3737() {
    coral.tests.JPFBenchmark.benchmark54(86.60326566369997,-0.20755423303451437,0 ) ;
  }

  @Test
  public void test3738() {
    coral.tests.JPFBenchmark.benchmark54(86.69367653319432,-0.4098165805732292,0 ) ;
  }

  @Test
  public void test3739() {
    coral.tests.JPFBenchmark.benchmark54(86.70765684710344,-1.0213028580915129E-9,0 ) ;
  }

  @Test
  public void test3740() {
    coral.tests.JPFBenchmark.benchmark54(86.73049948547066,-0.054593985309821846,0 ) ;
  }

  @Test
  public void test3741() {
    coral.tests.JPFBenchmark.benchmark54(86.73055022868465,-0.8604247913300722,0 ) ;
  }

  @Test
  public void test3742() {
    coral.tests.JPFBenchmark.benchmark54(86.81386636100598,-0.6353889663972683,0 ) ;
  }

  @Test
  public void test3743() {
    coral.tests.JPFBenchmark.benchmark54(8.681818818210488,-0.8482282307407587,0 ) ;
  }

  @Test
  public void test3744() {
    coral.tests.JPFBenchmark.benchmark54(86.90982266772528,-0.7405577015877469,0 ) ;
  }

  @Test
  public void test3745() {
    coral.tests.JPFBenchmark.benchmark54(86.94388998937893,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3746() {
    coral.tests.JPFBenchmark.benchmark54(86.9443666927466,-0.27558791376645786,0 ) ;
  }

  @Test
  public void test3747() {
    coral.tests.JPFBenchmark.benchmark54(86.99014474212953,-1.2799763755889444,0 ) ;
  }

  @Test
  public void test3748() {
    coral.tests.JPFBenchmark.benchmark54(87.0051415248824,-0.0243518886783769,0 ) ;
  }

  @Test
  public void test3749() {
    coral.tests.JPFBenchmark.benchmark54(87.00720645569669,-1.4959419112557732,0 ) ;
  }

  @Test
  public void test3750() {
    coral.tests.JPFBenchmark.benchmark54(87.03015083856982,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3751() {
    coral.tests.JPFBenchmark.benchmark54(87.08487506406192,-0.26878678816829854,0 ) ;
  }

  @Test
  public void test3752() {
    coral.tests.JPFBenchmark.benchmark54(87.09779594867123,-1.3636265526088849,0 ) ;
  }

  @Test
  public void test3753() {
    coral.tests.JPFBenchmark.benchmark54(87.13308852809794,-1.088615584909519,0 ) ;
  }

  @Test
  public void test3754() {
    coral.tests.JPFBenchmark.benchmark54(87.13849367871921,-0.727522467061938,0 ) ;
  }

  @Test
  public void test3755() {
    coral.tests.JPFBenchmark.benchmark54(87.16320785229684,-1.0107302556152855E-7,0 ) ;
  }

  @Test
  public void test3756() {
    coral.tests.JPFBenchmark.benchmark54(87.20075501340264,-0.6614872142733705,0 ) ;
  }

  @Test
  public void test3757() {
    coral.tests.JPFBenchmark.benchmark54(87.24928943507396,-1.4554691229691912,0 ) ;
  }

  @Test
  public void test3758() {
    coral.tests.JPFBenchmark.benchmark54(87.2615918408656,-1.0887463395051715,0 ) ;
  }

  @Test
  public void test3759() {
    coral.tests.JPFBenchmark.benchmark54(87.30468729671816,-1.0695431608926267,0 ) ;
  }

  @Test
  public void test3760() {
    coral.tests.JPFBenchmark.benchmark54(87.30854925311814,-1.4999999915167965,0 ) ;
  }

  @Test
  public void test3761() {
    coral.tests.JPFBenchmark.benchmark54(87.31527043491182,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3762() {
    coral.tests.JPFBenchmark.benchmark54(87.39180558613883,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3763() {
    coral.tests.JPFBenchmark.benchmark54(87.42097220919702,-4.5256892066701644E-10,0 ) ;
  }

  @Test
  public void test3764() {
    coral.tests.JPFBenchmark.benchmark54(8.742931143375259,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3765() {
    coral.tests.JPFBenchmark.benchmark54(87.43384243401493,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3766() {
    coral.tests.JPFBenchmark.benchmark54(87.46348694417077,-1.036981445178089,0 ) ;
  }

  @Test
  public void test3767() {
    coral.tests.JPFBenchmark.benchmark54(87.46535846538649,-1.4681447700341765,0 ) ;
  }

  @Test
  public void test3768() {
    coral.tests.JPFBenchmark.benchmark54(87.471722335962,-0.22510614027930842,0 ) ;
  }

  @Test
  public void test3769() {
    coral.tests.JPFBenchmark.benchmark54(87.5260155865234,-0.0017606563681359982,0 ) ;
  }

  @Test
  public void test3770() {
    coral.tests.JPFBenchmark.benchmark54(87.55422754945744,-1.4622304350436401,0 ) ;
  }

  @Test
  public void test3771() {
    coral.tests.JPFBenchmark.benchmark54(87.58494393086937,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3772() {
    coral.tests.JPFBenchmark.benchmark54(87.58796306824199,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3773() {
    coral.tests.JPFBenchmark.benchmark54(-87.6217602704249,-0.7182870831907673,-0.9773543540647066 ) ;
  }

  @Test
  public void test3774() {
    coral.tests.JPFBenchmark.benchmark54(87.64840514321216,-0.26576889111423857,0 ) ;
  }

  @Test
  public void test3775() {
    coral.tests.JPFBenchmark.benchmark54(87.70455473824896,-0.8049974215125815,0 ) ;
  }

  @Test
  public void test3776() {
    coral.tests.JPFBenchmark.benchmark54(87.70998770547942,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3777() {
    coral.tests.JPFBenchmark.benchmark54(87.74518062091602,-1.5249193415089435E-4,0 ) ;
  }

  @Test
  public void test3778() {
    coral.tests.JPFBenchmark.benchmark54(87.7591901566557,-0.05074671841184397,0 ) ;
  }

  @Test
  public void test3779() {
    coral.tests.JPFBenchmark.benchmark54(87.816334855652,-1.4906056855085303,0 ) ;
  }

  @Test
  public void test3780() {
    coral.tests.JPFBenchmark.benchmark54(87.84475090440347,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3781() {
    coral.tests.JPFBenchmark.benchmark54(87.9005273630853,-0.5223362063359218,0 ) ;
  }

  @Test
  public void test3782() {
    coral.tests.JPFBenchmark.benchmark54(87.92083535587727,-0.9612771596539003,0 ) ;
  }

  @Test
  public void test3783() {
    coral.tests.JPFBenchmark.benchmark54(87.98479262631221,-0.33699713069286474,0 ) ;
  }

  @Test
  public void test3784() {
    coral.tests.JPFBenchmark.benchmark54(88.04520050124856,-0.945054161599534,0 ) ;
  }

  @Test
  public void test3785() {
    coral.tests.JPFBenchmark.benchmark54(88.0527339255032,-5.9022748375868525E-9,0 ) ;
  }

  @Test
  public void test3786() {
    coral.tests.JPFBenchmark.benchmark54(88.05509731106852,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3787() {
    coral.tests.JPFBenchmark.benchmark54(88.11364709565007,-1.377769925088085,0 ) ;
  }

  @Test
  public void test3788() {
    coral.tests.JPFBenchmark.benchmark54(88.11576521325176,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3789() {
    coral.tests.JPFBenchmark.benchmark54(88.13058603172209,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3790() {
    coral.tests.JPFBenchmark.benchmark54(88.16403917922818,-1.329932470678027,0 ) ;
  }

  @Test
  public void test3791() {
    coral.tests.JPFBenchmark.benchmark54(88.17361159550873,-0.5870315180674197,0 ) ;
  }

  @Test
  public void test3792() {
    coral.tests.JPFBenchmark.benchmark54(88.17892347508288,-1.1716698793580846,0 ) ;
  }

  @Test
  public void test3793() {
    coral.tests.JPFBenchmark.benchmark54(88.24399409069937,-0.09041521207907177,0 ) ;
  }

  @Test
  public void test3794() {
    coral.tests.JPFBenchmark.benchmark54(88.25082089916455,-1.4999999999999978,0 ) ;
  }

  @Test
  public void test3795() {
    coral.tests.JPFBenchmark.benchmark54(88.28089218205018,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3796() {
    coral.tests.JPFBenchmark.benchmark54(8.82933358785477,-0.010551686646468883,0 ) ;
  }

  @Test
  public void test3797() {
    coral.tests.JPFBenchmark.benchmark54(88.31976339199744,-0.47931511628387297,0 ) ;
  }

  @Test
  public void test3798() {
    coral.tests.JPFBenchmark.benchmark54(88.33857733687665,-0.05765652283760528,0 ) ;
  }

  @Test
  public void test3799() {
    coral.tests.JPFBenchmark.benchmark54(88.3630293096866,-0.347231486561137,0 ) ;
  }

  @Test
  public void test3800() {
    coral.tests.JPFBenchmark.benchmark54(88.40190074707229,-0.3181335002705198,0 ) ;
  }

  @Test
  public void test3801() {
    coral.tests.JPFBenchmark.benchmark54(88.48486118209907,-5.886001754604428E-7,0 ) ;
  }

  @Test
  public void test3802() {
    coral.tests.JPFBenchmark.benchmark54(88.49501591388122,-0.0016279671152084063,0 ) ;
  }

  @Test
  public void test3803() {
    coral.tests.JPFBenchmark.benchmark54(8.8502768424067,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3804() {
    coral.tests.JPFBenchmark.benchmark54(88.58743023000127,-1.0100925639777074,0 ) ;
  }

  @Test
  public void test3805() {
    coral.tests.JPFBenchmark.benchmark54(88.62330542358615,-0.2660935454729816,0 ) ;
  }

  @Test
  public void test3806() {
    coral.tests.JPFBenchmark.benchmark54(8.863743823611344,-1.2679592275680989,0 ) ;
  }

  @Test
  public void test3807() {
    coral.tests.JPFBenchmark.benchmark54(8.866847147819716,-0.9556304342671398,0 ) ;
  }

  @Test
  public void test3808() {
    coral.tests.JPFBenchmark.benchmark54(8.86842461948143,-0.4918541786750126,0 ) ;
  }

  @Test
  public void test3809() {
    coral.tests.JPFBenchmark.benchmark54(-88.7368923279829,-0.036589669264738826,1.0 ) ;
  }

  @Test
  public void test3810() {
    coral.tests.JPFBenchmark.benchmark54(88.74075390189148,-0.8094329835775653,0 ) ;
  }

  @Test
  public void test3811() {
    coral.tests.JPFBenchmark.benchmark54(88.76807982717477,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3812() {
    coral.tests.JPFBenchmark.benchmark54(8.878778878516869,-1.402994456538437,0 ) ;
  }

  @Test
  public void test3813() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.10805284114079397,0 ) ;
  }

  @Test
  public void test3814() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.20072607819801913,0 ) ;
  }

  @Test
  public void test3815() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-0.944067257718813,0 ) ;
  }

  @Test
  public void test3816() {
    coral.tests.JPFBenchmark.benchmark54(8.881784197001252E-16,-5.859384087464777E-17,0 ) ;
  }

  @Test
  public void test3817() {
    coral.tests.JPFBenchmark.benchmark54(88.83517936730925,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3818() {
    coral.tests.JPFBenchmark.benchmark54(88.83930316614041,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3819() {
    coral.tests.JPFBenchmark.benchmark54(88.85510169094002,-1.4633357175417079,0 ) ;
  }

  @Test
  public void test3820() {
    coral.tests.JPFBenchmark.benchmark54(8.886107834166383,-6.91986690539794E-10,0 ) ;
  }

  @Test
  public void test3821() {
    coral.tests.JPFBenchmark.benchmark54(-88.88740019363095,-0.6966905604203406,-1.0 ) ;
  }

  @Test
  public void test3822() {
    coral.tests.JPFBenchmark.benchmark54(88.9030173706198,-1.3418133189788937,0 ) ;
  }

  @Test
  public void test3823() {
    coral.tests.JPFBenchmark.benchmark54(89.03462503155299,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3824() {
    coral.tests.JPFBenchmark.benchmark54(89.05785144463047,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3825() {
    coral.tests.JPFBenchmark.benchmark54(89.06257662679639,-0.7988834513568142,0 ) ;
  }

  @Test
  public void test3826() {
    coral.tests.JPFBenchmark.benchmark54(89.09128682879208,-0.350231462693134,0 ) ;
  }

  @Test
  public void test3827() {
    coral.tests.JPFBenchmark.benchmark54(8.911845921657076,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3828() {
    coral.tests.JPFBenchmark.benchmark54(89.17686446916133,-0.16990254290021056,0 ) ;
  }

  @Test
  public void test3829() {
    coral.tests.JPFBenchmark.benchmark54(89.19121013379427,-7.115765463865706E-9,0 ) ;
  }

  @Test
  public void test3830() {
    coral.tests.JPFBenchmark.benchmark54(89.19860867172616,-0.3597138878480166,0 ) ;
  }

  @Test
  public void test3831() {
    coral.tests.JPFBenchmark.benchmark54(89.28114241296626,-0.3276891270951898,0 ) ;
  }

  @Test
  public void test3832() {
    coral.tests.JPFBenchmark.benchmark54(89.32870335564047,-1.3624143870955976,0 ) ;
  }

  @Test
  public void test3833() {
    coral.tests.JPFBenchmark.benchmark54(89.334376472771,-0.5279910809752764,0 ) ;
  }

  @Test
  public void test3834() {
    coral.tests.JPFBenchmark.benchmark54(89.3849820989039,-0.09326257721870501,0 ) ;
  }

  @Test
  public void test3835() {
    coral.tests.JPFBenchmark.benchmark54(8.938542734522542,-1.1640908568796737,0 ) ;
  }

  @Test
  public void test3836() {
    coral.tests.JPFBenchmark.benchmark54(89.45460792882035,-0.4161425879201821,0 ) ;
  }

  @Test
  public void test3837() {
    coral.tests.JPFBenchmark.benchmark54(89.51297519768463,-0.15115398508091227,0 ) ;
  }

  @Test
  public void test3838() {
    coral.tests.JPFBenchmark.benchmark54(89.51399959006825,-0.341076548110636,0 ) ;
  }

  @Test
  public void test3839() {
    coral.tests.JPFBenchmark.benchmark54(8.952275482627712,-0.6359687835611405,0 ) ;
  }

  @Test
  public void test3840() {
    coral.tests.JPFBenchmark.benchmark54(8.952996789331591,-0.07963576155667745,0 ) ;
  }

  @Test
  public void test3841() {
    coral.tests.JPFBenchmark.benchmark54(89.61060993967217,-0.36643596309841864,0 ) ;
  }

  @Test
  public void test3842() {
    coral.tests.JPFBenchmark.benchmark54(89.62240940564757,-0.27574324062886113,0 ) ;
  }

  @Test
  public void test3843() {
    coral.tests.JPFBenchmark.benchmark54(89.64561074932888,-0.6643386192111187,0 ) ;
  }

  @Test
  public void test3844() {
    coral.tests.JPFBenchmark.benchmark54(89.65997066708059,-0.218993486691204,0 ) ;
  }

  @Test
  public void test3845() {
    coral.tests.JPFBenchmark.benchmark54(89.66917694477229,-1.1050597540648965,0 ) ;
  }

  @Test
  public void test3846() {
    coral.tests.JPFBenchmark.benchmark54(89.67753249742293,-1.4395140806916302,0 ) ;
  }

  @Test
  public void test3847() {
    coral.tests.JPFBenchmark.benchmark54(89.7214095909302,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test3848() {
    coral.tests.JPFBenchmark.benchmark54(89.77455845991702,-0.6430948231035813,0 ) ;
  }

  @Test
  public void test3849() {
    coral.tests.JPFBenchmark.benchmark54(89.78251589241782,-0.09383027551795209,0 ) ;
  }

  @Test
  public void test3850() {
    coral.tests.JPFBenchmark.benchmark54(89.80176947887631,-0.5964505999705949,0 ) ;
  }

  @Test
  public void test3851() {
    coral.tests.JPFBenchmark.benchmark54(89.80767558595726,-0.7314705121120207,0 ) ;
  }

  @Test
  public void test3852() {
    coral.tests.JPFBenchmark.benchmark54(89.81736786284554,-1.267012589665815,0 ) ;
  }

  @Test
  public void test3853() {
    coral.tests.JPFBenchmark.benchmark54(89.81744338070462,-0.5218827033389566,0 ) ;
  }

  @Test
  public void test3854() {
    coral.tests.JPFBenchmark.benchmark54(89.82771659384626,-1.1572911753383783E-9,0 ) ;
  }

  @Test
  public void test3855() {
    coral.tests.JPFBenchmark.benchmark54(89.93670066931284,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3856() {
    coral.tests.JPFBenchmark.benchmark54(8.995711678753324,-1.2107821526500302,0 ) ;
  }

  @Test
  public void test3857() {
    coral.tests.JPFBenchmark.benchmark54(89.9943584928946,-0.5829099997267768,0 ) ;
  }

  @Test
  public void test3858() {
    coral.tests.JPFBenchmark.benchmark54(8.999928412132821,-1.1733141888252048,0 ) ;
  }

  @Test
  public void test3859() {
    coral.tests.JPFBenchmark.benchmark54(90.00216549086062,-1.3760098611705343,0 ) ;
  }

  @Test
  public void test3860() {
    coral.tests.JPFBenchmark.benchmark54(90.0786184997906,-0.4832009189054105,0 ) ;
  }

  @Test
  public void test3861() {
    coral.tests.JPFBenchmark.benchmark54(90.10124590886036,-0.7451349698254912,0 ) ;
  }

  @Test
  public void test3862() {
    coral.tests.JPFBenchmark.benchmark54(90.112673113547,-1.0711104265624172,0 ) ;
  }

  @Test
  public void test3863() {
    coral.tests.JPFBenchmark.benchmark54(9.013922143839714,-1.772527278863798E-5,0 ) ;
  }

  @Test
  public void test3864() {
    coral.tests.JPFBenchmark.benchmark54(90.15585497923414,-0.9651822778105111,0 ) ;
  }

  @Test
  public void test3865() {
    coral.tests.JPFBenchmark.benchmark54(90.17793440732001,-1.3586541842560962,0 ) ;
  }

  @Test
  public void test3866() {
    coral.tests.JPFBenchmark.benchmark54(90.18434866084769,-0.45837406512416123,0 ) ;
  }

  @Test
  public void test3867() {
    coral.tests.JPFBenchmark.benchmark54(90.21810408580714,-1.4999999999999973,0 ) ;
  }

  @Test
  public void test3868() {
    coral.tests.JPFBenchmark.benchmark54(90.22418420751222,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3869() {
    coral.tests.JPFBenchmark.benchmark54(90.22489241003842,-0.22931975237415259,0 ) ;
  }

  @Test
  public void test3870() {
    coral.tests.JPFBenchmark.benchmark54(90.26457699299763,-1.1848607243771847,0 ) ;
  }

  @Test
  public void test3871() {
    coral.tests.JPFBenchmark.benchmark54(90.27352948227588,-1.3484441656585484,0 ) ;
  }

  @Test
  public void test3872() {
    coral.tests.JPFBenchmark.benchmark54(90.2749896845558,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3873() {
    coral.tests.JPFBenchmark.benchmark54(90.29388133145127,-0.9186644384356265,0 ) ;
  }

  @Test
  public void test3874() {
    coral.tests.JPFBenchmark.benchmark54(90.32030654949648,-1.3951498170347518,0 ) ;
  }

  @Test
  public void test3875() {
    coral.tests.JPFBenchmark.benchmark54(-90.38482639142752,-1.3907181862594358E-8,-93.07644153158024 ) ;
  }

  @Test
  public void test3876() {
    coral.tests.JPFBenchmark.benchmark54(90.38621573311505,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3877() {
    coral.tests.JPFBenchmark.benchmark54(90.41362361330249,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test3878() {
    coral.tests.JPFBenchmark.benchmark54(9.048466889819224,-0.8989765464812081,0 ) ;
  }

  @Test
  public void test3879() {
    coral.tests.JPFBenchmark.benchmark54(90.52796553461931,-1.4632176960502488,0 ) ;
  }

  @Test
  public void test3880() {
    coral.tests.JPFBenchmark.benchmark54(90.52870463419748,-0.8022010746571469,0 ) ;
  }

  @Test
  public void test3881() {
    coral.tests.JPFBenchmark.benchmark54(90.574290266479,-0.0025040747043460466,0 ) ;
  }

  @Test
  public void test3882() {
    coral.tests.JPFBenchmark.benchmark54(90.59257879483079,-0.2758449678511459,0 ) ;
  }

  @Test
  public void test3883() {
    coral.tests.JPFBenchmark.benchmark54(90.61298197497757,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3884() {
    coral.tests.JPFBenchmark.benchmark54(90.61963932654459,-0.9640441436327194,0 ) ;
  }

  @Test
  public void test3885() {
    coral.tests.JPFBenchmark.benchmark54(90.65274229627576,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3886() {
    coral.tests.JPFBenchmark.benchmark54(90.67596242073225,-0.3406441957584738,0 ) ;
  }

  @Test
  public void test3887() {
    coral.tests.JPFBenchmark.benchmark54(90.7100581198287,-0.14828169438873107,0 ) ;
  }

  @Test
  public void test3888() {
    coral.tests.JPFBenchmark.benchmark54(90.7405271455215,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3889() {
    coral.tests.JPFBenchmark.benchmark54(90.74245414157932,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3890() {
    coral.tests.JPFBenchmark.benchmark54(90.76516548916172,-1.1189324308274848,0 ) ;
  }

  @Test
  public void test3891() {
    coral.tests.JPFBenchmark.benchmark54(-90.77297612467822,-1.350560721321345,5.551115123125783E-17 ) ;
  }

  @Test
  public void test3892() {
    coral.tests.JPFBenchmark.benchmark54(90.821469989391,-0.916693767575794,0 ) ;
  }

  @Test
  public void test3893() {
    coral.tests.JPFBenchmark.benchmark54(90.8694045449767,-1.4999999999999787,0 ) ;
  }

  @Test
  public void test3894() {
    coral.tests.JPFBenchmark.benchmark54(90.92061970562497,-1.35628016390777,0 ) ;
  }

  @Test
  public void test3895() {
    coral.tests.JPFBenchmark.benchmark54(90.94118263486399,-0.592971215983181,0 ) ;
  }

  @Test
  public void test3896() {
    coral.tests.JPFBenchmark.benchmark54(90.94345414885125,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3897() {
    coral.tests.JPFBenchmark.benchmark54(90.95330322213906,-0.5842095806757213,0 ) ;
  }

  @Test
  public void test3898() {
    coral.tests.JPFBenchmark.benchmark54(90.9750631633771,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3899() {
    coral.tests.JPFBenchmark.benchmark54(91.05473439331493,-1.4999999999999822,0 ) ;
  }

  @Test
  public void test3900() {
    coral.tests.JPFBenchmark.benchmark54(91.0946626955905,-4.096359043569169E-9,0 ) ;
  }

  @Test
  public void test3901() {
    coral.tests.JPFBenchmark.benchmark54(91.10086001913055,-0.2758704002891186,0 ) ;
  }

  @Test
  public void test3902() {
    coral.tests.JPFBenchmark.benchmark54(9.112268085045347,-0.9112883452943867,0 ) ;
  }

  @Test
  public void test3903() {
    coral.tests.JPFBenchmark.benchmark54(91.13301753763281,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3904() {
    coral.tests.JPFBenchmark.benchmark54(91.15929163362851,-0.1424540557025158,0 ) ;
  }

  @Test
  public void test3905() {
    coral.tests.JPFBenchmark.benchmark54(91.16673594904218,-1.4900993720369951E-8,0 ) ;
  }

  @Test
  public void test3906() {
    coral.tests.JPFBenchmark.benchmark54(9.119290658479628,-0.8386214473029894,0 ) ;
  }

  @Test
  public void test3907() {
    coral.tests.JPFBenchmark.benchmark54(91.21346062820314,-0.2568402813066393,0 ) ;
  }

  @Test
  public void test3908() {
    coral.tests.JPFBenchmark.benchmark54(91.21612194721327,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3909() {
    coral.tests.JPFBenchmark.benchmark54(91.21639097667031,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3910() {
    coral.tests.JPFBenchmark.benchmark54(-91.24113404005084,-1.0348278101431787,1.0 ) ;
  }

  @Test
  public void test3911() {
    coral.tests.JPFBenchmark.benchmark54(91.24344003479652,-0.28644328928497487,0 ) ;
  }

  @Test
  public void test3912() {
    coral.tests.JPFBenchmark.benchmark54(91.26728191033646,-1.4999999999999956,0 ) ;
  }

  @Test
  public void test3913() {
    coral.tests.JPFBenchmark.benchmark54(91.29652322486578,-0.14866722700392287,0 ) ;
  }

  @Test
  public void test3914() {
    coral.tests.JPFBenchmark.benchmark54(91.2995925555172,-0.27924064975992735,0 ) ;
  }

  @Test
  public void test3915() {
    coral.tests.JPFBenchmark.benchmark54(91.31913926839201,-0.028557781983708033,0 ) ;
  }

  @Test
  public void test3916() {
    coral.tests.JPFBenchmark.benchmark54(91.32849394564117,-0.06435022417163348,0 ) ;
  }

  @Test
  public void test3917() {
    coral.tests.JPFBenchmark.benchmark54(91.33021860803089,-0.2657589014351336,0 ) ;
  }

  @Test
  public void test3918() {
    coral.tests.JPFBenchmark.benchmark54(91.37479525727167,-1.3070851708498696,0 ) ;
  }

  @Test
  public void test3919() {
    coral.tests.JPFBenchmark.benchmark54(91.39674171894484,-0.9810117974297157,0 ) ;
  }

  @Test
  public void test3920() {
    coral.tests.JPFBenchmark.benchmark54(91.4043989818405,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3921() {
    coral.tests.JPFBenchmark.benchmark54(91.44166403544779,-1.2115401511471147,0 ) ;
  }

  @Test
  public void test3922() {
    coral.tests.JPFBenchmark.benchmark54(9.144815946908992,-1.1718065732288707,0 ) ;
  }

  @Test
  public void test3923() {
    coral.tests.JPFBenchmark.benchmark54(9.146271365534432,-0.7437358672755137,0 ) ;
  }

  @Test
  public void test3924() {
    coral.tests.JPFBenchmark.benchmark54(9.15308965443971,-1.4999999886076398,0 ) ;
  }

  @Test
  public void test3925() {
    coral.tests.JPFBenchmark.benchmark54(9.157257223550825,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3926() {
    coral.tests.JPFBenchmark.benchmark54(91.62436012841616,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test3927() {
    coral.tests.JPFBenchmark.benchmark54(91.62440099897375,-0.5920018384473522,0 ) ;
  }

  @Test
  public void test3928() {
    coral.tests.JPFBenchmark.benchmark54(91.64489867309348,-0.04591077005281108,0 ) ;
  }

  @Test
  public void test3929() {
    coral.tests.JPFBenchmark.benchmark54(91.68241159105258,-0.018746138901021087,0 ) ;
  }

  @Test
  public void test3930() {
    coral.tests.JPFBenchmark.benchmark54(91.69610546350017,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3931() {
    coral.tests.JPFBenchmark.benchmark54(91.7126725673719,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test3932() {
    coral.tests.JPFBenchmark.benchmark54(9.176806500813584,-0.3377852135116033,0 ) ;
  }

  @Test
  public void test3933() {
    coral.tests.JPFBenchmark.benchmark54(91.77037938008961,-1.3601542574527912,0 ) ;
  }

  @Test
  public void test3934() {
    coral.tests.JPFBenchmark.benchmark54(91.78967961838275,-0.12540041815625944,0 ) ;
  }

  @Test
  public void test3935() {
    coral.tests.JPFBenchmark.benchmark54(91.79196531440903,-1.4975388709217867,0 ) ;
  }

  @Test
  public void test3936() {
    coral.tests.JPFBenchmark.benchmark54(91.81665124959025,-0.08831110097334616,0 ) ;
  }

  @Test
  public void test3937() {
    coral.tests.JPFBenchmark.benchmark54(91.83769457468959,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3938() {
    coral.tests.JPFBenchmark.benchmark54(91.84233678300694,-1.4452954841050314,0 ) ;
  }

  @Test
  public void test3939() {
    coral.tests.JPFBenchmark.benchmark54(9.186299128548995,-1.4519862620456074,0 ) ;
  }

  @Test
  public void test3940() {
    coral.tests.JPFBenchmark.benchmark54(91.8669324768617,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test3941() {
    coral.tests.JPFBenchmark.benchmark54(91.89749995987628,-0.11293325858083847,0 ) ;
  }

  @Test
  public void test3942() {
    coral.tests.JPFBenchmark.benchmark54(91.90202328296337,-0.930548901737627,0 ) ;
  }

  @Test
  public void test3943() {
    coral.tests.JPFBenchmark.benchmark54(91.92395900729346,-1.040449596417357,0 ) ;
  }

  @Test
  public void test3944() {
    coral.tests.JPFBenchmark.benchmark54(91.95922866361624,-0.6733252253001645,0 ) ;
  }

  @Test
  public void test3945() {
    coral.tests.JPFBenchmark.benchmark54(91.9882735118493,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3946() {
    coral.tests.JPFBenchmark.benchmark54(92.01030557649912,-0.2248329452232869,0 ) ;
  }

  @Test
  public void test3947() {
    coral.tests.JPFBenchmark.benchmark54(92.0439301577675,-0.6902547748573156,0 ) ;
  }

  @Test
  public void test3948() {
    coral.tests.JPFBenchmark.benchmark54(9.205371433427032,-0.0956985345192991,0 ) ;
  }

  @Test
  public void test3949() {
    coral.tests.JPFBenchmark.benchmark54(92.06633089631822,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3950() {
    coral.tests.JPFBenchmark.benchmark54(92.10048032954035,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3951() {
    coral.tests.JPFBenchmark.benchmark54(92.14188960387426,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3952() {
    coral.tests.JPFBenchmark.benchmark54(92.24653161124644,-1.0041026036373637,0 ) ;
  }

  @Test
  public void test3953() {
    coral.tests.JPFBenchmark.benchmark54(92.2751343743092,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test3954() {
    coral.tests.JPFBenchmark.benchmark54(92.31978389322603,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test3955() {
    coral.tests.JPFBenchmark.benchmark54(92.38487231654503,-1.152180287662219,0 ) ;
  }

  @Test
  public void test3956() {
    coral.tests.JPFBenchmark.benchmark54(92.41140893941702,-0.7210912426539124,0 ) ;
  }

  @Test
  public void test3957() {
    coral.tests.JPFBenchmark.benchmark54(-92.60048213247802,-0.43154118933872665,-1.0 ) ;
  }

  @Test
  public void test3958() {
    coral.tests.JPFBenchmark.benchmark54(92.6545642776718,-0.44911531904458357,0 ) ;
  }

  @Test
  public void test3959() {
    coral.tests.JPFBenchmark.benchmark54(92.66053982058942,-1.4999999999183973,0 ) ;
  }

  @Test
  public void test3960() {
    coral.tests.JPFBenchmark.benchmark54(92.69457844498521,-1.1684119742648518,0 ) ;
  }

  @Test
  public void test3961() {
    coral.tests.JPFBenchmark.benchmark54(92.72151103431999,-0.40575776755640725,0 ) ;
  }

  @Test
  public void test3962() {
    coral.tests.JPFBenchmark.benchmark54(92.74642538578328,-0.9511557383779472,0 ) ;
  }

  @Test
  public void test3963() {
    coral.tests.JPFBenchmark.benchmark54(92.84963212010291,-0.2872755379905101,0 ) ;
  }

  @Test
  public void test3964() {
    coral.tests.JPFBenchmark.benchmark54(92.88437746982271,-1.3635752354547996,0 ) ;
  }

  @Test
  public void test3965() {
    coral.tests.JPFBenchmark.benchmark54(92.90760507760845,-1.1244698864514806,0 ) ;
  }

  @Test
  public void test3966() {
    coral.tests.JPFBenchmark.benchmark54(92.92248979264414,-1.4040022342473515,0 ) ;
  }

  @Test
  public void test3967() {
    coral.tests.JPFBenchmark.benchmark54(92.93558262453928,-0.3810944235594198,0 ) ;
  }

  @Test
  public void test3968() {
    coral.tests.JPFBenchmark.benchmark54(92.97235210629142,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test3969() {
    coral.tests.JPFBenchmark.benchmark54(9.301930948481768,-0.9575856956925577,0 ) ;
  }

  @Test
  public void test3970() {
    coral.tests.JPFBenchmark.benchmark54(93.02665416605329,-1.4918291319842019,0 ) ;
  }

  @Test
  public void test3971() {
    coral.tests.JPFBenchmark.benchmark54(93.03377810381187,-1.4999999999991154,0 ) ;
  }

  @Test
  public void test3972() {
    coral.tests.JPFBenchmark.benchmark54(93.09095220319722,-0.27502458363387206,0 ) ;
  }

  @Test
  public void test3973() {
    coral.tests.JPFBenchmark.benchmark54(93.10714987428065,-1.2630391754578478,0 ) ;
  }

  @Test
  public void test3974() {
    coral.tests.JPFBenchmark.benchmark54(93.13162458663695,-1.4489006005846878,0 ) ;
  }

  @Test
  public void test3975() {
    coral.tests.JPFBenchmark.benchmark54(93.17050219452103,-0.22195403852606577,0 ) ;
  }

  @Test
  public void test3976() {
    coral.tests.JPFBenchmark.benchmark54(93.19196996950262,-0.8959418873696166,0 ) ;
  }

  @Test
  public void test3977() {
    coral.tests.JPFBenchmark.benchmark54(93.21889385299701,-0.990832820359353,0 ) ;
  }

  @Test
  public void test3978() {
    coral.tests.JPFBenchmark.benchmark54(9.331496713753126,-0.839628999915842,0 ) ;
  }

  @Test
  public void test3979() {
    coral.tests.JPFBenchmark.benchmark54(93.40377869266925,-0.530950344680619,0 ) ;
  }

  @Test
  public void test3980() {
    coral.tests.JPFBenchmark.benchmark54(93.43563175277939,-0.1988455850464336,0 ) ;
  }

  @Test
  public void test3981() {
    coral.tests.JPFBenchmark.benchmark54(93.48446889112901,-1.3192711078409876,0 ) ;
  }

  @Test
  public void test3982() {
    coral.tests.JPFBenchmark.benchmark54(93.58414568635524,-0.7198808419463318,0 ) ;
  }

  @Test
  public void test3983() {
    coral.tests.JPFBenchmark.benchmark54(93.65882788197092,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3984() {
    coral.tests.JPFBenchmark.benchmark54(93.66615366800443,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test3985() {
    coral.tests.JPFBenchmark.benchmark54(93.66952667071429,-0.90030286272696,0 ) ;
  }

  @Test
  public void test3986() {
    coral.tests.JPFBenchmark.benchmark54(93.67667239518943,-0.8353926579321563,0 ) ;
  }

  @Test
  public void test3987() {
    coral.tests.JPFBenchmark.benchmark54(93.6993562822399,-0.2538374602036275,0 ) ;
  }

  @Test
  public void test3988() {
    coral.tests.JPFBenchmark.benchmark54(9.370497695642271,-0.16104573739997274,0 ) ;
  }

  @Test
  public void test3989() {
    coral.tests.JPFBenchmark.benchmark54(93.72809338441758,-0.3156706616000813,0 ) ;
  }

  @Test
  public void test3990() {
    coral.tests.JPFBenchmark.benchmark54(93.7435569860288,-1.158425486816601,0 ) ;
  }

  @Test
  public void test3991() {
    coral.tests.JPFBenchmark.benchmark54(93.7693165345676,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test3992() {
    coral.tests.JPFBenchmark.benchmark54(93.77071010645298,-0.2217800893874653,0 ) ;
  }

  @Test
  public void test3993() {
    coral.tests.JPFBenchmark.benchmark54(93.77268606751224,-0.6201681819936482,0 ) ;
  }

  @Test
  public void test3994() {
    coral.tests.JPFBenchmark.benchmark54(93.81930891396185,-0.20347281762482286,0 ) ;
  }

  @Test
  public void test3995() {
    coral.tests.JPFBenchmark.benchmark54(93.87286402000512,-0.38330859876820966,0 ) ;
  }

  @Test
  public void test3996() {
    coral.tests.JPFBenchmark.benchmark54(93.91571296821161,-1.369511553253382,0 ) ;
  }

  @Test
  public void test3997() {
    coral.tests.JPFBenchmark.benchmark54(93.9255827185687,-0.4292018055732001,0 ) ;
  }

  @Test
  public void test3998() {
    coral.tests.JPFBenchmark.benchmark54(93.93693314460839,-0.9933786706098221,0 ) ;
  }

  @Test
  public void test3999() {
    coral.tests.JPFBenchmark.benchmark54(93.96397452081638,-1.2369482896762918,0 ) ;
  }

  @Test
  public void test4000() {
    coral.tests.JPFBenchmark.benchmark54(9.396596155435539,-1.3044007807864641E-7,0 ) ;
  }

  @Test
  public void test4001() {
    coral.tests.JPFBenchmark.benchmark54(94.0119098025445,-1.191267479953737,0 ) ;
  }

  @Test
  public void test4002() {
    coral.tests.JPFBenchmark.benchmark54(94.15264940357989,-0.6442749937935432,0 ) ;
  }

  @Test
  public void test4003() {
    coral.tests.JPFBenchmark.benchmark54(94.21252781603931,-1.378550602381389,0 ) ;
  }

  @Test
  public void test4004() {
    coral.tests.JPFBenchmark.benchmark54(94.22548779650074,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4005() {
    coral.tests.JPFBenchmark.benchmark54(94.25667898647049,-1.4999999999999591,0 ) ;
  }

  @Test
  public void test4006() {
    coral.tests.JPFBenchmark.benchmark54(94.28850915142661,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4007() {
    coral.tests.JPFBenchmark.benchmark54(94.36149964569427,-1.4999999999999876,0 ) ;
  }

  @Test
  public void test4008() {
    coral.tests.JPFBenchmark.benchmark54(94.39077316241598,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4009() {
    coral.tests.JPFBenchmark.benchmark54(94.43460413008148,-1.3996729143483755,0 ) ;
  }

  @Test
  public void test4010() {
    coral.tests.JPFBenchmark.benchmark54(94.43578925912763,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4011() {
    coral.tests.JPFBenchmark.benchmark54(94.43594075206602,-1.1635367508724084,0 ) ;
  }

  @Test
  public void test4012() {
    coral.tests.JPFBenchmark.benchmark54(9.449216621255886,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4013() {
    coral.tests.JPFBenchmark.benchmark54(94.50462552282889,-1.497579643147077,0 ) ;
  }

  @Test
  public void test4014() {
    coral.tests.JPFBenchmark.benchmark54(9.451366544435915,-1.0413309323532065,0 ) ;
  }

  @Test
  public void test4015() {
    coral.tests.JPFBenchmark.benchmark54(94.52119782377135,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4016() {
    coral.tests.JPFBenchmark.benchmark54(94.54736734374038,-0.24807042358802145,0 ) ;
  }

  @Test
  public void test4017() {
    coral.tests.JPFBenchmark.benchmark54(94.56249365258222,-0.3609746018042461,0 ) ;
  }

  @Test
  public void test4018() {
    coral.tests.JPFBenchmark.benchmark54(9.456958841450103,-1.1942624236073467,0 ) ;
  }

  @Test
  public void test4019() {
    coral.tests.JPFBenchmark.benchmark54(94.59379836221723,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4020() {
    coral.tests.JPFBenchmark.benchmark54(9.462148285576632,-0.2476428445641119,0 ) ;
  }

  @Test
  public void test4021() {
    coral.tests.JPFBenchmark.benchmark54(94.62585970902818,-0.23980713606813478,0 ) ;
  }

  @Test
  public void test4022() {
    coral.tests.JPFBenchmark.benchmark54(94.6846544567826,-0.8069690321671033,0 ) ;
  }

  @Test
  public void test4023() {
    coral.tests.JPFBenchmark.benchmark54(94.69606071224658,-0.17945235821417782,0 ) ;
  }

  @Test
  public void test4024() {
    coral.tests.JPFBenchmark.benchmark54(94.70636626766994,-0.5613281036763524,0 ) ;
  }

  @Test
  public void test4025() {
    coral.tests.JPFBenchmark.benchmark54(-94.7338196565706,-2.7368294338529325E-7,10.301392414403722 ) ;
  }

  @Test
  public void test4026() {
    coral.tests.JPFBenchmark.benchmark54(94.73678666673766,-3.541434276382416E-9,0 ) ;
  }

  @Test
  public void test4027() {
    coral.tests.JPFBenchmark.benchmark54(94.7681078283851,-0.21374315355794593,0 ) ;
  }

  @Test
  public void test4028() {
    coral.tests.JPFBenchmark.benchmark54(94.79873724645235,-1.008412418885089,0 ) ;
  }

  @Test
  public void test4029() {
    coral.tests.JPFBenchmark.benchmark54(94.80452936500205,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4030() {
    coral.tests.JPFBenchmark.benchmark54(-94.8084337875462,-1.4999999999999998,88.93438346653605 ) ;
  }

  @Test
  public void test4031() {
    coral.tests.JPFBenchmark.benchmark54(94.82086231712822,-0.6798482274907658,0 ) ;
  }

  @Test
  public void test4032() {
    coral.tests.JPFBenchmark.benchmark54(94.83606320052866,-0.6406078841827143,0 ) ;
  }

  @Test
  public void test4033() {
    coral.tests.JPFBenchmark.benchmark54(94.84937454784412,-1.4662732374365817,0 ) ;
  }

  @Test
  public void test4034() {
    coral.tests.JPFBenchmark.benchmark54(-94.98062637491378,-0.021389183351281357,-1.0 ) ;
  }

  @Test
  public void test4035() {
    coral.tests.JPFBenchmark.benchmark54(95.00480446874525,-1.388260629279742,0 ) ;
  }

  @Test
  public void test4036() {
    coral.tests.JPFBenchmark.benchmark54(95.00866699869016,-0.7332311160859359,0 ) ;
  }

  @Test
  public void test4037() {
    coral.tests.JPFBenchmark.benchmark54(9.502829635346743,-1.1109876689831062,0 ) ;
  }

  @Test
  public void test4038() {
    coral.tests.JPFBenchmark.benchmark54(95.03275318675047,-0.632515611654711,0 ) ;
  }

  @Test
  public void test4039() {
    coral.tests.JPFBenchmark.benchmark54(95.06220297091411,-0.2549047990133577,0 ) ;
  }

  @Test
  public void test4040() {
    coral.tests.JPFBenchmark.benchmark54(95.07625282007959,-0.11952077425636284,0 ) ;
  }

  @Test
  public void test4041() {
    coral.tests.JPFBenchmark.benchmark54(9.510131348524823,-0.941030643497756,0 ) ;
  }

  @Test
  public void test4042() {
    coral.tests.JPFBenchmark.benchmark54(95.12288947843646,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4043() {
    coral.tests.JPFBenchmark.benchmark54(9.514746401015117,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4044() {
    coral.tests.JPFBenchmark.benchmark54(95.17722829904083,-0.37571644448629576,0 ) ;
  }

  @Test
  public void test4045() {
    coral.tests.JPFBenchmark.benchmark54(95.18973179475017,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4046() {
    coral.tests.JPFBenchmark.benchmark54(95.28091429014478,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4047() {
    coral.tests.JPFBenchmark.benchmark54(95.30090136344563,-0.06673607859174752,0 ) ;
  }

  @Test
  public void test4048() {
    coral.tests.JPFBenchmark.benchmark54(95.32233122418822,-1.3460355760061766,0 ) ;
  }

  @Test
  public void test4049() {
    coral.tests.JPFBenchmark.benchmark54(95.33946881236653,-0.7111283892248537,0 ) ;
  }

  @Test
  public void test4050() {
    coral.tests.JPFBenchmark.benchmark54(95.34491824228672,-1.3423400603703977,0 ) ;
  }

  @Test
  public void test4051() {
    coral.tests.JPFBenchmark.benchmark54(-95.3677895774805,-0.4732904054541236,-1.0 ) ;
  }

  @Test
  public void test4052() {
    coral.tests.JPFBenchmark.benchmark54(95.41351218605695,-0.055728064960235635,0 ) ;
  }

  @Test
  public void test4053() {
    coral.tests.JPFBenchmark.benchmark54(95.4752590804905,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4054() {
    coral.tests.JPFBenchmark.benchmark54(95.48939812524578,-1.3939896511264223,0 ) ;
  }

  @Test
  public void test4055() {
    coral.tests.JPFBenchmark.benchmark54(95.49412264150081,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4056() {
    coral.tests.JPFBenchmark.benchmark54(95.50645609979426,-0.4296679361365061,0 ) ;
  }

  @Test
  public void test4057() {
    coral.tests.JPFBenchmark.benchmark54(-9.554601085863052,-3.552713678800501E-15,0.9268580305294201 ) ;
  }

  @Test
  public void test4058() {
    coral.tests.JPFBenchmark.benchmark54(95.63420794144763,-8.919270356759893E-10,0 ) ;
  }

  @Test
  public void test4059() {
    coral.tests.JPFBenchmark.benchmark54(95.70453431673133,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4060() {
    coral.tests.JPFBenchmark.benchmark54(95.71278946329619,-1.499999999999993,0 ) ;
  }

  @Test
  public void test4061() {
    coral.tests.JPFBenchmark.benchmark54(95.7548021033895,-0.5197113932627828,0 ) ;
  }

  @Test
  public void test4062() {
    coral.tests.JPFBenchmark.benchmark54(95.78098740034739,-0.4733866523821266,0 ) ;
  }

  @Test
  public void test4063() {
    coral.tests.JPFBenchmark.benchmark54(9.581457506851791,-1.0141851429517272,0 ) ;
  }

  @Test
  public void test4064() {
    coral.tests.JPFBenchmark.benchmark54(95.81752192711696,-0.1893743371916612,0 ) ;
  }

  @Test
  public void test4065() {
    coral.tests.JPFBenchmark.benchmark54(9.583412145649776,-1.8607379460999924E-9,0 ) ;
  }

  @Test
  public void test4066() {
    coral.tests.JPFBenchmark.benchmark54(95.87610811653931,-0.11023915193161471,0 ) ;
  }

  @Test
  public void test4067() {
    coral.tests.JPFBenchmark.benchmark54(9.589973211714067,-0.11150109516054307,0 ) ;
  }

  @Test
  public void test4068() {
    coral.tests.JPFBenchmark.benchmark54(95.90546616126721,-0.923308508949944,0 ) ;
  }

  @Test
  public void test4069() {
    coral.tests.JPFBenchmark.benchmark54(95.91712615914165,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4070() {
    coral.tests.JPFBenchmark.benchmark54(95.94323889695156,-0.48740915960510733,0 ) ;
  }

  @Test
  public void test4071() {
    coral.tests.JPFBenchmark.benchmark54(95.97956285949768,-0.1047613641964178,0 ) ;
  }

  @Test
  public void test4072() {
    coral.tests.JPFBenchmark.benchmark54(96.03225715854049,-1.4349291778321884,0 ) ;
  }

  @Test
  public void test4073() {
    coral.tests.JPFBenchmark.benchmark54(96.04682281181779,-1.1832022142751824,0 ) ;
  }

  @Test
  public void test4074() {
    coral.tests.JPFBenchmark.benchmark54(96.06273375802819,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4075() {
    coral.tests.JPFBenchmark.benchmark54(96.06777526844698,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4076() {
    coral.tests.JPFBenchmark.benchmark54(9.61126615434074,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4077() {
    coral.tests.JPFBenchmark.benchmark54(96.14356733557361,-0.12176895549124822,0 ) ;
  }

  @Test
  public void test4078() {
    coral.tests.JPFBenchmark.benchmark54(96.21795953289663,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4079() {
    coral.tests.JPFBenchmark.benchmark54(96.22844773210417,-1.0034421721542515,0 ) ;
  }

  @Test
  public void test4080() {
    coral.tests.JPFBenchmark.benchmark54(96.27275776370533,-1.0503628170597068,0 ) ;
  }

  @Test
  public void test4081() {
    coral.tests.JPFBenchmark.benchmark54(9.629181394157925,-5.329239592347127E-10,0 ) ;
  }

  @Test
  public void test4082() {
    coral.tests.JPFBenchmark.benchmark54(96.36117028330585,-0.2602903571293469,0 ) ;
  }

  @Test
  public void test4083() {
    coral.tests.JPFBenchmark.benchmark54(96.38219841644761,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4084() {
    coral.tests.JPFBenchmark.benchmark54(96.42488330127361,-0.07865519125598208,0 ) ;
  }

  @Test
  public void test4085() {
    coral.tests.JPFBenchmark.benchmark54(96.4327525670339,-0.11629626029053908,0 ) ;
  }

  @Test
  public void test4086() {
    coral.tests.JPFBenchmark.benchmark54(96.48565126184357,-1.4330457130220706,0 ) ;
  }

  @Test
  public void test4087() {
    coral.tests.JPFBenchmark.benchmark54(96.52930436486125,-0.37910099443752787,0 ) ;
  }

  @Test
  public void test4088() {
    coral.tests.JPFBenchmark.benchmark54(96.62567309848481,72.33187907149977,-75.39697468228252 ) ;
  }

  @Test
  public void test4089() {
    coral.tests.JPFBenchmark.benchmark54(9.67389090882607,-1.2782940446033642,0 ) ;
  }

  @Test
  public void test4090() {
    coral.tests.JPFBenchmark.benchmark54(96.74035425728846,-0.18082812179075214,0 ) ;
  }

  @Test
  public void test4091() {
    coral.tests.JPFBenchmark.benchmark54(96.78703884553732,-0.4512787221035097,0 ) ;
  }

  @Test
  public void test4092() {
    coral.tests.JPFBenchmark.benchmark54(96.81838268364868,-1.178910245749659,0 ) ;
  }

  @Test
  public void test4093() {
    coral.tests.JPFBenchmark.benchmark54(96.88504124564872,-0.8520132587002842,0 ) ;
  }

  @Test
  public void test4094() {
    coral.tests.JPFBenchmark.benchmark54(96.88738564950893,-0.8169377199562682,0 ) ;
  }

  @Test
  public void test4095() {
    coral.tests.JPFBenchmark.benchmark54(96.88914412494739,-1.1241378859564795,0 ) ;
  }

  @Test
  public void test4096() {
    coral.tests.JPFBenchmark.benchmark54(96.90949674856495,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4097() {
    coral.tests.JPFBenchmark.benchmark54(96.93747058438888,-0.3140469943812181,0 ) ;
  }

  @Test
  public void test4098() {
    coral.tests.JPFBenchmark.benchmark54(97.00995400324601,-0.25561754906011913,0 ) ;
  }

  @Test
  public void test4099() {
    coral.tests.JPFBenchmark.benchmark54(97.02380467700499,-0.6503969869025923,0 ) ;
  }

  @Test
  public void test4100() {
    coral.tests.JPFBenchmark.benchmark54(97.06188521548745,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4101() {
    coral.tests.JPFBenchmark.benchmark54(-97.06871003118476,-0.004902083823039935,-100.0 ) ;
  }

  @Test
  public void test4102() {
    coral.tests.JPFBenchmark.benchmark54(9.711528433577637,-0.20183568874963193,0 ) ;
  }

  @Test
  public void test4103() {
    coral.tests.JPFBenchmark.benchmark54(97.12279256946182,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4104() {
    coral.tests.JPFBenchmark.benchmark54(97.13469669388644,-1.2550739020947117,0 ) ;
  }

  @Test
  public void test4105() {
    coral.tests.JPFBenchmark.benchmark54(97.1986419282776,-0.5706178703626568,0 ) ;
  }

  @Test
  public void test4106() {
    coral.tests.JPFBenchmark.benchmark54(97.20408425407891,-0.7421459127580379,0 ) ;
  }

  @Test
  public void test4107() {
    coral.tests.JPFBenchmark.benchmark54(97.20810110551008,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4108() {
    coral.tests.JPFBenchmark.benchmark54(-97.20814664872195,17.403750347945504,-7.975263290435208 ) ;
  }

  @Test
  public void test4109() {
    coral.tests.JPFBenchmark.benchmark54(97.27019553372764,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4110() {
    coral.tests.JPFBenchmark.benchmark54(97.27412304023508,-0.34305064632069104,0 ) ;
  }

  @Test
  public void test4111() {
    coral.tests.JPFBenchmark.benchmark54(97.28678337658795,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4112() {
    coral.tests.JPFBenchmark.benchmark54(97.3047763058072,-0.6587931544247939,0 ) ;
  }

  @Test
  public void test4113() {
    coral.tests.JPFBenchmark.benchmark54(97.35112032407585,-0.8838016465249297,0 ) ;
  }

  @Test
  public void test4114() {
    coral.tests.JPFBenchmark.benchmark54(97.3774921401841,-0.8193459218051726,0 ) ;
  }

  @Test
  public void test4115() {
    coral.tests.JPFBenchmark.benchmark54(97.43164464866895,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4116() {
    coral.tests.JPFBenchmark.benchmark54(97.47284970038899,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4117() {
    coral.tests.JPFBenchmark.benchmark54(9.749269928771454,-0.5880768490532453,0 ) ;
  }

  @Test
  public void test4118() {
    coral.tests.JPFBenchmark.benchmark54(97.4990312786974,-0.9037503205966644,0 ) ;
  }

  @Test
  public void test4119() {
    coral.tests.JPFBenchmark.benchmark54(-97.50538844575154,-0.011858306078370595,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test4120() {
    coral.tests.JPFBenchmark.benchmark54(9.751959842232381,-0.3556975197207786,0 ) ;
  }

  @Test
  public void test4121() {
    coral.tests.JPFBenchmark.benchmark54(97.53948791124147,-0.026110737236479054,0 ) ;
  }

  @Test
  public void test4122() {
    coral.tests.JPFBenchmark.benchmark54(97.59431480112553,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4123() {
    coral.tests.JPFBenchmark.benchmark54(97.60212401875407,-0.7065986373923917,0 ) ;
  }

  @Test
  public void test4124() {
    coral.tests.JPFBenchmark.benchmark54(97.6195769371995,-1.089178255047194,0 ) ;
  }

  @Test
  public void test4125() {
    coral.tests.JPFBenchmark.benchmark54(97.64819906173366,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4126() {
    coral.tests.JPFBenchmark.benchmark54(97.67772473454039,-0.20051500353579524,0 ) ;
  }

  @Test
  public void test4127() {
    coral.tests.JPFBenchmark.benchmark54(97.69552312208941,-0.5126377413709129,0 ) ;
  }

  @Test
  public void test4128() {
    coral.tests.JPFBenchmark.benchmark54(97.70715397830452,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4129() {
    coral.tests.JPFBenchmark.benchmark54(9.774798830783851,-0.18323984366593216,0 ) ;
  }

  @Test
  public void test4130() {
    coral.tests.JPFBenchmark.benchmark54(97.76343512314286,-1.4275876019973133,0 ) ;
  }

  @Test
  public void test4131() {
    coral.tests.JPFBenchmark.benchmark54(97.77715748675084,-1.2126078824314184,0 ) ;
  }

  @Test
  public void test4132() {
    coral.tests.JPFBenchmark.benchmark54(97.81303116003443,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4133() {
    coral.tests.JPFBenchmark.benchmark54(97.85902701191068,-0.5561336370218005,0 ) ;
  }

  @Test
  public void test4134() {
    coral.tests.JPFBenchmark.benchmark54(97.89076884182077,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4135() {
    coral.tests.JPFBenchmark.benchmark54(97.90886702703872,-0.7395938776079589,0 ) ;
  }

  @Test
  public void test4136() {
    coral.tests.JPFBenchmark.benchmark54(97.93669315238192,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4137() {
    coral.tests.JPFBenchmark.benchmark54(97.94018451138612,-0.408964563724183,0 ) ;
  }

  @Test
  public void test4138() {
    coral.tests.JPFBenchmark.benchmark54(98.0308067311235,-1.4544684212116161,0 ) ;
  }

  @Test
  public void test4139() {
    coral.tests.JPFBenchmark.benchmark54(98.04745458130193,-1.0033897650535768,0 ) ;
  }

  @Test
  public void test4140() {
    coral.tests.JPFBenchmark.benchmark54(98.06351723001418,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4141() {
    coral.tests.JPFBenchmark.benchmark54(98.07182864712502,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4142() {
    coral.tests.JPFBenchmark.benchmark54(98.07464201508219,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4143() {
    coral.tests.JPFBenchmark.benchmark54(98.07968123198708,-1.0935071277884134,0 ) ;
  }

  @Test
  public void test4144() {
    coral.tests.JPFBenchmark.benchmark54(98.11163976830304,-1.1851692281300235,0 ) ;
  }

  @Test
  public void test4145() {
    coral.tests.JPFBenchmark.benchmark54(98.172161309762,-4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test4146() {
    coral.tests.JPFBenchmark.benchmark54(98.17762204313914,-0.9336643782390333,0 ) ;
  }

  @Test
  public void test4147() {
    coral.tests.JPFBenchmark.benchmark54(98.2147617993648,-1.1889620091430402,0 ) ;
  }

  @Test
  public void test4148() {
    coral.tests.JPFBenchmark.benchmark54(9.82317237919695,-0.3455784861472858,0 ) ;
  }

  @Test
  public void test4149() {
    coral.tests.JPFBenchmark.benchmark54(98.30410719494675,-1.4349201375134417,0 ) ;
  }

  @Test
  public void test4150() {
    coral.tests.JPFBenchmark.benchmark54(98.31014348788929,-0.7924779414367911,0 ) ;
  }

  @Test
  public void test4151() {
    coral.tests.JPFBenchmark.benchmark54(9.83337037794088,-1.4999999999999964,0 ) ;
  }

  @Test
  public void test4152() {
    coral.tests.JPFBenchmark.benchmark54(98.3468113755508,-0.3804008225552242,0 ) ;
  }

  @Test
  public void test4153() {
    coral.tests.JPFBenchmark.benchmark54(-98.35597771322317,-0.42945239942111296,-1.0 ) ;
  }

  @Test
  public void test4154() {
    coral.tests.JPFBenchmark.benchmark54(98.36947613075773,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4155() {
    coral.tests.JPFBenchmark.benchmark54(98.42073898880582,-0.3781806453269496,0 ) ;
  }

  @Test
  public void test4156() {
    coral.tests.JPFBenchmark.benchmark54(9.84215334334948,-0.8360804969839384,0 ) ;
  }

  @Test
  public void test4157() {
    coral.tests.JPFBenchmark.benchmark54(98.4788361528816,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4158() {
    coral.tests.JPFBenchmark.benchmark54(98.52608484662917,-0.9416859220754219,0 ) ;
  }

  @Test
  public void test4159() {
    coral.tests.JPFBenchmark.benchmark54(98.5417769640897,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4160() {
    coral.tests.JPFBenchmark.benchmark54(98.54809523630118,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4161() {
    coral.tests.JPFBenchmark.benchmark54(98.59650318312026,-0.9821285781598585,0 ) ;
  }

  @Test
  public void test4162() {
    coral.tests.JPFBenchmark.benchmark54(-9.860761315262648E-32,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4163() {
    coral.tests.JPFBenchmark.benchmark54(98.62991633159754,-0.5081420087742856,0 ) ;
  }

  @Test
  public void test4164() {
    coral.tests.JPFBenchmark.benchmark54(98.67355147827391,-0.1073372758832431,0 ) ;
  }

  @Test
  public void test4165() {
    coral.tests.JPFBenchmark.benchmark54(98.70060213506186,-2.2013168456466972E-8,0 ) ;
  }

  @Test
  public void test4166() {
    coral.tests.JPFBenchmark.benchmark54(9.880635433716709,-0.5538715727856421,0 ) ;
  }

  @Test
  public void test4167() {
    coral.tests.JPFBenchmark.benchmark54(98.81724735202761,-0.12779243272083704,0 ) ;
  }

  @Test
  public void test4168() {
    coral.tests.JPFBenchmark.benchmark54(98.82219343835814,-1.3528101224107263,0 ) ;
  }

  @Test
  public void test4169() {
    coral.tests.JPFBenchmark.benchmark54(98.87333211530097,-1.4999999999999982,0 ) ;
  }

  @Test
  public void test4170() {
    coral.tests.JPFBenchmark.benchmark54(9.889729084010895,-0.8940045921593764,0 ) ;
  }

  @Test
  public void test4171() {
    coral.tests.JPFBenchmark.benchmark54(98.93731502755517,-0.9947655823715178,0 ) ;
  }

  @Test
  public void test4172() {
    coral.tests.JPFBenchmark.benchmark54(9.894896176861852,-1.4999999999999998,0 ) ;
  }

  @Test
  public void test4173() {
    coral.tests.JPFBenchmark.benchmark54(98.96513361332893,-1.3751440063006257,0 ) ;
  }

  @Test
  public void test4174() {
    coral.tests.JPFBenchmark.benchmark54(98.97455287469774,-1.4945855899873155,0 ) ;
  }

  @Test
  public void test4175() {
    coral.tests.JPFBenchmark.benchmark54(98.99578419665445,-0.35120223848423393,0 ) ;
  }

  @Test
  public void test4176() {
    coral.tests.JPFBenchmark.benchmark54(99.00193851717395,-1.4280708616659865,0 ) ;
  }

  @Test
  public void test4177() {
    coral.tests.JPFBenchmark.benchmark54(99.07354838171081,-4.5548675799222655E-17,0 ) ;
  }

  @Test
  public void test4178() {
    coral.tests.JPFBenchmark.benchmark54(99.09156829829207,-0.8425857564538427,0 ) ;
  }

  @Test
  public void test4179() {
    coral.tests.JPFBenchmark.benchmark54(99.09388525382411,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test4180() {
    coral.tests.JPFBenchmark.benchmark54(99.11102037025685,-1.2040714994311728,0 ) ;
  }

  @Test
  public void test4181() {
    coral.tests.JPFBenchmark.benchmark54(99.18067885217968,-0.7290941616733377,0 ) ;
  }

  @Test
  public void test4182() {
    coral.tests.JPFBenchmark.benchmark54(99.23607081075366,-0.6322554462590944,0 ) ;
  }

  @Test
  public void test4183() {
    coral.tests.JPFBenchmark.benchmark54(-99.26011970393434,-2.220446049250313E-16,-97.36284741840954 ) ;
  }

  @Test
  public void test4184() {
    coral.tests.JPFBenchmark.benchmark54(-99.26787531635175,-0.9230737715152513,-1.0339757656912846E-25 ) ;
  }

  @Test
  public void test4185() {
    coral.tests.JPFBenchmark.benchmark54(99.27805452932918,-1.25022881268891,0 ) ;
  }

  @Test
  public void test4186() {
    coral.tests.JPFBenchmark.benchmark54(99.3332118430016,-0.005258559143231593,0 ) ;
  }

  @Test
  public void test4187() {
    coral.tests.JPFBenchmark.benchmark54(99.36189428295498,-0.5648041123250369,0 ) ;
  }

  @Test
  public void test4188() {
    coral.tests.JPFBenchmark.benchmark54(99.37897313081271,-0.059475920814865246,0 ) ;
  }

  @Test
  public void test4189() {
    coral.tests.JPFBenchmark.benchmark54(99.40610618944227,-1.4999999998873137,0 ) ;
  }

  @Test
  public void test4190() {
    coral.tests.JPFBenchmark.benchmark54(9.947649169637756,-1.092561489525215,0 ) ;
  }

  @Test
  public void test4191() {
    coral.tests.JPFBenchmark.benchmark54(99.48303021895696,-2.220446049250313E-16,0 ) ;
  }

  @Test
  public void test4192() {
    coral.tests.JPFBenchmark.benchmark54(99.48786778783833,-1.1295904714331833,0 ) ;
  }

  @Test
  public void test4193() {
    coral.tests.JPFBenchmark.benchmark54(99.54259960933832,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4194() {
    coral.tests.JPFBenchmark.benchmark54(99.5486675191018,-1.2466243808641337,0 ) ;
  }

  @Test
  public void test4195() {
    coral.tests.JPFBenchmark.benchmark54(9.9556775471207,-4.719461185225753E-8,0 ) ;
  }

  @Test
  public void test4196() {
    coral.tests.JPFBenchmark.benchmark54(99.59561577830237,-0.2854303078822742,0 ) ;
  }

  @Test
  public void test4197() {
    coral.tests.JPFBenchmark.benchmark54(99.61397960149446,-1.428198825771209,0 ) ;
  }

  @Test
  public void test4198() {
    coral.tests.JPFBenchmark.benchmark54(99.63545434336638,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4199() {
    coral.tests.JPFBenchmark.benchmark54(99.66496220854486,-0.5080864800708369,0 ) ;
  }

  @Test
  public void test4200() {
    coral.tests.JPFBenchmark.benchmark54(99.670094799509,-0.6063379659850368,0 ) ;
  }

  @Test
  public void test4201() {
    coral.tests.JPFBenchmark.benchmark54(99.68621076645582,-1.1182302448810617,0 ) ;
  }

  @Test
  public void test4202() {
    coral.tests.JPFBenchmark.benchmark54(99.69306097775333,-8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test4203() {
    coral.tests.JPFBenchmark.benchmark54(99.73639011490357,-0.6102812422141106,0 ) ;
  }

  @Test
  public void test4204() {
    coral.tests.JPFBenchmark.benchmark54(99.7398171557515,-1.1983575996956368,0 ) ;
  }

  @Test
  public void test4205() {
    coral.tests.JPFBenchmark.benchmark54(99.77374711691397,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4206() {
    coral.tests.JPFBenchmark.benchmark54(99.82541794783307,-1.3195980994333456,0 ) ;
  }

  @Test
  public void test4207() {
    coral.tests.JPFBenchmark.benchmark54(99.82684509370193,-0.497988588326353,0 ) ;
  }

  @Test
  public void test4208() {
    coral.tests.JPFBenchmark.benchmark54(99.89020315318444,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test4209() {
    coral.tests.JPFBenchmark.benchmark54(9.989128075620236,-1.292966839551113,0 ) ;
  }

  @Test
  public void test4210() {
    coral.tests.JPFBenchmark.benchmark54(99.89618001978546,-1.4999999999999991,0 ) ;
  }

  @Test
  public void test4211() {
    coral.tests.JPFBenchmark.benchmark54(99.94810038742293,-1.2036190053896725,0 ) ;
  }

  @Test
  public void test4212() {
    coral.tests.JPFBenchmark.benchmark54(99.98826133123191,-0.727814331081619,0 ) ;
  }

  @Test
  public void test4213() {
    coral.tests.JPFBenchmark.benchmark54(99.98970053828299,98.7751701701444,-82.47214226057633 ) ;
  }

  @Test
  public void test4214() {
    coral.tests.JPFBenchmark.benchmark54(99.99853234374014,-1.4999999999999996,0 ) ;
  }

  @Test
  public void test4215() {
//    	UnSolved;
  }
}
