import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
//    0.6130141761393355;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.020145456980422694,-0.30608620740368764,-4.198203578807451,-0.9999999999999929 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.035691630542646485,-1.345098444442109E-4,-78.80604197679294,-0.21382787078336374 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark11(0.0379712260039983,-0.021210563198981295,1.551549202700918,0.9780503179520578 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark11(-0.043553110563989916,-0.37070943722528304,75.44394179369067,-2287.3938766658275 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark11(0.049706010322658756,-0.9008403507933345,-98.11162111276148,0.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark11(0.05345342126290564,-0.4500982453098752,-67.43704855614133,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark11(0.055227359097805184,-0.8392806887520056,-1.5707963267948948,-65.82489494634441 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark11(0.07455460513424583,-0.7172098761330998,-39.90502020064432,60.520894998405424 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark11(-0.07652284914351526,-0.6313251933959012,-61.46463607654292,-0.06256435691320143 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark11(0.07897261839859482,-1.5028405672423468,-10.280751834070955,-1.0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark11(0.10467893800893838,-1.062274959974772,158.14249125275316,-12.402690480092176 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark11(-0.10867979206640377,-0.7393466487652461,-25.3259795646439,-86.28194325239201 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark11(0.1265416120347379,-0.5951478868358874,1.570796326794893,1.0000032855591094 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark11(-0.15350283849758647,-1.329543491301888,-59.11534697454523,1.0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark11(0.161503684036015,-1.1913207054491437,-65.19184813579015,-1.0000000000000009 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark11(0.17109069602278415,-1.2404598205456197,1.5707963267948966,-4.445517498970155E-162 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark11(-0.2043738654093481,-1.5707963267948948,-38.666107362958584,0.056590892342384784 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark11(0.20819547154684415,-1.4314646832652755,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark11(-0.2357881218471185,-0.017865591743813414,-29.375240602574195,-0.370653896663935 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark11(0.24429567538693137,-0.9343193079360859,-84.13887357808139,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark11(-0.25573319610910517,-1.0545561584592067,-84.41961901665168,0.03987829350978763 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark11(-0.26148557958624963,-0.41416449511251535,-36.00065884473827,1.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark11(-0.2645206955588293,-0.2920848355562864,-17.20527898117115,-1.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark11(-0.26520073716190873,-0.7107642910617459,-38.91755536637769,-57.827798907567114 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark11(0.2746224308994134,-1.5707963267948948,-62.73086977154391,-2195.674383902894 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark11(0.2815929728018709,-1.0250839790280821,-41.031224963377156,0.032834885477771025 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark11(-0.2843079451806929,-1.5707963267948948,-71.87630179743945,58.105953886385436 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark11(0.2939173403572325,-1.3722161304671046,-14.874125583881103,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark11(0.3033324490265521,-0.9699850695820826,-83.79612153295594,8.881784197001252E-16 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark11(0.3151599838333445,-0.10374210146865882,-48.54488848748084,1.0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark11(0.32641973681226943,-0.6843503632208154,-72.6011131528822,69.60062516358747 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark11(-0.3419065264205843,-1.5707963267948963,-28.77507888893338,20.54032584726056 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark11(-0.35282370225078913,-8.40186121877095E-6,-67.37063318057267,-0.46493056721545395 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark11(-0.3790988351124902,-0.3509264396800477,-81.15649424090982,-19.036219947419646 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark11(0.38039752697594054,-1.0045572250886121,79.81747477612626,0 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark11(-0.38068569649824724,-0.1853246641641526,-30.32282386715437,0.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark11(-0.41826657669517786,-0.19402815981162147,-31.54271030198511,-1.8062572991882284 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark11(-0.439151632177186,-1.3635350562580506,-45.502499030979386,-47.32975353130426 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark11(0.4541132179728046,-1.2120057733618117,-2.5393803001345816,1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark11(0.4557727716413478,-0.35616742837977333,-67.19502257324552,1.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark11(-0.46286329783418934,-1.4051022877014696,32.649732959598026,1.000000001083283 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark11(-0.46550227950308254,-1.0321962861862786,-56.13496274673879,18.62126543590452 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark11(0.46563626534677827,-1.5707963267948912,39.22708766781443,-2156.3850602635953 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark11(0.4865459258671878,-0.058719180391886616,26.633006126385766,1.0000000941911367 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark11(-0.49385670552990235,-1.5707963267948961,0.2611565750227432,1.0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark11(0.5023335148897452,-0.8416956834667447,-95.43592001638677,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark11(0.5288522530284396,-0.7322692762434524,-71.50840545275226,1.0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark11(0.5464420018973618,-0.12452262556874308,39.15670372228459,2.8853058180580424E-129 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark11(-0.552564841585403,-1.5707963267948963,88.31748311286546,0.8947992720182909 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark11(-0.5854507590387332,-0.001793180986171001,-39.1876785169762,-0.9420769743236066 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark11(0.5875403623644182,-0.25076869594778745,0.0,-3.294512422379352E-16 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark11(0.6047891113524052,-1.2561386674656672,-40.33639736475774,-32.24867236475323 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark11(-0.611762069989112,-1.5597404455745192,-37.934160271875704,-0.5666278856272551 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark11(0.6485635886632621,-0.03055805903781872,1.5707963267948966,91.38148955599924 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark11(-0.6542554223529882,-1.3829459763604843,88.08738827776378,47.208988421599 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark11(0.7179732817741667,-1.5707963267948957,-57.53970185576791,0.01264541533795763 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark11(0.7490115357686626,-0.020339827025300992,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark11(0.7518031838539443,-1.2816350672755785,-20.83001812090074,-1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark11(-0.762458373185023,-1.2143721813063353,-53.587401439155386,1742.2424210810234 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark11(0.7788025564821748,-0.6107273841978166,0.0,1.0632835415659365 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark11(0.7791582904610884,-1.568058084997823,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark11(0.8129965125855173,-0.48709646636801746,-1.5707963267948966,0.9999999999999997 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark11(-0.8253700620515412,-0.4266106182202556,-5.079266216903035E-15,-2224.995646915937 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark11(-0.8257884594827807,-0.9386740844329071,-81.81862829739927,1.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark11(-0.8361336369293492,-1.4873168803352963,-1.5707963267948961,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark11(0.8556362164373552,-0.49756247682895705,-53.90310072872207,-61.29410411611282 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark11(0.8626682199770298,-0.8399147762353891,-16.327284153365156,-0.8348483590613576 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark11(-0.8867051664771827,-0.1064186777443611,-56.39971933317804,1.0 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark11(0.8912746956152399,-1.560580617781693,0.0,50.90682005106197 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark11(0.9034170001997381,-1.5707963267948948,-93.59291557503974,0.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark11(0.9104246743689473,-1.5707963267948952,-32.83453478810881,0.48799717242558627 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark11(0.9107536271083552,-1.5707963267948963,0.0,0.29446083040574045 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark11(0.91196060431533,-1.5707963267948961,0.4236669126877976,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark11(0.9127516262613067,1.214137920337239,95.95500849958587,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark11(0.9157794944180391,-1.1139522872133465,-100.0,-26.62541109184558 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark11(0.9197129915365085,-1.552886159946245,-72.45629214759958,-0.8867723001317862 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark11(-0.9292041420568482,-1.5707963267948712,-0.19164665335524123,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark11(0.9294725552821246,-1.4951271752609836,-0.47070514297013233,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark11(0.9347215310004346,-0.17326079087051566,-38.183061678314196,-83.9135687978517 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark11(0.9558708429228107,-0.2775125868024304,-46.1444487212291,-1.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark11(-0.96459821081569,-1.264157025830956,45.52693712538099,0.06257152642562347 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark11(0.9697826468287989,-1.5707963267948912,94.75912028092722,0.06303193247235322 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark11(-0.9910919546856967,-0.12361187478857866,-32.982583526928394,1754.8483336270333 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark11(0.9911560648584994,-0.010092378931352732,-23.660184689747805,-1.0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark11(0.9992322280728132,-0.5674565368634654,-43.03095839274205,-2234.663174723662 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark11(0.9992568062857835,-1.0098961209572528,-5.414362888895615E-4,-0.3433694682001285 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999929,-0.2895534543597053,-5.763266583688136,-0.034092244418056056 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999929,-0.8622414494576903,-64.13485715226314,0.05168280387410193 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999929,-1.1643673485653723,-4.398101658589722,-77.54238268154135 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999929,-1.368279524076084,-31.520298307981705,-70.12397572542663 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999964,-0.42016229819985496,-68.48855893938507,-2.5565211870921144E-16 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999964,-1.470356924480433,-39.13799737372524,-42.02070759496588 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999971,-1.4763250467138733,1.5707963267948966,-62.16146337220778 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999982,-0.0965692020187266,158.4105039634208,0.6860335804074786 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999982,-1.5685550778445119,-2.55121607801918E-16,0.559490700092879 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999988,-0.4953444781705656,-33.07154077037377,-81.54446302627977 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999998,-0.09792353174499137,-0.21714171478745453,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999998,-1.4400716912105385,-1.5707963267948966,0.06256400719771774 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark11(0.9999999999999998,-1.5707963267948961,7.413989373024766,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.0041412704740397795,-72.7433736607689,-0.41326559906869775 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.010558144876941398,37.950901635531274,1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.016156820409224084,-29.886831026925663,0.9713029836890419 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.018087813566399935,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.023687311128069533,-17.00962648745901,1.0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.027632243953501057,-72.91873577465279,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.028074519290271716,-45.44803396756412,-1.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.034459661568228384,0.0,-27.064790793665527 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.038491423666876294,-56.81030158604365,-1.0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.042734937224031266,50.279310019821395,1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.04986665735949938,-66.74321893409237,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.05862470926629116,-29.230526241382208,-88.64241974413093 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.06113858843091896,-55.68575974750218,-13.460976445296644 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.06319899002686102,-75.41141355452835,0.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.06923862409205905,-67.90034403681933,-1.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07458972994298876,94.34868199456514,-0.026099223218703047 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07473750988151451,-1.5707963267948966,-0.34580098992012154 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07479518686877322,164.39798739047788,49.46802608046024 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07563667725397849,1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07951926946276511,32.797857376744595,-0.12261449413120395 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.07960546675634328,-57.165669317421795,0.0431860779762397 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.10099066080541767,1.5707963267948966,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.10420004867652619,-88.15985777918306,0.01762251321787999 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.11032475369272143,-9.124705242544103,-54.00338798791387 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12089600479321373,38.905040011734805,-0.8490599143795826 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12138705253103678,-55.42029144569087,0.8760048202125872 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12790472128120167,-50.851602788609114,47.80912163740204 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.12834565729085232,53.04661239230239,-1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1300874993896438,-25.9270552972598,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.15677512125617993,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.16966819887503792,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.18541317749379477,-100.0,0.1470349806729634 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1891250873780746,-56.57455034868677,1.000000000000003 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.19546547518295082,-69.77993861764182,57.33148877216011 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.1997665452451373,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.20451526861600522,-41.54398466001859,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.22320836533316266,1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2259070986504945,45.086625444487424,-1.0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2293316408948911,1.5707963267948966,1.0000000000046014 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2411468766353208,-1.5707963267948966,1.2295088155223226 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.24314970325577345,-76.1167554333802,52.311796772823676 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.27487994277574956,-100.0,100.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.27974741787676655,-1.5677685470894505,51.30678528963456 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.28515239948777343,1.5707963267948983,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.29120276006786944,32.56467109963845,-0.03777584517241067 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.2967032853380209,-94.70887067528358,1.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3099773573961428,-0.9279160694287655,0.05967792695789137 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3106642768263925,-23.68301845173977,100.0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.31274812682933373,1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.36039429824342883,1.5707963267945466,-1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3649017776113794,-14.08905511104956,54.42783420554221 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3733089569833705,-54.73210658716106,-1.0000000003466543 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.38137777508353987,0.0,1.0000015404317917 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3861496187498372,-66.2412264430768,1.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3915423063901544,95.16056665016814,0.2721448708391394 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.3923831235386519,0.0,-84.90838640344055 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.395574816873578,62.96321218477488,-19.871873137951567 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.40708948937355893,-1.5707963267948966,9.016580681431383E-131 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.40785134751656765,0.6166136730857266,16.924433358944242 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4105285433578365,-55.268409272885265,-1.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.41944854940275755,-64.39222443082475,0.9888298554672867 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4253808439394593,1.5707963267948983,-95.93192670913902 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.42985647837378316,32.895068299317586,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.45007586508984493,21.084967748844612,-0.1687597813122037 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4551959572223949,-37.5427926193042,1.0000000125174746 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4694595056596991,-70.26434797739614,1.0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4702756657988143,44.50183272564871,-0.6228759701535342 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.4805856940768791,-1.5707963267948963,-1960.2313129833965 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.49034080690958604,83.14253130979966,1.004643784495343 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.49990109875578526,6.712395439342036,100.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.508091149051596,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.5936146151244985,144.91714338603228,-0.2513307967346172 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6114670346887894,-1.5707963267948966,-0.8385827600946253 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6270337432428645,1.5707963267748142,1.0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6530596503781521,-44.05105946953431,-17.51841097393671 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6591509350290666,-14.429242601642166,-21.124812268994255 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6713720257977229,-29.046293710086758,-0.020735677115021334 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6811745539668671,-68.89472877136309,1.000324213142636 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.687022614319054,1.5861483795977236,-0.09742948861418443 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.6920557161976766,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7123142271399454,26.143897566132928,-0.06281515131371229 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7189135868190157,-30.87823365649598,-0.04764980928430873 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7290560504124546,0.0,0.9556594838369775 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7628247697356014,-100.0,6.293343679864785E-6 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7670525156555172,-45.654487619653786,0.357011265043897 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.789068344346396,-73.68508284681997,-1.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7941347961330478,-80.27049630133975,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.7955387927517856,50.41669745898781,-27.54689333941218 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8204369654711893,0.277267023258456,-23.282100387891248 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8211409325450066,5.148439267485811,0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8222771741209848,-1.5707963267948966,1.0000000001163218 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8229682887282204,0.0,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8240942390785543,-1.3703608829837626,-1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8289340632893344,-92.07356145638147,-0.8141971763223962 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8352722646134827,-100.0,-1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.8892303563118614,15.20138381978886,-1.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.926256813881072,-68.92210536485237,-1.0 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9453066992917392,59.506520782607666,0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9476394042874821,-17.884353482137215,6.314637399347468 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9531049228545335,-100.0,1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9557675532542165,1.5707963267948966,-94.50065049332132 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9707873640794539,-90.86897948000194,0.056883839398484695 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9733493338220709,-32.54083078384238,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9842726565538604,-31.560733021976873,0.44586484888718136 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-0.9927632530583775,33.202151105862065,-0.04841031654179906 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0002399247115878,-68.59842306629652,-1.0417560019813863 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0004819398002958,-73.57229994549571,0.9999999999999964 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.006661516539836,-4.699197882375742,-0.5203746615705638 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0177159986056745,19.62980226372106,-48.806387185972234 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0292837775935155,95.36290449980335,-47.86569202865757 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0313086939073854,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0435671772705215,-65.39041736445255,14.421303417153434 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0724800989540757,0.0,100.0 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.0929105702313446,13.370163633985527,-0.020323997959273976 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1088290592928192,-1.5707963267948966,-0.6534060259612994 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1147040876914125,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.116375931723217,-31.594481621814168,0.7759568529550321 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1268428436116862,0.9567008219271054,-0.030689140955621343 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1302384062705553,-62.27516054606399,-0.01661745722967604 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1721841232210153,1.5707963267948983,72.38711135341197 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.1813376387957142,-42.36905261427991,0.6933456252167789 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.198036813230863,1.5707963267948966,-3.2796621333149854E-7 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2037970524890103,0.014744464901410795,-1.0000000006915866 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2054874246667007,32.472639680266674,-1.0000002010484248 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2093352757298832,32.090527846434696,-1.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2215959883917176,-67.14764944003352,1.0000000000000036 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.227376695674628,-9.505479984261669,0.02552261864666481 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2440928147154255,-6.441287694935629,0.0 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2447550460702326,0.0,1.0000010794051055 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.251489555982884,-10.942517843512293,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2539560173438993,-27.039305210302558,-0.003604355441322913 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2556572567733446,88.36498414327444,45.67259596897483 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2578696895269963,-32.632994090161645,-0.06255253295341628 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.266428317469149,-8.40283939087718,0.0 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2817332541612276,-91.80173609754775,1.0000000045664337 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2848279878917204,-26.343984444407454,-0.9999999999999991 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2961695222672271,-30.69820860451233,-51.72616632732756 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.2975327656584594,-36.502559557757365,1.0075847647141387 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3118288010264507,-110.00309410157017,0.9987133873245845 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3160903435461684,-1.7763568394002505E-15,-64.20605015056671 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3250276295261887,1.5707963267948966,0.9923561931915519 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.343231026596889,69.13621877518887,1.0 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3448042311703683,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3486527168823184,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3491493908588374,-4.3541524162831315,0.06255262802364896 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.351895008216724E-15,1.5707963267948966,1.6543612251060553E-24 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3623051596133129,-65.75876975543335,-1.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3694038190412636,-1.5707963267948966,-21.888375841787703 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3751500213305299,94.5556024988532,-0.9999999999999964 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3765704784869692,45.507907650497515,-0.06259606364929286 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.378051652897536,1.1778790772042877,37.293567430680646 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3855701695112548,-23.797295285889852,1.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.3995626883358623,-39.145388294475225,0.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.405919357768488,-1.5707963267948963,98.71925105385425 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4153630653947817,88.47562952603609,0.010979145896395327 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.425302783810311,-45.91013697317909,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4356508887356043,0.0,-0.5457305047042766 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4593609716752194,-3.1524204223299845,0.3620898846509813 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4649172263738226,-33.36208450835852,-1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4653175756631627,-31.417231591349584,-94.75605864475244 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.476562607628149,0.0,0.7681770674380479 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4773470609173887,-1.5707963267948966,-1.0000029898177594 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4805038913728485,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4822734314851818,-19.39310503466723,-1.0000314904825067 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4887118981068437,-1.5673538319761378,1.0000001352711898 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4904708690198054,-71.70676430402159,3.5228333935010944E-9 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.4941782744397956,-1.2898405981881353,-0.06301076387879677 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.507073528254864,-42.64777604217016,79.59142167233006 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5304503251744688,0.0,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5311754051513708,-6.573577238464896,0.7357931784078166 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5363938143815847,0.6318743121472519,100.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5378071620179552,-36.130158990605125,-1.154122327223217E-128 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5406429155002066,-17.404608134207834,0.047354140160496085 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5437683329147658,-88.39865761645838,1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.546579003890413,-54.9840316688805,1.0643015488357057 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5470610787669459,-100.0,0.043980669651777465 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5495604475261084,1.5218686819280611,-0.0625762639335494 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.553454972149714,37.82609521492507,1.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5544741622290155,-31.763243414781456,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.569558684181405,-72.56697158283008,-72.54701841291228 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5705588188686832,-1.5707963267948966,0.9999999999999981 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707704532679767,-73.41412803019374,0.9353521054694421 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267943406,-100.0,0.0625525453944279 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948628,0.0,0.06258838514409432 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948704,-0.1472478879053377,4.5522099189454387E-159 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948806,-37.779595451622306,-0.9398314469147631 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794889,-100.0,0.36222202315714414 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-100.0,1.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-14.451143217931303,-1031.6986950841024 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,1.528267474150741,-0.6292513032028744 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,1.9546227012534791,-7.441508660178637E-9 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,31.78909686746322,-0.060267945931887446 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,44.59154173777635,-77.97908053828478 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-45.40906974733199,1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,51.24013427293704,44.7705083201341 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,-58.194612385771414,-0.04427644065852776 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948912,76.45185362965131,-0.7945183563198926 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794893,-1.5707963267948966,-0.821453599437163 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,0.07203114966473065,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-100.0,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5707963267948957,-0.012405677120957722 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-1.5707963267948966,0.04640289861847831 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,1.5707963267948966,0.9509122094126274 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,1.5707963267948966,82.34345853211272 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-16.479069134485115,1.0 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-34.72508079239552,1.061837054181392 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,38.813106591547744,-1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-53.45076225490332,-56.26125336766807 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-55.38136548813459,1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948948,-92.75272685244764,-10.777305499720896 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948952,-0.49910015328181706,0.0625591523637424 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,0.0,56.92087362559769 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-43.991376090660616,-1.0 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-54.550764351852166,-0.9308853064032035 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948957,-74.93112366159747,-0.06255304147239675 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,31.658545107605082,-0.03377496666996738 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,32.63485956760216,-59.59840830029124 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-32.70620097284822,-1.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794896,-1.5707963267948966,-34.077086230410444 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948961,-93.57022496360497,11.600125726648088 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.5707963267948963,0.0,-1.1270725851789228E-131 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.570796326794896,-53.269226998847145,2052.217846419331 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-1.984053005532076E-4,-2.7730628640909445,0.06255309803518247 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-2.220446049250313E-16,-1.5707963267974885,1.0000002982440392 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-3.552713678800501E-15,19.684995575283,-100.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-5.265198373977931E-4,-40.49693926875737,-0.7371517086819606 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-6.881074804573776E-15,2.3760537697430758E-33,1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,7.060913333941529,-55.11712746183843,0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,-32.55983608897906,-1.0 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-7.105427357601002E-15,44.06051345624033,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-8.881784197001252E-16,-60.74765069514623,-0.6178575244500468 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark11(-100.0,-9.547359512387034E-5,1.5707963267948966,-0.06246029131852171 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark11(-10.01631007052007,-1.3233122128429984,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark11(-100.29247136978533,-0.7225476159316577,1.5707963267948957,5.384441455132761 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark11(-1.0032773455862005,-1.5707963267948961,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark11(-100.3729976323902,-0.23273681983326755,107.65104557090444,0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark11(-10.059815609513851,-0.14559106300286623,19.35390032843742,-15.18534927078133 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark11(-100.61830365235512,-3.552713678800501E-15,-100.0,0.9373356561399362 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark11(-100.69903875679155,-0.4611382932803811,-28.87449237073464,-2288.090338697407 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark11(-100.91992269854121,-1.4617527378519526,-52.07421077817037,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark11(-101.07877399224535,-1.5707963267948912,52.23145008849892,-0.0019297323343947514 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark11(-10.193926091376067,-7.105427357601002E-15,6.967824956918406,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark11(-10.228768108443676,-7.858270435219666E-4,-0.7501931594149758,0.0 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark11(-10.240849062856654,-2.220446049250313E-16,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark11(-10.29891224084946,-1.5707963267948912,-22.51301477681909,0.0 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark11(-10.316833417133216,-1.000966067778629,-4.424010618526683,0.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark11(-10.319480713690451,-0.4474948639004423,57.52715362184609,-1.0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark11(-103.46750110407281,-1.0980053841225903,45.482405806521534,1920.7693013994672 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark11(-10.35486974441758,-1.521975054513172,-9.163975201632526,-1.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark11(-103.55843937258726,-0.633216630106773,-99.55972668786941,-18.824285471193974 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark11(-1.036093509253293,-8.881784197001252E-16,-28.63809322426037,0.9377783807318893 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark11(-1.042168793748825,-1.089417416997167,-1.570796326794897,-1838.861764391342 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark11(-10.423004275842686,-0.9740764198919862,-27.551670584662233,0.7115512092129972 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark11(-10.42849620440175,-0.06244111308017244,-48.86659890306035,-1.0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark11(-10.44880206882533,-1.1682200256902462,-41.75808102923681,-21.63568453651861 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark11(-10.56414460183315,-1.1089109699634307,75.80974491062727,-1.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark11(-1.0573810187146255,-0.41547312681445925,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark11(-10.633129266971718,-1.4097277556940766,-100.0,-1.0000007874919308 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark11(-106.38788726968143,-0.8313286139831906,-1.5707963267948966,48.03064951701353 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark11(-1.0724271072393776,-0.7135612613529246,-1.4674599903328833,-1.0 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark11(-10.864027719699655,-1.5707963267948963,-1.5707963267948966,-12.730594980860408 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark11(-1.0872764648200368,-1.1867639787667852,1.5707963267948966,0.9791836407747951 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark11(-109.12773062445521,-0.13400110497710183,0.0,0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark11(-10.951438171476141,-0.6091256979613888,20.354744656339435,34.46698859162416 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark11(-10.97794286356852,-1.5707963267948961,45.21752981358989,7.895174561146341 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark11(-1.0990608614514432,-0.24463486501705534,-47.51806654281727,5.355500878309229 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark11(-11.002531340622141,-1.4701609057977338,-53.855829635766234,-7.213264545145106E-130 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark11(-11.074880729033609,-0.8824445782456172,-11.319092948826535,-0.9999999999999996 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark11(-11.099040167089997,-0.8404715158597388,-49.69338297350827,0.8071823101367933 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark11(-11.113859720460876,-0.045603255918611064,57.77158568857644,-1.0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark11(-11.14492178065079,-1.570761525130432,7.432564911493297,-0.048054703714910774 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark11(-11.148653489120107,-1.5707963267948912,-18.530958023426198,1.0 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark11(-111.61770449659932,-0.7434568258878457,-0.39098197809416924,-1.0626809233244565 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark11(-11.185055199794768,-0.28028009906026363,-25.78361922557157,74.47987014505566 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark11(-11.215586707961963,-1.5707963267948961,0.0,-49.35579980837471 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark11(-1.1249585893907579,-1.2442820278893123,-130.09201308972928,0.742672823067719 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark11(-1.1281929397608081,-1.3550902184369706,-35.631407868828504,60.05479285194022 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark11(-11.330529459144746,-1.5707963267948948,-33.80688189743308,16.299003029676864 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark11(-11.340127078071774,-1.5707963267948948,-71.41186171049551,93.5791325166114 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark11(-114.00479579165858,-1.170000198184172,-111.45345490153755,0.3211619460952083 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark11(-11.462279728890806,-0.5269148600927038,-36.36606403951057,-0.9240115872184314 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark11(-11.468381854322493,-1.4769380981992892,-15.35771428036673,0.999999999999985 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark11(-1.1486596347688192,-1.4991146960046904,1.5707963267948912,-1.0000000000000009 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark11(-117.85512109992749,-0.2938158519626306,-6.90003973218117,75.08085582672867 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark11(-11.862260250634819,-1.5707963267948961,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark11(-11.869316675302704,-2.12915451807421E-15,-12.621156943123266,1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark11(-11.904790800629796,-0.9272926754875666,0.0,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark11(-11.930581992891831,-1.1634263330485597,-55.744193812064346,0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark11(-11.950723989141308,-0.10232349921676404,-66.38620238974151,1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark11(-11.961569514176254,-1.52961931104366,-100.0,0.28934341975725997 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark11(-12.015348664448187,-0.38075546714846076,1.5707963267948983,-0.0625525297803175 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark11(-120.45590822172997,-1.2393201622768641,-31.598666181018658,1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark11(-12.051603812763332,-0.257567480877841,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark11(-1.2083364397440466,-0.522912121974457,-5.517372894789343,0.8546844741451847 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark11(-12.090468971212198,-0.6712796034291313,-52.58532502763679,66.86633478851556 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark11(-121.95397399527397,-1.0785784929282256,-36.5292790813037,2234.2238297583913 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark11(-12.198675760992487,-1.5707963267948948,0.2508942614263958,-2162.7528371382577 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark11(-12.212106409797762,-1.5707963267948957,0.0,60.11379744928726 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark11(-12.295881386781023,-0.29825492208135723,-3.0063050602752144,-0.3041667274862023 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark11(-12.304918234693147,-7.105427357601002E-15,-93.12101718573406,-0.717307345618263 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark11(-12.330345656484297,-0.09371430913766687,77.81895218961367,-0.010755397948167544 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark11(-123.43818452736494,-0.12868264935040916,0.0,-2129.8504409203438 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark11(-123.6888754927517,-0.7831856068774243,-63.485252235904206,-0.3543148078838154 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark11(-12.372959020732239,-1.1741028402141171,-20.12703058840361,5.36349940459095 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark11(-12.387691441612503,-1.394500187999986,-74.96557343510378,0.529215764284936 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark11(-124.11165245209526,-1.4563647184191475,-100.0,0.9999999999999929 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark11(-12.428998511472159,-0.050228485780920096,45.43561790378379,-0.8519717696012801 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark11(-12.447543815351555,-1.464531733192305,-44.917812763265204,0.7656566763974565 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark11(-12.48174523052602,-0.026203393306678355,0.0,25.19993227862907 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark11(-124.83934608594579,-0.3994318590664916,26.50234027893331,-33.21257975981939 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark11(-1.248478271234462,-1.0996379479635185,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark11(-12.696478824769057,-1.4123439870939751,-0.1514790354463459,1.0 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark11(-12.701461001574131,-0.46215641599620744,-12.872865675254745,-0.012388040713146031 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark11(-12.715894118512722,-1.5544961509943107,-1.5707963267948966,0.841392289513542 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark11(-128.60891053738058,-0.5497926529187653,-7.003713421214857,22.775958368577797 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark11(-1.2861667560728733,-1.3843757085580846,-174.58156747064135,-2.0350731804174274 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark11(-12.967921433751606,-0.09552529655362418,-18.64081338643375,60.50615738110204 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark11(-130.32265418120687,-0.48484195656867773,-1.5707963267948983,-2198.2443681682953 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark11(-130.43968693908536,-1.326258925772392,-70.40668348608628,0.737796740571363 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark11(-1.3073703312996088,-0.908376015376136,-1.5707963267949054,-1.0000000066109136 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark11(-130.7494390716453,-0.9851637193396954,-50.949537045817486,-0.9999999999999982 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark11(-13.079785133561359,-1.5542868663839775,-92.21009435516812,0.06255752364345743 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark11(-131.13087084636746,-1.084944416497343,-86.58317862439281,12.039486781838834 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark11(-13.137104387890256,-1.0912699180095131,95.6068729310156,8.673617379884035E-19 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark11(-131.48236672636457,-0.09954676431562648,-181.73799375691627,-11.748367738656967 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark11(-13.178092471917576,-0.6002420177283481,-1.5707963267948961,-0.45201887379367367 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark11(-13.214652609825123,-0.728625657685396,-88.11324567218908,76.00885770068385 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark11(-13.22272462954406,-1.570796326793829,-78.53003630730399,-2340.066978141033 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark11(-13.236311027632095,-1.5707963267948912,-9.455737363121955,3.552713678800501E-15 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark11(-13.257646485357292,-0.811027336750153,-100.0,0.8968752244258797 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark11(-13.263895266568035,-0.0747257275184551,-21.587259468021827,20.185871104327973 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark11(-13.275167386499408,-0.46848965424399175,0.0,8.484963962482691E-5 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark11(-13.29382247738859,-1.2713548556915546,-70.553500237907,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark11(-13.333443562491109,-1.5524009723018803,0.0,0.013402138963074512 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark11(-1.3355664069803268,-1.5693884002759584,-77.2215099415304,1.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark11(-13.373629040863735,-1.1552170743169452,-3.3850779055580613,-0.007251567348392163 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark11(-13.39267155409623,-7.105427357601002E-15,-44.58932676096939,-1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark11(-13.396473045222848,-0.6896086084631445,-10.581796750953878,-1.0 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark11(-13.408589413655847,-0.9101402857219967,-85.71986013742747,1.0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark11(-13.426380010131638,-0.5766207218427124,1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark11(-13.435368118076436,-0.21137312671091535,0.0,7.7806802623966576 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark11(-134.8018084087205,-0.34683393772543103,-71.66901143595155,2237.3411055590186 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark11(-13.496196567148242,-0.12407556760091043,-68.265797536106,1.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark11(-134.97216967524565,-0.8950780249465993,-44.7228390895817,97.33485293608808 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark11(-13.50040632799832,-0.7502199766243612,-1.5707963267948961,1.0000000007367407 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark11(-1.3558407014827591,-1.3201797556826496,1.5707963267948966,0.5522788490230253 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark11(-135.88667249542192,-1.243582786805793,0.0,2198.4232902653102 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark11(-13.589309443506663,-5.551115123125783E-17,-1.4643020891430434,-1.0 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark11(-13.643910806500514,-0.303927881658403,-10.700349021055118,58.10453549044868 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark11(-137.01342959696592,-1.555175775110385,-98.76118493637863,-2156.890275831254 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark11(-13.703828538651514,-0.6077024967029248,-32.60400833247428,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark11(-137.44274135675732,-1.422122739877139,-55.50891795629643,0.005421290641399444 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark11(-137.74422566937054,-1.5707963267948912,44.8900452713124,-2179.7299045678556 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark11(-13.81646704908973,-1.5597266683607234,-1.5707963267948966,-98.93549523522518 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark11(-13.82446803880103,-1.5707963267948912,1.5707963267948961,14.429627437774684 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark11(-13.897679843698436,-0.05359829732825094,1.3611964764282958,0.0017477430291348343 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark11(-1.391767566838836,-1.2129934244200502,-14.766375102564695,1.000026435007231 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark11(-14.002438211241806,-0.7256628500054455,19.149959875086232,0.028395560394119855 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark11(-14.015588413520994,-1.5707963267948948,1.5707963267948966,66.21056652818902 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark11(-14.020073940015497,-1.5707963267948912,-89.60026843411103,-1.0 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark11(-14.024799318874924,-1.385758871496107,-97.56123356384147,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark11(-141.50156263011255,-0.40577841752426913,-167.93529884651971,0.01866117189203889 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark11(-142.18622032278952,-1.7763568394002505E-15,-53.89042088842176,1.0000000207774784 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark11(-14.270364061511636,-2.220446049250313E-16,-94.12449910363648,-0.784654298103798 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark11(-14.323670110043249,-1.2937836757866807,-14.648484680929016,1.0 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark11(-14.352830149705436,-1.4930418960065328,-91.50104070358083,-0.018741922095410368 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark11(-14.361808631363687,-0.9176261238083523,-7.447184977689915,-1.0000000000000815 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark11(-1.438883811007189,-1.0795200841543475,-2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark11(-14.397272549527074,-7.105427357601002E-15,-27.81311321416051,0 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark11(-14.479000104685426,-1.056053813563059,12.873566265546046,5.003367487225162 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark11(-14.488333381300976,-0.17836474925998402,-9.8103484887661,-0.013252011845736433 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark11(-14.566952980197343,-0.6484213791131845,1.0541031313624853,74.50540275199137 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark11(-14.573657745157087,-1.5707963267948948,-20.22980158986321,-3.151942345495586 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark11(-14.620406409262664,-0.9094056407825294,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark11(-14.64520907924138,-1.5050587516844198,39.211663685044755,-0.9994184649588831 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark11(-14.654631626017405,-8.881784197001252E-16,-87.6162874179113,69.6795529494022 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark11(-14.676109069063756,-1.5642455100301338,-5.9989833181583165,-1.0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark11(-14.708048533835665,-0.2553035956306968,20.387818866612434,0.15258739780208375 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark11(-14.767551318235652,-1.561526902070507,1.5707963267948966,3.097506580160398E-4 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark11(-14.772393209000697,-0.9287476023806767,89.27084719025532,28.506362436346933 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark11(-14.781168994897572,-1.0778144360337016,-64.71215620494928,-0.1379726505176773 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark11(-14.841545043064453,-1.5707963267948912,32.514793304342305,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark11(-14.878901734585256,-0.6680839006480994,1.5707963267948966,-0.9162167486423174 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark11(-14.934248277162647,-1.038776820235854,-100.0,-0.05038763271742899 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark11(-14.966928655945178,-0.6310987611150929,45.217531557007234,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark11(-15.009132715952163,-1.0389534675925916,-21.37887349366487,-1.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark11(-15.016145864583189,-1.0305816016472564,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark11(-15.066349738269508,-41.98078531213396,0,0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark11(-15.109329484962943,-1.5707963267948948,-13.491124072198422,0.620394363353725 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark11(15.160853533946252,6.270086783271253,0,0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark11(-151.65819152689238,-1.0349730425847525,-75.78907579267052,-28.87064476029741 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark11(-1.517243674665,-0.5606582492908216,1.5706289149466697,9.308950924421282E-4 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark11(-1.520432948974045,-0.7216225029578615,45.48999500386901,-30.553901118051975 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark11(-15.218508704404087,-1.3518390786894496,-1.5707963267948983,-62.38960156574481 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark11(-152.3522787254136,-0.038454177910224985,-81.39088198144026,-2319.283119359338 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark11(-152.54083047091518,-1.2714523502901045,88.10583238086413,-2223.260796823104 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark11(-1.5281445122176047,-1.5325681820828359,0.0,1.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark11(-15.342902990878148,-1.5616503965248434,0.7864062717590631,0.7160527941772454 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark11(-15.354530998313635,-0.7639816693415726,64.38583707592905,53.3226995822944 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark11(-15.398369908713534,-0.9521937612895801,-83.69605734292074,-2232.638253750285 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark11(-15.60707324112333,-0.5688589567021832,31.72031721088024,1.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark11(-15.80749771870562,-2.7755575615628914E-17,-26.068370425738326,1.000071156305485 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark11(-1.5816758804560607,-1.5707963267889227,-8.50760641078827,1.0151787197358797 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark11(-1.5823854973209694,-1.3734634029187671,-65.03791152227153,-0.7727077720647995 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark11(-15.833546725487423,-0.020565966947243917,-62.744093486705424,1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark11(-15.850314783019535,-1.1102801771828235,8.072514170360051,-59.55838421077615 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark11(-159.1855324297325,-0.0019244716011144747,0.019276852176215442,-0.9999999999999971 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark11(-16.014122269150107,-1.5707963267948961,-55.68230851577988,-1.3554598198059213 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark11(-16.02856030281731,-0.1998982304647663,-0.01413601975749617,0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark11(-160.7930110369228,-0.36608344605143506,6.489273111327576,30.68115438808502 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark11(-160.8395530509245,-0.8494694436793822,-137.47956707656687,0.7046951080317194 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark11(-16.093769878476436,-1.5707963267948963,-4.382638512627096,-0.06267296962941894 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark11(-16.1175002668167,-1.0520455438290262,0.0,1.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark11(-16.129498449693557,-7.105427357601002E-15,-65.3515435633776,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark11(-1.6132776729400025,-0.6247687239876409,-88.49783406879283,66.45407681459888 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark11(-16.16749477600477,-0.172901079346083,-61.88905618249283,61.89654260585334 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark11(-16.175606557386924,-1.5478008037579816,0.0,1.0 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark11(-16.18350058267081,-0.7018103242322145,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark11(-16.218837310964048,-1.570796326794894,0.0,-56.05331149639827 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark11(-16.232659831086767,-1.4195405922841347,-0.8083060649909068,-0.9582368073357675 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark11(-16.316112460648245,-1.5707963267948961,1.5707963272913543,0 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark11(-163.57804850330697,-0.043250841333692995,1.8563707040250883E-15,-2052.0045419720573 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark11(-16.401894386984026,-1.4961076028051015,-90.10036564712557,-0.9999999999999646 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark11(-16.470898268760127,-1.5707963267948957,-71.51672236863388,0.9442597786527003 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark11(-16.498027958854806,-0.9211337423255614,1.5707963267948966,-0.9788632490097332 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark11(-165.13929169537312,-1.3992126686847695,-40.532036994571634,-1.0080536153928705 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark11(-16.586731143947134,-0.7381371216924606,-123.65981467835701,-0.9999999957736264 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark11(-166.2983425815623,-1.5362862709260898,-1.5707963267948961,2201.055036427565 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark11(-1.66403270756252,-1.0762800427645165,-1.5707963267948966,-46.024135914352485 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark11(-16.673303060950946,-1.570796326794893,-23.37034994512978,1.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark11(-16.728540993782634,-5.984966061912904E-4,0.891013100531917,0.06255476732344482 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark11(-16.73109228288108,-1.4497180334658974,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark11(-16.76637429416224,-0.20388695040642713,0.0,19.775725380357464 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark11(-16.84300051972307,-1.5707963267948948,25.591120997940948,0.47422882489374873 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark11(-16.90247961455446,-0.48440431404002204,14.06669705852451,-0.7300402519272531 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark11(-16.924583312532732,-1.5707963267948912,1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark11(-16.9516246069348,0,0,0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark11(-16.953650202216792,-0.5640667125098033,-54.497783600789525,-1.0000000000000004 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark11(-16.968962537495152,-0.4068650679771497,45.14894510740049,-35.90253132919868 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark11(-17.052637288441996,-0.15169109335077646,-52.3171955369669,-0.9934835866452545 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark11(-17.08771815733017,-1.091846631924734,-1.1980795047651833,-0.5798566301852459 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark11(-17.089625979555393,-0.6741093602957875,-2.752895944653204,0.07943774213253008 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark11(-17.099697685684827,-1.021259304856733,1.5707963267948966,-1.0000000000000104 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark11(-17.12637916726405,-2.7755575615628914E-17,26.55790289328199,1.0000000250636711 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark11(-17.146887703006914,-1.340407215724906,0.0,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark11(-171.60894653051656,-0.007602762505174887,-72.20315929886078,2166.04185258959 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark11(-17.18967421482286,-0.7467492109696645,1.5697536657760236,0.9696335407619365 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark11(-17.240640380680247,-6.944784758400958E-14,-1.5707963267948966,-0.9755286457164152 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark11(-17.24632044862919,-0.04676699460639516,1.5707963267948966,0.7893139417884222 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark11(-17.251923214239266,-0.006446837162201291,32.47808622466953,51.67017564028519 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark11(-17.33928136380743,-1.1515706838109478,-1.4532059998458635,-50.85487826307819 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark11(-17.491605667641295,-1.5707963267948788,-45.860865489095474,75.08102210224553 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark11(-17.539134710407154,-0.018631879319893747,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark11(-17.554753788734583,-1.5707963267948961,-1.5707963267948961,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark11(-17.568993937868605,-1.0670743397833946,-14.34314055403309,1.0652395973654345 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark11(-17.580359387781858,-0.07085084842880686,-63.96775105463679,-3.5273402019181383E-16 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark11(-17.58507278995275,-0.0470136684448923,-66.00876439800864,-0.6367980178502899 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark11(-17.641225887073293,-2.220446049250313E-16,-52.23677408281121,-0.9999999999999991 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark11(-1.7649264382086187,-1.5707963267948957,51.16878971002558,-65.11024901574298 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark11(-17.68860204998144,-1.5707963267948963,-20.492160261216245,1.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark11(-17.756301835347923,-1.17702829772321,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark11(-17.811788616293875,-1.4799792584825988,0.0,1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark11(-17.837905490698894,-0.03400232830530197,-55.116053310656724,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark11(-17.842132160205267,-2574.5963742254994,0,0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark11(-17.858591630489617,-0.7184724922754726,-100.0,-57.549202221304654 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark11(-17.85910346390152,-1.2055604738841952,-9.841602011385948,33.55128987143817 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark11(-17.936414045473924,-0.09122059942857885,0.0,-13.236203117225827 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark11(-1.8023475567878045,-1.3941509310411808,-14.669085761020291,-0.26094473484541886 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark11(-18.030112227857757,-0.03155422360440441,-83.13672725180328,1.0 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark11(-18.13291701016702,-1.1654496752823165,0.3295142928047877,-74.13320460220531 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark11(-18.151605025152527,-0.9069466206561029,-53.40973118423085,-1.0 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark11(-1.8172808390565363,-0.6725636331464809,-29.975052312325843,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark11(-18.209812867048612,-0.22015991149817166,-83.66276880313707,-1.0633594234825352 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark11(-18.24245295105656,-0.039052974784511196,-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark11(-18.249403082950522,-0.03481096749259574,6.886873279773364,0.007242187308316359 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark11(-18.251566932048892,-1.2470287916835057,-73.37354917942793,28.133819694166988 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark11(-182.66167205341918,-0.5281571813890085,38.991933475297444,-34.86370527931566 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark11(-18.294877231591308,-1.3501386181950266,-62.09639475378872,-1.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark11(-18.306752986044568,-0.028678595237772886,-80.24422058980576,-1.0000020554144053 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark11(-18.317422660848706,-1.2614710080800897,82.12991694079801,1.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark11(-18.357246620082236,-1.2202023744014536,-49.68172635201347,1.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark11(-18.369623295244295,-1.002054851608781,0.0,-41.16101702776112 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark11(-18.43698558146865,-0.1481093218719991,-94.60143553467324,0.08700081113041869 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark11(-18.47834277690879,-0.10351007424142722,-44.00290850581875,1.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark11(-18.483682949862242,-1.5707963267942695,0.0,-1.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark11(-18.512795698776632,-0.023628989735394457,-34.0025692252382,1.0 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark11(-18.525953312429127,-1.239793016215825,-36.450796348816134,-1.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark11(-18.621890438970976,-1.5368610298439263,1.2964148336218355,-1.0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark11(-18.64803769086565,-0.7084077842394585,-10.996591162719227,-1.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark11(-18.65266155714479,-0.009114958481176508,39.15206960025785,1.0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark11(-18.66532621535118,-0.599823836730054,-14.42965630091318,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark11(-18.666126891131782,-0.49261054557144845,-56.35308120756909,-1.0 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark11(-18.699003316842024,-0.00924747106425806,82.17229890649728,-0.31258298624455694 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark11(-18.700565649585798,-3.554927534565957E-15,38.709912791920665,-0.5955707665934671 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark11(-18.725718699351873,-1.5707963267948961,-29.860133359187163,46.679420228817406 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark11(-188.62396661288975,-1.4731990902481265,38.39814633056051,-0.9999999999999964 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark11(-18.884583004579554,-1.037471927335739,-95.82520098051184,1.0000000000000036 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark11(-18.903914165496786,-1.5707963267948895,-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark11(-18.94795634472441,-0.5695389655894685,88.33989562867515,-1.0 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark11(-190.03911850341834,-0.43143090054767,-1.5707963267948966,74.01856488976725 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark11(-19.053429883437502,-0.43278538705567193,-37.58057771450041,27.07970400315392 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark11(-19.093233067812562,-0.0075041267176883504,-27.524739471913932,-16.016707735486023 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark11(-19.11674528223692,-0.5131929504166592,0.0,0 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark11(-19.11727627547364,-2.3657622354860034E-16,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark11(-19.133991726981108,-0.7330707780601387,-56.77616117192767,-82.27342964308346 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark11(-1.9170694693118282,-0.6922110866806882,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark11(-1.9244268532950617,-1.5707963267948948,-21.50102992310829,-1.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark11(-192.48612518845985,-0.9218588644541212,-72.38824762371782,100.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark11(-19.25655942825169,-1.5707963267948912,-7.324164470904364,-15.319424445532363 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark11(-1.9293111789675002,-0.6264134867696729,-44.45211428683436,-0.005991359752945069 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark11(-19.303694463310855,-0.29261261602301286,-31.962014850648192,-76.4188438073605 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark11(-19.32433426603232,-0.9375373586558042,-67.22132408956516,0.509264093713433 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark11(-19.341375788973004,-0.05857938431330445,-0.1579934832401877,-1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark11(-19.38211765444485,-1.3360428033664085,0.47914342905919827,0.7028508731245421 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark11(-19.408982920360415,-0.41811882863175565,0.19761308972310843,0.7416219919061726 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark11(-194.60819385877005,-1.5707963267948841,-84.43729162454561,1825.4635176387637 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark11(-19.56436652673553,-1.0595494792582858,38.82911556882028,1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark11(-19.661129457369448,-0.027895007065555033,-78.07394341743681,60.83022317284818 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark11(-19.670539483024317,-1.5707963267948948,12.696762437856062,10.53795695359912 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark11(-1.9761878548900553,-0.9886980978360933,0.0,0.9963888074907431 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark11(-198.46044575226964,-0.21035758383018516,76.24612047212636,0.18783824541667826 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark11(-19.885589978540708,-1.5707963267948912,12.860553684778921,-8.532209372742997 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark11(-19.88700652531187,-3.706012736757395E-17,59.141462781501765,-0.5042953188826006 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark11(-19.949910984651876,-0.37429922742865385,38.8621049965569,1.0 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark11(-19.983398176540128,-0.8077384558323989,95.12800639662811,-1.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark11(-20.041024967528163,-0.8555029388130093,0.10173418341173594,-0.9410691568784819 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark11(-2.0041732652910373,-1.5707963267948948,-54.972081345293276,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark11(-20.053147975320975,-0.6366512742328041,-11.361710750974211,0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark11(-20.05919572636983,-0.5588209045759229,-81.4084956802714,0.5993271568881888 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark11(-20.14173759234303,-1.5707963267948877,1.5707963267948966,53.8318260988504 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark11(-20.1863225230654,-0.9111435812902187,-100.0,32.27969367359802 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark11(-20.204557456730782,-0.37798940896942956,-78.27097894655179,-0.8817265387377451 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark11(-20.366532001735894,-0.011771365707168663,82.61527013956393,-1.0005811411550554 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark11(-20.36792338188847,-0.6974959018157278,45.29467737821881,1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark11(-2.037460900917722,-0.5214464478624592,-31.82394646739273,13.822436935599114 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark11(-20.388618779697058,-1.5707963267948963,1.0608258410559488,0.5077992270513558 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark11(-20.401929302699504,-0.09677448352592236,-36.33760360526497,-0.05659017442004631 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark11(-20.43821567134158,-0.9567612997284901,1.4483315158522836,0.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark11(-20.457629896201077,-0.35280721818594896,1.1469869004245516,1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark11(-20.49186926193313,-0.780348477817257,1.5707963267948966,-0.5825366270682285 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark11(-20.519758426731592,-1.568136732782775,38.576032663129816,0.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark11(-20.528418027139622,-0.24936404297309855,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark11(-20.59788498522236,-1.027297490026466,1.406343438234929,0 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark11(-20.67587837953017,-0.7596809904205735,-29.40318245297646,0.0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark11(-20.73638620350988,-1.1548060498426032,32.486648710233,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark11(-20.737965117829894,-1.5707963267948912,89.29733565458382,1.0440487148797639E-53 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark11(-2.07850418226932,-0.5443541107531863,76.56105918538793,-70.16367631302296 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark11(20.831876666710244,46.701667493535865,48.655487497195935,0 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark11(-20.850397345131036,-1.4180284040414954,-10.63047522336376,-3.837372737263659E-16 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark11(-2.093728162635977,-1.095042616994147,-20.892619672239856,1.0000080806994431 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark11(-20.989897281743474,-0.030550186217614437,-90.1316153117961,0.9999999999999974 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark11(-21.076054197183293,-0.6568386550572168,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark11(-21.0925646911662,-0.17756043826555779,1.47894626984102,-0.836025872893635 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark11(-21.149141981332363,-1.3708067451595194,0.0,-1.0 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark11(-21.221042357012166,-0.5779527395981453,89.12331401379771,1.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark11(-21.253133283533785,-1.4148850126348183,-5.023166348119245,1.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark11(-21.320846327518368,-1.4230306516729456,-21.82092985314045,1.0 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark11(-21.328441148835417,-0.027995257280161206,-1.5468429581109069,0.15356515627426126 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark11(-21.365879466698413,-0.8762307363216263,13.027773047621352,-73.40325757600021 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark11(-21.379061785215058,-0.3407827410705242,-5.128767529707192,2083.1379677870436 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark11(-21.386705528671932,-1.612179408195041E-15,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark11(-21.38999329858109,-1.5707963267948912,-73.61592865299951,-1.0000000000000036 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark11(-2.14313031786045,-0.3348882166166913,-31.269758653316586,1.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark11(-21.462764428154422,-0.46056714142188326,-94.92208124808052,19.022601281644228 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark11(-21.46602380835599,-0.26952277881792464,31.68120139332091,1.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark11(-21.477701925009068,-0.03260275145824299,0.09147502461071164,1.0 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark11(-21.507451170744723,-1.4607706840739065,-82.58957598964982,-0.06386745360406326 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark11(-2.151325517624201,-0.533399907090587,-53.94577547017322,1.0 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark11(-21.527137935808447,-0.7651123244616261,64.31945206820185,-1.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark11(-21.529991563269455,-0.6490199159149016,-65.03482572341952,6.911528576325267 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark11(-21.549909715383894,-1.1970064740923032,-23.848692896185923,1.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark11(-21.59312030690452,-0.967491355398938,-86.59198772181838,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark11(-2.164051218565305,-2.220446049250313E-16,-1.5707963267948957,81.87939891864619 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark11(-21.657649888858195,-7.105427357601002E-15,-163.4826020727448,1.000024602415477 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark11(-2.1671564124607197,-1.4743996142059514,4.984986497323137E-16,-67.45811650068627 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark11(-21.68217581625401,-1.432781862788091,-39.83321730726494,-100.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark11(-21.791533297121497,-0.8766977233845069,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark11(-21.805933347620353,-1.4164854007528325,-38.03122183432354,-0.04477198622778807 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark11(-21.831774376191703,-1.5707963267948963,-0.6562367096454977,46.23767176562694 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark11(-21.85757827330858,-0.02475573742438247,0.0,-0.14541940780478368 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark11(-21.941544223295395,-0.09231370177699928,-1.5707991662832737,0 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark11(-22.04853671931521,-1.3035036361301318,-39.16922870280233,-0.025891946203758787 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark11(-22.093986278492714,-0.05365057542209373,-42.94178024840326,0.05969015287296875 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark11(-22.095213915210756,-0.09438957262140316,-67.78135777727918,0.3976595851571405 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark11(-22.11380882694712,-1.1419505272323534,-100.0,-1.0 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark11(-22.150265837651464,-0.8956567395547338,-76.80865427049972,-0.013394047325236608 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark11(-22.179261765290573,-1.5707963267948912,-0.7985940137730345,78.69207895854004 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark11(-22.185191988227473,-1.5707963267948948,0.8238175543931363,-1.0000000000000009 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark11(-22.221204691799073,-0.5113206617319288,-101.92909659622484,-1.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark11(-22.2498656184697,-0.1517901223729048,-1.5707963267948983,48.64442824463055 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark11(-2.23742471421523,-1.2378523557924503,-1.111817683858159,0.1961058916438999 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark11(-22.42761368423149,-0.9505957381317636,0.3587783438060952,-85.95722680796412 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark11(-22.46746074367742,-1.1490703802777247E-16,0.0,1.0 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark11(-22.481672728813777,-1.1912534944670057,-1.5707963267948966,-15.820970894955558 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark11(-22.489483486946583,-1.4226773032043898,-67.30043801684228,0.31118307421665303 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark11(-22.49534504076363,-0.7788184667994028,32.72988510351779,1.000666755599151 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark11(-22.54954791174824,-1.2381678203574555,32.612373809274125,0.05188677448326104 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark11(-22.608505669663174,-8.881784197001252E-16,1.5707963267948966,78.55079161663551 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark11(-22.618439362944365,-0.3194057845986058,-77.60329198641871,0.7438511584395334 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark11(-22.650283174743716,-1.3729656085692168,-45.43966903993614,-0.05177729590934774 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark11(-22.685421078622333,-1.3005032884183225,-83.98197230604777,-0.025505268977760256 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark11(-22.68920375390054,-0.7829505502309306,-56.45754178194292,75.77839505221745 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark11(-22.721284822846542,-0.5205005946154108,-45.92512284395534,-0.7140964531255622 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark11(-2.2816876210046177,-1.1755655849623947,-87.13663056103093,62.256287387216844 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark11(-2.287652610804173,-1.5707963267948912,-65.47965897429056,-76.63473936948046 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark11(-22.90000994476361,-0.08466305395619195,1.5707963267948966,4.915539291606763 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark11(-22.935477003922244,-0.8087568643278557,-11.807132272413934,-1.0 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark11(-22.950095388443785,-1.537539072279083,-78.96742602555528,-1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark11(-2.2950760619468222,-0.5557424773430476,-4.275674020865665,0.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark11(-23.00982775363269,-0.205161096603528,-47.58550000654843,1.0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark11(-23.01834256291196,-0.646763065009992,38.07030591406536,-1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark11(-23.018568857295946,-0.5372503683000296,-81.12306346918947,-31.863519083520814 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark11(-23.036133859257184,-1.0622601430975944,-39.13616204855017,50.05246719530916 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark11(-23.100649954825556,-1.5707963267948912,-1.5707963267948966,-92.72522593547093 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark11(-23.11567551449277,-0.027103130471046896,-49.25569573075489,-60.78371450850378 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark11(-23.149807610537678,-1.353055140036439,-32.58134666564722,18.941793449999622 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark11(-23.166395301941208,-1.5707963267948912,-38.945743509223085,-0.9999999999999974 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark11(-23.232287495792765,-1.5707963267948961,0.8520492022056496,1.734723475976807E-18 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark11(-23.23317872801529,-1.4525225097454757,-21.850890957759894,1.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark11(-2.323726343328463,-1.4221416953341868,-44.95538407137944,-1.0 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark11(-23.262969278256246,-0.13126102747156077,-97.51176435947282,-1.0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark11(23.264609577355316,-66.03706933563979,-92.6001435867214,0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark11(-23.316951872575288,-0.49586390686871107,-67.51693972795434,21.178761930446072 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark11(-23.340301025172856,-0.9816297253885797,1.5707963267948957,0.8662482763678386 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark11(-2.3351032979695985,-0.07314595172002036,-7.7890369035251155,0.8147468137602489 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark11(-23.388979336730085,-1.4870525688167118,1.5707963267948966,-0.7162915330646448 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark11(-23.411131809290474,-0.0069190425790870685,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark11(-23.50395211525698,-1.4874130184421546,0.2781553059840771,-1.0 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark11(-23.51765404037662,-1.5707963267948948,-3.1787336409963913,0.9994453774903717 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark11(-2.352788160157041,-0.14906058396563493,45.35897955673837,-1.0000000457231948 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark11(-23.55147256135831,-1.5707963267948948,-73.62996693651131,-1.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark11(-23.604101368211552,-1.28894789111966,-6.306644261712286,1.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark11(-2.363011301728231,-1.4408520963076925,-38.86515566969916,1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark11(-2.366789244584613,-0.5542172769489867,-0.5920628785279187,5.421010862427522E-20 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark11(-2.378796090310927,-0.09392632703820425,-85.28134735578992,0.9913292689774096 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark11(-23.88137189559481,-0.14948780715272916,-37.843712159237214,-1.0 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark11(-23.88831358791923,-1.3307495963073972,-1.5707963267948966,0.3636003433716985 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark11(-23.922477338251376,-1.5707963267948963,-23.814961581238464,-48.74498219888539 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark11(-23.952931708193592,-1.3397421948802894,45.47737441843101,-0.05936534275266547 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark11(-24.03066180633411,-1.1206434885514738,26.407382030535217,-1.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark11(-24.040532774751867,-1.0931100163681069E-4,-27.87184702565246,1.0 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark11(-2.406778944053623,-1.0440984724924267,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark11(-24.096015262668615,-0.1858138557846587,-46.87186561881365,-1.0 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark11(-24.12805789742089,-0.3789894720008049,-0.0011825945738028287,0.332128571045554 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark11(-24.153953152642647,-1.5707963267948963,1.544213245207585,-34.49821480139204 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark11(-24.15580716708285,-0.963234934732824,-56.04035224736514,-0.6833261142888873 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark11(-24.184373028678966,-0.8674015570617083,1.247934298618491,-0.9497600600872816 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark11(-24.25431053939705,-0.9411302578618301,-0.30563662399121105,-0.9698310686308256 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark11(-24.27576003067949,-1.5707963267948963,-1.5707963267948966,0.430855057795023 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark11(-24.311725425291996,-1.5707963267948963,1.5707963267948966,-0.9999999999999994 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark11(-24.336080469807847,-4.440892098500626E-16,-44.11474476238991,0.07661105611043739 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark11(-24.493542961783845,-1.8960535477100838E-15,1.5707963267948966,1.4964607795435602E-16 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark11(-24.499621004401934,-1.5707963267948957,1.5707963267948983,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark11(-24.500459081263088,-1.2535039248628528,1.7763568394002505E-15,0.014845445842999688 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark11(-24.526658319410984,-0.9894358030024575,-1.5707963267948966,-0.9978028236321462 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark11(-24.56162957960286,-0.019858000860287005,-87.16376528974615,0.036102609958345105 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark11(-2.459482750306364,-0.3078299857479987,38.65992504810342,0.42941803603373696 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark11(-24.612628111718404,-1.484919068267132,-67.58206138144934,50.42249324967378 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark11(-24.656078079228834,-1.1087070722952896,-83.72013238283088,0.9824898695676445 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark11(-24.71455620293466,-0.26810636213284855,-75.19729575315752,1.0359786374837228 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark11(-24.770119386504035,-1.3903555718712242,7.918994069120917,80.18461742678343 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark11(-24.778326247379166,-1.5707963267948912,-65.98210794397819,0.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark11(-24.819207431242134,-1.5707963267948912,-110.72528030558783,-0.5431803930553555 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark11(-24.927391763428517,-1.3213912179734737,0.0,1.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark11(-24.974594655521173,-0.5274278398234209,69.75063612804121,2115.6815225022456 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark11(-25.018273981112873,-6.533083398027585E-4,-71.79510948933037,0 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark11(-25.077142484843943,-1.2616192145779805,-39.04344500575368,-0.9381318649598507 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark11(-25.129674217601462,-1.0918895161779947,163.48137646306998,-28.55257065379773 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark11(-25.131443495735283,-1.3660886929494285,-53.14528582135183,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark11(-25.170634217150184,-1.0231200593617582,-82.72799717347192,17.82580882600114 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark11(-25.20137895987459,-0.5073001786810591,0.4001420607968921,-1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark11(-25.32650808882213,-0.4007355881038308,-37.943184402526605,-5.397605346934028E-79 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark11(-25.406571647939515,-9.720687267349752E-18,-1.5707963267948966,-0.5158256148434931 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark11(-25.445677334090767,-1.0651179336060366,-28.240689424675807,-0.842714667090523 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark11(-25.465998694150237,-3.552713678800501E-15,-56.29101547884719,-0.9644816088037316 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark11(-25.470202808787732,-1.258611349702618,-0.6810436538696094,51.906026157409855 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark11(-25.516928086864098,-0.24917692569549477,-15.168036741700533,-68.03085863571037 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark11(-25.58707199554224,-0.21759185769634803,0.0,0.7328509530635576 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark11(-25.596151608210455,-0.5672829035684257,32.725327223024344,-0.710586797576288 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark11(-25.63981981397127,-1.5707963267948963,-70.11201377741378,0.21700479836961228 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark11(-25.65323887666702,-1.5707963267948957,0.0,-97.6716320134121 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark11(-25.662566134940477,-4.440892098500626E-16,1.5707963267948966,-85.56084833716768 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark11(-25.67055193312946,-0.9660679538088042,-27.994744730170183,73.45371211879409 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark11(-25.706250282804593,-0.3841512782580973,76.30062380186337,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark11(-25.723217096562067,-0.2587529619178192,-39.845726525647976,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark11(-25.726517691821602,-0.32707439723289133,-43.42842258729414,1.0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark11(-25.77900863023353,-0.06501506081545165,-0.7656856369386382,-0.06149235813521799 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark11(-25.830732519641305,-0.15522820563681172,0.2990100198364618,0.048431397925788114 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark11(-25.84773658859867,-0.7988484149677664,-27.45856708842162,-0.2416303173385277 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark11(-2.5860514145066418,-0.27910416033307944,0.17353783820543023,-0.9632652729675252 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark11(-25.888555480533903,-0.3010634012171565,-3.4958285016305464,-1.0 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark11(-25.911045503068493,-0.25243417186932415,-53.73930808542763,-1.0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark11(-25.913931732032722,-1.3733827741595888,-57.27003331108688,-10.40330629196529 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark11(-2.595625185933585,-0.31588930936581705,-9.30910768099406,1.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark11(-25.967056711216344,-0.09222390722823692,0.7584299494737805,-0.35534921080861936 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark11(-26.028943183566266,-0.3733771297216483,-1.5707963267949054,0.9398699848497201 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark11(-26.067260348203792,-1.3565505073022317,0.05064593478900123,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark11(-26.0889605622162,-1.4867971856662179,-1.5707963267948966,-1.0000000002083027 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark11(-26.193993343166838,-1.5707963267948948,-46.586417559005454,1.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark11(-26.24440581636621,-0.7997199493994582,-32.817652328720584,-31.166719188161068 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark11(-2.630520903230323,-0.9068078521826664,37.86245825312781,-0.6989752570965593 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark11(-26.3287993152074,-0.9674916749633389,32.93448872274829,-1.0 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark11(-26.36862865866039,-0.479552903249741,0.9063207893862326,21.676240076708105 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark11(-26.462151917141313,-1.5707963267948912,-3.2506677680258633,-1.0 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark11(-26.47359793324877,-3.552713678800501E-15,-41.39651652697194,-0.9939384278227021 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark11(-26.51515559059724,-0.4955185356689189,1.5707963267948966,-52.057782200483665 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark11(-26.555058967195016,-1.5116507931259424,-91.76996648666353,-72.07874634972868 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark11(-26.565132708345857,14.467394117934887,-100.0,0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark11(-26.593626645345154,-81.43070207130197,-88.33992982586582,0 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark11(-26.611655807127583,-0.9382083612174041,1.2647160597747105,-0.030383460759084047 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark11(-26.628766626299342,-1.3789699953054315,-0.31391663273589226,-0.03282792734087764 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark11(-26.722705707072567,-1.4574217145848842,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark11(-26.728975228479257,-1.0723712296527665,50.952576493181766,1.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark11(-26.744878368625713,-1.234233362498224,-52.39144456436205,35.833689241310864 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark11(-26.80728028420856,-1.5707963267948912,-43.64853603507639,50.152843001610165 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark11(-26.88596852333754,-1.343719617197683,-34.21523582176694,1.0000000411328345 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark11(-2.688811278925048,-0.009118875197092488,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark11(-26.898719390489404,-0.8961453868675215,0.0,1.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark11(-26.90867894471535,-1.1730023681085546,-83.41489138188729,0.28815176379497587 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark11(-26.98478949581336,-1.4847143405792371,21.076408838404923,-2125.7687471205195 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark11(-27.061462660884427,-1.5579832537839726,1.5707963267948966,1.0000000000000009 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark11(-27.10722773508941,-0.3828314682441015,-70.97943709694499,0.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark11(-2.7109713202278405,-1.3577859447427723,-4.180254526919384,1.0000000000000002 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark11(-27.194874986286408,-1.0646982604736692,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark11(-27.202162106322803,-1.5707963267948912,-66.04736666545446,-1.0 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark11(-27.210059273557107,-0.38008582096240867,-1.5707963267948983,0.03563760621652967 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark11(-27.235132940391956,-0.6159666141348462,-40.47381251330873,-45.30423338051166 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark11(-27.253568427115514,-1.5707963267948963,-0.8456702153972486,-45.61684515143128 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark11(-27.28082688813866,-1.0532354765967162,-15.240138381800612,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark11(-27.304297685743563,-1.5707963267948766,-30.109136344304332,-0.8482806331179549 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark11(-27.436046781242325,-0.48444271573958364,-95.87405472094036,1.0 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark11(-27.43802454730198,-1.139617135506352,-1.7752641062482215,-0.5735559762161567 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark11(-27.545191493496105,-1.5707963267948957,-38.70864752274494,-1.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark11(-27.564317354720593,-1.5080039246285406,0.0,-0.08189877946724901 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark11(-27.567662603017993,-1.5707963267948912,-1.9587791801211978,-12.417418314921335 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark11(-27.59080499779679,-0.19520161718512014,-29.05544713101392,-1.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark11(-27.598627477421147,-1.0459630770792903,-67.10548719394977,-0.05933171171844742 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark11(-27.598890441760204,-0.26248629247567684,0.0,38.03994909803146 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark11(-27.651011815410385,-0.27378930774993193,-71.48430840712912,-1.0648069347617384 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark11(-27.662008521265,-1.4665987342582048,-17.90944605305829,-6.852844003427549 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark11(-27.70076709718282,-0.018205751931473897,-32.66904153046823,1.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark11(-27.70235833599679,-6.4497930774098655E-6,-25.27022672026191,0.37280197183980673 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark11(-27.705647634101965,-1.7763568394002505E-15,-41.468553460361555,-0.007324216060164701 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark11(-27.73611176254923,-0.6456301139342768,-17.790944536018685,97.25703222211783 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark11(-27.736804421002553,-1.230512178606236,-52.651780631209284,1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark11(-27.76896502688043,-1.5707963267948957,-1.5707963267948966,76.4294482929769 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark11(-27.77004566691882,-0.019269357985884403,-69.97202057804395,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark11(-27.86517937292279,-0.961587690701205,-44.107869771246776,1.0000000018547075 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark11(-27.87919680549597,-1.5634763712316884,-1.5619121840641856,-0.0019139527319097793 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark11(-27.9709766507167,-0.0035962831102675508,-75.42634847496818,-7.259673628932399E-5 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark11(-28.017747989732786,-0.3167208464511855,32.62928645250066,-1.0 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark11(-28.092758131631616,-0.8624430274351851,1.46896258407648,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark11(-2.812075172679755,-1.5707963267948912,-0.049104223211896225,-1.1229160133180613 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark11(-28.12290930801034,-1.2251706775106679,4.440892098500626E-16,-98.44897528698228 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark11(-28.16209743120494,-0.5013816374908497,0.0,13.119184039176616 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark11(-28.183875550630333,-1.552369723296736,-73.80221841615096,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark11(-28.193759480660006,-2644.135168676816,0,0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark11(-28.237089367790343,-1.5707963267948952,44.727479692873295,0.9999999999999996 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark11(-28.293398643523844,-0.005445498657716742,-73.41757027682853,-0.2975713886121152 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark11(-28.314862829555338,-1.384984803356426,-99.29991416138672,-98.02247262099254 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark11(-28.388537757095808,-1.229577590754622,-4.11000692237435,0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark11(-28.40865888755637,-1.254696660608201,-53.75066647374247,35.362648311465605 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark11(-28.408769670352655,-1.0944033018814348,-38.775393684652904,0.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark11(-28.43089420803964,-0.0029430032100612458,2404.2931500915547,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark11(-28.455257578934308,-0.7443483381902082,-49.84536330398989,-1.0 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark11(-2.8455360926825004,-0.6797240410904091,-37.78004430664924,5.147557589468029E-85 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark11(-28.47596868083872,-0.6346182896310895,-17.39559356179825,45.64358868743929 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark11(-28.51145241976003,-1.4710942604916513,83.0619113871511,4.971752869986369 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark11(-28.51808778981654,-1.570796326794896,-0.1399448460721221,-28.17441777556701 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark11(-28.603804855308315,-1.5707963267948961,-44.2924740709706,-1.0 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark11(-28.60777723960136,-1.3235762747501028,-0.05002274711280025,-31.336489461715875 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark11(-28.622948848982443,-1.2414126626981137,0.0,14.19692327417421 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark11(-28.672200802421457,-0.5865184376961707,-86.82516481045856,-69.62762980027269 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark11(-2.8709154931831016,-1.570666517657813,1.570796326794897,-1.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark11(-28.773815178274212,-0.24549234299047856,-35.27839812236276,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark11(-28.818775994597527,-0.20966048518823935,-49.83947382168274,-1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark11(-28.88088214196349,-1.0256888327514773,76.23434567107175,-1.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark11(-28.885856237590865,-1.5707963267948948,-9.96448519975823,1.029968498765157 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark11(-28.945032479584054,-1.5707963267948846,1.4532647648162038,-4.887414293266366E-15 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark11(-28.948170826173218,-0.6209014703059701,0.24179318037120634,1.0 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark11(-28.95847295667056,-1.3999592997049652,-1.321664184283768,53.89199138240505 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark11(-29.010369882537372,-0.042422545280602186,1.5707963267948966,-3.422668758663642 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark11(-29.052923454499705,-0.057423297893187154,-14.730315449704701,-0.9882594477792094 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark11(-29.111248956921784,-0.2590293677183272,-68.17356722912481,94.39390481466057 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark11(-29.11848412585836,-0.43083562427966715,-69.39170837812101,11.963193980847008 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark11(-29.119910570823897,-1.4392020332659667,-46.68006950927143,-0.5742938769490546 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark11(-2.9190606520747546,-1.5707963267948628,-2.97375287172207,1.0294500624373608 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark11(-29.197951665196925,-0.09752066599413362,-1.2531700390696727,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark11(-29.225694198718077,-1.2427416203858364,-97.76827950583699,1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark11(-29.29506175852076,-0.5840632163477366,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark11(-29.31412565153992,-1.7763568394002505E-15,-34.205414376502645,0.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark11(-29.388310132635198,-1.3408301939931553,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark11(-2.944069227946888,-0.3569355367684695,-78.8640786353964,-89.63059751104088 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark11(-29.456291565472576,-1.5707963267948963,-4.151952921084284,-0.20733087250039045 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark11(-29.560725812067844,-1.5301997029776582,1.5707963267948966,0.17283083362077756 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark11(-29.577925830165793,-0.48663351569460384,-1.5707963267949048,-0.058074826715504166 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark11(-2.958208110845991,-1.5455797447952326,-1.5684607283732703,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark11(-29.603108065797315,-1.397800388132552,95.33327821425041,1.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark11(-29.646732097633095,-0.36042569695859317,8.060897405709525,-9.788507884545552 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark11(-29.676490024552272,-0.3086852484280854,-56.522637357086566,0 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark11(-29.741830875863734,-0.27982220827485627,32.684072741833575,-55.138747085061325 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark11(-29.845843617644697,-1.4885106423550234,0.0,-0.42752191030046044 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark11(-2.9887711767812633,-0.8540137865848973,0,0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark11(-29.9598557018796,-0.22174797132062588,1.2529509751047547,1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark11(-29.963774300687774,-0.39140791830011196,44.04491644263942,-1.778206999588062E-161 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark11(-2.9969290534303026,-1.5624177544264004,31.80537577533108,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark11(-2.999010034790804,-0.35667658553850284,0.12437140898924134,-64.81310678499146 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark11(-30.026850242339037,-0.0734636978383087,-1.407203294238373,-1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark11(-30.11572974716082,-0.5913788747140662,1.152239292305033,1.0 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark11(-30.130677384411868,-1.007179562358235,-24.846922722584225,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark11(-30.16516678810508,-0.4332850315204668,45.08246137446656,51.29540136517549 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark11(-30.186201224637557,-0.11395491366256366,19.989875451528196,0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark11(-3.019774591077675,-1.5707963267948963,-1.5707963267948966,-0.06024641575376791 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark11(-30.255754994464823,-0.9750227577112166,-16.755256527179842,51.07333608623937 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark11(-30.25866104667037,-1.5490881420197974E-31,0.6088064723562977,-1.0250665447337477E-143 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark11(-30.30193835031433,-1.5707963267948948,-14.29682344303913,-44.235049329756926 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark11(-30.32590686895891,-1.570796326794678,-45.179370995961236,-0.3407628767672861 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark11(-30.349214186401866,-1.876396837143425E-16,0.6206238327152536,1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark11(-30.364247893672385,-0.04167956653070195,-56.413829954150714,-93.837609989311 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark11(-30.378994164422256,-0.7438894812220287,0.0,62.25904215234927 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark11(-30.39735603401111,-0.7717202849673725,-34.12533671799753,-0.9221086279175918 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark11(-3.043784105723617,-1.5707963267948892,-0.6698623798010522,-0.9999999999999991 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark11(-3.0506033582206227,-0.6085024887841901,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark11(-30.546510898099935,-1.5707963267948912,-84.31895810624859,88.27893277192265 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark11(-3.0562493089346816,-0.6269087149565138,-134.66705217436012,-13.134923558050858 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark11(-30.57645708708834,-0.5308791171948801,-4.707453056348374,-1.0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark11(-30.61519341305629,-4.440892098500626E-16,-95.76974839425806,88.52376906147884 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark11(-3.062787865718086,-1.415339988884913,-93.17718319389209,-54.98403070351105 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark11(-30.751709733448365,-0.45116992466385236,-64.00135732541418,-1.0 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark11(-30.761620510943835,-1.5707963267948952,37.836373376559486,-60.222472093137895 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark11(-30.77218240459031,-0.8417789282875278,13.053798113091403,0.9978005967434705 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark11(-30.81434795729971,-0.13790259506458385,-1.5707963267948966,0.6018774465333527 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark11(-30.853564692986094,-0.3249756534324004,-43.46118527479661,-0.6984768857672785 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark11(-30.938431659770934,-1.1652607341926056,-18.923536921870557,-13.507701220535552 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark11(-31.01660218775183,-0.5522504036883813,-1.6293007428686224,-26.45109074959511 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark11(-31.065815629805947,-1.5707963267948963,-10.993671664494542,-32.34847703763954 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark11(-31.078659423637944,-7.105427357601002E-15,38.74658583946277,57.11615273337376 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark11(-31.087951788375825,-0.4385675626394201,52.95611333219517,-0.5564412238827916 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark11(-31.204361096700726,-1.0764538145635283,-0.6447172466134824,-10.199482405900929 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark11(-31.274041839249975,-1.5707963267948344,-4.078779764555037,-19.311072408973473 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark11(-31.32233495059893,-1.024389519981166,1.5707963267948966,5.361766740091326 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark11(-31.40138449306089,-1.3118364108859435,90.2384357760119,-1.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark11(-3.143433560762389,-0.16849381160539856,-73.53565575408001,75.22983471118948 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark11(-31.501307869338543,-1.5355503351518165,39.17823173272755,1.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark11(-31.57918649858705,-0.05809294430085199,-34.89761442185725,-1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark11(-31.623486247481836,-0.021104329557001977,0.0,0.7685487593798078 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark11(-31.638223647187928,-0.269217676714945,0.40321028397527314,0.35114298309525793 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark11(-31.72875521096637,-0.44801623261312123,71.70942917561081,-1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark11(-31.741378012621276,-0.7276702241337929,-11.667597840273297,0.11062854718784143 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark11(-31.823510136851475,-1.5707963267948957,-1.1372599614910663,46.0377244314782 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark11(-31.84763246523088,-0.8546143603927157,21.032316838676252,-1.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark11(-31.887545151436697,-8.881784197001252E-16,0.18359561139770464,0.8596372862361585 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark11(-31.911198204568752,-1.487012519296021,62.874053774909804,0.2365385481395723 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark11(-3.1957294101411513,-0.04381544558200297,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark11(-31.973046813955772,-0.16634785434786492,31.929215712457907,-32.842030497337454 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark11(-31.975269042013394,-0.7059310613898099,-31.93551658093249,1.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark11(-31.977818914886043,-0.20888560068626494,-95.70585821775835,0.25505784188880354 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark11(-31.98037219404904,-1.4099182053931347,-59.24696319089212,1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark11(-31.99758244641805,-1.3019048211920325,44.291746552776004,95.20327741774267 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark11(-32.06477490024545,-0.5813387543132524,-15.332569191189663,-1.0 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark11(-32.09455391472646,-1.5707963267948895,0.0,1.0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark11(-3.213493405037741,-0.8545965745194481,13.72295170954134,-0.037555420350316115 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark11(-32.147441439949084,-1.213795650482392,-17.40352822545305,0.8972300289187022 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark11(-32.18501102225735,-0.008247047604492075,-1.5707963268278107,1.723761846497913E-11 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark11(-32.23955245020655,-1.5707963267948912,-95.7125738679466,-40.7554679134577 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark11(-32.301881468274644,-1.546933052512988,0.942892778962704,-0.7017649274463655 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark11(-3.2309280958321747,-1.2510197980764062,-37.91394804817013,-9.984234825297847 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark11(-3.2378381399271703,-1.519319780763693,-92.26473981873217,-0.9265815482424453 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark11(-32.45906754599197,-1.0640004555420717,0.0,-6.294813474739485 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark11(-32.52901254139698,-1.563500391812621,-37.63207931215877,1.0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark11(-32.53162691797862,-0.2959827670178776,-1.5513851130881335,-1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark11(-32.54884358921269,-0.5835809827027365,58.1426729604513,-2163.857267332773 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark11(-32.60782565403085,-3.795936122362643E-6,-43.57647233309005,0.23071635975655344 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark11(-3.265047306054214,87.14519724986658,-60.96386617574083,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark11(-32.65228849477991,-0.04332162343675951,39.132734205265905,-0.1586319752461273 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark11(-32.68331451696942,-0.9988276871913373,-4.690705434295751,-2.758572525790413 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark11(-32.7941962496739,-1.5707963267948963,-28.6741899930895,1.0 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark11(-32.8019195312347,-0.24506261045504196,-28.354048455564794,1.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark11(-32.87835564310809,-0.27859559963295616,-11.648146505336172,2320.0022361920046 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark11(-32.919403095915925,-26.638818219890865,0,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark11(-32.94137490253836,-0.6994398963630744,-1.5707963267948966,-60.86758186871494 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark11(-33.00123984974348,-1.3620578445770541,-65.17684758940788,1.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark11(-33.02539316726616,-1.2911479914495911,20.01276429507422,1.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark11(-33.03465966786823,-0.3664279111543176,-1.1940081268114557,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark11(-33.079201481980064,-0.8393761652466137,-1.5707963267948966,-79.79669625344128 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark11(-33.08273990811814,-1.0655574237047223,-29.378273148256547,-1.0 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark11(-33.125308402667756,-0.0307345579357101,83.1154425474797,-0.8755915854127911 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark11(-33.165928693563856,-0.5148089916703427,-96.06817737561342,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark11(-33.18274287713391,-0.01706774209607169,-70.80354273129538,-1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark11(-33.218529728108074,-1.3770886689881974,-67.45118040410989,0.6711332121500422 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark11(-33.35587600058573,-1.3584750151852778,-1.5707963267948983,-54.86411732172705 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark11(-33.36212223363006,-1.5707963267948806,0.6698898527825532,0.25942883056313804 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark11(-33.390678149825064,-0.45962496865980723,-32.79353029370992,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark11(-33.432199249739284,-0.5256737378263479,-62.561146395854905,-0.012015273585624243 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark11(-33.469155114797374,-1.1673332037467206,-53.18170359016487,-29.982941728237634 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark11(-33.48552003475982,-1.5707963267948948,-4.8043468950353825,1.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark11(-33.50964209057796,-0.2936706362620001,-51.84507935760494,26.415350017979605 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark11(-33.55738897939896,-1.4049080171425918,1.5707963267948983,-0.7042930386552602 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark11(-33.56585731508807,-0.9585669377207684,-1.4820177124726057,0.5932576694849452 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark11(-33.59941259364897,-1.5707963267948963,1.5707963267948966,-0.38990056762910485 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark11(-3.3654830007322687,-1.1525760221109038,-1.5707963267949054,24.7511956501113 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark11(-33.66212755422001,-1.7763568394002505E-15,32.80584156428577,-1.0000000000000009 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark11(-33.683598397207994,-0.8729204885549431,-37.881381738211395,-1.0 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark11(-33.69161633029398,-0.2875543803140026,-16.41298209026491,-100.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark11(-33.697766779589884,-0.9381246921429778,0.0,-6.24320539208483E-16 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark11(-3.370258621559733,-1.1486330858183083,-35.27336412732965,1.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark11(-33.71155027540872,-1.1904441304324842,-56.91640987126279,1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark11(-33.71852682492712,-0.19320257209626393,1.0757554990278917,-63.18069845117106 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark11(-33.73648140541561,-0.3760378602663735,-58.157724435960965,1.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark11(-33.741471688437,-1.0742960360069769,-60.6575107111483,-1.0 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark11(-33.75821763462831,-0.28205783948082636,-83.07957826385326,-54.62654248875256 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark11(-33.794599797460094,-1.5479359103102024,-40.46274972743844,-0.04311593620017018 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark11(-33.80345300668532,-1.1393050302548458,0.026863807053801713,3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark11(-33.896076450261255,-1.5707963267948963,-21.199811775332304,0.027828460785711568 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark11(-33.93042528015224,-1.3756299864837087,1.196447442094037,-1.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark11(-33.95063846214383,-0.1893651675078658,44.43277354888923,0.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark11(-3.3970570354455534,-0.06524653249584997,-31.891395943912997,1.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark11(-33.97949358889773,-1.5707963267948948,-100.0,7.47542119917537E-17 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark11(-33.99825039574509,-2.85251092015169E-4,39.13724195073834,0.3269073407688232 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark11(-34.07390739447334,-1.3270216289665089,-1.5707963267949197,88.7467596963061 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark11(-34.1040460122126,-0.8011235996626299,88.23094746223768,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark11(-34.14900422466742,-1.5707963267948912,-56.03878830035962,0.41379226493124976 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark11(-34.14977540321456,-1.5707963267948948,58.04553795901742,-65.8063179492197 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark11(-34.15385336602699,-12.439950523899498,0,0 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark11(-34.16534750042881,-0.7042845742081593,-95.03748285935617,-1.7725938857865742E-15 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark11(-34.24576093270298,0,0,0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark11(-34.26514093560926,-1.3669142579788707,-9.63443492565769,-1.3297126078893686 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark11(-34.26636160560008,-0.8732333485992373,-49.14127368684318,-49.24096087320995 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark11(-3.427680444723781,-1.4115177200706162,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark11(-3.428743005616127,-0.17066502631465008,101.22346167438775,-0.6761245279234755 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark11(-34.288177824810205,-1.2355470360159033,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark11(-3.4289496655203795,-0.3109625354940322,0.0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark11(-34.30255091671496,-0.06437141855042228,-5.274867749492785,-0.8456161049383697 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark11(-34.31251952632036,-0.0875440101032101,1.5707963267948966,0.42140422963706214 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark11(-34.3165749927674,-1.0050940315552812,-88.31381866129992,1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark11(-34.33291967101224,-3.9800649835427844E-5,-29.71657329593201,0.728571128547231 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark11(-34.36342018716235,-0.48611776904305076,1.5707963267948966,0.9555550862305583 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark11(-34.385866351346365,-0.6638297068878645,0.0,-9.41406878514491 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark11(-34.39255743189525,-0.7747924700329174,1.0036530353160973,-0.48212440965707515 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark11(-34.39711658908004,-0.9161079191899065,22.6440201853126,0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark11(-34.41540512597005,-1.5707963267948963,-67.72748805501853,-31.755806547797214 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark11(-3.446388020480981,-1.1754961926606662,-72.03239288964276,-1.0 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark11(-34.50853706568958,-1.5707963267948912,-54.024111024604196,0.19463398383717878 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark11(-3.453603452531972,-1.3816551975355664,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark11(-3.458532993020821,-0.21689969324139324,-1.5707963267948966,-0.5827241210917784 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark11(-34.646812724994255,-0.9579329631074756,19.945102447634355,0.9000477271353459 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark11(-34.773726402137946,-0.1406153204146878,38.73160963965468,0.02385139307992773 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark11(-34.84727250684641,-1.4338500450901366,0.9272148469354287,-71.09717712322092 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark11(-34.90434337157163,-1.57079632679471,-92.47118142968893,97.6839850327961 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark11(-34.921362959143195,-1.3287994972208017,71.96277765232571,-0.046135238502499176 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark11(-34.955420179435784,-1.3280491917375201,-16.151956190768345,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark11(-34.98343913504045,-0.5524734004651197,0.15350041369711045,89.63640008072863 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark11(-34.990283727870874,-0.15872413675661345,-61.26952478031875,85.35646454519757 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark11(-35.11074660680525,-0.30259042703355005,-50.93123607990027,30.046930485807216 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark11(-35.145621478138665,-1.2074583754730948,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark11(-35.15246493185241,-1.5293291777449782,0.3834940036594197,0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark11(-35.173426545060636,-1.34697445535663,-59.74335167771936,1.0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark11(-35.18492292203619,-0.5721314991583584,-1.5707963267948957,0.9999999999999976 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark11(-35.186998572615124,-1.5706502697052351,-33.92240033795133,1.0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark11(-35.19032905876611,-0.12434499697344138,-42.73902036918141,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark11(-35.22431546181035,-1.2192907206812509,-1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark11(-3.5250631962328365,-1.5550154803358018,39.10406792657539,0.4285678461056551 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark11(-35.25190741007546,-0.22058613873570287,-53.28829080459161,1.0000000000000018 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark11(-35.2844363854533,-0.6300437626035368,-4.404155108438815,-1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark11(-35.32307289952648,-0.9584206467308797,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark11(-35.47709457291587,-1.096311501807572,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark11(-35.47718775253017,-0.18874917376041317,-2.178784835307855,1.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark11(-35.485257504885325,-0.15521592472188295,-49.76456851486972,-0.5877947311264726 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark11(-35.50569629235684,-1.1921106193715758,0.9657831466043628,-1965.3302822639312 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark11(-35.60429028865884,-1.434193218965306,38.10640870294242,-1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark11(-3.56787620396409,-0.003133220362499616,0.8807130082739647,-0.04357985764416017 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark11(-35.74142454517725,-0.588169976393663,-67.40909541128954,2183.916499141275 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark11(-35.79609800199917,-1.4297440094134908,-12.873943847680032,-41.069361763354706 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark11(-35.89246180078645,-0.5268245556724171,-19.715428744105083,-111.06849109524008 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark11(-35.97699218456958,-1.4767508401255842,0.9809004542831875,-22.64655290826994 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark11(-35.98506872577567,-0.0798276338786931,0.0,0 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark11(-35.98618089072883,-1.427357848160816,-9.640002193398725,-1.6813258457984546 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark11(-35.99878039182212,-0.739406710233594,-21.985468752195658,-27.057750230315335 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark11(-36.0351358460431,-0.26287158772387187,-17.599799350773097,-1.0 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark11(-3.6192081857867606,-0.7898829128842948,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark11(-36.193166509989496,-0.21630853298136987,1.4597464173100836,16.491163293570263 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark11(-36.29423082877355,-2.220446049250313E-16,1.2906558700337856,1.0 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark11(-36.35185141581272,-0.5447083647036259,-81.92966760642135,-0.26481705170740977 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark11(-36.43243113141775,-0.5556724676632662,-30.69620355398697,-1.0 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark11(-36.47461121383585,-0.1275879509842579,-45.737154770112596,-0.06014479216364882 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark11(-36.4854071219036,14.155778812655868,0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark11(-36.58964029145419,-1.395546881581748,50.55422793995703,1.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark11(-36.59931966387864,-0.8037992009378581,-45.07480129657879,-1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark11(-36.61692847665749,-0.48046266067625476,1.4201726411582936,-1.0 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark11(-36.63046051683352,-1.5707963267948948,69.69122018874457,0.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark11(-36.69953527844446,-0.008399370045765022,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark11(-36.7303866216043,-0.4875102470974663,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark11(-36.75401205429972,-1.3776452277966733,-0.7307157684270458,1.0000000000000002 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark11(-36.77433708357903,-0.9029167461604359,25.22425201624624,-5.002112510379565 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark11(-36.77542958693395,-1.5707963267948948,-34.625948875068424,-0.029700503700877838 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark11(-36.79365639006885,-1.0652021571372714,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark11(-36.80198221661877,-1.556680293477988,-14.623973548809456,-100.0 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark11(-3.6874968662378684,-1.3700155241921177,0.0,0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark11(-36.87763412603681,-0.6118433547561553,0.45725037854902095,8.254282071991918 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark11(-3.6942815685206547,-0.12282617866893825,-27.542327733341768,-1.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark11(-36.95545534794883,-0.16682876608855635,-0.3987217161613162,-1.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark11(-36.97277457848073,-7.105427357601002E-15,0.0,100.0 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark11(-37.009025956010646,-1.2261619819058156,1.391018489280899,-30.78922442958382 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark11(-37.01332798526607,-1.2044446443131853,-18.6785410741132,-0.4959783718130347 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark11(-37.078787435793785,-1.5707963267948948,12.912601517302763,-32.15640953755363 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark11(-37.07884521489268,-0.08862703443942999,-44.20122499824336,0.15853082543419217 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark11(-37.13742912675893,-1.5532551494435098,9.080592974332077,-0.9763573163475847 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark11(-37.17890700050655,-0.15459980065221357,94.3543614776247,-1.0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark11(-37.23088679528238,-0.5718453539413366,-79.51716229919573,0.8463453423716302 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark11(-37.28661567362277,-1.5707963267948948,0.0184753745741304,67.17731355216112 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark11(-37.35601721069852,-0.6201553426833392,1.5707963267948966,0.0403061993379934 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark11(-37.364843903623644,-1.5707963267948948,50.7299594099629,-0.5636996216307176 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark11(-37.52982433428163,-1.554082478599944,-0.0012903716044058641,0.703592944783123 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark11(-37.553028404963854,-0.5865749132461414,44.03453974265818,1.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark11(-37.57382598087809,-0.46555741115042976,1.5707963267948966,-0.06255281527050889 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark11(-37.59560308273099,-0.6944201034751849,0.20855239048648022,-73.4728344524574 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark11(-37.701160874667345,-1.5619842069221608E-15,1.7763568394002505E-15,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark11(-37.75047397663802,-0.7333704045151735,-1.1741424613133669,1.0000000000000009 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark11(-37.800260941891615,-0.12954384327730395,-68.77748474156648,-78.84636007877877 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark11(-37.80627040089595,-1.2026717045193294,-59.177175664934126,-82.60969315707273 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark11(-3.7865863044336976,-0.4539291199077996,0.8155242528952176,-1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark11(-37.87660524338989,-1.316725199292868,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark11(-37.994217899685914,-0.10724940026855379,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark11(-38.0126969994822,-1.5707963267948961,19.35037574494008,-1.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark11(-38.10541062298633,-1.5707963267940244,-45.259146753349434,0.056318179896395204 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark11(-38.11537888914833,-0.8384451313574743,-3.3727230040115117,23.973666470116118 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark11(-38.12108787803824,-0.02006768161316431,-74.03236362567212,-0.042975089465704316 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark11(-3.813745584464133,-1.1755642034265739,-31.505168000028014,0.04541248007098377 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark11(-3.8224479334535024,-1.1253917001121518,0.08765385792811756,-1.0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark11(-38.229549955487144,-1.5639422218654615,-4.295573079478118,-1.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark11(-38.23947565497086,-8.881784197001252E-16,0.0,84.52036381360824 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark11(-38.303185144319244,-2.220446049250313E-16,1.5707963267948968,0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark11(-38.38254924761662,-1.5707963267948912,-37.747751053882524,0.011615668556431012 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark11(-3.840413794465718,-0.34299523924958825,-39.074738071982395,0.19655217677210146 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark11(-38.45075098044142,-0.17820227512624548,-100.0,-0.045774860591621794 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark11(-3.8466745523608106,-0.15801969707800365,75.5444911683986,1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark11(-38.48256070791932,-1.003507172456948,-9.284083572265672,-1.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark11(-38.523884128612835,-1.7763568394002505E-15,-24.95590654504025,1.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark11(-38.61861179064683,-0.6187869135358142,-70.3792112817474,36.923036899596895 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark11(-3.8619379519573718,-1.2751066948176768,69.34294651597416,-1.0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark11(-38.646270838187,-1.5707963267948948,8.937628504380475E-15,1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark11(-38.678022498107595,-1.318765772736666,-13.4790988940285,0.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark11(-38.73274628799281,-0.5447101108607946,13.156619997443658,97.29310780950289 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark11(-38.764924642052364,-2.220446049250313E-16,0.0,61.56481457133674 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark11(-38.78046197039099,-0.16447218141466746,88.32293589224115,-1.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark11(-38.81640311633344,-0.5951948853810568,-90.50499573172452,-0.9238175594273614 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark11(-3.8986080238436536,-0.05077458175964544,-89.98551011052717,-0.9999999999999929 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark11(-39.020962673491184,-0.11658951301289466,-128.22879808275584,-0.04535870936847192 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark11(-3.9038048549162565,-1.570796326794893,1.5707963267948966,0.01370764406083905 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark11(-39.060126528356584,-1.179720153402593,-9.746318416803046,1.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark11(-39.07863603114875,-0.2836119330722706,-62.88741597559931,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark11(-39.34329821588908,-3.320993874414056E-5,2.1684043449710089E-19,0.9603771113008376 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark11(-39.51930958469199,-1.341759680693889,-9.45918950352705,-62.959345006232326 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark11(-39.58037924999831,-1.5707963267948957,-9.552935570743815,-1925.037683474188 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark11(-39.6349952257404,-1.189708641469597,-4.891696891047417,-56.029017934796464 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark11(-39.663949705682995,-1.2243810352723097,89.4637727956042,-0.013910527568274211 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark11(-39.71906837543175,-0.05110440879913852,-10.709963069901974,1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark11(-39.76566805776308,-1.5707963267948912,38.58360704635575,40.623217315704196 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark11(-39.80074152833629,-1.5707963267947094,-1.5707963267948966,-53.72475267535465 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark11(-39.823105869199615,-1.5064816558884166,-72.52807492690926,0.694942979464946 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark11(-39.84760276431081,-1.5421266102295046,-8.239901012489286,-56.353260358140865 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark11(-39.916453300463886,-0.2783470390727245,-10.872589605992886,-1.0520271448749525 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark11(-39.93179749675726,-1.5616866918200178,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark11(-39.9439191980219,-0.26062985818096734,-1.5707963267948966,-0.044618942761617854 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark11(-40.022888793485,-0.8913755714092519,13.130081484085494,-18.722679095517286 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark11(-40.12822547420848,-0.6589239294465625,-0.46592515519251343,0.011332840291887457 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark11(-4.017391507921772,-0.011553811092880796,-10.138642604580742,-34.06381943203746 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark11(-40.26767120516226,-0.3646843942597271,-10.317088690849728,0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark11(-40.43691199005362,-1.570796326794893,0.0,-0.5600570634770444 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark11(-40.53880680578912,-0.2994418869716542,-82.02009551782723,-23.844269740740273 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark11(-40.564681646625075,-0.1325646591215719,-51.49749412843963,1.0 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark11(-40.59789838157091,-0.5593077716263124,-29.978211924038206,-4.840656514731761 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark11(-40.657009839769586,-0.15069629472813634,-36.26487162521054,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark11(-40.683934284564636,-0.8759831487203508,-8.252001313605897,-93.08434565454347 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark11(-40.68843160774797,-1.1274744343181573,-1.5707963267948966,0.9801341313022127 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark11(-40.719701343460414,-0.7484527071093424,64.02175000882997,-1.000000073748239 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark11(-40.747506210453395,-0.7200713388118819,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark11(-40.764822391659465,-1.5707963267947562,0.0,-1.0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark11(-40.84575130132125,-1.5707963267948912,-0.21019284721662324,100.0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark11(-40.88348392735451,-1.4792689854380172,19.889245834199734,1.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark11(-40.88421854731175,-1.4140659140659793,-73.79853906892835,-1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark11(-40.94909696544027,-1.4542319455848607,-39.236185975729526,-0.9998890800986925 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark11(-40.9772747511881,-1.0846734129432392,-49.75380408815397,0.03223816132399893 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark11(-40.98514504595605,-1.569422302499195,-10.26274712224864,1.0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark11(-41.089366940980334,-1.5707963267948948,-1.5707963267948968,0.9999999999999982 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark11(-41.16635058307609,-0.38261032309506143,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark11(-4.120178897174862,-1.2818515115847844,-56.43765891798101,0.9999999999999996 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark11(-41.214710871900444,-1.5483524841606808,-0.32166237960090244,-2034.7262789066313 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark11(-41.21575741279865,-0.4422250573967213,45.0141858465984,0.01207510838342866 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark11(-41.22197830706793,-0.026650653667888123,-1.5707963267948966,-0.6978540397255562 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark11(-41.28955138460922,-0.6200050516910326,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark11(-41.380690460374666,-0.5596164373612149,0.0,1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark11(-41.39678653591817,-1.3805452344979088,-0.3041525124979356,82.66406679638283 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark11(-41.41832869547159,-1.4241918718754687,-22.854442223353765,-46.52504755039039 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark11(-41.44882593171351,-0.17700958839331288,-1.5707963267948966,-30.084681513482877 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark11(-41.54663999058208,-1.5707963267948963,20.957447389216817,-6.084273990552385 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark11(-41.54909283684738,-1.5475029497492292,0.0,0.7222968307528141 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark11(-4.156469806752213,-0.8860356571794994,-88.9052732509104,0.9816967604563952 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark11(-41.637567665700495,-0.9961167023262636,-39.38572389004433,0.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark11(-4.172386343244241,-0.3208681047207622,-31.581606351443114,-0.9631782139132047 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark11(-41.73140549276027,-0.22689762128767876,70.17365758479096,-37.493945168113086 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark11(-4.174918889672918,-0.3995597495838057,-73.47835576840944,30.127213753703586 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark11(-41.75313872281104,-1.0184551310072203,-1.5198802580182735,127.28992136193713 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark11(-41.79211392214758,-1.0011280774901707,-9.878640384702763,0.9058364145038154 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark11(-41.84172467464495,-0.8727163357889367,-79.25187384474313,-59.930795435942656 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark11(-41.88077343469197,-1.5707963267948963,-44.10487078738726,-9.612684700410966 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark11(-41.92585315374327,-0.8056408371369412,0.0,-0.7591722928889766 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark11(-41.97875777080895,-0.9495086700275988,-34.329222963834184,1.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark11(-42.13614257632595,-1.1563128498362134,-3.552713678800501E-15,-28.147070433831097 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark11(-42.145302251743004,-1.3339459637822588,-82.25726632512827,-0.9999999999999999 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark11(-42.19396377244504,-1.5707963267948717,-64.07261476059776,1.0887043207126381E-15 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark11(-42.22069151667239,-0.13336458998324474,-20.350218578117442,4.528252591132051E-16 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark11(-4.228573739387873,-1.5707963267948912,1.5707963267948968,1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark11(-42.30219749627919,-1.5707963267948963,1.5572834950004297,90.1023345058561 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark11(-42.31819467211388,-0.2668522883787563,-1.2484884712334892,0.030552715559683405 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark11(-42.337826602951445,-1.5707963267948963,-0.2332076944075259,37.84713088801472 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark11(-4.255865288455447,-1.5707963267948961,1.5707963267948966,41.50705596492972 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark11(-42.566561933703284,-0.8799655940002372,-8.806366871465727,0.7286708340090673 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark11(-4.266405687182075,-0.5275691170272274,-74.77083002731352,49.33419458031193 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark11(-4.268640642844701,-1.3774798533722092,1.4144914508891793,0.591727849994389 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark11(-42.72041543455827,-1.1953667733473492,-38.357934470207276,44.27067522668452 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark11(-42.74413335789706,-1.5707963267948963,-1.5707963267948966,0.02812926429946882 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark11(-42.79772237252137,-7.105427357601002E-15,-43.697693076421814,-0.7288265012212576 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark11(-42.83282594019157,-0.23627806228469353,-78.67459359397967,-0.849910225406858 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark11(-42.86357951227045,-1.5707963267948961,0.0,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark11(-42.86540157420831,-1.5707963267941984,-85.71089390773624,2252.2885140646417 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark11(-42.90639173571328,-1.2672469270619138,1.5707963267948966,8.103261637143218 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark11(-42.91778418136069,-0.5593901225771204,-1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark11(-42.9430658991182,-0.9489240635384089,-1.5707963267948966,0.6701755079165679 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark11(-42.97228365036694,-3.552713678800501E-15,44.30314872366464,17.539252993191383 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark11(-43.048224316419635,-95.07205167929531,0,0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark11(-43.056115391999434,-0.992706838215424,-73.465201178406,-0.6929521447628035 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark11(-43.13920569947949,-0.8970602320318308,-54.488308284969136,0.08401955145812745 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark11(-43.1851669016366,-0.8871431340181403,-1.5707963267948963,-0.6846431234070984 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark11(-43.218794870873765,-0.6736427483109305,-11.061327972109517,1.0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark11(-43.245893291749155,-0.2799028090544115,88.415951031914,26.62756370533373 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark11(-43.285011771704575,-8.881784197001252E-16,-16.072249090714127,-62.09660872876001 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark11(-43.35978448301888,-0.9567333974693718,-1.5707963267948966,-37.330427933528625 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark11(-43.40193106766344,-0.9539467364522164,-99.06764141822826,4.807140533824423 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark11(-43.413950723361395,-1.074440179587977,0.978313595208912,1.0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark11(-43.478073403991594,-1.560737260391547,-10.971517099866762,-0.6698548662860481 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark11(-43.548650846475404,-0.43522147196774624,-11.00285924373707,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark11(-43.59902790287848,-0.10622783428965477,-157.40704553919005,-1.3096068338579203E-4 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark11(-43.636539464848646,-0.11222165114830518,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark11(-43.64862121851463,-1.5696769469269425,0.04508819374792748,1.0 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark11(-43.722955709761614,-0.36643217381431725,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark11(-43.73838142818601,-0.24069513094547945,-67.01849139185178,-18.99112606172244 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark11(-43.79947969932516,-0.2730769416435472,-58.46994201151641,-1.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark11(-43.80253611353149,-7.105427357601002E-15,-21.082217545903784,-1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark11(-4.384710740667193,-0.7130984040366417,-1.5707963267948948,-1.0000009087231176 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark11(-43.84935315062803,-1.0387999976369118,88.11754751274101,-0.9824264908772599 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark11(-43.92197183238689,-1.5707963267948912,-59.10123378351435,0.40077096717138083 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark11(-44.00931791990541,-1.160571809588503,0.355712360350868,-0.33851626080693975 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark11(-44.013135008064765,-0.4073633075056877,-72.2954248914867,1.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark11(-4.402731315692723,-0.9379521867613554,32.50022907953496,0.30112721044206936 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark11(-44.05255982167077,-0.01385176722226444,-0.8526000924022759,1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark11(-4.405420751653466,-1.3312774891879116,-56.41292404951561,-0.7579738550444399 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark11(-44.09792187221276,-1.5707963267948961,-0.01542132733470918,-53.77621455573892 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark11(-44.16242775845097,-0.8781276731684233,-1.5707963267948966,-0.9999999999999999 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark11(-44.18443620084429,-0.5649567875677926,-66.25200417759511,0.14175213633782374 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark11(-44.2025898564357,-0.9050273614020834,32.67018093818308,0.09246387086696939 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark11(-44.21736614124593,-0.2478843842709466,-10.731063034892571,0 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark11(-4.422559230510014,-0.19151231740947125,95.32083440502952,-0.9999999999999998 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark11(-44.227472073106284,-1.1554970692277085,0.47723252868136373,-91.53307460106146 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark11(-44.23602169276002,-0.7388324363683267,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark11(-44.28939875208139,-0.002141978161250306,0.9928552636153247,-0.3114659284608782 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark11(-44.34309829125965,-1.5707963267948948,-40.581062045707284,-0.034122979864539695 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark11(-44.35971320874281,-0.8007715653739342,-10.901456871066976,0.9999999999999991 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark11(-44.3987882555064,-1.3683743130770687,-20.415036656935385,-0.5238366108976342 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark11(-44.42658191840447,-0.6595394468514595,-37.967147134158836,0.0587038950388643 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark11(-44.42922658033183,-0.41889337496906265,-48.97163043607843,0.65006971215172 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark11(-44.45139787661075,-1.4173365010376646,39.31138975744926,0 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark11(-4.447011232542854,-1.0353758159559217,-39.1147873585978,1.0 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark11(-44.489812604571185,-0.6690814424384632,-23.200327071974854,0.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark11(-44.587602012473354,-1.1019875929542309,-8.87243638455502,-0.5466913156690243 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark11(-44.59946008857717,-0.8850900803924728,0.0,-0.9335622235451464 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark11(-44.61310505882031,-1.5707963267948948,-44.1425052521605,0.0614233183801014 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark11(-44.62396492516367,-0.37236991455111124,-1.5707963267948966,-91.38960102915667 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark11(-44.80905991140919,-0.5873477491231938,1.1102230246251565E-16,-20.823315950226796 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark11(-44.864818276565025,-0.9054192331919921,0.0,-0.2396692812239536 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark11(-44.91475110063941,-1.1278868627356697,-40.45085571492832,-1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark11(-45.003705676304435,-1.5707963267948963,-56.57415586346754,-1.0 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark11(-45.02117462080235,-0.7513798880415271,32.806192868753314,-17.68273918917778 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark11(-45.030043189105065,-1.5707963267948963,-2.7905696564470386,0.9761188452322465 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark11(-45.0628387958143,-1.4477187224445665,1.7763568394002505E-15,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark11(-45.069049793001305,-1.5707963267948912,38.317948836325655,0.44850364629565387 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark11(-4.508892476625009,-0.9802144298354027,-3.0551413280694564,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark11(-45.10168719396537,-0.18960859882683678,-76.14538977631678,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark11(-45.14891440768861,-1.4043741848896438,1.5707963267948983,-56.4914203953734 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark11(-45.17965053571994,-0.9729188081687198,1.0464918586110903,0.1722057186704397 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark11(-45.198194688335505,-1.5707963267948912,-86.70253598878463,-42.36194542889648 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark11(-45.22322975457517,-0.09110151978260839,-1.5707963267948957,-8.425056355451677 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark11(-45.25030710707564,-1.5707963267948961,-77.63891616429433,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark11(-45.27959748976046,-0.4253049159294831,-21.04085392752549,61.30128769505275 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark11(-45.29807912128169,-0.5145081967082541,-236.77055763531862,-0.013043432087479045 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark11(-4.534051790205469,-0.12115695943563165,-67.42916871474512,1.0 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark11(-45.37363053114838,-1.5707963267948948,-0.08274708554720157,0.0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark11(-45.407656019006126,-0.880975374879591,-50.80937835183963,-0.7896767980596275 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark11(-45.423432312299084,-0.3608565364230525,25.88961568319554,8.880966673166839 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark11(-45.471873094391384,-1.5707963267948948,21.101812529967585,0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark11(-45.47514894023118,-1.5707963267948963,25.168843436901955,2120.5514974681437 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark11(-4.550055513201553,-0.43051320795061226,-62.07763632092981,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark11(-45.69416019335869,-3.552713678800501E-15,-59.17410422408475,0.4482978340329402 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark11(-45.72998429229752,-0.05198924490402172,-1.5707963267948983,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark11(-45.875898706118846,-1.3558372661212665,37.86812622671047,-0.977768981969709 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark11(-4.592167274906326,-0.4617978241029623,0.0,-6.628258634592206 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark11(-4.599038611509436,-0.6089721392318858,-31.58169468704188,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark11(-46.04502054971919,-1.941551745880465E-4,-45.25505550110204,-0.3137179883947836 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark11(-46.09139969474272,-0.04254826487200081,-10.092652871703407,17.702412177323314 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark11(-46.122519370993544,-0.5157338333701893,-1.5572719502145336,100.0 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark11(-46.205774870413315,-5.127595883936577E-30,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark11(-46.22767082417039,-7.105427357601002E-15,1.5707963267948966,69.60332608604702 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark11(-46.363440660070495,-0.8592820029222005,-3.522658623156049,-1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark11(-46.391606345062996,-1.378383331045685,-8.009482189501327,0.03811504995555173 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark11(-4.645172841504259,-1.1423868776726542,-73.93056719720738,-0.9999999999999998 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark11(-46.486858948135726,-1.1311387388568068,-70.4520652487939,-0.3621220674451989 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark11(-46.5458103378275,-0.12774856285584543,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark11(-46.5806415501134,-1.5707963267948912,-31.695652705233847,-15.170810969706409 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark11(-46.73872551720648,-1.4893840918707348,52.99743564830318,-0.04751077015930314 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark11(-46.74278163629088,-0.6054125726600255,-1.4587415633521181,0.9793089335191134 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark11(-46.75128770252401,-1.5707963267948912,95.42056876006166,49.61692150539173 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark11(-46.75321776100611,-0.646344473556816,-92.30241302744423,-0.774333189235394 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark11(-46.78724659301287,-1.0371188211071674,-65.30426757746046,-12.321951155532204 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark11(-46.84024332901171,-1.1864276648917322,-53.94225663137271,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark11(-46.840948315459414,-0.28622873581022645,-7.181548013655777,-1.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark11(-46.91507126760537,-1.5707963267948912,157.6482810544149,-1.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark11(-4.694184842012776,-0.7974977595279853,0.0,0.9060351459984075 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark11(-46.94543791582431,-0.5369572385704802,-43.562126496111645,-43.038468395317174 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark11(-46.96675039092406,-1.5707963267948912,-53.00972501859691,0.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark11(-47.04697135593122,-0.02150243474347061,88.51206605575521,1.0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark11(-4.706109645352188,-0.3388231734008076,-49.43352435795923,-17.542404625525272 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark11(-47.09507339164046,-0.9883689072626687,-10.629064350923713,0.9398796361539564 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark11(-47.12979450449593,-1.570796326794893,-45.2604655805858,-1.0 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark11(-47.29842201292669,-0.23900710179224166,0.0,-1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark11(-47.3104930132973,-0.12831196351573199,-97.5435448451343,0.530723118763071 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark11(-4.746093523273494,-1.5707963267948948,-1.5707963267948966,0.9999999999999982 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark11(-47.47854179793772,-0.9324804217325536,1.5707963267948966,-2064.9190068032417 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark11(-47.646648883892965,-1.5707963267948961,-32.63361355819538,-0.23957248997519087 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark11(-47.65957148032075,-0.1627624295182971,0.04173993485965548,61.04793139053421 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark11(-47.66391315764735,-0.2756552186840046,-76.39115230109087,-87.39401229723306 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark11(-47.68905435128717,-1.559658680383509,-3.2542023116504364,-1.0 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark11(-47.77094835036133,-0.14439307220664555,0.0,-1.0 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark11(-47.788354823381454,-0.8137567386077105,-62.70745507823174,56.47058211452797 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark11(-47.857049045621466,-1.1107314231355616,-3.2072169172065728,81.02188984361491 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark11(-4.790732741417983,-0.5922800667663926,-12.012792534947792,-51.174490478554006 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark11(-47.92607749769865,-0.1132956683231374,0.5447256748119018,1.0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark11(-47.972399621965025,-1.5707963267948948,0.0,0 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark11(-48.022452096795895,-0.620440947071928,-1.1516300117997968,1.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark11(-48.02597855339585,-0.1530330091700457,1.5707963267948966,-0.6516862583265046 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark11(-48.05885543989268,-0.937165037920222,1.5707963267948972,-0.9686726582637982 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark11(-48.103655368676556,-1.0324446380881511,-100.0,-97.30421325568469 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark11(-4.822789848938005,-0.980192511472866,-26.74028390315595,1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark11(-48.27949988508223,-1.5617456367848341,-1.5707963267948966,17.568723666970644 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark11(-48.31146467603585,-1.5686601486009046,-1.5388279093408619,1.0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark11(-4.8320129177506885,0,0,0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark11(-48.332888967617805,-0.5443245564648146,-27.058758736161124,1.0000000000000036 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark11(-48.38009279534747,-1.4541101131067569,138.4458064816051,0.10465752746430734 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark11(-48.38621478936684,-1.5707963267948948,-44.97350956025068,-0.7031937752961486 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark11(-48.38888235474898,-1.0934257905620601,1.5707963267948963,-0.02601896402529902 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark11(-4.848437702425156,-0.0017896121771116865,77.88636268978526,-2.3408381773460992E-97 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark11(-48.60276892261872,-1.4797688263752447,-1.5707963267948966,-0.010142455463696116 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark11(-48.61302761432891,-0.8743261586042204,-45.867411520603085,-0.761663287150725 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark11(-48.63753898665719,-0.07899740954812967,-9.459277542914982,0.7540252665020727 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark11(-48.693220522023175,-1.5707963267948963,-1.5707963267948912,-0.9226781776483542 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark11(-48.79271527254709,-0.09491553748620228,0.9380620904688093,-1.0 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark11(-48.948272249326486,-1.5707963267948961,-63.264775313988366,-0.9999999999999982 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark11(-48.97576477829435,-0.00104703579932508,-100.0,0.0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark11(-48.98327588529705,-0.41487094518864026,-88.1870304593179,-2051.0469240323955 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark11(-49.012813285485215,-0.44675958997373755,-95.3480701694705,-56.457500193252685 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark11(-49.06613302268465,-3.552713678800501E-15,-66.99126100023443,0.016413355396960188 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark11(-49.096747531130546,-0.2289533982675488,-75.69876689257696,1.0 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark11(-49.1039201967268,-1.3197150962998883,-8.672215575126694E-18,2.551524856380383E-16 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark11(-49.10706154659053,-1.570796326794896,-60.24912518912676,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark11(-49.28972113935103,-1.5707963267948912,-4.440892098500626E-16,-1.0 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark11(-49.29669992439548,-1.5499999939442406,-11.560471933452789,-93.24206678307522 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark11(-49.36134061680842,-1.4615463509314313,-54.90772427003741,2.5988524414112248E-113 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark11(-49.36594234644405,-1.5707963267948963,1.5707963267948966,0.10438751674249902 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark11(-49.41182262860215,-1.0686151264221906,0.0,0.8308420477700427 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark11(-49.424373789927145,-0.7112593021897164,51.8017854225082,27.95878324519652 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark11(-49.45253719867932,67.05702921595142,-35.55900780873988,0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark11(-49.45361144616457,-0.17299579702247733,-72.65006075495619,0.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark11(-49.49172097963814,-0.6353598451135313,0.0,-0.9419248619384609 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark11(-49.51974505661131,-1.5707963267948948,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark11(-49.574644655908656,-0.18412427734166287,-18.154348246420877,1.0010415475915505E-146 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark11(-4.959091722264503,-0.30736029114356755,45.477562349282174,-100.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark11(-49.60219292902131,-1.5707963267948948,-13.93653308210785,1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark11(-49.60236528833264,-0.9297074625141357,-53.77498858532565,-9.616644125995402 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark11(-49.613536348525344,-1.0711248058384217,31.44832805123303,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark11(-49.65790584429175,-1.5707963267948912,0.0,71.1128308429312 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark11(-49.6615819255843,-0.9439254618781914,-93.47932400210473,0 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark11(-4.966443944422931,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark11(-49.73632947172173,-0.6066976889202351,-1.9138175808952882,41.664837311331965 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark11(-49.767364830738764,-0.896040803091324,-1.5707963267948983,-37.19239134606457 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark11(-49.7917360699901,-1.2583406938029076,-0.1563586760309187,-1.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark11(-49.90241324281122,-0.37066705850292764,-67.18652279680805,-0.029519115146600952 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark11(-50.15002168514165,-1.5707963267948912,-1.037921239190812,-0.9999999999999989 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark11(-50.19450460470355,-0.021931198895600485,-33.4111490405095,1.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark11(-50.19503851233493,-0.9195553565119845,0.0,0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark11(-5.025611705769691,-0.9539961417090694,-67.2289822513973,-1.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark11(-50.29011495048969,-1.4082777742987673,-1.5707963267948966,-0.6034432809055161 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark11(-50.37705976381706,-0.613826592527027,-20.513234134813263,0.010141124761639225 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark11(-50.44901393808288,-1.5707963267948961,0.0,0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark11(-50.458604932944404,-1.1559070964537899,-36.87968195640963,1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark11(-50.48745879544971,-0.6281484825167922,-1.5707963267948966,87.65573810386769 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark11(-50.49864642155464,-1.1623323784081254,-44.185335708977135,77.23560025667479 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark11(-50.503803959767346,-1.5003638989771022,-86.03670952785657,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark11(-50.59643681948398,-0.8354495533186537,1.5707963267948966,35.313576274368636 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark11(-50.63147850220908,-1.5707963267948948,-84.6811658041165,-1.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark11(-50.69886743467711,-1.5527691929836822,89.52104177817439,1.0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark11(-50.7235535058968,-0.9424629370601112,-6.989314888264998,1.0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark11(-50.760219683449094,-1.2304502061977027,-65.0363449920257,80.44065568506042 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark11(-50.80386719837999,-1.3128203346471565,0.1735591568271957,41.29314239256439 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark11(-50.81600261796568,-0.7620478127524308,-57.97393345436906,0.5330384939653494 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark11(-50.93096184134862,-1.198392936708049,-1.5707963267948966,66.24326860620097 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark11(-5.093494597394738,-0.6146129472088142,0.6273694685428863,2123.076741477792 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark11(-50.98401034996553,-0.8586889081482667,101.07017008149543,-22.752926680113852 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark11(-50.99384539910323,-0.12055871199035698,-38.565929761952205,1.0 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark11(-51.00173474968653,-0.19043417322694145,-0.4076986042814024,-8.843350693381002 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark11(-51.017879731602406,-0.9388809910699294,-76.9919756021051,21.38372044938005 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark11(-51.12118023809229,-0.3182573771125028,-15.374809996868256,-2299.1461402510804 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark11(-51.28221751580602,-1.5707963267948957,94.4169184427416,-63.406285436056336 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark11(-51.32896691514948,-0.966023793085179,-1.5707963267948983,-0.04054292534471857 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark11(-5.13483924485238,-1.4465632605293838E-15,19.774669332999586,71.01296755702407 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark11(-51.354077928804784,-2.220446049250313E-16,-0.49355864206830313,0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark11(-51.383963941281976,-0.4096640369000415,-44.0247469791081,-41.780878803259924 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark11(-51.48516432564416,-0.6773237508635646,-46.22230783057108,-1.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark11(-5.152489379928395,-8.881784197001252E-16,-12.874600494057198,-0.2885734964659784 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark11(-5.155989949883892,-0.11152124715593459,0.9417588817959485,-0.3591094806397458 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark11(-51.63311927691099,-1.0010237598303777,-9.023610541829395,-0.04406785303782368 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark11(-51.735977764677166,-1.5707963267948912,-88.58386338475125,-1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark11(-5.177235093151293,-1.3425114655052806,1.5707963267948966,-0.07832790617369767 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark11(-5.180711369366492,-1.0566906818312107,-10.70867881264536,-0.6910398082911371 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark11(-5.187980395694012,-1.5588631209951873,-80.79051790962241,-1.0150089186395386 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark11(-5.191165338561362,-1.5707963267948908,-1.5707963267948966,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark11(-51.92735493069124,-0.02927471075270205,-72.97808534096069,93.03748392467512 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark11(-51.93499522705835,-1.513684174856639,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark11(-51.972251775766374,-0.49758825712578414,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark11(-52.07953332419942,-0.4772646596295471,-72.16974023948563,2.8853058180580424E-129 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark11(-52.08384380596047,-1.5707963267948912,-80.66840451598094,-0.5037212942903997 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark11(-52.088382645077814,-0.5622619504362698,-5.70140625591992,-1.0 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark11(-52.2157124316033,-1.1919788651818193,-1.5707963267948966,0.024641261948298576 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark11(-52.23011887168094,-0.8667592139644106,0.0,0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark11(-5.224967531152835,-0.2565969790532938,-20.778312956835123,1.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark11(-52.360004112384374,-1.0159732371118508,-92.21279389430453,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark11(-52.384937654084986,-0.19115634115632474,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark11(-52.396976021280864,-0.4483251429666346,1.5707963267948948,-77.2977000904782 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark11(-52.41153073511591,-0.9073028907786782,0.0,1.9350874047256672 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark11(-52.48419447478157,-1.1758913780876,33.041474960126465,-0.02154365912231314 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark11(-52.49262248114545,-1.2706087401017307,-1.319617094020115,-0.5928462291531877 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark11(-52.51813089559791,-1.5002826959446822,-1.5707963267948966,0.9836077253865929 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark11(-52.54115641111625,-0.15981771961082814,-1.5707963267948948,1.0000000000000009 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark11(-5.254821373191185,-0.22607208995718053,32.43577765092164,-0.3546586135215929 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark11(-52.64394050289992,-0.506866503064257,-0.503774366668954,-0.018824319718468152 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark11(-52.66140522890853,-1.552857793409843,0.0,0.977162239175576 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark11(-52.66522119487253,-0.913957820294863,-36.17069094397543,-1.0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark11(-52.7245975483767,-0.11781908316672629,-50.55079859240474,0.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark11(-52.72511658764303,-1.5707963267948948,-40.45144158855712,0.9673940022709954 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark11(-52.79905355730017,-0.46884987603704786,-9.918072803353866,21.46514823922874 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark11(-52.972597334756365,-0.7687795401136951,12.838211493300093,-0.2775332658266011 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark11(-5.2974667547210075,-1.7763568394002505E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark11(-5.298856774834498,-0.2806666926183413,6.68003749544653,-7.762419929672987 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark11(-53.004882645589504,-1.5706115763733455,-66.18403648226929,0.9775523212713199 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark11(-53.04421295779492,-0.7029025528477053,0.0893250722817176,0.0 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark11(-53.05609951009034,-1.0165852125763735,1.035574947297375,77.50886573282189 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark11(-53.087725989876425,-1.2685369412651255,1.5707963267948966,-0.049667783116554204 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark11(-53.12490796240144,-0.2088237735300833,-74.08807454890606,-20.211577832875122 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark11(-5.3159875322445584,-0.028328902138533563,32.306595249327195,-0.9820621327754974 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark11(-53.172530160085,-1.1763422576312008,-1.5707963267948983,-0.6102398670931539 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark11(-5.318885136938591,-1.5707963267948948,-25.858759197739516,-0.11926273568124302 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark11(-53.27828949303281,-1.339240482989828,-0.7622731528387363,1.0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark11(-5.331147059432276,-0.3237546122861218,-54.55861835384229,-0.4821526943544444 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark11(-53.34037669406016,-0.3592609300976939,69.8108139188532,0.26670354663138607 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark11(-53.36743367892331,-0.540435186801409,-49.45158172703736,1.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark11(-53.405175337379525,-4.440892098500626E-16,-60.770466965447014,54.99251537326897 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark11(-53.434485963009806,-1.2911754269977813,-10.71163308130837,0.043380059745377675 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark11(-53.441241818213456,-1.0525615058379398,1.5707963267948966,36.96815778175622 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark11(-5.348508444141032,-1.0154428381470737,-67.24420003716209,63.61334456569301 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark11(-53.58626657338057,-1.5707963267948912,-56.05799628141392,4.025199634080366 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark11(-53.58860858054602,-1.1803906240172664,-60.68775210656368,34.53788012208128 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark11(-53.594431940563396,-0.2728267972458185,-1.5707963267949054,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark11(-5.366180384150185,-0.11244012609646181,-73.51087955650229,33.40162384509804 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark11(-53.78914782220177,-0.001923848952639362,-61.85641786473533,0.3585677677317109 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark11(-5.386220158035911,-0.0887268135703762,-86.25470940447326,0.8132350237014228 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark11(-53.865727671629514,-0.1301790338828488,-57.10430177818803,1.0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark11(-53.887010717797665,-1.3315917549979437,-1.5707963267948966,0.004823161487460592 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark11(-53.958477079529075,-1.162650706808264,1.5707963267948966,-0.6821837329383229 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark11(-5.398210001777677,-1.3774216777367856,-43.46518453882469,-83.50879762596846 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark11(-54.01474760701399,-0.18017204992292007,88.31496100981119,-21.75728675687681 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark11(-54.105116823551846,-0.44160263139405176,25.793282820037245,0.9910204992697773 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark11(-5.411715632510436,-1.2643884203696727,-10.831923939285353,1.0 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark11(-5.414421380341857,-0.5804043494219258,-4.387018327641059,-8.278010891049657 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark11(-54.223290099837655,-1.4330159732778098,0.6935517102080005,1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark11(-54.246152482632716,-0.9453007306783939,-31.074089873107667,0.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark11(-5.434916704786261,-1.545614699875294,0.0,-1.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark11(-54.46015484188985,-1.465996750955265,-89.90133344415365,25.874874646786818 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark11(-54.47499609951167,-0.14126942842561746,-10.845574362075567,-86.60694765842618 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark11(-5.474922553886131,-1.4872492736025922,45.33701600954461,1.0084924400624415 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark11(-54.845548317245864,-1.5707963267948948,-52.8593235059925,61.68574707804177 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark11(-54.91179257711707,-1.570796326794896,0.0,1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark11(-54.92188190981541,-1.0591976471196893,0.0,-78.15011333524936 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark11(-54.938671114682,-1.4641064034888938,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark11(-55.041464188187454,-1.5392253470780202,-1.5534956375958777,0.26201996305172237 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark11(-55.096016141525645,-1.083562017840505,-45.08215647886615,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark11(-55.115764261065365,-1.5707963267948963,32.717982439116525,74.11306106176957 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark11(-55.124486851318146,-1.369122746383573,5.551115123125783E-17,-1.055371372868486 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark11(-5.51257016015047,-1.1126670508789929,-1.5707963267948966,0.7160025708408272 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark11(-5.513138962127293,-0.6480123098350885,1.0586195842099986,-1.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark11(-5.517719617144845,-0.5422507026663042,1.5707963267948966,0.9999999999999998 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark11(-55.214580631933636,-1.5707963267948912,70.37999543273204,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark11(-55.27124791188845,-0.01590474543385542,-1.3668301122621163,-14.58370255638783 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark11(-55.27420202366716,-0.7174761509831997,-99.15775260136775,-0.0507914105462529 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark11(-55.33936423118212,-1.523820377148212,32.624303193437626,-0.6309979295241737 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark11(-55.35698830306447,-0.42693994511027133,-55.13560107078282,-0.15878606916227866 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark11(-55.414885056469785,-0.7303220856855772,-73.81851635313832,-1.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark11(-55.42846839309621,-1.5403704937407183,-35.16181012135039,2.5418542938969466 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark11(-55.44277265581604,-0.9810191532916648,163.73026790195917,-1.253997971679792E-5 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark11(-55.52566075891098,-1.5707963267948948,1.5707963267948966,0.06255297507543538 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark11(-5.5624831513925415,-0.5996225655266733,-20.702028067045845,78.94121527022111 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark11(-55.653479224010724,-0.6059757391668897,0.0,0.05668472551957643 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark11(-55.72814656366181,-1.078792206236818,-65.31469032850593,0.662622002278572 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark11(-55.78024614766302,-1.5707963267948912,-49.6386667576877,13.276917733913894 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark11(-5.588121707117992,-0.4758787094814245,0.0,-1.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark11(-55.90288534557936,-0.0021051829017310966,0.0,1.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark11(-55.91276600021759,-0.0472519178088362,59.214116594030116,-0.2908562824749117 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark11(-56.00400033364272,-1.5707963267948841,-1.5707963267948983,-64.8408266831413 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark11(-56.004610756119256,-1.4130722505515467,-1.5707963267948966,90.9275333423599 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark11(-56.031077356891636,-0.8987618854929136,-9.959985019526954,1.0 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark11(-56.095331429439916,-1.5707963267948948,26.670022780583736,0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark11(-5.612182429568033,-1.0820169788679828,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark11(-56.14924164244403,-1.14418555727576,-38.53402378836617,-1.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark11(-5.61887733747772,-0.3724376789687964,-77.22585287757835,49.90315735124625 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark11(-56.20407243385631,-0.007635586423102275,-74.09713943042604,-1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark11(-56.243874722450926,-1.063579328790188,-24.126873765678127,0.7361718082264288 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark11(-56.27136702629678,-0.26492154441573135,-60.3166911110643,-23.717812369950096 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark11(-56.27425678717832,-3.552713678800501E-15,-10.887376555854757,33.942936133146674 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark11(-56.28002245383267,-1.3359351921008802,-63.47142624438551,1.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark11(-56.339613330223585,-1.5640362812051183,-47.02013437915575,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark11(-56.439775876656775,-0.23249428951869625,44.14497425901624,67.62262170067527 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark11(-56.4608416208926,-1.5304371432454356,-87.16171466120133,-0.1104095061171666 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark11(-56.727777605282256,-1.4252216219015945,0.0,-1.0 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark11(-56.7328443670473,-0.005036752511067327,-93.13689240144656,0.4659339186101668 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark11(-56.761546971670946,-0.15205367905006129,-1.424163836406115,31.944447479288165 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark11(-56.765781938911566,-0.05766973748148496,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark11(-56.774998949104294,-1.5561161184017525,31.615314279949466,-1.0 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark11(-56.804805588182404,-1.0032141940895873,-100.0,-2117.8740483724923 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark11(-5.686138775820859,-0.16978899596881392,-1.5707963267948966,-0.7151964493951528 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark11(-56.95449695762645,-1.463926576345793,-74.86105105868779,97.23177721474134 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark11(-56.9753771525119,-0.09834710216847498,0.0,-57.09149005997367 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark11(-5.700901569179161,-1.5707963267948948,-1.5610652067794621,-3.556413999176124E-161 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark11(-57.017573462048475,-1.125295433988566,1.3632837830019264,1.0000000409419834 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark11(-57.02913270125419,-1.5707963267948948,88.246138794038,-1.0 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark11(-57.117120371127015,-1.5422514230405735,-1.2297628181311981,-57.52720392024515 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark11(-57.146948384575445,-0.10263308514243699,-30.225304514074526,1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark11(-57.17771892989319,-0.5159502148495196,-19.392501461468147,-1.0 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark11(-57.21097632282468,-0.9070175631801856,-1.5707963267948966,-0.6020957036940191 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark11(-57.26656410477749,-1.1130839514295479,-21.979466332527835,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark11(-5.735995684343683,-0.24530310200227595,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark11(-57.370699496104656,-0.2989165968278218,-78.99280446054483,-0.17803120400241568 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark11(-57.39798419425113,-1.2905667529292904,-14.113204406676644,62.365828868641415 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark11(-57.48202036133236,-1.558247998020834,45.05433951944809,31.583922234277964 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark11(-57.506211569191755,-0.8847293557513787,-72.05764696323484,22.440211371349974 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark11(-57.50859634429327,-1.5707963267948957,-78.73403317335084,-73.34507427291419 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark11(-57.553250444088356,-0.9956829401107701,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark11(-57.57119604884246,-0.698897342788231,-72.5856839722743,-1.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark11(-5.758667687565848,-0.9201391433658704,-80.2663419581783,1.0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark11(-57.60683402313352,-0.009278440325976703,-11.405622938813297,1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark11(-5.768609322935187,-0.08633201578116179,-0.2707024261095654,-100.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark11(-57.84663894030514,-1.5707963267948963,-2354.3037122051574,0 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark11(-57.85317952574653,-1.3812558363467442,31.848985027201735,0.4843425426145339 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark11(-5.793692518002221,-0.4472589961418336,-85.13714568575006,-1.0 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark11(-57.9405778627165,-0.17811570948208907,-4.554868215062214,-0.42877673122461635 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark11(-57.98489797226503,-1.030673191980075,-2.220446049250313E-16,0.09683462034007562 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark11(-58.06469330402214,-0.9899445766200183,-122.89300703557363,1957.8551074833135 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark11(-58.07133106996904,-0.9794038529124471,1.5707963267948963,-4.861399808485126 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark11(-58.072253339510134,-0.20258887360921737,-30.877475820973956,-1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark11(-5.81551657752923,-0.6740090790802267,-100.0,0.0 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark11(-58.22133562662684,-1.0484154055550734,-0.88440985811048,-1.0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark11(-58.23703125594371,-0.9556636793620538,-3.1415922223835095,0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark11(-58.27075533254761,-0.16851177808280202,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark11(-58.285831008842784,-0.16659960369787497,-61.98007376329683,0.026509651738456652 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark11(-58.29026421732784,-1.1210137207316286,-81.40207621380812,-5.7787731189835325 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark11(-5.832849810412867,-1.4309423666218664,0.03194192143530982,-1.0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark11(-58.364060067091934,-1.148425118596613,19.38211020744837,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark11(-58.42014339559939,-1.5707963267948912,-60.81822942836644,25.09393494535198 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark11(-58.42688540925846,-1.5707963267948957,57.920902170821485,0.05813295672349811 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark11(-58.42701569995,-0.07168593546852721,-1.5707963267948983,-0.3313901848527677 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark11(-58.444595300574605,-0.5392056308715176,-70.85377121258367,1.0000000000000004 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark11(-58.484813034168795,-0.9417451718422067,51.07724909517026,1.0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark11(-5.849897583769433,-1.5707963267948912,-17.85364780522049,-0.3393888201231663 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark11(-58.51968237693986,-1.5707963267948806,-0.8538666415007369,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark11(-58.54025810172533,-1.7763568394002505E-15,-100.0,-41.475227568362826 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark11(-58.578977816735616,-0.9446092401233485,45.05191069331653,85.62628814708948 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark11(-58.611921793604886,-1.2427902867084752E-4,-26.35931601267339,0.9736248252566699 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark11(-58.61777445925858,-0.6824618478809155,-1.133426592109544,1.0 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark11(-58.64106400012006,-1.5261170464223253,-8.081879851579293,-0.9999999999999933 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark11(-58.65197387954576,-0.3054106852656758,0.9817389533380826,-0.9449354960940098 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark11(-58.784908158176556,-0.31088514355185254,-44.43788892652,7.389651752340882 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark11(-58.83031469944315,-0.6893993374951757,31.53181606169744,1.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark11(-58.87444047996388,-1.5707963267948948,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark11(-58.89625254720241,-0.2374832342226979,-84.81324139609261,0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark11(-58.904061590898806,-1.3106349939089128,-67.88320977018648,46.01466905504452 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark11(-58.91908295719212,-0.26586217644885823,-51.20957552684605,0.011589137369148433 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark11(-58.97058087593334,-0.22443520065384348,0.0,1.0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark11(-58.98842420475315,-0.18379613902039516,-32.952307526333136,-50.33088017958094 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark11(-59.013532563731204,-0.8055518459851332,0.0,0.9948088250536133 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark11(-59.071459020060786,-1.5707963267948948,-12.897922252017214,-91.61283844588733 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark11(-59.21132571524781,-1.365986078251542,0.0,-1.0 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark11(-59.2118081602891,-0.49864475944225295,-88.9006898513585,0.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark11(-59.2156569648139,-0.784772909037823,-26.309715118413294,61.724712359648805 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark11(-5.925744837525684,-0.24912204647939795,19.91958444804494,-1.0523205372388102 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark11(-59.27267798297355,-2.7755575615628914E-17,0.0,1.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark11(-59.27510456586618,-0.09395658981659594,-45.18306698771181,1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark11(-59.304184543632374,-0.7243967758576701,-32.54680973171385,1.0 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark11(-59.373543822936,-0.6728668056811558,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark11(-59.40560386669773,-1.0320268274765199,0.0,-52.758314576488026 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark11(5.94456942206088,0,0,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark11(-59.54560658408772,-3.552713678800501E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark11(-59.566327157324785,-1.2376644331453717,-57.643551509199526,1.0 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark11(-5.958383116318686,-1.4007509861015086,-89.65308756049113,0.013966933735484223 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark11(-5.96294759960503,-0.4025890472892315,-26.957340946869948,0.29828288612904175 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark11(5.967780259944803,0,0,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark11(-59.69214996784547,-0.13770794629954897,25.415448921900435,1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark11(-59.73559783986898,-1.2791512830737402,-73.20160191977521,0.9823119394173964 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark11(-59.81501437934895,-1.5707489219746347,-76.02190553638766,-0.3283634975285814 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark11(-59.84729595464753,-1.5707963267948963,1.5707963267948966,0.999999999999999 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark11(-59.86827710699722,-0.312200163286235,0.49696905953617576,0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark11(-59.908328210378116,-1.2306840277519893,-36.79524503874983,0.06255886551085364 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark11(-59.91825722967414,-0.5505234847054155,1.3467315045807295,-0.2810449317633924 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark11(-59.9498872629342,-1.0760146824009347,-25.35336831485435,1.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark11(-59.98134156855128,-0.9104328609507704,0.046028246523857265,43.74630509445675 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark11(-60.0025181682322,-1.5707963267948664,-1.5707963267949054,-100.0 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark11(-60.047659947483794,-1.3353219778669838,-97.58477522901869,-0.1710027923823647 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark11(-60.08475508816746,-0.5379493534353657,-70.58178784814164,-76.9289693753509 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark11(-60.14375254915693,-0.761504123718399,-30.428649413300974,0.051894444197983614 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark11(-60.172178628459584,-0.10118659854104672,-0.5588172846838177,-51.491175301033024 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark11(-60.190607672247054,-0.9094807814648536,-19.567109635592555,-1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark11(-60.22085285407964,-1.0349713818931014,-80.16015798026679,1.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark11(-60.22240588941499,-1.0927169883708487,31.968722149652585,0.7316087899354374 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark11(-60.37605438672597,-0.30385469842675406,38.143662192270654,-0.5729968007559814 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark11(-6.041347907504462,-0.11619569628217587,1.5707963267948966,-23.322187356451035 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark11(-60.45358367440569,-4.440892098500626E-16,-65.84844847896264,7.225288923811224 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark11(-60.503907447535205,-1.3345927557353292,0.0,-1.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark11(-60.517215308215214,-1.5707963267948954,-16.52618944233012,3.126259058258143E-17 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark11(-60.59774322676219,-1.1645918882867672,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark11(-6.067563456443082,-1.5707963267948912,-64.21909966049918,2378.3066595858486 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark11(-60.676759535244784,-1.569936144008428,15.698270410437903,-0.9652427681100451 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark11(-60.68431613314783,-0.7657707079946824,31.981016212519606,1853.6102815442805 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark11(-6.069840311117267,-1.5692003470409455,31.826752043567993,1.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark11(-60.71076371542131,-0.9859385390752438,0.0,-1.0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark11(-60.793121980688106,-0.06063797904418333,0.0,-0.4181058599867029 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark11(-6.088736324657,-1.5417735796417045,0.0,1.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark11(-6.090962164999896,-1.5707963267948912,-5.216073562744358,0.5509202122063344 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark11(-60.96053092336078,-1.7763568394002505E-15,-52.98314318183412,8.506382270106556 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark11(-60.99499862504896,-0.4050149243371197,-72.70960152456797,1.0000000000000004 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark11(-61.04068312876824,-1.5707963267948912,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark11(-61.0655388967366,-0.4410844940969464,-25.30999274190525,-0.04291194835412884 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark11(-61.07390983574297,-0.7024891369433024,-4.182561511431639,-0.027928974173299304 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark11(-61.119337522089374,-1.5539735355637083,94.35962208733592,-0.018198913751239623 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark11(-6.113902651107185,-1.5707963267948912,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark11(-61.28514410589029,-0.08560774308858843,-10.460512994267344,-54.348385101884155 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark11(-61.4065912003398,-2.220446049250313E-16,-1.366275367940212,-0.08431916176848775 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark11(-61.454083150300534,-1.5593042910546122,38.59942776285186,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark11(-61.519351354619005,-1.5123409399275256,2.852207275937648,-1.0 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark11(-61.52140606670437,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark11(-61.548291817436265,-1.2335343308824176,-33.9941072179146,-0.23830884051170642 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark11(-61.54930755031711,-1.5707963267948948,-46.144151308926936,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark11(-61.59536836179775,-1.2896951683561042,-1.5707963267948983,99.44635761432895 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark11(-61.60843304577374,-0.2161220921972582,-1.5707963267948966,-0.19435544956783882 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark11(-61.64660986251105,-1.3956651543941467,-45.04366655652868,-1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark11(-61.674240865142345,-1.255758832473013E-16,1.386101611161918,-29.182090576616503 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark11(-61.67464632591915,-1.000265603995004,-1.0055761241362107,45.369729310262 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark11(-61.74914372593315,-1.5707963267948934,-1.5707963267948974,20.0936575788879 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark11(-61.75881154142068,-0.2548331965878947,-37.62062358320052,-1.0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark11(-61.8133647505275,-1.2021944536766105,0.0,-1.0000003013802319 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark11(-61.86381109790658,-1.2282360440316655,-48.148782094703904,-1.2813331809171846E-144 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark11(-61.92666046553113,-1.302840462785549,-40.31668647177649,0.9999999999999998 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark11(-61.9353625725317,-1.526585669781184,-97.05656200687191,0.017985953403676536 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark11(-61.94651752838367,-0.02765843620781782,44.105812147503855,0.404768936468515 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark11(-62.01022993492781,-1.5707963267948912,1.2803404655367487,0.0619041559629466 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark11(-6.202355714717768,-0.21430828717652833,1.5707963267949,-0.5185541400236204 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark11(-62.109348605076285,-1.5707963267948868,1.5707963267948966,-0.02113514051547205 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark11(-62.116992176920625,-2.220446049250313E-16,-36.52430899782862,38.950718948619034 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark11(-62.15731064688973,-0.6932534247340594,-1.5707963267948966,2289.6023945384904 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark11(-62.182513215613305,-1.0389536993353037,-1.1745347744121997,-29.172572094085155 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark11(-6.21874218537135,-1.2091179455358558,-39.0967949740793,-0.8835773702212639 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark11(-62.23181053801206,-0.013634185538950388,9.15930298213138,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark11(-62.30151040338508,-1.5506764083298104,-47.04872664618796,1.1035417390645503E-6 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark11(-62.31252913866559,-0.13609036763341376,0.0,88.06902901923752 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark11(-62.366841786546345,-1.1117690488439893,-21.0470859176352,-16.421629645575123 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark11(-6.238572920220186,-2.220446049250313E-16,-36.04676243275633,1.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark11(-62.39202090933391,-0.626231545257002,-9.335548819250135,-54.33649630417685 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark11(-62.39415747066655,-0.5185414767520857,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark11(-62.40554421923974,-1.5707963267948957,1.5707963267948966,83.5302401371057 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark11(-62.536229824812544,-1.5707963267948948,-53.93680009333419,-10.220508376941552 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark11(-62.786388999963066,-0.5240661797543371,-6.634530194161663,-1.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark11(-62.82023984848964,-0.07625901439600469,-50.26637316324479,28.48550315448841 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark11(-62.94482462233752,-0.5354067875868793,-34.38916686396594,-81.41389899907453 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark11(-6.2995746341742915,-0.8689522286340736,-1.199618373536952,38.84183513689762 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark11(-63.19097681733283,-0.7574347137017925,-5.600507952465037,0.0 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark11(-63.19816277484553,-0.3255058635290218,-77.48751275087642,81.73168050540286 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark11(-63.21373612219312,-0.056319213180824085,0.11543401636576739,-1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark11(-63.29874472944896,-0.9033584956273306,-1.306374670790638,-1.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark11(-6.329891460458526,-0.08839300038013942,-1.5707963267948966,93.27874391918905 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark11(-63.33609092581935,-0.7769037105102937,-6.8191106306864215,-69.94308239430939 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark11(-63.371372841628286,-1.0644692398687938,-3.376483942827349,0.04466486590886931 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark11(-63.42627577118571,-1.5707963267948957,100.0,0 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark11(-63.48162523485972,-0.20218422524458474,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark11(-63.53138412409577,-0.6505344633704955,-17.131719413360727,19.279112868905784 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark11(-63.5319444720424,-0.5694131630239765,-32.69355838560418,0.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark11(-63.58435422764637,-0.022937513755632022,-28.569297544048723,-0.06255282597591787 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark11(-63.6247966758406,-1.5707963267948948,-45.53206080765055,-0.7811621132862736 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark11(-63.73504128432136,-1.5644092818661408,0.5139484867322988,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark11(-6.373604554939484,-1.1184971760535682,1.5707963267948966,1712.1794846087491 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark11(-63.74368425149723,-1.4224920297199837,1.5707963267948966,0.8319703610590782 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark11(-6.380584245578831,-1.0550502642884234,0.0,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark11(-63.8403250132623,-0.22425542545212757,-72.9116983763855,3.944304526105059E-31 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark11(-63.89361373863429,-1.5031683090028833,-7.944509060758397,0.8833745895509609 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark11(-63.96946828146528,-1.0230506804605588,-44.0638834746533,5.472819448200024 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark11(-64.02342255805793,-1.3546535946938207,-0.38845410428868377,-1.0000000000000009 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark11(-64.05553181290615,-0.5553729463200566,-37.84259794327866,-70.33635832478797 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark11(-64.10203563480196,-0.4022158440609593,-95.4538530291474,0.0 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark11(-64.10698997357686,-0.8990291820112701,-18.055746577647263,1.0001443289986456 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark11(-64.11541703776466,-0.4193622492755913,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark11(-64.12780608410672,-0.005356978808738085,0,0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark11(-64.20094759956592,-8.837812275496636E-16,-1.5707963267948963,0 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark11(-64.27478242812457,-0.765699158208835,-12.332783611408729,-1.0 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark11(-64.30531514385589,-0.27280904386286986,0.0,-0.08408919132900668 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark11(-6.438158379647118,-0.0820130027742163,-87.5765371570575,0.6199064303115813 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark11(-64.42664651194278,-1.0862874917321543,-11.103029370607835,-2.3376273137649797 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark11(-64.51506912573234,-0.011506238631555588,82.90516379847898,0.002035767216578166 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark11(-64.51695521024408,-1.2516971910020693,-86.61734163647768,-1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark11(-64.51916418408594,-0.9436559422078574,1.5707963267948966,-46.040284602402195 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark11(-64.56210791207134,-0.6231251807540223,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark11(-64.56575921562909,-1.5707963267948948,-23.969339461810904,1.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark11(-64.56659272218559,-0.8427959536618301,-24.075242292075718,-1.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark11(-6.461355983487692,-0.29136340172962605,-87.50292120940932,22.51909812891737 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark11(-64.63920039337286,-1.5190773134067659,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark11(-64.68782541408576,-1.5707963267948912,-63.89922280280602,-78.68087005208695 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark11(-64.77058423534436,-0.00454624662103359,-1.5707963267949054,-0.01787749014877127 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark11(-6.479854911772771,-1.0363453773060431,-65.38704457129353,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark11(-64.90369773097773,-69.29845292187514,0,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark11(-64.9111043385808,-1.4242881875770848,-32.94195973435691,41.60621382137394 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark11(-64.93312245335309,-0.3649275469351494,-99.10763355557874,-21.486841769145414 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark11(-64.99590610162747,-0.45626551532203763,-1.5707963267949019,-1.0000000064027323 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark11(-65.01654384441741,-1.359109062727767,1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark11(-65.03450556021829,-0.9994229528930845,1.5707963267948966,0.27717178967262257 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark11(-65.06097926900274,-0.038995202308155154,19.55744324884212,0.3090260263673555 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark11(-65.19366562089596,-0.0321728885402686,-72.59474354269729,-0.06153954626582678 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark11(-65.22455962474876,-1.1136047273581906,1.5707963267948966,-17.796471650203095 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark11(-65.26744366090507,-1.5707963267948948,-23.722607890516134,65.78743725094847 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark11(-65.31313729341679,-0.27802126715491227,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark11(-65.31504652588247,-1.543194791486236,0.0,0.0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark11(-65.45702481380238,-1.5698634807019052,39.453029538187444,-0.10656150168458177 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark11(-65.51652526421267,-7.105427357601002E-15,-30.867972996167907,-1.0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark11(-65.51847758804756,-1.5193246502491349,-18.88050556609872,0.9649857682573534 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark11(-6.5540398729902005,-0.016601669235012356,-62.27631422234405,1.0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark11(-65.5493644589288,-0.355444122270218,-0.23254807194991206,1.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark11(-65.57025811743836,-0.928273778784585,31.917276489785706,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark11(-65.78866402297956,-0.18402961433863574,-36.10728045193008,-1.0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark11(-6.583158409557342,-0.4310545681390261,39.17134495293507,-12.807783228313156 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark11(-65.86068491950716,-1.3241397155654404,-46.66447577413904,-1.0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark11(-65.87356117772761,-0.9379488358577568,-17.24792619900667,0 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark11(-65.9227274196947,-1.1243965773404196,63.447306371307064,-33.14990685793975 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark11(-65.95247642222574,-1.5707963267948912,101.5608464899214,64.26681745228476 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark11(-66.03949903761786,-1.4784405060578507,-93.49260869148695,-0.9580017404175543 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark11(-66.06613068737471,-0.5297636086087516,-1.547879711788255,-1.0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark11(-66.07991200764658,-0.1500142585003772,25.825761250150226,-1.0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark11(-66.11368825753823,-0.17020949895516463,0,0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark11(-66.11474073973771,-0.36655657374159034,-69.1907987237301,73.51541922077749 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark11(-66.11789839019121,-1.5051559780642922,-20.47157752682918,-0.34966723913456854 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark11(-66.12007510864574,-0.3398665468914049,-10.84208031098106,-0.00918771487380754 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark11(-66.21904911356604,-0.20026220991011381,0.026250681349203844,-0.05461591315106182 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark11(-66.24014577222064,-1.5559862233929214,-81.58148805663745,-0.3333849145269572 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark11(-66.24288134568248,-0.08883822537724961,32.484846814275045,-1.0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark11(-66.3081272325087,-1.6180504730808422E-13,-74.64828246236381,1.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark11(-6.648732225168032,-0.9059039036609271,1.5707963267948966,0.019797051980317944 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark11(-66.5644922854873,-1.1473151139936753,-29.090394786939857,-1.0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark11(-66.6165139092995,-0.5061383216926494,20.990970864195972,-0.6151000180952779 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark11(-66.65190544452608,-0.03247204463462025,-90.0997282730758,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark11(-6.684783377116261,-1.5707963267948948,0.6840434425011455,3.8936761382091447 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark11(-66.91032257735046,-0.0032191098792750993,-33.060430496425084,0.16942960161889642 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark11(-66.97095137006907,-1.4934167417157356,-78.92769638350936,-77.94734526488665 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark11(-66.98321440021635,-1.0158687970157598,-2.694988294055916,84.4114896995097 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark11(-67.10857470677968,-0.007645250746849774,-9.563030140377073,1.0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark11(-67.11007941931136,-1.5707963267948957,1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark11(-6.719941302220589,-0.09365514148580086,-21.346456746901847,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark11(-67.28748310364973,-1.0959523915819114,-33.13929144725698,-1.0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark11(-67.3553393183468,-1.2228366804266777,-0.33040521577841564,18.433365598832637 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark11(-67.36763345390634,-0.9918957626455622,-46.20141662800978,0.5037475347181469 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark11(-67.37016393409466,-0.41364685740703266,-5.554169827868638,-1.0 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark11(-67.66029341910891,-3.552713678800501E-15,-36.71523989483824,0.9192268892500088 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark11(-67.75879581731456,-0.9246415187494149,-4.480292150722955,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark11(-67.76385043185351,-1.5385270220242517,-0.3905729305748584,1.1231253682473077E-15 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark11(-67.8976132567115,-1.0653735046660664,-7.827352226696732,1.0009705464276781 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark11(-67.9742318963012,-0.3971334188817721,-90.79375190723383,0.836225016895864 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark11(-68.01017800917451,-1.566470815741453,95.66867737499999,0.9547757863459033 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark11(-68.04030427832855,-0.6462477600400032,-56.63844537391381,-2.1084395886461046E-81 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark11(-68.18688766084018,-0.06431127597504371,-0.7398165045647787,-19.610292963955374 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark11(-6.819644513762675,-1.0781004860948777,31.70688105459628,55.8704873621977 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark11(-68.2473436471329,-2.220446049250313E-16,1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark11(-68.3008107822052,-0.7441376320448816,-0.840088228382105,1.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark11(-68.30452784318302,-0.36817793293986356,1.5707963267948948,2341.542535180949 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark11(-68.42658754170374,-1.0083552392996453,-25.361738336763914,-1.030256263330856 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark11(-68.46637558234413,-0.6491207847250904,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark11(-68.4790493348038,-0.4187948216656013,-65.32302540564822,-61.12343846274471 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark11(-68.5715245520658,-0.25439624824482365,-67.28147320675076,1.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark11(-68.6187105764994,-1.5707963267948912,0.0,-78.76668922513609 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark11(-68.62920643311828,-0.4412256136917061,-7.768470482188292,-2270.3928123840283 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark11(-68.66140521556082,-0.473790302474427,-121.10834050535087,-0.06281929562762421 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark11(-68.66728981457457,-0.8860155123400543,-1.2653401307959342,-1.0 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark11(-68.67371461185176,-1.4295336801071934,-76.72712049239104,1.1704190886730496E-97 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark11(-68.76301485809302,-1.3068786624758193E-15,-1.5707963267948966,0.38593053721153714 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark11(-68.77573662355172,-1.5707963267948963,-31.58304646908843,0.40541568847545595 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark11(-6.879779252311817,-1.218039798783347,-93.65471965460853,-0.8756696298738557 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark11(-68.87803415258479,-0.4283027123536713,-88.40315586888245,-1.00005288426206 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark11(-68.89609176571179,-0.5101423852360649,0.0,-1.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark11(-6.892556409161703,-0.20379638761129115,31.864181664385253,64.76175709357634 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark11(-68.97981550691354,-0.292405123662483,-10.45093737012121,-1.0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark11(-68.98323499294904,-0.7216033178968375,-15.729659081402035,100.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark11(-69.09878838717945,-1.4631163040105073,-1.5707963267948966,-0.06255736832187761 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark11(-69.10616312055309,-0.029231423790289746,63.64522471442606,51.68089775770367 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark11(-69.14514216919352,-0.28186977079991626,0.6563936577661449,-31.973085626985544 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark11(-69.27086319654154,-1.3009890745547774,13.313865147411105,0 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark11(-69.28915100564069,-0.6012914653168328,-1.5707963267948966,-0.09631747413383696 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark11(-6.931239081670057,-1.0363049269189497,-14.55885478555679,-72.49377663182328 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark11(-69.43996135489604,-0.9304850508985875,1.5707963267948966,-0.015333132807441086 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark11(-69.5370401890178,-0.2452804220815412,-0.667041625794239,0.5970376159088617 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark11(-69.5391961804818,-0.8089107957081798,1.5707963267948966,-0.20549625485521106 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark11(-69.54634561924189,-0.9636667705228408,31.78712428648314,1.0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark11(-69.64141855764093,-1.2314101087000888,-36.3424806519158,-1.0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark11(-69.74266393621049,-0.7900821204563977,-44.144873619159526,-1.0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark11(-69.78148448378833,-1.5707963267948948,2526.4345361665755,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark11(-69.86150587938816,-0.35554330464839434,-38.81133030407646,-1.0090970368924959 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark11(-69.88705119647508,-0.027116601539034946,57.527916265598265,-1.0 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark11(-70.01938032564728,-0.8896376031845872,-45.98747459728991,0.8929895429603754 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark11(-70.0288801325885,-1.1333647818956925,-0.3280903746479964,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark11(-70.04544035640315,-1.1585341536898541,-236.13866400866857,-1.0033970817215814 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark11(-70.05196967808067,-0.09647082404738908,62.97586372844444,-1.0 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark11(-70.06601279941799,-0.3560627494284354,-88.24783389532926,-0.057679722739302296 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark11(-70.18707940858509,-1.178563961692811,-81.58496503340746,-0.9544024465868179 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark11(-70.1978875012718,-0.7680034993991791,-7.740646927976001,-0.13718099544412887 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark11(-70.3030777762641,-1.5707963267948948,25.33689337994356,1.0 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark11(-70.31177684277671,-1.1434939330712766,-46.550877576032114,5.421010862427522E-20 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark11(-70.32853073583951,-2.220446049250313E-16,-25.892938387934493,-2245.985767871263 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark11(-70.3373139477391,-0.40179887732320857,-0.6264507631108459,-0.5787682194668773 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark11(-70.3717554341941,-1.0805820592727313,0.5488055524803646,1.0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark11(-70.49263180785907,-1.3707708757339967,-58.33545990434724,-39.9514977920189 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark11(-70.55907355828003,-0.2026072229065221,-14.993687643612077,-53.66922797297178 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark11(-70.55991238002753,-1.4470148482521301,-1.5707963267948966,0.05981045392255895 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark11(-70.5994107342918,-0.12227620225326861,-44.48836915925823,1.0000003652626694 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark11(-70.64193290672814,-0.15559992466978972,-52.16267483211208,-0.0026719761740777725 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark11(-70.72051998517543,-1.2919318208210484,-52.98336359804765,1.0 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark11(-70.84039761171731,-1.3692889834853128,-46.79277898237297,-1.0 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark11(-70.89013205596297,-0.26461758669483637,-1.2587457405236213,-11.04893660865008 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark11(-70.99580598706498,-0.014747520267907488,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark11(-71.23815873497125,-0.2977237289282528,-100.0,-100.0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark11(-71.29156170670413,-0.6215364119602624,64.12939459214161,10.046170066231568 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark11(-71.34332679776841,-1.5121525881309896,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark11(-7.137871243724348,-1.5136462254883738,1.5707963267948966,-64.11536582877663 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark11(-71.43225275536554,-1.4880902719091043,44.289201763877784,-41.63532500312633 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark11(-7.143656322032413,-0.4150900753388238,-53.660005235137234,-0.6894626611278063 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark11(-71.52754862001866,-0.00262823981792637,0.0,0.7879727098884636 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark11(-71.55754400808006,-1.5707963267948948,-55.74012750699918,30.471961234171452 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark11(-71.6109851519671,-0.41859996271539507,-60.25432354193439,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark11(-71.64688272756214,-0.6354633280434063,31.748259566856763,1.0 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark11(-71.71921170300095,-1.7763568394002505E-15,-1.4129678917875932,1.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark11(-71.73918159380571,-1.3420523575625374,-9.742363625972391,1.0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark11(-71.80646359600603,-0.08064068097827753,1.5707963267948966,14.982177880309948 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark11(-7.206668848247553,-1.5707963267948912,-44.36697044212363,-1.0 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark11(-72.15099948077814,-1.539584691100672,0.8097597469726809,-1.0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark11(-72.15836059034591,-1.0596379535908933,70.18120793151155,0.0 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark11(-72.24223588591887,-1.1839862142303814,-37.74218996870743,48.30573955830383 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark11(-72.24766069925434,-0.04344354719802135,1.5707963267948966,-59.43855051375733 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark11(-72.2699303210653,-0.9731545897190212,0.16307825609703114,2139.1084623262846 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark11(-7.2322243872584036,-1.5707963267948024,1.1102230246251565E-16,-10.87261971351592 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark11(-72.3831490163863,-0.6877777934675908,-89.6853460998858,1.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark11(-72.41920878898527,-1.5492603376531144,1.5707963267948977,-48.35168841862641 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark11(-7.245653547596282,-0.0689934665943874,-2.220446049250313E-16,2196.733360934938 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark11(-72.66438098260357,-1.5629784750255824,-94.11825276370969,-0.06073628479922949 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark11(-72.68691593481454,-1.5707963267948912,-3.174997214409255,-0.045058711164909615 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark11(-72.69626335513345,-1.4830188455680025,25.934545235019815,-0.5952329521677475 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark11(-72.7169940436267,-1.5102804671725372,-1.5707963267948968,54.376143052994635 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark11(-72.8134579844569,-0.3618812117431837,-49.813442581076195,2167.76428067623 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark11(-7.2822542118661655,-1.1204812739657202,-40.023581372565275,-1.0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark11(-7.284634624611089,-0.8584942575465746,-9.532660964002623,-1.0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark11(-72.92596928809462,-0.22288290280724965,-101.78206919238094,0.3159179906167048 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark11(72.98257560548393,0,0,0 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark11(-7.300929182773008,-0.004846565110262895,-1.5707963267948966,-0.920087073926029 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark11(-73.1400864015845,-1.3636185996641499,6.517911146359592,0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark11(-73.24520936598792,-1.2011118882317289,1.2126880121867585,0.9704977506109755 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark11(-73.31228837580538,-1.0591509808179214,0.0,1.0 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark11(-73.34753536728135,-0.7937461126603154,1.3270561659904023,-95.01628755101311 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark11(-73.34793663665397,-0.2934431383214388,76.66660537019737,5.3708557900581155 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark11(-73.36326465193793,-2.220446049250313E-16,-36.97728400295602,6.776263578034403E-21 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark11(-7.343682568632673,-0.4944894561127322,-74.92994054681685,-0.2170103956073115 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark11(-73.50323166245204,-0.7503453032074026,0.0,0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark11(-73.50770561550434,-1.563525130071981,-31.725617080615322,-1.0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark11(-73.51666581867312,-0.21532021983847002,-19.38165792229001,0.032000252841381485 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark11(-73.61850933258913,-1.570796326794886,63.3812331147663,0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark11(-73.71956748885013,-0.3974502218374451,-27.343292601274822,24.796078372822063 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark11(-73.87535311427608,-1.0182924376977476,-1.5707963267949054,0.9999999999999996 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark11(-73.95522379073495,-0.11061072663049742,-1.5707963267948966,-0.9596249298690207 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark11(-73.95983059507671,-1.1145167670046834,-34.15698842152595,-0.05634495832198298 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark11(-73.99116516177725,-0.09617296427349455,-1.5707963267948983,-50.15537002073265 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark11(-74.05328774113028,-1.2668320969310085,-78.48303968493701,0.6774562114010081 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark11(-74.13999100900816,-1.5707963267948948,-90.60041232951066,1.0 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark11(-74.14645783255334,-0.5183229326509267,95.28298175578033,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark11(-74.29976802781508,-1.5066954387750204,-0.8538818794770379,-1.0 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark11(-74.31461860882128,-1.5707963267948912,-100.0,-0.464931247247964 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark11(-74.41271142557522,-0.008655556151408783,95.90907078795962,-0.05995746214623913 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark11(-74.4593673394255,-7.105427357601002E-15,-80.57251014577886,-0.03248016608392598 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark11(-74.49554981253804,-0.5855723058835097,-77.02805766713985,-1.0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark11(-74.5053852419534,-7.105427357601002E-15,-48.27578243329312,51.67582449985245 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark11(-7.461266175858085,-1.1281496420927972,-1.5707963267948966,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark11(-74.62630328080729,-0.7460659983095862,-88.11993287477743,83.27564018139319 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark11(-7.465398491353624,-0.050136086253782075,0.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark11(-7.471129502623921,-0.9921071248187879,-1.5707963267948966,6.134485360759802 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark11(-74.8213740434251,-1.5707963267948912,-37.40533506034524,-0.5461279797816516 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark11(-74.87583822795457,-1.1257677104753705,64.18184464292682,1.0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark11(-74.88382717434187,-0.21073671597599336,0.0,-0.8899985097573019 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark11(-74.96161916983606,-0.4855468510336891,-72.52606447149519,-85.12375429802177 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark11(-74.99854439077933,-0.24947784915198135,0.0,1.0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark11(-75.00972050992011,-0.6753657254024168,1.5707963267948948,-0.9855044505973816 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark11(-75.03515405851557,-0.9947260382717606,-0.02114144062356363,-0.9845746790071005 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark11(-75.03946699835586,-1.5007558662381826,-11.752173401802679,-0.00493218386579404 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark11(-75.10212844414986,-1.5707963267948948,-7.725348768065202,-0.8331617105296694 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark11(-75.14228233113525,-1.570796326794877,-65.1669380804148,74.46116809782616 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark11(-75.15539989445168,-1.5707963267948948,-100.0,0.8839276522694489 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark11(-75.26871312563026,-0.3981349927354849,0.0,-0.47935570130828903 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark11(-75.29614802018534,-2.220446049250313E-16,0.9418071534431681,0.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark11(-75.32539708579019,-1.3593621134748828,0.0,-1.0 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark11(-75.39047813439701,-0.8802833662940553,3.552713678800501E-15,1.0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark11(-75.418686850142,-0.6994691018036008,1.4774125663630762,-21.837848220124158 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark11(-75.43211231558813,-0.3648541146727231,0.0,1.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark11(-75.4574909682238,-0.463900770172989,-31.888031524790712,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark11(-75.46129214562895,-0.017319448438589607,-39.618312420706886,1.0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark11(-75.59175823693715,-0.48415626442710336,-100.0,-43.41091198441001 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark11(-75.61707225365532,-1.3970571539356267,-69.69545799158321,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark11(-75.68497718085594,-1.3968422521594974,-67.29338368207237,1.0 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark11(-75.72113744278872,-0.7755152957299263,73.57316511741391,0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark11(-75.95364524431848,-1.52098685579109,-40.54466840283893,-2392.025914474093 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark11(-76.05096036827338,-0.2539579889516522,88.29738816903917,1.0 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark11(-7.605633762841684,-1.5707963267948957,-1.5707963267948966,0.9999999999999858 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark11(-76.14514816587804,-1.4761001860938618,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark11(-76.15847741164472,-1.2050422981652815,-44.12972887540103,1.0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark11(-76.2860659000317,-0.4272585656096588,-53.92885774961039,1.0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark11(-76.3382640316873,-0.7570498111524616,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark11(-7.635554852344405,-0.32617890794039844,12.566370614359172,0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark11(-76.3939691192452,-1.5707963267948948,-92.0161730129802,-2.3152047783152323 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark11(-76.47119402254012,-0.20275910989159485,-12.401692150210607,1.0 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark11(-76.51704835943524,-6.477056203461342E-15,-96.66465141737545,-0.0669713388234654 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark11(-76.53461035728039,-1.4934847156047653,-83.4578605979527,-0.7088676627078321 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark11(-76.5600648127451,-0.16192097203186506,0.0,0.37001693638238287 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark11(-76.56796407837447,-1.5707963267948948,-42.562252406608536,-1.0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark11(-7.664045989401174,-1.570796326794694,19.829061254085417,0.27203860414962944 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark11(-76.65958113674532,-0.6883887048821432,-1.5707963267948966,0.7170153034887454 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark11(-76.71310095841899,-1.4065215114410297,-1.5707963267948966,72.39378108281593 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark11(-76.87681884609985,-0.0030836650701462284,19.70079284136948,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark11(-7.68824477722524,-2.220446049250313E-16,-19.163163881287716,0.11676129046713413 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark11(-76.88405445328422,-1.2885896011399183,-3.2386157436127547,-0.1501146035446035 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark11(-76.96897493517241,-0.7530351134798394,0.0,-1.0 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark11(-76.99570323758395,-0.09353163122779051,-82.81579758143303,-1.0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark11(-77.00951595764116,-1.5707963267948948,-37.271254565716916,1.0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark11(-7.705583825907119,-0.04989423902549406,-32.8889361532559,-0.34851621533249705 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark11(-77.13972868820358,-1.3213462085184005,-0.13287912735059315,-0.1882998587550304 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark11(-77.16227807351935,-1.5707963267948912,45.124172073163464,0.7264281381900481 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark11(-77.17555475157984,-1.5707963267948912,-1.5707963267948966,0.9999999999999929 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark11(-77.18965976844501,-1.2690021598103236,-23.308573918289866,28.534274594373358 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark11(-77.22634402662796,-0.030198296123039498,0.1233650002800361,-0.5273679228991064 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark11(-77.24514109101187,-0.3972539273485529,-100.0,0.9644674324135071 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark11(-7.730611221753385,-1.4511890541192742,0.0,0.04313389809469545 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark11(-7.743251918698731,-3.926271884587985E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark11(-77.44388948276324,-4.3368086899420177E-19,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark11(-77.54381890742226,-1.5707963267948948,-3.479778357328982,-0.9547162998127448 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark11(-77.54458618904737,-0.3108885776978968,0.0,-0.8145120108007752 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark11(-77.63168260506309,-0.4776225357537851,-12.856010974757368,-26.667063643509167 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark11(-77.63611267551187,-1.076395751445991,-63.89999811579101,-1.0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark11(-77.68961459103659,-0.32672024940213434,-95.21784563672657,0.5253833159002115 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark11(-77.69924766110441,-8.881784197001252E-16,-1.5707963267949019,-1.2366860572682918E-23 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark11(-77.72808541537451,-1.1765024698402708,-88.8811512024851,0.0625525484745771 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark11(-78.01515123848924,-1.5707963267948963,-70.92574430487745,0.36208931357371726 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark11(-78.04179571020151,-0.09407270103799929,-81.22287296213796,0.5738568489014471 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark11(-78.05259053954299,-1.5707963267948961,0.0,0 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark11(-78.06007467918832,-8.881784197001252E-16,-81.62696973384786,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark11(-7.811114119315993,-1.5379861272044437,-50.278267939515466,-1.0 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark11(-78.11342439114841,-0.1235818500744723,-11.181054300072123,-1.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark11(-78.11403190846633,-0.7323071304943856,158.5992750142164,0.5329270662572632 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark11(-78.16035348045737,-1.4479070718747749,-30.89064001369685,54.45422980620961 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark11(-78.20884850679313,-0.8828676063413036,-1.277633926337809,0.03834309858200963 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark11(-78.232968868768,-1.3895704144298036,-26.888853266563828,-1.0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark11(-78.33056166704563,-1.5707963267948912,-56.033605889775195,1.0 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark11(-78.48118766787006,-4.4371274386478406E-16,1.5707963267948966,-5.951719220762143E-4 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark11(-78.48837512307585,-1.2916274203669869,-9.557854892399376,1.0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark11(-78.5279765755675,-0.4616944847339544,-4.418575084141587,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark11(-78.57237062110113,-0.020193056812766962,-67.42815342219185,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark11(-78.7038905654051,-0.807198173280312,-1.5707963267948966,1.0031544175452622 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark11(-78.7194436208416,-1.5707963267948963,-2.0266272704776043,-20.673563551587804 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark11(-78.97380555289752,-0.3879802542919054,-4.6810693739659275,37.194291459589834 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark11(-78.98389291862864,-0.42898555675503336,0.0,0.03704358181167017 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark11(-79.08058437571873,-0.2590637197605348,-0.059702283802619875,0.4406511495131158 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark11(-79.08090558722165,-0.5020099448379536,-97.23249206319713,49.015046173383524 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark11(-79.2227537308156,-0.9048183545060935,-95.28447496313986,-0.6599259948334562 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark11(-79.30629809508989,-0.8030425530337265,1.5707963267948966,0.6967558842423424 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark11(-79.37393004345395,-0.774813493285818,94.29270999849231,-1.0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark11(-79.4592401028639,-0.7146217372942277,0.0,47.462934902060724 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark11(-79.48245505947942,-1.2420630768475736,-1.6430497344364028,-1.724717305622228 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark11(-7.951982532788736,-1.0448936207425914,0.883807890838493,-1.0 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark11(-7.952287559480268,-1.5707963267948912,69.7098811044819,1.0 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark11(-79.52351196593497,-0.6838371189446341,-20.250362749575658,-0.06255252560138866 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark11(-7.957616931918554,-0.6644490555498374,-91.7743571982422,-1.0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark11(-79.58416529347703,-2.1014832595707202E-4,82.02831023607573,-1.0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark11(-79.59417771122479,-0.3109252439827745,0.3951307094567983,-48.55539268318978 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark11(-79.6046517264521,-1.4305932287454821,45.46971876375318,-1.0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark11(-79.62274625450897,-0.013729842614585097,-21.122391466095127,-23.229652761996377 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark11(-79.6271685056872,-0.348200781679838,12.73083298174875,0.8527831171525129 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark11(-7.964994818347776,-1.2934773661853634,-1.4783682054199048,-0.436833223330494 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark11(-79.65985046671543,-0.02844354183019604,-28.0988179275518,-76.49532801169545 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark11(-79.74297596237311,-1.1270462642719785,1.5707963267948912,-0.9999999999999927 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark11(-79.77064318621139,-0.5729307555226419,-13.429006167233965,2239.5634900881414 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark11(-79.77822031329896,-1.0332600112981716,-16.152084164959547,83.04873400473386 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark11(-79.81167901494396,-0.4894728923088148,1.5707963267948966,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark11(-79.84447236576914,-1.195979510901309,-96.38011046498227,-1.0 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark11(-7.9917502234928826,-4.440892098500626E-16,1.5707963267948966,0.34109401747626694 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark11(-79.96124985170344,-0.010350282466886816,-1.5707963267949054,1.0000201987491542 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark11(-79.96785560341263,-0.01566112050841333,1.5707963267948966,0.04237636943037618 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark11(-80.01208542499853,-0.6513521730484442,1.5707963267948948,-10.942328175209578 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark11(-80.07667328760243,-0.8170088496652224,-0.05227288758540756,0.36427501309396154 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark11(-80.10103260702813,-1.5707963267948961,-29.25131660159392,0.037796417371494084 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark11(-80.17695476648412,-0.6708949492487285,0.0,-1.2934660840192542 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark11(-80.25924793539728,-1.1339180008260628,-52.71662655347164,1.0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark11(-8.031067024854329,-1.5707963267948948,-15.463683021777527,0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark11(-8.03328355091828,0.0,0,0 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark11(-80.37819050977804,-0.4486115276282887,-73.12420635199854,0.14576461690654763 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark11(-80.43043393317583,-1.1329060299467528,0.0,-1.0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark11(-80.49834606330614,-0.4749069004122388,0.1264006271731697,97.54396476312799 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark11(-80.57440504311727,-0.9237358210305974,0.0,1.2994262207056124E-113 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark11(-80.60559684971616,-1.1171181794114773,50.96479232318546,1.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark11(-80.65077067753585,-1.4944995680494932,-31.85826169837268,0.04011181464126286 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark11(-80.7177805479092,-5.551115123125783E-17,-90.27577337128342,-0.06280184070408545 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark11(-8.080874525554663,-1.3014701054574274,-22.09881590357645,-99.02301980969239 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark11(-80.85659517186032,-0.24436278109223153,-8.775467912661526,1.0 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark11(-80.93074750284455,-0.8202085710897563,-1.3673184875042543,-69.21217295106585 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark11(-8.093330047587749,-0.008006833081061426,-0.40032390574003124,1.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark11(-81.09499186309455,-1.5150206231464067,-88.3902725230303,0.0625963306547922 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark11(-8.112927300367868,-0.8139749599844708,-17.965889961079462,-1.0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark11(-8.116159524275865,-8.047464626628614E-4,32.91865516419864,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark11(-8.12329320463736,-1.3337716490899014,-1.5707963267948983,0.0 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark11(-81.26035837409911,-1.3641933433180664,70.65397804145303,43.88266314132804 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark11(-81.27023388884564,-0.41467052673457905,-67.57025190103403,-1.0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark11(-81.2949668705166,-0.5968246004217382,-70.81386310428755,0.603650923625147 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark11(-8.129802475936517,-0.0612672612452358,64.31285767773853,-30.446925826030053 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark11(-81.37905683765453,-1.438548157314222,26.6974630990904,-0.2074822982201424 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark11(-81.5730880845452,-1.1205055666498596,-91.193751713932,1.000000103112775 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark11(-81.58933690603868,-0.8668283005081124,-0.7084579204604409,-80.74332195776219 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark11(-81.58970286133453,-0.07264677177682781,25.409138024962502,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark11(-81.61976890346341,-1.304490290297643,-46.29676848224747,86.35860977493022 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark11(-81.63181730910685,-1.0081747134842711,0.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark11(-81.69873403987081,-2.220446049250313E-16,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark11(-81.72938957865155,-1.5707963267948957,-78.52932348184666,27.585190520471812 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark11(-81.79813281712481,-0.6630106337026682,-130.1591515978736,71.19782034718727 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark11(-81.80899775940478,-0.1864148082988797,-45.334807275571485,2176.7577158280315 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark11(-81.80934730486379,-0.7253509454208693,-37.786309080070765,0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark11(-81.84442243400547,-0.3147306959238019,1.5698564744014225,1.0 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark11(-81.84464338897283,-0.7857776332852365,-2.2723293006364176,-22.85476944001456 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark11(-81.90943399847434,-0.2485465604237494,-93.62208992595936,23.919028012649576 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark11(-81.96171449477563,-1.560854562004791,1.5707963267948983,-0.11182950807607939 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark11(-81.99128862724484,-0.13858945931151556,39.13461766575094,-0.9096846084008545 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark11(-82.00574637530127,-1.5020620287972122,-84.72072681192975,-9.83105272411639 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark11(-82.02858782854915,-1.5707963267948912,-21.108519757527628,-46.581993372973976 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark11(-82.0341532759179,-0.1234510134467337,-64.74026605852993,0.5416543088190062 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark11(-8.204196285940633,-0.1498262320463582,-30.33027736455019,0.05006198349904645 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark11(-82.16899167568744,-0.35129641993021765,20.24723523943183,-0.027644111801113813 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark11(-82.17316849565874,-0.9433564918606085,-86.81119498827206,-0.735205703807196 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark11(-8.234159126848821,-1.3736945508228473E-14,-15.952346280088175,-1.0000000000000002 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark11(-82.36806609790155,-1.2103117129232537,-0.4305791688760819,11.526859705112056 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark11(-82.42447114446834,-0.6504435309885741,-36.333614446029806,8.127961105010833 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark11(-82.48757308962418,-1.0674063552279849,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark11(-82.48861452035031,-0.044047128303973435,0.97158831309514,1.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark11(-82.50221252813067,-1.5707963267948963,-77.96758014240031,-96.74414361732605 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark11(-8.258875168990071,-1.5707963267948963,-21.721716178468156,-0.015678950701713767 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark11(-82.63763520210846,-1.543140849895483,0.0715548327233416,-27.039732440468175 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark11(-82.71733715688153,-0.25582520428784505,-70.91018815365894,-0.01 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark11(-82.7237094608186,-1.0563434500270161,-33.0208600221996,36.29626859244357 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark11(-82.83196522173692,-0.5339868880557788,1.5707963267948966,-1.000000000000007 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark11(-82.85028861926638,-0.03290012489458032,-44.58434241213662,0.19630844287310356 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark11(-83.26297254366219,-0.988650998142619,0.05674799788343254,-16.56761263000158 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark11(-83.3081086713868,-0.8678630807212933,-38.70496479308809,0.9421689621406963 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark11(-83.33384588462785,-0.020127605797114825,-99.29122140061898,-0.03007817961800771 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark11(-83.35555257982219,-1.4698064544580682,-61.86829534863242,5.293955920339377E-23 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark11(-83.39191041165499,-0.3380023691269542,-36.52292617098303,-1.0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark11(-83.55553611545977,-0.40076020097930054,-61.26106232922269,0 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark11(-83.56988031220158,-1.5311739172876742,-7.785628753068025,-0.7965414922464147 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark11(-83.65940074682052,-1.5707963267948963,0.0,-1.0000074526368603 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark11(-8.367530535572655,-0.42137678132229045,-49.80318494995246,-1.0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark11(-83.70244287381213,-0.11183449932342748,1.3071170845870324,-43.838818947151914 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark11(-83.70362313525546,-0.5451761615704616,-66.27196796576375,136.46396186722225 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark11(-83.75435736390219,-1.1866521850033156,-90.76099067828365,1.0 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark11(-83.82794688318138,-1.4657008870154815,-94.78880569550532,100.0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark11(-83.88542787401128,-1.2593258064940187,-71.35728329065809,-1.0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark11(-8.391910310215115,-0.9154957503178132,-48.40526055386718,-35.128289336074445 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark11(-83.92094681773092,-1.268773159643704,-107.61394171381906,0 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark11(-83.94533004671727,-1.5282935369058492,-3.1393032918361925,-33.69960415044146 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark11(-83.98790124259425,-1.426719719470197,-2.5407445445591024,6.681911775230489E-52 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark11(-84.02958162696439,-1.3405445811717858,-12.952692613717815,0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark11(84.14001529481979,0,0,0 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark11(-84.1480043617822,-0.17976320595358186,-74.78734213050865,0.01936850361081284 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark11(-84.16410591438745,-0.45997836116389124,-98.26566400333125,1.0 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark11(-84.24629541132532,-1.5596224931416212,-34.457850855250705,0.5522744562047416 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark11(-8.425512850924072,-1.5707963267948963,1.5707963267948948,-0.5709291017900284 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark11(-84.25821164588832,-1.560951849081269,-1.5707963267948983,-12.034995994581726 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark11(-84.36001864211384,-0.6048964564436403,-66.99497284740428,1.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark11(-84.52450869274557,-0.7673822402031338,-12.584866421135516,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark11(-84.53728754905028,-0.026942200493740076,19.2004615863173,45.16064993476476 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark11(-84.54024116150363,-2.220446049250313E-16,-74.28724055664053,-0.9999999999999999 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark11(-84.58778763458272,-23.26242681537383,0,0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark11(-84.59857214408741,-0.16160925754398248,-55.08667126702279,0.0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark11(-84.61856521713128,-1.5707963267948912,26.159934758120613,-8.008332380732404E-146 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark11(-84.63059238209321,-0.5168595116487908,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark11(-84.71120882149367,-0.8180917042350145,-30.300209153861363,-12.173435343795703 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark11(-84.72596116471831,-0.4027680152499613,-1.5707963267948966,-54.59055926247829 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark11(-84.7447044928211,-1.5707963267946035,82.55205890841316,-44.11076967712497 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark11(-84.82206319631233,-1.5707963267948957,-18.535411179116295,-0.03547518205177544 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark11(-84.82249036248172,-0.48689182373188467,-4.178508308440755,0.9604603052559935 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark11(-8.484283358418775,-1.5707963267948912,0.5492945557785414,0.6745359131981092 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark11(-8.488003360050357,0,0,0 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark11(-84.98956017108743,-0.11613813934378925,-60.09327450184776,10.036787592101277 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark11(-85.06628958608557,-0.2889974252778158,1.3505159451741522,0.008350290488386036 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark11(-85.10689511794236,-0.0329019456166299,0.700395040240656,-52.651695486635504 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark11(-8.512803023880934,-1.3112151003486918,-11.523512332678125,1.0 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark11(-8.516741988278115,-1.5707963267948963,-65.18082947523075,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark11(-85.32332074802125,-1.250493591542578,-38.971677944129326,5.421010862427522E-20 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark11(-85.41777255650801,-0.5665955517741924,31.847905298795993,11.272913556963989 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark11(85.42756929651867,56.601849859007274,71.82121985519078,0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark11(-85.5080470375521,-1.5404723028794207,-18.204332169129643,9.845440041430315 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark11(-85.50977499340726,-1.0136485546462999,-1.473093874194829,1.0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark11(-85.51221103097058,-1.5707963267948788,-73.38651101148432,80.44342914058714 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark11(-85.5881722689795,-0.7964192384544735,1.1893377433320633,0.9999999999999986 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark11(-85.59130994850119,-0.37629800841620376,-1.5707963267948983,2086.6917490388823 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark11(-85.63986525737484,-1.5531656433147034,-61.54811431120899,1.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark11(-85.64181292812651,-0.7490666849270013,-2.220446049250313E-16,0.1683374578101393 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark11(-85.70584434454409,-0.48712553314460094,-100.0,1.0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark11(-85.84265287957442,-0.724170071082103,-21.053320317095654,-0.1309905170636958 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark11(-85.94376673281452,-0.9294714738698715,-48.220848847063145,-0.6344551114438662 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark11(-86.05567953217468,-0.34591160716475366,-1.6189278804448186,0.9999999999999991 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark11(-86.0818790881277,-1.5707963267948963,-58.845699827718185,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark11(-86.2085589212079,-0.3016468979821315,-44.761439124522795,0.011704486762173588 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark11(-86.23324469129291,-0.8048632401067856,-7.598673559179071,-1.544151122518878 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark11(-86.26762754672488,-1.5707963267948963,26.612928190069248,1.0 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark11(-86.46329270957153,-1.5707963267948901,0.0,2070.428971614578 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark11(-86.52467683297932,-1.3358975957523809,69.8175269738291,-0.375377080103512 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark11(-86.61761607592071,-0.4583243176975036,-16.454914713338127,0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark11(-86.62502301432491,-1.209778467196439,95.6088672893675,24.40546066871307 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark11(-86.64413092496382,-0.7164227917344563,-136.4442188616323,-16.755577637651854 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark11(-86.7188500915371,-1.1945545611263126,-23.985110437299195,-0.36212727096832736 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark11(-86.72165158837234,-1.5698006662767137,-2.4489470046856354,-1.0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark11(-86.751598502921,-1.1353590642416975,2.7479628947138792,0 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark11(-86.85064743891925,-0.16684417368868534,83.08074393360573,-1.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark11(-86.86358907852757,-1.415365756353631,1.525917984259371,-1.0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark11(-86.8770897596404,-1.3752141991321682,-11.881704697317847,-1.0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark11(-86.93532961327737,-1.5381678892953736,-2.6089935990860047,-0.42114451781426465 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark11(-87.01999903950308,-0.47858408826912224,-1.5707963267948966,-0.00283943635754344 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark11(-8.70542052074464,-1.4583276666659348,45.40076472541032,0.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark11(-87.11288881052963,-1.27698604568522,-66.44430460180419,8.881784197001252E-16 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark11(-87.16222600327708,-1.5707963267948912,-40.74052920219056,-1.0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark11(-87.18690998793375,-0.007123263987705468,53.08294744224529,0.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark11(-87.20837025933788,-0.46032184068584464,-1.5707963267948966,56.693733905314254 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark11(-87.25944956904765,-8.881784197001252E-16,1.194262124094351,-1.0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark11(-87.26050121259198,-1.0183674366869866,-0.6570731043019765,3.0260858197234084 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark11(-87.32525857121283,-0.14988563192068005,1.5707963267948966,53.88028369644189 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark11(-87.41527094002353,-1.5686431554409725,1.5707963267948966,0.9265701304097245 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark11(-87.45768262706058,-1.3972969990901423,-33.49426190270766,-0.930426476961968 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark11(-87.55571200996448,-0.033020233210132734,0.0,1.0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark11(-87.55882585847718,-0.1894271721507863,-3.552713678800501E-15,65.4536041831173 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark11(-8.758652092053126,-1.5707963267948912,-60.083361677051194,0.7969379462198907 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark11(-87.64073806011474,-1.0387191278350478,-65.91472230764946,-0.7484034220552225 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark11(-8.765016420411726,-0.9507673459675235,1.5707963267948966,-0.7568424940288071 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark11(-87.69038275718214,-0.2401268636993814,-1.1577010409537078,-1.0 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark11(-87.70731215007149,-0.8201952131575037,-44.26884511963978,-0.5998006440139969 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark11(-87.7422822950423,-0.45944112576850693,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark11(-87.75486473560927,-0.26539539408975044,88.29641676511012,-1.0 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark11(-87.83159038291369,-1.3222249544172515,0.0,4.25377669920739 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark11(-87.84152652674769,-1.5048394210582337,0.0,-28.68016388602284 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark11(-8.785927700871355,-0.2530672193382273,-54.18507864470429,0.989702855471761 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark11(-87.88595836464167,-1.5707963267948948,94.59947437519432,22.436885192988893 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark11(-87.99271560468785,-1.5707963267948912,-1.5707963267948954,-0.9999999999999991 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark11(-8.806227086087622,-1.399363101108812,-1.2967218410047732,0.015668373603982585 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark11(-88.08868595512175,-0.11250575375369307,-3.5401437814664165,-1.0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark11(-88.09375095310189,-0.3967808270649025,-213.99557580691987,1.0 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark11(-88.17669353873916,-0.9958040587331451,0.0,0.8433447218325066 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark11(-8.820726402525198,-0.02752374221335367,0.19899599665249967,-2.845888959751441E-17 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark11(-88.32295779126275,-0.12783654568873498,-100.0,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark11(-88.33163131126832,-0.8830037162738327,1.5707963267948966,47.45832062224122 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark11(-88.46081564619415,-0.006206692958309334,0.8723242503475237,-49.169405254177676 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark11(-88.50429463634454,-1.324839959671002,-10.784364985391123,8.552847072295026E-50 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark11(-88.5602611993223,-0.3372969916653341,-20.13637392037436,-1.0001169123744351 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark11(-88.76809933390781,-1.4638126261511593,-32.94454555968122,-22.181866887263723 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark11(-88.8713922202231,-1.079296395862058,-17.545474855526578,-0.23851459874248704 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark11(-8.88759599638666,-0.33599662896979704,0.0,0.0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark11(-89.02500385883418,-1.5707963267948948,-5.773109506808252,0.9999999999999999 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark11(-89.04012470704443,-0.5000164407719367,0.08768120917762173,1.0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark11(-89.04764776317961,-1.0622477185303125,-0.31290862712219,0 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark11(-89.08828533951232,-1.43174831380693,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark11(-89.19725618084698,-0.14598766934830237,44.20631932329937,0.9527904423271555 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark11(-89.25187729107266,-0.9452819196770488,-100.0,0.011243372480066047 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark11(-8.945506092356046,-0.17527913187920774,-29.505880939134585,-1.0096332960776295 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark11(-89.68118189208116,-0.8650856393291928,1.5707963267948966,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark11(-89.6879174537244,-0.33025350642410634,-0.2065989325530173,-0.8367352493452092 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark11(-89.76052812887062,-1.3195548440988745,-39.215940518430024,34.262017855822364 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark11(-89.83053174579231,-0.8713972432073553,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark11(-89.91803128745127,-0.4832059073945345,64.74897166409039,-1.0 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark11(-89.94088324918424,-0.5288665123750154,-71.61255948623418,-0.9999999999999996 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark11(-8.996564514744957,-1.5707963267948963,-1.0205865571684718,-1.0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark11(-90.03815028412721,-0.07552792519779289,-73.61615496408047,-1.0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark11(-90.07488375093328,-1.2584833177228596,37.807197176184275,-0.9892058806278574 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark11(-90.08436587947917,-0.5532826152098875,31.70613570770726,38.136928543975614 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark11(-90.09091419478774,-1.3225214184740022,-84.25047227538568,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark11(-90.1884131985703,-0.38305951511552855,-1.5707963267948966,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark11(-90.58932380311923,-0.001629921098309639,-99.11032470675956,0.02352613496172533 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark11(-90.61335070542708,-0.08033355645316753,-52.50613806211548,96.71007406905832 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark11(-90.67258709171057,-0.9476987066661291,-39.167125066443,0.23104732699380948 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark11(-90.71711286481869,-1.5707963267948963,-0.8594690464034725,-1.0046287692236366 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark11(-9.072535019723446,-0.9252891512890358,-3.2530076635763407,76.99145889097215 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark11(-90.81813651559997,-0.001419686041344903,1.4772072571879562,-0.2802064396424164 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark11(-90.84786838270541,-1.5707963267948961,-73.37964065888262,-40.69487410787616 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark11(-90.85257358212098,-0.005532051698133221,-1.2923475534041478,1.0 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark11(-90.87597756607968,-1.42455069552324,-1.4232128738811998,1.0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark11(-90.91043738603742,-1.0227028823677733,1.5707963267948966,-97.72116397545457 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark11(-90.92166484073991,-0.9812902328206194,64.69794548513724,-1.0 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark11(-90.9437626254615,-0.8070480383060006,-32.70187786963918,0.9780610897432581 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark11(-90.98648949961584,-1.5707963267948961,-72.74640338762731,-40.97073342574623 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark11(-91.00461595162466,-0.39038951279579326,-88.51090104026602,-1.0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark11(-91.02729433896575,-0.18800528540578298,-100.0,-1.0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark11(-91.18593933591667,-1.5427919605183582,-1.6600540356348716,-0.9370857327646347 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark11(-91.26364653648659,-0.3992421493300288,-45.26049448059737,43.444058599971186 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark11(-91.34034486180445,-0.6957873753460145,0.0,0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark11(-9.137107684879808,-0.7533807183980303,-58.39546124791541,0.0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark11(-91.38999523715847,-0.07683606486905023,31.705470106806356,-22.11722114338366 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark11(-91.4686061351776,-1.5707963267948912,-52.115935238507035,0.21690599947352518 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark11(-91.50556908814502,-1.5616103801235992,-42.555996258285674,1.0000000000000022 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark11(-91.51476172222789,-1.5707963267948948,-47.01722350970773,1.0 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark11(-9.152951638172503,-0.0667186249148175,0.045588483262922086,-58.37617005903326 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark11(-91.63922849465784,-1.0831431596856764,0.0,-1.0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark11(-91.65636447329278,-1.3812738773438094,-22.34732957562877,0.6175418460186165 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark11(-9.171852617565149,-0.14374177495547552,-31.704334066516765,0.9187409980144547 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark11(-91.74183326750749,-0.14746836453507006,58.65656357166474,-0.9652847143953975 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark11(-91.97054861348428,-0.03562169897580805,-49.84902048822884,-0.9359903481329996 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark11(-92.01889239316428,-0.6371979342168872,0.0,86.18775169733067 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark11(-92.08442233384596,-0.8142204170914581,9.20162236602463,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark11(-92.167101065428,-0.1986357347283212,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark11(-92.3187969709284,-1.0095953043382622,-39.85915321962459,67.10617705035509 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark11(-92.3234163971495,-0.5272453439161664,-18.057577991619354,0.3581045440275444 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark11(-9.242283303352224,-2.045439378300608E-15,1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark11(-92.59517494599959,-0.22731759048992117,-23.681402701068897,-1.0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark11(-92.6053755447739,-1.4210854715202004E-14,19.82131021888563,-1.0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark11(-92.67075025507145,-1.0020831278050464,-44.04193121361364,-75.94659761661009 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark11(-92.70618467933642,-7.105427357601002E-15,71.8363957881597,-0.19010938059516747 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark11(-92.72049704432035,-0.5245589006655846,57.98214447821619,-0.9774751098192134 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark11(-92.76000093496441,-0.7135432810354857,1.5707963267948963,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark11(-9.298994630518953,-0.22334805531175284,-0.24041478593452184,-65.86604858893043 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark11(-93.03361718852784,-0.3502484563160375,-14.446427475738318,36.40524385275932 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark11(-9.335396236660635,-1.3216829210150158,1.5707963267948966,-0.9999999999999997 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark11(-93.36136653036658,-1.5707963267948912,1.8919403802629517,-0.35173633325474896 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark11(-93.37466004900072,-1.570251994287434,-4.7045703029000965,-0.8496606401433585 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark11(-93.38899827504417,-0.007556121185011373,0.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark11(-93.39027098292695,-0.052483243480835995,32.4368695954457,-27.217634946087657 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark11(-93.46608282424121,-1.5707963267948961,0.4408688306262657,22.570212928009173 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark11(-93.4956402138971,-0.6992336120656825,26.071535415504613,0.0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark11(-93.52299522797196,-0.4624651753691972,44.13211362318549,-1.2683139185651058 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark11(-9.35696703970372,-1.0882657340877246,-73.08180086686208,-1.0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark11(-93.70785577642508,-0.29009414150165647,-68.85783444010082,-0.9002081329763207 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark11(-93.84203333798064,-0.03310109223265195,-37.805183512389604,-0.2935726803942438 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark11(-9.385580356750694,-0.18483594760360078,-37.70039617294716,-1.0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark11(-93.86849948965681,-3.552713678800501E-15,5.245191719484043E-7,0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark11(-93.90852535205161,-1.5701411509364676,-67.18117847980898,0.22424551155355044 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark11(-94.0990734272284,-1.5707963267948961,1.5707963267948966,-1.0000060122392258 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark11(-9.412115052656004,-1.5707963267948948,1.5707963267948966,1.5423487136658458E-179 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark11(-9.412313586870882,-0.13763578080950506,2.9595406231858163,-27.497427023498716 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark11(-94.19329527343186,-0.7550169932159811,-34.58462496702395,1.0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark11(-94.23463511993043,-6.184215403977067E-4,69.62459709869921,0.9991930487395546 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark11(-94.30646724847087,-3.552713678800501E-15,-2488.2212272050974,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark11(-94.32276838108037,-2.220446049250313E-16,0.42978128090127843,-0.04875421591557316 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark11(-94.36138561517862,-0.09863625863322872,-57.8147405318782,-0.03850460847157622 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark11(-94.438426583234,-0.8727939103792733,-74.77182829389659,1.0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark11(-94.60454026611202,-1.1895174499888141,44.502889837205274,-1.0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark11(-94.62895285786527,-1.5286763786917532,-26.596633079233925,-0.9448905920809878 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark11(-94.64494531087725,-0.8307313837767818,1.5707963267948966,61.06455914615253 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark11(-94.70150110452866,-1.5479834383674036,-1.5707963267948963,1.0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark11(-94.75504956622294,-1.5707963267948273,-12.514649885348476,95.02588315791189 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark11(-94.75722804169234,-1.5707963267948948,-86.51687568901765,-13.857942184783337 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark11(-9.476972736923045,-1.7763568394002505E-15,1.5707963267948972,0 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark11(-94.81472616593439,-0.221126430551152,-45.02413504275606,48.40612449261795 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark11(-9.482558592093199,0,0,0 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark11(-94.86942944945982,-0.6628596286254591,1.1980959965446971,71.62134512878274 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark11(-94.8863648550167,-0.11619727274483818,75.65306149278243,-1.0 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark11(-94.9947138101624,-1.5707963267948954,-7.014643815174047,-1.0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark11(-95.02082675344406,-0.03576997421450123,-135.49315149599374,-202.23331382387042 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark11(-95.02139927852922,-0.36957271877144215,-10.545269394569397,-21.85800444878963 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark11(-95.05568761618828,-0.23462354905294736,88.23712363903311,0.9949486539236247 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark11(-95.06724080743795,-0.07216534693872192,-36.94973036833599,1.0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark11(-95.20282579828826,-1.4884223485132246,-100.0,0.05990527823118802 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark11(-95.27921738483597,-0.6603037839691552,-17.278759594743864,0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark11(-95.34643506040794,-1.519887421742549,-151.9016140139076,-13.87397352771545 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark11(-95.34971420062952,-1.5707963267948957,95.58879514558261,0.7404374183822044 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark11(-95.36403697775451,-0.6224408916211264,-19.783797528876335,-37.763511812917926 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark11(-95.4859787776378,-1.5707963267948948,1.5707963267948966,-13.811571664532861 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark11(-95.60063452226733,-1.1024579632771199,-8.881784197001252E-16,0.6911880179041898 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark11(-95.70063657279802,-1.5566986486876941,0.0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark11(-9.583953892216453,-0.15848770441186844,-95.66611192590781,-28.724238865860798 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark11(-95.98098472977064,-0.7963146202026997,-0.6163051323092361,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark11(-95.99224850900588,-0.3048315032932682,-45.146791895283066,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark11(-96.04771111075917,-0.3543438761861796,-3.473024066644445,-22.417960908837458 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark11(-96.0950336874778,-0.4844640561219462,-88.40394066105986,0.13436043782900275 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark11(-96.1205970068113,-1.356009709936116,-45.300308584505544,-897.8966722512632 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark11(-96.13256454518358,-1.5516743693454558,-8.155829782076381,-28.68339976507619 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark11(-96.21147835578334,-0.5450621355748009,1.5003558663721637,48.483169346615085 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark11(-96.21974660156678,-8.881784197001252E-16,-44.523700707019806,1.0 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark11(-96.22942457997421,-0.1037767790509827,-93.96169202295061,1.0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark11(-96.23219007315983,-1.564146123229735,-85.09838417337423,1.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark11(-96.24449868841786,-1.2270832555902536,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark11(-96.27132427135504,-1.4273651313432354,-91.01406749087505,0.06257574988903289 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark11(-96.36164915957407,-0.017348258348396553,-65.58203416936955,-1.0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark11(-96.38922716228168,-0.8129924492994576,0.0,-6.096021078878234 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark11(-96.47073629991249,-0.5150530583760631,38.77979978304745,-1.0000000000000018 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark11(-96.47274674874713,-0.2344378102817508,88.24296092898851,-23.109017490303202 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark11(-9.654874858914724,-0.18587295502937046,-29.12955971046034,-84.97356442056616 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark11(-96.57432872433758,-1.4827647064002099,-3.3531791791930736,-0.9588832035009467 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark11(-96.58659336657155,-0.44066274663732696,0.005370409202491971,0.45249569443815496 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark11(-96.64516576262255,-0.668413613247921,-74.79119264309668,84.58165220379945 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark11(-9.666571856430563,-0.8554675871190474,52.94201051486744,-1.0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark11(-96.71052507555146,-1.5707963267948948,45.083274450782156,1.0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark11(-96.72494274650484,-0.3295743436664904,-74.65614103075569,-1.000000467665884 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark11(-96.73463768588972,-0.12004754967639862,-83.96182974197401,1.0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark11(-96.7503825688491,-0.4510574675479618,1.5707963267948966,-1.0000000000000009 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark11(-96.78848637188256,-0.5776218926276072,-88.41588259310888,1.0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark11(-97.0355212448691,-1.084443364113457,-99.24130355496952,-1.0000000000000002 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark11(-97.07718814820828,-1.5391574492392621,-99.01745795210192,-0.3550505297815213 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark11(-9.710619352448848,-1.2424291806642396,-36.77862856642982,0.5414533271513053 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark11(-97.27092137220686,-1.302383363722057,-45.25573305685866,-0.9142641268216245 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark11(-97.4231148383827,-1.3881396058269508,-100.0,-0.483007132118403 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark11(-97.4605524456834,-1.4849714542378718,75.86727098412139,-1.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark11(-97.48237089065309,-0.6485010293759867,-5.2782148930848365,0.6190282605811495 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark11(-97.52085980403739,-0.007884610081310998,1.5707963267948963,5.306299356636049E-97 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark11(-97.54121597821519,-0.05573805139634567,0.0,1.0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark11(-97.64903105603378,-0.5595614079353294,1.5707963267948966,0.7050886369170684 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark11(-97.69622282761858,-0.193417609722325,1.5707963267948966,-2335.1860486681894 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark11(-97.70273412993117,-0.6407214679852969,-56.44519687947913,-64.30817475747186 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark11(-97.7386737481787,-1.570796326794639,-1.348497804714814,0.8267067227260501 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark11(-97.78093685974372,-1.5361547925201529,-0.3053730900383077,-5.006560657294016E-16 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark11(-97.7836377512755,-1.312180308729298,26.54796044081975,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark11(-97.8240079667274,-1.5473135224463122,-3.3756118703153755,28.974850892789533 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark11(-97.85387863582982,-1.43014045171293,-40.818440373431145,-1.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark11(-97.90234643501846,-1.5004478505696541,0.4985466228504706,-1.0 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark11(-97.9263846747624,-0.41397733163642014,1.5707963267948966,-27.864524714505706 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark11(-97.95097153678526,-0.07392172638667915,-67.04917963416179,1.0 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark11(-97.99741153457687,-0.32244334658809765,-1.5096564460182103,1.0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark11(-9.801686242779851,-1.3398218291360955,-70.4712117963156,-1.0 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark11(-9.804997807916278,-1.0044729343425138,-100.0,1.0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark11(-98.0602981322671,-1.3113920377016648,-21.069735224525346,0.0 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark11(-98.16506484104494,-1.5272390762123937,0.6705193487549373,-1.0 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark11(-98.16662486705572,-0.9760816344259808,-1.6734730081827536,0.9445142260489434 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark11(-9.823614727877642,-0.015740246063157846,-53.25142744745708,0.6096973341704184 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark11(-98.25771480610996,-0.6517904211057141,95.76415748088844,-1.0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark11(-98.30578742534627,-0.5437540614567002,-72.64525125271152,-2149.171767533602 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark11(-98.31294008405547,-1.5640862538844633,-65.22714495847042,0.9999999999999999 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark11(-98.3191041580025,-0.07577745862657648,-14.429615369139526,2.710505431213761E-20 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark11(-9.833493633161437,-1.146487622485439,-3.8657971452952125,0.3684188454141569 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark11(-98.36230559905688,-0.6309922080042867,-88.35034050790708,1.0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark11(-98.37687891960688,-0.20863318800304897,-55.325520163014396,29.966909431709748 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark11(-98.37917169016393,-0.798879595396135,37.78959476797809,0.0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark11(-98.38280963330266,-1.5707963267948948,-1.5707963267948966,79.17040035715883 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark11(-98.61495499969686,-1.5707963267948912,-1.5707963267948966,-0.7261501723786103 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark11(-98.76107446631349,-1.167884844165278,-1.5707963267948966,-2.3408381773460992E-97 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark11(-98.7667855506166,-1.4720273681482217,76.79801224878832,1.0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark11(-98.84084106062889,-1.4961893816272696,-13.228537025508984,-1.0 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark11(-98.98982666389443,-1.527037736453542,31.54375814490279,1.0 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark11(-98.99714486469456,-3.552713678800501E-15,0.0,-55.126937030026156 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark11(-99.02176059123568,-7.105427357601002E-15,-97.99943081623313,53.25927181279126 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark11(-99.02767439156617,-0.0014501777008397998,-1.5707963267948966,0.14631479216102417 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark11(-99.08264337859931,-0.974380579204149,-76.46438929577714,1.0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark11(-99.14798846635718,-1.45278085524326,-10.617462097840468,81.76039503684461 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark11(-99.15615833073443,-0.9505187370047689,0.0,-65.28009908981183 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark11(-99.18756361995014,-1.5707963267948593,-45.39404583927682,0.17844924372239301 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark11(-99.19860663987129,-1.5704493959163615,7.280645577334557,-0.0023912295316550003 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark11(-9.923202861537813,-1.493052079026267,83.76764574837429,-0.8125306661440476 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark11(-99.306314061407,-0.12614598601133054,-1.5707963267948966,0.04270769852379348 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark11(-99.33314479960858,-0.9095180535407555,-0.22692339210745116,1.0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark11(-99.39986634386098,-22.63591657715969,0,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark11(-99.41867321155217,-0.7029701225493862,-29.792052798303324,0.2680310775334309 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark11(-99.51741635179054,-1.311686312844492,-100.0,-1.8991135491519597E-65 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark11(-99.523412825955,-2.220446049250313E-16,1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark11(-99.54454396970283,-1.5707963267948961,59.25840538999705,-0.7165499142441771 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark11(-99.65969354646987,-0.07891840885018667,-74.84181282919498,0.190019482300607 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark11(-99.69802788413138,-1.330596510584874,0.416530700643892,-0.3620984028865648 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark11(-9.982376418541108,-1.2582893792610252,69.65650352173613,-0.4743518813518411 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark11(-99.87759318663865,-1.570796326794867,-0.9055126236500558,1.0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark11(-99.97377889824047,-0.48499495775589174,0.5521283408770624,0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark11(-99.99381306007356,-1.543940215340847,1.5707963267948966,-0.3624271895054807 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999903412,-0.7352671527591657,-15.184995684696188,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark11(-99.99999999999996,-2.7755575615628914E-17,1.5707963267948966,1.582770520235438E-26 ) ;
  }

  @Test
  public void test2400() {
//    	UnSolved;
  }
}
