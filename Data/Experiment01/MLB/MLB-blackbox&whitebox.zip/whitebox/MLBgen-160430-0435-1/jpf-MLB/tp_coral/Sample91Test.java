import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-0.0010500883076733647,87.96564438882189 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(-0.00229735565663235,91.10388959856068 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-0.005686564674563792,-43.97661058558254 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark91(-0.008763881928559935,-50.25671857550813 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark91(-0.009913576455121254,91.21718990242954 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark91(-0.014598625020504793,65.95529973642162 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark91(-0.015389531947496593,-38.63458124908805 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark91(-0.015417680642987363,1.5707963267948966 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark91(-0.015469006817227678,-47.139553432164185 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark91(-0.020760397521286666,30.043779835026072 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark91(-0.028209940654037913,28.2461239416541 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark91(-0.03664752720355236,88.00124182771776 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark91(-0.04129551129438507,15.666660716263795 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark91(-0.04351257621493501,-62.77849301589126 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark91(-0.04915526650697544,0.04915526650697544 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark91(-0.0501578175551882,6.333343124734775 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark91(-0.0559312799728293,-9.487449211295957 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark91(-0.06854504579707937,62.90039811759294 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark91(-0.07594584059728504,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark91(-0.07702154611896983,0.0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark91(-0.07877506182598286,-87.59996809188692 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark91(-0.07966719543962653,-1.58E-322 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark91(-0.09628830698140578,-16.582077503182177 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark91(-0.1000594308448064,-42.973791902062366 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark91(-0.10130365986014489,-72.73159876878714 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark91(-0.10955534706985226,2443.811585704703 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark91(-0.11378301053512241,-66.09857069688589 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark91(-0.14509129204910431,-56.403576472567174 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark91(-0.15298273360776005,-84.85267265463762 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark91(-0.16564491020784763,-34.72316409969557 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark91(-0.1658021864754908,-34.723321375963216 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark91(-0.17402340048837536,-56.3746443641279 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark91(-0.17539032201711935,-33.59756767061168 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark91(-0.17773326790506427,-98.10199819050055 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark91(-0.1828008937282346,97.20666284498901 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark91(-0.18821672015304577,-56.36045104446323 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark91(-0.21550855724482143,0.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark91(-0.21791832716580523,-78.75773466691064 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark91(-0.21955623177170464,-62.612295950537025 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark91(-0.24607147492339518,-56.30256334582184 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark91(-0.2504965485763501,78.28931979116848 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark91(-0.25287527523233694,81.93423579285763 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark91(-0.2648583720405435,0.5923711072888095 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark91(-0.2717220336525408,-21.956053642924815 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark91(-0.2732311753175124,-53.6800047375816 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark91(-0.27374582451694796,1.2926936270354368 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark91(-0.2936062221558265,0.2936062221558265 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark91(-0.30474777209887033,-16.012711040047837 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark91(-0.3262980290194252,59.363962389186646 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark91(-0.33055854452411093,0.0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark91(-0.3531495323011802,79.85482008583156 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark91(-0.37288427553188846,-78.91270061527672 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark91(-0.4007867636902991,-15.905286641552097 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark91(-0.40172405907622305,49.82362024197192 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark91(-0.4057474706924795,1.5707963267948983 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark91(-0.42416974957196363,69.53920812854741 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark91(-0.4276107307151449,-91.53379768481915 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark91(0.4428299527000505,99.40287345238164 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark91(-0.47208599748252866,-68.86281349927148 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark91(-0.47514286363658664,-56.07352490097969 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark91(-0.47772367127250187,-49.78775878616419 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark91(-0.49165550634480937,3.469446951953614E-18 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark91(-0.5129808678738041,0.5129808678738041 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark91(-0.5188964712206613,21.47225210390789 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark91(-0.5235379150302507,66.84687422376214 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark91(-0.5239374366608028,-66.49738316204646 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark91(-0.5266754402022096,78.01313822913554 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark91(-0.5407614522599269,62.85139317923101 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark91(-0.5534802042106288,13.119850818569802 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark91(-0.5575609340736682,33.99995825541406 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark91(-0.5614436540292669,24.650055898531207 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark91(-0.6099208559205008,-60.30018127412657 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark91(-0.6187627057808882,-13.352449173535419 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark91(-0.6561232535032203,-22.647271828631773 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark91(-0.6800439132347157,94.92782352092851 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark91(-0.6805784066937656,88.64517270720798 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark91(-0.7094043733570053,-55.83926339125927 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark91(-0.721330680910313,60.49952740192617 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark91(-0.7269791904704203,-99.80398572440296 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark91(-0.759568158203469,63.591421229999334 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark91(-0.7981028453746207,58.89215757283145 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark91(-0.7983639771630209,95.76365330502023 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark91(-0.8059098572914674,13.37228047165064 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark91(-0.8120579069800244,180.86623335033858 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark91(-0.8196436095063511,14.888319658442615 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark91(-0.8254652325901743,0.8258025673364173 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark91(-0.8517003257938563,77.68811601395097 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark91(-0.8695212701896429,19.163334574781828 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark91(-0.8923458305487036,57.44101359516498 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark91(-0.9053419623580541,-50.44817733493129 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark91(-0.9079239005090456,38.607035743586565 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark91(-0.956876324823466,76.3551000109785 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark91(-0.9603082180642768,0.9602607580255168 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark91(-0.9658294360018306,-4.107742009385987 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark91(-0.9693687532750561,-85.79237040019947 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark91(-0.9774198918863704,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark91(-0.9804620291761019,19.83001795071486 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark91(-0.9855980381454752,-26.546237750222215 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark91(-0.9925337159563838,-86.36327676410008 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark91(-0.9939737166206053,-1.2560710162842061 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,0.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,100.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.039668323906173 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.1E-322 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,1.5707963267948966 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-20.914500261366364 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,2613.707846955151 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-2621.896705537103 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,2629.461221365747 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-40.84165514588882 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-56.27476656477472 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,61.87069990094221 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,-6.772001786430626E-17 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,78.02988605435993 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,79.90336543396103 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark91(-100.0,84.8476894014737 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark91(-100.96033925221846,0.42937433734507696 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark91(-1.0151767349262597E-115,1.0049286038806172E-98 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark91(-10.15543772431712,-20.539286834782274 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark91(-101.64410383458137,-10.123420624331343 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark91(-1.0202131635318814,86.72372293573233 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark91(-102.09926850213189,1.5707963267948966 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark91(-102.10513155727858,89.30245385076415 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark91(-1.0212166913648686,0.2941556408541013 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark91(-10.23909930854532,91.54665177195466 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark91(-102.45703568208069,32.63144842228042 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark91(-10.358110185517452,-145.44659428987856 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark91(-10.377386338616759,-90.08439296334268 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark91(-1.0410285038177884,2465.1916396927454 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark91(-1.0440487148797639E-53,81.68140899333463 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark91(-1.0472963021498747,-11.519074312209298 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark91(-1.0480245530975032,90.32823191919636 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark91(-104.83717721649587,75.53293656441399 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark91(-10.500685267997834,-96.31346495405514 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark91(-10.50555534861587,6.283187923819686 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark91(-10.571478346510403,31.141425245916167 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark91(-105.76629102410516,-7.331044505127399 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark91(-10.585395315453102,22.482590863974778 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark91(-10.59102407143468,1.5707963267948968 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark91(-10.592172896810297,-22.930323382796573 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark91(-10.62164197444551,-1.1968640136761302 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark91(10.623404657252195,30.404582012220402 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark91(-1.0626850694570211,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark91(-10.655668784869903,-51.89871572289566 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark91(-106.81415022202582,1.5707963267948966 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark91(-106.81418717151452,5.809118443697077E-4 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark91(-106.87047203971701,-66.0297675430497 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark91(-106.92758402305444,0.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark91(-10.744274300783673,-12.56637061452508 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark91(10.762868861079587,62.59607253300475 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark91(-1.0778381693092715E-15,56.54879649137602 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark91(-10.816492931680017,-77.21640241828156 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark91(1.0842021724855044E-19,40.84070221783636 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark91(-1.0938499769238774,60.946472655283564 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark91(-1.0944325692821852,-48.218322373129084 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark91(-10.972040834007391,117.83325796317412 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark91(-1.0983603290068211,1.0983603290068211 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark91(-110.10669519720395,32.80259782326243 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark91(-11.011050275077851,-1.5707963267948966 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark91(-1107.4489769583313,1.2723687669797562E-10 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark91(-1.1096559234512595,12.508730842250436 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark91(-1.1102230246251565E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark91(-11.106567736473806,-1.4604546493114055 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark91(-111.49355071747831,-123.03659634363324 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark91(-111.64810858582575,78.87343344376984 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark91(-11.174954466061601,-1.3914161482975715 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark91(-111.76517503931815,42.59396524512367 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark91(-111.94254830042992,-94.95179167241395 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark91(-112.22754761289566,-134.2186961880242 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark91(11.2809184311579,81.64003840692394 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark91(-11.370184482966721,-42.2803578129656 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark91(-1.1409952807276493,51.40647773816434 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark91(-1.1410907981647438,-1.5707963267948966 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark91(-11.413138339051791,0.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark91(-1.1465534723633254E-5,-119.38050937087742 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark91(-1.1468887028740493,-88.7452267452606 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark91(-114.82736614789349,1.4115620349288645 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark91(-115.43000754244312,51.04198531135166 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark91(-1.1545343364410663,-111.11027721208383 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark91(-1.1610856420224304E-27,28.274333882301306 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark91(-116.23885932019999,-147.65485471149293 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark91(-116.30143432562139,138.23056605972704 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark91(-11.663882728759845,-49.08901636841681 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark91(-1.1695919065609428,56.2508646793529 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark91(-11.722638711765095,22.83488047772263 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark91(-11.737244355999838,-32.20250108133733 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark91(-11.743355250882345,91.92920231758083 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark91(-117.50977160634464,-148.07770730948732 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark91(-1.1762439813505592,-98.56561624263415 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark91(-1.1833185112220241,57.7319862758383 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark91(-1.1855638661105399,-55.36306772208051 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark91(-1.1859539424446306,57.73446820137345 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark91(-1.189418238254846,40.59908276495793 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark91(-119.17243257528519,1.5707963266452114 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark91(-119.25333779831055,0.0019745985245930658 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark91(-11.937604361906622,1.5707963267948895 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark91(-119.3775392442586,1.5297673122865637E-8 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark91(-119.44640059215016,-9.490657716507393 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark91(-1.1952429446958057,77.34457339504903 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark91(-11.95550422789311,13.896057029101456 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark91(-119.8417262268693,-8.40962943354215 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark91(-12.007484239521132,-132.50577782560936 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark91(-1.201028685653807E-16,84.82300016937684 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark91(-120.50862219319075,-84.90571866375373 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark91(-120.61887694943816,1.0265322609116837E-13 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark91(-120.81591725919081,-89.3903013046872 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark91(-1.2122431414537205,-42.770054008803385 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark91(-12.164842863476093,-3.769076175087207 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark91(-12.248855630528396,8.23530932853285 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark91(-12.274549712452526,-0.29182090190664717 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark91(-122.91745702769377,-0.3951948440601889 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark91(-12.292447732310766,93.97385672564539 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark91(-1.2307474187469125,-17.618808502791847 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark91(-1.232438370469179E-9,87.96459436011887 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark91(-1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark91(-12.33297119672541,61.22529324432883 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark91(-1.2418035765481246,8.182974384221255 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark91(-1.2434477169071345,-86.06644936383155 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark91(-1.2494006755768223,77.29041566416801 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark91(-125.26761948340086,-132.34297811096218 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark91(-12.56637061435917,8.673311564732444E-19 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370614359181,1.5707963267948966 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark91(-12.566370673965237,-78.53872909936379 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark91(12.566371015497774,0.10317565260283393 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark91(12.566378243767122,1.5707963267948966 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark91(-12.566378298152049,1.5707963267948966 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark91(-12.566387013190276,1.5707963267948966 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark91(-12.56649268553876,2.2574925299035541E-4 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark91(-12.568368061468963,-6.283187497445866 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark91(-125.68670217185218,0.02299588779496651 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark91(12.570462031648916,-100.53101196190988 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark91(-125.71899916491274,-170.76682669504828 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark91(-1.263155349075024,61.73336866844582 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark91(-12.678633528463516,-30.87699890380162 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark91(12.691375527129694,56.42423262628835 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark91(-12.697204880849668,0.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark91(-12.754699696450642,0.18832908209146867 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark91(-12.758373304152956,-0.08447054623208317 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark91(-1.2809010814253272,-79.82071742117016 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark91(-12.810526239019069,0.8042602809772691 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark91(-1.2825339214467056E-9,-31.415926534615366 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark91(-12.841659299562632,-131.67160276556785 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark91(-1.2924697071141057E-26,18.84955713739603 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark91(-12.981615185373839,0.41524457101466566 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark91(-12.983593860358186,-41.257927742666325 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark91(-129.88440912343185,-119.2442091443436 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark91(-1.3014122613519419,-75.36063513727302 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark91(13.041829383332486,66.44890449435897 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark91(-13.05301804125996,0.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark91(-131.94689083468342,3.1415926522203534 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark91(-13.203433733336482,-32.668494782758714 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark91(-132.27646334016947,9.701107145699936 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark91(-133.1763823100612,-27.201547177644784 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark91(-1.3332287172627364,-87.62487778768144 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark91(-13.33665582111756,-50.13946433405492 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark91(-1.3341490445875808,39.659894279119726 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark91(-133.67213456965982,1.4163495347012915 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark91(-133.84215549969346,80.03613035209695 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark91(-1.3430503355405223,-5.359040656737779 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark91(-13.431965597240577,88.8501692044813 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark91(-13.448026185139817,0.8812947258575526 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark91(-134.5873047531562,15.206783916744046 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark91(-135.08631341031258,-2.2734768307591952E-13 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark91(-135.09043739090237,1.5707963267948963 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark91(-135.13977348993302,95.46639974110255 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark91(-13.51842512453969,59.324859479700024 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark91(-13.520387407102959,64.12681969913515 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark91(-13.571362262997908,34.55751934628109 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark91(-13.571630315950953,1.5707963267948966 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark91(-1.357188956077927,-51.06105711885421 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark91(-1.3694503249743581,-67.34291577048253 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark91(-137.3555594104776,73.92298356919719 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark91(-1.376443268882471,-74.02178041727257 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark91(-1.3872030822227166,64.21817111613537 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark91(-1.3877787807814457E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark91(-139.0038377105517,85.1494229078751 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark91(-1.4011789009993099,26.87315498130883 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark91(-141.36820012153834,-1.781472485632857E-11 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark91(-14.137166941154378,1.5707963267948966 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark91(-14.137173742177453,1.5708031278116628 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark91(-14.15810225189982,51.85721409497734 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark91(-1.416158446778738,-1.5707963267948968 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark91(-14.173124515788203,-44.60042561022433 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark91(-14.193923595721202,1.5707963267948968 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark91(-1.423010086075059,1.5707963267948968 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark91(-1.4247672700141534,-42.55752988024295 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark91(-142.6068841686725,19.109805281238195 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark91(-142.94246573831322,-1.5707963267948961 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark91(-144.51522920967668,-1.422676941039754E-10 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark91(-14.503361766969206,138.3745847560208 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark91(-145.05667436748865,27.730921579949964 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark91(-14.519240783221306,-28.71599081198933 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark91(-145.98493405789068,-67.38042394349256 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark91(-146.08405879958988,1.5707963267948966 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark91(-147.13174593644877,84.2998928646529 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark91(-147.17301422412189,59.690260425807004 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark91(-147.33428486676496,-84.88823318059556 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark91(-1.4750817757288197,-67.63995660324663 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark91(14.778287297993202,42.23735544291202 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark91(-1.4788152321500701E-272,0.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark91(-14.88494241967527,27.82233252435502 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark91(-149.03675915056178,-14.137167128502462 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark91(-14.905028457541107,2.338657843181934 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark91(-14.93701752699468,-1.5707963267948948 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark91(-14.967803232587311,29.474589457641883 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark91(-1.5003434865324694E-14,6.162975822039155E-33 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark91(-15.013130682652132,2539.2032007295684 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark91(-1.509448935891145,20.477221624828346 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark91(-151.9741822642268,49.58473132720542 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark91(-1.5209263500924413,0.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark91(-15.25481771957886,-8.0948E-320 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark91(-1.5265859320304012,-9.025971879324148E-277 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark91(-15.289448167159065,-61.73330298515764 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark91(-15.318848788383452,0.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark91(-15.386896017061117,46.80282255295905 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark91(-1.5407439555097887E-33,-25.14836622871835 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark91(-1.5414581215035312,-7.219290990153446 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark91(-154.17722062195745,-28.035153286250562 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark91(-1.543636415599801,1.543636415599798 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark91(-15.459266172204057,0.24869709574490945 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark91(-1.5482410103033768,5.852095443365248E-98 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark91(-1.5504035462938417,1.5707963267948966 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark91(-15.50864627908552,-56.34935077575283 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark91(-1.5608948042106277,31.297408146025248 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark91(-1.5611301081005664,-67.5539082708749 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark91(-1.5621631837455268,45.54446033400264 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark91(-1.5628574084014966E-5,-28.274349510876647 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark91(-1.5663768520657653,-98.95574911334934 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark91(-1.568235170652216,-100.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark91(-1.5692218365493098,20.421926738579206 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark91(-1.5704852158095144,1.5711074377793801 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark91(-1.5705634371527684,-54.97488491240698 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707911858603385,-84.5295720850957 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark91(-15.707945805903668,-78.53981628877516 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963130310147,70.67571769273157 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963139488275,45.5530934642203 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963242019265,-180.6431051841022 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963261411604,32.978619763919816 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963261570024,7.853981633974488 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963262804843,-17.262633382183292 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963265130893,-61.24874911898704 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326535593,177.49153679652792 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326575597,1.5707963267948966 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326674725,1.5707963267948957 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326744087,-98.97613121888872 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326767511,58.09955578470886 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267700455,102.10176124163132 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267879903,-73.8305773334639 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267894642,-54.97787143783023 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326790264,1.5707963267948966 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark91(-1.57079632679072,1.5707963267948966 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267911556,1.5707963267948633 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326791768,1.5707963267948966 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267923586,-10.995574287564265 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326792755,26.70353755551658 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326793144,1.5707963267949054 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267933958,58.11946409140735 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267940457,20.420352248333042 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794491,1.5707963267948966 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794584,1.5707963267948966 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267946223,1.5707963267948966 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267946412,-80.1106126665415 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794659,1.5707963267948966 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267946803,-29.801270499337157 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794748,5.9E-323 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267947704,2.4864888548025164 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948486,-56.28692379916866 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948557,17.124815744006924 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948832,1.58E-322 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948877,-68.8557505146987 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948901,1.5707963267948963 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,1.5707963267955307 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-20.829251706660216 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,-62.65512939968935 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948912,94.51875811079164 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948923,20.42188877476568 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948923,7.851834800281944 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948926,1.5707963267946141 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794894,1.5707963267948966 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948943,1.5707963267948966 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,127.23450240966491 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948948 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-1.5707963267948966 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,1.5707963267948966 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,2564.551865010686 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,2627.8441272668274 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,26.916281286992444 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,30.490955877888695 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-48.69468613064497 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-6.283185307293269 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,64.39078015622208 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,70.68161973572396 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,70.68571559563539 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,70.68583470576954 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,7.853981633974485 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,89.5495077970509 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,90.89718350673112 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948948,-98.95449607146244 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948952,1.5707963267948966 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948954,1.5707963267946845 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267856375 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267943594 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.570796326794893 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,1.5707963267948966 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,25.83546447145831 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-30.77846390701775 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948957,-64.50781905015305 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794895,89.5330817939259 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-1.4676993771651825 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.559809919570379 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267948966 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,1.5707963267949054 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-2482.053038881413 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-48.69062678624771 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948961,-89.80924743471766 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,26.720527190568202 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,100.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-10.611076982881968 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,113.09733416959186 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-136.67127484483493 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.570796326794896 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948963 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267948966 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949019 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949054 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,1.5707963267949197 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-17.27278597038873 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.420352248336034 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,20.420352306843615 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-2469.4468399073744 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,26.70377666108392 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-40.78318451830258 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-42.41150082345884 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,45.552314707409124 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,51.83627878420065 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-54.97970903042582 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-61.261516140805895 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,64.3963159164409 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,70.68417982749843 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-80.11061266625812 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-86.39402309032994 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948963,-92.67493706089834 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,-42.40906838897875 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.4849552740036973 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-0.8116349316689022 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,10.081287467033832 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.110665626116756 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.149100672270393 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.540048985733819 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-10.99557428756401 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-111.52653920023688 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,114.6681318560238 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-11.59070308907873 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.2451990551949166 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.57418327670411 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,12.898285856725213 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-12.960183308767336 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.3454745915707995 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-136.6592804311531 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,14.137166941151683 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-142.9413517352184 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,147.65485473687144 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326792769 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267931826 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326793338 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267937164 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267943013 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794813 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948273 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948886 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948895 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794895 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948961 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267948983 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949054 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949197 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5707963267949339 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,1.5718632770379286 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-161.79202165995108 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.2787595947401 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-17.278759594742123 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-180.86942069121466 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-18.590186002364618 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-19.66232123822915 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248332215 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.420352248335615 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,20.42035224833691 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,2.0E-323 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,215.19909676617837 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-21.99114857512855 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,21.991392715784755 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.09281207931444 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.558225277358314 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-23.597579608157563 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,24.740588788960586 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,25.132741228079503 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,25.132741228357315 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2613.511666556517 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2630.473026144333 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555513243 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555515318 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555516572 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.70353755551673 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,26.703537555517205 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-2.8883110013837273E-275 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.836065069380233 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-29.845130209099683 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-3.1415926535897927 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.415926931764993 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,31.59878183766145 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-31.984337387116298 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.02999060209327 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269144 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,32.98672286269171 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-34.292749292109335 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-36.12831551627966 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,38.26852283946256 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,3.8990786967097932 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,39.25029405989486 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.0215293667718976E-87 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,40.84084217514482 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.0E-323 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,42.02056178583112 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-42.53650082346494 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794896,64.38690285328389 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,4.450147717014403E-308 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,44.75439336657093 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.55309347705162 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,45.61566257562507 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-4.699916568495576 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-47.00685461251326 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-47.1238898038469 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.69468613063713 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-48.724689277439445 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,49.619355425210316 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-49.770732804377495 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,50.1702970213727 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,50.26548245815944 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.83627878422993 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.83627878422998 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,51.852099694606075 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,52.66858772698761 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,52.978549408807396 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,53.407075587863645 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.8365872336537 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.96133467200579 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.97787143781656 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-54.97787143782029 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-5.4E-323 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,56.54866776461627 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-56.54866824145356 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,57.36414352041918 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.11946409140643 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,58.11946409140936 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-5.971345446197468 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,60.09122203645567 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-60.233046460956984 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-61.26105674499906 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,61.27147891038189 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.283185535595891 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-64.28692487230224 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858665 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,64.40264939858982 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,65.69753972655502 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-65.97344572538564 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-6.731002185997683 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-67.54258215101552 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,68.43908522625658 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,70.68583470576523 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-70.68583470577035 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,7.089815073439968 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-70.94805324994098 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-73.82742735935739 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-75.54264934832433 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-76.90758463190075 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.9690200129497 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001295156 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001295179 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,76.96902001295435 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-77.00441290633337 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-78.4600565926169 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-7.853981633974486 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-78.54176944498023 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,79.3466525055002 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.31889630066127 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-81.68922149333926 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532012435 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.25220532012514 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.2522053201292 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.26869920654181 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,83.27199116466724 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,84.64057433858832 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,84.76387929113884 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,85.6933820921158 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,86.39379797372106 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,87.29017596382448 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.5353906273051 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.53539062731184 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,89.83913979042782 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.73547593483029 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-90.78731582288498 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-91.10618695410399 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,91.10618695410437 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-91.10618695460818 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-91.83442096311825 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-92.66173771350492 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-9.328660109454638 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,95.80262612970043 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,95.81857593448505 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,96.24424300029686 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948966,-97.38940277886167 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,133.5176877741912 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5683471742085322 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267914096 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267921472 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948941 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948948 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948963 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267948966 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267949054 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267949163 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267949765 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267963814 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,1.5707963267964233 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,32.967963758380975 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,45.55309347704842 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948968,76.96902001295439 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794897,1.5707963267948966 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948972,-17.27467679329443 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,-23.561944901914107 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948974,90.51831002567492 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948981,1.5707963267948966 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948841 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948948 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948961 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948966 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267948974 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,1.5707963267949 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,190.06258285820098 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,20.420352248334908 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,32.98672286269283 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-36.11612488610712 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-42.8789153002236 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-53.787494121142224 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,76.98173548137642 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,83.2503086440583 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,85.39691868439473 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,-86.39379797371586 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267948983,89.55619483780802 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949019,32.98461703886471 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949019,92.256266779274 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949054,1.5707963267948966 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949054,1.5707963267948983 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949054,-62.16119956802866 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326794908,1.5707963267948966 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949134,1.570796326789332 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949188,1.5707963267948961 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949228,1.570796326805915 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949339,1.5707963267948966 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267949514,1.5707963267948966 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267950267,1.5707963267948966 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267950351,1.5707375916490145 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267951972,1.570796326794896 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark91(-1.570796326795346,-100.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267953828,1.5707963267946665 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963267973455,1.5707963267948966 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963458021779,1.5707963457923952 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707963515212864,7.85398539855896 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark91(-1.570797029864824,1.5707956237345637 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark91(-157.07987689397046,106.81414782098322 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark91(-1.5707989534895643,1.5707937001023036 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark91(-1.5708065828265783,1.5708065828278865 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark91(-1.5740353056196332,1.5675573479701763 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark91(-1.5766124540495154,1.5649801995402994 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark91(-15.773083056971325,-38.37610787613127 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark91(-1.5777218104420236E-30,65.97344572538564 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark91(-15.89033456700156,-91.11748887957518 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark91(-1.5891563455395044,-4.079903606031497 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark91(-15.897341959102576,-0.18937869115360978 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark91(-1.5913373926124734,-34.2365367219295 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark91(-15.915554875034239,1.5707963267948963 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark91(-15.919339185131886,38.14467049235458 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark91(-1.6051903967411982,89.93057995887045 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark91(-1.6155871338926322E-27,-53.40707606193856 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark91(-161.71693525871373,-93.99962685389754 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark91(16.20796326794897,21.541446905617835 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark91(-16.364846358015583,-95.9091239868419 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark91(-16.369285738860043,-6.9445077780906646 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark91(-1.6420061068037226,95.88978571449752 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark91(-1.6499720557265526E-16,31.415927954983438 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark91(-1.650729418924115,97.39878054083695 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark91(-1.6559749082061261,-55.06305001923261 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark91(-16.627902939736803,24.212801556930508 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark91(-1.6704779438076223E-52,-6.283185307102923 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark91(-1671.1026396279701,-1.2191128995868432 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark91(-16.760280153125613,-40.84344504711007 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark91(-167.88249640023224,23.402065144908633 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark91(-169.10775920287406,66.30881418169062 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark91(-16.9168849690231,76.67693630227183 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark91(-1.6940658945086007E-21,1.5707963267948966 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark91(-169.64600189434168,1.5707963267948877 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark91(-16.975851228960796,-51.435703467813966 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark91(-17.000232455058082,-1.2922691871091159 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark91(-1.7026121798274076,77.10083586598245 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark91(-170.6932672210833,-61.78458914456141 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark91(-17.106074934182665,46.230786206146234 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark91(-171.21679961958392,1.5707963267948966 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark91(-17.17895336295779,-1.470990095008825 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark91(-17.278759594743864,-1.5707963267907705 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark91(-173.05829301441932,94.00164091987313 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark91(-17.307132492703,104.40608033451255 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,25.13664825595265 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark91(-1.734723475976807E-18,-5.0255393869863365E-17 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark91(-1.7347667723780091,68.14967636267335 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark91(17.41905583944559,-25.139735278114728 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark91(-1.7524886189427664E-11,91.10618695408648 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark91(-175.3860543539671,5.905436344405459 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark91(-175.6645675250129,9.345073119951692 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark91(-176.60161497032468,152.59263535176532 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark91(-17.666114538409126,-1.183544860191861 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark91(-17.67137753211763,-0.39262626802914113 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark91(-17.719612304910655,10.513600935323149 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark91(-17.74272551470615,60.79709082503868 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,-3.6028670230595026 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,57.30516785129362 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark91(-1.7763568394002505E-15,-59.414739973732225 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark91(-17.82407556682463,2.244784694212335 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark91(-1.786072411258805,-17.063483510279955 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark91(-18.141239778110652,-65.97346415495082 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark91(-18.15370317668949,-2628.4117748122094 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark91(-181.64767836939558,12.20706467203847 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark91(-183.09033603604053,-28.275638786726667 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark91(-18.358814239629872,-0.4907416819088873 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark91(-18.397692916553154,40.77977604465457 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark91(-18.69564321977825,37.699276793232734 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark91(-1.8715561652817826E-16,-84.82495887594429 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark91(-18.736196114342917,68.4647867534186 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark91(-18.849530850068838,40.84070449643784 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark91(-18.849555915923176,91.1061864403141 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark91(-18.84955592340156,-1.5707963267948966 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark91(-18.849555930823996,-8.552847072295026E-50 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark91(-18.857368421541857,0.6478530458809456 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark91(-18.85736842161274,0.5005408064974081 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark91(-18.890819455345735,36.19234527618144 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark91(-18.917371333555213,-34.62533460150418 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark91(-18.95823049730243,-18.45162656853394 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark91(19.032688618293975,-54.16910111792688 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark91(-19.073025371243986,100.0 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark91(-1909.2763955214466,-1.5707962998284912 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark91(-191.86820757340604,-27.94366201710814 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark91(-1.9197666102692987E-34,-34.55754970706622 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark91(-19.2894193758875,0.0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark91(-19.380520836412142,-100.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark91(-19.393357713811483,-1.5707963267948966 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark91(-19.43147278885411,-61.004403352630696 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark91(-1.9474013587499286,14.708128035987244 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark91(-19.492734069213412,0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark91(-19.501628006233254,90.45411486940951 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark91(-19.656035977785432,0.8064800562466728 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark91(-19.689251412490677,14.86826777699705 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark91(-19.748821605492655,-35.45678487344162 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark91(-19.766342761691405,1.734723475976807E-18 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark91(-19.805657508882827,18.849555921550113 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark91(-19.81515854122364,2572.658787670539 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark91(-19.825759493758497,20.175063777544057 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark91(-20.150642020993576,26.973247782853733 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark91(-201.72757183870627,25.798383237677847 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark91(-20.200926607279214,1.5707963267948968 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark91(-20.3197493564061,26.979482527236247 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark91(-20.36111604099871,3.750911597845402 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark91(-20.413637724077226,1.5707963267948912 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark91(-20.42035220057333,1.5707962790287004 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark91(-20.420352248326875,1.5707963267948966 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark91(-20.42035224833089,1.5707963267948966 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark91(-20.420352248332627,1.5707963267948966 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark91(-20.437798443140387,1.5707960325309154 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark91(20.525404328147673,52.354569631305964 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark91(-2.053857359605256E-11,78.11434033897118 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark91(-20.542209695055718,1.5707963267948966 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark91(-20.610881643264506,35.484801976455316 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark91(-20.653973419379454,1.5707963267948968 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark91(-2.0679515313825692E-25,-65.98125848363573 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark91(-20.725357812102995,-68.18872406472661 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark91(-20.792931735811536,1.1982168393170174 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark91(-20.811541400405062,-11.905339944375767 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark91(-20.982574092519968,-35.962364675558135 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark91(-2.0984757313855175E-7,100.53093742602795 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark91(-20.99091861119144,-107.62844213365901 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark91(-20.991148566661177,88.9645943002528 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark91(-21.026759154031666,38.93488769397811 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark91(-21.054555558294542,-0.4778332993197978 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark91(-2.1175823681357508E-22,-18.85053253530157 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark91(-2.1175823681357508E-22,-91.10618695364413 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark91(-2.1259429726341295,14.692313586993302 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark91(-2.142004180546991,1.5707963267948966 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark91(-21.44449980307904,4.069281871876385 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark91(-21.485640804194574,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark91(-21.505976364504146,-0.9105757843998094 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark91(-21.55056673070881,0.440362702267874 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark91(-2.1684043449710089E-19,-1.5707963267948966 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark91(-2.1684043449710089E-19,59.69026042006917 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark91(-21.687493813642547,42.348225642706154 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark91(-21.688125072135293,-15.931645161625568 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark91(-21.759799790649566,0.23134878447898627 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark91(-21.803961745092213,9.23759113073304 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark91(-21.86948485186879,-1.5707963267948968 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark91(-2.1904391778863197E-9,83.05065592568809 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark91(-21.950935272581916,-4.9E-323 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark91(-21.96931388283953,-16.237914748617207 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark91(-21.99079647010985,6.287091557414864 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark91(-21.991148411311034,56.54866776461627 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark91(-21.991148574421022,81.68140896009955 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark91(-21.99114857496939,-15.707963232787055 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark91(-21.99114857512855,-1.5707963267948966 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark91(-22.022398575138915,1.5707963267948966 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark91(22.136786630916447,-23.446750476967708 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,1.5707963267948963 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-19.458698519582224 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,28.274333675524154 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,63.59962940069599 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,90.06216584388558 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-97.38937234081777 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,-97.38937234086758 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark91(-2.220446049250313E-16,98.95536981041596 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark91(-22.273421875843894,-8.52478941564886E-255 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark91(-22.321498898604062,55.53024831186204 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark91(-22.32803285374291,63.22817215059818 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark91(-22.356378214660257,1.5707963267948966 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark91(-22.44588581490537,-65.51870848560884 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark91(-22.52333225300231,-72.49555632927522 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark91(-2.253933757382906E-18,-216.75920464470477 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark91(-22.596974464055023,45.07535619732943 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark91(-22.629957965349263,-45.42409476169375 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark91(-22.688894181009417,-28.772481891601014 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark91(-2.2768135374835197,1.9730748089482346E-19 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark91(-2.283333925324039,-54.26533383929224 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark91(-22.877255925625178,-78.91168061122224 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark91(-22.907066446790793,30.768627565161637 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark91(-22.94150091020954,-83.36163453803813 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark91(-23.151047930605625,2.6015592699123717E-259 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark91(-23.272979406104284,60.9720912491818 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark91(-23.286932567036004,0.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark91(-23.35228238940219,-0.5792418391820908 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark91(-23.35708155278842,11.200437636699307 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark91(-23.41886235581177,100.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark91(-2.350988701644575E-38,-28.274333882540986 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark91(-23.544017228729434,1.5707963267948966 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark91(-23.56194490192203,-1.5707963267948966 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark91(-23.585538505081676,62.17523744899235 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark91(-23.69754189347981,-72.14427745140704 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark91(-23.736390747555923,61.086610899368495 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark91(-23.753004967273043,4.521328915035096 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark91(-237.9116216143778,-61.245507176066894 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark91(-23.831099462433258,-2.0E-323 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark91(-2.3899533038744787,1.1615450325873082 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark91(-2.39542810166137,0.7461611829651235 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark91(-240.33569010516314,1.5746484323388623 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark91(-2.4074124304840448E-35,97.38937003431326 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark91(-2.451658344784223,-54.097009419832055 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark91(-24.531922914058182,97.40113263760014 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark91(-2.457204685373841,-60.374648386422024 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark91(-24.591758794454208,-68.13447496004397 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-21.99114857512855 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark91(-2.465190328815662E-32,-56.54866744581205 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark91(-24.695606420063683,83.07065538018418 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark91(-2.4957167363105808,-5.638015248215418 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark91(-25.029340411661224,82.42692934687972 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark91(-25.132725583030858,6.283201734594817 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark91(-25.13274125852088,0.2405318476563187 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark91(-25.132741705555507,-1.5707963267948966 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark91(-25.13806507298638,1.5707963267948966 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark91(-25.14460353752983,72.2568052668737 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark91(-252.53277141815965,1.5707963267949017 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark91(-25.32347950780691,-124.46835430537054 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark91(25.422116403450488,83.18125572222999 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark91(-25.471073372894086,-2629.0946601886158 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark91(-25.478358777828703,0.4139962789876481 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark91(-2.5489470578119236E-57,9.424777960769378 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark91(-2.566535269056782E-18,6.938893903907228E-18 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark91(-25.69660737762221,8.530004585833979 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark91(-25.708296921658217,119.72949137004214 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark91(-25.737260635667074,0.604259346515351 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark91(-25.863599966888046,-88.73627316449002 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark91(-25.86769655077988,0.8358161776728495 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark91(-25.877352883750714,-65.93726521535801 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark91(-25.985395198428378,-54.135386363324386 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark91(-26.021764097860636,-106.8205399250656 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark91(-2.6049462737934694E-6,-157.07258171346635 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark91(-26.05865827177321,0.8140547886946488 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark91(-26.147299648293934,-35.572077609063314 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark91(-26.231813204942718,66.79635905509062 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark91(-26.322698970630398,5.551115123125783E-17 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark91(-26.42806901261035,50.05603843940706 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark91(-26.45142918116747,-92.0679503166048 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark91(-26.47157587071706,0.5849191998895698 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark91(-265.46448184409456,1.5707963267948983 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark91(-2.662159244243666,-52.15121745575776 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark91(-26.655275606050992,-68.14809529754626 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark91(-26.703537555511208,1.5707963267948966 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark91(-26.70353755551661,1.5707963267939877 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark91(-26.714557231754952,0.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark91(-26.74052981582618,56.42631072738568 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark91(-26.782936717186118,42.54747691729781 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark91(-26.884105498855867,-86.57436591706194 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark91(-26.92277404262495,-47.723407358761975 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark91(-27.068757288024123,-28.08144634736517 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark91(-27.07369581155605,-55.18432043892325 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark91(-27.081111290722692,9.860761315262648E-32 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark91(-27.084568184046905,-1.5707963267948963 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark91(27.10442358832468,63.85224477361277 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark91(-27.111792619286106,-63.79803030420196 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark91(-27.12558579308854,5.556534463758368 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark91(-27.18205287246134,-2.2784756311113742E-305 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark91(-2722.314768753823,0 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark91(-2723.237725262333,0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark91(-27.348060956039717,0.9262729262684222 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark91(-27.48541936775026,0.7888986030724883 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark91(-27.516485417965367,7.888609052210118E-31 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark91(-2.763718387707466,-34.674383762225474 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark91(-27.742718669494547,68.27945321104312 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark91(2.7755575615628914E-17,2.8729424438392326E-11 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark91(-27.799799287384047,-58.937854773456515 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark91(-27.808216370191843,26.857316695372162 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark91(-27.852488756998664,1.5707963267948966 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark91(-27.871925791577965,-22.792651008120718 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark91(-27.890851885859064,-71.23557656703849 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark91(-27.896387239173986,67.53918132602871 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark91(-27.951116985168998,-41.163921393806454 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark91(-27.95578474306967,-64.66808698514902 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark91(-2.79682422799112,0.0 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark91(-27.98900827990149,0.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark91(27.99418872214727,37.51525638675653 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark91(-28.160613844008466,0.1137200382996728 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark91(-28.189628043173173,-62.02166586217791 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark91(-28.255356742609663,113.8144928429576 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333800329973,-21.991148231740187 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333855621624,18.849555921487873 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark91(-28.27433388229872,-12.566401418317174 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333882306063,175.92917108512125 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333882307754,0.0 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333882308134,-1.5707963267948966 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark91(-28.274333888554963,-84.82301130579317 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark91(-28.274334164252895,-2.7825404066040247E-13 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark91(-28.274334860509427,37.69911238694166 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark91(-28.274337552155195,0 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark91(-28.511348178824264,-94.5754404255989 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark91(28.546200021473197,-58.940177301596485 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark91(-2.8570037992273605,0.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark91(-28.69267501773598,62.04330650070901 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark91(28.6948474141077,-24.909890126489557 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark91(-28.826852625048787,66.50964715079081 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark91(-28.839687030135423,-1.5707963267948966 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark91(-289.0263666224174,-81.68140897252782 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark91(-28.97875578336911,9.474755127424189 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark91(-290.50396368159767,0.4165406726518356 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark91(-2.9074822614798137,-1.6985715804103165 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark91(-29.096828067520587,-0.5557901229512829 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark91(-29.105027422105877,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark91(-29.185463388978718,-64.48050693434365 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark91(-29.23052695903493,-44.938490226983895 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark91(-29.272008289263056,-93.20418313543159 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark91(-29.31012457553348,-100.0 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark91(-29.5549224329762,71.24548016688543 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark91(-29.6288612525464,-46.68928840214879 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark91(-29.633582329656804,-123.31007660670784 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark91(-29.701630603918836,57.58510469023834 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark91(-29.735024343296743,0.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark91(-29.81998950748406,90.05325453326253 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark91(-29.827984987952334,2580.1872418501584 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209103036,61.261056745000964 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark91(-29.845130209103218,-1.5707963267948966 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark91(-29.900240237439917,-1.5185669175616654 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark91(-29.925146155724704,81.54151504419326 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark91(-30.06604361417196,-89.88180211880588 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark91(-30.2157057264331,1.5707963267948968 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark91(-30.241873127764315,-20.280331458109274 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark91(-30.49714053129276,-0.9187860046051716 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark91(-30.607934483603444,-22.10725672094587 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark91(-30.624583289260386,113.8516489940786 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark91(-30.834125881258437,0.4399062505545004 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark91(-30.970668372467628,55.512447919526494 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark91(-3.1239949157846683,-3.172842653589805 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark91(-31.34335905011163,-57.05126404491113 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark91(-31.346345547157103,3.266592654558629 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark91(-31.350612003804997,-1.4934998945112754 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark91(-31.405362172622482,1.5707963267948966 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926477081713,-72.25658633748627 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926535897927,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark91(3.1415926535918812,0.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592653592484,-1.5707963267948966 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926536480026,-4.791370946791819E-4 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415926537092385,-3.011489863849054E-9 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark91(3.141592657323256,0.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592675153921,-1.3601991276535503 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415928920083727,-1.5707963267948966 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark91(-3.141592892008511,-2.0140490667952538E-5 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415928925589833,-0.023472274125777175 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415929005117467,-1.5707963267948966 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark91(-3.141593164227011,-1.3881827110198513E-17 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark91(3.1415932836127807,-1.5707963267948983 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415934177411744,6.283185958211048 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark91(3.141593921022826,-0.03215380929341017 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark91(-3.1415945630843884,-1.5707963267927234 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark91(3.14159658174952,-3.9325343055111753E-4 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark91(-3.141602445810405,-69.11503828510925 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark91(3.1416232158859354,-1.5707963044190831 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark91(-31.416912917323312,47.123953555299494 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark91(-3.141739253966909,-8.899465137643282E-4 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark91(-3.1420809348402647,-4.0699133564406353E-4 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark91(-3.1421756081198846,-1.5707963267948966 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark91(-31.447176535897935,-1.9259299443872359E-34 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark91(-31.447176535911467,0.03219132839203872 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark91(31.47389932803165,26.765835753756065 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark91(3.1494051535903944,-18.84384154279516 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark91(3.149405155600272,18.855842989240113 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark91(-3.1494051992779686,-1.570796326794898 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark91(-3.149405224055665,-1.3284533052435197 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark91(-3.149553101341382,-0.4632222542281763 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark91(3.1572176535897944,84.81340530253019 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark91(-31.609415659126512,50.65332757860742 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark91(-31.665863188458587,-1.5707963267948966 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark91(-31.712383852353927,4.930380657631324E-32 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark91(-3.172842653589901,-204.20353790820832 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark91(-31.745065887734356,62.794984176986716 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark91(-31.908128844938744,0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark91(-31.93491598536255,8.357045331735932 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark91(-32.00006660898214,2.0324681796190404E-261 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark91(-32.010611448497684,-0.17332155959385176 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark91(-32.0297277880064,-1.5707963267948966 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark91(-3.2055318820167296,7.044203657368268E-133 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark91(-32.13573887043832,-7.9E-323 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark91(-3.220125253107298,2582.655352862772 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark91(-32.2837926162651,1.6016664761464807E-145 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark91(-32.32975683826123,0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark91(-32.401006540546035,14.925343601384556 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark91(-32.454983079562645,-32.214889620652926 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark91(-32.49578053391846,2.0617386555692625 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark91(-32.5155400140751,1.5707963267948966 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark91(-32.530437689967826,14.694173669103797 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark91(-32.56907020272442,58.819898053978704 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark91(-3.2603223824512893E-17,-97.38937126546934 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark91(-32.68163193488922,1.2651892622668037 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark91(3.2763505492081415,-47.25512709721633 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark91(-3.282301197415499E-8,78.53982397922151 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark91(3.2866426608224217,-87.81954429328515 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark91(-32.91522505204027,-1.5707963267948966 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark91(-32.95701539760558,1.5410888617076457 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark91(-3.2964929518725055,-83.43159468183332 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark91(-32.966399289885196,1.5707963267948966 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark91(-329.86682577408277,0.05587356764033286 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark91(-32.98672286269101,1.5707963267948966 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark91(3.3087224502121107E-24,-56.54866595652106 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark91(-3.3110843016120457,72.4261226805875 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark91(3.3202521175392437,19.02821538548821 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark91(-33.25215842774917,1.5707963267948966 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark91(-33.319701326589836,21.183604084299105 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark91(-33.56647955386789,-82.13473671957821 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark91(-33.73558028748222,-55.09478470089402 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark91(-3.3803485494655234,-78.88149047241828 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark91(-3.3881317890172014E-21,-18.84955747545117 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark91(-33.9581479062426,0.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark91(-34.34628264320575,-78.42789949256998 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark91(34.5149182350537,16.417378765118613 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark91(-34.557519189486314,1.5707963267948966 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark91(-34.55751919693831,-1.5707963267948966 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark91(-34.55767480726181,65.97344544763422 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark91(-34.55849575198773,0.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark91(-34.55849575198778,28.274328442163622 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark91(-34.564435075991625,-0.006915882352526135 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark91(34.61981050156692,-31.36736370211996 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark91(-34.66023295197196,0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark91(-34.67867690431379,27.753830969548964 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,-28.274337655024507 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark91(-3.469446951953614E-18,84.82300164788437 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark91(-34.7308576115073,-0.17333842201957103 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark91(-34.75213135233925,3.336204816441319 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark91(-34.80180215275172,0 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark91(-34.8651305832063,-0.30761139371857604 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark91(-34.873866965492795,61.37670857784505 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark91(-34.88175032734074,59.27210353357569 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark91(-34.90147724389401,36.73486514275609 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark91(3.5156512279097503,34.1834606151682 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark91(-35.216937236508,0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark91(-35.30650150338927,-0.7489823139015449 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark91(-35.326702547144635,0.8019109967088971 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark91(-35.42668092492336,22.76196895393825 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark91(-35.48091645540151,100.0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark91(-35.50809424503758,-118.8129062968443 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark91(-3.552713678800501E-15,-42.798821630452366 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark91(-35.56437396247563,2632.355745508604 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark91(-35.63067670130678,35.63067670130678 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark91(-3.5726067773092645,-84.39198752320495 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark91(-35.7964967073069,94.92672702762054 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark91(-35.8421977939914,-62.51266366383963 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark91(-3.5873240686715317E-43,-3.2665926702702817 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark91(-35.87364391290353,5.4E-323 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark91(-35.95737344291861,-1.3998542534308833 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark91(-35.97415044868217,-1.4166312591944408 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark91(-36.0885786783474,70.17123417225991 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark91(-36.141723646046366,-1.5707963267948948 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark91(-36.33098513382358,2.0E-323 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark91(3.6365859079745775E-17,1.597031372161294E-18 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark91(-36.47120697236714,-0.22373458522939793 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark91(-36.51214942566841,88.3359457589161 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark91(-36.51672410366594,-1.5707963267948968 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark91(-36.56538963835931,56.295847275284586 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark91(3.6734198463196485E-40,12.566375371968212 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark91(36.74537897883059,8.039405274696904 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark91(-36.819468649953755,2.256492969831037E-277 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark91(-36.83167274765386,85.69044074234807 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark91(3.6904219657137447,-49.71665314531274 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark91(-37.08647271403887,93.63514047865515 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark91(-3.7092061506874214E-68,2.3629997187283515E-52 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark91(-3.7120677991669413,-77.96934119416768 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark91(-37.23555242120062,37.23555242120062 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark91(-37.23737633369939,-88.60499868927552 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark91(-3.727024743630608,-84.37590841524178 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark91(-3.7286509284291145,3.7286509284291145 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark91(-3.732543753023005E-11,-106.81415023029687 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark91(37.47020902211548,-74.11401499733353 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark91(3.761582851819948E-37,65.97343940010963 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark91(-37.69630331141383,-1.5707963267948948 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark91(-37.699111234971,-91.11009321088841 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911183555685,-56.54866776461487 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark91(-37.69911184307751,6.797514484319326E-18 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark91(-37.6991123309874,1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark91(-37.70106491557683,1.5707963267948966 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark91(-37.71330116991969,1.556970419877088 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark91(-37.754806853054355,0.05569500997683572 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark91(-37.87668639582489,0.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark91(37.99039024441561,-66.68261897137337 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark91(-38.03963045538673,-97.97795085970512 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark91(-381.13152436575564,-1.4164550548774966 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark91(-38.44009407531777,83.33253229924966 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark91(-38.452700433939235,-3.8951812444515093 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark91(-38.47498388190375,-50.69208382571843 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark91(-38.51037199792411,-2701.063111524078 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark91(-38.52261538031871,12.86901338849735 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark91(-38.56342148572689,82.06708503661505 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark91(-38.5890901615511,-30.196441410323004 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark91(-38.66512276012697,-0.6047860487970491 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark91(-38.6846174626033,0.9851779062006878 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark91(-38.71750891899348,1.0183970759159622 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark91(-3.8766029144338434E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark91(38.79527232215193,36.83166077342028 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark91(-38.79572506682707,-62.132164618377104 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark91(-38.92961706632843,-37.73571496457213 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark91(3.908581281958886,-36.932123214708426 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark91(-39.140011254809,0.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark91(-39.20478399889409,-11.060698458542605 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark91(-392.6750733069083,0.9516257204605163 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark91(-39.26990816986814,1.5707963267948966 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark91(-39.318987126639215,51.88535774099839 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark91(-39.360104810917115,-243.38323401216428 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark91(-3.944304526105059E-31,-87.96459342520835 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark91(-39.44545962193458,-14.795531998289164 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark91(-39.605272037655205,-87.46387510564064 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark91(-3.969542259919397,39.1198447381708 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark91(-39.918763026039784,98.87970794181476 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark91(40.06533799017967,1.8656674329219385 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark91(-40.08731944160087,-47.45539789917461 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark91(-40.1672837767123,13.18002751793334 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark91(40.30478608433759,86.64678372622609 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark91(-40.354686695846816,-42.15313595265678 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark91(-4.0389678347315804E-28,18.84955600105726 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark91(-4.046154429903261,-2538.371596779303 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark91(-4.05095780233792,-57.458032913364406 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark91(-40.802606746508104,-27.16090557457487 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark91(-40.84070449317708,-1.5707963267948966 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark91(-40.84070450002576,-0.003920654539451488 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark91(-40.840704615876604,4.930380657631324E-32 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark91(-40.873356956198,-97.05713067382263 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark91(-40.87557439338492,-38.333321422380045 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark91(-40.89974241341381,33.774290820944316 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark91(-40.962301276228665,42.64434202601515 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark91(-40.96884828171476,65.21469495902434 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark91(-40.97820404671587,0.30956465671557243 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark91(-41.07963414944278,90.9588628810409 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark91(-41.18201255402238,5.153783194021681 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark91(-41.276750204447566,-67.39212503680184 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark91(-41.326107951823815,-0.4854059726609065 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark91(-4.1359030627651384E-25,3.14159104169009 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark91(4.141592290082467,90.10618695410155 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,34.456218624495705 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653589794,6.409753986638107 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark91(-4.14159265358981,-0.9999985560969668 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark91(4.141592653590368,-16.061138628331847 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark91(-4.141592752455355,-1.5707963267948966 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark91(4.1416628388041685,-50.12772604248332 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark91(-41.43993220185251,-2540.3284808278404 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark91(-41.459655791436134,2.3546019924119292 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark91(4.162590089211532,-60.71125785382781 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark91(-4.1761948595190557E-53,25.136647478723066 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark91(-41.850121267679675,0.0 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark91(-41.89799793963688,-38.756405286047084 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark91(-4.193618905829169,-50.63158814083906 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark91(-41.944265869682965,-80.17281161660736 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark91(-41.9809543505815,-38.75187910198198 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark91(-42.042862358847714,-33.20214628649897 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark91(-4.210012489770833,-45.193992615708844 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark91(-42.270011004847106,0.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark91(-42.29248418858748,61.644356694284596 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark91(-42.374137569758474,31.88869697441993 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark91(-42.411500823462845,-1.5707963267948963 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark91(-42.41267670810225,-1.5696204421549078 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark91(-42.44138838714393,65.45646763937364 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark91(-424.5592074691471,-1.570787783052858 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark91(-42.550490456696714,91.0677817349538 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark91(-42.59816572306061,99.05523851591255 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark91(-42.68103767036686,56.063578428103256 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark91(-42.70217064024814,1.5707963267948966 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark91(-42.75731545808776,-2.5653355008114852E-290 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark91(-42.816894705509355,1.1652372849284787 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark91(-42.925699512371764,87.29040963941003 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark91(-42.94458085526893,80.11061266653972 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark91(-42.96721536453282,17.78350685780775 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark91(4.2989788492618946,51.42286865310879 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark91(-43.153879504159406,-15.062400693309677 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark91(-43.213451963476544,32.47306969803478 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark91(-43.35410213791808,0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark91(4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark91(-4.3368086899420177E-19,-16.207965710183938 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark91(-4.3368086899420177E-19,87.96459428677184 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark91(4.3368086899420177E-19,91.10617153079734 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark91(-43.42843383713227,-6.837048620304424 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark91(43.78618093944232,-60.40655197630211 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark91(-4.3790577010150533E-47,-50.26548245743668 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark91(-4.3790577010150533E-47,91.10618695410399 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark91(-43.800138923328745,-1.570796326794781 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark91(-43.981409407432004,-1.5707963267946994 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark91(-43.9822966746034,21.991148071754804 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark91(-43.98229714149448,-50.26548240189459 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark91(-43.98278543156006,-84.82299973417187 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark91(-44.00438221504843,-74.61181010245639 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark91(-44.017555656095155,-64.72144139894165 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark91(-4.41279763837268,99.2597599300905 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark91(-44.14008401396161,-2.379713756882084 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark91(-44.152388453987946,-58.86927846817154 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark91(-44.25108610732431,26.191506603915222 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark91(-4.4354801715190905E-16,3.14159252238985 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark91(-4.440892098500626E-16,37.840735464100945 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark91(-44.412910025781585,-79.48154431902037 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark91(-44.42789780229275,1.5707963267948966 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark91(-44.442622857326214,6.743511016930269 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark91(-44.474659670565295,-29.755915841967678 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark91(-4.457869377216845,-18.92049561492722 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark91(-44.75723303306481,1.5707963267948983 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark91(-44.79003163030514,29.20382854984868 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark91(-44.923814879523505,1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark91(-44.924464145645004,0.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark91(-44.980910788730085,-53.80291525873611 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark91(-44.98211831455649,-56.46128090347784 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark91(-45.04864146455073,40.5266085088041 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark91(-45.0792512503819,1.0968666889890109 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark91(-45.107948908444406,1.125651758187301 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark91(-45.13061553033068,-92.56584388053646 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark91(-45.2371870874724,25.106572945800096 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark91(-45.33368728917354,16.793583883679332 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark91(-4.534334474452622,-52.014333290163655 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark91(-45.45343808907902,6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark91(-45.51372606007848,-77.27705626204931 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark91(-45.553093477049735,1.5707963267933618 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark91(-45.584035640696996,50.17430658305449 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark91(-4.571652837985198,-95.76946123963812 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark91(-45.838214128351254,-3.0417465060722557E-210 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark91(-46.046827136412155,-9.42488398806275 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark91(-46.23680224175959,44.58598655112874 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark91(-46.32728102781365,1.4682607025854963 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark91(-46.42181077049472,0.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark91(-46.453620996372244,-9.975149465263485 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark91(-46.76103261211232,31.66627700711723 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark91(-46.796327934933224,47.047025265616384 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark91(-46.862677519741226,-73.47229658794545 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark91(-4.68909372977358,-69.89617970905024 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark91(-46.91562043263646,63.53113233619854 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark91(-47.03191987385055,0.09196992999635085 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark91(-4.706263779765472,-1.5646711261756974 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark91(-47.09347258941185,0 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5706842712845943 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948912 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038469,-1.5707963267948966 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980384719,-1.5707963267948966 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark91(-4.71238898038483,-1.5273918775827486 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980385123,-1.5706457147741746 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388980390132,-1.5677180101971082 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark91(-4.712388981699958,-1.5692965684157576 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark91(-4.712401216956456,23.561957093331394 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark91(-47.13951480404717,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark91(-47.1551397138749,-94.2790296076938 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark91(-47.35661781502245,-61.168465508524726 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark91(-4.746514361220706E-15,4.746514361220706E-15 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark91(-47.466343078913766,-25.747888467009034 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark91(-47.55245463404319,6.283246342335839 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark91(47.601909404893064,-87.3816339559554 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark91(-47.77084547358093,-77.93304163021307 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark91(-48.02298728624561,-33.23537478192739 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark91(-48.124303106518035,-6.02495651468405 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark91(-4.815479449542371,-7.7508911648168 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark91(-48.27267341203021,48.779647810869164 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark91(-48.34827451262833,-1.2243847087814308 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark91(-48.406795002561026,-1.2829051987141273 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark91(-48.61351197948382,-1.56510793084832 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark91(-48.6199211194476,66.78158868318016 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark91(-48.65563749108561,2616.786857782368 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark91(-48.67992934242967,-1.5707963267948912 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark91(-48.72201663740044,-9.243148709144631E-17 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark91(-48.768838757767675,2659.273490096335 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark91(-48.785725573770506,61.84381349933719 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark91(-49.094065920357124,-45.53388831432898 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark91(-4.917614030756489,92.4717582305271 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark91(-49.21222507813396,-1.053113171644262 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark91(-49.21825114286222,60.183706208754074 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark91(4.930380657631324E-32,1.5707963267948966 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark91(4.930380657631324E-32,50.2654926791146 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark91(-49.425928399071715,64.46882690213056 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark91(-49.69510729621001,116.80930334404903 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark91(-49.70421013613864,0.7960356827221418 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark91(-49.71676727517958,82.62054599206093 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark91(-49.83772408135799,0.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark91(-49.92878988174171,92.26123928774241 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark91(-49.94665081675542,25.295692500257225 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark91(-49.96744173231903,21.358446032639623 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark91(-50.01171333028409,73.68512652084561 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark91(-50.02861971560518,1.5707963267948961 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark91(-50.03603134656924,2278.6914522954553 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark91(-50.04172932827587,2.0501330894674953E-143 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark91(-50.05757111792701,3.0041327865819327E-22 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark91(-50.083376593266145,1.0553178144107943E-227 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark91(-5.009448019471521E-15,6.283186568653289 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark91(-50.154263306140784,91.10618805701198 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark91(-50.26547843046642,-6.533321494885771 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark91(-50.265482445519794,9.424777665391437 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245743543,0.0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark91(-50.26548245743668,0.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark91(50.31754674688048,-34.37773702252986 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark91(-50.37949861087994,-4.141592653589794 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark91(-50.452343091997975,0.1868606345612827 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark91(-50.46164650035472,35.23216560046815 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark91(-5.059157605646196,23.215176276661943 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark91(-5.0730833781487945,-1.2101019290307922 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark91(-50.89094312580962,0.0 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark91(-5.097803698729993,124.47832453514214 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark91(51.04512110916525,11.390225370791256 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark91(-5.108161105334859,98.56439646312832 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark91(-5.109909686509671,-26.30601684938826 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark91(-51.14266963862531,44.02915457400621 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark91(-51.17044387881829,83.95574035737573 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark91(-5.120453151557272,-8.853983392984421 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark91(-51.22338232841548,-0.7360877150334915 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark91(-51.27181612917919,-72.07557351058128 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark91(-51.331877058255806,0 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark91(-5.136876054506536,23.986431976045296 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark91(5.141592653589803,1.141778624939431 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark91(5.1415927471154514,1.3017540730736719 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark91(-51.415940047843044,93.91653312110319 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark91(-51.45070363723063,-2620.6785867202775 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark91(-51.586077882284364,83.50240622207674 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark91(-51.650609058269055,-87.28174281968283 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark91(-5.169878828456423E-26,-122.5260197401375 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark91(-51.72236830748282,-55.09381925639913 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark91(-51.725680022284216,40.187972448171905 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark91(-51.79472236423261,-94.92962498896189 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark91(-51.82691103604785,1.5706176750271312 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark91(-51.82772912746486,-48.68613647387505 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark91(-51.836278784228796,1.5707963267948966 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark91(-51.89539608068887,26.762654851970524 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark91(-5.210696936785311,-51.03675811573539 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark91(-52.26258690907669,-67.11793392733546 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark91(-52.305925863626456,-20.016907404503286 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark91(-52.333477594546984,0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark91(-52.33517092381539,58.618356230994976 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark91(-52.35133426388827,77.24850791044605 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark91(-52.43797705882023,-95.40311337673113 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark91(-52.47315280125306,91.10618696253007 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark91(-52.538676936377165,-36.73034739507352 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark91(-5.260616760658493,-86.28799708254712 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark91(-52.632635249035786,58.7399538913738 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark91(-52.70181951163708,-42.88273804800542 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark91(-52.79446760598028,-51.86459178245355 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark91(52.82835022340825,54.27867045646374 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark91(-53.2453454641078,-37.89919955097584 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark91(-53.387628655628916,-66.31025888477775 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075106940326,-3.141570765207691 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707511102636,-1.5707963267948966 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075111026465,-131.94796837175465 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707511102647,1.5707963267948966 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark91(-53.40707511149215,1.5707963267948966 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark91(-53.407075587863645,1.5707963267948966 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark91(-5.3475197187597745,74.46255809773523 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark91(-53.50659703222737,-0.09952192120088346 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark91(-53.53335333465709,0.0 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark91(-53.55021288926624,47.9356599653388 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark91(-53.560587194148404,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark91(-53.72825254307039,179.39195868666212 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark91(-53.75943959116434,84.34480426761111 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark91(-53.79943462514285,-1.2826677504057426E-290 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark91(-53.84159358003705,20.06228689247986 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark91(-53.915496526221006,-25.641162643912867 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark91(-53.918396980946135,1.5707963267948966 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark91(53.97097523608318,-15.901436166685073 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark91(-54.100836332075545,-68.36552633025289 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark91(-54.16539934102944,-12.56088080392731 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark91(5.421010862427522E-20,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark91(-54.24660250556543,-0.8396541856842007 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark91(-54.305296029099694,0.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark91(-54.48218480770133,55.473558056064704 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark91(-54.559925955291895,-133.9356332600957 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark91(-54.625877905747885,31.29122504873581 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark91(-54.90808298088062,-37.69911184312048 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark91(5.493779480834194,1.5394180199837606 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark91(-54.955626990958635,-37.50520434295683 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark91(-54.9593980197211,-1.5707963267948966 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark91(-54.97787143781954,-1.5707963267943323 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark91(-55.061886417401865,0.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark91(-55.071872397204345,0.0 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark91(-55.11935007580658,18.289329215091122 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark91(-55.12560581785921,77.13133028678826 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark91(-5.515199904107148,73.02461643563768 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark91(-55.317271263909575,78.44893661939349 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark91(-55.32791734876056,1.5707963267948966 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark91(-55.33791258813134,-2.1084395886461046E-81 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark91(-55.34445254033365,73.64088120478377 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark91(-55.3474466801979,1.5707963267948966 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark91(-55.35713206187689,48.31542550658629 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark91(-55.40066870872138,21.894193634370723 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark91(-55.43107254664478,10.439943122608101 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark91(-55.43860689358509,82.05548746773287 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark91(-55.47673432978206,0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark91(-5.548444377251309,-0.7347377669491403 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark91(5.551115123125783E-17,1.5707963267948966 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark91(-55.52948358976817,0.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark91(-55.53608860194756,73.18854531130361 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark91(-55.64194186787685,59.770731886819505 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark91(-55.665288873830136,98.4962834688568 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark91(-5.587466697050344,-126.35942475372097 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark91(-56.12622947316013,1.5707963267948912 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark91(-56.2963232016778,71.39184839047365 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark91(-56.2967632384363,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark91(-56.346103118793025,8.393128936975842 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark91(-56.35722248452639,15.443774097261322 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark91(-56.36274586817969,0.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark91(-56.41898619173521,169.51632172096777 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark91(-56.420782735458886,-19.349555921538844 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark91(-56.42146082632173,40.984876110934074 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark91(-56.46663777513917,50.863328785645955 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark91(56.51224357525541,97.07366806802096 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark91(-56.5142521241127,84.92137373262035 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866758448715,1.5707963267948966 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776452187,3.1415926346488754 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark91(-56.5486677645682,78.53981601349086 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461443,81.68922158435481 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark91(-56.54866776461674,0.0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark91(-56.54868781298762,270.17696051437457 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark91(-56.65406990067656,-9.598059608932038E-240 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark91(-56.72478192822423,34.72956048468444 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark91(-56.729854367789024,25.260635876418476 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark91(-56.74451952597905,14.860104273718438 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark91(-56.77762697035811,1.5707963267948966 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark91(-56.8688085524663,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark91(-56.87879382794526,-43.5607242637871 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark91(-56.96726428134785,-3.5601891703213666 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark91(-56.980228406560855,-55.31952663343431 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark91(-57.08250789669381,-91.70228806406922 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark91(-57.168611649824406,48.56917621795466 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark91(-57.17657405420666,9.74899365180704 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark91(-57.32916666471972,1.5707963267948968 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark91(-5.735092034250513,-13.82271422320116 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark91(-5.739718509874451E-42,-91.11013962945275 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark91(-576.4803203418085,-1.5707963267948912 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark91(-57.679125887735225,0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark91(-57.77728952977639,-68.71489009483325 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark91(-57.79049707265629,28.204343489533294 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark91(-57.84751872699656,55.26359414354681 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark91(-57.89954602813695,1.5707963267948966 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark91(-57.945453800908275,9.639679460411536E-181 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark91(-57.96632868950455,145.93092299001876 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark91(-58.01207050888889,-111.59239464490526 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark91(-58.0455207427339,-21.713593754528617 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark91(-58.09809512743424,1.5707963267948966 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark91(-58.119464091409384,1.5707963267948966 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark91(-5.813971373141133,-82.15062292737308 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark91(-58.48407627700416,81.84679639473207 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark91(-58.72030040065972,1.4788152327084684E-272 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark91(-5.88082473678125,0.0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark91(58.88456434574013,19.42216859540919 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark91(-58.93634902206142,-30.662015139753283 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark91(-58.977630668567,0.7126275739533011 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark91(-5.899342731553901,26.681237731824694 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark91(-59.03149322333361,5.228606848929445 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark91(-5.909106315382871E-126,5.3224498000101884E-110 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark91(-59.18164727492925,63.34046621507269 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark91(-5.918601176128629E-8,169.64591466766817 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark91(-5.924412866661697,-7.97970035067104 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark91(-59.60384723147414,-66.90402010665238 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark91(-59.6902363488164,-81.68143951155295 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark91(-59.690260418078715,0.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark91(-59.69416666855752,0.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark91(-59.75199948246856,1.5707963267948968 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark91(-598.4122596809252,1.551005791981242 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark91(-59.93769848693529,0.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark91(-59.94281032864444,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark91(-600.032451388763,1.5707963267948966 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark91(-6.023643952129348,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark91(-6.026947654462421,24.87650357600118 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark91(-60.278970415449116,0.25363685902205835 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark91(60.33719331369019,-86.56392594541896 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark91(-60.51008323286173,21.483581219492553 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark91(-60.58234074115643,-70.64183134700873 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark91(-60.584744881123854,-61.28639933256237 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark91(-60.6517459380298,22.55262693507484 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark91(60.67842126880788,-67.23562307227567 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark91(-60.694299080941086,-87.2691348208015 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark91(-60.76210691126993,-1.0715944907627737 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark91(-60.85951714553593,-0.21409377911963734 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark91(-60.89688943227704,-1.5707963267948968 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark91(-60.942416478205104,-1.252156059999032 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark91(-61.00490586917901,-10.278022663789415 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark91(-61.052417194827115,-1.3621567766210432 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark91(-6.1078238951616495,56.37330635259834 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark91(-61.242849843986384,-1.5707963267948983 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark91(-61.25355205626421,0.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105629015214,-1.5707958719447075 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674499662,-1.5707963267948966 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674499902,-1.5707963267948966 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark91(-61.26105674499988,-1.5707963267948966 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark91(-61.261056745000964,36.12831551628345 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark91(-61.26880003116972,1.5707963267948957 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark91(61.27275859638965,-80.14305897322554 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark91(-61.28052986216851,-1.5707963267948983 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark91(-61.309229755762324,33.15044657185149 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark91(-6.142604017333958,37.55853055323189 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark91(-61.60996756316413,0.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark91(-6.162975822039155E-33,50.26548245755335 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark91(-617.3196573646744,0.6020016376481194 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark91(-61.81061950186541,-46.650993949496346 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark91(-62.187387805002004,-119.01695541104534 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark91(-62.24528179638354,-36.35376158970309 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark91(-62.26803903111946,0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark91(-62.42886317268251,38.07249046036762 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark91(-62.5411868725376,-1.5707963267948966 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark91(-62.5836222214416,-85.44899812183407 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark91(-62.68514706126173,75.2515176756209 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark91(-6.280215066806562,86.13757394976432 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark91(6.282151321943802,-34.55550567304098 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark91(6.283185306999015,1.315931506456802 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307111139,-0.9814529510221581 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307177243,0.0 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307179585,1.5707963267948966 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307179705,0.1976338163293609 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark91(-6.2831853071837145,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark91(6.283185307184089,2.223356158502605E-16 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185307184927,1.5707963267948966 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185336982206,-3.8518598887744717E-34 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185346862072,1.5707963267948963 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark91(6.283185784016747,1.5707963267948966 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark91(-6.283185784017091,1.5707963267948966 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark91(-6.283186040008992,0.9690911737696323 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark91(-6.283187387037044,37.00980123237767 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark91(-6.283189122698264,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark91(-6.283189725713715,1.570796326794896 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark91(-6.283210144553516,0.4516873069566642 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark91(-6.283307378136245,1.5707963267948966 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark91(-6.283323526530118,0.003904760506167188 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark91(6.283411395563805,0.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark91(-6.283684110094598,-73.38884079802548 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark91(-6.284161869684816,9.878972870169963E-4 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark91(6.284164898959865,0.0015318064386799861 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark91(6.284184111032787,18.849399914818108 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark91(-6.284744498135322,1.5707826212149567 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark91(-6.287091557179587,1.5707963267948966 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark91(-6.28709155718003,1.5707963267948968 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark91(6.28709155782957,-72.25582558072867 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark91(6.289404382029974,103.67877664330976 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark91(-62.89435307179587,0.0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark91(-62.89435307179587,-1.5707963267948966 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark91(-62.894353446484054,-270.1967478558736 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark91(-62.92185113859499,-0.08993410102566306 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark91(-6.298810307179587,-1.5707963267948966 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark91(6.298810307179589,0.0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark91(6.298810307728584,1.5707963267948966 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark91(-63.0260353519047,34.36333690937889 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark91(6.314435307179588,-25.154940222343726 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark91(6.314435307179695,-28.24495125066765 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark91(-6.34995899268243,0.0 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark91(-63.61004358368658,-1.5707963267948968 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark91(-63.64076696027085,-83.38469802348929 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark91(6.371646743628531,-17.34149718107041 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark91(-63.73549180460385,0.9036387328079887 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark91(-63.92037881600185,-42.89377140605112 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark91(-63.99984949800473,50.25453844704075 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark91(-64.15928920863594,-62.88766165212909 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark91(-641.6004533101116,1.3451987428306125 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark91(-64.37882309909799,1.5707963267948948 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark91(-64.3995357268273,1.5739099985583336 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark91(-64.40264939858602,1.5707963267948948 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark91(-64.49259344367584,84.7004622173639 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark91(-6.462348535570529E-27,-100.53061332407076 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark91(-64.62452735880403,-1.5707963267948966 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark91(-64.65732841067029,-1.6144575721085346 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark91(-64.82268096287375,47.36380136886052 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark91(-64.92092180909073,1.0520606506368502 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark91(-64.93382597920825,-29.54461056218739 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark91(-64.95961447351837,84.89204759215559 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark91(-64.98314151272749,-62.95575733218391 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark91(-65.06334206871729,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark91(-65.21709203241667,28.02749342575429 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark91(-65.29957649849331,84.04541386142222 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark91(6.533185307179587,28.403207673895 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark91(-65.38234104147736,1.5707963267948966 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark91(-65.5877296751668,3.906623403161319 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark91(-655.9144604701199,1.2873139728772034 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark91(-65.60404021874933,-100.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark91(-65.63099983525503,31.431909572334096 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark91(-65.69341682726122,20.70930587427422 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark91(-65.81402485190586,-1.5707963267948966 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark91(-6.589006799132829,25.667300734205476 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344572538235,8.414954176610412E-10 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344572538564,2.906803978234225E-5 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344572538567,-1.5191611930212893E-14 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark91(-65.97344596380536,15.707963267939961 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark91(-6.605506713523071,-72.57895243890873 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark91(6.6174449004242214E-24,56.548809704014644 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark91(-66.26171448049382,18.46915977737369 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark91(-6.63399853183744,46.773076579189045 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark91(-66.37787543485183,84.81033097045568 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark91(-66.41789435451287,-62.02784259666021 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark91(-66.46684159986967,23.370998302185725 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark91(-6.651530676604244,-42.65395699496769 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark91(6.652315710555941,37.329981439701164 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark91(-66.5377275108021,-79.43020862210975 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark91(-66.53999466911313,24.296218185814517 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark91(-66.78263454655985,-53.061102449505505 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark91(-66.9257811578727,-1.5707963267948966 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark91(-66.92602423540804,49.93392036583594 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark91(-66.96161794733419,28.275878308374683 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark91(-66.9688718401105,35.12503708552893 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark91(-67.01405063661264,-62.027541387859486 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark91(-67.04346673899207,-7.3769676957865045 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark91(-6.7071419157063445,-84.38681631225377 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark91(-67.12269446079237,6.992143678912029 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark91(-67.1264946287064,-28.595243984403822 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark91(-67.2444077338285,-2598.117647712875 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark91(-67.25716221665304,-1.5707963267948966 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark91(-67.2764310310264,53.625939909422925 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark91(-67.33515562502046,0.20920203338113932 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark91(-6.754056414725838,-33.82022417892992 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark91(-67.54424205217843,-1.5707963267948966 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark91(-6.755001919960961,1.7894596039159438 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark91(-67.56495388157082,-57.2268303050246 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark91(6.764753863977191,89.4041523534741 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark91(-6.774224342006134,1.5707963267948966 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark91(-67.82025103015404,1.5707963267948966 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark91(-67.89484348080242,93.38360253290136 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark91(-67.9324436020454,-64.6014201160281 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark91(-68.17052317591168,-65.27161743317856 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark91(-68.49328511927033,-96.51113330241901 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark91(-68.67686903700348,-30.079448506554012 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark91(-688.3134903650425,-0.331552883358166 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark91(-69.00211688549602,-23.440497115951956 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark91(-69.06695975119422,1.5707963267948966 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837881416,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark91(-69.11503837897547,2.3151685948686577E-14 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark91(-69.13066337897544,6.298810307179592 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark91(-6.938893903907228E-18,-1.5707963267948966 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark91(-69.40596642506699,-0.29092806820100325 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark91(-69.43349866005005,38.012768942811874 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark91(-69.43632202064165,-77.02922063347098 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark91(-6.959182525784314,-3.580012420167469 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark91(69.6597230429285,0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark91(-69.66972755326819,25.012993521175595 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark91(-6.9689628331516005,-1.1392378155556871E-305 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark91(-69.77997135925101,2612.93032485675 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark91(69.82494276466247,95.96150078257216 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark91(-69.86769508231959,18.94125407682426 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark91(-7.009499936818194,-29.000648511946746 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark91(-7.011114390577291,-18.284639314031537 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark91(-7.027007569313817,2.397770391455563 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark91(-70.409582503405,-117.88931712229697 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark91(-70.44213068495102,1.5707963267948806 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark91(-70.52096509513241,0.0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark91(-7.062970060495194,0.7797847533156073 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark91(-70.64423626746944,65.59004545378724 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark91(-70.66809829661528,1.5707963267948966 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark91(-70.67617679221958,1.5707963267948966 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark91(-70.6789938825923,1.5707963267936373 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark91(-70.6858347057659,1.5707963267948966 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576623,1.5707963267948966 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576654,1.5707963267948966 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576928,1.5707963267948966 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark91(-70.68583470576961,1.5707963267944864 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark91(-7.0688064188567505,0.5000001547556165 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark91(-70.83700838475339,-42.56267450244525 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark91(-70.96000310668762,-40.59682611959783 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark91(-7.096361443611741,-23.20098830416448 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark91(-7.105427357601002E-15,-3.5941945133906756 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark91(-71.26608288927002,2699.434336076443 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark91(-7.150525109633103E-14,62.89435307180344 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark91(-7.163785908476555,38.207753029070744 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark91(-7.1746481373430634E-43,1.5707963267948966 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark91(-7.1746481373430634E-43,69.11699150397546 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark91(-71.83254459552184,69.6047318645114 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark91(-7.187971966088117,0.9045229980797029 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark91(-71.93682870264828,0.0 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark91(-72.13933766849006,1.1392378155556871E-305 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark91(-72.25662117607203,-6.283307381801434 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark91(-72.25663103256522,0.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark91(-72.2566310336595,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark91(-72.26444353424547,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark91(-72.36799999745706,-0.11136896489181754 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark91(-72.40802691955767,-34.40441681497744 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark91(-72.43928142270188,13.49743088503979 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark91(-72.44747902187503,-2.430157781377403 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark91(-72.5338855810021,-1.3730926196138284 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark91(-72.53649268854801,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark91(-72.69174754985038,-83.47029808357811 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark91(-7.285974701685888,-9.941385313628984 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark91(-72.88576545099865,-97.82380281144407 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark91(-72.94403265143262,48.14371224223765 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark91(-7.296813850854248,-10.43840650444404 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark91(-73.07914094012143,54.229585018582675 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark91(-73.10926615619222,1.1665795231290236E-302 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark91(-7.32370572070775,34.46138440873733 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark91(-7.331762109695406,21.778874988001625 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark91(-73.47794408656831,-2.621116270731097 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark91(73.50064119518194,-48.94052805845992 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark91(-73.52201759923379,92.11133869845149 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark91(-73.6971005901372,-90.84878798396994 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark91(-73.77405100400362,-9.458522456473773 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark91(-73.82889736948414,-1.5707963267948966 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark91(-74.0657548658229,-1.3324688203321415 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark91(-74.2306014783791,-27.19015102544202 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark91(-74.35702557696338,-1.0411981091916573 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark91(-74.41905275269784,-0.9791563310226765 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark91(-74.46510212482424,0.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark91(-74.4847530860176,14.321072315168308 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark91(-7.463494563034317,49.867560883190606 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark91(-74.68334775576493,-0.8559187188271551 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark91(7.52316384526264E-37,-72.3816323844229 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark91(-7.530130445254632E-13,-113.06853602006791 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368615502,0.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822368615503,0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark91(-75.39822392457363,2.3841429879124408E-7 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark91(-75.42105474967182,0.022831063516787157 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark91(-75.53472505294164,0 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark91(-75.5817624632865,26.922910902925416 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark91(-75.65468317258474,-81.79321961633617 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark91(-75.67926280865831,2700.2688037528073 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark91(-7.578289944449406,1.2951046372698192 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark91(-75.8416194719186,33.05764196707017 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark91(-75.86867013713545,157.68799247219943 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark91(-75.9380955034585,-24.25772431128756 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark91(-76.02114889401915,-20.687072553000686 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark91(-76.07701942480176,-48.02353012057293 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark91(-76.08328227209363,-184.4298661190678 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark91(-76.08542261153252,-9.444763368268266 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark91(-76.18080569007695,88.74717630443612 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark91(-76.18606675843108,-1.5707963267949054 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark91(-76.19831845589154,0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark91(-76.21323428488802,0.06624235072142781 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark91(-76.2937170736545,-2613.0906868010043 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark91(-76.49435197229032,-50.6708010799043 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark91(-76.51420669671742,1.1159830105623854 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark91(76.54973408725797,14.940602404697984 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark91(-76.60256639864542,-5.078842594689203 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark91(-76.85591655408388,83.13910186126347 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark91(-7.688975054329632,-5.4717939929445265 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark91(-76.91171363794167,-51.06757801901135 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark91(-76.91703183711785,117.78950591728187 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark91(-76.98900988392013,-95.06959488272057 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark91(-77.0120002349765,-58.34317046283086 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark91(-77.02582538975507,29.816031260765385 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark91(-77.0659537928311,87.87806014880312 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark91(-77.08117507622998,-27.968660513634305 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark91(-7.708355632142642,-53.73900953982462 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark91(-7.712011837225347,-94.35894879979017 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark91(-77.13244962917787,-50.00111729776493 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark91(-77.16415549666522,1.170634275333736 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark91(7.717870448084296,-39.13379698398223 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark91(-77.19907505555173,-36.0617456364252 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark91(-77.21360861116906,65.78445634765662 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark91(-77.2951493947489,-87.8258170591979 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark91(-77.3028550660541,-49.73510992511408 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark91(-77.30338712200033,90.04139501388346 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark91(-77.38482174239678,-21.9911485845158 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark91(-77.42241436516889,50.64643170414531 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark91(-77.46260961288914,-42.90509042340141 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark91(-77.48572566775931,26.134602961339482 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark91(-7.7719251151976465,7.711743568329229E-180 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark91(-77.78543135969498,14.262698855145242 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark91(-77.91758856269428,-2700.236254808478 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark91(-78.02487397747012,-4.141592653591653 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark91(78.02929160556397,4.466876726229543 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark91(-78.05133439359025,50.75396440359127 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark91(-78.06685796973102,1.5707963267948966 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark91(-78.28145822038488,-69.24770724903323 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark91(-78.333067222938,-1.5707963267948966 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark91(-78.40810995015235,0.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark91(-78.41923557361326,-30.349288448054892 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark91(-7.8426329943454585,27.534893683170395 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark91(-78.44341638052944,0.09639995921538919 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark91(-78.44747777071561,20.457030333164244 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark91(-78.4543957493802,72.52249849685762 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark91(-78.46141930464013,-93.93965388271776 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark91(-7.849128251297923,1.5707963267948974 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark91(-78.5398163397404,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633977431,62.05367787597783 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark91(7.853981633981131,-100.0 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark91(-78.55874737017638,-1.5707963267948966 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark91(-78.72803949507966,-3.4568587494885605 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark91(78.73492819814217,27.008453361663953 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark91(-78.74245466359652,10.745948245872512 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark91(-78.77947336154237,2.4198516903000638 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark91(-78.81895576152559,77.25966406258772 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark91(-78.83838644852644,78.08563840551145 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark91(-79.04001509586249,0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark91(-79.12385255681143,60.87200389895409 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark91(-7.912822623960302,79.62136902090296 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark91(-79.51609482999791,1.5707940486316287 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark91(-79.5292273560484,-2604.2497886483284 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark91(-79.69458308808382,40.64956705866928 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark91(7.970855085662072,73.94424731803858 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark91(-79.88442579829263,24.897251107408636 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark91(-79.95792608729823,-45.7057800562935 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark91(-79.97928764817507,-55.22182816553362 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653779,-1.5707963267929421 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark91(-80.11061266653972,42.411500823463484 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark91(8.036151553134161,-7.671871528909522 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark91(8.077935669463161E-28,84.82299986708709 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark91(80.99952270094735,-97.13951113774415 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark91(-8.103981633974506,1.4950165647155045 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark91(-8.103981633975627,1.5005329660580666 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark91(8.103981633980034,-1.320938065485742 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark91(-8.103981633984626,1.225829401824122 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark91(-8.1039816518734,1.320797085300854 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark91(-8.104101048296453,1.1415060155128756 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark91(-81.15270351112349,100.00225943266224 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark91(8.12149553973752,67.81168282781093 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark91(81.29382626176547,94.68301303901097 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark91(-81.39942363909103,89.58623743790181 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark91(-81.4081354214583,3.6498303049006893 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark91(-81.42447369266172,60.64134198670501 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark91(-81.53883083289435,0.0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark91(-8.156630584998156E-56,-81.68140899333459 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark91(-81.67673967568157,-15.73732770366935 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark91(-81.6814089933346,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark91(-81.68922149333538,-34.55751918941087 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark91(-81.68933905864814,-78.53981587267482 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark91(-8.169369338146119,1.255408622623261 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark91(-8.170047651327934,-2665.2348206706783 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark91(-81.7006201583454,-128.77394936808486 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark91(-81.75474992088404,6.533185307179596 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark91(-81.76866634669688,29.706005738396243 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark91(-81.80485492525442,23.12971935774094 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark91(-81.9264933496246,-34.54414723784349 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark91(-82.11592257255111,2623.335802423858 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark91(-8.216747012668034,54.65023960585245 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark91(-82.20116066654137,8.906140695453773 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark91(-82.26173685403762,-81.53110404603134 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark91(-8.23570878417081,1.5707963267948948 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark91(-8.236092143148846E-84,-6.136366831622158E-92 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark91(-82.47512937451503,-1.5707963267948966 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark91(-8.251382964932347,2.0522684006491881E-289 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark91(-8.251648732391299,84.53141263217358 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark91(-82.5231908720852,56.588914989261035 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark91(-8.256658819818487,2588.881462616795 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark91(-8.273287418837526,1.1514905419318533 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark91(-82.73741722964986,87.63469287039763 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark91(-8.279748896509647,1.1450290642597332 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark91(-82.98716253233572,1.3059881268907163 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark91(-82.9990303482312,89.5904670287458 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark91(-83.174520162031,1.4931111686963763 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark91(-8.320130360525086,-1.5707963267949139 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark91(-83.23886837500766,1.5707963267948966 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark91(-83.25220532012705,1.5707963267948966 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark91(-83.25220532012737,1.5707963267948966 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark91(-83.25765832902745,1.5707963267948912 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark91(-83.26937350667428,0.0 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark91(-83.29054237926778,-64.33661757119891 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark91(-83.35502204639516,-32.652524474607546 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark91(-83.36144429533202,1.4615573515923983 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark91(-83.42938010833191,1.0406237079649487E-258 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark91(-8.3433262456887,127.19303681601876 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark91(-8.352344958233289,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark91(-83.77275535381072,1.5707963267949054 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark91(83.7795291325572,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark91(-83.84162049564823,-37.23421671008457 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark91(-8.392835662913171,2629.8698945625006 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark91(-84.25444682178194,0.0 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark91(84.36830667864902,-37.51144748785489 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark91(-84.52478879062484,23.926234139530123 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark91(-84.5647740244402,90.09525622361488 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark91(-84.58797696680635,0.23502468011806574 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark91(-84.66546726613105,28.737676422843037 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark91(-84.74258462089304,-14.480916007418486 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark91(-84.7457726487921,-2567.8362892746677 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark91(-84.75449926448194,-92.31696835271686 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark91(-84.77469515928453,69.83875466539516 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300144985085,-1.3118286415228244E-9 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300161530142,-91.1061869540917 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300164682825,-31.447176537535555 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark91(-84.82300253287086,-91.11009350106787 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark91(-84.83579733763635,3.1572176535897936 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark91(-84.89837520664709,47.19926336356957 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark91(-84.90129727189047,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark91(-84.95457823316262,15.923905551827445 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark91(-85.07263570672207,0.0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark91(-85.264146769528,-61.53235890303592 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark91(-85.28710202054542,-21.52704820150755 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark91(-8.536539921221861E-8,153.93826192882358 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark91(85.41887739503855,-25.768487082840878 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark91(-85.42736296067967,-0.6042925962051281 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark91(-85.45593459625795,94.72737217350341 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark91(-85.52690609008549,1.5707963267948966 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark91(-8.552847072295026E-50,65.97344572538564 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark91(-85.53635684298065,53.4983904443215 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark91(-85.57857161937712,13.770328791636771 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark91(-85.6406735896258,-96.5717003185822 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark91(-85.76799959181113,71.56635944552369 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark91(-85.86690463946837,-1.0439029925439558 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark91(-85.89824387852713,-1.0752422316027084 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark91(-85.98617757812903,96.83071995849949 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark91(-86.04167519441569,-1.6472184286297693E-83 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark91(-86.10897229508869,5.06E-321 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark91(-86.2898544226878,100.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark91(-86.38331255348848,-19.69854528685451 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797371932,67.54424205218223 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797372047,-1.5707963267932623 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark91(-86.39379797372487,-1.5707963267948966 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark91(-86.5947634410639,-56.15218574343943 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark91(-86.65248965003356,-26.962229231827486 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark91(-86.85682661409872,-100.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark91(8.687100728199738,-43.88705944750937 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark91(-86.97034804742415,35.91488039209494 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark91(-87.07728727377578,-6.7863029946843625 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark91(-87.15306445098243,0 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark91(8.72996596942523,11.870969140524878 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark91(-8.737031409534652,-2644.8000205397384 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark91(-87.74428585156029,-6.53318714899227 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark91(-87.78180268261542,49.72097019697643 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark91(-87.90032150273655,99.06844150156908 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark91(-87.96182364211379,4.141592653589794 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark91(-87.96460955950755,-97.38837145844137 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark91(-87.96465533567051,119.38017866800188 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark91(-88.11084747080155,36.03732430799613 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark91(8.834326886672526,11.975059135520139 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark91(-88.35545069219796,5.053459880608334 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark91(-88.54265599205306,82.46106091773356 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark91(-88.55295866059924,-1.5707963267948968 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark91(-88.56821114536795,-6.6599917309756716E-257 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark91(-88.5775451971536,61.54619962651236 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark91(-8.859760071142603,6.848203197420251 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark91(-88.61397839635552,-3.266592653589794 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark91(-88.66670109504891,91.75387837236607 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark91(-88.67913210166618,29.680837842940733 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark91(-88.70855209694184,-63.207178863728394 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark91(-88.72793810048401,-55.180178668557424 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark91(-88.74678509919106,84.77562787528034 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark91(-88.7618707286364,0.797276428122185 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark91(-8.876335658383336,-62.89090077557863 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,100.0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark91(-8.881784197001252E-16,1.5707963267948966 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark91(-88.97906370078248,0.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark91(-89.08903071147303,75.74366525182705 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark91(-89.1875278590458,-1.5707963267948966 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark91(-89.19176960249975,-77.56474464864655 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark91(8.927343709240116,49.766047017375904 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark91(-89.3456653298345,-71.6164776075261 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark91(-89.37790067047983,-9.431619624149661 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark91(-89.48701183488612,-35.41799009878426 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark91(-89.53539062730567,1.5707963267948966 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark91(-89.53539062730835,1.570796326794893 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark91(-89.59303865842642,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark91(-89.689285640501,-48.540791117449906 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark91(-89.71600661442527,43.23037204572228 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark91(-89.74894087258357,1.5707963267948963 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark91(-89.82737691840079,75.89499889424971 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark91(-89.82888663437755,-86.43637735213878 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark91(-89.82911888452762,58.272851424135816 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark91(-89.84061132584523,-102.5559613285878 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark91(-89.84258469429315,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark91(89.97016076737341,66.2341610352021 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark91(-90.01625578451772,84.41400761888556 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark91(-90.05247884887456,13.62007871958862 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark91(-90.09169883833512,1.0144881157688843 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark91(90.28650026234783,-51.762310918126445 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark91(-90.35709420294988,0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark91(-90.58376654760607,-25.519886381671512 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark91(-90.625645411262,-84.72947664078421 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark91(-90.72085833084728,26.398899324056124 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark91(-90.75853706024658,59.426457910049066 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark91(-90.77007324957285,-1.5707963267948966 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark91(-90.78285843674878,-3.0019282873894326 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark91(-90.85359609676978,0.25259085609800014 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark91(-90.93551477993242,-55.43980305630217 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark91(-90.96493026216446,-1.5707963267948966 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark91(-90.9706678282638,0 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark91(-90.98250054139251,2.5465402278821463 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark91(-90.99928386823399,57.54637972043096 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark91(-91.10261239950101,-57.695068674878826 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark91(-91.10342980093087,-3.144621036262983 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark91(-91.1061827052763,40.84071981766381 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark91(-91.10618695408385,40.845661670328724 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark91(-91.16683991875895,-0.06065296465494896 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark91(91.21623430190013,-19.581608843186586 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark91(-91.39672152327137,-10.194996260368995 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark91(-91.82492538517273,23.27184471887317 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark91(-91.90579800846153,-2.9930319366467444 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark91(-92.08800490066211,-5.327993384780537E-256 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark91(-92.19573355360879,-76.67054346039437 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark91(-92.28430633759682,-5.635165833937733E-17 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark91(-92.4124184335664,-1.5707963267948968 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark91(-92.44128428216041,-62.813502975593515 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark91(-9.250579949869348,-54.561883781613254 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark91(-92.81890841682146,17.136834458821305 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark91(92.88867283776815,94.11905869729853 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark91(-93.03047598953061,-1.2173036181631827 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark91(-93.17788509450986,99.36340515894054 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark91(-93.22357010539494,-75.09062532544834 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark91(-93.26235425205098,6.543576858943467 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark91(-93.52061381619995,6.015375485018453 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark91(-93.7824742534723,0.46530520797415137 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark91(93.78388510163265,20.752641144969573 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark91(-93.88662823747289,-33.4268782810401 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark91(-93.89760971438204,-0.3501698933117547 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark91(93.92833798315837,54.754513843014365 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark91(-94.1980460533259,-1.5707963267948966 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark91(-94.22429165139005,-75.59234308436848 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark91(-94.24773543284918,31.416048606210904 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark91(9.424777168875899,21.991148572457035 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark91(-94.24777840072463,-81.6814089863795 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark91(-9.424777889410926,3.1416002829843284 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark91(-94.3379802648806,0.09019866340476138 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark91(-94.34693512301773,0.09915358390989461 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark91(94.3986163874421,65.26872505497263 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark91(-94.5165470542371,0.2687674465432969 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark91(-94.60723767905543,-87.18108259710584 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark91(-94.62980226045164,0.0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark91(-94.82820672324445,0.5804271155506519 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark91(-95.19097662792588,-1.1786276243417717 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark91(-95.24005907383567,21.584621992732536 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark91(-95.25522955272938,40.55389362968731 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark91(-95.3809761566776,-17.248395605989614 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark91(-95.5010835147987,-54.66037901813138 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark91(-95.64373643548765,1.395956827793857 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark91(-95.80464130169887,1.5707963267948963 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark91(-9.591963577487945,-6.413338752028713E-291 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark91(-95.92450616087814,-1.5707963267948966 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark91(-96.07018794128157,1.318627338150537 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark91(-96.17749514526905,-73.51535308722983 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark91(9.645783632717709,73.93942510292965 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark91(-9.645795191514347,43.98276493082025 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark91(-96.65543128483223,81.66831620299791 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark91(-96.72852307305075,-69.11503837897546 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark91(-97.01097103059024,0.3784011683517709 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark91(-97.12086751244033,93.29092065857131 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark91(-97.16681804135376,-14.256610531032578 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark91(-97.22009338109785,-36.76195467074932 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark91(-97.6033028578449,-0.2139277894600358 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark91(-97.61367591270093,-1.5707963267948966 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark91(-9.762904469585969,-1.570796326794896 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark91(-97.6573932197542,-23.244449228387577 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark91(-97.7558890242569,-55.13982350749004 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark91(-97.90677006519586,-65.61851553839696 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark91(-97.92334055877308,-114.93600353671168 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark91(-9.794877308154895,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark91(-98.08723614461132,-93.12497477935263 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark91(-98.32465320909967,-95.28283386088849 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark91(-98.39506247578244,-1.0056949018308927 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark91(-98.44931963998266,-19.511100929565842 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark91(-98.56748846108687,1.5707963267948966 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,1.8778431903708163E-18 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,50.26548245743667 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark91(9.860761315262648E-32,-78.53981982866208 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark91(-9.860761315262648E-32,84.82299951134014 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark91(-98.65312303640468,-1.5707963267948966 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark91(-98.65357444376252,0.0 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark91(-98.66464314287117,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark91(9.872849305892109,-49.81741111231396 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark91(-98.81772918638869,-1.5606735799577394 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark91(-98.85436607668288,1.5707963267948966 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark91(-98.93682404176703,-95.79523138817723 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807828,-1.5707963267948966 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858807849,17.278759594746486 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark91(-98.96016858808208,-1.5707963267948966 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark91(-99.07432501826054,-31.640916917789255 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark91(9.924777962988358,-169.45986236054804 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark91(-9.927127772782361,43.47994733824412 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark91(-99.47798497531429,13.233971033266343 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark91(-99.48730584653782,19.574420927582587 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark91(-995.2541992381557,1.5707963268223248 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark91(-99.5554727648487,-44.78939790093912 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark91(-99.71486371622403,-133.8105892541342 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark91(-99.73319733204941,-7.080952890003556 ) ;
  }
}
