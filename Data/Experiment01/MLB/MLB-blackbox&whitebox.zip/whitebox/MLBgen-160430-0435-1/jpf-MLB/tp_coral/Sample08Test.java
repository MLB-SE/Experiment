import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(0.0012076717718289484,-2.024230979176301,160.78516728180858 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(0.0012635862516496843,-94.21541941601463,13.194501878059981 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(-0.0015485363966296773,17.938770380296607,35.99862474074662 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark08(-0.0016493577803210254,-32.933695594995875,28.917752511998078 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark08(0.0018516270997781734,-16.438194815557285,-32.85430970262403 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark08(-0.0019184777394639662,15.762107161479264,31.863701306214484 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark08(-0.0019442819141719735,20.096104378256967,40.20210216482763 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark08(-0.0022483748382959605,-18.77814782859251,-23.432776719056807 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark08(0.002674732634171039,-39.85293460529094,-72.65107095620606 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark08(-0.0046180605891914936,10.408282963983893,20.80469161573207 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark08(-0.005576099305602264,11.738768287123417,23.828844930724678 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark08(-0.00965232606372026,-62.46773708052358,-122.45041955189689 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark08(-0.009996263052339333,-12.933711655795564,11.945512707581635 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark08(-0.01154081030771582,-8.077316972916602,-3.236507243640673 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark08(-0.012707281798045256,-23.235736234131963,5.3199895375942035 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark08(-0.019615256068690162,13.332805297485534,28.17727947977067 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-26.72777560892769,-51.884754891062094 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark08(0.027853045185682265,-42.27809721687518,-1.2428684084923443 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark08(0.028187398888753767,7.220619059911448,16.09659664328405 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark08(-0.029305285849136484,-32.38551752703406,30.844026486088303 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-30.304766529081622,-59.69448622543393 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark08(-0.03126147586034733,-69.38516890733396,-30.551610854898755 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-33.350521390482555,9.500169411086262 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark08(0.0,41.24830395275107,83.76151247550342 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark08(-0.05237869043909342,3.0610461835120177,6.231470894030757 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark08(0.0,-6.11039907417225,26.72897515543396 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark08(-0.06784242170639931,-4.619407537298499,3.484664399016399 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark08(-0.07092475099189197,-48.22557730515797,-52.20539241839636 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark08(-0.07470385953668728,-49.525717355387165,-97.7047499625895 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark08(-0.07588037181883722,-22.152192541410358,-44.224874508555374 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark08(0.08166217594189035,-0.8998261308444915,0.016130592931584475 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark08(-0.08197926983950019,2.899561524928266,6.6082049326202785 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark08(0.10032758858035794,-10.610506802671388,-0.4996791239542913 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark08(-0.11971048044882995,0.1689831318224073,-0.021165177701675295 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark08(-0.12405961613805516,-49.59991787969433,-99.9696387833173 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark08(0.1487064026917234,0.3012900119045203,1.1207999121986525 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark08(-0.16609122150220657,6.515262125021034,30.48320320177764 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark08(0.18858749161388366,-100.0,-22.89372488859443 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark08(-0.20171883969722046,-47.021734828477356,-94.64862617604636 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark08(-0.21666289434143948,8.306768977024522,17.534345597819616 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark08(-0.21676832930722814,2.220446049250313E-16,0.8533868233553494 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark08(0.2168510800651626,55.99155532819308,113.43885720078167 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark08(0.24230193684947154,-33.72923323216266,10.200557905645454 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark08(-0.24594759450219195,-18.826801562073346,0.3392350774548438 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark08(0.2785714726010722,-11.483881044655828,9.722203640617257 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark08(-0.2966843998146259,0.32348051473423056,1.3003140699047768 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark08(-0.3282710428308414,-0.1799966786926921,0.22598984091698812 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark08(-0.3736901175037025,-22.064276490399166,-45.120319275026866 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark08(0.40392795606488835,-25.193763066128,1.9390921234605791 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark08(0.4340218493616084,17.66874514726519,59.390796883827825 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark08(-0.44023049293582145,1.1052293577078398,0.905797462022878 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark08(-0.45331591926106846,3.5651515297486225,6.803602828518078 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark08(0.4662180866345878,-22.118800569972205,20.36632608637506 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark08(0.5182853044573515,32.04419734773907,66.39790025421661 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark08(-0.6114685241944215,27.334014031855848,53.8448172112465 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark08(-0.6503416277954107,13.928746689604205,25.906468495822182 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark08(0.6743645481276939,3.1651396379501096,9.567913402082063 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark08(0.6871911396594478,-13.664267748741315,1.8259692859558605 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark08(0.698731483980088,9.852963192151245,21.859606792132592 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark08(0.7321332833448797,-93.67140774126585,-27.77231071264108 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark08(0.7630574693321622,-2.333853796127088,2.908566216515182E-14 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark08(0.7737742477757834,12.818903505704114,27.959129754736836 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark08(0.8145365544299068,-80.21588340959822,-58.51357262422909 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark08(0.8180328331146929,14.366232319164778,31.939625605242107 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark08(-0.8509412971136463,-9.66872836020703,10.09644225098052 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark08(-0.8559443293537228,10.695342553439772,18.82285211881838 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark08(0.8827461364977743,-3.371922896014357,-3.7940238974573046 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark08(-0.9331964565565315,-16.891329501718165,-36.578533135768424 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark08(0.9514980756989126,-45.790947665971046,-50.02230393932188 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark08(0.9706575071817269,34.59800587445545,58.42049460933782 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark08(-0.986637026567087,-12.519067677504188,-28.920558593661696 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,0.0,-10.233429420303718 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,0.23146605003878307,-21.713191989037288 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-100.0,21.975356387091708 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-22.245932812577166 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-48.307229332727346 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-67.2370632796456 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-98.97713546862701 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-99.26154079484202 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,100.0,-99.66506518704311 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,1.2411048165483773E-4,7.999651612008163 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,12.45505146496563,1.4380992270873776 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,1.2463227109555622E-4,40.11801938531997 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark08(100.0,-125.99936367167521,48.62650913902496 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-13.125570486681482,-99.62706184346435 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-142.71899473977862,-276.28500407573006 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-168.173460633813,206.63142118672363 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-193.40135129212774,193.1662579819668 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,19.610715593305994,16.753174447454292 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-197.80218499790456,204.35663452311164 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-199.73806458434927,175.21933431185766 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-23.185466365022,0.36111660634711523 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-237.2312445277855,149.47639443057753 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,24.76218296911063,46.193005217361126 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-26.449162242731756,-13.569429651317733 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark08(-1.0002653576486114,-23.13886968086338,-36.626825129875385 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,26.76699690533195,-57.683458555552924 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-28.066583229698033,-72.3742365752903 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-28.344511851233058,97.60548507959109 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-4.271776151534505,-100.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,43.33324528776498,69.90717278911653 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,43.51037709036269,57.76226041994357 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,45.066347300357634,54.67078786847354 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-54.42700349199485,-0.2545968585396885 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,5.948648786817628,-98.42920366727571 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,68.99739392876774,59.310425088029746 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,79.35644515873237,16.007491057851023 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,82.7732906877268,-33.57009733737458 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-86.08999266605369,99.99970955908861 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-86.51682990684267,-26.610060257987982 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,87.39455753456059,-67.20598589658702 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,9.089339409244093E-17,77.9396063499336 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,-92.18270868555403,-31.43009942700138 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.76300232828216,-100.0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.81066690349661,-99.7212628639484 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark08(-100.0,99.99745721270143,-100.0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark08(-10.01223275011449,-42.71648517789067,-1.80878109130009 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark08(100.14610406867143,-147.30853906770736,6.25248475501914 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark08(-10.015223457784586,-46.5475387008051,66.47672577459208 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark08(-100.21464017343217,97.44571973183763,-105.75179347395773 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark08(-10.074699421980974,47.721469710273425,66.78963748139881 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark08(10.085241211005526,23.966149119588355,7.502034244754583 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark08(-101.09033643039983,101.40098776825181,-98.52978376359586 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark08(-10.117590865363923,-69.68744440277474,-0.002227861689213429 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark08(-101.33273777767157,100.0,-91.19211530387214 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark08(1.0137250176417312,4.678833657747192,107.67674260215749 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark08(10.182556712569298,-65.48640085885145,-98.85433525320013 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark08(10.18519383692687,-49.973700147239455,-69.39181878369828 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark08(10.18841911892406,36.95229602393821,105.78169337774823 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark08(102.68810112861782,-352.0526170578796,-162.5169923979745 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark08(-10.274512311393373,41.111373558362025,52.25685248572628 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark08(-102.81204338173495,-168.5885069134341,196.70556488272283 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark08(-10.297596068352872,-27.304468215124317,41.156740433324586 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark08(-10.328741908619437,22.089046316985527,57.56895989505646 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark08(-10.340194225278996,-85.97969016656101,0.8519588764511639 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark08(10.34720404112879,-90.84483504600081,-29.754152154647556 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark08(10.386631640460704,13.377283047251959,57.917480830979734 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark08(10.427729750739568,-8.237812534777959,14.807564182662789 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark08(104.34678232700402,-279.5488728684088,175.02872523049652 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark08(10.44180578543093,5.772961204151432,44.442136091390545 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark08(-10.458906984843603,-1.7524197737671041,-34.609056282140344 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark08(-104.69187110397618,35.070399148761844,8.838474873422225 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark08(-104.8387233896691,-215.74422817577624,-249.42481663818796 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark08(10.490905321481849,-14.078344028081444,3.358157499933476 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark08(-104.93754775129511,-101.26469589210598,55.78150107555017 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark08(-1052.9960878550082,-463.1505873046438,-634.9606843583798 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark08(-10.533022187147445,-57.23063213038677,-57.95119175800379 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark08(-105.64064601984602,-21.767624824433867,10.900684496325752 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark08(-105.87678514259477,-5.152359067386455,-7.3266887742009885 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark08(105.97901233743048,-310.65584012667716,150.53138902090876 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark08(-10.599303589870138,-18.036433679509955,-36.266912129305766 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark08(-106.05690664242904,-80.1427043561148,-100.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark08(-106.07091941883496,237.5219306433287,156.83687514583045 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark08(106.16201251154868,-235.77349081267366,-146.51273067337777 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark08(-10.625413303641068,-90.31995617472373,-47.96580969523077 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark08(10.642737375692434,-87.79763235524253,58.904055972726155 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark08(10.67840200591688,-76.14421374839206,69.41950417511427 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark08(-10.753550803111665,16.948811531399,10.012670814195044 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark08(-10.76525663430832,-32.71576801049338,-59.78600517182522 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark08(-107.90033908343874,-245.76122225919357,127.4425303823974 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark08(-10.79971782892369,98.13541935141151,-86.90286571569202 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark08(10.802896051629231,-13.895018214287829,4.662918489453494 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark08(-108.05227211023538,-55.09368069634098,81.9537609030906 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark08(10.817191508762404,-4.395966750228599,23.659641025830016 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark08(10.819846959254837,-17.236136737970277,4.845493451920545 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark08(-1.0869579714053934,40.450068600375374,79.21005961332946 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark08(10.87131594515508,-16.307544701792576,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark08(10.87265136058643,20.897027557994313,75.92725918326977 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark08(-108.73634989105248,-192.06824851659437,-193.71639647258039 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark08(109.04012271229004,-305.9057395147535,-101.60726421757833 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark08(10.929781795381892,28.081328148836015,90.5227980106126 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark08(-10.936488457943112,15.079908740463798,-1.0825459738933125 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark08(109.3891548638669,-260.6023077388638,-85.93959292956372 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark08(10.967866733275944,-41.04768639681276,-11.489971068231569 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark08(10.97219564935288,36.51374481927428,106.02831599977765 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark08(-11.007152492179786,-16.69549155955281,-64.84164426885009 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark08(-110.08527603571727,199.65025130205788,59.77275894794822 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark08(11.040425167776434,-1.4260269525937446,23.730994256553345 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark08(-1.104451112020915,30.775998113396117,58.418068414675595 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark08(-11.063252669194242,65.47539819607066,98.7937070273122 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark08(-1.1072231214646937,-6.558950378076646,-47.855496656445304 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark08(11.098520388263978,-77.80296756632956,35.28852064211021 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark08(11.098905783065629,21.600125364075545,76.65849768594781 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark08(11.10228769635684,24.709373409287096,-32.56021267758604 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark08(111.22573580313066,-247.38848145387448,135.44948533594976 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark08(-11.127213780002378,-12.294531491936894,-57.970704323880916 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark08(1.1199080672886226,19.626963615694848,43.65577772118366 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark08(-11.212682350350114,48.21263441964673,64.358018115038 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark08(11.235887044766883,-63.71851149703345,90.39703299864206 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark08(11.254706019426267,-15.50980752521223,4.315299334649239 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark08(-11.256400615233229,40.443379901128544,47.67781844066894 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark08(11.282831015681312,-41.710673788891775,-17.419748669004264 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark08(-11.31985438724035,20.531538902426103,7.103514643131158 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark08(11.35288590248285,-9.841888349237985,14.712535669664202 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark08(-113.62515582382876,-31.677287751582448,55.59307676808105 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark08(-1.13757524907229,-153.8480541751984,-96.38956094835969 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark08(11.379225380450466,-40.32100727331149,-8.049983335334344 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark08(-11.398838945498241,-61.1015199250404,121.4332099549639 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark08(11.405843686411927,-62.97122959217453,-90.15413179831839 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark08(114.11847527490549,-255.28477002219836,139.6764989570109 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark08(-11.446061888901538,-67.52643290317735,-81.24769375760613 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark08(-114.68286408268922,19.0357308629765,33.80313440874384 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark08(-11.477309807494137,-41.85916835189949,45.220429055344766 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark08(1.1481761544809463,26.3083582035359,57.617893662721706 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark08(11.483140292796902,-100.0,-7.938888063804697 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark08(-114.97153406300085,-198.02808978932327,-149.5877730028251 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark08(-1.1523142295933724,-56.27797722831045,-20.479014824675662 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark08(-11.54491761675093,70.75950107709089,100.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark08(-11.57428882132706,-16.4891212388743,28.06341006020136 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark08(1.1641122185389725,-0.8569794771095636,1.9691713868813185 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark08(11.670213033935276,30.476290129097016,97.53401568679476 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark08(-116.76112999948747,-139.32381907695466,-363.8574661990414 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark08(-11.714482761504195,-22.82245460188699,29.394421254796 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark08(-117.21895109865204,-101.41711524509623,1.952619009449247E-5 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark08(-11.746599605208969,30.413146774834612,0.004396897621620414 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark08(11.747194944462862,-71.76397159581781,-51.445397645108116 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark08(-11.748743095516705,-12.101889589699134,-59.40157263491367 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark08(11.76913226166909,-30.745841770015954,18.97670950834686 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark08(1.1769883497418523,-14.551885715225948,13.374897365484097 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark08(-11.771880284057115,-91.14947672870176,-40.654696807999706 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark08(-117.72716259464062,-188.01855583378554,-181.43368602740077 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark08(-11.798744877155713,-54.485076327535076,-91.78987172090763 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark08(11.802501730697935,-84.03974041756068,-0.0232987856542195 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark08(-11.807005942989697,0.0,-34.970696702704466 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark08(-118.27032236387359,9.910933646750118,105.21744376181732 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark08(-11.857869816474702,-6.180728406440338,-47.93506626230476 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark08(-11.875383399433787,-63.682264532013136,32.86809138428629 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark08(-118.90812168663658,-155.49096937040343,193.28794737103442 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark08(-119.02085261842076,26.67781312406424,92.14984626806522 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark08(-11.914512269444081,3.6170171172513603,-22.004567600715617 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark08(-119.27728319968462,-0.5990293194865899,-100.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark08(11.94752228640007,-29.628013744893714,21.822051900125235 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark08(-11.9883431531963,-4.256879759800009,-44.44639294673691 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark08(-12.0056331022046,-60.08147899585961,70.51631577126932 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark08(12.048490584992571,7.858687363979051,-1.356728763087847E-13 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark08(-12.122602968529003,-6.435817389217457,1.773243528747712 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark08(-12.128998553109074,1.0857082360702695,11.043290317038805 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark08(-12.14457212555841,1.1102230246251565E-16,-34.91749116775131 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark08(-121.53702304683756,-128.87948078446394,-256.64746384242227 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark08(12.15601373881287,-3.3016510341223593,31.42773418097965 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark08(-12.1602095946563,93.36961351556064,131.25639336423387 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark08(-1.2160801052265469,1.113155788361646,0.10081482761998015 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark08(-121.81824023323644,46.17430589966705,11.082994349670612 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark08(-12.185366275858073,-18.533451169627213,-51.14264298385456 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark08(12.191224366877913,-18.286836550318096,-1.2698257804140607E-12 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark08(-12.219834022529186,16.450741099601238,-3.75801986838508 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark08(-12.233268053400453,6.027123554980535,76.11794453666832 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark08(122.80415511577374,-121.61817401408925,219.75406180250081 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark08(-12.281086002902258,-6.0489412550598685,-47.65123099077459 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark08(12.33072140852205,-36.85427242709887,-36.71436128642743 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark08(-12.339729306085882,26.481181374424654,14.13730269534209 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark08(12.358645161825514,-7.084338178253893,24.47805545576365 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark08(-12.372134376724938,-33.12510841606075,67.52273379738836 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark08(-12.385265175537436,-8.450880498815826,-52.67825183323259 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark08(-124.45975602352291,67.82424042906395,-16.52602659674509 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark08(-12.447435793485058,43.74122947954199,51.63200412217023 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark08(-12.46018331824778,0.0142050011750412,-17.374254023055016 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark08(-12.461256947870066,-100.0,70.93580982951191 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark08(12.493812233179806,1.3877787807814457E-17,38.86077358719706 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark08(-12.516595963687744,-55.044705202381856,65.9905048392747 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark08(-1.2529205174879374,19.02715948968698,36.10796025821107 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark08(-12.601124084066335,-35.623830221372046,48.224954305438374 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark08(-12.662163812796194,16.882088803315384,-2.6515175049629205 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark08(-12.668232941251652,17.08065455724159,-3.8433897092717726 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark08(-126.87775526631715,-211.7623946665201,-162.379700257097 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark08(-12.692325387288244,8.657905942576509,-19.190367949916823 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark08(-127.25115639636533,-137.66687199714127,217.69725901960416 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark08(12.798265837939026,-42.71608024238616,28.383340277449953 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark08(-12.820272498200708,93.6721699825759,16.24507515616105 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark08(-128.6997976420995,-190.33069995178087,-193.57344342502546 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark08(-128.9455845130804,67.10106780366823,-94.48317716119993 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark08(12.903469519088548,0.0,83.94226013096282 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark08(12.915715965803285,6.950940673338526,52.64902924408695 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark08(-1.2918170549614979E-14,-30.783767865005405,26.574623849002876 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark08(-129.19263287108228,-181.13304433289028,-146.14324255898848 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark08(-12.94829236185569,6.7894200914137155,-0.017867948783756128 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark08(-12.961480790338081,17.14297035326247,-4.181489562924388 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark08(-12.969589589718403,-64.73036089253733,-3.989465923775504 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark08(-12.978450984768147,-16.705759332188293,-79.59775251411929 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark08(-129.85057550127294,78.5063850591888,-4.987266872803026 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark08(-13.001440191785264,5.669929417607481,-27.510133115908133 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark08(-13.021767281091064,10.848194758885933,1.9818363416875981 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark08(-130.61093815023509,-229.62163033814272,-121.73062890079652 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark08(13.080529453264722,6.513675731044528,52.343740822987044 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark08(-130.93124517254486,-106.89614865695977,236.25725824709227 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark08(13.12305890139076,-2.4655397074811614,36.008893616004826 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark08(-13.163717884845653,-26.282393601828336,-66.88110329633918 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark08(-13.207121199278863,-100.0,-100.0 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark08(-132.2672674311514,276.1469489725141,157.03806272066487 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark08(132.51176999373695,-287.25746043303224,88.17072143536691 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark08(-132.94039240943712,89.8590232805305,39.93919960755295 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark08(-133.59767476421837,-68.81292490399575,91.44447860936052 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark08(-13.36617683730303,20.875280857381014,-10.693998296403933 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark08(13.390653842003545,-38.57202432729729,-4.621450192575466 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark08(-134.24755343836176,81.03155619436937,-20.19285504551496 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark08(135.6552867928086,-254.02271271805265,-100.0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark08(13.582761523932568,2.4166112908115926,45.581507153420894 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark08(-13.614635461303328,18.022394824544367,-4.799116734821244 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark08(-13.622000338822874,30.7746164922024,20.683566095770363 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark08(-136.29491915015038,-163.657202167522,-24.70007862570824 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark08(-136.3685909966793,-272.2472350384361,-110.95610045708744 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark08(13.692142355236129,-61.71967930333581,-68.88765714061087 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark08(-13.73204874740415,-65.10384776458545,-163.56649221342323 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark08(-137.54895370496948,-124.44807349058908,-188.8214900682649 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark08(-13.787177670878526,32.110258564989024,22.858984117342477 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark08(-137.96725998369192,-186.09786870177146,-188.6902237268815 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark08(-13.806730168483714,45.96836342568567,50.51653634592021 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark08(-138.33415203008536,-143.67747774572115,-211.58876109108354 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark08(-1.3836086898439353,-1.1108290556263987,-5.359543888988196 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark08(-139.44200663562233,167.71789144628752,81.52938114334603 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark08(13.957046993097613,-68.73385334830245,-7.3152741957912895 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark08(-13.969963104560012,-171.2977333512948,99.92650846439302 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark08(13.98193840478634,-19.16613309975933,5.184194694972993 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark08(-14.025173307441591,47.20216662872042,-52.770576526003076 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark08(14.031945288715121,26.14632029303749,95.95927277901524 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark08(14.083101873571998,-94.32810942696588,67.42744649991322 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark08(-14.100378997104059,-97.64782965624815,-74.16785638133119 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark08(-14.12722529016655,-41.308813292689095,-55.47590549780709 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark08(14.132290224901867,-18.447412497100785,5.507055343164169 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark08(-1.4210854715201997E-14,25.29372712326558,56.19369782539828 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark08(1.4210854715202004E-14,-85.22195944736373,3.244338144554604E-4 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark08(-1.427458145206125,-39.43025492848433,7.105427357601002E-15 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark08(14.27475027960276,-19.997572316178214,4.39990253324675 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark08(14.300479782087208,-18.72517135808243,5.677106835909171 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark08(143.05146560213763,-105.0849640147929,218.9886740823045 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark08(-143.19690042086944,70.09284369572418,2.482253986639463E-5 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark08(-143.23227063392247,103.31400509898383,-223.00356527896002 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark08(-14.336038575302084,22.74582144459754,90.93010857446004 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark08(-143.43066589286934,-187.63360922452094,-144.3203179038333 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark08(-143.501138373403,-124.82371525448976,200.186869173246 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark08(-14.373376322861692,-6.23329939549372,39.864416610645144 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark08(-143.79455120154006,105.85395157913163,-219.62071348085394 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark08(-143.79936297535926,100.0,-231.1507326015114 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark08(-143.95302847509976,100.0,-231.67678753044424 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark08(-144.3368624140598,106.48409831086093,-218.577251425406 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark08(144.44109848442082,-107.50510973235005,218.76840606683567 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark08(144.6077624428591,-151.66691605986344,146.98643608394931 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark08(-144.7847856908026,100.42935114960264,-235.46679589139677 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark08(-145.394559505159,-90.9466012414506,-182.98110358247217 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark08(-14.555524976976924,-5.351143131000299,-54.36504574406548 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark08(14.558467625072256,-72.66778044716396,55.76390913489025 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark08(-14.563728591273723,-26.70925314425391,-12.321305495999848 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark08(-145.77309527121426,-225.68565736053725,-102.92174047776498 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark08(-145.87950095400586,-56.77651989446572,96.06001925764107 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark08(-146.04117704195735,31.22905111509829,-92.70045529812137 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark08(-146.21043633700612,-54.4477053994535,-87.74317954319156 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark08(14.625580417240585,95.4110223551628,-22.99396889930641 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark08(14.629752784990458,-76.68179553634295,37.669628255540246 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark08(14.630934241464608,-25.315059549813178,-5.166520048437634 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark08(14.631102657299074,-75.63099761245164,-0.2328641641556329 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark08(1.4637774188863992,30.216432394902565,65.9755514036491 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark08(1.4643966969689408,-21.725795157846797,-37.991609571942725 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark08(-146.52423329842665,-112.42368372727833,-205.05127559379358 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark08(14.658328437396976,-22.148157771838658,6.33001837508367 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark08(-146.97314891604225,129.24208800393276,-182.34360557499602 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark08(14.71722052777541,5.930936055136416,56.326860354390604 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark08(-147.2703167419038,142.46371783540818,-155.5925646990245 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark08(-14.741617036793864,-27.036952965327757,40.242530599691165 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark08(-14.751484753502737,-98.34627403160523,43.211845770472394 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark08(-14.791296109774779,15.013484379381506,-0.22228604748109304 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark08(-14.797037795305352,-78.5564520818131,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark08(-14.823155509501966,1.266322473850252,2.4267939054644585 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark08(-14.845271873383878,18.594297264697556,-5.776424763961627 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark08(-14.866494055156371,-27.199312578164022,40.4950103065255 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark08(-148.69615440118866,-85.61672587523502,-278.0167390211549 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark08(149.08935927510115,-117.44971325815985,212.91169988513792 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark08(14.940075714690146,-69.7872203309714,26.106220788244634 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark08(-149.5477037774353,-69.16430148483427,149.5969669812401 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark08(14.962827027622922,-46.13405640015959,-1.8271888261440232 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark08(-14.981056955653706,17.90503938859415,-7.562295762977921 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark08(-149.92305404435797,99.82173328359185,-250.9202906310535 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark08(-150.07679818770922,-98.66298468923935,-339.0455510592459 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark08(-15.019611746472734,1.7433948029528636,-40.649631054536606 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark08(-150.2222341525527,106.43110476095131,-237.39922710561066 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark08(-150.35151122316367,100.0,-237.97982914485638 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark08(-1.5043220673836721,1.603748366261641,-1.3054694696277096 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark08(15.062324666452868,-42.00771179793303,-51.787972021864284 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark08(-15.098638334758187,21.70562916649586,-0.33325356638959935 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark08(151.24638967234205,-85.97792953699819,281.91079557790664 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark08(1.5128339423361645,-100.0,100.0 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark08(-15.15893875114797,48.82705385777193,53.711327405102324 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark08(-1.5194028853920152,-8.852175229905761,9.153383491559413 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark08(152.0335023539411,-142.71770510405378,170.10036827297313 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark08(-15.265385142667485,24.96626413120053,4.436287952621026 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark08(152.8716729054561,-151.9296024123992,155.7694522007821 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark08(15.297899988853317,-39.24093624964503,-2.1698372031421493E-12 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark08(-15.30505419521355,26.497863825780904,7.10642532116904 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark08(-15.328687733430733,-21.329951259565355,-49.829616521283214 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark08(-15.336913036168635,2.1820300624628074E-17,-45.939126677630725 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark08(-153.41680257232125,-288.9585667748887,-164.34118700614295 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark08(-153.4930168065416,139.83816279917576,-179.91699450287828 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark08(15.354337965933414,-16.85573958701837,12.354241440342 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark08(-15.420118278129252,50.59348605230912,54.92661727023049 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark08(1.5473569147409592,3.8014258224629938,13.324405069210684 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark08(-15.475097827953244,-55.02376130430109,70.49885913225432 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark08(15.477970075627319,-20.59574337381107,5.281879271107801 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark08(-15.483527434281553,6.598936369488895,-32.07958700627535 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark08(-155.42214491648664,136.1567737017225,-193.41218978018165 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark08(155.7769023858206,-144.5421707359502,175.36258294696648 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark08(-155.8164220571844,73.93138924057355,-319.3110488527795 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark08(15.604488303215827,-62.03525275100334,-77.2570405923591 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark08(-156.06058861547854,124.82863834259898,-216.98730417167243 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark08(-15.61356945297911,21.377675026900814,-10.927555334615654 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark08(156.20355939292796,-107.44708090005408,254.4312500119687 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark08(-156.26260053144273,99.47750836863149,-243.99615381721358 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark08(-156.45642851338584,150.70723501580082,102.53055489957565 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark08(-156.46882626976242,99.72829584183037,-225.2916623751085 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark08(-156.55967250341806,-228.54384565308408,-96.60290174638743 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark08(-156.56635484838108,138.23160057662275,-192.1859599337061 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark08(-156.76785592380043,100.0,-100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark08(15.692061047373436,-22.570920512219725,2.6684509875507576 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark08(15.694654352853831,-5.2511908497760675,37.18507082310372 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark08(15.715869050198409,-28.543901560153696,-9.237372769711024 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark08(15.722986662855373,-46.100754233371546,-0.5946480342836367 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark08(-157.27521128865772,135.00631610112706,-200.9718302466434 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark08(-157.29339819736984,57.585634498421115,89.7698284876956 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark08(-1.5739251498478533,1.7537816104690065,-0.2560589593931611 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark08(15.74412044584177,-17.144609555421187,14.084557151010186 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark08(-157.51074635588927,-165.20274860774896,165.70800959918478 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark08(-158.0437499984811,94.70167945418514,-0.9640575243604559 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark08(15.818882060602983,-20.003466437716728,9.020501305835069 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark08(-15.825234311590684,2.218776403421503,-42.38840421330424 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark08(-15.832525553968482,-92.09694426096544,-5.167877867789824 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark08(-158.38426186445184,-26.943623973126424,62.92923772587531 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark08(-15.841006555405214,4.945168781104207,-37.09863375465463 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark08(-158.4478822214326,162.91518501167053,-148.8452078406022 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark08(15.858911801016031,-100.0,6.087439732202114 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark08(159.02274568447336,-157.0877243357926,163.51623715260203 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark08(-15.90673364654754,0.0021369879226586395,-46.21008850379774 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark08(1.59347102802571E-6,20.88934353886789,43.06459419803465 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark08(-159.3555121653684,145.06849313321948,-186.77156994279116 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark08(-16.001339574241747,20.733621793100518,-4.965978809729314 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark08(-160.68605595946485,-123.06286530299445,171.2569557448445 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark08(-160.73943620937206,-138.47919241196485,134.5940704071215 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark08(16.077499546905997,30.92315549454059,212.17914758627137 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark08(1.6104588317931061,-36.34499580259771,33.11622207476028 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark08(-161.06614294365795,100.0,-275.3548090807222 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark08(-161.1974245939212,-142.521232095619,-158.78367377290616 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark08(-16.12006501502406,25.13655832535267,0.407039515626986 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark08(-16.13564045273135,14.718994044247028,-0.006613868250650087 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark08(-16.14159741051825,20.959265459778205,-4.935464985203452 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark08(-161.56599660533524,-100.3655987257104,-225.87259520600543 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark08(-161.68068632224552,104.57093787271364,-212.0913097426251 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark08(161.9288750134852,-161.613776512861,162.71085820956137 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark08(-16.196481279907573,-0.3660732456637561,-49.3215903310502 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark08(-162.27600230289903,161.93143466199862,-162.4200936557943 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark08(-162.29613288466626,15.864837564923846,41.32299990076729 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark08(16.2369289320175,-20.440811557121613,9.399960008604165 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark08(-16.262942719291942,26.06226080891969,36.26870644761899 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark08(16.264444729746213,-96.32567080237338,13.222960828603874 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark08(-16.267804949566248,-75.14399850827145,91.4118034578377 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark08(-162.75144508500173,137.58787525994813,-161.8979033863547 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark08(-162.9193805124447,175.3262417680447,-137.64221299776713 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark08(16.292582912699295,-34.731150455651246,-19.013755846409712 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark08(-162.99945120036702,100.0,-288.1705241151674 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark08(-163.13288154798852,173.20763366613556,-141.7100620408225 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark08(-16.32960574208548,84.61263169453461,94.41081402205866 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark08(-16.34068615123374,36.73220635555205,24.475263710596575 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark08(16.353282458280006,-100.0,126.88519514083482 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark08(16.400194407967863,20.28629729278416,91.33491504689398 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark08(-164.0762363634056,164.7981687888107,-161.9921141422029 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark08(-1.641022285251053,2.310775397503283,-0.3015160607465929 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark08(16.43164465895983,-51.70136129796304,-52.5369922922517 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark08(1.644031417590917,-42.00464118615258,40.360609768561666 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark08(-164.4425109583827,183.80725647058694,-124.72217737507061 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark08(16.44726635393416,16.340768124995634,83.5941316385875 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark08(-1.6449329144579257,-36.7784841820317,-76.92097078064228 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark08(16.464290073849483,-22.600647120538056,4.5655607198936785 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark08(1.6465196771448882,-0.0032595833299263284,6.460829871785636 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark08(-16.468663455478662,69.2488573639136,90.6625206881861 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark08(-16.468893818572845,-70.70111638437501,-95.264482436092 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark08(16.4752164712834,-62.03178974248648,-74.63793007112275 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark08(1.6488855993406628,-31.42433130713147,-56.66841016444314 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark08(-16.51664934681015,22.004021224044063,-5.48737187723391 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark08(-16.524057081600127,5.015601348131526,-37.97017222174244 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark08(-165.55073943647847,151.1800824719432,-192.72494624902595 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark08(-16.586639615223106,-26.427445139150706,54.79960406549489 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark08(-166.42829498505765,-188.28878491853257,-158.62012390338137 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark08(16.644966364877437,-21.60332326248581,-1.8970879071207675E-4 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark08(-16.64980207917888,7.016889438397383,8.119587017338405 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark08(16.65471053357084,-47.4472768552886,0.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark08(-166.6405916742033,198.51193275995746,-99.41558366107597 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark08(-16.68428095063672,96.46383480324369,-23.046960393157832 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark08(16.71101783466588,-23.606727883594633,8.466506375723647 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark08(-16.712190318471166,-21.29104585030357,-92.31658155812393 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark08(-16.714766951185325,39.62748119537865,30.680117460078215 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark08(-16.720869255852847,11.060304425879877,-27.461313029296843 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark08(16.77706576689489,-0.0029165574386371407,50.61251896369711 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark08(-168.17855505666392,-175.28255213191738,119.4625981064271 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark08(-168.3346080891713,155.47162501029004,-193.73616075103982 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark08(-16.843950639427433,22.004265014318214,-5.286442171735341 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark08(16.869443844039722,-56.45337917194331,91.33561050868389 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark08(16.882099367433977,-29.570211439488972,11.117315745260102 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark08(-169.03896796851055,-159.3979863268605,-134.0856786297842 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark08(-169.03936727623187,-111.46303129336638,182.40304385183907 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark08(-169.17623671840937,119.15636378342327,-193.79037694118725 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark08(-169.3304517005381,175.8145966067548,-156.17129744109806 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark08(-169.38542290586722,194.47942706561528,-100.0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark08(-1.7018750663793611E-4,69.69458325363306,140.7320495511034 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark08(-170.38197226480128,195.38004439550656,-100.0 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark08(-17.072430859020756,-8.65186400559244,25.735855080461185 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark08(-17.098375050654894,36.39959108862145,21.50405702527822 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark08(17.103371313003166,13.271355764480873,77.85282546797416 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark08(-171.10631537973072,175.9091215401543,-161.41989061996213 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark08(-17.191324991118133,4.474783233549222E-6,-51.14396009264452 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark08(-172.02138462046,179.24845178618796,-156.69844099875147 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark08(17.21342120418414,-23.092061223423208,5.9208084076737295 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark08(17.220795663223626,-29.798396661671756,11.006804671653233 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark08(-172.21698498258263,-13.502576706257324,87.2233207908626 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark08(17.24574938568193,-22.76298954445655,6.3273416148068815 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark08(-172.665587709094,117.3890775951062,-162.52352163103498 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark08(173.33041744041327,-210.72539202791557,100.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark08(17.342718356159633,-23.076935462528695,5.947462993352661 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark08(-173.70306871521646,162.38721376918974,-195.4461248561053 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark08(-17.37560596854111,-52.78417574426425,126.42607173654622 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark08(-17.390500668721682,0.0037830617057626748,17.307604005814166 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark08(-174.15368820829156,154.82496161347765,-142.49377634244365 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark08(-17.42856721374141,59.05970968882142,65.8350448790662 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark08(-174.3485781379444,187.25403530275506,-148.53613110359905 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark08(17.44131613331658,0.3536638598291644,54.60124375404749 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark08(174.71514592756893,-164.97253771473095,194.9921498113461 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark08(-17.511793601509023,14.881375035395891,-21.27148667738134 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark08(-17.51260354800214,6.168031808876045E-4,-51.594408216986196 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark08(-175.18875709701126,99.66108824702057,-325.45082511668863 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark08(-175.28150783098198,181.41510170009306,-162.82661637859255 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark08(17.52904760085687,-87.56152658733738,-77.39806359213793 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark08(-175.56840617269688,206.89766830054077,-112.25900646725903 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark08(17.563358627285947,-39.823256075238476,18.118304794362736 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark08(-175.7288866740212,131.70928379457663,-262.73040854327525 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark08(17.577487930569305,-1.351285124420599,89.21441266926574 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark08(-17.670931069105805,-25.862989744956334,-98.30169599946339 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark08(-176.84336775866586,-67.37686511286493,-356.4922679908996 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark08(-176.89592984326828,110.35032862104903,61.83271546662697 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark08(-17.699012261956582,49.10831657996182,45.562260680065286 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark08(17.729186631982284,-3.092779149953474,-19.778000135618605 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark08(-17.736812146265123,31.08167439627357,41.63394544998772 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark08(-177.41896499695426,215.6609680852756,-100.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark08(-17.75128991206458,-14.652892907472229,18.267015724637048 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark08(-177.52821965011077,215.5482091239064,-100.0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark08(17.773088178670832,-18.91643554496917,15.486393446074162 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark08(-17.79222203570366,77.84902306057288,-9.216320885808457 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark08(-17.881174841624674,26.03636410024849,7.51754214434186E-12 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark08(1.7899038875989777,-18.517669500007283,-30.42720150471483 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark08(17.900468677312993,-3.2394742012944673,48.79325395614494 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark08(-17.915799977481996,-40.937400844505575,2.607880484167767 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark08(17.931524605995627,-58.6919238796088,-25.640561288801987 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark08(17.95605407656819,0.9661045696349753,57.37116769574541 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark08(1.7962614038670275,9.654314365766663,26.268209269929304 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark08(-17.964582098059704,23.996207218250344,-5.901331857678416 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark08(-17.981406237825237,-38.56775852627586,-29.316189955093076 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark08(-17.989999875857904,-84.54515031916054,10.642097702512004 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark08(-18.020061618365098,-50.13138652121168,66.94401432443641 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark08(-18.048012545825713,8.93401796522624,8.622933643379572 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark08(-18.080782487027566,52.18833108226624,-25.97890587519737 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark08(-180.9134271653723,187.07987696069097,-116.83510058116462 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark08(-180.9883231183692,-219.0382207854927,-100.0 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark08(18.10672226933967,-22.051207947442037,10.217750913134937 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark08(-18.153523511497358,10.052786648881758,9.68333600593167 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark08(-181.78174253312397,187.90096598841245,-99.4640321652451 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark08(-181.853278134762,175.5229455480274,-194.41953033349634 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark08(-181.98779221974334,50.026754895730065,-194.5284311327516 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark08(-182.0181131661058,188.0958790764891,-99.80603466980205 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark08(-1.8223679719674648,-30.43346285334486,9.23261924269389 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark08(18.230314620201238,-15.591168727671924,36.868774697362326 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark08(-18.2558840189063,-77.47496837623882,12.502121890250422 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark08(18.267862221455722,-23.96752085855116,6.868544947264851 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark08(-18.29043446766958,0.19218471553779642,-79.61967520070921 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark08(-183.13438267270868,-168.58147957282372,-113.09720572319706 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark08(-183.35777879349607,190.0372914574894,-100.0 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark08(18.33867107074125,-10.092902595515234,35.652696244029315 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark08(183.70066735209065,-220.441761684071,110.33986444057209 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark08(-18.393031789847043,-71.65538808169681,-8.64001336922587 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark08(18.393261275724363,-47.81535066236463,29.421614181972448 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark08(-184.0053383204975,140.7011511602072,-157.36792469717548 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark08(-18.406487786942357,1.203854875766886E-14,-49.57234872960461 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark08(-1.8421257371830535,-54.93542974381995,-73.01407267237856 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark08(-18.494387060352096,-0.46227690397590493,0.18372901152125287 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark08(-1.8512002819507218,-8.520187241738464,10.37138752368919 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark08(18.529131283931928,-26.20055982440772,-3.9258204637524 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark08(-185.33099730801055,203.25056865146558,-148.80354531962055 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark08(18.536547733496022,-126.43845341762828,-39.06577657068749 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark08(-185.45267170685062,-100.0,-202.38762075000477 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark08(18.56419650371134,-64.4012023907138,9.981178626898572 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark08(-18.591768302667596,7.407250014698167,-30.644402842766013 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark08(18.600464750893728,-33.32362116622196,77.3767438078978 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark08(-186.28006108238222,188.0809416387275,-100.0 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark08(18.636998949877736,-219.4824002209208,-99.59568379742237 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark08(-186.39572321136907,193.71974090858532,-170.26901588728566 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark08(-186.93605995047193,-217.77125692584218,98.46806779905091 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark08(-18.715370210319296,7.204228874444173,-42.54544695278531 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark08(18.733406972143428,-25.21421640712081,6.4808094349773775 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark08(18.75773918627156,-29.719158773992913,-9.877494129023972 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark08(-18.761173621596757,-4.435732173385786,22.934609089015346 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark08(-187.62206137327584,156.26092375485234,-135.9594122830365 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark08(1.8777835013703497,-3.602073415450662,4.618527782440651E-12 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark08(18.786742421380573,-24.0366674996711,-23.15015233776851 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark08(18.791644855314615,-32.10392449055213,14.98588657838647 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark08(-188.05983850820041,181.91669612077078,-118.17810464526421 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark08(-18.807651035369474,-59.86498113842791,-75.47525885089881 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark08(-188.09088283258228,-0.24550461568312104,-35.88457109067385 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark08(-188.18672500604364,100.0,-181.39141669230315 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark08(188.46020826153858,-220.97286652890136,123.62514979797535 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark08(-188.5420480945741,201.3922880268863,-162.61321914703134 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark08(18.870619151192887,-27.29453574786406,2.10091506799619 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark08(-18.88193203597174,-24.169948798231054,52.47665879497845 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark08(1.8904733375442788,8.988568372806725,60.65932800698886 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark08(-18.92277555373217,18.37725526677894,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark08(-18.927743737070088,3.9934530852059993,-34.872466433750205 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark08(-1.894834179000696,14.950527196483405,25.78734818275962 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark08(-18.953996141832917,-3.1063769929307767,15.101979628707227 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark08(18.96496347513885,10.374047955270262,79.21378266275197 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark08(18.979584527090665,-25.33766636574605,6.897157471165733 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark08(-1.901152888292564,-34.29978008197118,26.273664488521387 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark08(19.01953840801482,-0.0014325988114766153,57.64946984909784 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark08(-19.099800040327438,28.648270659742657,-0.0028588014969992918 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark08(-19.196736583419764,17.975288601147433,-8.272533178909747 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark08(-19.22193891442383,-35.89913545336543,-35.12676390453379 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark08(19.246403691577047,-0.0014004542023110574,58.27756200356324 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark08(19.25006952647752,-46.45720431279213,-34.3859147957461 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark08(-19.301980360862956,3.2762685431312777,-50.05174032136223 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark08(-19.316928537313323,12.336633105586346,5.505468878072143 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark08(-19.359156491737618,46.637969051977514,31.371676244017863 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark08(19.368170642753938,22.553513330837735,96.49914960954887 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark08(19.371634397273493,-19.632775102310557,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark08(-19.37824983697948,28.80149554345035,0.002808277588430428 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark08(19.40489637835527,-61.174825051889826,-6.405856702000006 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark08(-194.0898628178165,99.4744406287229,-181.10805198443077 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark08(-19.41212545661359,44.833800737236906,31.431471185812708 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark08(-194.29055147263102,187.60559683888704,-99.97967819785956 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark08(-19.43825488386683,60.36707864952464,63.89921637823063 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark08(-194.4502804617141,100.0,-175.29278231779782 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark08(-194.46123320314172,-144.80277866836036,-156.350304352259 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark08(-194.55258118453858,100.0,-188.16274491522182 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark08(19.496073583962936,-28.627093114593507,1.2770378966502327 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark08(-19.497152953603578,-14.37920513926734,32.305561766076025 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark08(-1.9507432456733544,1.8023024757256891,43.245170593943904 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark08(-195.30470977431253,147.9731114909203,-157.4600864150529 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark08(-19.54112481887051,-4.406840260107998,-67.43705497682751 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark08(-19.574339019181128,-12.77662866798655,-84.00566466719586 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark08(19.606060424160404,-14.247034425544589,-2.496824612132586 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark08(-1.9608956753083957,0.922948672998269,27.943737194596547 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark08(19.63358069912616,-30.235769212086666,-3.868573879203842E-27 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark08(-196.58439354796295,-183.6786772342286,93.46869687135212 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark08(-196.67178589177965,247.4515370660761,-94.23934929699115 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark08(-19.673508869464612,-19.795524869924655,-22.182220916611758 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark08(-196.81604152881647,145.04352850897163,-218.08971410705914 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark08(19.694325578332677,-19.37786094935021,1.2543316978124315 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark08(-19.70262671674261,-43.09596120038595,11.811271057464147 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark08(-1.976946511166911,4.266907623505677,2.6069923269958615 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark08(-198.22182505901435,-114.80682691130676,169.89303728446157 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark08(-198.65671413382586,193.720879207037,-207.16445912007748 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark08(-19.908384411092687,59.17923164629379,60.204106386104414 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark08(-199.28017060155457,-119.32634866054836,-150.3120522154273 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark08(-20.021006977848593,16.335952602940765,-25.820319400869355 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark08(20.026915800948814,-8.007076438456697E-4,97.95617775816054 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark08(-200.3430201665808,124.82140769625765,-143.1731070488943 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark08(-200.43044260475662,104.73593410812182,-221.9998623044021 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark08(-200.55757083743285,100.0,-206.66989458028348 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark08(20.058698520084782,-38.47308291026341,-16.770070260272462 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark08(-200.71528247343645,194.17580342215325,-100.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark08(-200.74581174808105,169.14817636446975,-100.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark08(20.144731502010487,-19.33132848806534,-60.072939382327895 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark08(20.146425123879336,-47.6399379944258,-34.84059450001391 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark08(20.15828242493702,11.129678117093249,83.51494486395801 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark08(-201.73180459335182,176.88851065381948,-100.0 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark08(-20.179621533064175,22.645094731914963,-13.677878808567701 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark08(2.0194839173657902E-28,-27.60953890688566,2.8450060488240894 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark08(-20.27085720406769,0.0,-10.350486988968584 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark08(-2.030358602230369,-9.65335127014428,-0.006208740725218507 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark08(-20.314353616263844,1.1574501918067046,-13.296635071819102 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark08(-20.343950482611962,0.40837431619927994,-33.706396336099914 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark08(-203.50201752366902,254.67409538420856,-100.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark08(20.363059502611065,-58.41725366261248,-54.7809482177498 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark08(20.403903115033764,-33.30329055016956,-5.34308276857381 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark08(20.456801480447396,-82.75111708725888,59.76395309082318 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark08(-20.460117654813097,0.2859573086177914,2.8981945164137226 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark08(-20.50139574785886,4.33820061651717,35.509998288884454 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark08(-20.534573357954724,48.75102111288204,37.46911847869481 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark08(-20.65040612902716,-54.22387053093052,-5.699067035050902 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark08(-20.65486124970366,34.170973300209425,7.060009664021965 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark08(-20.679150348718384,27.89336226986245,-5.668512006929678 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark08(2.0685126360607655,-39.766162527346275,-73.13864017300986 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark08(-20.687729151275363,57.61348424970717,-45.519281147332194 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark08(-206.98112147365123,113.24090305984905,-155.4297790560973 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark08(-207.2596841651357,125.73441541518754,-162.78906150008154 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark08(-207.38095430173198,-159.12870624266668,102.94532189743165 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark08(2.07419964734558,-21.759653802099592,-36.378925370889164 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark08(-20.747779724181257,-35.399118263370724,88.11809828098075 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark08(-207.71009410054998,-100.0,213.92485690481763 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark08(-20.78778393056361,-149.48781956240265,174.8819463897566 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark08(20.792082283933222,-3.784086599124741,55.27978859982883 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark08(20.953964825535003,-68.85834506156561,-30.782304402741005 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark08(-20.983444220533727,-52.03780412110828,90.32610588235767 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark08(-209.88631552268848,-61.224960479001005,-261.1882037027732 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark08(-21.001960317969615,27.638282942344233,-6.632729655470739 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark08(-21.037111784881915,-44.88607946883121,-0.8449799510880365 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark08(21.07305011043984,-1.5883058826913725,60.18239116382988 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark08(-211.2515848081939,173.24522782897685,-98.29637290219215 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark08(21.137059803907732,2.027773166486287,100.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark08(-21.202651537169668,-100.0,-54.34696461034176 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark08(-21.215347780534586,-70.38525752079151,91.47292484751578 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark08(-212.7594717172045,137.38072044900295,-112.18844190448523 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark08(-213.0198356866991,100.0,-193.80586591211343 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark08(-213.0733410255985,100.0,-218.9261722876907 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark08(-213.09765779306582,-76.2372636561968,214.79894100699772 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark08(-213.12909524428468,-147.03789383329928,122.33876340150357 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark08(-213.25141619747077,100.0,-162.63544999112392 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark08(-21.326726115414896,-43.35705277128913,63.10610405780977 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark08(-2.1392849341375353,15.471020553683275,70.06396972150779 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark08(-21.519800520731238,95.6567581961241,170.74322312439338 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark08(-21.5281574590696,35.08765333830906,-19.570163519760115 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark08(21.529577365967587,-29.72226493888618,6.621891246123697 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark08(-2.153955676297329,11.741061014882703,18.59105132766831 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark08(-215.9495416131023,-71.59524585254415,-225.21073739770353 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark08(-21.617221208349704,1.0754642734676436,-61.12993875131893 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark08(-21.62705793460256,-3.5670942281388145,-70.44456593329045 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark08(21.637200697670096,-8.805256607755673,91.48025565656687 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark08(-21.64657935543071,0.3152116421012785,-71.0217037624743 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark08(-21.647258287636568,-97.53397600681365,50.075037309152066 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark08(-21.657578635999506,-0.002537107033326942,18.19915864246684 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark08(-21.803559010107023,33.22762865675666,1.1828919745747934 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark08(-218.181336335259,-263.6405443036177,94.8167420602159 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark08(-21.8797382887988,17.5289184896366,-30.443700457964866 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark08(-21.953124681633838,82.28135755541201,100.0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark08(-21.97506375911985,13.899838628356514,57.17506205146604 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark08(2.1989926155906354,-96.32496647692338,74.46363030173237 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark08(-21.99443114329883,28.904808503690017,-6.910377360391124 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark08(-2.205281790254167,2.9444923398915033,-0.7257158567181435 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark08(-2208.9000016925825,-721.7229474202716,86.42049043447983 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark08(22.152590885706374,-153.23595202908334,-76.2894709260895 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark08(-221.62671428060992,159.5819034383824,-100.0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark08(-22.203309226747102,28.910202165994807,-8.277689266042604 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark08(-2.220446049250313E-16,-88.43490051528103,-100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark08(22.206649930065414,-7.026631808919209,54.13748249915272 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark08(22.255475562386025,-27.38339826243473,5.28724118190385 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark08(-222.77006107248792,-347.81162878093744,-238.76616787186148 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark08(-22.284121714997855,29.631202668872884,-7.347080953875032 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark08(-22.308877072673933,29.213771942242964,10.851467137896357 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark08(-22.321509312310518,-20.477087803208875,-81.52138150506482 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark08(-22.42951469299743,21.059430678773914,0.0014958867895827677 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark08(-22.47539433392912,-14.95096691751602,-1.8435469184296354 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark08(22.477421462489303,-30.370846855959734,7.893425393470439 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark08(22.4839958147036,-21.819122619443622,24.620056547702397 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark08(-225.08190683684649,99.21725066717207,-149.04384040160113 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark08(-225.83662237866807,112.58343741900435,-168.62826875260401 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark08(22.629803089672347,-6.448528666407908,56.14082971122453 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark08(-226.581718018903,201.37091386761523,-100.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark08(-22.666902418087858,-43.00206757815465,9.357975609274384 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark08(22.683214286755536,-101.29608970107726,-7.916040748926003 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark08(-22.69918823764303,-20.446414838701358,43.02892265848433 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark08(22.699928334621383,-0.14437853025123282,68.81714393397755 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark08(22.753492194181504,-98.22118018668004,30.14973256008762 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark08(22.80492825846168,-75.98535848728999,-26.941928234205164 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark08(22.811469564256697,-62.08678861170394,-38.23269967283591 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark08(22.862986238138244,-14.301679212208882,41.55639661679186 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark08(-22.900155032259455,57.76106457799282,46.82166405920728 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark08(-22.955407185839903,-67.67651107121554,-77.13081746787347 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark08(-23.01632660606745,97.16127351619514,100.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark08(-230.41253093345802,73.08560165804468,153.8544999528783 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark08(-23.06210360167998,33.87562836757932,-0.002010636667662948 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark08(23.065679415366276,16.134090466517613,94.75283019874935 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark08(23.08028932348689,-79.38765337923977,9.486488240744492E-4 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark08(23.09054144600651,-83.47321694497494,60.38267549896841 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark08(-2.311073640438038,31.120175454762993,55.32217496106426 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark08(-23.12309526440311,51.954952564387675,66.3608634982252 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark08(-231.45723562190616,-97.49483889654005,160.9598498191209 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark08(-2.315421470057201,-24.429201793380386,-54.47747985993238 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark08(23.170608670245596,15.059470377909426,100.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark08(-231.82683731645332,124.76818614182801,-137.36284473261657 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark08(-231.9840826063488,-86.02841124382147,169.77992587719714 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark08(-23.207427754503414,31.55856506977092,-5.411089092441863 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark08(-23.236618525827254,-2.132157994583369,-15.868247769689983 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark08(-232.55715190982497,195.10125361698923,-100.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark08(-232.67943935542849,182.64213206139038,-100.0 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark08(-23.275245654523967,58.49131290545097,48.72768517412493 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark08(23.283107473616248,-17.148807460323727,35.5517075002013 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark08(-232.88814097989078,176.64384878714742,-100.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark08(-233.1834079305682,166.6485033032373,-114.0110934181585 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark08(-23.33773668445205,13.260128102696093,-43.32948721102961 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark08(-23.35008896343609,-0.27292022343421984,-69.02531101038181 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark08(-234.8955044701035,-111.81276252380525,-155.3250890924796 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark08(-23.515336455465842,-135.7966598949283,-8.072994729896195 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark08(-23.520493189924508,-74.10562317630622,-61.174197586459634 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark08(-23.534053754945017,31.543471396621072,-7.515218471592899 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark08(-23.57151065699301,-48.45154339221607,59.749573327098716 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark08(23.583268110603264,-27.164675517319605,9.707264620271697 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark08(-23.647025202936625,31.08461893123233,-7.437593728295704 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark08(23.66893125537666,-0.28034140199613944,72.01690728893259 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark08(-23.68451662854393,-93.42687283732529,-25.20971052312474 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark08(-2.370255665777904,-48.979046669044436,-97.76360615962875 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark08(-237.15648640707388,56.758973029177554,-295.0795801572967 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark08(-23.729126092574308,3.3217188962341915,-64.54394048525454 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark08(-23.750423577652658,-54.82907003257121,-17.239082359964232 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark08(-23.765034898468073,28.458612728477156,17.328836437796554 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark08(23.777912079339224,-28.569137390751425,14.1954614565202 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark08(23.8238501889344,-80.00879981156311,-68.7675865246067 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark08(-238.4487048794149,100.0,-194.4638879664459 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark08(23.851107876503093,33.58869939290545,126.85736817926689 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark08(23.852023389591853,-36.5201797411229,11.403440141263946 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark08(-23.873060279347776,-44.27629750344458,66.57856145599746 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark08(-23.878557563540593,21.810335616929574,-33.168330752547256 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark08(23.925561718678217,-34.08391539814841,10.158248532170113 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark08(23.93787540284587,-35.058403442632745,3.2665464058123486 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark08(-239.68528752585473,125.46076809979756,110.80868166846645 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark08(24.00977554538543,-82.34206999192266,-28.80725407346658 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark08(-24.079765079330784,-4.850841135505377,-24.577948301113516 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark08(-24.08306692415306,-75.2648990875484,61.31185154594411 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark08(-2.40909529426508,3.2125378693117925,0.7673537517481839 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark08(24.10223434186001,-29.27649132785109,-35.46839644112319 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark08(2.413757399227064E-27,-87.34783680570844,-23.818432111562302 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark08(-24.157853363521088,-0.028101518533781622,22.864870568713975 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark08(24.26328805220106,-32.398021319804855,8.031062046701669 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark08(24.36111111555097,-10.509908519116905,39.06507916276411 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark08(-24.361207186841295,0.14808097972948123,22.642329880316897 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark08(24.36162890462079,-25.82885174376571,23.634744584475133 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark08(-24.370996873165126,-78.05283506696094,35.36040405802959 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark08(-24.37592759016745,37.30159579599702,3.046205148286571 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark08(-2.4380499685138126,-10.376330620072437,-28.05757390832667 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark08(-2.4386155508883167,-0.7217066628950567,-1.5522039635775482 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark08(-24.394292750218753,67.32081761931042,61.45875698796459 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark08(24.429128580026685,-100.0,100.0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark08(-24.448902549458,5.58313353997407,-17.29767598817844 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark08(-244.63528157874845,138.15914684741432,-99.4127698814448 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark08(-24.51800253974465,-8.80164164984043E-4,-72.78989763344194 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark08(-245.27160603340707,-102.60915784155279,141.13122996629028 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark08(24.57217063016738,-8.61765539417796,56.5635302651086 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark08(24.583207444707153,-14.871217766501601,44.00718680111826 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark08(-2.463368040781656,3.3220083124030655,-0.19195077040983533 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark08(-24.65914575632186,61.74416779987329,51.08167858263002 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark08(24.669518616402886,-48.66045896385514,8.12259257368208 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark08(-247.60691508558347,71.43427332313966,-189.99156107094845 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark08(-24.76310957061964,71.00276565018449,69.28699891530493 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark08(24.783498096458946,-37.17612063107927,-8.609959190094581E-11 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark08(-2482.571948979235,-370.2378321310736,83.87790131572888 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark08(-248.31381388115022,164.22029078525293,100.1626595509766 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark08(-24.85100663040196,57.57941877429236,42.17661398417372 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark08(24.85501218472249,-35.70669592593513,10.823125462784773 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark08(-24.922629055518808,-78.9232770006861,3.6604607130286126E-5 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark08(-24.932112042719623,19.057487565914894,-35.11056466953419 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark08(-24.946658309328065,0.005887425119266343,-10.695032334691827 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark08(-25.00733580922419,36.572548160026585,-0.9635365012958603 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark08(-25.009263763244977,-67.22226509314939,-165.38102186296868 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark08(-250.15101812495493,119.93681602740199,-139.7069215160687 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark08(25.03531145667164,-38.615923191121645,-0.5568708250426947 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark08(25.103997568216375,-71.27277012159331,-66.60885250006515 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark08(25.145850206996627,-19.12914313531562,-1.8256005828624469 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark08(-25.153680393736394,-0.04668726579177779,1.3375804056256004 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark08(-25.15553067750479,89.99969196797704,105.621110655936 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark08(25.17050598770936,-123.27197522913517,-20.154273602147804 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark08(-25.17629369030822,21.88987196268284,-30.577186729014592 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark08(-25.19066953370148,-18.622317966049778,51.87607456329346 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark08(-25.249678022195155,33.513240482789044,-8.130459632267469 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark08(25.257412161110253,-2.777718051378254,70.22570261956335 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark08(-25.291960021065982,33.93054464742789,-8.014790768342163 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark08(-25.29526362383407,37.831227451297146,0.0 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark08(25.366022484377602,-141.0718372145741,-42.67857300273385 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark08(-2.5403792786442487,-5.709667672914314,12.375453355165519 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark08(-25.432649829913046,-57.1778227026049,-65.73152284752189 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark08(2.5457443021501263,20.527917469381023,49.695470496472495 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark08(-25.46865560767689,10.212162847355398,39.71396973034024 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark08(25.54981661686768,-18.643859023353258,40.93252813069142 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark08(-25.560954746426518,34.357121637703266,-7.96862096387299 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark08(25.573613460690552,-95.36462545293372,14.968853552235387 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark08(-25.577859939898225,-3.670585706301047,-82.50395490550189 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark08(-25.582591383364857,19.162600751218385,6.381050062636651 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark08(-2.5590618053824556,-31.32670705454123,-63.62698394997368 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark08(-25.616604350143103,-68.85734722859661,52.43523406075312 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark08(-25.625108301876605,-24.291568968533067,76.16092735429586 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark08(25.6430814126122,-72.59896905046473,45.429755141851636 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark08(-256.4974353465203,76.49039506037062,94.04579676118713 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark08(25.649947913035742,-162.48064487200662,92.55667885429821 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark08(-25.697578414905664,-0.6139275519681093,-8.246013464404786 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark08(-25.739766349491404,1.9333271365567763,-35.42685304025572 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark08(-25.741708189604154,45.73021202411877,15.806095806219972 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark08(-25.753863611171656,34.56623385533651,-7.2415739173699585 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark08(-25.818292656672963,56.22512374156298,34.99575618697505 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark08(-2.5835485510276754,-49.534108294937354,-6.005235340471657 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark08(-25.86653861458608,34.32378763259812,-8.510477580624798 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark08(25.91892943095088,-35.15616902379661,8.362435311212224 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark08(-25.923307066379262,45.86626979809929,15.30036776662311 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark08(-25.94934384595593,-52.027936628556745,-18.091882050752798 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark08(26.011055965775274,-26.22215175385877,25.588864389608286 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark08(-26.065250089960863,3.64902957617085E-4,-52.569130044884595 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark08(-26.08510438279596,-14.168296189254036,-10.80922190593509 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark08(-26.10722797369505,5.82214122168171,18.074869023733655 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark08(-261.12965636740404,136.10428482752357,124.44766228224319 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark08(-26.161415857635298,-36.587127487334705,-24.772119923415325 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark08(-26.162595963387854,0.0,-76.96717343210254 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark08(-26.198376754650905,-19.563022840089687,-66.40313446149788 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark08(26.26004493391418,6.1959024662297315,91.2460817936755 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark08(26.2941262142631,2.8914858518510433,86.13347269373487 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark08(-2.6326274303982506,-21.56789616038151,50.53080847227714 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark08(26.349204756760276,-38.05861688949406,15.51236816201492 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark08(-2.6359488356674063,30.571940160511236,54.781397166385716 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark08(-26.362754183533013,37.18398415117412,-9.250433640846218 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark08(-26.364833980299927,-42.003517708544855,1.800571671618357 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark08(-26.42378344262218,94.98875090027448,59.95025117578109 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark08(-26.440123786789876,14.252616332399947,37.34447927361654 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark08(26.440263972467044,-45.580864444788006,20.711396799115857 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark08(-26.468180584095155,-48.04954168309971,70.43052687933672 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark08(-26.47939894716311,-8.100127483907627,-94.22677540174993 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark08(-26.54269448716615,52.25002801197129,24.873748680200123 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark08(26.658520169743696,-81.30968604017751,-1.5126788710517758E-15 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark08(26.67175817933412,-44.37128882719315,-7.213827231261645 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark08(-26.683765395851278,18.734564827727606,45.66806400054905 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark08(26.881596222288334,-7.5338577510308795,67.14786949159813 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark08(-26.899254871718558,7.375506803268816E-4,-79.17494296240399 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark08(-2.6946177693316697E-4,20.982524454675247,42.02731979458331 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark08(2.6980557537506638,-3.374140343444077,1.3543331325302184 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark08(26.995065601387466,-42.27664520792354,-1.9972972848897943 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark08(26.99784751442026,-5.940922980379717,69.58920256164686 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark08(-27.004228859685515,16.942683363913403,-0.003433253745616558 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark08(27.01016871168015,-109.3662974674809,-100.0 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark08(27.017246086078963,-36.56031182510299,7.972269412229156 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark08(-27.058678044038036,91.18567526256189,101.27588398285313 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark08(27.07237363308726,-52.97964469149327,-23.366926012582436 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark08(2.710505431213761E-18,21.232869997246578,-8.780289527922257 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark08(2.710505431213761E-20,-33.974449409798794,-66.49333978034466 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark08(27.105735615527493,-81.17944371683245,-79.47088426028753 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark08(2.7135057992781384,-49.76772820014375,-53.00734684460784 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark08(27.156989241605327,-6.967905780403203E-4,83.01106529206727 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark08(-27.160044747800665,34.17690061565344,-14.870837502700077 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark08(27.204676813554062,-30.30368456361246,-4.126079915281079 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark08(27.23859264383798,-30.60556298339582,5.981677449034562E-5 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark08(-27.249107839301228,2.731733741871633,24.517374097429595 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark08(-27.261205798999043,15.213870969338242,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark08(27.295522510863915,-78.26063169117953,20.246708200019057 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark08(-2.7323523836364982,-150.1762841343607,100.0 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark08(27.393512441944573,-15.41442225019462,51.60424768364296 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark08(27.46635586461268,-65.76617664769608,-4.707035978636153 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark08(-27.49533322883063,71.2872769197469,53.23139794962098 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark08(-27.517570316891266,77.91380937356632,105.89401379579868 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark08(-27.539278759516105,27.5283807658123,-0.9054575308495381 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark08(-27.58107181885441,-162.40248811786475,1.2103303810223593 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark08(-27.595459055121676,55.49628003631521,62.755117790039236 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark08(27.699168712837853,-85.26557042713104,-43.25612739490226 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark08(-27.721547143492227,0.005390960547659862,-82.0113090589851 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark08(2.775557561562894E-17,49.87939881477373,99.16330679756116 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark08(27.808458398402525,-115.13090526255645,86.0331782351534 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark08(-27.854079064991183,-0.0022794153218664718,-1.7283395768082503 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark08(2.7866615260660446,-100.0,41.03556534284171 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark08(27.925630319579597,-60.548755434513865,-5.795601941683632 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark08(27.93900632961308,-37.747504037762724,9.892807240108677 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark08(-27.94552929338808,-46.11773909907999,-88.10021376786658 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark08(2.8035731673772606,-3.70220404807488,1.0063114059820226 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark08(28.04411955183113,64.6827437463844,-70.20874399376692 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark08(-28.052151014356713,-75.56631675692543,-76.66245782442239 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark08(-28.076403070185187,-163.75403930713952,10.069223841532036 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark08(2.8079288883366345,-3.4888709060601255,3.016841179684548 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark08(-2.810206864579934,-32.44029968555245,0.6359833734926776 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark08(-2.815592767333819,-70.74202032946759,-49.30415320846781 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark08(28.172066469674437,0.0,86.06555509662162 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark08(-282.4537228431268,100.0,-193.48766721055466 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark08(28.25494345661587,-98.49413942635174,-68.04446548345703 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark08(-2.827882763211555,31.65018883751179,100.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark08(-28.297385229120724,61.916427401241975,40.511495441916665 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark08(2.8366863834616036,-0.2353085682553768,8.060962591691364 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark08(28.393685097359597,-43.82210910330103,-0.8923665877283706 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark08(-28.42316246114068,85.85714173543451,86.44479608744699 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark08(2.845388129648927,-7.075320133918147,-4.215462530960738 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark08(-28.47447214141359,4.50322975732333,80.66562770842489 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark08(28.511234107430177,-73.55546189385137,-60.00642513861732 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark08(-285.48236528602826,138.22318334531693,100.06323523399259 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark08(-28.548814081585544,-7.11846983465401,-98.31258558726975 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark08(-28.557931649198768,-11.706247636263674,-32.37886244541303 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark08(-28.567551121643813,32.30489818516026,-19.6366997300275 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark08(-28.63461667979749,-11.06076846291937,38.10680108675001 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark08(28.636959917472666,-24.756188033969742,42.632110440490344 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark08(-28.653225964626397,32.87007164277451,-20.219534608330157 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark08(28.723145181951352,17.783506880116885,154.55541431743873 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark08(28.736673135147953,-81.85443542091417,11.2197455576853 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark08(28.790900518364978,-36.97068323082481,12.431357146419742 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark08(28.79159232198724,-41.31997661426834,10.957713037215667 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark08(-28.794690304919328,-54.497654083582624,-37.808028354869165 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark08(28.818597766196778,-86.31086016644392,-86.16592703429748 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark08(-288.3103780446095,99.70619688690445,-187.24515106368293 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark08(-28.847973137142926,53.87232005559262,-41.8455927470891 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark08(-288.5748938663274,5.613287612504791E-13,-167.69938879119272 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark08(28.898004002154302,5.980263484698101,98.65453987111147 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark08(-28.908294413066372,1.7569188805820242,-83.21104547803502 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark08(-28.961430302393524,39.99617355873073,-0.03916896877305441 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark08(-28.96842070043975,-4.630108430208125,-63.220220644920545 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark08(-29.015303678683026,40.191869897221046,-7.024771214999907 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark08(29.02273179557136,-3.1183690079921575,82.40225369752437 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark08(-29.100392828938734,28.89487666843222,9.06094097380946 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark08(-29.108232118925507,41.95908834733824,-1.8564224831213805 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark08(-29.15089128303227,-76.47452764998303,-81.75139956074015 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark08(2.9170537279757305,-24.602756555750382,-39.737089051075856 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark08(29.19993117418885,-1.710786343825392,85.74867388918602 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark08(-29.23171470397633,45.6624949809987,2.4690734893673523 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark08(-29.234125227532918,-2.5540790522925505,-91.23973746038897 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark08(29.272766395808198,-29.622405402108935,28.573488383206737 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark08(-292.8120918885261,-59.88192242139169,189.6075476972975 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark08(29.336865320754,-32.24094192862615,24.285250271397455 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark08(-29.353798716705136,38.95648673033839,-9.60268801363326 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark08(2.936893857944158E-15,-9.509637345133589,6.99414408769384 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark08(-29.424010908126448,48.65750343154707,-56.37751084871103 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark08(-29.447704045226445,38.55538711941249,-9.661541570059468 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark08(29.60095169644446,-88.78165904632755,-88.76046300332169 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark08(29.616547729326804,-44.72226767382763,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark08(-29.618554379850515,31.472902473415996,-24.346353336720824 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark08(-29.650248523485217,-65.04234240467773,52.453200407110415 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark08(-29.66317229325331,47.012501225858024,5.035485571956119 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark08(29.70284930902897,-40.99304434325327,7.122459240580374 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark08(-2.974061403650416,-66.2919200652526,3.5072377236743932 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark08(29.74955285306589,-27.81426128521369,7.851632382519789 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark08(29.807160371729505,-97.89173437348683,-24.35273824793083 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark08(-29.82305926574753,-50.00050927632267,-51.170439739910066 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark08(-29.844959116893378,-89.90767705902303,-54.27527612601892 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark08(-29.878091620014594,-100.0,-50.36069667823599 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark08(29.977625489636754,-64.88358157036848,-39.93827545805128 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark08(3.0054337294945364,-1.423670704614579,7.739756106049348 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark08(30.06497016738054,-58.246312357462905,6.174025721639765 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark08(-30.069384535474214,34.160676447299295,-20.31600438502916 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark08(-30.114969279460396,-0.19800610978776945,29.901998352179877 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark08(30.381728439625928,-16.392951614578298,58.38215743709879 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark08(-30.38510516163801,-83.23521642959551,88.29883784173518 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark08(3.0391153691303963,21.735969811364587,54.16008205691526 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark08(30.416965105418143,-41.96010280718101,-17.619282616752614 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark08(30.51821948838999,-26.40462573622051,38.74540699272895 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark08(-30.523857483451565,7.65499832575707,-76.26156759435474 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark08(3.0525046727161214,-0.012647570345355304,40.68707186203537 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark08(-30.565978415071342,60.28000616917032,29.146202782039705 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark08(-30.57660487139317,25.724549204074105,3.281107098756721 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark08(-30.60815549702957,17.54676367728076,-55.1601428097323 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark08(-30.63630458204632,-13.835576235351319,-17.673230603651618 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark08(-30.688020665552735,90.18989613778518,89.88652660570527 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark08(-30.72618243753473,12.098747040404918,20.19823172392465 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark08(-3.085975919248085E-12,-45.513698339456816,-1.8420565444471415 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark08(-30.947754152289725,-2.480354412612563,3.305644566495841 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark08(31.014370524303924,-37.8344115892474,16.279225632490796 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark08(-31.02856544713278,31.087106790345416,-38.00316463484825 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark08(-31.060732570014544,-34.10903387532121,21.749869148489957 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark08(-31.088824296385393,12.503044974251097,-41.76163755633624 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark08(31.102194883243698,-90.91547643580043,56.55491826345013 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark08(-31.102504951775973,5.423801167364628E-4,-93.11484601200185 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark08(-31.15664979699168,83.04553133190961,72.62136552849083 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark08(31.185564600978847,3.2150750137828568,100.0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark08(31.21004235381261,-2.1471458466962146,90.9066316948403 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark08(31.22850653356019,-44.25709118135432,12.93281098083085 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark08(-31.23822119553111,40.929856339864735,-11.262431471128519 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark08(-31.238497161476985,-10.125149152865145,100.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark08(-312.40733147545455,-63.2291580098223,168.8160305628693 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark08(-3.124630979198195,-56.16482452974589,35.376090684528805 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark08(-31.24717540752111,16.30553881838252,-59.55965225900339 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark08(31.29310552148449,-75.06450781474787,-55.92673159970297 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark08(-31.315886045412853,27.669084156572133,5.723772864758622 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark08(31.341039209576962,-74.76030888524184,-10.493415536228625 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark08(-31.342148937812613,30.971628786585683,13.241005719316831 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark08(-3.1402293094589804,-13.324480847952017,-35.746506173011475 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark08(-31.423432621973163,32.59205939200078,47.77175657152233 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark08(-3.1427215864240714,17.098585173813508,26.339801915149696 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark08(-31.433671489062462,7.006789161528652,7.838832888021358 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark08(31.447739364695934,-44.64202277228698,12.791215720460183 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark08(-3.144906147987928,2.904448024245362,-23.187941591036278 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark08(-31.4889012959829,13.857636252762447,-34.18788076064119 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark08(-3.1510329509466004,13.490269837452814,17.73555256384752 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark08(-31.524423294022853,14.446132317557982,44.03985243794142 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark08(-31.544923174755255,1.9807796305414023,4.5125532633896555 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark08(-31.56095795561727,36.971586388964,-0.8059566780737697 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark08(31.571333225087216,-49.37437693362672,53.39023986194485 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark08(-31.646389460848507,73.78771305391902,54.19620579000935 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark08(-3.167872868328321,4.374414401995013,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark08(3.1747893173084965,-19.847955826084537,8.994296599621947 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark08(31.757086959516172,0.8439209795225976,97.8400334118502 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark08(31.842600482061947,-47.69470571327846,0.14433285128579024 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark08(-31.859890055869744,-28.38885923678542,61.58319550929613 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark08(31.887380316140426,-39.704185002469934,48.79276891367232 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark08(3.1929386848768115,-3.7736446195098954,2.031526815610645 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark08(-31.94660841782281,62.18216402045821,16.901895411571722 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark08(-31.993496633877573,53.19774357587243,32.07122648441279 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark08(-3.2051062657802865,4.022829057170757,0.0011356437955494438 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark08(-32.09387099239896,0.8295111235995981,-0.05558038289477167 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark08(-3.2228976942183776,-67.46628007145239,70.59784345687552 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark08(-32.234086260738025,12.914815091364453,-70.87262859948515 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark08(-32.27998424433962,-0.5649070214883678,-96.39897044920072 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark08(32.36957528916003,-34.26982751857106,30.136642094294498 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark08(32.393776033888436,-24.906331031171234,212.1757437801871 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark08(-32.47117097033433,-43.459917282134356,18.477348847323764 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark08(32.498969707339185,-50.65922188660671,-2.265976403690105 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark08(-32.52887315529621,43.573764141157085,-9.534056364397923 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark08(32.55807656972101,16.863426445923253,-11.675079996633158 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark08(32.58897384439478,-10.460094537841828,78.41752878429557 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark08(32.62241541070436,-36.914858788016176,24.037528656080752 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark08(32.66667121960386,0.0,99.5443872007771 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark08(3.267295860625294,-4.3564864909185275,1.8847434717254412 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark08(-32.674434250306724,60.953518252887825,-25.787219215507147 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark08(32.76364345668315,-29.26337704260397,40.73203691080804 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark08(32.82043406293371,-17.312255778043628,25.88332264313692 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark08(32.82737772250386,-44.073955829210234,11.904476132966623 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark08(-3.2832618744575384,-12.73535210428352,15.08877146616363 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark08(-32.84206425755307,-32.03243240639548,64.4601958646802 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark08(3.287378469937437,-35.04497842738275,97.00965036294994 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark08(-32.88946883194824,51.44631990635262,4.224233316860528 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark08(32.93793481051824,-29.41907775982027,46.188488399374904 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark08(33.058994895665634,-63.03820125479372,-12.553037633135713 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark08(33.067185169280975,-56.84578258611872,268.765575997032 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark08(-33.11024831779623,4.33818927779938,66.85367631417625 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark08(-33.24683683032478,-0.10743187021093198,33.03940038303091 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark08(33.337033422083906,-37.55639950885885,26.469097575328906 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark08(33.360317269984215,-20.51717085743855,60.61740642187043 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark08(33.40751761740106,-76.30571116349832,42.68753356284589 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark08(33.47070366439376,-35.467311375989794,29.680786291576975 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark08(-33.52853818434628,-5.804456929558908,-95.9365910553606 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark08(33.5313692578696,-61.19597697849005,-26.892945577649577 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark08(-33.53381706613938,-84.21076802300216,-36.371396041840924 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark08(-33.537357761241765,44.70285557731571,-9.635565802298986 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark08(-33.53784323954831,-52.277859499209626,21.936459709290304 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark08(-33.58622271122617,-82.15827326076399,-6.800978863893363 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark08(-33.61243032575713,1.6143257992296896,-97.60863937881177 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark08(33.692728199366314,-48.788352457232605,-0.027475204818934174 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark08(-33.72177757677279,1.224269698597278,-98.7167933331238 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark08(-3.372928863717071,-38.9743706513637,-86.49673156708371 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark08(33.75375559260835,-55.7505336278404,0.0056289544083038545 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark08(33.755223823402694,-114.17232526612239,-2.4091833965613144E-5 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark08(3.3845180113786455,-36.20523727989214,38.61507655333045 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark08(33.85380578758899,-54.019559425417555,25.315251229380635 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark08(33.903572411823035,-69.89018500887627,62.594729283275456 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark08(-3.3930687444451175,55.78939190083027,100.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark08(33.95590840962346,-51.58172310806071,-8.968270062279515E-4 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark08(34.01347171033023,-76.31668754672583,-49.022267577782095 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark08(-34.049621138240724,13.090948330107068,12.31206716158377 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark08(34.057505212747806,-72.45053211828896,-42.72828268827598 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark08(34.115493616724024,-84.38085214582486,-66.41522344147762 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark08(-34.16315461913678,42.360990661413425,-3.8454885850091043 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark08(-3.4176551944107,-11.174549050529635,-11.061013704663011 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark08(-34.27805989840322,100.76056438075582,100.0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark08(-34.298681178554794,20.781487667025758,7.817058389968622 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark08(-34.313747206478155,-51.19241702629091,-67.71172314632048 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark08(34.36836979064134,-202.6407751717196,139.15005433510996 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark08(-34.39214920785997,71.4939232276017,53.10709856620005 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark08(34.398826307117794,-20.20301880513938,64.36113838573972 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark08(-34.42945895459446,-15.86790713434605,-91.0399184145788 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark08(-34.437472235641664,93.13939079223928,82.96636487755359 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark08(34.437491145590954,-45.94961976101721,11.413233914738449 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark08(3.4446324747234254,2.239797864100084,16.306962380300234 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark08(34.46842167830213,-45.21800928767558,14.54004278635013 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark08(34.479080577984405,-57.470241774987166,-11.50324181602103 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark08(3.4531889054696494,20.41104626750725,24.026304126211038 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark08(-3.462004739580763,16.001710599072425,84.00764476541895 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark08(34.657064958515434,-36.03818987440314,33.150803383749604 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark08(34.6792725876926,-35.75512549868439,30.154953952272567 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark08(3.468817023538294,-8.243572524552787,-4.711477637978273 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark08(-3.4694968408110327,56.26343620675063,95.40599290907241 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark08(34.6976611567825,-5.144152195194948,95.3754754067525 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark08(-34.76638696352841,-18.772143803276954,41.83802532164634 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark08(34.76998939725185,-79.39598238820302,-52.91120025785562 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark08(34.78733710976889,-1.8846405515318438,145.83892737022586 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark08(-34.82793429356609,25.32654956803963,-52.33550362720649 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark08(-34.96458514171969,11.459964676931675,-81.78332851744032 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark08(3.4974024035460126E-4,-38.6038960089855,37.032851258794594 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark08(3.5026938446757185,61.5563766891602,43.429538731007256 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark08(-35.052639460821084,0.0793457188188903,33.40251618869904 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark08(-35.06200210295278,-87.84878469641286,47.46576149174802 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark08(35.06702887472983,-100.0,69.5715533280597 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark08(-35.08694248139639,-0.7608668329914952,0.05883905634857502 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark08(35.12132220634459,-73.27557548593728,9.263289847277719 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark08(-35.12873410135596,26.014274917298202,-52.562286016732536 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark08(-35.134101700138196,99.54634500298673,93.78550380563087 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark08(-35.157799054308455,44.868918944573366,-14.96022641671009 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark08(35.17750887171689,-38.94980621380264,-23.061772464463566 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark08(35.18270750866935,-41.828719472695994,88.14733837243833 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark08(-35.192809895283844,-44.532093099080484,38.65563218410091 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark08(-35.2761829708398,-34.51472517474849,-4.366199132017455 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark08(-35.28670744545525,77.2449138262048,46.23598290794513 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark08(35.3241480633155,-88.50804981112086,17.75299154497145 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark08(-35.371700590411855,47.16275491501554,-10.22025799780879 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark08(3.544208339059892E-4,-77.65789776689063,-16.40567983647569 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark08(-3.5502392148537956,4.736734454157043,0.3843010874916492 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark08(-35.51254323112018,-4.218300516210973,-1.1493492824293987 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark08(-35.515322293865665,68.88826665615566,32.5906236290422 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark08(-35.56635053059125,19.882113605380564,15.375592201703526 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark08(-35.60090730936015,43.43553358548479,-18.427864484658976 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark08(-35.65871493248027,32.979322662423755,3.7561373030457377 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark08(-35.678380199268936,47.55062275799306,-11.124542197718826 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark08(-35.681328740772145,78.54053724597286,51.60788459642416 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark08(35.68397061940426,-78.3814313862514,-4.433417732375276 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark08(-35.720075112425604,-0.056428680615070365,0.6659140618429831 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark08(-35.78452844700553,62.59149909109016,45.58436405118555 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark08(-35.851103606090845,35.45860674055795,-36.00191558863699 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark08(3.5893252601226777E-4,-79.879914625509,54.785984438119264 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark08(36.01802912915005,-89.03453910232616,43.50843390994208 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark08(-360.2002228113054,46.68107703022618,232.92441837199692 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark08(36.05701309455581,-42.13193258260027,25.47797044526179 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark08(-36.06585252208717,75.08633737787116,41.97511718948083 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark08(36.09860104590143,-59.96755105906876,-4.6915813846489485 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark08(36.18349823942125,-54.582837184409065,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark08(-36.192118975512976,52.86523095464239,-2.845895017254133 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark08(-36.21643292876874,-52.594563353586175,-79.77463212205134 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark08(36.26251294129732,-47.15333556793089,15.164137436932677 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark08(-36.28382339531365,-6.954554150607782,41.66758121912653 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark08(-36.394121147915776,4.00480796622348,-5.410220640359149 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark08(-36.43984417008281,6.001652967940856,-95.74543024757183 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark08(36.48351464261695,-37.56755568221743,34.315432563416 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark08(36.4941392403252,-54.744835601483544,-0.0072534819914764626 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark08(3.6499513091477844,9.453606694088856,31.411188372159728 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark08(-3.6617313920614114,30.267430678790635,94.88031498110578 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark08(-36.62368100746798,70.27908217043246,76.18902132876619 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark08(-36.65468072263755,-0.8966733388237458,15.262608312695772 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark08(-36.68194853519541,-65.59543192046922,42.16000203826813 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark08(-36.68804853987126,60.43288664720345,12.372424001588016 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark08(36.71070035320703,-84.76218517324948,29.00531795926076 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark08(-36.799095713540474,-15.098274049531916,-46.276525153546686 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark08(-36.89058648668775,-14.161483955112715,-100.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark08(37.02941986141145,-6.170361051957907,99.45464923745965 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark08(37.069498189804875,-52.9807288134519,32.305007585140864 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark08(37.1112300198638,-47.63511355361361,16.115578482821277 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark08(-37.16305948337983,55.74458922506974,2.8876373989942877E-15 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark08(-37.207287705609176,62.53807058860699,15.02507438718135 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark08(37.30911016906917,-153.26935271463114,25.317336858668604 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark08(3.7316180378672588,-5.815726408616435,1.1341976231638 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark08(-37.335287220756506,-26.179518452774847,61.94400934673646 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark08(-37.43139538685241,39.61606184198071,55.0929152079633 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark08(-37.50587306253524,30.171478701974717,-52.17466178365626 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark08(-37.53101004342431,-94.28002239803484,-79.73640956303167 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark08(-37.55321062254169,-26.253177455017887,48.462504754867815 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark08(37.62643539579844,-78.09078929729915,-44.60864774542366 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark08(37.63706322146206,-50.69984824098045,13.0627850195184 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark08(3.764221249132978,39.49789443796864,91.85490566464233 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark08(37.65035706730051,-15.567566523000195,81.77930620748305 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark08(-37.67349320207681,-64.7949986110114,97.94328801399469 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark08(-37.68594202141869,-48.19267467439351,137.39458815360757 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark08(37.727247210027585,-62.77294117375815,26.630643783617643 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark08(37.74840776307401,-44.66641085355295,25.48319790891102 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark08(3.780161363865905,34.944395995816,82.79962979291813 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark08(-3.7802417660320997,-25.99601329942217,-62.01364892974705 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark08(-37.82005345722416,50.064489433748946,-11.804645579024111 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark08(-37.82927202749118,37.80195334728147,-36.31343764501801 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark08(-37.869998019855046,4.593677514739614,-60.14983970581092 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark08(-37.88744753265752,-37.47057794808274,-62.546544971007314 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark08(-37.89091114903112,50.5188999989599,-12.627988849928794 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark08(-37.92000036163467,-124.88309709557323,2.4429841002230748 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark08(-37.93919508642684,-56.35855679911859,88.97898974427683 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark08(37.94817217129355,-48.33542265092823,10.387250479634682 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark08(-37.97481978133209,-15.198716667309967,19.498295747364836 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark08(-38.012865545402825,50.10398148055757,-13.66181718591626 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark08(-38.03016509492148,43.22375092188481,-35.14987662890744 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark08(38.07019798968139,-94.227092833713,-72.67279537158694 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark08(-38.08172545405387,20.206379959042632,14.264099110540498 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark08(-38.08667879536003,-3.1624332546648253,-82.85224120722194 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark08(-38.1057939147569,-25.167807256327965,61.695097912994605 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark08(-38.11575190686671,3.9107172718880014,32.63423830818382 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark08(38.227222778733235,-10.36799760755558,94.05993205359081 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark08(-38.240503982958074,55.51797484891593,-1.0368212857378614E-4 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark08(3.825228801134195,-140.63659015277452,76.0619909151591 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark08(-38.270689456585785,-61.890319922201485,69.63593112965941 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark08(38.295621815900354,-51.141165369312894,12.731644068463712 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark08(-38.339802566482724,51.13011984927249,-11.400217107864966 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark08(38.41703214140642,95.64266871581296,-63.32713455973371 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark08(38.53749437035523,-51.49273279195918,13.877177862994943 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark08(38.693752493788075,-21.785083311748508,74.08188718466205 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark08(-38.721121446346714,52.25354006047538,-30.505840139639577 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark08(-38.73370160738743,-74.29283669869486,13.171979210440721 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark08(38.780136097242796,-100.02209111760774,-51.67026883583793 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark08(38.84437823013818,30.87452210454108,179.71626063589497 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark08(3.885780586188048E-16,-0.5976748657901259,-0.020956035476666267 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark08(-38.96231874835643,26.21872131981091,-67.54894490017263 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark08(-3.896498709510168,-57.05820251323013,19.255462270019137 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark08(-38.96608026234238,22.931932483280658,-45.12687796419572 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark08(39.081267127497625,-87.20755743124744,-43.07891082061262 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark08(-39.088646181754136,16.148467524029385,-83.39820717040874 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark08(-39.135232860504324,56.276271959769716,-3.282852143955315 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark08(39.15016157850015,-125.6691076262152,81.27019258603424 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark08(-3.9159775253515967,5.134083418278958,-0.10301066044255917 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark08(39.1792866687273,-65.54551501087492,25.54279566324159 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark08(-39.207559733618545,12.7386499845294,-90.57458290500193 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark08(-39.35603310419804,83.56967016854725,49.07124102450041 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark08(39.458843834953626,-46.16039968312523,27.62652846540532 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark08(39.54292551965273,-14.125196033728697,91.94918081829567 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark08(3.959000827054989,24.38301111249443,60.717588134555854 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark08(39.615444988254616,-53.31957295651573,13.704127968261117 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark08(-39.68709269424543,67.63793124802766,15.948158099080091 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark08(39.75405961054762,-80.61460764134048,-15.349987964456204 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark08(-39.80231206316971,17.881184297936954,-26.137023915512472 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark08(-39.814809921962016,93.0714679439605,52.26930244879091 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark08(3.981853425440769,54.8460203694889,100.0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark08(3.985527872403992,-56.804202904892314,-0.09156396571712669 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark08(-39.92269931236733,29.66095021159878,8.692707920360194 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark08(39.96911467512736,-17.178699490428755,85.54994504452458 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark08(40.00098066849395,-61.97213212352163,-0.020241921488340253 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark08(40.01798141483109,14.141418948963564,93.00828363695888 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark08(40.03143368368399,1.825283561547225,156.56401065770382 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark08(-40.09419681485818,24.580053682418907,-26.14509639344587 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark08(-40.119211492885405,64.03331819804376,46.599574700473305 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark08(-40.13074921717337,-30.520532588357256,14.742802138271216 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark08(-40.28699849464977,80.21085010899753,40.563503307528094 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark08(-40.29393329076234,0.03216004815746487,-55.36795664911136 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark08(-40.31181843091626,-100.15274466339677,-100.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark08(-40.43060676090716,53.06326561660268,-14.203455182490412 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark08(40.469872325936414,-92.99158570427312,-63.002758103942114 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark08(-40.503941878341784,53.43628430884816,-13.068460690534156 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark08(40.520102015734636,-43.98621749797998,35.15866737803884 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark08(-40.63351492696012,88.66792614734719,55.435455173649466 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark08(4.063664796318565,-52.07759923458897,-59.43207230901779 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark08(-40.8244728643677,10.241692964436556,-13.464664616911492 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark08(-40.85302849122649,23.899272708752164,-49.06747523422656 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark08(40.98133040637424,-31.84576174833507,59.252467722452586 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark08(-40.996452877040966,-5.720067636511121,22.650139345166796 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark08(-41.133843194603614,2.451996600427195,38.68184659417642 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark08(4.121162467162686,-8.11738968909834,2.4254320191527423 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark08(-41.27366719281814,-90.87291966746083,77.9773836895929 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark08(-41.28289425395125,60.06915091386458,-3.7099957846308307 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark08(-41.341779504249196,60.264746892647054,-2.0495811836532942 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark08(-4.142424991346942,78.3546960981484,-27.54434562320813 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark08(-41.70699141530118,63.11175692810656,11.579527635863784 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark08(-4.171373579187392,-12.506460970909226,12.73844166898137 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark08(-41.75742608755708,99.6030427512294,75.36410287616243 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark08(-4.17935318765179,-2.778983056759136,0.7552807602580828 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark08(4.190781470446575,-44.82004715004857,-83.78580980734439 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark08(41.94323203552247,-100.0,-29.815833003663485 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark08(-4.202657696502378,-48.9124252986001,54.50079062675675 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark08(-42.13915857827948,-33.41472657272275,-34.92193524135474 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark08(42.15891829790925,-71.6273896715278,-89.31582363573357 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark08(-42.198667103565676,-15.418599445507999,56.19510024264082 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark08(-42.24093049981612,44.82684899537885,-4.1567148223576265 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark08(42.35714078372095,-64.40107135223718,33.12408299501223 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark08(42.49739185086622,-2.2801152860238147,-75.6707768201541 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark08(42.547383300006395,-42.695335018055765,43.82226319051716 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark08(4.255391445917169,-58.015284217317785,-33.184730592291565 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark08(42.555343137358,-80.81140163945737,11.346895083204302 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark08(-42.6495403723699,59.08308792274855,-8.238250378764757 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark08(-42.708372949798836,-95.52103115861343,-92.66299806782202 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark08(-42.7347800390401,61.96029524217084,41.17511633855476 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark08(42.73744754328624,-84.31773234742094,-39.046236583963875 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark08(-4.275147252188431,-27.035111654838385,-92.03596724413718 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark08(42.79005842338274,-52.8781762880297,24.184619020883712 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark08(-4.28394380697169,5.641347568013539,0.0016600419069034437 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark08(42.85576705266482,-57.99569918855875,13.569135809099043 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark08(-42.86842396673055,-32.980299207816586,14.28255156238977 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark08(-42.90411260973493,90.00081620452814,0.028162771553716937 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark08(42.94931077587111,-36.23512371097809,57.94848123245205 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark08(-43.05066794490979,-59.03707728709511,8.634068600304573 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark08(4.31187782830591,44.1932328694285,6.054373585876121 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark08(-43.17871206505257,50.341886311841144,9.082112568384424 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark08(-43.25113986924496,87.10281344470982,53.92053914938663 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark08(43.291169854303284,-76.53348274718654,4.264827491590729 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark08(4.341998345716155,1.9252244271866354E-19,13.625637220006839 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark08(43.47746350718526,-59.41406583287223,50.69718623625653 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark08(-43.51813005731094,57.820796735669695,-14.261222049225964 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark08(-4.353001191174805,0.11997853709416009,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark08(-43.605575202154,1.1017380147305915,41.0354659276438 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark08(-43.703354710303614,46.17369951180643,-0.7138052950862459 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark08(4.372797905076163,-5.968938871112138,1.5961409660359753 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark08(-43.73586903568971,70.97957030692162,10.751533506774113 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark08(43.82409048176544,-99.99997162862277,-68.52758819025716 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark08(-43.8315009538153,75.8272310831382,20.159959304830508 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark08(-43.83429271795289,63.412696113592204,-29.952355484469685 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark08(43.83617280258445,-94.4092698953519,-55.7392788204387 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark08(44.0213536240217,-56.26683070353089,20.805795828724367 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark08(-44.12240253266002,58.404277475623566,-14.281874942963544 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark08(44.16294995685165,-44.77343180966902,42.941986251216896 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark08(44.165970403885154,-81.74005838077238,-29.411409223094402 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark08(-44.22455908800368,56.5375213748315,13.308452782469793 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark08(44.22568694191955,-37.48907592283168,57.69890898009529 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark08(-44.23536077592121,-16.869078637609036,-21.409086841897533 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark08(-44.29048549495193,91.40450435192604,49.93755221899652 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark08(-44.29910896621795,81.83955199075407,32.34513052452514 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark08(-44.37018268439124,72.20273343174391,11.466116033666422 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark08(-4.440893300225255E-16,-39.776513668332754,-77.98223100987062 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark08(-44.41460619401047,64.83922142403497,-3.4724929138549885 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark08(44.457629364648014,-92.11464154162074,-50.85639498929112 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark08(-44.504552548687286,-34.34682799686481,0.0010276111380349558 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark08(-44.53585947328509,65.59460972617605,-2.418358967503181 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark08(-44.54526925057103,-21.964296062475764,37.44467118971002 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark08(44.724027350346155,-57.97514742938719,18.392712732632074 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark08(44.781765205047634,-65.55084836048692,10.461897034826883 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark08(-44.803321682396664,1.284407341825757,25.44985354111838 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark08(44.947515751054574,-60.42584047084684,15.561662638264936 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark08(44.96538982644697,17.51285321917778,170.49961009840618 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark08(45.12401562107165,-44.49468924064343,39.280488499777306 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark08(4.519972685842184,-28.529332101231745,-41.97416837003189 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark08(-45.209060285195996,-23.26143340373685,26.18834503756795 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark08(-45.22558512482321,81.06292444282415,22.112048622381646 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark08(-45.270733859812324,47.283634169070055,-2.0129003092577227 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark08(-4.527484375194935,4.857454563233315,-2.2967476723232805 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark08(45.295571965348344,-60.16027107007146,14.864666406615655 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark08(4.531925393001659,22.488221357788568,58.57221889458212 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark08(45.35657353464644,-47.20948663285366,43.22061932141297 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark08(-45.40678200984238,31.697303063414886,15.280275273222392 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark08(-45.45099526626994,15.3511892812866,33.83913190214223 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark08(45.46128329054796,-66.48513324642038,-3.776483055663999 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark08(-4.546323471462153,21.76892020882842,31.469666330065273 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark08(45.470869481917276,-31.058979113567453,75.86544654541177 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark08(-45.610508778294616,79.90651076562285,23.870502344783805 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark08(-45.63352946299861,-85.9002843854632,12.222616301378991 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark08(45.70753150755234,-66.95352229732917,29.62681753630713 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark08(45.74203165589772,-91.13568677871467,49.53696619790713 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark08(-45.79346630999531,-35.033830608444056,9.791037925326901E-4 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark08(-45.809984895115264,-15.174703990264916,-10.354124726178725 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark08(-4.581001785459417,-100.0,44.59284751074688 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark08(-4.595308237031457,-6.5660627204145,-26.179461259488452 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark08(45.973532341666896,-41.31492766428264,55.29116504173312 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark08(45.98723375044658,-72.9678215587694,-7.973941866199073 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark08(-46.12427872360618,74.5361580237674,10.699479876716538 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark08(46.17495979889763,-62.47290228254868,14.727898825863038 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark08(46.17585594938702,0.006319442025619401,139.19307941035095 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark08(46.20630998797707,-82.58430281299295,-3.1929753979698106E-17 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark08(46.21530534170246,-94.05889213369124,46.2727904651939 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark08(-46.22465620651579,-55.52936113960445,-61.00864422164243 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark08(4.633133292484949,12.402329371012708,-12.893870009907863 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark08(-46.36788032665715,58.54793319458465,-22.007774590802143 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark08(-46.39460818128169,3.263077885931481E-4,-26.058641368228784 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark08(-46.44164111478196,38.13284260424096,-19.060352367532747 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark08(-46.47594147489477,65.23682163714078,-8.954181150402743 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark08(-46.547508050097996,0.0,11.434305594239708 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark08(46.57498826031329,-61.72839575827819,16.7242038247598 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark08(-46.699126415846344,70.02478095174072,-4.803517327212903E-4 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark08(46.726056749595074,-59.25419192449381,14.60951419801573 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark08(46.746881234115364,-86.90486858322154,-20.15010329567299 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark08(46.75704743488923,-44.18255496752054,53.467273788143174 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark08(-46.945370806133944,92.25807846575637,43.680044513110936 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark08(47.15299705236225,-5.879247409129754,100.0 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark08(-47.16317854381957,96.45841559491254,52.99809188516127 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark08(47.17596163789546,-75.88513124759024,-8.671581254699223 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark08(-47.19568419205276,63.97376275751565,-12.44121033629212 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark08(47.23685363106644,-96.19742564526189,-50.68429039732444 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark08(-4.725489076990868,8.725969638902857,12.8758557762701 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark08(47.302271377253646,26.0984191322559,-96.50903449969694 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark08(-47.31597949225724,44.575386149684704,-51.226369850607426 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark08(47.34807165714153,-59.79067939483602,41.82041803416497 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark08(47.36818327190889,-17.68072591274384,-0.11953321445068354 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark08(-47.405764272899994,10.815802388107992,36.64678265905915 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark08(-47.446021383202876,72.16187506926595,3.5564823157181675 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark08(4.7448116269779685,-7.117060418144575,0.04651577371330289 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark08(-47.50515571735844,2.362779910256259,20.40278397494788 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark08(-47.54958689221938,8.937556207561109,38.61203068465826 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark08(-47.612410003680615,-47.73782467726632,20.401075141510198 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark08(47.63036869123297,-91.27323751540911,42.07207249738125 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark08(-4.7682775674355184,-78.6835316091566,60.84528733676743 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark08(-47.741215852852775,59.46128025970994,7.374406684543645 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark08(-47.74130854102481,77.43916411808641,13.195272184996002 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark08(-47.90193461986196,73.43992954763719,-3.545557958538275 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark08(-47.91726825952349,38.99531203170368,-26.606244062048503 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark08(48.03171288393511,-90.70784182156352,1.4441944350696865 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark08(48.11100976079165,-74.57801236212332,28.03779892812656 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark08(48.15891880699175,-36.79171250273102,72.46412774230808 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark08(4.816297471945004,-14.795557628140491,-1.0395053167623778 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark08(-48.247995316925184,20.65592517632217,-90.29175972371988 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark08(-4.831009322035139,6.445809348630131,-0.03061294205025881 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark08(-48.31273975298403,49.82362267820176,0.01895263739491876 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark08(-48.33612272645812,-27.676386298952096,77.58330535220512 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark08(-48.354739966302816,-166.1831009745326,-48.63650968064572 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark08(-48.36668205826227,13.796182443850412,-55.285764423088146 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark08(-4.837464517240939,31.177250557396587,49.378341399755904 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark08(-48.3938805238129,3.654295884585707,44.73958463922716 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark08(48.4614261182916,-58.94837229336306,29.05833009494357 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark08(48.462956665994525,29.813757463119344,206.30277905047578 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark08(-48.47299126019623,-25.70086254222619,87.03615582491628 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark08(-48.49330193435775,-37.98007808281913,-0.03452014869114901 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark08(4.853515894257512,-44.06575884815898,-28.346475647734835 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark08(-48.5631289385168,77.69641407855488,53.89083778355209 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark08(-48.58131387404858,-90.48690244333709,19.099003855659006 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark08(-48.615329662866266,57.426706317851085,-30.992576352896634 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark08(-48.68719488101239,-74.69696452125838,-156.22058922627593 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark08(-48.69822036335662,29.32349851757349,-85.87686772812798 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark08(-48.70243089954292,67.87032353235985,-8.795849307114189 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark08(-48.750733760043865,-30.45861149672382,-100.0 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark08(4.88348263726202,-82.33072124921677,-54.23912759427167 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark08(-4.885621134466574,6.511365668695496,-0.06333573921383504 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark08(4.891109030044653,-16.201122903639483,-17.503629820495306 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark08(-48.9142702244898,96.32646609348515,46.52875310747553 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark08(-48.969316540504224,95.83316235425227,77.74478467375475 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark08(48.97805265553447,-76.04113766452826,-3.5862613565086394 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark08(-4.899772182100782,40.082546821208915,65.49071030365276 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark08(-49.004047071822086,-53.74059098971862,-51.77509607927116 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark08(49.061758959898995,-35.837450010263105,76.3060850509966 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark08(-49.19024902163779,17.35379555269884,51.696883190096486 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark08(49.23349724852253,-66.1432587783167,16.90976152979418 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark08(4.9239581182158645,-89.68502331590862,-33.910483912176616 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark08(-4.924635912180292,6.45315659727942,-0.2967982151871388 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark08(4.930380657631324E-32,-21.219858120579346,21.219858120579318 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark08(-49.36100564701356,75.76547060171112,3.5075262748049987 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark08(49.37552311046616,-78.73112822552196,-14.521639383504755 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark08(4.938768378672971,-78.2704362873444,15.506430236528866 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark08(-49.602957222076746,74.71554732461384,38.35425997674338 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark08(49.609749994525735,-63.28834094227765,22.252773225722166 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark08(-49.634189057642665,-66.42739901474542,-46.34584406942401 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark08(-49.71460824698904,72.18394080309602,-4.775943134775051 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark08(49.731329029947865,-77.1127553833636,-3.4607273500887326 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark08(-4.983687836286419,6.665092120255468,-0.3311265088898744 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark08(49.92508369606074,-55.344788367350105,40.6564706802769 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark08(49.939241728258466,-294.7385921824071,-250.88231658328783 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark08(4.999001162742859,54.492769322334325,124.9251793104417 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark08(50.04609836382127,-78.73358792781798,-65.04273802812216 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark08(-50.07594932272746,85.66169553858835,22.666339435789205 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark08(50.11101062970317,-97.31984799884536,-11.39363907448687 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark08(-50.13119703046251,52.64357437212852,-38.27820723263296 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark08(-50.160993485445154,74.89184696069013,0.8651599379284562 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark08(-5.018995255147468,-39.64371423114745,0.007894575000907891 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark08(-50.249296202075286,23.346465033930453,-3.0818647752413924 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark08(50.255234592384426,-58.45366294523901,35.10031947506686 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark08(50.29383707497809,-75.54482441108905,25.250987336107244 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark08(50.31711975184737,-19.368018182449575,-16.983189242665617 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark08(-50.34673004286778,5.96226346972783,-100.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark08(-50.37791014644457,-43.278076468623965,45.35677075943829 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark08(50.41056656695437,-36.315470118560775,78.67166253429663 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark08(50.421468163811795,-56.20465547902587,54.83032101048485 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark08(-50.52755426451135,-9.267805477417324,-25.32195493285299 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark08(50.54302936009518,-41.902462857681606,69.39495869171722 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark08(-50.58438692372691,90.79310004594754,29.833039320714374 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark08(50.62478446804991,-7.677651113659962,1.1582604935701255 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark08(-50.69689969517313,72.06155938804982,-6.806052056408632 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark08(-5.0925208600881575,-116.16245845574586,86.47210946807736 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark08(51.04352512767203,-26.88910499481602,100.0 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark08(-51.04386205699283,-55.39241449498371,-49.0932227304272 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark08(51.10832210303989,-81.78274991136107,-10.240533513598635 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark08(-51.11916784578361,75.51959448800363,-1.8603793008930931 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark08(51.13315504544343,-39.07992313892763,10.78446759062291 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark08(-51.188133338112756,52.70840484654674,-5.821980030076673E-4 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark08(51.234304733290344,-57.29844377083302,40.67682298499985 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark08(-5.126391500436601,14.701751104191278,14.02437771283541 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark08(-51.30186181303125,-14.726716105445057,37.65173876796104 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark08(51.33804912809286,-83.18884209561134,-11.886915430884883 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark08(-51.40558317537387,-61.16568395542945,20.097378233987698 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark08(51.43556752631454,-54.75486060609233,37.040230707312524 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark08(51.44250559802514,-66.25176796436818,15.11159188495155 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark08(-5.148368686344629,-11.528667013902735,-0.0168481034889153 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark08(-51.49623067528046,47.33876933762022,-27.26803950589 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark08(-51.49972171565586,46.14108401885713,96.33035218743879 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark08(-51.568130768311974,81.74836210968805,8.792331914440174 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark08(51.627607631642576,-57.8374304790745,10.355864672057814 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark08(-51.64100355709141,-12.833462481246883,-16.79908736575713 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark08(-5.186067094244365,-34.58854221732024,-84.29789801227543 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark08(-51.891145759760654,-12.65462980398327,-47.586121208785556 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark08(-51.90027262103873,23.190552117308695,-77.90348106802776 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark08(51.917526936941435,-52.70371472303124,-0.7981092333958122 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark08(5.196053527095207,-98.47302344741857,58.68150967146272 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark08(-5.199582404694965,-11.285040623417636,-1.2667513131436928E-18 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark08(52.03991536829594,-69.68483217053972,17.469891377188766 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark08(-52.1640762152448,91.02336484905848,-31.00504225992919 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark08(52.167812573212615,-70.6042836901231,16.865666666186545 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark08(52.177664892226936,-35.93266928481608,84.66765610704867 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark08(52.17957513140712,-83.68814376832422,90.89944827428778 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark08(52.185697523279345,-55.74480186627406,45.65364635254713 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark08(-52.25239711105347,72.13645011648464,6.88550284205138 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark08(-52.284814442669386,73.38746046563674,-8.508726069939824 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark08(5.230091432494784,30.36728345014273,77.9956375245647 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark08(-5.234775419119785,40.37086262621392,66.60819532186338 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark08(52.353399881649224,-62.552293413472526,31.955612818002624 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark08(52.380917559186095,-70.77148806343375,17.170572877485668 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark08(-52.41796857811245,66.17995831069511,-24.87780238793428 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark08(5.245124966519427,17.373219332842954,51.782581663491335 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark08(-52.460990876271254,28.68048168518353,-87.11853336397338 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark08(-52.46849483149087,85.05485728598941,95.9371446789801 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark08(-52.608417486817046,-2.827151088100962,19.66338120675212 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark08(-52.612260989341955,-7.79320120258906,-72.95025556220955 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark08(-52.62956810629727,94.38496415422554,32.45065730479578 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark08(-52.76112786026224,87.00523941414383,15.727095247500934 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark08(52.827733206950946,-92.42393488148193,-67.08434180445953 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark08(-5.287026535459131,-7.69361017223231,56.84418178873548 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark08(52.97443869104601,-44.95999660154091,69.00332287005624 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark08(53.05155893959841,9.636026882920262,179.45267570836538 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark08(53.181481049144395,-166.53514525481694,-34.596785410799754 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark08(53.18813366657115,-54.079472158397024,52.684275522143736 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark08(-53.2266573194073,-37.83585044255633,-9.597099088691351 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark08(-53.264895029607715,-7.936088134783304,3.204450990529878 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark08(53.34525600717954,-71.22353757241966,17.878720461772417 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark08(-53.347431627014494,9.482262408374247E-15,54.91822795380938 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark08(53.38972179323555,-90.51655430485316,-19.293146903204754 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark08(-53.419686342292145,-0.012852918991356432,-2.2877932432976342 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark08(53.56042542115509,93.65817144420456,-54.77742182581138 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark08(53.60432942180287,-98.61111998326831,-23.289856127120075 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark08(53.60482466461693,75.91243476712106,-25.49915689259015 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark08(-53.61390378000881,-37.28906522232095,-78.19870944009818 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark08(53.74608091172043,-98.3654363321723,-33.92183360238841 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark08(-5.375809038648001,-54.27059990092644,18.959031805913227 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark08(5.3768016136338055,-3.341768722692984,28.79833777875254 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark08(-53.83502413922553,13.003876103449269,40.83114803577625 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark08(-53.85981668981009,-48.00209116453119,39.097045003477284 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark08(5.387636973651211,-7.2576521792045625,1.8738078581446773 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark08(53.97296949687209,-71.44258016353147,19.03374816355333 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark08(-54.00068792909159,82.53586896559446,4.640470470709019 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark08(-54.00983210151058,-30.359495120770024,-27.15824166881713 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark08(-54.06865485696545,54.45953419316895,34.86314242581855 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark08(-54.1309528933493,42.383969024438265,-33.195634304807186 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark08(-54.14966639127288,90.7231223474513,18.99731115277761 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark08(54.150797319084205,-51.300294269031724,61.42259974598405 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark08(-54.19293744993312,99.82791687352525,-49.434646093530496 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark08(-54.2070420587154,8.369788291669849,11.295712914389757 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark08(54.22186781447752,-95.87902585535785,14.893223706470323 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark08(54.24662255470212,-1.7763568394002505E-15,164.0940668697885 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark08(54.24662503574942,15.521353958104257,-34.68674696630923 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark08(-54.293936710014854,-33.62475662399258,84.21886107664184 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark08(-54.328504449984855,-93.70777757665071,-67.36732784177728 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark08(-54.46252849789144,-12.195453429351133,50.97544916169505 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark08(-5.449073140184839E-14,-39.756421821233765,-66.36967785985215 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark08(-54.52574853707428,-36.89196936274981,40.60681768934903 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark08(-54.53698682183735,-85.31396290621616,-63.70161605621461 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark08(54.542678465681405,-28.749542115289362,107.29297500849941 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark08(54.545028725888415,-100.0,65.58082025181048 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark08(54.563291067365505,-46.76306135855394,70.19811731419719 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark08(-5.45637688167146,-82.25246855686115,15.002359787649738 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark08(54.56533691262031,-170.3828558312284,74.88338649531113 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark08(-54.58411593857647,31.362533976565945,-100.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark08(-54.636450362157674,53.44588022638649,-3.225864020350855E-11 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark08(54.63826152064551,-69.95705068870414,25.569046412084727 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark08(-5.466776002130669,-21.653045191753325,28.38317591149313 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark08(54.67380367214871,-34.777754018779056,96.01985583167168 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark08(-54.682479543713036,-13.905401837069402,67.32315161587987 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark08(54.731089126030575,-93.52500238858256,15.078762136193134 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark08(-54.80896028729599,100.0,35.573119138112034 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark08(54.846726824734844,-56.399008514553486,-75.45153350711774 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark08(-54.889905609445975,-11.9174577044975,0.1420544735965919 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark08(54.92592759651943,-68.64000960374145,29.068559908870267 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark08(5.495749858508592,-87.57587543263756,61.303321007713016 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark08(-54.957675671388245,60.41603162499764,-42.47027404310433 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark08(-54.97644490186591,92.79655449472278,20.66821199445603 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark08(-55.008170864201794,83.53361330872306,46.335558339927495 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark08(-55.03613428340825,71.80961447782948,-21.485869174805927 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark08(-55.071145277305106,45.032125832576696,-11.986578056432379 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark08(-55.08517933657355,75.95541323195205,-11.773915219021656 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark08(-55.10903756078094,11.988620148418264,94.7025219998662 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark08(-5.518213750436998,-86.47682128203046,-106.25879677828756 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark08(55.29259722887308,-95.01539866663452,76.768820284197 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark08(-55.41829579643232,17.398761591126814,-48.58740009508025 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark08(-55.4330202641511,73.56848419471089,-18.135463930559798 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark08(55.442926900933585,-64.68617205122652,-38.941787085818696 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark08(-55.45063607813363,-36.455495671178625,44.163795655675614 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark08(55.457543451241065,-16.541053252104206,-7.779546684662122 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark08(55.47743213634717,-73.97131754328626,18.59470371087286 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark08(5.551115123125783E-17,8.881784197001252E-16,0.8764689199481861 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark08(-55.52870101910368,25.680981627460042,-26.293069471341525 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark08(-55.5867417668119,45.245717365012155,-6.245557056977824E-4 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark08(-55.64619219623562,57.60192130099217,-50.16393765992764 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark08(-5.5772880006018255,-0.7928620119786225,-16.746791698967826 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark08(-55.875235925791344,-86.40824269270921,-37.748407357358616 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark08(-55.98165805032966,39.276638760945616,86.55539558032515 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark08(56.05360812851846,-100.0,-39.37025144448186 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark08(5.608685530431667,-42.576154558052295,-68.27022093098182 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark08(-56.099000125431324,98.49754536113261,28.931564904165953 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark08(-56.10157159261354,0.5313540198990231,54.01411657218889 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark08(-56.160058794387155,83.72131179655881,7.2460087484300475 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark08(56.23831786788712,-67.86541630106524,-17.710565129179923 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark08(56.33678287633902,-79.19801996401466,3.709182191863591 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark08(-56.397600471358636,74.97027936738098,-17.681446352519064 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark08(-5.6399323359931,-2.32502417541645,3.5706631976952634 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark08(-56.41232495261852,-22.148514599038176,57.202016336116316 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark08(-56.485198127182315,78.25196303426364,-40.5767873581778 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark08(56.52238994345912,-100.0,-38.103817722904246 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark08(5.672052714016246,-57.69089895802577,-90.92190739526164 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark08(-5.701333188617025,7.223699728518483,-1.0991433247500026 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark08(57.03301238827768,20.751670345911364,-91.0652571466583 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark08(57.04667292537056,-48.26786981393916,5.128311970074321 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark08(-57.07313944439454,-22.400517386954476,29.748425988768034 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark08(-5.708969034560949,-10.835100865631183,-32.15071757987216 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark08(-57.18133961105928,24.503854560291686,-40.17531634784156 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark08(-57.277885410289144,-49.844470160054584,75.25950432125767 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark08(57.289584511673645,-52.7193038542069,68.00094215340204 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark08(57.29522928152205,-76.69147113893474,50.96408351361267 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark08(-57.32316152639456,38.4359223276976,18.615846335404854 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark08(-57.433677503905855,-77.80563731109864,-11.8535583269832 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark08(-57.4420592802561,75.67346463293454,-14.646971325528124 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark08(-57.44465806620741,-13.29978705760499,34.479907159612736 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark08(-57.53191140578606,-52.619166529740774,-7.334180415888649 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark08(57.651174020043285,-45.44449249879706,83.63520093947639 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark08(-57.664478479349036,99.92212700055737,28.421614889862525 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark08(57.69236000867491,-47.54450789170264,-80.95957913732417 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark08(-57.69637199311588,0.0,-2.6421172630292244 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark08(-57.702577206009046,51.375599000900166,86.77410124129199 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark08(-57.7865166774328,-89.04262934998715,-55.92216432991823 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark08(-57.80798061089215,45.50098433523217,6.672286724610615 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark08(5.78410139438264,5.420257540236857,29.610895264734822 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark08(-57.861973243751976,72.09170774536517,-15.800530828408089 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark08(57.91709050586692,95.36300727281088,14.254201313893148 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark08(-5.805268661234653,-33.53568793868057,-46.66666665034851 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark08(-58.05465871601443,-17.581812929422128,4.330006869249047 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark08(-58.064303483708244,50.21058902465108,-73.80220397436692 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark08(-58.06430499765391,-13.287657427344541,-100.0 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark08(58.08491840081399,-65.60362208431047,43.04751103382102 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark08(-58.14410816494719,73.9717074459067,75.09747528064372 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark08(5.814680343955198E-9,-63.8774004127892,-82.31452621230804 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark08(58.214734633089115,-95.57381449589217,84.55743671662445 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark08(-58.26838019847307,83.48541477768211,-7.834311040054899 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark08(-5.833377892424025,2.416784823560986,0.27493886228921416 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark08(-58.41902600551477,41.134613406610505,-92.98785120332326 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark08(-58.456598438157634,64.66961513245654,-46.030565049559804 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark08(58.4773739680958,-71.53680682252298,32.35850825924146 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark08(58.51595329491157,-95.53160095902209,60.04141756195534 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark08(5.852272920794135,-83.93401514246516,133.84673750457162 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark08(-58.60243020816562,-44.747767769089,48.89824949330327 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark08(58.60369462109189,-301.3863618028851,-194.45796870709918 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark08(-5.86221389540016,-0.30425811935906755,0.8806757541058801 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark08(58.753938608235295,-68.29363183925643,41.245286328699436 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark08(-58.83390026941693,47.31484896855554,-74.53615874561545 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark08(58.925852305988954,-40.26275637478356,97.82284049519465 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark08(-589.3262076867126,-864.3328612603724,-630.9006087050524 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark08(5.894406485839824,-0.08661950293967546,19.080776778435016 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark08(-58.99133510979747,68.2657888706497,-40.2855201359296 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark08(-58.991696993736994,70.45882290770497,8.428039639399774 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark08(-59.0028393290247,-218.8476983495219,-66.62061917588971 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark08(-5.901283677851429,-3.701624656273896,-24.955606424180335 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark08(-59.0390188841986,78.36014166330378,-19.32112277910519 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark08(59.06383209064209,-38.05771018664109,101.4839670269405 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark08(-59.100807058570396,-23.952852171619554,-42.61694666932247 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark08(-59.12760901144462,-83.05363693527173,-3.0576189839342893 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark08(-5.929681790978825,15.774690645261474,13.864557936180834 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark08(59.32298690269445,-51.95183296280745,75.63609110926335 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark08(-59.357170270356896,-52.81205530302688,31.860681037314293 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark08(59.41432235407663,-66.38326253659405,47.000135931770416 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark08(59.46610032375303,-47.796584347096505,82.8898557056162 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark08(-59.64640784614663,-71.61301794102562,5.7324061446335755 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark08(59.64846571814392,-52.2685928766077,74.40821140235454 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark08(-59.67690185790455,-74.96810363715193,-7.725504616751407 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark08(-59.68258697906287,89.27654776949338,9.383926166525323E-5 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark08(-59.71067528937436,94.61269773600887,4.876328444037306E-6 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark08(-5.984939607628846,57.58667028595765,98.78931807582366 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark08(59.89370052587299,-65.27756183581656,88.34607120845021 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark08(59.900912446839385,-29.771552089506997,83.37630723352675 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark08(-59.90983098310105,10.441930539558953,-77.72606413063421 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark08(-59.936603427508686,-100.11924178985058,79.93984925888765 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark08(-60.02511626878547,97.09104895758242,14.106749108808431 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark08(60.05811036014309,-73.22746199394165,35.290203419340884 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark08(-60.11550237006256,79.57614265460053,-40.044318725538886 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark08(-6.015980597492696,34.04973576091786,26.68572142656553 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark08(-60.19645915377027,1.4724807107494517,49.94298830168981 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark08(60.204850140803714,-75.1957681294617,30.22301416348776 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark08(-60.460102734461685,89.49939243955296,-0.8107269974842416 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark08(-60.47587775691101,45.855295341673354,-33.52905179422949 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark08(-60.51268312117179,6.007332513122965E-4,-43.21074915035 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark08(6.051316593761047,38.232120776425276,96.18898764016775 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark08(-60.54094951229244,33.220731151653055,-39.030792675540454 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark08(-60.59610169345726,100.0,19.782491246313857 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark08(-60.78293274823634,97.05526802566565,11.927516978951187 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark08(-60.80740347430085,-4.174007278609516,149.92236469757609 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark08(-6.086769957338335,7.592066593940654,-1.5053803573388036 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark08(6.09197159922844,-8.238932694957454,2.2554689681568476 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark08(60.93712924778797,-100.0,-3.473630071250187 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark08(60.949774533885595,-285.9233554838813,-212.33843557303868 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark08(-6.095333472495633,-41.641730227520306,-100.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark08(-61.01652480756709,6.328629035612278,-12.186638784684959 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark08(-61.09433867070601,-152.20056978168532,-84.04834844007256 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark08(-61.23953876990229,-60.37749068776905,-40.5238620475767 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark08(-61.263346176181116,-10.37277366823014,9.092714579997814 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark08(-61.34931693244522,41.500494588352815,19.848822344092397 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark08(-61.35462382638688,10.68838923540254,-98.83408028196537 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark08(-61.38869279879129,35.30612357450891,26.082569224282377 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark08(61.421597366026134,-78.45673370148802,27.459914312943827 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark08(-61.68142871650879,-49.15167110436621,-2.7214551717228124E-5 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark08(6.169426770302689,-8.548791834359038,1.539927300235053 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark08(61.752653421651985,-90.68717629718684,5.454403997377163 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark08(61.804959557584496,-82.72033683243951,20.91537727485501 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark08(-61.825060403780796,-63.91763012799192,-92.01194142664646 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark08(61.856583700124226,-92.44271676106463,2.255113905038314 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark08(-61.85749458709303,82.29556629960686,-19.45367269733157 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark08(-61.97628295772375,2.798279417908617,9.62879065848044 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark08(-62.02574627282025,51.31651917941831,5.426134342454589 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark08(-62.0333943226044,95.03068473899134,5.531956306856671 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark08(-62.23298636549699,-0.729170346151281,-48.73858219841368 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark08(-62.24291419791558,24.757816393974373,-105.46062945670968 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark08(-6.224802883919104,-47.68414141779445,-0.9103578889268523 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark08(62.32228978071717,-43.55457073459279,-47.31136732933814 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark08(-62.3472296177795,100.0,-63.29953271037374 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark08(62.5080695106592,-51.065445859570005,-67.17817577419542 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark08(-62.65929172736711,-30.585199647049212,90.27267636851957 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark08(-62.70588261045009,47.352114613322414,-93.41341860470496 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark08(-62.73183043874573,78.69103668268536,-17.530002570734524 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark08(-62.81167456517976,3.811131571418208E-4,50.62082346732757 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark08(6.284052992437502E-17,-33.95290397069489,-66.33501161459492 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark08(62.9980457651799,-60.14608347289192,70.27276667655076 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark08(-63.101317725959156,-174.6303690814563,-142.1536988979921 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark08(-63.108438143099924,-52.65668725404085,115.29193291645781 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark08(6.317090002911016E-4,-29.371868827958874,-58.578836029339904 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark08(-63.2456392087987,0.5608629869593926,12.89758311369755 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark08(-63.25535144602053,37.321694836277345,100.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark08(-63.268316401384595,41.292034228474805,-100.98596969554728 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark08(-63.44556466694527,17.326937169169792,2.4619279442717925 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark08(63.60847890386967,-48.73568789964614,94.92485723911162 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark08(63.62030589571651,-67.28911089607223,-81.86613777674236 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark08(-6.366216438235824,-100.0,20.274405855131477 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark08(-63.73572184118126,5.48861074112456,-84.73629122370893 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark08(-63.78458333290597,84.68947984176248,-20.403993988398057 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark08(-6.380637941958216,-57.446945788343754,62.256787403507076 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark08(6.381075341140991,-53.680780206068306,-50.44044127871164 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark08(-63.85903120544749,30.253815673948942,33.605215531498544 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark08(-6.389378674217181,8.58837990628537,-1.9904807169466507 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark08(-63.92564847960446,37.57197886155287,23.166037579840708 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark08(-63.96353687103312,-64.90638042620503,-43.98836354612013 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark08(-63.97106823228766,45.365188287154616,-100.0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark08(-63.97806124442911,-46.73896828079689,41.27128012762918 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark08(63.97993945869314,-58.84825687925698,74.24356588663669 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark08(-64.00320554923076,85.31332864115669,-21.38295936537888 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark08(-64.24172084464813,54.229275471705186,-82.8177648177388 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark08(-64.27573765188578,-175.57829739965115,-97.03774179817759 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark08(64.33842354813804,-85.9440119418118,21.12724676079052 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark08(-64.43186392897483,79.87889936820105,-1.7309854882963123 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark08(-64.43429441964206,69.3806835956523,96.49605812535839 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark08(-64.56356169303068,30.58876348412189,32.40400188211389 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark08(64.58890026513839,-86.9813976621643,21.374701797881475 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark08(-64.71670122793482,99.27454525773007,-2.1472962742196964E-4 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark08(-64.7832326868137,4.997023023703453,30.172362237844247 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark08(-64.84394014330819,27.71183111864912,18.34468302341717 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark08(-64.86962386699619,99.76405440273243,4.919305543876584 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark08(64.90657974297105,-55.898797276581995,64.07136752854397 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark08(-64.97024388979979,-129.0342326677431,-225.22369197698077 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark08(-65.0625263097894,86.8096919234874,-21.566833415001028 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark08(-6.50687981678702,-55.11064486264965,34.07461547576136 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark08(65.09592658491155,-83.49316952777201,2.8986697522191918 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark08(-65.14410390842335,-29.65288455045203,-26.984103111397403 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark08(-65.19451158286527,70.34457821469725,-53.323592733887274 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark08(6.522955279781954,-93.04331205070324,84.94956044412639 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark08(-65.25766694445443,43.56308514513533,49.997622278565515 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark08(65.28334869646852,-51.660390688458705,92.85317959563508 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark08(-65.3528681350387,77.55905517223943,-40.480522646816574 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark08(-65.3789389616037,-318.9304742262573,-160.55859406792416 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark08(-65.45958220584586,-25.325959026765418,-83.4775162282213 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark08(6.547536550236959,-8.718299347597572,3.741559124155508 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark08(-65.48466940470915,54.473415230333124,26.936491236574284 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark08(-65.50493859169222,87.72398893645683,-20.64823702789986 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark08(6.556451942562917,6.039927667476871,33.200057449131464 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark08(-65.5743925451737,99.99997821004303,4.8466981960092905 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark08(-65.71887622627897,42.37889074183033,-72.00543205924225 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark08(65.80344616470502,-100.41907734421933,23.012873609050903 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark08(65.84965864282503,-65.48087510928332,89.54213294578533 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark08(-65.86129967505201,83.64382682616258,-3.361500613565312 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark08(-65.88489154301935,-55.84441721893705,-81.96489012191545 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark08(-65.90582140168041,-56.55316757831476,-95.66282593415652 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark08(65.93512636510185,-79.08783327613119,41.200508869838075 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark08(-65.94543544445128,-185.29130955176896,141.8667213854359 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark08(-65.99658031941337,88.56928457661203,-19.280375478221142 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark08(6.615435266282641,-40.254422719476025,-22.768089970267877 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark08(-66.17693282058015,88.31755346907995,-21.89569152358054 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark08(-6.627447464319474,18.987512878646612,19.663479691129695 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark08(-66.33556929534205,-15.094223081794084,80.0880782919054 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark08(-66.36331070424826,-89.21437297529842,32.034054239289915 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark08(-66.4664033673215,76.01406202732348,-9.547658660001979 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark08(-66.54539105746797,10.278276844259764,54.69631788641331 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark08(66.58336906922472,-78.98903775251271,22.833185416531006 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark08(-6.659042773610237,-1.356743761061305,2.4475294567331836 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark08(-66.5982996096733,-44.999996027692916,-5.709156571187197 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark08(-66.70759078488841,81.02530807260399,-38.07215620945725 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark08(-66.75504940070971,4.190412692635306,35.692663908693895 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark08(-66.8489668663258,90.46454300432796,-26.330203597168342 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark08(-67.00386295338639,3.1664757242599393,65.50907560287988 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark08(-67.05645744713219,60.3825091249439,-81.19999789719337 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark08(67.29694778216623,-52.226002326768146,98.8749073275097 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark08(67.31940683461737,-96.74390364019544,27.853700478783182 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark08(-67.3464298915164,-8.122009766221474E-4,11.74399355299986 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark08(-67.41065245864156,-93.4062462136693,-100.0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark08(-67.42763506664186,-7.911642040569209,-59.54883887346495 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark08(6.742934788684906,-85.06976170265399,76.75603058717404 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark08(6.755406941416677,7.882623756645543,37.344968136940395 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark08(67.59787766407854,-68.20427728883358,73.85295226198136 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark08(-67.73022401590114,-68.38587677318509,-0.5821520266820954 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark08(67.76171922713664,-55.96599750500913,135.71484999583677 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark08(67.81586506360931,-169.5462252813553,-34.88851840934686 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark08(-67.82767035234377,24.071303885450064,59.212486877746386 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark08(67.85645363103461,-58.6861180433908,88.3203369697921 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark08(67.87471264240973,-75.97019461389688,51.68388294635833 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark08(-67.89156657094706,0.7814455622539697,-57.09604222347749 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark08(-6.807141980383754,13.241265527971768,6.185567952636465 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark08(-68.16520245393767,-52.304482358654944,69.33815371725362 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark08(68.23952175441154,-126.52966603798092,-22.647575933724895 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark08(-68.27299405079735,35.97708355264536,30.72511417135709 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark08(-68.31911288215747,-20.082591258977445,85.81200193137016 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark08(-68.36608232604348,61.02848253081887,81.86297786398057 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark08(68.37854546353373,-95.90464698008878,25.955305189760168 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark08(-6.845776280850599,-92.96513817922644,-80.66051341632071 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark08(68.58465419805786,-91.75404100015366,23.1693868020958 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark08(-68.58995239642731,95.25332010179096,-13.802766634272004 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark08(-68.63262907552834,-20.514007083267895,-20.18811281388875 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark08(-68.72210839565994,69.83709128823365,34.86936018003979 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark08(-68.76894618683582,-58.83538892633444,67.00222597546511 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark08(-68.78557974674145,100.15173478239507,1.5172777220363783E-6 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark08(6.879283965095814,33.9159369254631,89.0101313625495 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark08(68.82091438237777,-257.1786176695942,-187.45246276444192 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark08(68.87722831020943,-220.1655381943298,-230.8352375628365 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark08(-68.99755001591265,-45.70249996545124,-70.97789171999727 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark08(69.0470171442422,-100.0,44.946675122411364 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark08(69.15099599894668,67.31926335865006,29.04917113091389 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark08(69.23605796131477,-92.47830112782805,23.180348709087873 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark08(-69.33645713336179,-231.81474159814843,-274.71628672617953 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark08(-69.36371667865319,-63.85693917463953,4.510540519596063 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark08(-6.94014359271921,-85.734197991966,90.66150312488523 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark08(69.41517825367171,-39.90067837619474,98.86778244668119 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark08(-69.42305496235733,1.3795228599126046,15.95393538026811 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark08(69.42306283107922,38.374260451321504,73.04598987002154 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark08(-69.42388387010402,-78.53804576197751,24.21129669819773 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark08(-69.46368105546624,-11.857042717625646,38.691101808318486 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark08(-69.46809308682364,91.7976861854099,-23.90038942538115 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark08(-69.46848396768817,92.30395300060401,-22.49603204081331 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark08(-69.52292263953198,-15.626719251925778,-18.759007638085222 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark08(-69.56315480798791,-49.98197865814501,64.18174642171809 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark08(-69.60789304544856,63.45778785440719,-0.09707441021013907 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark08(-69.64072867594062,-43.6270720419432,-25.690319184619725 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark08(-69.7010039659375,3.543824252058242,0.0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark08(69.79353993963957,80.88746972901126,-1.19569229200971 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark08(-69.86497420933928,35.13490043768596,-43.57772098018052 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark08(-69.9343980338166,-78.40389822721403,-76.22868443883814 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark08(69.99136864659499,-221.31315165802846,-231.25790211821516 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark08(-7.001172719393198,-5.496360001918176,12.497532721311375 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark08(70.01233954300758,-78.0498324929652,53.93735364309236 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark08(-7.011438799496693,-12.747905204664178,-44.95933048102354 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark08(7.017371369760384,-10.21466992456032,2.1935705869554076 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark08(-7.041857602030523,-0.8951939925695818,2.290015369841757 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark08(-70.51260167661573,3.8088940796794475,17.33281391093614 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark08(-7.062995161690763,0.0,-20.499678146870163 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark08(-70.77269941231955,-0.23673004345321513,46.92607646538103 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark08(-70.84106819863304,-85.96895837786865,68.4987983459891 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark08(-71.00735744369827,83.13856702241252,5.277468008849624 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark08(71.03646158255509,-57.34009053723008,100.0 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark08(7.106754155528361E-5,41.203920277953486,88.8635448106685 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark08(-71.08110694851366,1.5182270798270077,47.441351460464915 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark08(-71.25900754545452,100.0,-12.329683830425214 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark08(7.131000907107964,-21.030959199461506,-19.104757542866565 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark08(-71.64267377500076,-53.63973048133934,81.02180254013919 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark08(-71.65354248184357,100.0,-13.389831118735833 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark08(-71.67519140432486,47.25907799061264,47.555794451257896 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark08(-71.78195794124069,-27.313976792685885,-48.55906845337477 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark08(-7.184775364848311,25.943047506955345,30.33176891936576 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark08(71.88986328397878,-69.7453000358346,76.5838262355656 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark08(-7.21386173831952,-86.57044849824563,-30.308599580271313 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark08(-7.219883712385581,-6.261177664432726,-32.638955583390015 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark08(-72.31332521866105,152.0663309953726,88.15221556163249 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark08(72.37148455331675,-94.6305695934098,27.908350363911715 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark08(-72.38958935427524,-93.5447978665211,5.692681795100384 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark08(-7.2445155296943105,-1.778206999588062E-161,-21.271449352048894 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark08(-7.247535904753023E-13,42.279894711242946,81.40055044221744 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark08(7.259378008568794,19.733318903489533,99.99568275443755 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark08(7.2632554868721195,-21.965632875351986,-27.283091944810177 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark08(-7.286188252618309,70.39043637420475,100.0 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark08(-72.86525680964321,51.22825693422439,-88.08314135441483 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark08(-73.05589461949813,9.470530634429341,8.570782655177618 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark08(73.10877058225672,-81.16960585452686,73.36502650428703 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark08(-73.16750356136043,3.6161552616361026,-22.522163584482072 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark08(73.33839501456248,-67.07583787465371,1.0824854498893899 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark08(7.339617357878076,7.400488995576097,38.37575772246456 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark08(-73.427254364339,-81.56034653690192,-18.07086163283016 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark08(73.51093640239739,-106.22771732152493,1.3649819805739063 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark08(-73.51229083297595,127.31252465122074,-19.4376370618448 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark08(73.51958071088312,-75.13602405968462,70.28669401328014 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark08(7.367156509847083,-80.7247303162594,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark08(-7.368989267909756,36.699946609998555,51.29292541626785 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark08(-73.71355251798049,-25.529963067236178,55.96012824621437 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark08(-73.78857812802606,-45.69352428058007,-66.25809149684459 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark08(-73.81340591940302,-0.609687965063434,5.040602709014047 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark08(-73.82266149673097,-68.89227373333213,-9.580531508888157E-4 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark08(-73.91609324535722,4.391278246031271,19.543975157743102 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark08(74.01050921897976,13.166593750822429,85.67262111491743 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark08(74.14104613056563,-89.74539495632112,44.50314480584951 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark08(7.4196160535164495,-51.902856547777,-82.44396329124501 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark08(-74.43101325334025,-81.21024402861346,-7.487318248777257 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark08(-74.51321044901343,-20.267814090623986,-61.64375559895402 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark08(-74.55971755030528,-79.43803239039113,77.32195996026604 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark08(74.60730091830109,-100.0,23.821902754904013 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark08(74.63871965517981,-93.64314535820387,36.62986860783258 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark08(-7.467403675491164,-87.45304801950607,85.6517335519917 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark08(-74.80407038207596,-53.470611179102875,-34.80537941958811 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark08(74.90570381918116,96.18898498179703,68.21163884553195 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark08(-7.49182389296476,-60.90990955860566,-100.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark08(-74.94655170485329,-57.43299721708218,70.09712277039239 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark08(-74.94964746224238,75.6188301723181,84.00072305534727 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark08(-75.04287362432581,99.99935600920891,-23.559112527764707 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark08(-75.07951192971802,-16.872617974443443,-37.598457238080684 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark08(-75.20257344708875,-91.61993674409217,-75.7187538037543 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark08(75.27099526490058,-100.0,24.729009817822185 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark08(-75.27142023896711,51.02061327499641,-33.355130553888344 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark08(-75.4140664669386,6.659355521565544,-24.071346011666133 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark08(75.42942931290531,-79.39022984930699,69.07862260754112 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark08(75.56913758769493,-81.02447837317084,66.05323978460088 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark08(-75.58076727677641,-47.70077672889601,-32.59947223610999 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark08(-7.558407373536857,2.1904248586656188,-5.097721702159208 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark08(-75.68956999476553,67.30219455913692,-90.89352453924819 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark08(-75.72112801469413,-0.7994427535210775,-70.26888442734767 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark08(-75.81014470555533,-14.343563968166649,90.15370867372198 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark08(-75.84044028363158,-31.071059418614794,69.32018452059162 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark08(-75.8526168247824,-47.66618628903054,43.08163304878956 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark08(75.92740606904839,-54.280159974097856,207.54109657075963 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark08(-75.93909907865999,17.602370167728907,16.543752911582242 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark08(7.595673278778752,12.405602008968131,49.11571621623357 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark08(-75.98215008231298,26.843774639930576,20.66950537220871 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark08(7.599064468822548,-28.203487697431008,68.11764091729252 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark08(-76.14024344449932,47.96838365292007,-76.47022521944986 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark08(-76.29063526573992,-11.456683098669586,19.154268009654757 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark08(76.30853971645865,-101.54988478584646,26.358422592393865 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark08(-76.35985302045425,-11.796364503803858,15.527678438589092 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark08(-76.3712382409313,-51.32930923948644,126.99942669017443 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark08(76.56747272418416,-89.41385674175659,51.15303285062046 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark08(-76.73301277496385,-17.056742244501535,38.758376133210305 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark08(-76.75289784669565,-0.0022858596781496487,8.953143155637548 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark08(-76.81596997473493,-0.006052791382984424,-3.3784123226132294 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark08(76.87857976657025,-100.0,32.03779061917686 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark08(-77.0366966649257,1.8142987182490429,75.19813050758256 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark08(-77.05260918304394,100.0,-24.133962194952606 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark08(77.0609862332124,-100.0,24.43566020973471 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark08(-77.17438594090146,40.09960966567881,32.18465313266712 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark08(-77.2192962394827,-37.62316980598122,71.15555962536612 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark08(77.25642447036229,-86.84459684023004,59.650876057421684 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark08(-77.26378621081344,74.0366359251388,4.797946612469535 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark08(-77.30368771015,-35.750124519232315,-51.06407766210437 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark08(-77.46733125236577,90.33032298306543,-12.862991730699678 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark08(-77.47884047705396,51.512119349665234,-97.50611380624002 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark08(-77.65317277129813,-21.533768718541058,1.5134285887802434 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark08(-77.73118180657053,-122.42876385216617,-370.47853388328025 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark08(-78.14635038503882,-2.9621801535962815,30.895545154695412 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark08(-78.17442247769534,-40.332142452472645,-100.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark08(7.828589496779836,0.8601923024250542,25.89194798131742 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark08(7.842894120965605,-100.0,100.0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark08(7.843670826930648,-8.312799629063889,95.00096442562707 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark08(-78.65266945608735,111.67769299419614,-37.73536360858836 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark08(78.7107104550423,-69.7162909533937,97.87342677529543 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark08(78.73500193891358,-99.75454444614854,36.77618417591333 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark08(78.74486802557291,-78.34118544353562,72.83859528720413 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark08(-7.877253464073547,-34.33064896651143,40.63885583595208 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark08(-78.82875662013585,119.0788261505651,5.269392790135463 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark08(-7.887902504692228,-41.85083776477626,49.738780995295365 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark08(-78.98460216348845,67.46350258353388,-63.25596130865154 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark08(-79.02345589394046,93.2801809382258,-12.685928717490448 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark08(79.10746222767739,-71.77126195940124,95.35065909102457 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark08(7.912090409571045,15.050359428291124,54.10289242946828 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark08(-79.16045058365758,108.6258608096752,68.30058306332346 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark08(-79.24081163524228,-49.99759589031938,-77.50460277122471 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark08(-79.26608435081413,16.132433148339814,-48.39117544821394 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark08(-7.926705231406959,2.2737367544323206E-13,-22.266289842387817 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark08(7.929185548623096,-39.921066793753226,-69.87481621124715 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark08(79.41156093787849,-74.77255022875829,-1.6853446359594182 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark08(-79.47513641766189,74.49025059116896,-88.56464897322502 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark08(79.7091097011318,-61.20739592198505,155.65578687338808 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark08(7.983121324929943,-0.009366103673478676,21.008168241567887 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark08(-79.87194933887201,40.358979662635846,-1.791269444692361 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark08(-80.05035645913783,29.952953513644502,34.10063527658588 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark08(-80.16037270704504,-19.25652649702458,-13.557643989173055 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark08(-80.26746315908285,-292.52668156890894,-140.86424340279976 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark08(-80.30561597546786,58.86946626160224,-40.3320640214071 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark08(-80.39313746990064,-7.746864325571461E-14,80.39039179283206 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark08(-8.051825663738056,0.8153405615568217,3.1137829331607083 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark08(-80.57116923267186,26.78176404682399,89.6005677816444 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark08(-8.060607005794571,-15.551490522936943,-54.92795899321101 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark08(8.07211405493071,-10.767516609905137,2.69782591809488 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark08(-8.07477360683392,-142.55703831464638,30.003597944751178 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark08(-80.7616525761382,7.18116753197451E-4,-27.08442472713722 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark08(-80.7898366794041,13.904851739315635,-100.0 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark08(8.090587282109308E-4,-16.27984102470661,-32.548331040500216 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark08(-80.91128655856558,39.50391596053787,0.7197743099955516 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark08(-8.098092871299594,-97.63514386891029,-17.99907778242886 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark08(-81.46668272799418,-1.1737850362691324,100.0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark08(-81.48445849239022,3.4139684285963144E-13,-5.42436148524003 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark08(-81.4947627681992,56.78464151505841,99.79090881227202 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark08(-81.55834193671798,49.41680313999799,-100.6000700833933 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark08(-81.69029576153318,-85.44752453051164,11.806277670612433 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark08(-81.70091721834332,-20.857669562508153,47.20377207332851 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark08(81.75302816418959,-96.7142767336674,53.40132735202883 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark08(8.175590233537651,-59.05617103762264,32.58438984956146 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark08(-81.78166516190926,77.38665564610984,-90.57168419350808 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark08(-81.84953314833987,32.08793072342843,-98.79348688548902 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark08(-81.93131370699442,-100.0,76.91995902542868 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark08(-81.95007233507535,6.16173373598606,75.77063550636527 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark08(-81.988258150264,59.09383253649411,17.059935589961757 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark08(-82.2242157132338,61.287454769320114,-92.37249957382924 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark08(-82.2344289113945,48.486262493584064,64.44982468186555 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark08(-82.25107077461949,40.008214015006644,-8.201461253632496 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark08(-82.33991183480171,-59.263982640335215,25.364966292314577 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark08(-82.3622683823066,75.80965186551859,3.469446951953614E-18 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark08(8.241127300889499,-9.721693891302614,17.892270454121306 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark08(-8.253592166522823,10.962930832626476,-2.6950895132533637 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark08(-82.5809752165753,-53.1146035304282,-8.259987396590887 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark08(-8.259998884662444,10.150151684247167,-2.9088969586981053 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark08(82.69721466344521,-96.90657744943917,54.26995768090436 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark08(-82.7232089856292,4.388678181012307,19.93818163037014 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark08(8.277259116537024,19.896519226450526,66.19561212930701 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark08(82.79332301764441,-95.50794374106846,58.934877897591015 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark08(-8.28667810150896,-0.8819795234875016,2.3642809072344138 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark08(8.288944799398415,-12.00285237212578,2.4319259807385794 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark08(-8.292913222784541,3.780952988874663,-16.065775663878142 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark08(83.09169339399392,-169.64128817706296,-87.27560105425952 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark08(-8.319114972189798,36.74498874202929,48.92723037474012 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark08(83.21800589436266,-77.49377512082509,94.66646744143786 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark08(-83.27933357545358,20.792511316285516,62.486822259168065 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark08(-83.39549638189654,-32.111130236776745,-65.10306437974674 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark08(-83.41342384398388,36.42539049433785,-57.28785836299247 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark08(-83.53518329861068,37.47097758951688,44.4934093822989 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark08(83.55549204513795,-320.2207431549814,-187.91586880688996 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark08(83.57971878999076,-91.13168972306215,68.8368192337328 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark08(-83.63340434459448,100.0,-17.937391982200413 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark08(-8.37023112515267,-16.717640325916335,-58.16433386971934 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark08(-83.90182171209162,79.20708038450057,32.84801207315524 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark08(-83.96703338757621,-87.82433003370213,32.671952158585526 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark08(-83.99526845596687,-48.47166783379482,100.0 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark08(-84.00587539215422,-51.9899825468197,-71.84289757160546 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark08(-84.11523014866985,17.342935364651108,65.20149845722385 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark08(-84.19391933003205,3.34591735103724,-0.24146215730528015 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark08(84.20329868588655,0.8962660841099819,-58.72883673268805 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark08(-84.2221905871124,-43.25039404085927,0.23808459147897815 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark08(84.2777059600888,-58.910974900713384,52.48075363277846 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark08(-8.449096379743803,-44.40334259337593,99.99671240261824 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark08(-84.52245447572813,51.735235435892,32.30231737985944 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark08(84.58224650634796,-56.53008197869725,134.08148092072128 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark08(-84.6352952680032,77.53946620684059,-4.412674786356973 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark08(-84.6840709643963,99.94485481389994,-15.26078384950363 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark08(8.470329472543003E-22,-99.55182669911365,-22.976642045999895 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark08(-84.73038164303341,42.467565272438186,52.14656218118671 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark08(8.483825862420051,-51.176133718247506,30.503519923020747 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark08(-85.22354475587925,8.234193923419346,38.27863920235063 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark08(8.52836714626983,7.5540526904214245,42.26400314644723 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark08(-85.29544922817507,44.80029926504946,-39.060442482482756 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark08(-85.32057832486039,27.217060571225364,-44.08619655980704 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark08(85.34620854376824,-100.0,56.254970813090154 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark08(-85.46861020208873,93.06254529223013,25.39278778256255 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark08(-8.5538968008742,62.647139585705105,99.99999999999989 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark08(-85.60144882403542,100.0,-11.476168352079455 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark08(-85.67914602237514,80.88978077782879,2.2664142868012663E-4 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark08(-85.70363448703941,27.523816152139574,-100.0 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark08(85.78202579017304,-80.0223863188582,99.07517902952033 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark08(-85.8175849014307,-11.722767650647171,-67.24229568823989 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark08(8.588429325534237,33.551270297108815,94.43862489761523 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark08(-85.95825011439477,-144.55470769115493,-332.36242739623935 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark08(-85.97165865073319,98.75499338624644,-15.263905905697058 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark08(-86.19524921685392,-4.040756439756122,78.91107491058426 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark08(-86.24502880097333,86.56388601970829,-85.60731436350339 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark08(-8.631260582588856,-0.005645849908333923,-32.23415724289716 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark08(-86.36290800229608,-4.831105530248877,15.525388393666699 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark08(8.64238975054998,-23.42495428477307,24.22054410360957 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark08(-8.644595948207332,23.684073783578253,23.005156049329404 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark08(8.665405851176448,-55.0345044928089,-82.50199510529356 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark08(86.95705570659928,-149.1924588440594,6.915141311010827 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark08(-87.01670755635848,62.32658573770766,-73.14419557219667 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark08(87.09544112227073,-39.82598013601719,219.38761182602153 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark08(8.711847279796181,-23.83287534197879,10.979435385901072 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark08(-87.13927020297919,56.589005846365076,-109.49816287082581 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark08(8.726759716383015,98.79291323539968,2.926653352520887 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark08(-87.3425615530449,-51.07141172792323,-24.071012590246216 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark08(-87.58549289876079,67.04916242337214,-26.105564780837923 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark08(-87.90162456108465,-92.17984867632394,-51.14818294170467 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark08(-87.9719343333361,9.039283602152391,100.0 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark08(-87.9745916565123,-75.08767635009028,-4.1933276977075025 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark08(-87.98482141995217,4.538059890600204,22.75651191084973 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark08(-8.799527278973727,18.06009864921873,11.276688875685243 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark08(8.814089351150926,-69.80805371946055,-10.236302216088404 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark08(8.822569536735235,-7.470409934981826,11.526888740242054 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark08(88.33663872108798,-93.85913682022576,1.316257743306224 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark08(-8.837851622595736,-70.91400803810916,114.89369954173478 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark08(-88.40844646282198,95.15978713863524,-67.44442639165878 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark08(88.6281801340241,-88.93387712418598,89.58758248049526 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark08(-88.62868951872773,0.5368598928837796,-11.918338711881088 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark08(-8.874057405760324,-2.812267562879006,-30.850175854830447 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark08(-88.84287945390864,-53.3044188002001,23.95953592986524 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark08(-89.03744364660409,-89.95927195540973,-19.709150242487944 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark08(-89.11451995991844,51.43667011446223,-19.411579733465473 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark08(-89.18118591435477,-19.44951519651343,-80.00391164315565 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark08(-89.29917252694462,99.6519253125064,95.2302390873128 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark08(8.936848205963898,-27.50004811741772,3.530807444098663 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark08(89.39667123820145,-98.55284884230849,71.17114430954575 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark08(89.51368981481417,-95.29829859082098,78.04125008045717 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark08(-89.54665629047209,147.32215097139468,39.71122541033567 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark08(-89.64810663973368,24.970835488586403,64.00611487401848 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark08(-89.67293450851193,-58.83927147234851,71.7983234546709 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark08(89.73965108948511,58.842196184586385,32.429508984579826 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark08(-89.74638146297444,0.0,27.387608966219858 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark08(-89.88722866280912,-11.6881072154737,52.72779913362583 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark08(89.90566911896428,-215.5682596165469,128.82391260586306 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark08(89.93202170617322,-88.88003785081756,93.60678574367944 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark08(-89.99395626289237,-83.25047367334926,53.940207957918744 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark08(-90.03391690178964,38.44359067881916,21.724459441912256 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark08(-9.009171532947077,11.947659573969103,-1.5613991241081278 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark08(-9.031717765587596,-90.06541007962375,-80.46526573631347 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark08(90.36263858230765,-6.483192300236766,-6.8959800758352685 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark08(90.436111175853,-93.766670868039,85.28495873975591 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark08(-90.44193110068777,-77.1099691825222,-29.351251771942316 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark08(9.052874507799583,-33.50484759209154,-38.28027533398944 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark08(90.55506637533385,-86.61799772639822,100.0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark08(-90.75307714283605,47.946930181855436,44.784761553760866 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark08(9.106309717526251,-11.618147514436703,4.082634123705349 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark08(-91.09423294028302,93.46759963578853,15.316240705538348 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark08(-91.16374896986991,-12.495023408356992,35.84025052812876 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark08(-9.118074175875238,0.002630136797283087,25.508276065845465 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark08(-91.18861946069596,33.3888063756055,57.57872478459253 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark08(-91.31954031313545,-131.16285228752963,-20.932501331727288 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark08(-91.35395386402685,8.388866657403256,-50.908003754903206 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark08(-91.40326624242266,121.8180229741111,-29.622761605972997 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark08(-9.150415114152672,-5.649862313563263,11.519843375066884 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark08(-91.51044140315598,-221.45461511786448,220.23299547373628 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark08(-91.60212655830438,-58.526683550386636,16.986946787979562 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark08(91.62943528880841,-91.20916792434005,94.04071826864435 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark08(91.73112708336892,-89.76448683183196,96.73181700980702 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark08(-91.76512727575536,-76.27475903026027,74.90967424061387 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark08(-91.78299030760475,41.61511354945257,-72.69152680288835 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark08(-9.192653153899166E-5,-144.23028846876085,-118.46818907975829 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark08(-9.206641941428328,-23.807051874222882,1.7171433326336398 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark08(-9.211245281281041,-68.26218941932125,55.780478730152936 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark08(-9.225502113077281,11.386756450691745,-3.7320506644093614 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark08(-9.231766692526044,7.995159515108952,9.817442175114252 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark08(-92.34711296356106,10.714357790687501,91.48675604841691 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark08(-92.71163848012682,11.183522989855563,1.975387961200302 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark08(-92.86993210064726,-72.03639902791691,-26.421099952477746 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark08(-9.290602173584984,13.148282431720688,-0.004445330518681409 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark08(-92.91261247332727,18.934317356605387,73.97829511672188 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark08(-93.03020484052966,77.70019684077174,34.69795051374846 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark08(-93.05433390437472,88.79610269316461,-100.0 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark08(-9.315867026420504,11.905101400158124,-2.6060414581655182 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark08(-93.24255750192638,-153.80911732836267,-234.44368230143863 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark08(-93.41275418036483,-17.490154747340853,-51.15123623830864 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark08(-93.47107674305236,-11.17212393472885,56.372669585629204 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark08(-93.47457287276237,58.56027180064623,1.48385343007719 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark08(-93.47844815838077,-26.211479907977676,13.644290597311661 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark08(-93.48367873448164,53.75911184670158,-90.15232776715112 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark08(-9.349714582585566,-2.3733829623069838,-31.225113345575775 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark08(9.354224686327498,-23.544715895411656,69.39021770666116 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark08(-93.59329306280917,-136.80316242094358,3.905072615644282E-5 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark08(-93.61566419353953,-51.375764414859695,-3.3866945201974374 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark08(9.363352709384397E-97,-7.665247369407607E-7,0.9824477513026901 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark08(93.66956136880246,-90.8318213411608,100.0 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark08(-93.69035121240208,-69.53315235818859,51.72482938948522 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark08(-9.373264580899892,37.496649172143435,-28.123384591243543 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark08(-93.82174068073493,55.88470176613952,-100.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark08(-94.12134919373332,-73.27479423128327,-89.30373048799323 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark08(94.21194693484404,-76.9146930532539,128.82027379778683 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark08(-94.25599171415647,150.0773987071566,-20.694729538672522 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark08(-94.59392216093552,-6.938830306119412,-52.467787558845025 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark08(-94.6312659812771,-44.43888176541412,87.2752994754702 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark08(-94.67782472789285,-227.51917799094164,165.82855802052043 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark08(94.8653171831755,32.602834280478135,42.45774750492285 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark08(-94.93743650855815,-13.127838286727638,62.92513613777626 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark08(-94.9634371463708,-52.61867656617383,-12.63911162244763 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark08(-95.00240258922636,-201.41012538926861,173.60468625431344 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark08(-95.05868704431836,-37.90485644533595,-2.7090155327787286 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark08(95.05877793887916,-1.9944572677390795,58.53887706308248 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark08(95.06213404588334,-99.6897114556074,87.37777555322975 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark08(-9.514621839833458,41.0447755117448,53.55275887758452 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark08(-95.31167470731938,97.69075271814044,-88.98273170891602 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark08(-95.33298828379941,73.78312946204218,82.48370824521699 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark08(-95.3736504719378,84.37255820697038,-78.51765863305882 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark08(-95.40599727411046,-70.70569427091411,-0.8283645312441053 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark08(-95.6458201610561,8.078049773899536,-0.21070308995704012 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark08(-95.65711866052968,95.21479238357861,-51.11800682383681 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark08(9.596478540561665E-4,28.245842487656233,57.95000097405033 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark08(-96.00279989635582,21.38424901852037,-25.183519164018108 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark08(-9.604934868290663,-64.39661112977389,12.943190292416617 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark08(-96.2791128653123,49.717317716192845,37.17578802890874 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark08(-96.44405106337389,-315.128361046166,118.21075754904746 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark08(-96.45279393763825,-140.6881083904733,-318.99511112329714 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark08(-96.49998072208366,-91.4340756426815,-5.6667555940341436E-5 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark08(9.656104218309864,-42.18472299995528,-55.401133344980956 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark08(-96.67518014183419,53.02844296169654,43.64673718013765 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark08(-96.68281700680794,-44.65852674782159,-95.50685600252137 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark08(-96.7339404377169,132.36550632173098,-32.64966956202416 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark08(-96.80571370869416,68.57389607303716,11.238040960665941 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark08(-96.97158494171975,-0.069082206424742,-80.94607158062004 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark08(97.16405592113786,-98.4181105617585,95.30020059836295 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark08(-9.718923295276001,-27.10856879280587,-55.43002318405226 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark08(-9.728976898418757,-25.250786113395407,-41.98925725811095 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark08(-97.30350238033967,-238.06630143629,130.70650720794845 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark08(-97.39629955480606,96.8749552117681,2.0921406698328693 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark08(-97.44379632382372,117.58348841069643,-12.81078793613593 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark08(-97.65879628032658,-1.5632367736690638,100.0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark08(-97.74608263206675,-63.46193148402766,21.931476984401385 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark08(97.74915093357137,-174.5235820563856,-23.21537280190718 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark08(-9.7830309130026,38.56025875815451,-28.777227845151913 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark08(-97.88242989122831,-229.83693750474853,183.52377054425855 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark08(-97.88466877247805,10.354003637753113,9.988750010123312 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark08(-97.91151579170216,98.70572228494655,5.7522413549977784 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark08(-97.9451530346152,57.39493783387966,-46.79024245012605 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark08(97.94869500332052,-20.93244630478877,25.980867101624597 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark08(9.816060403795591,-17.77184630853357,7.955785904737973 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark08(98.24348740267094,-100.68844374560695,92.33524918133524 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark08(-98.25368444648237,49.55733184908439,-12.385888972267699 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark08(-98.3400587641974,-12.81967392161931,-12.582870633000535 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark08(-98.4310375172841,66.62348237438101,8.89016762663129 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark08(-9.849163036739268,4.31878852477518,16.85898341422836 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark08(-9.854764332708822,0.0,9.382369590377301 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark08(-98.68481106768212,-156.81382669296926,-282.62211667942455 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark08(98.79655204116794,-100.70788766679054,96.40272160451738 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark08(98.81089555075798,-182.2749584273808,-74.83025922091743 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark08(-98.83530938886645,-145.91190544424137,3.504204476235273 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark08(98.90715807668114,-98.99743817116712,99.03765609867871 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark08(-98.91419136286304,57.169215480477256,45.29214051407467 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark08(9.893978733595674,-84.55884823960508,24.250355524900954 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark08(98.96130657204921,-99.98171392293142,99.27683812858096 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark08(-98.98405645764845,-100.0,-56.372252592363424 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark08(-99.00597833903129,-40.44510322412207,-100.0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark08(-99.2654000198544,-57.66386444883666,-16.559803048986936 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark08(-99.34684248878244,-175.20959762349233,-251.4333492635099 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark08(-99.37583378593042,99.99999999999999,-98.7799128341807 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark08(-99.3854244969897,-36.4210132668571,-87.69067361927458 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark08(-99.44231701143269,-39.69197529906923,87.6027909490208 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark08(-99.48951692831915,99.08670041959418,-98.72435361897418 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark08(-99.52985350617787,-6.477783585815155,90.74541327225393 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark08(-99.61449295568832,6.0989595504583605,34.398592402697545 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark08(99.77457677342547,-100.02992781221577,31.83365265970572 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark08(-99.81729350866982,100.0,-91.91252126943169 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark08(-99.8292874193756,-15.334295510873755,-52.78668254147953 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark08(-99.86653770620589,72.5780771659278,-90.52387361234769 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark08(-99.94283283192118,-42.06509816373929,75.06463755997115 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark08(99.96310837003647,-100.0,77.26471668254388 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark08(-99.97490123623491,99.88554334130694,-100.0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark08(99.9866839906884,-99.99999999695484,100.0 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark08(99.99645642577737,-100.0,100.0 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark08(99.99993864459337,-99.99999999857152,99.99981593663708 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark08(99.99999957915657,-99.99999940261158,100.0 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark08(-99.99999999999996,4.440892098500626E-16,97.05637882971712 ) ;
  }
}
