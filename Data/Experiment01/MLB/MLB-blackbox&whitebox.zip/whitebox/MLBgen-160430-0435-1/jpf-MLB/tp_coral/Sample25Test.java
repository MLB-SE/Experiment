import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(-0.0010435269087174168,12.955197235417254,36.09310159031092,6.3488708321132785,-71.61845098708703 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(0.001668133673155183,0.7897791283453383,-16.463607803459126,-0.2561436099965947,-83.2609672500253 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-0.0018784864827506177,-42.46344374514178,82.52229634969831,-21.459683705053674,83.35609116348867 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(0.002285589278657915,-43.12395608679867,-2.2400553483132817,-22.24713747815739,20.77736115284857 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(0.002424297835547373,-6.20967094233167,-3.5047186734047955,-3.159784117843649,-27.610261395776874 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(0.002550729726256311,-76.90771224114988,20.614511573910892,-39.239254283972386,-27.60529165065158 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-0.004312733096681813,-5.574704938821571,0.005435215806501185,-3.2705816115196833,11.149152228201444 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(0.00431964079280877,-45.18431234450138,-363.64049655303285,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-0.005092978313436592,66.07308064130558,83.65641276469628,32.93396409512205,16.533594574377062 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(-0.005347979728076879,-77.16022727618369,0.0026739889232807457,-39.228111526100925,13.044719514728667 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark25(0.005486630617804199,-104.02588491124783,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark25(-0.006785230374247987,17.02720127577932,231.50216616330954,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark25(-0.009210564519345796,-33.12788708216569,24.018863452889832,-17.34630659058111,-29.88399907885525 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark25(0.014469992574707569,-13.540907188541894,-20.289307182890596,-6.778141991579741,-61.82925653693925 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark25(0.016812600406535247,11.872446008199239,0.7769918631941807,5.877132671358841,-31.897966570185318 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark25(0.018326700928385994,-27.860740462243243,-1.7235699427550262,-14.459530720493657,47.73805642450603 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark25(0.0190922585882123,-29.894362076462176,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark25(-0.01938986176764979,-27.63412859809131,0.7950930942812731,-14.602462462443102,28.44473084289612 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark25(-0.020525318211351617,3.552713678800501E-15,3.552713678800501E-15,-28.61806739919281,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark25(-0.020882423081896917,25.14723844844829,11.125474710737219,-87.20192445603088,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark25(0.025360681480207543,-0.06746649520743987,-6.317264477042953,-23.97171402195059,0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark25(0.029940656067898662,-0.19554046635844863,-2.721845157558324,-0.44192504326278736,-2.022945071063134 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark25(0.033920562933396126,-1.6226003596440108,-46.308085448911605,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark25(-0.0346581539308127,-22.852774814094357,1.7763568394002505E-15,-11.468570544831271,-69.11114257293924 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark25(-0.03495081742311257,-51.6008995636801,16.102081789472145,-26.55540252227881,103.20613171473397 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark25(0.038907465251815765,-13.37631588176523,-26.86501712636255,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark25(-0.048085378596173456,4.272390035344763,6.316188480760926,1.5209821400717671,-1240.8592023123852 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark25(0.05128067754302307,8.365199100982903,-10.231568950287155,3.967302172116822,-100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark25(0.0844965702365721,-2.153977321091176,-0.1441227905555883,-1.8623868239430337,-74.05268419088912 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark25(-0.1442977124091308,2.4600685144607026,-1.1102230246251565E-15,0.4518130334538054,-6.490933355716302 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark25(0.19537075874245652,-1.5543122344752192E-15,-3.1093244547623695,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark25(0.25332312603637325,-0.3783489474565198,-2.8421709430404007E-14,-0.20767194625937696,-0.8140984318818569 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark25(0.26674672251489895,-5.888718376688431,0,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark25(-0.2738817114575909,3.552713678800501E-15,7.053648694246624E-5,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark25(0.4358167662202121,-1.3093801410019588,0,0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark25(0.5387884044964435,-0.47618766954085057,-0.06366489261349295,-0.9676674323545177,-68.39525415025011 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark25(-0.9419994943221894,0.08072209824535553,26.81167671318461,0,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark25(1.014122139589675E-15,-26.345790067961914,10.210176124166829,-13.473702416882588,-62.39935441109575 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark25(-1.0184803421185174E-15,36.27381269739824,29.712546534569892,17.351508185301675,-74.11842172159137 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark25(1062.0780222763753,-4.1281543855128166E-12,-1110.968939315035,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark25(1.0658141036470148E-14,-10.364005453001933,-46.02863602520096,-5.763871947665965,-95.50828743617963 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark25(-107.63559712777591,-0.1414594889293257,2432.386323003083,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark25(10.781614528215172,-0.017149634747039413,-1.2338431108024626E-5,-0.7602518540282337,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark25(10.785171711385441,23.591221060203942,-0.0031114026158764237,11.010212366704524,-49.11426420358751 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark25(-1.1102230246251565E-15,17.876474520008514,0,0,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark25(-1.1102230246251565E-16,50.63027756781307,0,0,0 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark25(1.1102230246251565E-16,-56.85867702084987,-40.92707459743819,0,0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark25(1.1327652415818363,-0.3670412547358559,-0.0017758747279725921,-2053.5221326318706,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark25(120.24327397301373,-0.004747009155808846,0,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark25(-1.2548563529580824E-8,23.82932895321497,-0.01283638529561868,11.829336640167202,-49.229454233224835 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark25(1.2680582348716107E-4,-90.56677976479202,-15.414059879623672,-45.636417147943604,72.56175023046403 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark25(1.2773179304863686E-17,-6.867374146111143,11.74812355312908,0,0 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark25(1362.3334586920168,-1312.1009328661596,0,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark25(1.3870215891782353E-14,36.01359051635969,-83.09004426031609,17.82717578871731,-117.46939116115753 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark25(-1.3877787807814457E-17,5.26703306566994,5.124143988955979,0,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark25(1.412316677638567E-5,-49.871792579145676,-68.19083993451206,-25.652736721895998,98.17278883149646 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark25(1412.4776298321476,-1306.7381248599904,0,0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark25(-1.4205748371768578,1.1057469734692518,0,0,0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark25(-1.4210854715202004E-14,81.85142549678233,38.03643366553911,40.85834304224353,-163.69726687968924 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark25(14.212165656936477,-0.01011384208606361,-1.692336492395911E-15,-0.1752427830903716,-20.98073389624973 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark25(14.31820225385795,-8.204394248597426E-14,0,0,0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark25(1.4710455076283324E-14,-38.18019011905446,-70.13539670896567,-19.871884441709426,-9.039347781337547 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark25(1.5571426077747762E-4,-0.03628172610781223,-100.0,-0.7853981633974243,-1.4982328745792721 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark25(15.592534778750732,-32.565434890878535,-24.569015762788467,4.863337838550223,0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark25(1.5987211554602254E-14,-24.255305959593514,-35.32765719380903,0,0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark25(1.6342482922482304E-13,-3.068437068189741,-65.21658733489248,-2.3196166974923185,-27.89314963951132 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark25(-1.6384066754625692E-15,-33.69703535122171,3.169822308099819,-17.097562935011194,-37.12325876438348 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark25(-1.6810434061480264E-6,30.421754320739876,-4.817479748453479E-12,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark25(1.7234372955668415E-4,3.083544656172709,-64.4855122636771,1.2148517547611621,-7.737885639140314 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark25(1.734723475976807E-18,-43.0352917329077,-57.712785676326185,-21.718959692758414,84.4997871390205 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark25(-1.734723475976807E-18,-76.91532845498848,63.999992692423746,-39.24306239089169,-100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark25(1.7763568394002505E-15,-0.050687288227291294,-0.05582322168343178,-0.8107418075110928,-1290.0507649279068 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark25(1.7763568394002505E-15,-5.163331632710879,-83.92179699558869,-79.82293481910963,0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark25(-1.7763568394002505E-15,65.6713430702266,58.296667142932534,37.66950424257689,0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark25(-1.7763568394002505E-15,77.91056018152186,33.91572848475414,-93.60433641043764,0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark25(1.7867877953787678E-4,-3.7476432419257653,-4.537264229846703,-1.8738216209628826,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark25(1.7992740378432928E-16,-18.871925266839582,-61.02583064462243,-9.547344664265026,-85.13861302357783 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark25(1.8025420129232002,-3.694822225952521E-13,-0.00772819377259952,-0.006868404401723267,7.389644451905042E-13 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark25(-1.8474111129762605E-13,-168.8060042715126,79.24686057303174,-85.15334221816794,29.713942412238914 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark25(-2.002096215543787,1.9468870959826745E-12,1.0390266987166683,0,0 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark25(-20.359400746929396,76.64012382674036,50.60530862519212,-12.41268267333544,85.73918172548383 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark25(-21.25471320434771,57.20544148647565,16.407947212434394,0,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark25(-2.131627190840764E-14,27.576262266652808,25.711553705764587,13.002732969928957,-99.07881257763188 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark25(-2.220446049250313E-16,34.41715807572166,0,0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark25(2.2365043150784913E-10,-8.420746490904017,9.797929056890094,-4.267660139730824,14.127355287786632 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark25(24.31073520002694,2.058448774019163,6.058011709815195E-4,0.06262898922325433,-49.963105660356234 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark25(2.521674214614112E-6,-57.90858742661816,-5.652051831167711,-28.971477058974283,-88.38898024064667 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark25(-2.5758596549547548,8.881784197001252E-16,2.1316282072803006E-14,-63.9101815515138,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark25(2.691518358655486,96.7502351369798,31.433283836477898,0,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark25(-2.7755575615628914E-17,10.901489880388134,42.253975861784085,5.450744940194063,0 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark25(-2.7755575615628914E-17,2.2704708286579316,8.355410928129789,0,0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark25(-2.798944870415653,1.7763568394002505E-15,0.0,0,0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark25(-2.8421709430404007E-14,59.39330520139029,2.347618461059909,29.494350717294125,-163.0822810638774 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark25(-28.54976593212415,9.947598300641403E-14,0.055019586869097206,0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark25(2.855391614240635,5.4499967061539865,-3.2002697549830014E-5,2.6945576354195757,-12.47078973910287 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark25(29.067539671596933,0.0,0,0,0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark25(2.949029909160572E-17,-2.6832925098508444,-99.95870827983077,0,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark25(-2.9709212426408864E-14,29.046743370131736,42.9335418859213,-35.47426012447259,0 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark25(3.014642287998588E-4,-51.968123351866225,-0.495866621359375,-26.764036012256547,-30.679044228178267 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark25(-3.081807389143654E-8,1.3618509275229402,17.56545548995163,0.5766347615680665,-55.442355823424975 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark25(31.18356771722901,-1.7763568394002505E-15,0,0,0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark25(-3.139964116705791E-14,-64.57491846313901,0.04541791370875861,-33.07285739496695,-49.92104658101026 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark25(3.1671202030957375E-15,-0.24381964892388552,-66.83973330061163,-0.9073079878593902,-1.0831570289471255 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark25(31.774947039859033,-5.17790255116779E-11,-2.3867416811674105E-14,-0.4315553296892496,-78.26084001328267 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark25(-3.226256616885422,43.890836283277025,0,0,0 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark25(-3.268496584496461E-13,1.6313863612723765,0,0,0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark25(-3.3306690738754696E-16,19.537973630658996,0,0,0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark25(-3.410605131648481E-13,9.479457195434184,38.265247580942614,4.7397287040829665,0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark25(-34.56738135480737,-40.81728960637838,-10.53702839288799,72.48356390487285,0 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark25(-3.469446951953614E-18,28.685727883939293,22.430639601383582,14.146042882797232,-57.37145576787859 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark25(-3.4747244972814506E-9,18.9063578187151,22.403384057982656,9.194936585223228,-64.89151158109044 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark25(-3.552713678800501E-15,-15.915098114242685,88.89536765562303,-8.163598898468502,4.900141990504984 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark25(-3.552713678800501E-15,1.8357446278377632,68.43894772359648,0,0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark25(-3.552713678800501E-15,4.647934280505169,0.4621439167607626,0,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark25(-3.552713678800501E-15,53.08358795019552,36.711883829320854,0,0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark25(3.552713678800501E-15,92.66123353377616,-40.21633005112478,46.33061676575566,0 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark25(3.5602249805212364E-14,28.699342790733038,-19.168720150911383,14.178318106284205,-42.969469720535315 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark25(3.5641077822670665E-13,-84.04636415136733,0.7853981633972751,-42.307178800268694,-16.71149805303086 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark25(-36.96386056746594,-43.30109487448293,59.06390747786244,45.64842371518756,-17.388242582932705 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark25(3.907985046680551E-14,-0.12098365297621926,0,0,0 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark25(39.62467685104539,-8.881784197001252E-16,0,0,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark25(41.43534438939083,-5.6843418860808015E-14,-1.7763568394002505E-15,-0.7853981633974749,-34.20416291026247 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark25(4.218124692159876,-3.552713678800501E-15,-43.21664635705322,0,0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark25(-4.263256414560601E-14,85.22558283550802,51.50739166073613,41.827393254356565,0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark25(-43.15582089755572,4.440892098500626E-16,62.51121650119276,0,0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark25(4.418163085818731,-0.0063207917127424944,-0.35553154020882227,0,0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark25(4.440892098500626E-16,15.760115667342742,-0.20403932772614208,7.494583919443521,-98.31065433701491 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark25(4.6938025607109216E-17,-63.45003152780225,-2.0684337409256006,-32.51041392729857,-89.8415978226769 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark25(47.964864202540326,-63.117283980550496,0,0,0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark25(-5.192967039021216,-0.15422516094149513,1.4210854715202004E-14,-1748.1972264599012,0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark25(5.205310070956885E-4,-40.31941094008566,-35.688318716525245,0,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark25(-5.2178542740328314E-5,95.14177196447677,8.289046E-317,0,0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark25(5.4018637748799395E-8,-43.523487711736514,-84.66147674543555,-21.762722451578263,72.25521491238459 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark25(-5.407979668742893E-15,-39.524632996285554,-0.10760729053181295,-20.31273863567041,-60.9298767283412 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark25(54.639400871718294,-56.55795669994177,0,0,0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark25(5.483619906136994E-4,-75.60848297073242,-85.03042028350653,-38.54368521330641,86.31482591888695 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark25(5.551115123125783E-16,-2.1533336822766236,-42.133836846407604,-1.215611280921369,-100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark25(5.551115123125783E-17,-69.90384713248977,-21.910302336443912,-34.9680263320571,47.44640158704212 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark25(55.534627980787235,-29.475490314853573,0,0,0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark25(-5.789603321921583E-4,52.89550734317196,3.1656935688744667,26.44775077937944,-106.89918282757546 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark25(-5.999994660121806E-4,100.0,56.115245839561624,0,0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark25(60.559267590858724,98.07789941104795,0,0,0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark25(-6.243062425323273E-17,0.9808061458587664,4.26239470782443E-255,0,0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark25(-63.43843511091014,-60.46333809535649,0,0,0 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark25(-6.3961977201240074,6.573068021810229,0,0,0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark25(-66.17479697096489,78.41269930405187,0,0,0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark25(-6.661338147750939E-16,39.11558350492106,100.0,0,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark25(-6.785683126508957E-13,0.027622244617605506,0,0,0 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark25(68.12168697392784,-13.705373325112234,0,0,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark25(68.77019555592548,26.509092955249187,-36.443620552931286,-31.428320788754377,-78.46353624016163 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark25(6.938893903907228E-18,20.556798065138715,-15.815462808304034,9.49300086917191,-46.430378670016296 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark25(7.105427357601002E-15,-23.105437810210418,383.6148849980047,-11.748004234039225,12.965203250549056 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark25(-7.105427357601002E-15,6.327844649910716,101.60309417986036,2.3785241615579125,-91.1821092658218 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark25(7.105427357601002E-15,-67.95284166785119,0.016790798689769047,-34.40301332454948,-100.0 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark25(7.105427357601002E-15,-72.47965649934838,-5.50875518222913,-37.025226413071636,29.25785665722887 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark25(-7.105427357601002E-15,7.325051196140385,30.67171390455936,2.8771274346727456,-16.220898719075667 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark25(71.63602151425629,-2.8421709430404007E-14,-41.36478586788612,0,0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark25(72.83228158971102,-41.1895145144584,-17.416990196361155,0,0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark25(7.759227331289962,-1.3287111818369577E-15,-17.699197985403927,0,0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark25(-7.847374278133117,2.22108267241083,29.85124608581603,0,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark25(7.903653009867784E-4,-9.947598300641403E-14,-100.0,-0.7853981633974918,-99.45865312505894 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark25(-8.387715711831191,0.18727343424136667,0,0,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark25(8.432916062410484,-2.220446049250313E-16,-5.329070518200751E-15,-0.7795062740930586,-90.60957324101842 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark25(-8.44425148246863,1.4210854715202004E-14,0,0,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark25(8.505196539767469E-15,-61.59546302865148,-20.998386231582806,-31.299529414200933,105.96061076664131 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark25(-88.15113528705328,35.03645041397502,54.99912702564521,23.277225477061833,-66.52512282770473 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark25(-88.25979429794954,-54.92568238874311,0,0,0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark25(-8.881784197001252E-16,15.34989602431483,14.462561743358648,0,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark25(8.881784197001252E-16,-176.83440247403274,-79.51660004757606,0,0 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark25(8.881784197001252E-16,-60.58755127315718,-15.716545687472248,0,0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark25(8.881784197001252E-16,-94.60117041396146,0,0,0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark25(-9.237055564881302E-13,49.24815794422716,0,0,0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark25(92.56736093896274,14.27179566516159,0,0,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark25(-9.406399973023796E-4,49.844793600677136,97.32867499243017,24.83003898462517,-99.9753967221933 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark25(96.51728200869337,-89.71457853233626,0,0,0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark25(-99.71187727044116,1.5418777365994174E-12,0,0,0 ) ;
  }
}
