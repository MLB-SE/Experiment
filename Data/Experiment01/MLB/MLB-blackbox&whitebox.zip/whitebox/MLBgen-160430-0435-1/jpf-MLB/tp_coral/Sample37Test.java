import org.junit.Test;

public class Sample37Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0036109179470544817 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.005162689071227078 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0064472165730791176 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.00711463581290217 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.009081488603291277 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.013562727660462515 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.015071910256211574 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.016136377521519307 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.01702492941160294 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02020944681467512 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.02575183913961432 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.027420947798034945 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.030638934939630713 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.034664184513941175 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.037901723964275075 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.042138663466385395 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.046200088060038974 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.04872657795192481 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06272956958472359 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.06627528410984951 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07250590793417189 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.07474655827363819 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08029307884457659 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08340345454103293 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.08955232278370939 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09502167297182496 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0957583291078869 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09668067849869266 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.09849278302674236 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.0992600030280748 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10436875236828946 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10617974811433717 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.10669591698533054 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11469766563692074 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11574829715677026 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.116934206608593 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.11905420933520361 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1255141700814022 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1315796821207158 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.14893926962787418 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1496185989873718 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1523952385523515 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.15375040378129867 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1544125658118527 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1587808838682747 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16555660836101804 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.16975478292912838 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.17145551846727622 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.17877464934984 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.1835042831349416 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18516945496837633 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18576749887230593 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.18684806126849246 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.19912499244891269 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20292715658257876 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2049284705684613 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20498285405217498 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2052325750663142 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20725549182781489 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.20871328246376208 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.21703873140194707 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22005855541828812 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22045805672601682 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22221230175258844 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22510966941342003 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.22579629906107002 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2301183025460789 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23223194998998054 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.23275920819646956 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24591558370701927 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.24759316314026591 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2523793060481372 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25280238909265973 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2538153586984757 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2582194952471326 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.25876514108666093 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.26749235515195835 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2695254800450395 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.27064056207682086 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.27343339741281625 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2737971236675687 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2778744967678364 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2824019293803417 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.28727851419393136 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2901507862107149 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.2937449446312588 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.297504055648929 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30275252941677255 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3078735335207883 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30848171689129694 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.30893364610055585 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3125435604201954 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.33695780680926646 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3454379086888366 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3466574040295589 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.35035088562132444 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.35111487019238696 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3590239654497876 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.36065732917603244 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3678074370583033 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.36902232210655583 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3748828624381306 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3840992097923568 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3869155256811938 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.3910700084153569 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.40078737451487667 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4043647733487248 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4080417229220603 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.41627707383811696 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4210705747767869 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4278689689938897 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4311479578600623 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4366366205858019 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4423765622417477 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4430123564303945 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.45197852100485925 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.45408660209092355 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.45531589224697006 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.46015529783478537 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4614706670246096 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.46439992160608856 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4665743855291893 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4677317801120705 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4737724821377327 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4791351902012697 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4824124134037504 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.4955350208893208 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.49984038421300925 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5041799503250814 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5049142299904332 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5260537652753343 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5282685262883495 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.530417237358991 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5313728049565203 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5314726253860957 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5330472188830484 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5357716769614485 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5422171861215777 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5424887688425213 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5498941464761771 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5511423106717901 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5620066282132513 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5641689235436047 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.564983346036116 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5657746847874461 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.573622941784264 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5755648585155058 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5791424029677772 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5818210270967064 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5854009855450268 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.585591573748907 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5959076638251508 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.5964483571586374 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6130645720585619 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6180453491161649 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6245970443973099 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6285546290961257 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6305142053663579 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6311996618130798 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6399257224554658 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.643862803132687 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6447229450773775 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6464967708749803 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6506940746562719 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6547220577014576 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6548265664266779 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.663579063211861 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6697896757418658 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6771545234459191 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6792590650695052 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.6823907116587105 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7048202699541326 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7086988252563469 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7118742957325663 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.725630101948397 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7256401074501992 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7291387100147375 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7341455551957279 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7367016852831476 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7387622376284888 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.738889413216016 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7411260758338862 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7428429849281901 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7475927663235069 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7586545034180077 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7612654807187305 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7694142035061389 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7700228385170989 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.775122378549284 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7760185691545236 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7762304129474558 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.784732217579247 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7856887593957111 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7911480107287758 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7945813619363147 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7956952331734413 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7969931153748687 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.7983743186920265 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8022506047551838 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8212372285749723 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8306551152415125 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8339620602872388 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8367180008385162 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8390390225150381 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8595205599177405 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8625105088240859 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.862961888275521 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.863916657792351 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.864388640463011 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8652144929669632 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8676965063200157 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8689305925292121 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8721948707283596 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8787988247432016 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.8997627357000226 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9086196465473222 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9097893768559719 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9098042149725813 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9192645332540748 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9237618689549691 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9318657090815214 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9320266833772943 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9357759337742357 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9410534376621573 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9417149891601575 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.958809977255143 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9610097474080703 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9640693058496016 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9647555855572136 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9658232675047289 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9696019559106333 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.988752933370705 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9929618346037037 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-0.9951406030190197 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.006990320002373 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.007710471757435 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.009947894336209 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.014668520711286 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.01579006816083 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.01652146776064 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0165946529134733 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0168571905778663 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.018547793887419 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0198599075972794 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0220617455886087 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.023175825967428 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0236890536299068 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0247281784422926 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.024961692824581 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0283909073941544 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0319059839587084 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0339939397908893 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0359814763816217 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0388530009981287 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0399812187255293 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0410588795636073 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0413047077154056 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0596151915969187 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0609978955E-314 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0724567701409506 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.078768337288773 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.080623383592311 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.081916936380166 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.082288324981393 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0862731565703285 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0874881987631202 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0924702820155119 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0939536379410595 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0997453132555677 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.0E-322 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1003856685607865 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.101752477286281 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1052817607410077 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1114750380232863 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1146893846329249 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1358743318469386 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.138182854169841 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1384574137019072 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.146042632966596 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1494655563927085 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1530270884885736 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1543062425097617 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1554316793243942 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.161770065838963 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1816721098430065 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1880943441056502 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.189346185815423 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.1962456733214677 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.198719310805561 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.199220788064821 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2024922335047958 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2030211569203857 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2142504201458757 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2151350650579762 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.216444766927962 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.221218936596017 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2258682120126883 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2274515729936581 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2324018668653256 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2372132190959633 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2446497340497018 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2466092760367777 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.249866198452935 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.250208331688989 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2515379515354823 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2616949135199678 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2619218328117827 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.269405670843355 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2745111516731384 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2752518843273752 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.276327218936757 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.279749601540574 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2839239063127081 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.2919686665521652 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3011359735121302 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3025087307765517 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.309141033691274 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3092901710138847 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3099655820121738 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3108361006616245 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3163489029116069 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.31897824763096 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3200220815764254 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3220525599574693 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.323454017464283 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3263042361914472 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3314495168659874 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3330013971021284 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3381727982938223 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3434206232337829 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3442074796769434 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3588349959239732 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3636030584814423 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3700792487132138 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3725693974421436 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3733180932754152 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3757125651863618 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3783331655914175 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3893680244227369 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3895201862022029 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3896022207410192 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3983075440762744 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.3984228245913934 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4012172333427118 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.40555693742915 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.408084488624766 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.416613322483185 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4274147465312126 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4315575502990157 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.433572163848467 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.436670385284684 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4490208391197714 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4561508220875838 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4608553655206342 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.463763147971207 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4689284296437488 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4713181065541072 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4733052981623707 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.476319563579588 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4822128349019295 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4866105330024055 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4890976505886944 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4981430261541682 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4994990829960675 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999998899 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999414 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999476 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999574 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999796 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999822 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999876 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999893 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999911 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999992 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.499999999999993 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999938 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999947 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999964 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999973 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999978 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999982 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999987 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999991 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999996 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.4999999999999998 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5687353788086043 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.5707963267948966 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-19.452073646094732 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-20.122425938396844 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2.465190328815662E-32 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2634.8316677989196 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-2728.295787913751 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-37.97642685945708 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark37(0,0,40.850299731545505 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-48.99089960491902 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-52.10073559450969 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark37(0,0,5.551115123125783E-17 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-56.96086936715559 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark37(0,0,5.954807070704177 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-73.99559646832006 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-78.24836781303569 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-78.46591019864131 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark37(0,0,8.248264927622543 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark37(0,0,85.25763076121007 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark37(0,0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark37(0,0,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark37(0,0,96.03487344061017 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark37(0,0,98.83456811350632 ) ;
  }
}
