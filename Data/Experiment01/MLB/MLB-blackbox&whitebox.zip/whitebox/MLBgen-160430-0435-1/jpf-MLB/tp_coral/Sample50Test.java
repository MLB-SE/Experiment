import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.00158556561265793,5.614450702292541E-4 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.0017473380141918829,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(0.0038161929031802102,3.3643009066044203E-7 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(11.6075341502805,24.6075341502805 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(-1.178845217060201E-36,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(13.261262387358826,81.40280969762472 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(1.3934486874709497E-39,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(13.949444586653273,32.90487407698771 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(14.009313499338305,35.990686500661695 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(1.4365396892868088E-12,1.1965250356783556E-6 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(14.835026971663083,27.83502697166308 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(-19.377590527880486,49.70034720930633 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark50(19.595807611749066,63.67797353390125 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark50(20.869285251095278,22.121699067437532 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark50(2.550595063298076E-4,3.832426078045155E-5 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark50(2.879773969281942,20.912148342687303 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark50(32.07335234515739,75.62960184103582 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark50(3.432508407937331,5.478132970795426 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark50(3.5535869911327245,5.551513417519031 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark50(3.7360064726024516E-5,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark50(39.27365097509147,56.608412496467025 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark50(4.0372403248845664E-5,4.9877788720918286E-5 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark50(4.090954985454254E-5,1.0772987806856466E-6 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark50(-43.382524639431594,0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark50(4.499784156397624E-10,2.0453466358986983E-5 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark50(-5.320139272367883E-10,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark50(5.788731069116783E-38,0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark50(69.03132953671738,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark50(7.161615928823494,94.88057007495502 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark50(-97.14344551122511,0 ) ;
  }
}
