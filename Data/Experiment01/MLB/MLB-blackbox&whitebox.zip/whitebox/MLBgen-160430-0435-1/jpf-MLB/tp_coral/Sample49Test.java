import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.002981407782396105,1.1499713109126267E-6 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(0.010666113541093813,7.169806723305113E-5 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(0.024740719514619182,3.983451161639161E-5 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-0.0636230656829333,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(0.5839438022953342,0.7641621570683372 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(10.823256672225794,11.774369701089958 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(11.099053617594492,18.584176052210495 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(12.527105971844193,29.729080356307094 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(1.8486326408165263,48.151367359183475 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark49(1.9821522057703956E-4,4.928863894609134E-7 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark49(2.2688359153764546E-4,3.864822826155093E-5 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark49(2.3562231252215047,5.28258553564199 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark49(24.405877926361256,80.42739138214054 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark49(-3.233084966553055E-9,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark49(34.02155562077053,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark49(34.50620987775562,98.03572709476987 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark49(4.093795615001117E-14,2.0233118906384096E-7 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark49(4.189020120240624E-19,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark49(-4.53574496812976E-11,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark49(46.4441653029304,80.11462692005941 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark49(6.875508859541313,93.90999879264876 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark49(7.582853195498312E-17,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark49(-77.02313301306731,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark49(82.5855690255772,82.7936328349956 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark49(8.373400132302919,56.37968726340284 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark49(-8.597876836233E-5,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark49(93.83940390247474,0 ) ;
  }
}
