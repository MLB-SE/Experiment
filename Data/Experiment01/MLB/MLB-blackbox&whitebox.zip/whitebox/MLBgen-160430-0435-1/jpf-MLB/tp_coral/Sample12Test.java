import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(-0.9999999999999991,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-1.0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000009,-100.0,-1.0,0.06255253660387253 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-1.0,-0.04566833408366633,0.3228113905779926 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000018,-59.162842503867,-0.9785804335772115,0.23782215046469735 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000036,-85.61139274391911,-0.02221437044882254,-5.483135054166086E-9 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark12(-1.000000000000007,-27.85555156474417,-0.9751011267880415,-0.4092188341436401 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000142,-100.0,1.0,-0.06276224523355924 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000142,-1.0,-0.9709643880749754,0.062597095593699 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark12(-1.0000000000000142,-64.1062080460752,-0.9048654056050046,-0.06256768536520715 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-0.9999999999999929,-0.9999999999999996,-8.976313649624851E-17 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-0.9999999999999996,-0.050938675201916805,67.45418413884722 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-0.9999999999999997,-0.9713960373481334,-1.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-0.9999999999999998,-0.9999999999999445,-0.9999999999999982 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-0.9999999999999999,-0.1648649414751792,0.2710480581814567 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,0.0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0000000000000009,0.0,-1.0000000067893948 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,0.13922258513084584 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.002345716842313994,-0.04766449774642416 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-100.0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,100.0 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.020500155332452905,-0.5619250396025417 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.02468301248151457,1.0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.043812289249077915,6.938893903907228E-18 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.04634411069594874,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.05139038158430703,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.05342470531741507,1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.05374680378552167,-1.0000217530347901 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.0,-92.7023640149008 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.0017174044025986945,59.46365659225532 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.2444441708117726,-1.0000000006811147 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.3818526462382853,-1.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.45843633934568995,-21.730824994924532 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.5248231314259275,100.0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.006691406111867498,-0.04577321797013653 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.678502683757499,-11.513412477755196 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.76926504279518,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9600882523063407,100.0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,0.9993954522766708,1.0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-0.9999999999966115,0.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.000000000000007,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,100.0,-0.17327150513539036 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,0.3141481381926947 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,1.0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-100.0,-3.717909044380401 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.03755459230281699 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,0.06255331635594119 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.30113890131705745 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-0.5988478386034188 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,0.96616347562387 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,1.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-100.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-1.002128874980294 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.0,-1.0247887728197553 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.0,-16.73447480732921 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-1.3877787807814457E-17,1.0 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.015130513415621327,-0.9920308882269971 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-18.44633857273859,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.03129408546248766,0.7480637272973398 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,3.250282140006581E-14,-1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,3.552713678800501E-15,100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.04477381305937604,0.9524558799324865 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.04703237352024843,9.070234308546043E-9 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.04823451892088382,-13.558250211635198 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-49.266971868116634,1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,5.29304393717413,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.05610567918210184,47.70667375579586 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.057800900136712026,0.0 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,59.33983115018994,0.9999999999999999 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.060154358978593336,0.8706245571395543 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.06053379924701659,-0.6757053141169105 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,-66.12298318298544,0.7734854977175445 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.07194730211766898,-51.031900757907486 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-100.0,99.70217403110998,-0.046950233183774254 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.294282091488122,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.312768566316159,-0.9831090475484028 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.3272805846598967,1.0000317473415985 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.3708090318463484,0 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.9106593488647301,-64.21463794940581 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.9775695768367048,68.67720303406202 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.9973745966379889,1.0 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.9999999999999982,-1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-0.9999999999999994,-82.35068399197614 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0000000000000002,-0.9999999999999988 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,0.36708540364994763 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,-2264.512995810254 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.0,-8.236092143148846E-84 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-1756.1502853263007,0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-2530.9535995373703,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-3.320169328889815E-17,0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-4.039599334970871E-4,1.0000200457290043 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-10.429007611310045,0.0,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0,-4.938764075834887E-4,0.025822780608225918 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-10.59096840984313,-1.0,1.0 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.09206050636128,-46.90810563136079,0.3625642124651671 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.0952969809282536,56.97497631547665,-1.000002003530517 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.076728940618544,0.03622790126523866,-0.06456301485787787 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.571936734890983,-0.5001864491396621,0.06023577959706983 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-11.975784503468999,1.0,-1.9851521088480948E-14 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-12.143708784159523,0.9605646372625122,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.4366108620085156,23.39633303907602,-1.0 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-1.4482179046401953,1.0,-2.7355767673747375 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.653918059383978,0.006291693713009083,46.40512464432035 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-14.900013120312646,-46.36527856516089,-0.3232698278752332 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.29679984307544,100.0,1.0000287963480605 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-15.679557027938834,-1.0,-1.0587911840678754E-22 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-17.062439362193057,1.0,0.9981940050105004 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-18.33812057227133,0.6353365170374811,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-21.6376917843971,-56.93009516085187,-1.0302805118928258 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-22.95662408161057,1.0,-0.36209567927925135 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.185248401743323,-73.8569741838385,-1.82877982605164E-99 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-23.345159781907284,0.32103434772585693,-1.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.495237389407905,-0.9999999999999982,1.0000000000000009 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-25.497407637393984,0.00554838245348821,-1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.01908497285379,0.9794219273143165,1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-26.558069230136894,0.18814564770500686,-1.8306419339117093 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-27.82969563403214,-1.000000000000002,0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-29.476067889659365,0.10157133016921283,52.41533877830477 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-30.54816865575205,0.07342678746511999,1.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-31.471330262987525,1.0,100.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.137669649030556,-0.48162209895483343,-1.0 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.21553367352969,0.05102571520693322,0.3534682914749925 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-32.8506859376882,36.05054344115292,-0.19509894182324583 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-33.255814175929316,-1.0000000015352801,0 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-3.347580011611537,0.010503767243575352,-1.0 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-33.715867926674655,0.027680882604923573,-100.0 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-3.4128574018417583,-5.379134429026877E-4,-1.0 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-34.31390573997241,-75.14524991423015,2.0880974297595278E-53 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-34.32986906553106,-0.01379393495903134,0.3620960278709793 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-34.44481435009769,1.0,1.0000165755385586 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.14959196933653,-0.0027332677144662892,-18.297055980052782 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-35.61648208915223,-100.0,-0.05537860885954679 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-36.19343132046225,0.0,0.6747301525431977 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-3.6984763421755593,12.68888081465543,-0.9999999999999996 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-37.85508618333684,-1.0,1.0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.17114558058407,-54.37397788717162,0.05163057844925889 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.27732120559641,0.0,-100.0 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-40.81553445427524,0.0,1.1242653935047148E-7 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-41.2296130603634,-53.81648389277116,3.55032940586896E-9 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-4.264409436760529,-0.8917869841299448,-99.0759974544799 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-48.234623624940205,-23.906249757180547,1.0 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.03263402107579,-0.644399435867322,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-49.875675233323406,100.0,0.9161377946266387 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.10577628374253,36.9055572774541,-0.040641100558879 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-52.2972383989703,-0.05610211233675218,1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-54.77478782158853,1.8923199342895725,1.0000039470442523 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-54.861660582292785,-1.0,1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-55.54331248065389,-0.9749954379746412,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-55.79600063258261,-0.4862852287532652,-0.39637340850598124 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-56.258752463731426,-0.06173023863451459,-1.0000520874751364 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-56.589983845369005,-17.420449267818174,-1.2025378976689598E-15 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-56.90405778576617,0.0,31.663049703385205 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark12(-1.000587036303966,-50.39344392576958,-1.0,-1.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-61.54365371578228,0.9993506250440249,1.0060624108698342 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-63.420255768349776,-1.0,-0.5846338413688164 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-64.44500691985148,-42.221982610606915,0.038110230961599045 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-64.81059782787544,-0.9999689830519751,-1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-67.3614211402221,-1.0,-99.1579245645292 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-70.32673433196484,0.0,1.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-7.310330668593759,1.7763568394002505E-15,-76.00302331296612 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-73.23957908679299,-0.9269696360933274,-1.0 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-73.79648209681928,-7.512287827300711E-16,59.56212154546901 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.7498499198673,5.551115123125783E-17,-1.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-74.8374468930793,1.0,-59.425756291638976 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.7614720881166,-0.999993127395037,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-77.9593710714968,0.0,-1.0 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-7.810282792463808,-1.0347349116930904,0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-78.6081764158638,0.0,-1.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-83.2452775343483,-0.4453016345566957,-1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-83.71417296260209,-1.0,1.0000000000000004 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-85.01475304147601,0.8992118356272806,-0.9566336473082059 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-8.582408722112927,-0.387212726383104,100.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-89.05804796176291,0.9690984675233448,2.3603208665858507E-4 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-90.75971346457956,77.94796597405256,-1.0000000000000018 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-91.7462200613015,-1.0,0 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-92.91033712240859,100.0,0.9441347587711846 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-93.93452824362825,8.881784197001252E-16,1.0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-95.87748331192101,1.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-96.53903685333414,-1.0,-0.8487225200423638 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-96.92803885964,-0.5568856332202244,-1.0 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-97.44657835548007,0.010225548528658904,-1.0 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-98.64505193459499,-0.012067894234307389,-1.9472399201439312 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.63603363272203,-0.9996284879603428,0.05523460289289825 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark12(-100.0,-99.99998959822496,0.0,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark12(-10.05428773828777,-59.42818416651576,75.55352319151832,-0.9553874786469273 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark12(-1.0101915174003946,-1.0,-0.14710214147225953,0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark12(-1.0177834435965953,-1.0,-0.8839859605314399,-0.24624508628703978 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark12(-10.19916928172968,-64.4152272935755,1.0000000000000018,0 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark12(-1.0227598340396042,-48.24123527612152,0,0 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark12(-10.257357787498982,-19.009086135877993,1.0,0.11546225101280072 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark12(-1.0274656561868731,-55.39129158819126,0.5819419085351163,-0.02930876225208301 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark12(-10.30670861784817,-2.910166441781036,2.8744160649670696,-0.7851833625273519 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark12(-10.314355530849742,-1.0,-0.004500514272728354,-79.43223049099342 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark12(-10.320097891951917,-100.0,-43.39515528852724,1.0000000000000002 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark12(-10.417853888238776,-7.288128877585049,1.0,-0.30249772635080374 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark12(-10.427210188570635,-35.492883211869604,-1.0,-0.5909381081236991 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark12(-10.46952256492859,-1.0,-0.9999999999999991,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark12(-10.488957845088544,-5.6553339632855195,0.025917423584588747,8.673617379884035E-19 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark12(-105.57931408062625,-1.0,-0.24157975748541682,1992.3342544877228 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark12(-105.83510783499622,-1.0,-0.7923423183325582,-0.3841511082278899 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark12(-105.95195023179511,-1.0,-0.05935092244621898,-1.0 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark12(-10.633518800941735,-80.2431631586624,-1.0,1.0 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark12(-10.654589321827729,-61.11754612439806,0.0,-61.88754662271698 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark12(-10.717554314605422,-23.21585949869693,-72.71377516494289,99.30631858202818 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark12(-1.0741265181950859,-4.1905044068045605,22.219639216350654,-0.0632570619350844 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark12(-10.82885980600021,-34.17333498823629,32.7267257943478,97.62619135457842 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark12(-1.0893800685222674,-85.98219964782248,1.0,0.3923960515899966 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark12(-10.94190499318672,-5.8590322203566565,-0.9999999999999982,-0.9726803935753362 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark12(-1.0947986269671561,-80.24927481858687,0.0,0.0625543773562946 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark12(-1.0967194578883834,-1.0,-0.049671938132153974,-1.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark12(-10.977543118611434,-38.517384555141014,-1.0,-0.12216017103779375 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark12(-1.0980144717350753,-1.000000000000007,0,0 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark12(-109.89233596895359,-51.15788016483883,-1.0000000000000036,-2405.681082429601 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark12(-10.999740898461603,-32.211187365440466,-1.0,-24.42126411720095 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark12(-11.009682097247307,-63.45870798527676,-1.0,0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark12(-1.1035451409901356,-50.21167472424928,-1.0,-1.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark12(-1.109579802262095,-63.850054304278444,0.044041204958444435,0.0 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark12(-111.28329277212723,-98.31582186783449,6.938893903907228E-18,1.000044465263557 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark12(-11.146744473471266,-1.8489759938856434,-1.0,13.171275557929917 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark12(-1.1171858667479577,-1.0,-0.7519381524011237,-76.79192589937102 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark12(-11.190162685385282,-82.33425057929948,5.492372735699497,0.9999999999999999 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark12(-11.231375567407024,-1.0,-1.0,-0.9999999999999963 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark12(-11.266387579488784,-22.89470706282619,-0.952250886070835,0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark12(-11.271123142430412,-67.21619486099952,12.276476029370855,0.9772042708164456 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark12(-11.340489092342748,-88.41933340119695,32.38162315744751,-33.73299415222343 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark12(-11.356567536025581,-1.0,-1.0,-0.9959827268089168 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark12(-1.1359640949855727,-51.75561160368834,0.0,1.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark12(-1.1407767067622245,-100.0,0.6076136625480981,-86.45509695262466 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark12(-11.624170073817353,-100.0,0.009742748531451184,-1.0000000000000016 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark12(-116.62896570967524,-73.67293960820611,-0.0365460056137181,2083.1629851756284 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark12(-11.710263350436833,-45.12080340631858,0.0,-0.053926326412679776 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark12(-11.794701041823423,-34.47080257096394,-1.0,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark12(-11.853466219749537,-67.19685928959976,0.057540606833037675,100.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark12(-11.962101650848885,-83.81101333913787,-0.9353998498221979,2.7420549749656606 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark12(-12.065789094715266,-1.0,-0.978639389185199,0.19984759793940127 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark12(-121.2365759551501,-1.0,-0.009454943486585474,-0.8626945812402482 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark12(-12.212535413964504,-1.0,-1.0,-0.6287676070402699 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark12(-123.18312890274004,-76.78776793482781,1.0,2353.3009538955707 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark12(-12.327160890169463,-51.15156338301657,-71.11738743055976,1.0 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark12(-12.45677701953531,-95.11018525304189,75.19274111423195,2372.050417677703 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark12(-125.34624380796383,-70.13956081354024,-0.05518942363761059,0.3008964527731397 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark12(-12.54349945920221,-40.19414357103452,70.81529211247329,0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark12(-12.57461038386127,-3.0592097530950135,3.0753645401662553E-18,-1.0 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark12(-12.596896159465024,-65.56998594352491,1.0,-76.77506636766977 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark12(-12.60947768811252,-14.770809990111104,-70.07413623307322,0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark12(-12.696923797999212,-8.666897307097447,0.352134030330641,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark12(-12.772264405254663,-35.09957380344839,0.9658993599247563,1.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark12(-1.2779522653724769,-25.46911152942861,0.7924393853718037,0.0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark12(-12.846723146928035,-33.74576789140152,0.014884580468683767,0.9716267100251024 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark12(-12.88309923316273,-77.68224718939472,-41.95698904118385,8.881784197001252E-16 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark12(-12.963550757534628,-1.004605527689947,0.899570665321588,0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark12(-13.063128707692922,-8.185453362725232,-0.8004015730024271,0.04557102074680286 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark12(-13.073892024320688,-72.36557576481907,43.81218703961897,1.0 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark12(-13.075222877630077,-60.06128994143597,-1.0,1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark12(-13.103057157060181,-24.021207956322257,-1.0,-1.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark12(-131.49967510743264,-91.88510354640916,0.0,-2303.688113881894 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark12(-13.230723149524344,-100.0,-16.610858413038155,-1.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark12(-13.24286974668312,-51.75532601975122,-1.0,0.0 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark12(-133.15578164047062,-2.5611917420151524,-0.9999999999999999,-0.9649417081504869 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark12(-13.396352587069504,-100.0,0.04280583023280771,1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark12(-134.0323199242985,-9.857635770145539,0.05239766066576079,-0.4106630054112368 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark12(-134.31300772071393,-91.54065644763921,3.8423973695760054,-0.677647337247997 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark12(-13.440668888446837,-45.709063071266684,-0.03694802090891304,0.9999999999999996 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark12(-13.460547878545686,-8.122735201550267,-22.606307770324975,0.0 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark12(-1.3464144592386207,-1.0,-1.0,-6.5316025724666845E-6 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark12(-13.629417715073686,-74.50000200121478,-0.043587991438447535,-8.1214138794100775E-115 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark12(-13.653094723840425,-1.0,-0.027616952344025135,0.9758052578652698 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark12(-13.708561161884397,-92.42740979209474,-0.987769232462377,-78.99674884329818 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark12(-13.709683481255226,-91.70051081094526,22.468575900063264,1.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark12(-13.736158691617245,-1.0,-0.053039839091170715,1.0 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark12(-13.742877391620107,-8.867293558317968,0.0,-1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark12(-13.792868793611264,-100.0,0.009154636143631878,-1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark12(-13.797095657947807,-18.955937687572046,1.0,-1.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark12(-13.812851767431974,-1.0,-0.7270886169943127,60.03640600911981 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark12(-13.818609021117894,-1.0,-0.5277914984936982,0.9999999999999996 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark12(-1.3871170801958712,-16.948216290015843,-1.1102230246251565E-16,1.0345357587669375 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark12(-13.880653907460374,-84.68717693499035,1.0,-1.0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark12(-13.888898556102669,-100.0,-2.266110543044176,0.06282196729913184 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark12(-1.396995436233648,-37.99188328572493,0.06122634526005663,46.92691614500374 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark12(-14.004099552470983,-3.0117426088349886,-33.917253685897805,1.0 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark12(-1.4016194855543205,-27.580085850932022,-1.0,0.8723588924509358 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark12(-14.052057329618549,-58.415301647367016,-0.9999999999999964,-82.0562856282084 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark12(-14.056146304408625,-99.23676242523172,1.0,78.49248613063202 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark12(-14.08187573338808,-30.40102467980403,-0.06298679373354255,87.33082188551626 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark12(-14.112524068759743,-1.0,-77.36388024927464,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark12(-1.4137746550737846,-62.87533285608013,-0.8781821245458602,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark12(-14.146019901727593,-75.83412196838681,1.0,0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark12(-14.172331440829264,-31.233737636124445,-0.017495706490454233,6.776263578034403E-21 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark12(-14.235772939179414,-73.53740382304514,0.0,-0.26351232345616504 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark12(-14.270601666526243,-1.0,-0.05684100986091403,5.551115123125783E-17 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark12(-1.4336861981597018,-70.5166152803038,-0.4465917860758789,47.54883247200638 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark12(-14.36949321706679,-86.898091767051,1.0,69.30537113198761 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark12(-14.383733274653444,-100.0,-0.09325007946449149,-0.04123853735628773 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark12(-14.387375330405565,-21.596766483695223,-0.013386863915369945,-1.0 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark12(-14.469382991556364,-1.0,-0.6329852543232657,-76.74677601676498 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark12(-14.497225767887373,-1.0,-0.047816693147968325,-1.0 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark12(-14.551496478655423,-34.765273576041714,4.051807294500321E-17,0.8730910017943037 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark12(-14.637737973907875,-1.0,-1.0,-0.99956610050791 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark12(-14.657959811700028,-79.10095234166775,0.10341073963406455,-0.1324038373184382 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark12(-14.697921216452812,-276.42283492780757,-0.06788910371873313,1969.408093911649 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark12(-14.736551891802728,-1.0,-1.1102230246251565E-16,0.286665697307824 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark12(-1.4743104962593314,-88.63436263352298,-35.220251604403494,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark12(-14.792290498001933,-36.4023299857311,-71.51571729857713,-66.83304988233246 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark12(-14.824746962539521,-1.0,-0.0017993381586465518,-0.02242088789860816 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark12(-15.02281763704596,-3.9437874664419326,0.8793623730013191,-61.95287246835801 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark12(-15.042882073825393,-39.45313020811699,-1.0,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark12(-15.10449427264538,-56.85564998626033,-0.037363159506889405,0.7620082768372062 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark12(-15.10663177295433,-91.45037127796732,-0.571275240815567,78.04332609941099 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark12(-15.188198611468238,-1.0000000000000142,1.0,5.293955920339377E-23 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark12(-15.213105685491714,-86.80111952933727,0.0,0.997616962524507 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark12(-15.23199266749748,-74.59450733390374,8.270863584038352,-0.463371346313707 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark12(-1.5479589318128153,-22.11913810058239,-1.0,1.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark12(-1.558622374102409,-32.62899758563532,-0.8820409155707986,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark12(-15.605811230354592,-1.0,-0.004527514532901973,-1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark12(-156.63187484768014,-17.440062850029754,0.46234678535419693,-2215.433546601726 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark12(-15.717348603382234,-1.0,-0.9931967778372717,0.3147952795161766 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark12(-15.725954251719951,-31.877261531410838,-1.0,1.0 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark12(-15.75859331445993,-66.43536296262377,-1.0,-48.4881080091992 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark12(-15.801850826715985,-57.8826587766516,61.27988508270211,1.0 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark12(-1.5917254892141124,-1.0,-0.948009473108736,-57.5320172601865 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark12(-15.92648806099408,-1.0,-4.3550296100856373E-16,-66.18295409092376 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark12(-160.00477888482428,-63.9098248905386,0.05905338264332402,-2003.954347357718 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark12(-16.031722390122287,-5.2928519912115695,-0.005445814106455837,-1.0 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark12(-1.6061306477139747,-58.28126256865064,0.0,-100.0 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark12(-16.118109093801557,-100.0,100.0,-2373.1452691372597 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark12(-1.6154202843049816,-53.26896010901676,0.01734806044016262,1.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark12(-16.215588365215993,-1.0,-0.7123736679348007,0 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark12(-1.6230996801255686,-1.0000000000000018,-0.9999999999999999,0.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark12(-16.25258582713262,-28.558857234410592,0.0,1.0 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark12(-16.260004023530854,-1.0,-0.9969459621286243,-1.0674100720312225 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark12(-16.382851006221347,-69.33933978171966,0.9345471259909508,31.010497376077026 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark12(-1.6505548697027024,-79.94732159932722,62.126242381367774,-11.273816210061 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark12(-16.511684116397362,-25.853656308473802,0.6282197072552469,-1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark12(-16.51381667527582,-35.92438312175632,0.0,-1.0000000000000018 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark12(-16.62895558331757,-0.9999999999999962,-0.3057256660833314,-1.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark12(-16.646356231119476,-29.095845768556536,1.0,-1.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark12(-16.648457301714487,-1.0,-0.0121710711327877,0 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark12(-16.728792493669573,-88.36414380939244,-1.0,-0.013049388292845437 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark12(-16.742196910457583,-100.0,-1.0000000000000702,1.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark12(-16.84492795019131,-1.0,-1.0,-0.04279871554310192 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark12(-16.89246748427466,-1.0,-0.44508732999282286,-44.59596011815775 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark12(-16.915147515981904,-58.607989978183994,0.04172987543869748,1.0 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark12(-16.91715126097418,-80.72993147256743,0.9999999999999964,-1.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark12(-1.6921340635619746,-83.68158005853633,1.3877787807814457E-17,66.29634577530408 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark12(-16.976161840099362,-41.54133360904244,1.0,0.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark12(-17.0594677054353,-1.0,-2.7755575615628914E-17,0.03808203143983885 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark12(-17.132403844722276,-100.0,0.021745900135117097,0.038443464226221566 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark12(-17.14984141335685,-1.0,-0.0315172673187295,-48.40488858537031 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark12(-17.1775671908849,-1.0,-1.0,-0.4097619133409798 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark12(-17.233617720750477,-1.0,-0.1315726890968456,-1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark12(-17.283337566861462,-1.0,-0.9853435362358981,82.9126243977154 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark12(-17.354181362507887,-35.73064086519339,-1.0,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark12(-17.36224911092904,-15.296405672121484,0.0,-1.0011547523884978 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark12(-17.374260170786037,-30.540412401031183,-0.03589370819560944,72.34634570025824 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark12(-17.455604508110838,-42.241861598895156,0.0,-12.130967995761011 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark12(-17.480171181269327,-20.3981295712345,0.014330850947697295,12.557932978292456 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark12(-17.51047416075113,-31.43397533002343,-81.82194974794467,0 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark12(-17.586392581945468,-44.29577530615086,-0.11064733231374979,1.0 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark12(-17.589777697721587,-129.996887503916,57.12540381741334,-2453.899323553822 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark12(-1.759266044728052,-100.0,-0.039778836336098744,0.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark12(-17.652518335384308,-12.33244992274896,69.18990052416089,-1.0 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark12(-17.655334445095974,-98.77802831204023,24.947301559796614,40.04334296433356 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark12(-17.74997370044317,-32.59886088786553,0.0,-1.0 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark12(-1.7775852552760085,-17.02525754449971,-1.0,-1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark12(-1.7792021850679436,-90.47315551060287,-1.0,-1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark12(-17.834424386310403,-10.31284307087409,2.2810204654399653E-6,-0.5760460690681739 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark12(-17.843978879073447,-27.508954620327813,-29.57492620353672,-62.91527258637926 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark12(-17.912395465906812,0,0,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark12(-17.942940972908794,-47.332516438026275,0.9703939465017121,-1.0 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark12(-17.96885208761946,-100.0,0.0,-80.16412558252719 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark12(-18.002538234987384,-6.243533247738213,-1.1375315857137451,62.185071697443846 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark12(-180.20148909167557,-1.0,-0.04728472317988973,100.0 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark12(-18.058896268290365,-8.204682541147971,-1.0,-0.8585620156923359 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark12(-1.8092280678010582,-32.97163500100375,96.07353327057083,0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark12(-181.43341235662257,-73.80410354871033,0.0,1.0000723366203157 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark12(-18.152690441870345,-1.0,-0.046378876353078705,-1.0 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark12(-18.158314690268174,-0.9999999999999999,-0.8801365308990233,35.48491539261008 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark12(-18.20752335672197,-25.515910273477257,0.0,-29.742822235040656 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark12(-18.24282431381737,-1.0,-0.9849717958713562,-1.0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark12(-18.25117087665496,-53.576949658935206,-0.9984213965072206,0.968585552437745 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark12(-18.300746342282473,-86.2796025026483,-0.014565961400471325,-1.0 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark12(-18.462938518232487,-25.124339596501997,0.042277893106206665,1.0 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark12(-18.48328962141281,-70.40745771997206,-65.31428041985856,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark12(-18.598406533767402,-1.0,-1.0,-0.0038478539342431395 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark12(-18.612341903076917,-71.57376838748604,0.0,1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark12(-18.63700911658468,-52.15663829538765,-1.0,-0.007577036150327426 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark12(-18.68657862233386,-41.47544082249904,1.0,1.0 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark12(-18.76765437436025,-1.0,-0.03645787007255794,1.4693679385278594E-39 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark12(-18.888234150621095,-60.23326539830221,-1.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark12(-18.90360490975725,-48.19967557241323,1.0,1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark12(-18.919777179006417,-82.92057765368736,-0.1710838941055215,-0.9999999999999822 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark12(-18.94490133168253,-19.980746322790438,1.0,-0.4004395939273328 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark12(-19.021814324321063,-1.0,-0.8976423094916938,1.0 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark12(-192.37116119328732,-27.993920811104555,1.0,-0.2936054096548757 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark12(-19.27345481059386,-33.17227815037098,73.23628414116351,-1.0 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark12(-19.2932414144238,-6.924740629158634,-0.04112377867451575,-0.8328806356186274 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark12(-19.35607491172769,-14.828264065435093,-40.22647433748689,86.75083602623249 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark12(-19.416399400660058,-1.0,-0.010110548369522037,0.9903095613707066 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark12(-19.455011030448244,-26.95104458598173,0.6566201560669342,1.734723475976807E-18 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark12(-19.52117558683858,-27.991901698453326,-0.051598574038276696,-1.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark12(-19.53526015448299,-1.1500471284983698,-0.5205923700962958,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark12(-19.535267597423058,-35.696639476738,-0.9524367709655914,-1.0 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark12(-1.95974977461767,-4.64102801382861,-51.32499942729777,-1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark12(-19.631946399781427,-100.0,1.000000001297844,0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark12(-19.735658488650664,-99.63111299743096,-0.9999999999999997,-0.0513260582335795 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark12(-19.766120731219885,-35.390160495196014,25.63731268309894,-1.0 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark12(-19.782776579830546,-72.04316579741858,0.2868521757904107,-1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark12(-19.86486892566747,-22.743936935421768,1.0,0.045883749721050235 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark12(-19.87958952594707,-45.34905034216658,31.099137856678375,1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark12(-19.890190554509356,-31.030118604186974,8.881784197001252E-16,40.067967054087426 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark12(-19.891745482984135,-91.58105614753921,-0.9668637941532188,0.4893662093507665 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark12(-1.9996183739116056,-88.0057835821226,0.0369377274979165,1.0 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark12(-20.09960631477009,-1.0,-1.0,-0.06255929456121913 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark12(-20.111972308753003,-86.65862960368439,5.6863152799079936E-18,-0.05223057362632655 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark12(-20.136484878895754,-1.0000000000000002,-0.04628523079602087,1.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark12(-20.13754465034438,-95.00000279245164,1.0,0.29294460832325453 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark12(-20.14420726900332,-75.67347624300312,-60.65514851263453,-0.6917408683783557 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark12(-20.196570407227096,-39.03853427070827,-1.0000000000000009,62.24193510856934 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark12(-202.20226426023987,-1.0,-0.021233370682067765,-1982.0903746951335 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark12(-20.29336699469503,-53.46424993485196,0.9999999999999982,-0.576589452159854 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark12(-20.295289161878188,-60.73155914105541,0.0,0.011730639350987032 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark12(-20.396192495769625,-48.73566678114525,0.0,-1.0 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark12(-20.398061909632077,-9.063389488529918,31.78660359870422,-0.03002358707525543 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark12(-20.53898580349801,-10.96064856412554,-0.025213623360238586,-0.9477582787188876 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark12(-20.569048713136382,-2.23693447093828,-0.3419754655329675,-1.5423487136658458E-179 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark12(-20.62734354957276,-40.223264348012215,-0.9690619328416908,-0.0013099380794066862 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark12(-20.765217880513703,-44.482596961670644,0.9999999999999998,1.0 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark12(-20.800290033713484,-91.24939177750305,-99.83572179290022,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark12(-20.814424024233766,-1.0,-0.032717369923493264,1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark12(-20.864183574547894,-22.26351140309592,-98.34896385584511,-57.77282791750391 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark12(-21.016949302349524,-24.133743274637737,-0.061223441348593796,1619.7685724696255 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark12(-21.03041005603702,-50.720575183558765,0.9999999999999964,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark12(-21.04489135246913,-87.2220078160511,0.02396283541245013,0.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark12(-21.076627832136055,-36.0662170443811,0.8916496546901418,2299.2950856231623 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark12(-21.132764400350663,-1.0,-0.551494350319999,-0.3063839053382227 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark12(-21.195610663441023,-33.37538943021191,0.9206220738961095,80.38084059213209 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark12(-21.2050581049849,-94.60689940912526,-38.23858089957224,95.57789187286448 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark12(-21.246215597362422,-43.87967578107298,-0.0956875969914122,3.469446951953614E-18 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark12(-21.298084070812784,-41.99879779612632,0.0,-0.9639193259739918 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark12(-21.371101176662687,-85.42624516012675,1.0,1.0000000000000009 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark12(-21.513751859243442,-68.8601456072147,11.552642284502959,27.364605137054326 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark12(-21.566382956790505,-34.4050618267726,-0.02755404212017058,2.944449707205596 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark12(-21.59532466080725,-83.15713796412328,-1.0,19.647187085720812 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark12(-21.635149341106672,-42.51535248777368,94.7406619097493,-1.3684555315672042E-48 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark12(-21.682093318479275,-16.676227599633904,-37.16630288669247,-1.0 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark12(-21.750325290412476,-18.206268002435092,0.04106338846015082,22.170596748398026 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark12(-21.751811797741855,-95.79943456403555,0.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark12(-21.78287012250504,-14.95448423419816,-1.0,1.0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark12(-21.789310625237704,-1.0,-0.36832014239421584,0.0 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark12(-21.875477199119654,-15.885585910082348,0.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark12(-2.1945652600495293,-72.13646976260384,0.0,97.66787036784271 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark12(-21.989320866106077,-86.51845657320798,-0.9999999999999964,18.057555130427986 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark12(-22.06225061301348,-70.1954883465445,0.04747520653284985,1.232595164407831E-32 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark12(-22.07381035892245,-21.05400425119909,86.53191813534175,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark12(-2.2113602953873004,-8.521049716574142,0.3926445530239657,76.55984847844897 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark12(-22.134930653721064,-1.0,-0.4906295055428218,-1.0000000279910084 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark12(-22.139002836226805,-53.430632420709586,-1.0,-0.8305469001565848 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark12(-22.28189168645505,-1.0,-0.9548286207213221,5.551115123125783E-17 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark12(-22.296177176483653,-100.0,-5.551115123125783E-17,8.83121127321571E-4 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark12(-22.304291743325976,-2.138824137793179,-0.34868098497682354,-20.44566357525055 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark12(-2.2315940211358996,-1.0,-1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark12(-22.340856073933185,-1.0,-1.0,-0.9734294885508055 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark12(-22.42343052747316,-1.0,-0.8694682754037064,-7.645497045799647 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark12(-2.2449548693158503,-11.001402269064512,1.0,0 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark12(-22.505133849299323,-56.97287342809845,0.0,-0.007911412543572291 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark12(-22.558704658578026,-56.82630616347972,0.0,38.064451763818845 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark12(-22.689033509738493,-1.701407216630039,1.0,-1.0 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark12(-22.796014905427807,-82.4843737286623,-0.8662516766326579,-1.0 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark12(-22.884699917060303,-1.0,-1.2296732348653083E-4,10.51312623740226 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark12(-2.2928845350686298,-100.0,-1.0,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark12(-22.993109367557185,-2.9009035353403707,1.0,1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark12(-23.00145697001363,-64.38910196958794,-0.015318401797667058,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark12(-23.1471219655294,-71.27633392314134,0.05048200152418669,-100.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark12(-23.19881676113782,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark12(-23.260012007700865,-82.7021461330165,-15.92298891828608,-1.0 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark12(-2.3395349024245538,-51.10727003550057,0.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark12(-23.46825394160635,-1.8904271289445376,54.66743761981717,-1.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark12(-23.470655208209514,-1.0,-1.1102230246251565E-16,9.71560487022284 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark12(-23.533120197665028,-0.8317636884319057,0,0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark12(-23.536121379815345,-1.0,-1.0,-0.8649844376445677 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark12(-23.60568397967484,-53.10691235287217,18.948480206761346,0.9708605953401597 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark12(-23.64194912898687,-100.0,0.9999999999999929,0.25946921445439175 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark12(-23.72696214652821,-21.000263257917688,-0.9999999999999989,45.929374936159974 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark12(-23.82039186424886,-1.0,-0.4788263974298417,0 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark12(-23.914419599185734,-3.239293379634562,0.6491348327988214,-1.0 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark12(-23.91934663053365,-32.25914048517534,-0.3570656602931903,18.383657129501923 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark12(-23.93259564711021,-35.88422161762911,-1.0,63.319771864832774 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark12(-23.97886119052426,-100.0,-10.766436818976008,3.056856745249924E-5 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark12(-24.003577821970385,-96.83412190543828,-0.025773388593913482,-0.9817415624946227 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark12(-24.07154366604748,-52.52221415602261,-0.5828615854397782,-0.6751713988100767 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark12(-24.1837662361115,-82.15383152976979,-1.0,0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark12(-24.198634027897395,-34.55499286383898,0.8785884639242274,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark12(-24.204252867515464,-1.0,-0.0520376520406743,-0.5717971741529304 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark12(-24.305043212867346,-25.139084539168238,-0.022707205947670867,-0.058107243790078256 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark12(-24.323987539176144,-63.687585589265026,-0.5744370770890307,-31.563891332644147 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark12(-24.42353816801095,-56.46489274916792,-1.0,1.0 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark12(-24.440731926301297,-21.670153643558393,9.154069429450246,72.859635798813 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark12(-2.44420850264366,-5.915133265573624,0.9728878858478764,7.31511930420656E-99 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark12(-24.451556509579177,-9.923296511370722,-0.9999999999999999,0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark12(-24.469756414953366,-87.50478871604446,-59.17611249617312,0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark12(-2.447184851496699,-1.0,-1.0,35.385715075764566 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark12(-2.4494806124438373,-100.0,0.0,-0.5051702794348082 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark12(-24.522475893946392,-48.34759646525449,1.0,0 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark12(-24.576207521128104,-45.09552881171818,-1.7763568394002505E-15,-46.08017587332395 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark12(-24.576927029789573,-36.77611372636329,0.9781193885617875,72.18583213561656 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark12(-24.717624172150924,-58.72783063558928,0.9611732035738465,-0.9698533143503213 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark12(-24.994746040715697,-46.63188266550187,66.16416739626479,56.239118415240085 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark12(-25.02072773037527,-21.495457260257282,-10.66418784948759,-6.643995165021323 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark12(-25.049156478753694,-39.24935285222848,0.011371186362134475,4.976688308929087 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark12(-25.058017528304248,-66.76577666751442,18.795475638581507,0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark12(-25.141209729782293,-15.06038456582452,-1.194806543827732,-1.0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark12(-2.516792252882709,-41.537233326795274,-100.0,1.0000000008154082 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark12(-25.200658511290065,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark12(-25.203493787596486,-37.82711555554301,-78.61612137561387,-0.22394396377360148 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark12(-25.218023374056145,-11.961170146481047,0.0,15.268505705952222 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark12(-25.28077347476024,-23.866527008388147,1.0,-1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark12(-25.283153896174923,-13.23190485334267,0.9303056113587784,0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark12(-25.305224383089666,-1.0,-1.0,-0.8305452551680901 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark12(-25.34191097606808,-1.000000000000007,0.013985789683750888,0.01622948000544361 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark12(-25.37873294612575,-58.73348202662442,1.3877787807814457E-17,-15.913698734126346 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark12(-25.438757853902487,-23.2181607491529,0.8869576356139175,0.10916320704843152 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark12(-25.60404794588204,-65.40301401851855,0.20703935461799183,-0.4471626871979809 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark12(-2.5626237923368924,-54.7998445157464,0.0,0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark12(-25.638756812989058,-23.84852175047054,-0.038906922323613785,0.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark12(-2.5692636468568635,-63.20170967435683,0.0,0.051692199893692586 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark12(-25.717519895821553,-90.58733510898314,0.4340263110889113,-0.9556420565749661 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark12(-2.5723452400135045,-70.42046082670524,0.0,79.15490361852164 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark12(-2.57528679765413,-1.0,-0.9095555405073528,-0.9994203761588414 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark12(-25.768702045861968,-1.0,-0.038141491265681754,0.04821027924330956 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark12(-2.58518753194177,-57.85273975495486,86.74877077100541,-1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark12(-25.898301699845796,-73.39813353116058,-0.02401227667585043,1.0 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark12(-26.006045913024863,-3.4907027046300954,-0.08904365936529501,26.450339929564464 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark12(-26.01326300631425,-1.0,-0.5059951878372606,0.5150077128540097 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark12(-26.113377123379692,-30.415903036983053,-1.0,0.9999999999999991 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark12(-26.15621422465231,-1.0,-0.0051905280909742,-71.54401139621581 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark12(-26.163323943130905,-10.958203073465935,-8.881784197001252E-16,0.020507933628465258 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark12(-26.18721250878545,-1.0,-1.0,-0.7231714208275166 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark12(-26.318155588651212,-29.06669132448298,0.0,25.672047530135547 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark12(-26.389727599090815,-1.0,-1.0,-0.28698935570370704 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark12(-26.421547191588516,-67.24658859844955,0.0,0.9276349676114111 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark12(-26.609604143344704,-72.70549854656737,56.80277432783191,-0.018996528649413202 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark12(-26.73573568759093,-1.0,-0.009300194640302267,-4.525362798030603 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark12(-26.933581700576703,-71.93958960006346,1.0,-1.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark12(-27.026047408664798,-62.553234959265986,0.020084736879049325,83.47693439812656 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark12(-27.11039413842309,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark12(-27.137624560821326,-1.0,-0.47271528899978776,80.89909938604293 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark12(-27.150572099032576,-1.0,-1.0,-10.439974031366113 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark12(-27.18834298914075,-56.91859270146038,-5.695928563226758,0 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark12(-27.19029945385942,-81.0178251475183,-0.06003867356460785,49.730616245506525 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark12(-27.294344048334782,-1.0,-0.2638822115326097,-0.9641000449693303 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark12(-27.304623334322834,-2.300179184924936,-0.9081890701138813,0.0 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark12(-27.34002394683224,-100.0,0.015089297101274057,0.9920601092284398 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark12(-2.735610532190086,-1.0,-1.0,-0.017552703969084593 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark12(-27.38152280860671,-89.27402901699283,0.8770512453667646,0.27334256675317414 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark12(-27.398372215500494,-78.0638755542422,71.67295216951952,-0.8896820608276147 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark12(-2.740540563179877,-51.805178759040786,43.573700160241714,-92.0793106799666 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark12(-27.459445692606828,-53.253829330547305,-5.551115123125783E-17,0.058002980675264375 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark12(-2.750778447704213,-56.42776758220407,-84.30973445774133,-0.5854189728413975 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark12(-27.513513239879927,-1.0,-0.925467980534924,26.941864702626095 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark12(-27.656130008026544,-37.46371574472029,-0.49214719472579693,-34.40914173247515 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark12(-278.687033993419,-100.0,-0.8720544608145886,2112.76124493341 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark12(-27.883020095540925,-11.870920858605787,-0.9596270732054473,-1.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark12(-2.789224872851676,-10.633404474242809,46.736938948078716,0 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark12(-27.96977467677362,-5.555134027826952,0.06027057421837001,-1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark12(-27.975101234658705,-27.004791640109122,1.0,1.0 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark12(-27.9830598147215,-18.734410026539322,2.7755575615628914E-17,1886.7255790974946 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark12(-28.0983374191878,-56.206385426107204,11.403780868357604,0.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark12(-28.098878541895417,-99.82564189788994,-0.02806772521686951,54.24606191352919 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark12(-28.12960116213059,-1.0,-0.03401798843913937,-0.23735542155923642 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark12(-28.134716564728947,-13.070191904500675,0.5099283574778042,-74.78126037416011 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark12(-28.156020089145304,-100.0,0.026699966067760275,100.0 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark12(-28.184214388906998,-1.0,-0.01872521540145212,-34.55459364560904 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark12(-28.19002644112721,-38.51939078600792,-0.024520044143414778,-1.0000000000000004 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark12(-28.211686306174755,-19.141248642591613,1.0,-0.9373340695778967 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark12(-28.289782342573748,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark12(-28.307655101280037,-29.600428807755268,-0.9774988066435003,60.06359169414763 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark12(-28.327426304619436,-2.986678614649415,-0.6111893585429242,0 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark12(-28.45603179366482,-91.24137693408785,-0.6219229493577574,1.0 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark12(-28.459627645924602,-100.0,0.05223663986203847,1.000056484483507 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark12(-2.846089778594484,-29.09884126429823,1.0,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark12(-28.489551770499073,-12.748982289911064,-0.0038890759092010604,13.671464320260977 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark12(-28.508788545988864,-15.561849863944477,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark12(-28.602189921912757,-158.53631675317413,1.0,8.742778913665062E-9 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark12(-2.875073620024414,-4.716065964482084,0.6937912100771888,1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark12(-28.791403693567236,-92.06495028333755,1.0,0 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark12(-28.809590109078556,-10.617111759402036,-1.0,-0.019136892333189243 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark12(-28.83315904546352,-31.542197059645268,0.0,-0.047054767166179394 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark12(-28.898184237976018,-59.30376908933587,-0.9899037900714699,0.0 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark12(-28.96194965550099,-28.972776920336628,-0.8097432474395114,-0.8131940032550486 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark12(-28.995760014466917,-78.60103850001407,1.0,-0.8249570617347204 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark12(-29.077632193276997,-1.0,-0.8214182736436803,72.86104893100006 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark12(-29.157156804262037,-94.64244990330921,-0.009043622359400226,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark12(-29.170539614462044,-1.0000000000000009,0.0,0.7832012235349808 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark12(-29.189750369330383,-96.29041047814258,17.863903257506422,0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark12(-29.194070898258005,-7.775383641118779,-0.6391525993785371,-67.03999637596533 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark12(-29.274365208649854,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark12(-29.38507275000399,-43.12612698024138,0.054656971115167596,1.0 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark12(-29.398521791640647,-100.0,-0.9990730119344878,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark12(-29.450201732131923,-1.0,-0.7783479296867801,0.006883133244192541 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark12(-29.52187659167251,-57.484546486925026,0.4776108711000582,-1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark12(-29.574565487607213,-38.10182347937455,-0.032799218186497794,1.0 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark12(-29.5809761555164,-27.414723802150476,0.0,-0.027225375714691052 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark12(-29.661673705482492,-100.0,0.07222830608676467,-87.10724969026055 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark12(-29.747040401358014,-1.0,-0.04998721579283749,-1.0 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark12(-29.872895509171165,-30.93681542514583,0.05393974296095316,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark12(-29.96799837168365,-50.373634854056405,1.0,0.9592272672144757 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark12(-29.989002868834504,-26.3712039454048,-25.914687736748803,0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark12(-3.0046907476529294,-6.6664110473449645,-1.0,20.068427790264877 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark12(-30.072534804430006,-1.0,-0.011237162102535874,1.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark12(-30.15377245556432,-78.4508270177763,100.0,1.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark12(-30.210225764250794,-24.048990517623068,-0.702639501702864,-0.9999999999999998 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark12(-30.243321535875882,-1.0,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark12(-30.31626795531728,-57.22406881187149,-1.0,100.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark12(-3.037471922474861,-48.64768951294726,66.99263394840233,-1.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark12(-30.390022539073247,-20.28070351128014,-54.12356847406191,-1.0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark12(-30.390075045422975,-49.417824184917,-13.843465173756869,36.906966971599985 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark12(-30.463856353937192,-90.61955649717811,0.0,-0.06255262526174869 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark12(-30.513037801431373,-100.0,1.0,-1.0 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark12(-30.53823638960455,-7.806661660808454,-1.0,1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark12(-30.545326189353233,-32.96007855021979,-100.0,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark12(-30.554431315899766,-83.5555336304504,-1.0,33.43521853430162 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark12(-3.067134217103411,-73.03795805267188,1.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark12(-30.758436486415277,-1.0,-0.02497465680373761,1.0 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark12(-30.81453683490442,-26.743931179419313,-100.0,-1.0 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark12(-30.962774058885216,-71.87308373678087,0.0,1.0 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark12(-31.009384805321734,-1.0,-0.019135329704558553,1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark12(-31.013739799485684,-1.0,-1.0,-0.6841154703579218 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark12(-31.014453537038992,-11.312103626987717,0.0,0.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark12(-31.08905855867969,-8.484583927483527,1.0,-0.6552959140524692 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark12(-31.09299882493428,-54.4213816614319,-1.0,-5.547162708393831E-7 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark12(-31.09410378774153,-38.89198086209231,-99.4618830254557,-1.0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark12(-31.101222881148132,-4.458262249814187,0.0,-0.6238138656009418 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark12(-31.12206743893252,-1.0,-0.5550663519264631,1.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark12(-31.140517658463345,-3.6077822996251943,0.0,0.7027821764901436 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark12(-31.14097028054112,-61.381288682205664,-0.7388093542498798,0.09584771876960418 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark12(-31.172876357079595,-26.128514499825233,-0.6691305823463034,-0.02860577881817883 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark12(-31.174186459504405,-36.16694298911484,-16.391693198338015,1.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark12(-31.191542933251778,-58.77290644645544,0.030789079007507325,-1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark12(-31.274958145902673,-62.49586813058719,0.9463434623121143,-40.59738876299361 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark12(-3.1381473756188267,-66.4880918769285,44.640912473898325,1.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark12(-31.382264312944862,-62.97619041883068,0.0,-41.772431239055855 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark12(-31.49982926885317,-23.991553584002357,0.5008903796766175,1.0 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark12(-31.505157135855598,-54.20657404018839,-1.0,11.209676523739065 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark12(-31.572737485957077,-89.86350172383099,28.487631736944564,53.87323304880695 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark12(-31.760456595726843,-12.771869258710863,-0.05518422992223976,0.8517654213494016 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark12(-31.784083698226297,-48.6692546688628,0.034567237358540615,-0.9999999999999964 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark12(-31.82011544502075,-25.274161221317996,1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark12(-31.827653279302993,-29.379605432418696,0.050559980408593025,-0.6341427228331139 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark12(-31.831945570969033,-92.61630418273948,-1.0,0.04583397287499487 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark12(-31.898454839319186,-85.72531344925052,-87.15887081777316,27.286279262229442 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark12(-31.92123775173825,-49.05122889789594,0.007253759446745253,-0.9168668336832357 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark12(-31.948684242074023,-2.202540320468273,-1.0,-43.775091920380845 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark12(-3.201950034483027,-67.64103296878156,-1.7763568394002505E-15,0.14334346275542043 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark12(-32.1927032626097,-100.0,1.0,0.9999999999999971 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark12(-32.21318924254548,-77.76281811550749,57.29614818047824,-68.12533492614669 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark12(-32.28584080059218,-30.33819968322293,7.511588560124378E-4,-1.0 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark12(-32.45475987774928,-84.05300787695336,-1.0,-60.88671734687492 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark12(-32.461283674903996,-9.12993197844119,-1.0,-1.0 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark12(-32.488526874597866,-97.1175283186843,-0.028374789596794014,9.490736769288205 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark12(-32.49139162520362,-98.66466752583119,16.85446587256527,0 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark12(-32.5085761108022,-95.19693783847133,-0.03224783850510149,29.84688554331373 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark12(-3.2518587268939374,-45.54388089839319,-0.3661809183757754,1.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark12(-32.59639553897885,-22.764442928072,0.0,-1.0 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark12(-32.63236072576937,-86.30920348621642,-1.1102230246251565E-16,0.9999999999999964 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark12(-32.662255083025194,-28.73203238458215,0.0,1.0314803225067362 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark12(-32.66683516256462,-1.0,-0.02951965956035435,-1.0 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark12(-3.2677305551569065,-1.0,-0.04444132330803541,-71.87839132797227 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark12(-32.68810325968055,-18.74741994641859,-1.0,0.8078992320746183 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark12(-3.2788722479569063,-100.0,0.05655873607231126,0.0625993738149503 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark12(-32.86792351593178,-38.319752687573825,100.0,0.6872489774942464 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark12(-32.890942966361386,-1.0,-1.0,-1838.1751361112497 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark12(-32.904636040100854,-36.92849228294784,1.0,-0.817776138583136 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark12(-33.04692128095511,-94.95453964337354,1.1102230246251565E-16,2.5082546261411557E-4 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark12(-33.0650139054207,-50.94640133349466,0.0,-5.473635484076266 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark12(-33.147788212177815,-61.84241321912809,-1.0,0.049162045174323765 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark12(-3.317810356509939,-41.81782884627332,-0.5894404911504939,-1.0 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark12(-33.198426477333925,-47.26164593347406,0.0,-0.7556930762280264 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark12(-3.3237715184561925,-2.177770940817405,-0.9458187605125095,-1.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark12(-33.503266822686,-20.70429803839893,34.96855871749773,-82.48018871191167 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark12(-33.694430847501025,-10.51335162079758,0.9811521602715163,-1.0000008930866562 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark12(-33.702567492211756,-1.0,-0.8112009676320745,35.223267217534485 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark12(-33.731570447305785,-1.0000000000000036,-2.7755575615628914E-17,1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark12(-33.910587047072596,-3.1487969850742177,86.59445022218249,-0.6189738111945549 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark12(-33.9599553582223,-38.31204806009272,-0.05503170576014965,30.19596423489621 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark12(-34.06810412248229,-100.0,-1.0,1.0 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark12(-3.4273156254502295,-9.14867497033416,9.553065001574357,-1.0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark12(-34.30829526607862,-1.0,-1.0,-40.232589908090866 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark12(-34.32229654517265,-46.79327262160619,0.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark12(-34.342410095134966,-81.54094268542536,-0.057047974269333945,-98.51534097530352 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark12(-34.356537945667824,-26.875044433471754,0.479753383012446,1.0 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark12(-34.368920594087086,-1.0,-0.058469061599447425,0.7128791320028722 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark12(-34.5571647385206,-89.36899891125654,0.05387139432621376,0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark12(-34.597782769564915,-77.00202213040417,1.0,68.3865135053855 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark12(-34.60917483322983,-75.8977948875843,55.24069211429236,-11.299860681667312 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark12(-34.61330373158606,-58.239251832310416,0.23744568868795402,-1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark12(-34.6739808231672,-89.73480491753875,-0.5456594651670434,-67.47385239183687 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark12(-34.678154305165805,-62.39365627138848,1.0,22.387039756996376 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark12(-34.753738332464586,-40.23817098397706,-0.9537677239110753,-1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark12(-34.78746817112619,-25.700388537205725,27.19659000786656,0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark12(-3.497784648487918,-39.60232646818566,-1.0,-1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark12(-35.03920779168215,-1.0,-0.500333232598284,-0.3592836364960594 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark12(-35.08723514566319,-1.0,-0.6607900051605049,-0.023800946595706182 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark12(-35.14450040592695,-1.0,-0.2689192315369793,-7.3024916455161835 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark12(-35.235229446734024,-5.577889799811794,0.0,0.4311478555566841 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark12(-35.29146756141305,-4.967820291581237,-26.785351574670905,1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark12(-35.32629432515978,-100.0,0.045162514346313465,-1.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark12(-35.340926945559644,-1.0,-0.9868458034731671,-0.06451132786155314 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark12(-3.5398284492516865,-72.21233673833609,-89.04515536354347,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark12(-35.532651724855945,-49.14457764174803,-1.0,40.726689994938134 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark12(-35.587523764917755,-1.0,-0.02019297544461742,-8.572556768529552 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark12(-35.72223510168259,-57.45983971451124,-100.0,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark12(-35.78028112292694,-1.0,-1.0,-0.007357061684198918 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark12(-35.79325807379155,-26.59125420767419,1.0,0.012573049301853656 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark12(-35.79989372956096,-99.86235165863113,-0.011602428231745421,-0.8646282987999707 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark12(-35.81583168025149,-24.40536064759715,-42.5450582446919,4.656540491284829 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark12(-35.849038943079314,-8.168975506793958,0.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark12(-35.85118690871438,-1.0,-0.6166109834891162,0 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark12(-35.85250794035355,-30.88633459457906,-29.14397976424944,-0.3123442657635632 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark12(-35.890932326868686,-71.04563310014515,1.0,-0.004028315798648609 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark12(-35.92802625061577,-83.79800429460317,0.05394695927646981,0.2914780517009079 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark12(-36.05052332512624,-36.26289096512008,-38.031544537321565,-1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark12(-36.0970271340987,-21.25411895598996,1.0,1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark12(-36.10621615780689,-1.0,-0.9998883316238578,0.4843156304635162 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark12(-36.10790354054937,-1.0,-1.0,0.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark12(-36.147710554405954,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark12(-36.19107322819781,-17.591980137526456,0.0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark12(-36.33541093384978,-1.0,-0.06031282824134415,-1.0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark12(-36.38137473906263,-89.30292786636387,-1.0,-0.011550603696989013 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark12(-36.479815745420495,-81.81232778170403,0.7352928282548492,0.6529676011666605 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark12(-36.53832876930072,-1.2363684894105091,1.0,-6.266900518457547 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark12(-3.6551923187895277,-74.64682578492132,63.02405133098254,0.023651999858997165 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark12(-36.62837043430347,-68.74131354352215,0.036012230235259346,-1.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark12(-36.699277080119984,-1.0,-0.3158559839906807,-67.00356187818169 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark12(-36.728771241698546,-34.60464352981772,1.0,1.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark12(-36.86681160775982,-1.0,-0.0308667843037926,0.06255968764988828 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark12(-36.9017515115664,-46.68572286763705,-1.734723475976807E-18,0 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark12(-36.93940761824596,-68.60301358014202,-1.0,-0.061235357534735996 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark12(-36.944764829579746,-9.476564828617384,1.0,-1.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark12(-3.695641439375169,-39.362130662503525,-0.9775817546744555,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark12(-36.95755248585189,-100.0,-1.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark12(-37.01639683346549,-55.55937617707216,-46.5037965249582,20.16348014650879 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark12(-37.13132399285545,-59.86568961035482,0.9776576308905709,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark12(-37.22380991762125,-6.230326725086002,-0.010925519846027631,-1.0 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark12(-3.7241379389416487,-20.69667625066039,0.035355353683948175,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark12(-37.406662762479684,-1.0,2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark12(-37.42022576192928,-84.95559629297372,1.0,50.93001076806323 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark12(-37.46837301468557,-42.35104407027971,0.011521646546747274,-1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark12(-37.709136511792565,-68.7764071431593,-0.0471209084877324,-1.0 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark12(-37.73474124607288,-42.17026965517914,-86.98658405395298,-1.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark12(-3.7777941561086887,-35.8215115403803,1.0,0.9461301947776581 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark12(-37.78359328957149,-36.750623145668136,0.9999999999999964,45.255525933567625 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark12(-37.8051736310457,-71.6192101120979,0.36363578994430207,0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark12(-37.81429255029183,-74.94240965310894,-0.06112591463420915,-4.716488593039301 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark12(-37.8421965456451,-61.46845210997068,-0.5274348418494504,1.0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark12(-3.79240378773092,-47.22962099829882,-2.7755575615628914E-17,-0.9999999999999982 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark12(-38.06061513867972,-83.22514035021354,0.9581749909029524,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark12(-38.09616161249641,-1.0,-0.9288275512187832,70.93092467231575 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark12(-38.17132699505961,-37.99125783025926,-39.0046557806507,1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark12(-38.18004415627121,-11.543588302274953,1.0,1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark12(-38.20557424508612,-63.66060468360678,1.0,-0.05157064157820157 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark12(-38.356894537943006,-46.672461193395826,0.0,-62.31982732756033 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark12(-38.38596554995081,-74.85534692510443,-0.0468420109789367,-1.0 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark12(-38.43261737337999,-30.654873545346632,0.6979403766551007,0.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark12(-38.46127874661524,-51.26454779184671,-0.967167664128296,0.2127313204390998 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark12(-38.533562366929985,-38.072926468961434,0.007825524182431043,0.024657511374951646 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark12(-3.859132716317389,-40.45191438749018,1.0,0 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark12(-38.629303890326,-49.32793040014276,-1.0000000000000018,30.959943979247605 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark12(-3.8668896347154202,-26.309730353346836,-1.0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark12(-38.734129529781654,-43.270610230833825,-60.913042931701234,10.48476442491264 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark12(-38.9001739806023,-73.76554283789565,1.0,-75.4757126905093 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark12(-38.9053839564122,-42.91680654186496,-1.3877787807814457E-17,-1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark12(-38.9651723726661,-83.14800211355731,0.027381636476210003,1.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark12(-39.029805454819886,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark12(-39.03974325195537,-1.0,-0.037362522839117784,0 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark12(-3.9048997983578766,-48.336646232990645,0.9059197281883743,-70.95485005302884 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark12(-39.07385033301731,-67.52320495793334,65.60386761643778,-26.716379366857865 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark12(-39.093113388381155,-22.884965684806666,0.049433226134544817,0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark12(-39.12938371564317,-178.6608650380922,-0.882056557382854,-2158.4160132385086 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark12(-3.91410852211473,-1.0,-0.3052843584775126,-1.0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark12(-39.3133777097983,-63.137710825907874,0.0,1.0 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark12(-39.31683287174166,-32.22710035517755,-1.0,-45.27222058399023 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark12(-39.38569729889731,-70.6451869237556,0.9999999999999982,-1.0 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark12(-39.40188719585156,-14.360581202544187,-0.03014384159447403,1.0 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark12(-39.45898450895674,-1.0,-0.7269814438339836,-92.2374710628642 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark12(-39.49801485941481,-50.65698009379972,-38.443700800687324,1.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark12(-39.50037074085895,-22.335380711610195,0.0,0.29377466769223215 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark12(-39.58838707674846,-72.79850393692611,0.058095330200673714,-0.9744889670310474 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark12(-39.614032675491615,-12.34684083680662,-0.8595714307443387,-87.20141916728599 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark12(-39.857485097334155,-43.28504902814909,-1.0,-21.628182251183688 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark12(-3.9873334333607398,-6.960828987610593,-0.04190398303119974,-0.04464049082587796 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark12(-3.9930936351040884,-1.0,-8.881784197001252E-16,-60.72827548045521 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark12(-40.0261793365856,-1.0,-0.015527036981577313,-1.0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark12(-40.02883642293332,-15.581155072629155,55.1010878931143,0.051572490955103745 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark12(-40.0500302743672,-50.517573909867984,0.9198198070040253,-76.31819257406795 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark12(-40.17451618010924,-15.65391437417553,1.0,-1.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark12(-40.192997722353546,-55.03614343665716,-7.468271788673288,0.6881241176434152 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark12(-40.40899909173194,-22.92707127938769,68.98410069486206,-55.454176742046734 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark12(-40.41002049011966,-36.22347475637494,-1.0,100.0 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark12(-40.43267179259138,-1.0,-0.9999999999999982,-0.1703350105499979 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark12(-40.453120416985996,-11.068936125019006,-25.168088041450982,-0.05589421095120346 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark12(-40.46039086395637,-1.0,-0.6290050039045083,0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark12(-4.046498866531834,-1.0,-5.6902623986817984E-160,0 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark12(-40.46685053965523,-53.287400053081114,-0.8238315425212885,-33.54184523202112 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark12(-40.46887522625542,-27.145276343721378,-0.5512111077002521,-1.000046627007764 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark12(-4.047602028525194,-16.105514190685597,0.9999999999999929,6.722447208446914 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark12(-40.51391971185061,-100.0,-0.021419680665692595,1.0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark12(-40.588326144700424,-19.811300648616893,-0.017762051880618603,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark12(-40.64916920413154,-52.16680642434321,46.17027044335563,-0.7070907895846261 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark12(-40.714389456883,-7.896439952667726,1.0,-1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark12(-40.760213570511944,-7.9932787137716845,0.7166294741627377,-0.8420956977065543 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark12(-40.79283643071495,-1.0,-0.9435040702130655,0 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark12(-40.82489625170253,-43.91396948696884,-1.1102230246251565E-16,-0.07956930225435732 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark12(-40.82497530820128,-1.0,-0.024572685343126364,-1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark12(-4.083852316941858,-1.0,-0.9508994099329667,0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark12(-40.848222358746696,-34.96503565636799,98.02565349110228,-6.897670020038248 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark12(-40.90769654542874,-1.0,-0.9041563341651857,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark12(-40.96729224957278,-1.0,-0.09752772286563637,1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark12(-41.048745454491375,-77.30588244676127,39.415255821229856,0.011011460664414885 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark12(-41.10189649597536,-1.0,-0.8020188133655175,1.0 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark12(-41.14329234134919,-42.18407293330888,0.972478254796983,1.0 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark12(-41.16941296551898,-65.78752059145518,-0.9799287631224943,5.722686457586033 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark12(-41.17993114790019,89.8306704692479,0,0 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark12(-41.20873912578184,-43.157077209784504,-0.9285391987438063,93.37200849043447 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark12(-41.21652473955752,-100.0,2.7755575615628914E-17,26.619773391623475 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark12(-41.23053558755314,-91.29012571296357,-12.466609265892473,1.0 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark12(-41.28986804579717,-40.7571105761146,-0.9814668261386645,0.056937090827517 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark12(-41.356242858905965,-1.0,-0.6197047632546263,-6.018531076210112E-36 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark12(-41.369021346250925,-99.93357366776792,0.01608945925247312,0.536775830902108 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark12(-41.45561085315166,-28.743831107062157,0.0,-0.7045200782275353 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark12(-41.48446027530859,-17.49119717453259,0.042169691836042134,-1.0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark12(-41.501868108125976,-9.67309531348208,94.01232520813576,24.87669259513214 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark12(-4.151522957580396,-45.490117330771916,0.02840616482892936,-0.11238193194123014 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark12(-41.63657513928632,-22.67467073364245,-1.0,65.07911649167457 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark12(-41.67798520742609,-32.91060669233982,0.0,1.0 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark12(-41.71063926002236,-75.49483499539748,1.0,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark12(-41.760920326818194,-89.41800210389167,0.047745972546153995,1.0 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark12(-41.79240240339103,-31.9424383345918,-29.645315428307605,-0.2628931812850148 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark12(-41.80799933070689,-1.0,-0.4334573431963067,2200.015973761536 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark12(-41.80978302440026,-30.97551117072277,-1.0,0 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark12(-41.90864940178858,-1.0,-0.03546636121290293,2090.59513906672 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark12(-41.963185275321216,-1.0,-0.00305071444007185,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark12(-41.97450532445735,-1.0,-0.9545703670151252,-0.9579056732714217 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark12(-42.06746297954819,-1.407764705212954,0.026536223201054643,-22.089714474285238 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark12(-42.11872527920624,-1.0,-0.9697839673209159,1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark12(-42.26833605891608,-66.8913053292269,47.356138097131485,1.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark12(-42.38536683757243,-1.0,-0.0013978513205179046,-0.06255307207456082 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark12(-42.38734596975086,-1.0,-0.00916085290342794,-0.9999943991252409 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark12(-42.39333709420795,-16.851134523914567,-73.82372306565222,-1.0 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark12(-42.400387475875384,-63.22208372966945,-0.05566043210430888,-1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark12(-42.400616736448654,-39.82097647454785,0.0,-75.56425091149532 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark12(-42.442392899704856,-100.0,0.33232694893405146,0.9047652910557524 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark12(-4.247005158475306,-6.201995927685837,36.639120670873254,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark12(-42.481132669586835,-19.295571343042894,1.0,0.12269587096893941 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark12(-42.52804907195136,-41.237234565089274,-1.0,1.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark12(-42.55490502719134,-19.74679498083286,-0.4798085734456905,0.7225717757726531 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark12(-42.58220939656491,-1.0,-0.027757160013479817,-11.818341921159368 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark12(-42.60349714402541,-57.2095474754333,0.37503909292354365,33.83592060797872 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark12(-42.61478806282774,-98.34659387956611,0.044008770206104754,0.9999999999999867 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark12(-42.664622134747034,-48.612153540824615,7.739890149271936,0.0213716112396016 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark12(-42.69248091952179,-137.29043610187477,-1.0,-0.25560956928332246 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark12(-42.70725446117079,-43.10571159354758,0.9286029077667239,0.8008215855201719 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark12(-42.7305799015912,-1.1485093722902402,-0.9787125722765375,-0.8923486616777732 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark12(-42.74988767131972,-6.826104337156762,0.0,-1.0 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark12(-42.7618617081965,-69.00544556018161,-0.7787962472442842,-0.9828150020655508 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark12(-42.779788106662416,-7.713677295056131,-32.56777522246978,0.009969753761503306 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark12(-42.812664060798,-58.194753316498414,61.85542339158218,0 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark12(-42.83964539802149,-13.768632041774726,0.0,0.728673410792279 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark12(-42.86686467424491,-41.907958596012705,-0.04398418330632285,-51.775653523123815 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark12(-4.290491602277915,-1.0,-0.03429504192702123,-0.013835461774285185 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark12(-4.298579341815606,-1.0,-0.054074152889121374,-1.0110194067305818 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark12(-43.001670696977314,-100.0,-0.03438872902384789,-17.48878318340222 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark12(-43.07372647660641,-92.19013605224097,-1.0,0.4216086440595843 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark12(-43.0756905816373,-1.0,-0.02603576431179738,-1.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark12(-43.107270768956774,-1.0,-1.0,-0.45338664509795135 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark12(-43.12078945781612,-27.521604798697673,70.14507779626891,-1.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark12(-43.566348959016274,-61.34521967175761,20.01804534848921,1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark12(-43.6432781630684,-26.106690239464875,-0.10435135086298664,-0.9999999999999998 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark12(-43.645383076747436,-100.0,100.0,2174.4744723517524 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark12(-43.68767023135468,-10.570163823581062,-1.0,-43.291132463345896 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark12(-43.70465958505546,-100.0,-0.04478895238236924,32.27748884739096 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark12(-4.371665945326313,-97.94236968038454,68.78849126756987,-0.20822937580543055 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark12(-43.71900133379116,-95.05759412093373,-31.865913413593418,-70.90146412780898 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark12(-43.843605515252015,-17.30355163492085,-1.0,-6.929057646442345 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark12(-43.85465796681947,-1.0,-0.011229316200093185,1.0 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark12(-43.89907746721328,-22.46480411722176,1.0,-81.82497344434307 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark12(-43.948195436919924,-2.264933587280595,-33.47100638077505,0 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark12(-44.0250869142871,-44.503390355928005,-28.7826887353434,-93.31305818331914 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark12(-4.40764666434735,-100.0,1.0,49.97400427673972 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark12(-4.409049677433757,-1.0,-9.165075780814824E-5,-96.56914699654551 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark12(-44.118459547008555,-20.25240582404998,-1.0,-100.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark12(-44.18103805113222,-29.48480251106829,1.0,-82.0392016599889 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark12(-44.186524722533214,-79.91452065112163,0,0 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark12(-44.22277356657542,-9.205255333332657,-1.1102230246251565E-16,0.3575216975812481 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark12(-44.23562986615098,-4.230525860968846,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark12(-44.239784953281315,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark12(-44.2789914618852,-80.70516639556126,-1.0,-38.62586436049561 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark12(-44.3635250794847,-32.419374841971226,35.142949626233644,1.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark12(-4.436559349721021,-17.109143896231586,0.9230581028549152,2274.569100744976 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark12(-44.46298933430399,-1.0,-0.3197610572094254,-75.96953687215462 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark12(-44.51770803767324,-66.0938178698995,0.9999999999999982,0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark12(-44.53861454152278,-46.378575372346646,-0.03498552128036036,1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark12(-44.554835631790596,-27.58178165429456,-0.01198093906406042,-1.0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark12(-44.640791784202726,-3.930424105217952,64.48044103050296,-1.0 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark12(-44.68886864055163,-65.46461805095561,100.0,8.673617379884035E-19 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark12(-44.69419865112221,-50.15715668670955,-1.0,0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark12(-44.71004581129373,-35.50887708108292,0.49707302230938244,-0.9550695076565339 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark12(-4.475683293063136,-20.877143259513982,-0.004917306962214332,-1.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark12(-4.480374539162285,-48.992008098809166,0.98688178277092,16.499413090630224 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark12(-44.809421972675096,-1.0,-0.011463508980223169,-1.0 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark12(-44.88736066852449,-1.0,-0.022755191384107754,0.689656715948028 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark12(-44.92406706975346,-19.43956671139268,-28.546162029983602,0.8703284865476179 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark12(-44.92938498822505,-23.700079181709555,1.0,0.6793653886024698 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark12(-44.94080791022442,-78.82495477995266,-0.9446230464499505,-0.051078713809091764 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark12(-45.06020838048192,-37.96675706558638,25.954162044506816,1.0000000000000036 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark12(-45.09054168140055,-33.622242958752494,-1.0,1.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark12(-45.136612553625696,-100.0,-1.0,-0.937464023250076 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark12(-45.164464693006515,-1.0,-0.9999852894451949,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark12(-45.16679284203729,-1.0,-0.026182982473708566,1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark12(-45.18114524588903,-32.38461619112857,-0.018592796226084708,51.548096788689065 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark12(-45.1831963174973,-12.45400494304102,-0.006724681418381395,-0.4111990696582204 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark12(-45.268105637691505,-33.92065566022046,-62.86553295029022,2445.487438520104 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark12(-45.31321226395264,-91.91728638847874,0.0,-91.76734840072518 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark12(-45.322690677122026,-80.01385859494546,28.94255218609935,0.062556121512807 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark12(-45.39940396217038,-1.0,-0.29810998448789094,0.04316170545970191 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark12(-45.419047530562274,-3.802009331067107,16.902555436093174,1.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark12(-45.433278050895915,-1.0,-0.032192640315347076,-1.0 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark12(-45.50803589874952,-57.025581343724866,57.64241255461354,31.44956300745966 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark12(-45.593944271718954,-71.57880868588563,-1.0,36.455437205485076 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark12(-45.72065389019559,-92.5081934823591,1.0,-100.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark12(-45.75021191866626,-5.597287460707136,-1.0,0.05992392752235931 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark12(-45.76422553758095,-7.492480326916805,-49.74391508585381,-65.67350568462231 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark12(-45.93547354655137,-1.0,-0.9974799841788247,0.9999999999999999 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark12(-45.950656272004856,-1.0,-0.32576550899866397,-67.3366156989053 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark12(-45.95121790762888,-19.245625190007345,0.9999999999999982,78.9351222877757 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark12(-45.98949864971977,-56.24125647160181,1.0,38.03234983707543 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark12(-46.02371386968059,-76.90281376726995,0.032521176470413415,1.0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark12(-46.21624674728105,-100.0,-59.531565786703545,-0.9642921146512433 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark12(-46.36281101166431,-12.22204502550725,0.6856365007774823,-1.0 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark12(-4.638724363381613,-86.10640653170458,-12.995687712938661,0.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark12(-46.40764013472576,-41.05925015757814,2613.3621656056166,0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark12(-46.45859935697557,-48.90308972888987,0.0,-0.9999999999999998 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark12(-46.47854247782726,-1.0,-1.1102230246251565E-16,-1.0000020992626464 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark12(-4.6494742807900735,-15.795552544433557,1.0,-2321.126142370844 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark12(-46.584660329298494,-99.81326302776132,-0.9523934184485445,1.000013795419841 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark12(-46.734764404001396,-1.0,-0.548856887377843,-1.0 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark12(-46.8279395695892,-76.60542743437777,-0.1401197778419232,1.0 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark12(-46.86875461133744,-36.10016530622664,9.249182484351465,-16.139420038737384 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark12(-46.89626314297552,-1.0,-0.1184520141187974,-0.06130580442458005 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark12(-46.89737909763141,-79.1102680491182,-0.02050280286969149,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark12(-46.957180666757466,-58.82224935254562,1.1102230246251565E-16,1.033503740834524 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark12(-4.6969894748063075,-0.9999999999999964,-0.670959955348724,1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark12(-46.98339594586291,-1.0,-0.054476036226567305,-1.0000017808193706 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark12(-47.0307029707431,-10.081587891651566,-36.59430620528346,0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark12(-4.704415637167385,-1.0,-7.241256126212595E-16,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark12(-47.09023775047049,-28.55855881425605,-0.011974783677399113,0.9245397068286967 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark12(-47.107602799322336,-76.954560314361,1.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark12(-47.116659137189274,0,0,0 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark12(-4.715043050234279,-20.879524477840842,-30.572149408259985,1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark12(-4.719424660697456,-1.0416650065798705,-0.050994804122462115,0.7630469725377724 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark12(-47.20389785510771,-87.658682564465,0.0,-1.6867516709168837E-80 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark12(-4.72427385460227,-30.303729104690255,0.0,1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark12(-47.24631380792094,-87.33128713072594,1.0,0.03307265359069324 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark12(-47.27592180265675,-53.61366594108134,-1.0,1.8991135491519597E-65 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark12(-47.365689583333385,-36.81281843154331,0.0,43.013954085166475 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark12(-47.450242030237966,-39.50400647343087,1.0,-0.37824627666873006 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark12(-47.4698057530266,-1.3895522833124312,0.10269816851664659,1.0 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark12(-47.57206929246919,-71.10554211643063,-0.9308038772217273,-29.02097069007261 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark12(-47.898426080075446,-29.249506553835843,1.0,-0.008948405765206613 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark12(-47.94712452882671,-68.36466718324243,44.66476283534797,1.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark12(-48.09546379419403,-41.19015892874152,-0.030984486178365356,45.37549764119191 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark12(-48.10472375633529,-27.46272186327468,-0.11860206662365758,1.0 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark12(-48.10661925992847,-5.059241980311839,-41.42961252010284,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark12(-48.12785439132863,-18.43706299677924,0.0,26.1106171327253 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark12(-48.23338765476396,-1.0,-0.7172505838593111,-20.65374803411601 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark12(-48.3199477353891,-32.28325865229955,-89.29996951485563,73.80147446920401 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark12(-4.837689247665547,-70.54967954206144,0.9987743223836398,-0.05253029573640333 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark12(-48.40998808663376,-58.85934345595447,0.6555238523444863,1.0000000000000004 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark12(-48.41549865387018,-1.0,-34.19792853522802,0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark12(-48.51415617216164,-60.3850672677389,0.016299188991239097,0.6912974658492451 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark12(-48.51891995313225,-6.966346140412028,1.0,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark12(-48.596213273882654,-61.3374187886455,0.0,1.0000004055686889 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark12(-4.868291549222064,-55.60405816624649,0.0,-1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark12(-48.719528779190036,-47.955401564660875,-0.010170821349881263,15.037647036175038 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark12(-48.73417587763652,-22.948163932865867,-0.9999999999999993,0 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark12(-48.751887333902424,-32.1378846071421,-1.0,-59.31220683100468 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark12(-48.79222753616341,-1.0,-0.021607469272878238,0.0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark12(-48.89387973691151,-79.0821191266541,87.1572232575163,0 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark12(-48.94489553227842,-46.644045066925855,0.0,-15.866590488914586 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark12(-48.948742707241855,-58.42382632862411,0.16675620647678446,1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark12(-48.992867674528945,-43.35004897068855,1.1102230246251565E-16,0.9999999999999991 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark12(-49.014583292548906,-23.224407527191048,0.8758821098564893,1.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark12(-49.15107500792402,-74.41994208355482,1.0,-93.63358155174997 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark12(-49.166224547683285,-59.08214925416925,-1.0,0.9703131009231768 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark12(-49.166302656152126,-1.0,-0.04309323003838551,-4.2168791772922093E-81 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark12(-49.17996666110025,-23.087726117893553,-0.709622717383489,0.002305758062528973 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark12(-49.217719579950405,-34.50828260098647,0.015080712248138173,16.846725823844313 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark12(-49.22664656117318,-3.8437225200298673,0.9670860917563676,-0.41428683911213776 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark12(-4.923735512322296,-1.0,-0.016553838555162598,0.9073663543168622 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark12(-49.240079424750306,-75.88868858469553,-0.015281750508910145,1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark12(-49.32354161526643,-16.30355440740721,0.6801990458467357,76.4519806031198 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark12(-49.44687555041413,-1.0,-0.9460901842607861,51.234242570219884 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark12(-49.483913850389726,-10.689656750592857,-0.9999999999999993,0.9732927499264782 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark12(-49.49089835936577,-1.0000000000000093,-0.9229247278583017,-59.36395855335841 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark12(-4.958866603750581,-1.0,-5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark12(-49.624276852855054,-4.567810894141601,-0.9898336222677104,0.8041202858282166 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark12(-49.66251974602909,-1.0,-0.6814505594642921,-1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark12(-49.697937083654644,-27.026484979818427,0.26227839615663395,-1.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark12(-49.74021736871579,0,0,0 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark12(-49.79805962351932,-1.0,-0.8611294052217486,1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark12(-49.837815781505654,-56.438647651285436,1.0,-0.9999999999999999 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark12(-49.866980174842304,-16.47903559137029,-0.05303003721573807,-29.055130686273657 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark12(-49.90344518020715,-30.912827400687796,0.0,45.53726357411561 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark12(-49.91138413670816,-32.31208165188604,0.01706450737528111,-1.0164126933519773 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark12(-50.058085921132104,-32.27670153200376,-0.028339135132861126,2.822208065909294E-4 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark12(-50.193383962510495,-31.651883327311552,-1.0,-0.9652483373756575 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark12(-50.19403281938153,-12.055578951358758,-39.60330264629245,0.4676342971576436 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark12(-50.2046067633192,-21.27372212844833,-1.0,1.0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark12(-50.20487229301391,-75.99581914688893,-0.422408165321992,-0.03113342082412955 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark12(-50.23715059337739,-30.092686765377366,-0.2823224994339961,-0.019450609685660036 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark12(-50.39880953948415,-77.79423145786146,-0.006923516119601086,0.6714788140960455 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark12(-50.43692982354375,-11.045032854576704,1.0,1.922958150121795 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark12(-50.57922090969463,-26.16312741166172,8.881784197001252E-16,0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark12(-50.6122867735755,-94.18480132230914,-0.9097523704978359,-1.0 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark12(-50.73972581727375,-54.698197545908926,-1.0,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark12(-50.74092220221842,-47.27987363917126,-8.929257177497746,26.57315787210534 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark12(-50.75611939498345,-1.0,-0.6926977507492721,0.9346023338636313 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark12(-5.079419663088031,-10.243749480199165,-1.0,0.1738989151988475 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark12(-50.80921984140967,-74.3076588389181,0.0037657285578793533,1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark12(-50.95421714459014,-0.9999999999999998,-2.7755575615628914E-17,-8.008258197932001 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark12(-51.006750639895664,-94.88898167779746,-0.12527424339529059,-0.9996486887113648 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark12(-51.131911647365534,-1.0,-1.0,-0.7739126338777554 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark12(-51.13603669526439,-1.0,-0.062338570523287146,-0.4002239688883942 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark12(-51.17600060367242,-87.18172789701455,48.257232787794635,0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark12(-5.120824551121287,-100.0,0.0,0.059261485014931475 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark12(-51.21637605703561,-39.11050771475274,0.011665883096368616,0.9457690307262973 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark12(-51.41412517720075,-49.20303281303653,-1.0,-0.9744543286296109 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark12(-51.42767024762571,-46.87357402633937,0.033701936554419755,-54.50536423792506 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark12(-51.44522126070861,-52.30638278470816,-0.6756217640042226,8.470329472543003E-22 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark12(-5.175062940384656,-42.21462604686425,-0.016311448544789456,85.08564112268098 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark12(-51.76758049810193,-3.6255254165965325,-42.37276506648041,1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark12(-5.188972425608473,-9.575397268253546,0.0,0.0 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark12(-51.929862095158356,-34.34781020563243,2.843538488498754,-1.0190935731375197 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark12(-51.95384905051028,-49.38430746995569,-0.48326707291573007,-0.9999999999999999 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark12(-51.965940250846444,-48.13423974097443,14.140180826580295,-0.9999999999999964 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark12(-52.014618224185625,-95.04648814304304,-0.9999999999999964,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark12(-52.31765717732173,-60.94703640366453,1.0,-0.025644086123842363 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark12(-52.35170059878034,-21.482390690246426,0.015508394619753873,55.32158193749908 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark12(-5.235513916789785,-135.36356065597434,-0.9999999999999964,-2191.085762502684 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark12(-52.356550291839284,-35.14201257545444,0.9999999999999996,9.359247624049084 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark12(-52.39418111037487,-55.45799206746455,29.03640133465491,1.0 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark12(-5.2525276153441816,-1.0,-0.9713138466671523,1.0 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark12(-52.5613024851991,-58.91557095487816,1.0,-0.2806998264249241 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark12(-52.5993958525402,-18.124973611678683,0.3994607634395966,3.0699156354170682 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark12(-52.691590041811736,-55.938186636095594,-1.0,1.0 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark12(-52.76081861653819,-1.584189247846397,0.04543966929905907,-1.0 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark12(-52.775977942871855,-43.083085150994634,-0.7658325794331766,0 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark12(-52.812445115704556,-1.0,-2.9478839920228987E-15,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark12(-52.85090681345142,-71.01580870046223,73.2725300025802,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark12(-52.88778137364956,-28.04656998588773,8.151139946351165,53.693633615593626 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark12(-52.89144013907865,-48.29002966637612,69.49267530349283,0.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark12(-52.90106005659201,-100.0,0.8898641758103912,0.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark12(-52.962070478128354,-43.82398468707449,-0.7026363404909262,25.268441745748603 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark12(-52.97781067084747,-56.346776302618565,-6.181742786876587,0.9731218032959338 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark12(-53.063642209597575,-68.14909089479411,0.0,1.0 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark12(-53.11896239930856,-4.054711663243095,-0.9837247957847174,1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark12(-53.15642175126619,-1.0,-0.46230681554113673,0.9990684062268621 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark12(-53.1645326872658,-1.0,-0.9991613837134984,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark12(-53.19702466946599,-1.0,-0.7720462996647127,-0.509637316768275 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark12(-5.320393227106663,-64.31143924993232,-0.03953230517983085,0.9999999999999999 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark12(-53.258243788214585,-47.35366410637437,0.0,5.98538458741945 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark12(-53.28724286260007,-55.14964622322002,-1.0,-0.9999999999999981 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark12(-53.32125265772358,-46.709224086852956,0.8512350182883196,-0.0741519847862187 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark12(-53.34886916988872,-57.82370881578938,-100.0,0.3616026329017401 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark12(-53.35424228984709,-1.0,-0.8533512921158222,1.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark12(-53.45246633828075,-1.0,-0.9717921378576947,0.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark12(-53.520591007150124,-16.250155162832886,-1.0,-23.490279081615935 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark12(-53.55789926141695,-1.0,-0.014125318999765026,-10.478227462685927 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark12(-53.5690803603659,-11.647715653468259,0.0,23.192918537427 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark12(-53.57951357666585,-100.0,1.1102230246251565E-16,9.016580681431383E-131 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark12(-53.60002491469826,-11.562283853467973,-0.05168637252052186,-0.6345415145794263 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark12(-53.62027941436685,-59.51963619051304,-0.36168456862699827,23.75090404855898 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark12(-53.63029762150127,-29.492861276105646,0.0,62.11145916315368 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark12(-53.70685359864436,-1.0,-0.9649395692325782,-0.8447753534795281 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark12(-53.95500208967617,-26.905183245970008,1.0,52.502026131084016 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark12(-53.973222413800954,-49.63415553513784,-1.1102230246251565E-16,0.02566862546222585 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark12(-54.219701081797574,-42.08412600242565,0.9999999999999962,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark12(-54.27887067036696,-1.0,-1.1102230246251565E-16,100.0 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark12(-54.28011412223133,-1.0,-0.9995467390387476,5.537614812009859E-6 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark12(-54.346760674305294,-61.572413138549855,-0.9535045676447136,-71.23049530557505 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark12(-5.441569373495143,-1.0,-0.5830088202162995,-0.5392369145822886 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark12(-54.42892335622669,-35.521923085849494,0.7471079798771463,0 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark12(-5.443434161086982,-1.0,-0.09758882874535897,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark12(-54.43642272366553,-1.0,-0.015484387962778678,22.410761083818482 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark12(-5.448422858435904,-1.0,-0.045045915629868705,29.813282579889837 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark12(-54.49928492581473,-77.46589419230452,-73.93822471299802,0 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark12(-54.51228739710014,-67.3839678416781,53.20278842133209,0.9830518843658625 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark12(-5.461612585699854,0,0,0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark12(-54.649472521484775,-32.2406585091569,-0.9295344761415575,0 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark12(-54.649810118588555,-66.77503507204008,-5.8581906792798084E-244,0 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark12(-54.72336428519505,-33.3526528665575,-1.0,1.0 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark12(-54.72853370014159,-30.69590824556944,91.08983929102484,-1.0 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark12(-54.76736568685705,-30.26407763840465,-47.72308703510869,-1.0 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark12(-54.77396837561954,-1.0,-1.0,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark12(-54.80051024392782,-8.842794626550734,-12.173038716471392,0.5360645634038671 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark12(-54.81365463049258,-1.0,-0.008492678629339955,1.0 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark12(-54.831588626833714,-84.09999695872024,0.4450100029404781,-0.00462217491473861 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark12(-54.85413935951336,-45.454000786623354,-31.035471649909336,-1.000106608492819 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark12(-5.48800465004274,-1.0,-1.8582144179021413E-16,1.0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark12(-54.97080480721716,-1.0,-0.06774316943419945,0 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark12(-54.97288696496833,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark12(-55.2952656641444,31.385085613669332,0,0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark12(-55.317957747614344,-72.60268106125537,0.43859276802159286,-0.06255262560761334 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark12(-55.33735327229702,-19.888217240021437,1.0,0 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark12(-55.4139173431882,-64.23668705778356,-1.0,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark12(-55.59682814934139,-1.0,-0.046000829994637775,82.10010963850664 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark12(-55.64877783126035,-71.34969656970739,-1.0,0 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark12(-55.681195022780905,-43.26889452831688,35.12791550200393,63.9956974551971 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark12(-5.570366313876036,-29.509132477780213,-90.0316048733054,-30.478895934377405 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark12(-55.766739898193585,-79.28129077343873,0.9999999999999991,-1.3399197643530658 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark12(-55.77376272507285,-75.991905472431,0.019657562591432587,0.09785791839586366 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark12(-55.790090436415355,-1.0,-0.8229509047243901,26.40044574087198 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark12(-55.84802300002259,-38.94977591648932,0.5622233537581387,-43.90608291375848 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark12(-55.84839124805806,-57.4223228931177,-0.011424692720385028,1.0 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark12(-55.93237205488349,-68.89469712027325,14.481625156340431,-1.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark12(-56.032293872892815,-40.59075966347579,-16.13190492143803,1.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark12(-56.094052540240725,-87.54808627813625,0.0,-0.13030698449498224 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark12(-56.21510131569963,-18.66908113401568,2.7755575615628914E-17,-61.83517189146244 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark12(-56.21977890850538,-19.321621661910825,0.3272675399525582,0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark12(-56.26194426988083,-17.077500043544774,-1.0,-1.0 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark12(-56.4033092474729,-1.0,-0.05054591808595843,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark12(-56.406977534497045,-41.85577749136571,0.37232710237749445,0.998783035758958 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark12(-56.453297779786034,-84.12749173214178,-0.6977044252333904,47.96387141158782 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark12(-56.474653877481806,-17.692461324241037,-1.0,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark12(-56.514030943112914,-12.491267604027026,1.0,-5.16769948283651E-11 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark12(-56.51679719232577,-1.0,-0.9999999999999996,-88.9851426352855 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark12(-56.52477768882207,-1.3098223642940536,-0.0015672695050600177,1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark12(-56.5333824771689,-31.304977444944143,0.0,-73.98385098830259 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark12(-56.53516568278023,-1.0,-0.8587173036052955,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark12(-56.542787739116854,-5.058940987695195,0,0 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark12(-56.56023147158777,-37.76596237857236,1.0000000000000036,0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark12(-56.587728095695944,-30.95239920778944,-81.70082368949939,1.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark12(-56.625800329905054,-85.39098028880561,-0.056726681840476,4.440892098500626E-16 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark12(-56.69109355917941,-23.39169834709496,-6.689780459526327E-16,-1.0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark12(-56.78661209350198,-10.791506357270002,1.0,-1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark12(-56.81755143407277,-1.0,0,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark12(-56.84136759740259,-1.0,-0.9862911082007139,39.63254184365626 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark12(-56.92878993419646,-1.0,-0.038133543880076226,-1.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark12(-56.929771183973486,-20.817650489148903,38.87676855212197,57.48110094445394 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark12(-57.127930980051225,-35.905064987486476,0.004704448443202475,-0.9408772914830457 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark12(-57.144413513610644,-16.545377930318494,0.0,-51.487725763761595 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark12(-57.31552597699589,-98.68317357858504,-71.96527982716546,31.387557791663568 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark12(-57.36962663009341,-46.812507828433574,0.7264517583663501,-0.062133468310796525 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark12(-5.7473585142052315,-100.0,-100.0,-1.0000000049808497 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark12(-57.52847981343207,-1.0,-0.9906847671389939,0.9993374621674112 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark12(-57.563776834761526,-15.32381594740366,0.0,51.971196640327065 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark12(-57.62442581229611,-88.20029747807055,1.0,0 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark12(-57.62543378639163,-89.51315607841391,-100.0,-0.031455536694105335 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark12(-57.719400103641675,-79.12138468200894,0.03673181975857563,-0.02478716419367627 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark12(-57.753873444764864,-1.0,-0.6370012875298046,-22.765847260519372 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark12(-57.79699120954942,-90.22158539949545,1.0,10.519027450411755 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark12(-57.84474235224912,-1.0,-2.7755575615628914E-17,-0.9980319902141015 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark12(-57.97495221732954,-68.81720995030403,1.0000000000000036,-64.98777017589883 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark12(-58.015714546642336,-92.08736506598825,-3.824857543157813E-9,0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark12(-58.041496361152156,-38.087894384729715,0.035897998570580486,-0.03717017504682607 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark12(-58.051902733963765,-8.136797138183297,-2601.272204438464,0 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark12(-5.808638664935856,-67.58931139840911,-77.6752118591227,-71.68228937607341 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark12(-5.809679037371519,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark12(-58.17271973805022,-64.19200300865023,-0.0510549979418623,-0.013726495794420883 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark12(-58.17436654829612,-19.009360949634043,-1.0,0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark12(-58.254861575696104,-52.27438611269266,14.925155331516663,1.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark12(-5.8316992942772,-64.60302574549289,-97.56059126303742,0.9999999999999964 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark12(-58.32448962401653,-52.91282936233459,-0.6379563716241595,-0.990562167806865 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark12(-58.404520072767866,-1.0,-1.0,-7.371030767686327E-16 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark12(-58.475639163586735,-89.24305297772256,0.0,-0.9912150844022405 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark12(-58.528702639818405,-94.002159147703,-93.7148595638328,0.33771822683192654 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark12(-58.62013397411897,-24.689846601215603,0.05639247025842798,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark12(-5.865004934193044,-84.20012519112107,0.054233348458568253,-1.0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark12(-58.70029030112668,-39.67237003927531,1.1102230246251565E-16,-0.0013452870352905603 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark12(-5.879247883699534,-23.79865941635518,-87.07168630546258,0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark12(-58.833658940595534,-37.3906367244589,-40.03253243681206,-19.92619922561829 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark12(-58.840107419018814,-20.744844738795457,-98.47753692703718,-1.0 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark12(-58.92827126229393,-1.0,-0.11023134274778634,-1.0 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark12(-58.93558481211816,-100.0,0.03989011461067189,-0.04221107079460046 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark12(-58.95532530913582,-31.25832810993712,-0.9785721145525547,1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark12(-59.09142016014016,0.9999999999999998,0,0 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark12(-59.09451829906331,-25.4825943441297,1.0,0.49488334520022903 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark12(-59.098971305309355,-1.0,-4.440892098500626E-16,78.4024773448996 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark12(-59.16306116316736,-44.64030556893797,-1.0,-5.2709868246965925 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark12(-59.184147536419275,-79.57491359536732,-1.0,-41.215754515789996 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark12(-59.21678857436943,-100.0,0.0,1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark12(-59.27627328984375,-57.09051071278082,-0.5124588942532,-11.748887596467512 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark12(-59.40616668278941,-3.742094904616602,0.9096080103447273,9.327513687833683 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark12(-59.82151288604394,-81.91769679211276,0.0,0.35511629509772646 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark12(-59.84598140066621,-67.73520741673856,1.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark12(-5.988376884451391,-61.26632220066169,0.10250272076010347,1.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark12(-59.884603923588784,-5.822722977774687,0.3635714914690956,1.0 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark12(-59.89143032344699,-2.854610774115686,1.0,-4.5719495651291E-100 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark12(-59.93825023761799,-77.604945825795,-0.03436547703555704,-0.8883238904772753 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark12(-59.94778756720709,-67.88351355977456,0,0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark12(-60.025931347564686,-50.80663188346463,0.06331869225069653,1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark12(-60.053008684521814,-18.931018474786782,0.031979952548584545,-26.460340567315697 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark12(-60.16367141585785,-74.83617513368543,-1.0000000000000002,-15.89387967117135 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark12(-60.22545301540641,-9.140106086579218,0.06083766198336893,-0.9999999999999982 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark12(-60.22974212167968,-29.511669503950646,0.019457154189542365,100.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark12(-60.30533452558095,-1.0,-0.31170196933426375,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark12(-60.3835792558201,-41.937452880290415,0.9024937077970347,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark12(-60.40966952117854,-56.63420045903305,-1.0,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark12(-60.51577724060734,-52.76615190962996,5.5457328785136326E-17,-0.001114694399679009 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark12(-60.5306733984885,-34.581060772509204,-0.029579836046342543,-87.72294877472143 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark12(-60.59386763765791,-2.8449585333465848,-76.73372115110124,1.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark12(-60.66666591408827,-30.4370457866297,0.03215880478286787,49.7433771839547 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark12(-60.68531281790567,-39.29243921073519,-0.882200094370901,-57.10122208604611 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark12(-60.68936347253131,-31.468071798332645,26.796809077689517,-54.544388933927564 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark12(-60.70654445328155,-11.221875592961993,1.0,0.04091651883969711 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark12(-60.7957833822141,-99.97183551927526,1.1102230246251565E-16,1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark12(-60.79970215023174,-1.0,-1.0,-0.5389421275294439 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark12(-60.86230169459361,-1.0,-100.0,0 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark12(-60.86989757258323,-23.469145049635593,0.0,1.0 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark12(-61.08221073717005,-80.6124269233467,-0.0608506995619166,-2102.7347264362857 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark12(-61.29233905883184,-1.0034775709843966,-1.0,2128.6544338220747 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark12(-61.331216250042296,-15.382607567255375,-1.0,-1.0000054579597577 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark12(-61.344269595671754,-20.760154973364457,-1.7763568394002505E-15,-40.57987939708501 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark12(-61.363551888346336,-47.593876067617515,-0.05744021365127454,1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark12(-6.145874981334909,-49.980926925864985,0.0,-0.008249859487004851 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark12(-61.60319245570774,-65.49632421641071,0.7747997488220272,47.64405763558584 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark12(-61.63301986638267,-51.18011132157736,28.888890151451076,-0.9711753453605365 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark12(-61.714063408538756,-13.894061454624264,85.30810933847684,-27.83233357099148 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark12(-61.76198267317472,-1.0,-0.014243268765232749,83.7141144525502 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark12(-61.76284761533203,-69.3518161715416,1.0,-1.0 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark12(-61.79906248457216,-80.38734929667841,0.0,61.76498924042607 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark12(-61.887778936831666,-87.48269454753527,1.0,1.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark12(-61.93294370151001,-1.0,-0.059858963441016155,2123.8231071672762 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark12(-62.00369029323497,-51.33955564897235,-91.68371846083804,-0.36595384786349283 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark12(-62.02045294788854,-27.677844155361612,0.05145997675502949,1.0 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark12(-6.205645857071146,-1.0,-0.7495097553879435,1.0 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark12(-62.07378982194724,-46.105307421808135,-0.2404864205349213,-1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark12(-62.08222299003068,-36.673141692713806,-40.14706361312464,0 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark12(-62.0965587705092,-24.92315667951179,-0.8084386901287175,1.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark12(-62.151117112757156,-1.0,-0.9365979829753275,1.0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark12(-62.32998933363245,-1.0,-0.011442949422849236,87.86990804725536 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark12(-62.45661611240929,-8.406775049672882,0.0,1.0 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark12(-62.47580756543575,-23.311760281850795,-3.469446951953614E-18,-0.06255253960990509 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark12(-62.51274687336774,-26.556533538032536,0.0,72.19671099880696 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark12(-62.52867901810758,-87.20835991671117,0.03125049560076866,0.9999999999999996 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark12(-6.256099875659018,-65.50070985007581,0.06055334163832826,-5.2045753928633364E-18 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark12(-62.5852323617162,-79.64330327538316,-65.17697363223675,-20.151652619243492 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark12(-62.65594564247223,-39.15352034181618,0.0,41.14835296248174 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark12(-62.71932890664835,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark12(-62.810990994049256,-1.0000000000000004,-0.19567016734609666,63.660087223226554 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark12(-62.89661540630441,-80.3978345532491,-0.061512499190342546,1.0 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark12(-62.914624682193356,-100.0,-0.959774989485331,-0.47853900507310376 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark12(-62.92957346838443,-37.30557494506288,1.0,-39.520538501349556 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark12(-63.07784549387106,-100.0,-1.0,0.42885341490465034 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark12(-63.10184436521941,-39.4732592086031,0.0,0.6660407655020328 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark12(-63.1391605999664,-1.0000000000000142,-0.013636085053096462,1.000000040570752 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark12(-63.16665362129536,-45.546074962632424,0.010734348529967878,0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark12(-63.27082787030037,-1.0,-0.0321222449825839,0.012354511756725473 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark12(-63.275648220420045,-80.45181820161683,1.0,0.36209240138108223 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark12(-63.32423713610201,-53.59395939140971,1.0,74.10705664523653 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark12(-6.33670523743383,-1.0,-0.5929964215577712,-0.7082273335737256 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark12(-63.369629807638205,-32.31318633107761,0.0,-1.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark12(-63.43235311508053,-99.39818137193993,0.08462613792923945,-9.22982250450486 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark12(-63.597316636779574,-75.66327557145644,-39.36286155164361,1.0 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark12(-63.658727723647196,-77.90445195509395,-0.9846015474803753,1.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark12(-63.665161189308776,-59.42914026298725,-0.8856629562902469,-81.84513178934348 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark12(-63.69233249639461,-99.92823429489633,0.5423333332413496,0.05814272719503461 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark12(-63.71308227715808,-52.97169069395718,-84.00268806306369,0.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark12(-64.03088149141445,-72.57862130999541,0.015820103790164408,-1.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark12(-64.12813069746579,-17.382102261842032,-13.884212527060448,0.6457246176203939 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark12(-64.17926449043587,-33.98376004909454,-19.508179022231204,0 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark12(-64.23579223223615,-2.463599291981211,32.54964833813807,0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark12(-64.2715463007639,-11.723531845920284,-0.04557810512240007,0.04394839032289605 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark12(-64.30683172191539,-24.226244312635853,1.1102230246251565E-16,-1997.9974914608795 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark12(-64.33238650213606,-3.2206759186431224,40.84052213403532,1.0 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark12(-64.35967673953442,-70.79846085689294,-1.7763568394002505E-15,48.85166859982844 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark12(-64.36533671571424,-11.740465555636824,-0.04443714585110786,13.653397848330483 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark12(-64.36689315023011,-78.3379579107896,-0.6601803429118148,1.0 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark12(-64.38599101039877,-1.0000000000000018,-0.0432102982924131,0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark12(-64.53817469475165,-7.353439401181916,-69.04202785460157,43.41650967053695 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark12(-64.63436191925385,-108.78275760518429,1.0,-2172.955953652061 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark12(-6.46365960260786,-3.4961150726751926,-96.54526033552652,-0.0557197640122189 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark12(-64.81240302724794,-80.8713247010424,-1.0,0 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark12(-6.486522328222803,-11.292864497365933,8.558948868539598,0.018600599396063955 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark12(-64.89415394286567,-100.0,0.02072107234924278,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark12(-64.93993145953324,-60.699271028006535,-1.0,98.60603417477148 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark12(-64.97340051119217,-94.48952135155851,0.05046590111699656,0.9999999999999996 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark12(-65.01719087451701,-55.87596024652059,10.947277254985963,1.0 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark12(-65.0389376706799,-2.373852627402975,-0.2037519934555801,0.36458047351065304 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark12(-65.0803200302172,-1.0,-0.9520835354060155,0.7545541209800164 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark12(-65.15449188053026,-52.54814400560942,-0.12475088979780935,-10.83096720457145 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark12(-65.17045267127727,-1.0,-0.5840261212503483,-1.0000020456213978 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark12(-65.43843777553927,-15.016509968613125,1.0000000000000036,0.03288046478871563 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark12(-65.43928497701171,-13.052586512187363,0.0,0.7846365984424302 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark12(-65.49425820910824,-1.0,-0.29092724628003525,0.9999705121150291 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark12(-65.5051463987759,-94.72330130816789,-0.2994578290994063,-18.144595756621257 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark12(-65.50608151988348,-58.88130835486384,0.1539718359498965,100.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark12(-65.54907697503056,-1.0000000000000142,0.9999999999999999,-1.0000001843294262 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark12(-65.58216326363022,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark12(-65.62681702263615,-15.406212823647735,1.0,1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark12(-65.69843298292521,-100.0,5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark12(-65.70131515518293,-3.9036972070974,0.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark12(-65.7186874002571,-76.969197620558,-34.155095105712185,-0.3653645892140328 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark12(-65.73511260044998,-99.99293540047522,1.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark12(-65.7363440539101,-22.74143366948648,2.3055044209186484,0.9509717911692801 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark12(-65.83005174833167,-8.941071676317947,-65.52809705981737,-0.14100723718213304 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark12(-66.03715315923002,-24.092061849928655,-0.027467322567485797,-8.361806960037583 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark12(-66.03730528541334,-25.107229881084965,0.765649650895387,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark12(-66.04512481069837,-1.0,-0.11640396750902893,0 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark12(-66.08643156308281,-52.607769617941955,-1.0,2413.866876237598 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark12(-66.1096095695177,-63.822377793650546,0.9745378380250997,-50.54429977042485 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark12(-6.621364459091765,-77.2203714305727,-17.751508656141908,-39.04570729690309 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark12(-6.623760359314277,-1.0,-0.02447596413744657,-40.386437443583404 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark12(-66.26315402674989,-1.0,-0.9554918110690747,0.904885625918141 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark12(-66.433611791536,-12.012695718196122,67.05447665502871,-0.46692242479869206 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark12(-66.45243601601564,-15.291108284243553,0.0,-1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark12(-66.47710621037012,-34.93651287573327,0.6555496473627507,0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark12(-66.50556120459099,-71.99219534899251,8.323783288052581,0.9999999999999964 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark12(-66.57018064755935,-1.0,-0.023416416189763756,0.0241700184796112 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark12(-66.60577378209169,-52.528709863743714,-0.02911059609492174,-45.645164106477054 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark12(-66.65035987034462,-1.0,-0.05944764900454877,87.47964298556421 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark12(-66.67858272186396,-1.0,-0.012243159802977343,0.5098400710386932 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark12(-66.70887291134167,-1.0,-0.9739013695258251,-1.0 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark12(-66.709195890972,-19.86886453159029,0.0,-1.0 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark12(-66.75652858590625,-36.1066282979417,-1.0,-53.399657791047524 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark12(-6.676601077491854,-1.0746205112087832,0.8969108247985383,-1.0 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark12(-66.77570378746186,-11.297617213845765,0.0,0.9999999999999964 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark12(-66.82700745636517,-13.322490712395897,-0.42228363256007306,0.3120779027229192 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark12(-66.90471738653535,-42.3576671157976,1.0,63.13312079813136 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark12(-66.95518336783799,-100.0,0.0,0.36212967246949435 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark12(-66.99923497904032,-57.24302417885852,2.7755575615628914E-17,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark12(-67.059469793289,-62.87061219328389,38.68453591876653,-0.9773143810919436 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark12(-67.1410193126921,-62.79704268268391,-12.426315942089005,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark12(-67.14791163673726,-80.16485718206945,1.0,15.9841893718079 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark12(-6.718482222156328,-1.3746506219075114,-8.009094471404584E-4,-76.90602021332528 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark12(-67.19529235437535,-69.62805503406376,1.0,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark12(-67.23734973079169,-18.40694304996748,2.5230458768566137,0 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark12(-67.24616551448237,-64.75970611401145,0.02353391667724605,-18.321422804771284 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark12(-67.30788507029173,-44.80787958122004,0.0,-2276.538899331546 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark12(-67.35621923721146,-1.0,-0.021567437625180652,-1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark12(-67.37650292550597,-46.95732025584087,-0.03986457206906412,-88.67620910537201 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark12(-67.57079628772951,-6.143337453029261,11.587035261236593,0 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark12(-67.66727100076085,-12.673398871110873,0.8633699768048345,-1.0 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark12(-67.69469909065896,-1.0,-0.8840906201373208,-1.0 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark12(-67.69775767728837,-37.63894500571456,57.70775880979451,-63.60514138352573 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark12(-67.75566518415427,-1.0,-0.7800566014790791,-13.552199033768717 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark12(-67.75888733857428,-29.65100524918627,1.0,-0.8169151792017766 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark12(-67.87761045804262,-100.0,-1.1102230246251565E-16,-0.29992026329362886 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark12(-67.90772772697441,-100.0,0.40869106530359056,-1.0 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark12(-67.98604379794148,-100.0,-1.6056950835969046E-16,1.0 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark12(-68.09835212134614,-77.21824197968968,19.164138984231244,-1.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark12(-68.11033314094175,-1.0,-0.03736008409105662,0 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark12(-68.2151563730984,-98.9441828255182,-87.9264442106913,-0.9999999999999996 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark12(-68.23752678550862,-35.38754650065489,0.05225449624250448,-0.9221359376174155 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark12(-68.29089560546365,-33.525398766219695,60.70945995687998,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark12(-68.35779072051382,-20.188338914395693,0.8814127935417209,-0.8771260713707238 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark12(-6.836672512942253,-22.63048875723474,0.10965475781667906,-2.967364920549937E-67 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark12(-68.51080730282345,-34.29365784717147,-1.0,-1.82877982605164E-99 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark12(-68.52191691900646,-1.0,-0.0382386746658292,-0.9999999999999998 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark12(-68.53771123709424,-34.5757092902709,-1.0,-1.0 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark12(-68.56547884391719,-89.89032943200712,-7.668766675780532,-34.819303042787936 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark12(-68.56896503706653,-100.0,0.9999999999999806,0.01023738640820146 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark12(-68.71714983674183,-15.622458637699445,-0.004884111574462141,-1.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark12(-68.83235433930939,-59.022591660916916,-0.2731423549592096,1.0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark12(-68.85880627858648,-49.058520175923896,0.0,0.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark12(-68.87191778272866,-100.0,0.9408918591232015,5.320033193517149E-4 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark12(-68.92004667484622,-82.27654920143092,1.0,-0.9999999999999996 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark12(-69.00049380982247,-26.867825124919932,-1.0,-2250.404217930697 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark12(-69.01151044068831,-60.927398765789725,-5.122176361897836,-2280.613273522986 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark12(-69.08399163734045,-1.0,-0.00930967070948624,0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark12(-6.91118361270724,-4.4297385523326405,0.010666129100358242,-0.9995527798546351 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark12(-69.23904539663155,-3.0757519108982017,-43.64146221647707,-0.78734488983739 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark12(-69.3083440815931,-56.87547797032593,-14.483999527439924,0.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark12(-69.40899930670122,-55.38376682982776,0.0,25.066086559824765 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark12(-69.48823676616692,-12.555336878711833,0.003010096843045704,1.0 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark12(-69.64387547697899,-26.914897746546544,-1.7763568394002505E-15,-3.858711566204647 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark12(-69.66522173859754,-80.19286267322417,-77.52663148770483,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark12(-69.71335555531167,-72.09557080287041,-2.7755575615628914E-17,21.276796217214223 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark12(-69.75404890591652,-1.0,-0.9186153562229519,-2173.938759220045 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark12(-69.85059556794428,-100.0,-1.0,1.0000000000000007 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark12(-69.87628687735044,-65.61049315107404,14.967667607084834,1.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark12(-69.91015823529364,-2.505194583772318,-25.532899662567583,0.3696546686727481 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark12(-69.96734730447734,-1.0,-0.17654584906881832,-85.0199395731494 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark12(-70.03297717761325,-58.61974735048894,-0.8366997951980446,-75.37013266295135 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark12(-70.09868570021432,-50.67638025782273,1.0,0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark12(-70.14161681698073,-69.62370317963477,1.0,-0.44548915338856565 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark12(-70.14617688109604,-10.176087826430056,-1.0,-33.44750774439788 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark12(-70.3039290892365,-78.7983769841678,58.255199292533405,8.674544880160639 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark12(-70.36193566129127,-21.58050284166589,-0.05478603961563444,-0.8583133194444188 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark12(-70.36709265330853,-13.234829259990434,0.0,1.0 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark12(-70.36797123561752,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark12(-70.37763990979194,-1.0,-0.00502898966992962,-0.9272526558437433 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark12(-70.40690924830962,-10.631305233185394,0.9999999999999982,-1.0 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark12(-70.51613165673106,-1.0,-2.7755575615628914E-17,-0.24672299223315264 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark12(-70.62978675780329,-72.54991346913806,-21.871083646531737,-2335.0803788801895 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark12(-7.0713956757128535,-1.0,-0.050346955188624205,-1.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark12(-7.07215283221079,-31.610048101424894,0.0,0.5455354874358243 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark12(-70.72531528014956,-78.64640248619652,-76.4348412873417,0 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark12(-70.73672462744018,-20.983486109050588,24.365171304062443,82.99357417223075 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark12(-7.0803271517751085,-63.41665196668798,90.73828787481747,-62.424826569589186 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark12(-70.9272929266988,-71.70912701436646,-0.023280828995516895,22.605284727814997 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark12(-70.93100789219947,-68.37909367119325,0.9787992394472075,-34.36881203599952 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark12(-70.94519888454853,-13.688951510892512,1.0,0.8142493432015454 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark12(-71.11107910079606,-27.418809200353152,61.67346357923827,17.947595777250754 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark12(-71.11354849062693,-95.4536734798089,0.0610949920374352,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark12(-7.124059359201372,-25.22660319075507,96.87423866245169,-0.02080392118063762 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark12(-71.25621096655819,-96.06946252949773,1.0,0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark12(-71.3055642678364,-7.914457145462236,-0.9530249212627967,1.000232635315097 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark12(-71.3363052464761,-23.998549031193104,-0.023539510593998537,1.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark12(-71.35251081187792,-6.070329247734449,-1.0,53.690609406403865 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark12(-71.39240890958953,-54.59277139177683,-0.20479235030033993,0.05750285003101807 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark12(-71.44081651039633,-0.9999977155270388,-0.0449940007170202,-0.3635447525628172 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark12(-71.51164840520683,-58.372201094469055,-34.165057318981695,-83.35824009684487 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark12(-71.5361931990285,-93.2031941973388,-0.9999999999999996,1.0 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark12(-71.65253048929158,-56.07922359253215,-1.0,-0.7755327854410576 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark12(-71.65971906698384,-12.524747839512399,-5.551115123125783E-17,-56.55489804130597 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark12(-71.75234207322002,-69.03191869487198,-0.7219335083815739,0.9999832232517014 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark12(-71.80423840006432,-35.17686585516475,0.5041355036840967,-1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark12(-71.95465520918782,-1.0,-0.04307445531924514,-2284.666075703508 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark12(-72.03587662975123,-41.17605990891623,40.77871789604766,0.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark12(-72.2550813612406,-76.02312780927224,1.0,-0.048242004810154504 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark12(-72.30803124861038,-14.424951652911961,0.3594289762552833,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark12(-72.34164257621434,-8.826644456697736,-1.623809742527655,29.713180783192882 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark12(-7.234390337860114,-100.0,-1.1102230246251565E-16,-1.0 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark12(-72.37114157935207,-91.15629940524708,1.2513019344894381E-147,0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark12(-72.45162259020101,-1.0,-0.009135548390827947,1.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark12(-72.57832259630595,-54.64231313269799,1.0,-77.10286259246917 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark12(-7.258952047939492,-34.73276439869089,0.6662904532222713,-16.625748507172453 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark12(-72.63285184235632,-33.01547422703506,-1.0,-100.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark12(-7.268882171602925,-44.046015253982816,1.0,-0.19004985687150366 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark12(-72.74308115548962,-41.433150352588264,0.8818618033395135,59.80097840472701 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark12(-72.77811481306082,-80.70160951340844,-0.4041224339982544,0.475932514480057 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark12(-72.78451696280376,-2.7416625633528184,-1.0,0.28284685154488387 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark12(-72.84525154613266,-63.13481583138357,-0.04038808383145205,-1445.7858242147836 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark12(-7.285444183716553,-53.070754419729575,0.981496749979583,1.0000003731238025 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark12(-72.99956164679045,-1.0,-0.025802277571117777,0.9799646214195024 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark12(-73.04172771856774,-1.0,-0.7654734295573866,15.949077182535143 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark12(-73.0818325321289,-38.49471844691826,0.9758913568165047,52.94288695761277 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark12(-73.1196611049322,-33.49892402425636,8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark12(-73.23100622622326,-16.412533859846462,-58.3050799881794,39.628670093336666 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark12(-73.41582676480789,-65.56161774642382,0.9747351761128432,0.0901046274218591 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark12(-73.44229310177893,-13.483877888910952,23.459076909040718,0.041484440926697896 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark12(-73.44319722848974,-15.59649479864713,-0.008806488997899306,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark12(-73.51433143993633,-74.301513212866,-0.9999999999999996,0.661019612490108 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark12(-73.67588263105753,-46.825609371493805,1.0,-0.5872272455169599 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark12(-73.68177942518359,-11.808968312105435,3.423338163581022,-91.28628779701103 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark12(-73.81382541740656,-75.2376567908442,-0.9755954135922662,6.532646768881272 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark12(-74.01647135212147,-37.41848726949293,0.05092787003157225,1856.0358492248117 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark12(-74.07632743436207,-48.675307863322615,-21.80292535763573,0 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark12(-74.08251524272207,-0.9999999999999998,-0.4281890702475293,-1.7700319645950772E-4 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark12(-74.3529319091982,-34.68477786036594,-35.509670453151614,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark12(-74.39055727412077,1.0,0,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark12(-74.55055391011751,-64.84695867539995,-14.326611099942092,-0.7157119461732642 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark12(-74.55650313502429,-5.817852281609835,0.7866167916897321,-2279.558505876945 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark12(-74.68372699208757,-79.19787273398622,-42.90190542803256,-1.0 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark12(-74.84839871363741,-54.33518610678879,1.0,-30.99568327578757 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark12(-74.96130531496574,-43.92993778461508,-76.04521953838162,-0.9154702419877522 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark12(-75.02506758404641,-69.0228164705061,-1.0,-1.0001123301013448 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark12(-75.02525461020068,-1.9654349781991378,0.9999999999999982,0.06255277952336459 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark12(-7.502663508694567,-36.26017448749424,0.06255252583222783,0 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark12(-75.14600716590428,-43.15359449723894,-0.061910314418136825,-1.0 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark12(-75.1628530102147,-12.555849813282157,-0.7190723268755503,1.0 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark12(-75.18496198240891,-39.190342339233865,0.8526363551459658,-0.6586313683280225 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark12(-75.2676880091821,-90.90130179067297,-1.0,0.012568305968176237 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark12(-75.3133256005157,-8.422614883111464,0.9999999999999662,0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark12(-75.4083982685546,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark12(-75.44939905650381,-54.229154210490314,-64.3696468155357,-1.0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark12(-75.505527214049,-31.257587944919308,-83.45015026801441,62.86996151330041 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark12(-7.550616466006278,-69.9595327007891,0.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark12(-75.58477347556266,-1.0,-0.10117625106795614,-0.1906573499924421 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark12(-75.59185925872019,-3.50948065502597,-1.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark12(-75.63525638973462,-100.0,0.6730163709388519,1.0 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark12(-75.9225190433261,-12.58733332115142,-0.8488368465628473,1.0 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark12(-75.93693408246264,-74.45436598426596,1.0,-100.0 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark12(-75.95585882049724,-1.0,-0.9625196361192818,1.4426529090290212E-129 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark12(-7.607891205907279,-7.596068788384855,-42.21639144495812,-8.576176334478063 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark12(-76.10740517796013,-1.0,-2.7755575615628914E-17,-0.13394568083727634 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark12(-7.614908375777773,-1.0,-0.05563914851824053,-55.28237554951174 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark12(-76.19161421925989,-1.8013249299456466,-90.50930633702748,0.15134319167732735 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark12(-76.26312368309225,-98.85882851598168,0.03908541605937298,0.44831485272685134 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark12(-76.37009930180744,-1.1660779478195518,1.6676949990295974E-16,91.66754579462678 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark12(-76.46958462874879,-100.0,0.9338665237144382,-1.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark12(-76.63602828829335,-100.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark12(-76.64661733718722,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark12(-76.70947170998338,-32.188985105911684,-1.0,0.4983859981745127 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark12(-76.78402756236541,-50.02129912646797,-0.05956614330044774,-39.955402531496645 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark12(-76.938214965989,-47.6061386355259,-1.0,1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark12(-77.01181620958266,-32.18460728093877,0.948478671052212,0.0 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark12(-77.06747707126603,-68.36811493333734,65.34897894843988,1.0 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark12(-77.09099730906767,-54.084233819599184,8.881784197001252E-16,-0.12394523201878149 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark12(-77.10689120215581,-1.0,-0.8018324380148876,0.7819410286661799 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark12(-77.21219741149578,-1.0,-0.014508283181407405,0.7293737176718307 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark12(-77.26633390576681,-100.0,0.035074240778227406,-0.1681435183417077 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark12(-77.3153536262871,-60.7324323975877,-6.344891451396094,-4.7283148189951625 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark12(-77.32270687522033,-26.31613913658819,0.9999999999999982,0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark12(-77.35886558965777,-19.55430675788537,-77.89091921187214,-38.393600972691424 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark12(-77.37055829914677,-56.45448683470165,11.424665642642267,-10.804170720724926 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark12(-77.37681381189881,-1.0,-1.1102230246251565E-16,-0.044298955179404964 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark12(-7.738497940296114,-14.778039769480358,7.671414301775897,0 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark12(-77.5444008034908,-87.87964988113897,-0.016538288764496832,-0.8721670920356619 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark12(-77.55969119344753,-7.072207670405854,-8.46211981604316E-4,1.000002522598107 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark12(-77.60863772669045,-29.67612142396014,-47.677293439801296,0.8789105139642372 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark12(-77.6241501913773,-24.820600782802174,18.773827424535156,-81.14579122786742 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark12(-7.762770533237152,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark12(-77.6896704002821,-57.52880264861077,0.0,-0.9999999999999991 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark12(-7.7732556940273625,-1.0,-2.7755575615628914E-17,7.329011392998634E-18 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark12(-77.73954099631241,-1.0,-0.03725066562406704,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark12(-77.74388699343046,-1.0,-0.8461733060472225,-0.05527541938184992 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark12(-7.798675424832079,-23.61091508115807,-8.881784197001252E-16,20.826873775562802 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark12(-77.98750533976191,0,0,0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark12(-77.99049770753074,-95.03443838045659,0.9999999999999996,0.6496123305261101 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark12(-78.04585308998125,-47.394111864512546,0.257964815253164,1.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark12(-78.05761105722314,-87.48370936718622,-28.90509653305773,-0.1750703504553508 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark12(-78.06657079316467,-97.62947272329438,0.0,-0.016825411249851555 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark12(-78.14334966314209,-21.71717894689305,-1.0,-0.156690559396093 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark12(-78.1663060879038,-18.810656533555786,-35.723723567905466,0.19713092673124688 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark12(-78.2579245312536,-1.0,-0.7357205468627399,-1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark12(-78.33055009472824,-1.0,-0.7067284253700241,1.0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark12(-78.50192719575031,-45.01685027529308,1.7763568394002505E-15,2381.7892168469157 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark12(-78.64983748077026,-85.15143874442485,0.623764049787512,100.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark12(-78.73384791283964,-35.6691896500291,-55.971786924233946,8.104547295418612 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark12(-78.9074519641583,-56.822121520220904,-0.950325535142461,0.522820318728539 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark12(-78.93224079288285,-83.63355017224477,97.17578958015162,-1.0000000000000009 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark12(-79.0431870109037,-1.0,-70.60870764963255,0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark12(-79.39865964500929,-0.9999999999999998,-0.9793639846231138,-1.0 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark12(-79.40767468972865,-100.0,-0.015710678206699857,0.8276882140042287 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark12(-79.46129283340566,-42.45668169142457,1.0,1.0 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark12(-79.46383438413447,-2.2356895411006974,0.01667508304052772,-35.8958731978245 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark12(-79.51237249645585,-41.39085894881447,1.0,0.9643240289051955 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark12(-79.53849396417647,-1.0,0,0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark12(-79.67712854651741,-72.82826370349866,0.0,-32.09736722970176 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark12(-7.969374874004359,-37.92949086133368,49.62797740980301,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark12(-79.70681441324494,-30.086095925780512,-1.0,97.09001516616522 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark12(-79.75007467922238,-1.0,-0.03382117061333845,1.0000006459851498 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark12(-79.83293005754865,-1.0,-1.0,-0.011283245116477412 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark12(-7.997496108545909,-1.0,-0.9931284955326909,34.55071861164109 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark12(-7.998417797141737,-1.0,-0.03217891006277318,-29.735004951671357 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark12(-8.005676900177528,-15.602826140492645,0.0,-8.539592954087269 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark12(-80.10153805867712,-56.70043254874799,0.02220917661072072,0.02723924503819815 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark12(-80.1204972392088,-19.827860460417703,-0.05925793966568414,-0.05946108825372401 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark12(-80.26372241913988,-87.37084564826549,91.33933396291317,13.644912950706555 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark12(-80.33735483270733,-59.1914414686341,-0.5789925275865896,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark12(-80.39953303848449,-58.3176915412021,-0.9024521986591799,0.9999999999999996 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark12(-80.5409994066693,-66.88569236471268,-0.9461103991521311,-1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark12(-80.5585058895904,-1.0,-0.16171183047845078,1.0000000000000036 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark12(-80.60447871463974,-37.30482586609351,-0.5597951204776068,0 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark12(-8.09431017319496,-2.5273611300826264,57.82722869363927,94.51470546119289 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark12(-81.01053713247167,-42.28644245908884,62.20715917456331,0.9999999999999982 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark12(-81.04139698075541,-54.05199740907715,1.0,0.0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark12(-81.30648131468297,-1.0,-0.7959946545180363,1.0 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark12(-81.32708524673379,-1.0,-0.04834580092469354,0.021231087528491677 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark12(-81.39117530729098,-1.0,-0.03572078121858935,0.6833064098371038 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark12(-8.139429374518977,-85.07072944229799,-1.0,-1.0 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark12(-81.40587613276993,-25.813300241607713,-1.3877787807814457E-17,0.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark12(-81.41561850489052,-38.630920912889046,2165.944908716866,0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark12(-81.41622297027224,-30.169103025968568,0.0,-0.558388362326333 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark12(-8.151867744147268,-1.0,-0.06218559134516688,1.0 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark12(-81.66173431866525,-60.7784928043001,-77.41499019814356,78.44505447572672 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark12(-81.68099968986317,-100.0,-1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark12(-81.79988476230744,-41.5960318410155,-1.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark12(-81.86863462324865,-100.0,-0.05549580688111171,3.02546243347603E-123 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark12(-81.90630068525837,-16.338401741882386,1.0,-100.0 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark12(-81.93822567423044,-29.264412320140785,1.7763568394002505E-15,-17.526707922789114 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark12(-8.207744353317977,-9.111132449497148,-1.0,0.9954187119746528 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark12(-82.09047757099,-80.35107656375942,0.8035396366409095,0 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark12(-82.11727904164337,-71.2696343137975,-1.0,0.5671239981775464 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark12(-82.23739102721524,-4.865952114507003,-0.03285703002340157,1.0 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark12(-8.224459688481335,-1.0,-0.016057387912888264,0.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark12(-82.35061230192817,-92.99168878556196,-66.22554266165105,-1.0 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark12(-82.36982289417028,-76.12757391389086,1.0,0 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark12(-82.37296863796955,-71.82031188762276,-1.0,-0.038318258233501254 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark12(-82.43061637851376,-1.0,-0.7091816162284432,93.17816301466456 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark12(-82.46961956809284,-135.3345339808872,-80.1392372584327,2246.835647594683 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark12(-82.49936417365302,-7.292591152057497,1.0,1.0 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark12(-8.250035087277785,-41.69431142860752,-1.0,-1.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark12(-82.57696166673205,-98.72326332299251,-35.872693309163694,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark12(-82.94444772053428,-47.7125078779989,36.12558596565222,17.614716604867468 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark12(-82.97339196641087,-8.759305033684257,-0.976509071585246,1.0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark12(-83.10189446413311,-12.049280333499633,-0.24012488786146813,-24.323751135298867 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark12(-8.3204017728104,-89.02169292649909,-11.251804416311757,0.15816573535025918 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark12(-83.49606267263206,-92.82067408389221,27.656976885687907,-0.059201681395605166 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark12(-83.50785092944736,-98.37217448171249,0.3478102741913208,-30.61512739037689 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark12(-83.51742532202208,-3.4047097467265317,-0.061349912448355234,-0.13518921515708093 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark12(-83.58134234857282,-54.130820689494506,5.8518377194083655,-78.55386583743322 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark12(-83.6004796243655,-3.0589419640321065,1.0,-1.0000023766013795 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark12(-83.70068672360141,-70.78837135078001,-0.007075504879288763,0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark12(-8.381467611386974,-16.024359198538292,-61.48276439317757,-0.37859234937707953 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark12(-83.84570327346395,-83.08078972843171,19.161587606044165,61.41420344621869 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark12(-83.86654338685699,-100.0,1.0,1.0000000096094686 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark12(-83.90603497892266,-95.98057332226475,0.010869761187350613,-0.9999999999999999 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark12(-84.02337315596735,-72.24652024880642,0.050920816779713565,0.6690826437077371 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark12(-84.10707864502035,-30.015216330247682,1.3877787807814457E-17,0 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark12(-84.25420419258346,-1.0,-1.0,-0.625069880900972 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark12(-84.30424126282148,-74.0395989554491,0.0,-0.47506498203095937 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark12(-84.39244115147375,-19.52234429283905,-1.0,39.26838116081565 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark12(-84.57362815178332,-38.512685234359594,-0.9999999999999998,79.18930442418707 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark12(-84.68096823785858,-6.097533406947463,-1.0,-62.06037217627385 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark12(-84.7441067924991,-1.0,-0.5473056975819114,0.8312398998088445 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark12(-84.79097482492753,-1.0,-0.6788783020677468,-1.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark12(-84.80585442654632,-33.951426942123916,1.1102230246251565E-16,0.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark12(-84.80834748039499,-97.48498824008361,-0.7639639089622143,-0.6812431556190328 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark12(-84.8184111728294,-1.6053667836078347,95.2390329484104,-63.65160084478696 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark12(-84.91606908239709,-1.0,-0.3862577643868934,0.019327575332672375 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark12(-84.963133356652,-22.647608603189855,0.0,-0.2340012217797831 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark12(-84.98859682424111,0,0,0 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark12(-85.07719090500265,-71.60645101969938,1.0,0.9999999999999991 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark12(-85.17043417074564,-97.12958935387898,33.44003982919017,93.00940581873107 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark12(-85.18721735329872,-100.0,1.0,-24.062780677644035 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark12(-85.39732034588255,-37.941734401384885,30.17253100015668,0.2940239124686874 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark12(-85.45958392543893,-53.53911389158719,-0.015536030281749436,-1.0 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark12(-85.5485152602045,-1.0,-0.8945518238102668,0.0 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark12(-8.571971226888426,-1.0,-0.030699988789701912,-0.6366364802113011 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark12(-85.8444521489978,-16.29054925539475,0.23673940892399425,0.5842415072918741 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark12(-85.86852204852491,-50.54191538939429,-1.0,-1.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark12(-85.88581592334307,-1.0,-0.06255252523143971,0 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark12(-85.98261702393879,-50.994588031582566,-0.051259939232011775,0 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark12(-8.602693602089024,-73.04309084743664,-0.5014135651866366,1.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark12(-86.04897571522781,-33.16370433822806,1.0,-3.5404263815909047 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark12(-86.08792416871995,-89.58881452703918,60.76531003579478,24.275843586524843 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark12(-86.14564814451869,-64.99618082285744,1.0,0 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark12(-86.19222815614943,-28.305252774163417,0.009755743033918296,-41.467097097995634 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark12(-86.20774878533614,-108.26920679507191,56.823596458696244,-1.0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark12(-86.33000929273007,-54.57322644749217,-0.780616998410398,1.000005249949155 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark12(-86.38551816301548,-32.81814776817535,0.0644715258133389,1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark12(-86.43395237779536,-1.0,50.37846248956558,0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark12(-86.51762890427976,-100.0,0.9999840747079451,-0.747741040620417 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark12(-87.02928444377935,-1.0,-1.141363915060618E-16,0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark12(-87.23679405182726,-88.65583936161542,-0.6108499969025404,0 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark12(-87.25511611586813,-100.0,0.0,0.9999999999999991 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark12(-87.30887919587983,-18.484034631497636,1.0,2377.002630710802 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark12(-87.40754026431648,-76.80098436928849,50.42086122366454,-0.23081114876379372 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark12(-87.4085526838206,-22.182896551125282,21.408523023881436,-1.0 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark12(-87.56646488427793,-87.95615743647107,-1.0,0.7575096131712304 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark12(-87.60166806190382,-2.984078781212391,-0.697174218375916,-65.62891137416476 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark12(-87.67971896343425,-95.6862254840075,0.014742900709998924,-0.44559230226864593 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark12(-87.76654275265861,-42.0614644825109,0.019541940146856826,0.2460128822399389 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark12(-87.85506038750053,-78.89963215145978,-1.0,0.0 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark12(-87.86959296040777,-1.0,-0.5042336314844296,-33.938048436043736 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark12(-87.9902739596339,-1.0,-0.057582940788170375,0.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark12(-88.05758106255132,-1.0,-0.060776328503691385,-1.0000000000000018 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark12(-88.11374897284134,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark12(-88.1419172684865,-12.624531605721636,0.0,0.18423795943524102 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark12(-88.18370221149335,-16.45504660096346,-1.0,58.60400779648554 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark12(-88.27272543103973,-83.21415546525886,-1.0,-8.900695591783446 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark12(-88.29292574929237,-28.33409952519911,0.6346395708620822,-0.999999999999968 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark12(-8.843094793922646,-1.0,-0.04254788914732471,-0.38670240289231594 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark12(-8.843619791548633,-2.7764327652789187,1.0,0.8110462194935665 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark12(-88.49759751186244,-1.0,-0.013339482161030591,-75.2598907362617 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark12(-88.55045541425008,-1.0,-0.5343825872421857,0.815018099216502 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark12(-88.60086098416568,-28.544028871916368,-5.551115123125783E-17,0 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark12(-88.60904703063753,-1.0,-0.19276476727371072,-2092.7844627246163 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark12(-88.63837348155776,-29.80649370890096,0.9531705784599005,0.013082405871297165 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark12(-88.69768330951439,-100.0,0.0,-1.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark12(-88.78317490253968,-74.83076300706085,-0.5063943880810431,58.78929267818866 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark12(-8.878764969399455,-26.955673799822222,-97.66151327954884,-0.6818636304376349 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark12(-89.11588861471888,-5.0732430746978,0.0,2407.272937583367 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark12(-89.13347737199416,-100.0,-0.045686482663825245,-0.9905659186617769 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark12(-89.14881552544014,-2.5793310622702643,-0.751226709772253,0.06278809958914368 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark12(-89.16376118287457,-1.0,-0.07089714242331568,0.036952363842757976 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark12(-89.18037087449733,-1.0,-0.6700749027588699,-1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark12(-89.23126934050666,-67.049922935689,-1.0,0 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark12(-89.2409118825831,-91.36596174153783,-0.9502490507487626,-1.0 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark12(-89.28313230605518,-78.62445469852663,-0.032643082360928506,7.670162466760324E-5 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark12(-89.2852120699826,-74.96359533951454,0.25337594154204623,0.9721150107724386 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark12(-89.30210257361871,-1.0,-0.010430395864435761,-67.15333405029696 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark12(-8.933267580167838,-4.375303831384526,0.6665949371120743,-40.26242097766846 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark12(-89.33458791391014,-61.94398806016678,-1.0,27.984595536832682 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark12(-89.4066084572681,-2.762406021154031,0.0,-0.5599049137533572 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark12(-89.4976667824927,-64.20492362212043,0.0,1.0000000000000002 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark12(-89.5474693015159,-67.176739093581,1.0,0.07289120079617528 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark12(-89.59271612331534,-65.64072873430186,24.48978808182312,1.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark12(-89.60631702983494,-63.99125442762113,0.006956847592987092,0.024393441409259253 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark12(-89.60843041399389,-9.688825543823725,53.21849107143498,0.20524579101675755 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark12(-89.75547400829348,-0.9999999999999931,-0.007618305539627501,-0.8990979404388457 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark12(-89.79900466278589,-1.0,-0.969096844121575,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark12(-8.99472685728507,-27.037274032241694,0.8981822906060104,-23.759038072986606 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark12(-89.99985179703046,-53.757036971466846,-100.0,1.000000000000007 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark12(-90.03395458643377,-12.948945188382057,-0.03574107408154279,-47.34951306681361 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark12(-90.04366206679467,-32.17537593470534,0.9676167483063959,1.3428385856740848 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark12(-90.10147720527928,-1.0,-0.05541242946548902,-0.9593713510307098 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark12(-90.1315736433256,-1.0,-1.0,-63.31018094661437 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark12(-90.14041933645068,-49.51037327383231,66.80763295467665,0.2702333442079108 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark12(-90.16911477557628,-1.000000000000007,40.024956308343846,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark12(-9.023042099502675,-1.0,-0.013065092331395425,1.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark12(-90.26442532968566,-89.29433437148906,-1.0,0 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark12(-90.31157175490625,-76.49349403545472,59.44676315687296,-1.0 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark12(-90.31475524016624,-82.69752158063572,-0.011154183866814354,6.553079465265372 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark12(-9.032648747118891,-59.16837044977543,0.8051050609995005,-75.49071047307432 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark12(-90.4326628875293,-1.0,-0.5812599625984187,-0.03207143614286103 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark12(-90.43664312864088,-3.760484388370358,27.22916707453267,0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark12(-90.47594948363124,-7.8603720038892675,-1.0,0 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark12(-9.051405951056744,-1.0,-0.05184534044849931,-0.9251312690566709 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark12(-90.58337806311633,-1.0,-8.881784197001252E-16,-1.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark12(-90.85291946291643,-1.811282090016591,-0.0614973482920258,-43.76018406328622 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark12(-91.08053593592814,-19.557773217097637,1.0,-0.05475959250388873 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark12(-91.11583494296143,-31.936373722459436,0.9999999999999982,0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark12(-91.27687579771248,-13.310849935384919,0.5675611816456603,0.027787406248336477 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark12(-91.39963132130221,-59.932320997993514,-0.013919945090979713,-0.9518977008381404 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark12(-91.43153039575833,-99.31146308242747,0.9847169019493102,1.0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark12(-91.45622640253761,-57.3143367841765,-0.045964515513074,3.6828654647733607 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark12(-91.51159059914474,-43.58001760588333,-0.4384426746441079,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark12(-91.607378809164,-99.99522108555117,0.9987858306090119,0.4960841040161422 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark12(-91.62602018831258,-82.65534599022446,0.03795162870114494,0.8707537290060925 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark12(-91.72006139047551,-87.02477931180815,-0.8740523123835661,0.0 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark12(-91.84928662406989,-84.23657702299687,-93.00490880899925,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark12(-91.8504513156929,-21.384616162703793,0.6461192779831307,1.0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark12(-92.13837621703594,-2.3113411845666443,-0.9682755868877941,1.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark12(-92.16007382306952,-36.8820290154817,-14.313093178914826,-13.798421047130645 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark12(-92.19478525976544,-13.719391964333456,20.23715185219335,-0.20289726409031017 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark12(-92.24866172377607,-40.34754170876788,1.0240022811786948E-8,0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark12(-92.4521620486838,-100.0,-1.0,-0.0625527311790382 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark12(-9.24769869708988,-100.0,0.43045915704490767,0.4956065213705496 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark12(-92.5172174350921,-51.27754093706089,1.0,0.05393193215636759 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark12(-92.53082822969081,-24.04460842443712,1.4015773621828647,0.7013425041674655 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark12(-92.57990344036608,-37.57261891486259,-0.1952191563185437,0 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark12(-92.61552686736398,-1.0,-0.9990442124706923,0.026623928815559746 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark12(-92.63443465093468,-1.0,-1.0,0 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark12(-92.63615671331982,-19.38723749147551,-0.06782813800207776,-1.0000000000000018 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark12(-92.639207205286,-10.848506650329405,-0.9965111563233818,-1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark12(-9.269169671437727,-42.005150476380685,0.6423127595542574,-86.77841336583293 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark12(-92.80415628684051,-1.0,-1.0,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark12(-92.91634991729879,-63.802308005052,-0.06160551476933088,-0.36146020164172354 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark12(-93.00433043323793,-32.20564954672544,-1.0,1.0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark12(-93.11092280647372,-100.0,-1.0,-0.7575390307135017 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark12(-9.319827210516223,-44.819459615746844,-7.567892223191755,10.450438963255149 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark12(-93.24531544972396,-5.980236493943437,0.0,0.024976078745987812 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark12(-93.32365511119794,-16.73650750396456,1.0,-1.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark12(-93.3335513020518,-83.69227808009656,0.037906268522206216,1.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark12(-93.55888902948111,-0.9999999999999993,0,0 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark12(-93.7681205118562,-4.8623273001886105,0.0,64.33875435417195 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark12(-93.9692109793273,-1.0,-0.967748947877319,66.03071103758751 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark12(-94.1204253066854,-64.10730605327254,0.981658252269904,-1.031222792232373 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark12(-94.14636629775472,-33.99719262314029,1.0,-0.7635676902908273 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark12(-94.21364897740318,-62.99336163942111,0.9999999999999967,1.0 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark12(-94.2803351021577,-79.63439813608402,-1.0,-1.0 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark12(-94.30039058605773,-16.544395737236933,0.9999999999999982,0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark12(-94.343514708256,-0.9999999999999999,0,0 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark12(-9.439289563333247,-81.06006623333563,79.10624075478412,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark12(-94.41089624985057,-81.85673421315438,-0.8989616239331752,1.0 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark12(-94.46664715762637,-25.903361325041658,-0.5920521524125997,36.69711002138727 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark12(94.64573445634585,0,0,0 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark12(-94.79145748957387,-77.46213736672125,1.0,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark12(-94.8201973301777,-23.01380926304823,1.0,42.50899618871645 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark12(-94.8452651101483,-10.292173813445316,-88.76328685317931,-1.0 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark12(-9.489690678198798,-60.74868679117738,-1.0,1.016546608612635 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark12(-94.90190998665722,-1.0,-0.028404756780343265,-0.0054941338298241105 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark12(-94.92217426428465,-56.35915291060818,0.4467054086363671,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark12(-95.40370456273232,-36.93583706834037,1.0,1.0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark12(-9.565627586045837,-1.0,-0.11325842879079184,-0.9020940718581298 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark12(-95.72691432216075,-35.925875224052106,-1.0,78.66558073565506 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark12(-95.80526043605457,-90.42723435072314,-0.05095350791819886,1.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark12(-95.86528139085374,-42.82172194578794,0.0,-1.0 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark12(-9.587008377258478,-100.0,0.23626567642919993,33.818781115639126 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark12(-95.95220354373373,-77.28947668170728,0.010171735433230123,24.50002912551944 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark12(-96.01255717184685,-48.21202865913206,-1.0,-1.0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark12(-96.13061234744656,-1.1321808929991306,1.0,1.0 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark12(-9.630232719924429,-15.125528887216904,-3.552713678800501E-15,0.02150364265332705 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark12(-96.49435269131438,-1.0,-1.0,-1.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark12(-96.6766542276539,-100.0,0.9841410889092628,-0.4335192350877372 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark12(-96.83627993911487,-1.0,-0.9232241347956744,2.6868739678717333 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark12(-9.68724994921729,-1.7550733697554985,0.7626116562008098,32.802951952192416 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark12(-97.04365189886957,-66.94192232602612,0.0,-0.9742677027011037 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark12(-9.70616706385551,-77.5298762312952,1.0,-1.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark12(-97.09763145663676,-10.178966454649673,0.0,0.3237479118030425 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark12(-9.715024474400035,-30.21751834833523,62.954786370292375,1.0 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark12(-97.33281619434233,-88.76426693469728,18.225642527888184,-20.909715239181992 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark12(-97.3763748428829,-94.72173518015433,-0.7128289739610545,-0.08367469818405127 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark12(-97.45725730476101,-35.906320019204266,-87.02935128436586,-0.054679118567346204 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark12(-97.48134078296657,-82.21935521354555,0.9699426237997009,0.2049553121924394 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark12(-97.50138646058639,-4.6704856024365,21.35358069062643,-1.0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark12(-97.50356809888561,-32.89603192545644,0.03451569895344353,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark12(-97.7277160056568,-52.00760436351522,0.029272029761808274,86.00767878144912 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark12(-9.784728542740623,-43.85410358402919,0.9804228880904822,-0.22052007399608906 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark12(-9.784962732241297,-68.23112757692387,0.25923332136359994,1.0000150069945026 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark12(-9.78676291944825,-48.41437204245123,-1.0000000000000004,1.0 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark12(-97.87641697423005,-86.9417438283691,1.3877787807814457E-17,-0.7251368740982878 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark12(-97.95150436574455,-1.0,-1.1102230246251565E-16,-0.09310636513438908 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark12(-98.05084833884199,-6.877647939142445,1.0,98.13126876834053 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark12(-98.14439977446162,-1.0,-0.9993964123762219,-0.8604943405158946 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark12(-98.25598145204246,-89.4770726479855,0.0,-25.07975455725979 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark12(-98.39687412685839,-1.0,-0.05044842684519715,33.64549640455439 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark12(-98.42869748241509,-1.3275282532333792,1.0,0.11433866653560365 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark12(-98.49831912477306,-68.9262355790411,1.0,3.4332083464982002E-15 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark12(-98.49859211947596,-1.0,-0.02696728733450142,-72.3713698407138 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark12(-98.50284645407461,-1.0,-0.04673317454001929,45.67951745002004 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark12(-98.56912531169948,-1.0,-0.84611735331018,-1.0 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark12(-98.72293726138295,-46.213293441654976,-0.06255252536515897,0 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark12(-98.8527234914086,-42.18923226761464,-2631.5527745488976,0 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark12(-98.89316267569177,-1.0,-0.02869918039357351,38.45208443325422 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark12(-98.94594331180755,-143.1777130742502,0.02621110079390422,93.93847983168277 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark12(-98.97554514569813,-47.67012081221203,1.0,-96.44744326760711 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark12(-99.00137297480578,-3.0031658211013195,33.88416572963061,0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark12(-99.01023385805246,-98.8881279952673,7.9084392711312885,0.5006443276788239 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark12(-99.04566536646249,-0.9999999999999982,-0.8164673730971646,1.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark12(-99.0933849412676,-69.12432533562097,1.0,-1.0000000000000009 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark12(-99.18214247721924,-1.0,-0.07420975154745196,-0.6562547980182405 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark12(-99.21010194362373,-1.0,-1.7763568394002505E-15,1.0000000000000004 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark12(-99.23245029727497,-1.0,-0.027141686619682415,33.50606933382437 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark12(-99.26661167656738,-100.0,-0.3399171555987964,0.9999999999999999 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark12(-9.926833188869288,-37.01127879664077,81.60122766938339,2.996272867003007E-95 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark12(-99.30062161831988,-26.23355176011588,0.9999999999999998,-1.0 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark12(-99.33815893143185,-1.0,-0.9931472256206137,-1.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark12(-99.40225813112224,-58.677949555519106,-1.000000000000007,0.009669450069322717 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark12(-99.48842517904255,-1.0,-0.9862771678560165,-1.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark12(-99.5826633409515,-1.0,-0.17204449603401734,1.000000364823817 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark12(-99.6082919749035,-5.683246528431323,-0.045294641743328715,-20.851433156540267 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark12(-99.63982019564244,-1.0,-0.8810605949595741,1.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark12(-99.6574938112131,-100.0,0.0,0.0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark12(-99.74348226397268,-38.61249845116547,-18.539549805711367,-0.06255313762082101 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark12(-99.8256384788432,-1.0,-0.9260312119618135,45.609403130559 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark12(-99.83283605071468,-1.0,-0.9999999999999982,14.052584712460767 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark12(-99.86036501945202,-1.0,-0.028928549636445033,80.18279096923295 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark12(-99.87247343231108,-1.0,-0.05577479871866234,1.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark12(-99.95182578606733,-0.9999999999999998,-0.026094763126623607,79.77946300464788 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark12(-99.96581066462389,-99.98660611437099,0.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark12(-99.96981472414814,-34.91081702275429,-0.43508750643836347,0.9589716994398104 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark12(-99.97987660415492,-41.35826725447079,1.0,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark12(-99.9810531569703,-1.0,-0.38566922077668414,-0.023217831549718206 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark12(-99.98424553581177,-1.0,-0.7808832906741211,-1.0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark12(-99.98535215330668,-97.67806403498189,1.0,0.3199216579104256 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark12(-99.99691603186912,-35.17123327822368,-0.9836656548310275,0.9891739665804108 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark12(-99.99706745292224,-18.35098431224386,0.7901767747850259,0.9989269071960287 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark12(-99.99975378048865,-1.0,-0.05562978221708309,0.9998107464233248 ) ;
  }
}
