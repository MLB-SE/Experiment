import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0,-0.35291532792864744,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(0,21.088048813114725,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark14(-0.21324585982628008,-0.5340763597125324,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark14(0,-23.978997056085774,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark14(0,-24.29378979349164,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark14(0,-2625.340130287133,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark14(0,-2724.5022403847533,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark14(0,-37.26583862621489,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark14(0,4.005119054893669,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark14(0,4.73969519646613,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark14(0,-60.58377422963448,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark14(0,63.76785438253293,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark14(0,-6.931343920062432,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark14(0,7.734602619799887,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark14(0,-93.70167809952865,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark14(0,-97.86247633282554,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark14(0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark14(0,-98.67935673402637,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000002,-0.5613250311603286,-1.5707963267948966,0.05957548763879572 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000004,-0.5024683671264683,-90.72055825673625,0.9709388993452479 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000004,-1.3221866717070043,-98.69296112635352,0.06255654297033784 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000004,-1.4387902668967814,-38.36206384766454,13.672108300862224 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000004,-1.5707963267948948,39.097446287861565,2.4780966958016304 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-0.4073655936007583,-71.45138455949385,-0.0061270528639435495 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000018,-0.6186851751827662,0.0,54.663859683528884 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000036,-0.024248177910001126,-33.73224491654098,1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000036,-0.6846773652294685,-0.9707078716392606,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000036,-2.6734877874504284E-15,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-0.09351233073098929,-12.541056609963874,3.469446951953614E-18 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-0.34369800148612817,-28.013180307337322,0.060998040379901586 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-0.5560786320443217,27.043353065479565,0.0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark14(-1.000000000000007,-1.5707963267948957,-1.5707963267948966,-0.051889355379105224 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-0.37110224395945945,1.8701272416205694,0.059831811444910815 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,1.3374866152594647,0.0,0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-1.4145840295730094,1.5707963267948966,0.06255337883611296 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000142,-7.105427357601002E-15,-7.9241096821444374,0 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark14(-1.0000000000000284,14.462659169172241,-1.4470537464560795,-86.90682120228124 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0011862424975973484,0.23803673028913863,1670.1531726276062 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0019366690889655869,52.25986595646743,0.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.00264613895569428,-0.16088644638058766,1.8224669168898666 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0030697461862468634,-1.5707963267948966,7.0509157797741605E-6 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0066322838260027064,31.8683332724436,-1.0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.008177512119200994,100.0,0.02499051720070733 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.011579907600885115,-53.779265625537256,2.710505431213761E-20 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.028860749554774356,-33.67254253539906,1.0000000000000002 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.03149149984859101,88.48839579290613,-8.680962148361012E-4 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.03865502097142559,-1.039922302385392,0.9086308470729512 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.046477383565756446,59.23513054835976,-0.01629130341667392 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.048829339378936965,88.30377169428749,58.81656549366122 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.049818081854340446,69.4780106001835,-0.025291146415579835 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05093475472990931,31.7748556634403,-68.95810803137164 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05098392187221866,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.052237437093362274,39.23258187547597,-0.8434387174002823 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.054328450943991274,67.94532565260499,0.8075794866440869 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05613998457797612,1.5707963267948974,-0.08424566887882912 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05738670049986727,0.0,0 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.05763355500631118,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.0594115794398411,-73.34457280528312,0.0 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.06836859231981202,-16.3256394309049,-1.0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.07666456441757913,-48.5442406770637,0.9998155753200996 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.08495761123166576,70.7903096776888,-99.72559866738212 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09069361658733333,0.0,-1.0000000515267107 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09615880468231963,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.09926783479872989,-39.83291276900989,0.987902044930473 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1015151267585074,-12.367137852794599,1.000000000000007 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.10351025339963954,-100.0,100.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.11388307780860317,27.472447531691202,-1.0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.11439655970639506,-71.59116650882851,0.8192696106196125 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13160329704774354,12.225762114728253,1.0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13352965968613262,-66.36480017530634,0.5291630227058838 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13545961971239218,14.912102812183939,72.0181471002681 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13667896239781516,65.18981283949961,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.13867190299330467,83.97386373221633,5.421010862427522E-20 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1414654251401573,-13.227853342157218,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.14198220519501892,100.0,10.35923897548501 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.150760916022195,-100.0,0.05674804487729873 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.15223836707820837,0.0,44.99870172501468 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1571477010594189,-27.17384894188436,1.0000000249433796 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.16002702428446192,-27.905663177057562,69.66275555124224 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.16414622442283608,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.1739904988081945,-1.5707963267948966,-0.9960117897150136 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.17703241885710785,86.69356090113789,9.394064568413711 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.19648757612720502,0.0,0 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.20800291297926166,93.18456009240765,0 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.21116784630997032,1.2776429890270555,1.734723475976807E-18 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.21322678250055982,0.12543027702821963,6.938893903907228E-18 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.22187339317186505,-0.04031046262652538,58.635228083871404 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.222009281414134,-1.5707963267948966,-15.799023912829457 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23090851527669654,-100.0,6.018531076210112E-36 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23348918950512276,88.21212538177494,-61.892898695449645 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.23983793178196022,76.89650662314762,1.0 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.25974715460952214,58.40311020829585,-55.685916327920886 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2660980401217793,75.24590117595108,1.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.26750929042169336,95.6663393396441,-1.0 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.2706042966995773,1.5707963267948966,0.6781637331080965 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.27090684081854477,99.35005343503539,0.025301778101439368 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.27585358581865715,0.0,20.962550197039445 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.28988822375633794,26.744470708697428,-0.03831075216560899 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.30144667058727287,-1.5707963267948966,6.242671439408056E-17 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.31045353298452083,-1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.311477385561737,-1.5707963267948961,-1.0 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.32496868703819154,0.3268819370575916,0.9653765422553849 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3250645635523336,4.963463961805175,-0.3624098518988419 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3307448759477697,9.199651803212106,0.5364835812486435 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.34943269123027776,39.465561963775315,-0.6721923935236345 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3655861381279123,6.54758684807034,67.82394249670922 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3710474900205172,-1.5707963267948983,-0.06247390115175144 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.37482622936888,-34.34630339092852,0.028699793379534502 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.39444267360428376,18.711368388137466,0.0163639059464122 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3966888232635595,-64.0335296882628,-0.06256552584944754 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.3977039735500357,52.98940069796214,0.30042333379880914 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.42193871966086066,6.953673524517075,-0.999999999999919 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.42635270396430436,6.432410742340683,0 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.43277320225869453,-9.566238509071487,0.02370295496674636 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.43405488209887755,31.479471771280714,-3.939427053597831E-6 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4411680031605437,-1.5707963267948963,0.07832066618922225 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.47968233842467567,-85.9178647849118,0.7362132807799662 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.49066105378641434,57.463470324772956,-0.9859969198211476 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.4917414878355051,-47.31067023688617,0.9557139068302885 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5002296430339187,-0.13184084462043982,0 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5130325926394667,-100.0,1.000000000015558 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5246348275141669,39.28402169300119,7.105427357601002E-15 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5253283402162819,19.033575377453012,-0.018221220365967183 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5270716067471247,-1.5707963267948966,-7.213264545145106E-130 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5308166513142558,44.43635426935204,-77.33071150206878 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.53832477400789,-64.13993101564301,1.000000000000007 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5407597893867496,-74.1684295238682,-1.0 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5536850451605346,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5663757265967079,-60.276559833516984,-1.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.5751687316844256,31.458315553361743,-91.28020679483295 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.575486094265969,-63.96649632960831,0.027545030845897777 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6005849461908713,-26.48435207941661,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,0.6012087713395599,28.019406887017283,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6242938499347919,-2.1252285721962094,9.763903037724274 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6433231932162864,-64.89316511775283,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6663740430861821,-44.45428647289874,-100.0 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6788296052379685,-14.97355283903468,-0.020319207050723393 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.6877167723185165,-1.1102230246251565E-16,-0.953160213427872 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7148232214277627,-60.00058860785228,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7453537299324163,-55.13748293613597,-54.212495115439005 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7518708233234137,-81.84463717918528,-4.70197740328915E-38 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.754654719931243,-60.08519332995618,5.463851811939092E-9 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7574045523699545,95.40227586256643,-0.2574187998778257 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7664827373870136,-66.22467248875316,-0.1133275392910365 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.7956783516211225,1.5707963267948966,-2328.4373838066535 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8013081539880816,1.5707963267948968,0 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.81755272893625,-88.24912666587245,-72.72813295832307 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8258902118954345,-0.5650953239727811,0 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8260801867323817,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8284193331497774,-31.73423949367034,-0.29581690439642827 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8444623746987365,-44.01919597657815,0.655982746299351 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8557892383268042,1.2210509665794334,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8621947164033504,1.2888649674008121,-0.714880826023653 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.8764964165024506,-1.5707963267949054,-0.015934562332148405 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9110521637985087,-31.850967028316212,-1.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9125963827108068,-100.0,1.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9147166820011575,-1.5707963267948966,-0.37286222274264036 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9506306229926942,38.74831246176833,10.712887146012633 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-0.9622779664165719,1.5707963267947143,0.9562073732455805 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0148245879536373,-67.68202649476937,-1.0 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0163455357527802,0.2659003050731409,-1.0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0303506256266624,-95.51072310642823,72.89671983132175 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.040177080158494,-8.9437200136298,-1.0198776782324988 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0424577345440307,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.047852040740678,0.0,0 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0541122107652083,-47.08913987655615,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0604194321623939,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0733971136134222,-5.918786197984446,59.13647493458333 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0759562123571158,-49.031766814270306,-1.0 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0937763844148836,-1.570796326794897,1.0 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.0991538254580484,-4.4317624070873105,100.0 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,0.0,0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,0.7785513628703513,0 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1102230246251565E-16,-1.5707963267948948,3.606632272572553E-130 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1137902280096057,1.570796326794896,-1.0000000220763308 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1219180018089008,-1.5707963267948983,0.3626234429045212 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1296143681787964E-16,-66.48712037596758,1.232595164407831E-32 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1307442047786986,1.5707963267948966,0.9665473371967919 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1315294505576787,-67.49760987014083,2.4125549067241465 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1406090856095612,-63.80652578463489,1.0 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1821248513945677,-19.51374445887234,0.0 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1829032919819262,-100.0,0.030658939737399027 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.186566201789355,-95.67050187207845,-1.0 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1945111538930413,-32.750505565898166,1.0 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.1982226500267539,-11.167750063484931,-1.0 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2034601430344145,-53.36455713011701,0.9998725991613502 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2187088524542622,0.2630613137586413,1.000000000000018 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2477109775080342,-100.0,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2498136505609763,-38.90786906510467,-3.158978700346712 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2720468634051936,4.052055205422576E-7,0 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2735382207878132,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.274431305446973,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2869112210991345,-66.36585716979351,0.2943864954407312 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2893065474677357,-58.71337908172314,0.21253994815903365 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.28933130285954,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.2898398195197336,-31.716660554527277,82.84140898074648 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3163764440608279,-84.2147196829091,1.000000799612441 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3325582575723485,1.5707521584575506,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.343993528262908E-15,-34.30911410551525,-1.0 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3604916348675387,-67.39752570108993,-6.095363092665757 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.364509539912207,0.9837249811890965,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3656984849028924,-16.254304633626095,-5.2710989716152616E-82 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.379500554422293,-2.9135844788926164,-0.9631592453561237 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.3840712557281107,-66.13868257621621,-0.9857771634732025 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4240121226949585,-17.36377396928703,-0.011414070195210957 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.429223054312502,89.86696463762155,-8.294240034874228 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.429286974821771,25.971449306558483,1.053941697720542 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,14.431951179195927,45.2547520570444,0.0 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4769201160877943,-1.3389517875103705,-56.27344329623387 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4964183578117423,-1.5707963267948966,1.1270725851789228E-131 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.4990626940368375,-78.47650931998957,9.1438991302582E-100 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5084954258626615,0.0,-1.6704779438076223E-52 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5119067046052694,-100.0,-1.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5156631492022061,-73.73168700887987,-1.0000000000000018 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.518952426636685,-30.891566159267477,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5256005914040673,-50.5804467932247,0.5389920157961496 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5386467824240748,-77.80253046165352,-1.0 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5405188508720944,0.0,-71.52345169707081 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5517681465961248,38.778959374318646,0.9329387745962135 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5659261576262355,1.5707963267948966,22.217207194099945 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.570772745916275,-55.24563499888433,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948806,-24.675841586508646,0.6612925696848421 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-17.25905941267031,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-42.90751544620161,-23.005817525787098 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-49.34257209450923,-51.67798379033794 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-7.402115441030503,-0.9999999999999999 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948912,-97.16674130109666,-6.364818451254084E-4 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948934,1.5707963267948966,0.7711823575786411 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,0.0,-16.011203524975056 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,0.5898666216190321,1.0000019739834956 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-100.0,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948948,-66.12411184910574,0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948957,-1.3078144776964478,-20.546597384558602 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948957,-1.5707963267948912,7.2832462324234705E-9 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,1.5438478546323495,1.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-1.5707963267948966,-34.33070223878629 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-20.90860683170984,14.646240560600065 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-39.058644805122086,-0.9323505469830558 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-53.41368407144205,-1.0000001801068854 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.5707963267948963,-86.45884806340747,-0.30642411446923745 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.7763568394002505E-15,1.338224881613065,-0.6648446577712459 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-1.9464023940012778E-16,0.0,-9.161299591497619 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.220446049250313E-16,-100.0,1.0 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.324799345270768E-13,-1.5707963267948966,-0.1096683237116388 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-2.5719375953203357E-15,1.5707963267948983,0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,2.927566661788482,19.37184063507258,-181.70513844421052 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.0399298952089563E-15,0.0,83.73191114428889 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.469446951953614E-18,0,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,3.50579232703836,28.239365812582868,0.43887779805166494 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,1.1603859481617236,-1.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,32.75859354011978,0.04157791645586384 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,-58.45659208556393,-0.89808129122477 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.552713678800501E-15,-7.461402851393007,1.0 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-3.944304526105059E-31,0.0,0.1354199179253922 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-5.026302461355583E-4,-72.26087666234507,-0.6778465166890846 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-5.551115123125783E-17,-32.13493106816565,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.446043416709235,50.368976703945776,1.0099396891835697 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.452530281203054,26.66097464584298,-9.316294792517553 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.468787580545574,39.39655453872973,0.0 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,6.750060583171302,44.24496620894712,-25.143551418825282 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark14(-100.0,-7.105427357601002E-15,-19.188516919954765,-61.511188074927155 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark14(-10.010573253600104,-0.4877129778296665,-30.803977281517486,-25.94472115139463 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark14(-10.011864703339967,-0.5823268889868802,-81.98319406470686,-0.09743055023447655 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark14(-10.03449821299975,-1.5707963267948963,-52.184253772982125,-0.7004088964069362 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark14(-10.045010037219004,-1.11664739350894,31.698819359679817,-31.795471715055353 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark14(-10.046547666357647,-0.31350373222192063,-95.66181178573548,-0.014849402016389193 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark14(-100.53978819224945,-1.3031203331317966,88.20133331242829,-1.0 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark14(-10.05746983859568,-1.5707963267948912,6.652334070987626,-5.1977048828224496E-113 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark14(-100.79540932519863,-1.1478176070408528,-7.105427357601002E-15,-0.028916684608767507 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark14(1.0,-1.2443249857367675,0,0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark14(-101.51485406033117,-0.8895113516883901,-41.66640582156547,-73.60867411657885 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark14(-101.58600757479141,-0.6781324406089791,-56.520001527861574,1.0 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark14(-10.18535931237299,-0.3125872281145109,-41.03959587662376,-1.0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark14(-1.0186679310555713,-0.2638302389902485,-11.190289369784198,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark14(-10.20151871692066,-0.09684174258503941,-100.0,1.0 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark14(-102.3017839046895,-0.13344692633969366,-2.190375765512772E-15,506.8324976077821 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark14(-1.0274171402756984,-0.0051199431180891375,2.9304645025332405,-0.007911489023389888 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark14(-1.0305997504441835,-0.4133816098963597,-88.845528198835,57.49354299893869 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark14(-10.399629778557383,-1.5401438334645234,-72.30364671204951,3.2944368572595385E-83 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark14(-10.406983585165698,-1.5202174067860974,-48.48463694164431,-30.98527568857206 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark14(-10.418430593955947,-1.5707963267948912,-68.3423716886597,-15.239496143222027 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark14(-10.434244501144672,-1.570796326794893,-45.21159394458189,0.040286372624286054 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark14(-10.48305017184093,-1.4639855181639596,1.5707963267948966,23.642004593503327 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark14(-1.0500632647781885,-1.1270529627585413,-93.72908842730425,1.0 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark14(-10.511331403478025,-0.37040742866104936,0.0,1.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark14(-1.053206863263807,-0.1229439762861445,94.30425074001991,-20.630434416145718 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark14(-10.54691006055332,-0.5456361705750581,-5.432351603963795,-0.4652386090868609 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark14(-10.567003481287427,-0.283855814685674,-20.235097533950395,1.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark14(-105.67128865526084,-1.277292886686851,1.5707963267948966,3.8384155704645835 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark14(-10.608518147591493,-0.9402694923263838,1.5707963267948966,83.0438840548932 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark14(-106.46720237877675,-1.9681939796663874E-15,1.5707963267948963,-2153.291462605021 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark14(-10.680828860918934,-0.013079445311594926,32.8575970990311,43.0066865854481 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark14(-10.691409469679783,-0.30440331659472974,44.975183051722084,-0.36329388694535747 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark14(-1.0,-7.401486830834378E-17,0,0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark14(-10.814501693654698,-0.4442272284153348,-1.570796326794877,-85.74762267449722 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark14(-108.17984971218651,0.3897191050028058,157.59328332827323,-64.91412339609927 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark14(-10.857577450960324,-0.5140003460515599,-0.48287458972730013,-86.4541080386603 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark14(-108.9022910020993,-0.5881726461363048,-56.65828773933829,-2146.303077945907 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark14(-10.894872146445806,-0.2542782736590965,-53.128163528758236,-21.3835169213161 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark14(-10.971687973398645,-1.5707963267948912,31.43186072959813,1.0 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark14(-110.17322466431658,-0.19967338881857266,-12.266545390576681,-50.73527627020651 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark14(-11.052077324564001,-0.08823932528217697,-36.77105167863823,0.9867193429568183 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark14(-1.1074781992940308,-1.3966549190405562,1.5707963267948968,0.5785546196671795 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark14(-1.1085772180883282,-1.57079632679489,1.5707963267948966,-1.7333407300970446E-15 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark14(-11.097250609942904,-0.07987804276217592,51.232895774278894,-2.2458740908534498E-17 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark14(-11.105499435060779,-0.772183809896291,-15.008250447337701,1.0 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark14(-11.193600999351816,-0.19682346301709813,57.18054671379578,-94.03141130299082 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark14(-1.1267670825730391,-0.5919356058257293,-0.47852185261863944,1.0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark14(-112.82832291125935,-1.1594568531538694,-81.52683602006228,2208.1283128371897 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark14(-11.305033964405151,-0.5865419979417663,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark14(-11.310378555058232,-1.5707963267948735,0.23842053234648516,1.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark14(-11.314127601578848,-0.8183025930217553,-37.35623169105753,0.9295247908749134 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark14(-11.395941666150804,-0.4726525363908979,-63.55057788958609,0.0837906099283714 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark14(-11.441517734535847,-1.5707963267948948,-1.5707963267948983,29.38673351230604 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark14(-114.50186035203913,0.4670324406294417,65.34848107244122,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark14(-114.63051732262713,-1.4035997965958367,-49.031738721140364,0.7860501717476645 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark14(-11.469794392511075,-0.9072368630497465,-24.433270247805154,-0.8932063449654289 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark14(-11.473731631378431,-1.2973745363580358,45.097714461414846,-1.0 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark14(-11.47901332723061,-0.4049359801295711,-58.66798231519621,-0.4875644063585449 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark14(-11.49567344362649,-0.3226378475773425,89.43389067934254,28.071011062367237 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark14(-11.520916811118733,-1.1957078930592324,-30.48794273662247,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark14(-11.525260850337617,-1.3200886545720945,-59.654526405109145,-98.88378653625941 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark14(-11.542297721976938,-1.1214352062783575,-1.3762005828448167,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark14(-11.559083718353953,-0.3120639684774429,44.7468274154378,-1984.000068078282 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark14(-116.19649090292961,-0.17601942319078756,18.007917260188947,0.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark14(-11.633971449523965,-0.16301167772379266,-31.902414972717576,0.037479435375340486 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark14(-11.656591693936337,-1.4272019446113786,-100.0,1.0 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark14(-1.167046139441597,-1.370120862188001,-53.879386006331664,-0.06255336604516089 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark14(-11.704133470714124,-5.775909793649925E-15,39.126367446799776,-50.23351093523121 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark14(-11.740217516222561,-1.4828942749867189,-72.43157884512966,0.5984802139760479 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark14(-11.749706006318178,-1.475848711802712,-53.9642702432911,-5.625897625408058 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark14(-117.76487022359028,-0.8995763485886661,-4.811271189828094,-58.20460539300464 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark14(-11.78083691625588,-0.3250869572251408,0.11850336289367314,1.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark14(-117.82941262123364,-0.4649278743853129,-0.08292950488144449,75.57673988961946 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark14(-117.85241344036008,-7.105427357601002E-15,-136.31445673988625,1.000066862276916 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark14(-1.1786192473018429,-1.0616101629567631,0.0,-1.0000000000000142 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark14(-118.31293423567004,-0.15996422832422752,0.8361701203090142,-2161.8018385499417 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark14(-118.31628364790896,-0.4534444185219426,-38.95089811598598,0.0 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark14(-118.54721560255906,14.450226805205958,102.93576795064106,68.32188348637371 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark14(-11.859703901329674,-0.7425202627650174,-1.2408876450094326,-58.841870069522564 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark14(-11.912072075638445,-1.2763861600789075,-1.5707963267948966,-15.228669928690408 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark14(-1.1944577652308226,-1.5707963267930185,95.50188668727802,0.9999999999999998 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark14(-11.969629842363695,-0.7571068080681816,-62.068891989952064,-9.4039548065783E-38 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark14(-11.984582165033888,-0.6679013349628349,1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark14(-12.034953008713018,-0.9570854896029876,-60.05857648262152,22.44850864838821 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark14(-121.40044488132159,-1.3604794759574332,-60.064789451924504,-1.0 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark14(-12.155287697333293,-1.5707963265051077,0,0 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark14(-12.163044371558211,-0.13299609431932222,-6.345843185178398,0.0 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark14(-12.163226428135616,-1.2241624176093273,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark14(-12.26312661161248,-1.5505062071382465,44.21553865868281,48.23464158965172 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark14(-12.276752165643803,-0.414031004283397,-30.877326822817558,-0.9164775437857751 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark14(-12.323605004749453,-1.5707963267948912,-13.649899966095631,-1.0 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark14(-12.328361172110522,-0.01326929117370662,-8.544975826891898,0.038021558319790205 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark14(-12.446836667352287,-1.2364246494660716,1.5707963267948966,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark14(-12.462217202756632,-0.20838639902619205,2.4143412419057675E-32,-3.7453410837537587E-96 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark14(-12.462918207659067,-0.48555804010188586,-0.008519618485490968,0.5712819219251979 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark14(-12.503712121017713,-0.3110200736900033,-3.6842197117457545,-33.44065274467812 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark14(-12.552812512565437,-1.1959557809440884,0.8730064502702654,1.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark14(-12.580534887956151,-0.004506480550549368,-1.5680438389115428,-0.3135446731270722 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark14(-125.8817366558609,-0.6723177896057155,-65.99827159853504,-84.1479143408051 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark14(-12.597618233705916,-1.4498032077731828,-33.34880590827017,-98.3920214291095 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark14(-12.61292195113299,-0.4691362233235772,38.4925094862046,-75.82323204349794 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark14(-126.1902152819473,-0.5171336065967372,12.14492619163012,44.24524149198908 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark14(-12.631617050853812,-1.5315245897467304,-3.0953041641608294,-0.33085673770097124 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark14(-12.651182582807714,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark14(-126.71429340654716,-0.8257798499841797,-1.5707963267948983,0.8433806827793049 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark14(-12.695230196092732,-0.27859631589128797,-45.29534160219668,1.1707253673558568E-6 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark14(-12.696431343101466,-1.4946797684270445,-61.09869104428258,2217.2914674822014 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark14(-127.17028862986359,-1.2690511574235828,-39.11076771268511,-13.315649566374702 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark14(-1.2763848081041413,-0.4482766520355153,-17.03286648558314,-0.026281747728551685 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark14(-12.793598110671118,-0.6715746187541336,-10.622213084316538,-0.9618809763958067 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark14(-1.2818442648873738,-1.4993140599575565,-65.24859748225667,-1.0000072039407497 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark14(-12.829218368189386,-0.1342062387880583,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark14(-1.2831374918541165,-0.2992436851613188,-106.02885861442475,60.85651828950397 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark14(-128.39498867996076,-0.19998112793951633,-0.48721984706615473,48.48140760843575 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark14(-12.848893810648455,-0.05756092817567901,-19.40273962867846,0.8482444568390901 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark14(-12.872512528840783,-0.3005141908117276,33.234156483354376,-0.9428408571087623 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark14(-12.939145927402636,-1.5707963267948963,-43.3079847849847,1.0 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark14(-12.977026343848708,-0.10915311462788585,0.0,93.67407448118762 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark14(-12.979566870872967,-0.17506008882305227,39.01151707025152,1.0 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark14(-12.995607606900123,-0.11242490430066829,0.0,0 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark14(-13.027036966578335,-0.15891801947818207,-1.5707963267948966,0.36787549032586586 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark14(-13.029167494997079,-1.5417870969943146,-1.5707963267948966,-0.021941669258536436 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark14(-13.042961622621249,-0.5659093299559697,-24.56723542970078,-35.778684969371085 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark14(-131.12195714215986,0.3518486100873378,56.40157125996305,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark14(-132.23189229174872,-0.622406403960003,-0.5530001357949317,-1.0 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark14(-1.3325626439364477,-0.3276370301504148,-100.0,-0.41081990909188937 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark14(-13.358236967647457,-1.4230849718145757,1.5707963267948966,6.988013611123739E-16 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark14(-13.377046025031781,-1.468309267455848,-0.5994268438564232,0.6404798786719701 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark14(-13.407652212337162,-0.43859389130368287,1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark14(-13.432923589896845,-0.5560721941177295,13.976040386327895,54.99685361774377 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark14(-13.450874335121313,-0.37387284676057597,44.59147268430432,1.0395409765644899E-112 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark14(-13.4695286261911,-1.098547333143891,-72.93734487786384,-1.0 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark14(-134.94919089275248,-1.1164116794060188,-136.22497790424072,-2076.9119453627604 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark14(-13.517955367864527,-0.2628255670753965,32.65077595812451,-50.756786511047224 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark14(-1.3520378446264703,-0.17011848519518308,-20.364833605896667,-1.0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark14(-13.540970973009166,-0.10457446546033929,7.159008403629272,-0.9280625879851309 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark14(-135.9956288234289,-0.8143974550290629,-30.44761158685168,-10.46915421205885 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark14(-13.607178401579686,-0.30094434192172176,-73.08458856169145,-0.8685581517118781 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark14(-136.64576595124103,-1.2576311663674358,0.0,1.0000128870385834 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark14(-136.66260876999166,14.505978561391757,157.3747895223044,85.22607727767178 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark14(-13.687144498690483,-0.02649965832948451,-39.23750788336664,1.0 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark14(-13.76878773740312,-0.6686611906477262,-100.0,0.5740509070906727 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark14(-138.1726064744607,-0.0011822407461282436,-1.570796326794893,99.59812872649933 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark14(-138.33672870921563,0.5073759047713551,68.5835231978403,1.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark14(-13.921484249179267,-0.4557153591380314,-95.49862110276148,-0.012107439882800303 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark14(-1.3948301328064132,-1.4339600478667824,-86.97413005316555,-13.882568035967608 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark14(-13.950529695426123,-0.7467972731741918,-42.66088133182222,-0.7763365538331317 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark14(-13.950707046209104,-3.552713678800501E-15,-64.44228013584687,25.44448949850167 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark14(-14.039738209676187,-0.4077434087559224,-30.409673486550588,93.51624257502601 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark14(-14.043690141472581,-0.00581178994853409,-1.7730689586295478,51.19340760158059 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark14(-141.13610436381822,-0.3025309805658487,1.5707963267948966,2099.557655329885 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark14(-14.120052277795692,-1.5117597822815194,-0.7936869617867583,-1.0 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark14(-14.168693236987338,-0.08452517853709317,13.599002204011002,1.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark14(-141.72297032053865,-0.08475223385311603,26.181700762034026,-0.5049643073535686 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark14(-14.180269850558247,-0.5562874206498505,-72.98007481492743,-0.936213194240233 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark14(-142.14525464919691,6.429559893830569,82.5796736142356,-1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark14(-142.2063049392773,-1.3474970898276233,-10.002872627094376,-63.482445052717395 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark14(-142.26092376443427,-0.972069208359008,-0.6815289064907821,2011.6854683605698 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark14(-14.258679782785016,-0.18257099333728294,-12.836241474507077,-1.0 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark14(-14.266479875228555,-0.4916769010627426,0.0,-0.03599845392339407 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark14(-14.267917213952558,-0.1490711280515946,-100.0,1.0 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark14(-14.30605653559201,-1.532639035012712,-100.0,-1.8991135491519597E-65 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark14(-1.4332455214051467,-0.08727638933121207,-1.5707963267948966,94.88077582731144 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark14(-143.5891884248294,-0.5313992607514129,-68.97338664248547,80.34783894911232 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark14(-143.95754762418852,-0.7738791501438218,-71.53014071901866,-22.616040332164047 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark14(-14.411522805008458,-0.7055041031470779,-100.0,0.7176534294682875 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark14(-14.41894173887934,-1.5707963267948912,0.0,23.316660767378266 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark14(-14.431670336527494,-1.5707963267948912,38.88858505706034,-1.0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark14(-14.441137341054114,-1.5690868835760117,-7.073397538164947,-1.0 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark14(-14.449271316453386,-0.1184447485310447,-22.15608596908288,-0.015260932087765466 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark14(-144.69564679529927,-1.4322011432096753,-19.40680178943987,-24.18291232372647 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark14(-145.08788015906248,-1.3212015245733113,-43.63142683701028,-1.0 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark14(-145.15052639574242,-0.06964352058612733,2.0669043040373225,-1.0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark14(-145.3369691885319,-1.07454038121814,-97.9210054352546,70.81799131643385 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark14(-145.76192332812164,-0.014325595378494056,95.28628458794545,0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark14(-14.599061673016621,-0.6823386609254315,0.0,-1.0 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark14(-14.614061594765234,-0.05001500259864933,-61.81390817491238,-0.01 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark14(-14.643228150891993,-0.6467374432695809,-71.84533820908227,-75.63238334572917 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark14(-14.658038589074613,-0.8909691976625389,-21.294521523885322,-0.9999999999999929 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark14(-14.690505564347907,-1.0982482959864304,-2.671937513963081E-16,1.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark14(-14.707367929151786,-0.8859874212614582,37.829833713432734,-22.18007084342939 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark14(-1.4729997047571146,-1.242841821787735,-18.49081671419799,56.585876300366635 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark14(-14.732657295937962,-1.5707963267948948,-45.16236343722933,-77.26567666977489 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark14(-14.741253795239082,-1.43292488807654,-71.52555113720692,12.562255206439724 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark14(-14.76893366349239,-0.45701073758359456,-96.82201225640566,-0.9918685902191485 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark14(-14.800933046349252,-1.0707920548175673,-0.2404635819963732,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark14(-1.4873117787848569,-1.5152584602432684,-1.5707963267948966,-0.04666309008942988 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark14(-14.887728609702021,-0.0472380014974662,1.5707963267948946,-0.3672787652348859 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark14(-1.4923572827815352,-1.2371539649113097,-53.92043219215935,0.9508871916263186 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark14(-14.936345794760738,-1.5172716074482906,0.9255831499840748,1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark14(-14.969379819145185,-2.220446049250313E-16,-1.5707963267948966,1.000000000630321 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark14(-14.984628182281227,-1.5707963267948948,-56.172596080974195,47.50317772781324 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark14(-14.997757251710883,-1.1102230246251565E-16,19.127817337652917,-3.207818735996924E-10 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark14(-150.22470977602117,-0.7291729019164881,-121.18705352488155,0.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark14(-15.049607332118029,-1.4626544839392943,0.0,-2079.705677396005 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark14(-15.050274691229585,-1.5459234127417512,-31.799130562949916,-0.36649865550583616 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark14(-1.5052311738730222,0.23713615032321866,74.31543226882594,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark14(-15.071025213383038,-1.5707963267948912,-38.51151253878432,-0.010262366576406765 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark14(-15.080667579296078,-0.05129276254337922,-65.87271679961081,0.06256174116657356 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark14(-15.090051361035904,-0.3708921100977577,-91.72362038759127,0 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark14(-15.096246112444305,-0.6959854584584235,-72.73104327048577,-61.53001765625234 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark14(-15.112003410716907,-0.3825139473541861,-1.5707963267948966,-1.0000000129908704 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark14(-1.5173249421284256,-6.915794405588645E-5,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark14(-15.190312261824602,-1.1102230246251565E-16,92.79184640686293,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark14(-15.271427562942883,-0.03161582673205568,-31.616985722164657,0.8199965701921215 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark14(-15.283422911674226,-0.1517314386489291,76.98296827490161,-19.93977742792407 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark14(-1.5290037485027237,0.24815031970650728,-100.0,0 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark14(-15.316656455205365,-0.3711060975697903,55.237978917284124,48.1879286658625 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark14(-15.317292418011704,-0.031633405533146454,-78.0154965022317,0.043567977002407915 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark14(-15.321629011940502,-1.3363577078952367,-61.94557832149587,47.83647670623881 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark14(-15.328012846876746,-1.1102230246251565E-16,52.57851851538713,1.0000000007558585 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark14(-15.342516891271025,-1.327140949229338,-31.26777289430667,-0.5646021288484699 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark14(-15.391448846539879,-1.0886092227755908,-1.5707963267948966,-0.19075774028161518 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark14(-15.406595775346403,-1.0611614115342434,0.0,-1.0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark14(-15.483066070204664,-0.5679822953151414,-30.75599429120524,100.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark14(-155.5046645708012,-0.3657301385606946,-44.371946672624944,-2323.4577826287446 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark14(-15.557963947721419,-0.18300615699611456,-88.25448661465283,0.015554536430003707 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark14(-1.558884663701372,-1.5707954325712596,1.5707963267948966,0.9154493154809282 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark14(-15.597785699890355,-0.08515452385655672,0.0,5.252683592444083E-16 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark14(-156.0149389267463,-1.5707963267948912,-52.388371486142724,2299.794108589641 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark14(-15.621424977711598,-3.563063673727575E-16,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark14(-15.644511787253421,-0.771221664173978,-66.22805575077534,0.33922243463293 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark14(-15.645706990594343,-1.422480148084035,0.4368256943746246,-39.80565215560221 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark14(-15.656932029864489,-1.3835581325111113,1.5707963267948966,-79.85256798042597 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark14(-15.65715010789976,-0.7881504548617803,44.507522544031865,1.0 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark14(-15.68087441842269,-1.3487508694589678,-55.98802686688376,-63.67367228002418 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark14(-1.570388458656444,-0.17352481747431386,-68.02626881947423,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark14(-15.763565200640699,-0.32207807219462137,1.8816818632380121,0.11891966105892915 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark14(-158.42944043081235,-1.5707963267948912,-47.07472306560186,-82.44335797542377 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark14(-15.848911621670524,-1.052864846984514,0.0,1.0 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark14(-1.588236087491607,-1.3492293784469946,-29.980518845854775,-1.0 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark14(-15.894692855260509,-0.326073933782522,-3.326738520731439,-60.0501935992098 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark14(-15.93989860989388,-0.3276952040435086,-90.07557504614607,-77.26505389337186 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark14(-15.960282612941356,-1.5707963267948954,-1.5707963267948966,-0.0011868744115667781 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark14(-159.70843114048313,-0.018236986143077866,-1.5707963267948966,14.494244063713252 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark14(-15.979541414757364,-0.045724786286798054,42.4717565123606,0.3064261582198142 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark14(-1.5992880849059503,-0.10931127240925564,26.1956581444582,-537.1946571014452 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark14(-16.00587737560884,-0.5091380198674921,-88.3235916733441,-62.92629161667975 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark14(-16.032691575766982,-1.3632930251677144,-64.5739289211015,-0.13155175305672395 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark14(-16.076008705921268,-1.5200041978815952,-73.58706730867964,0.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark14(-16.100660168035056,-1.27350670764859,-39.8587650528485,1.0 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark14(-1.611322715637911,-1.1119486138990364,-101.9830246527833,-0.8490803639242333 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark14(-16.181788537876074,-1.4409253784217482,-0.8123127797344304,0.0 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark14(-162.27885741351693,14.430093055781953,129.25990747417936,0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark14(-162.58262434300283,-1.0460921377274093,-32.46700120983535,-1.5255007451119127 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark14(-16.267321014730438,-0.05501708528665086,31.84778071495081,-0.06259788637227037 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark14(-16.331679178948434,-0.011717554569697487,62.94167129503021,-0.930698894227599 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark14(-16.412455693107773,-0.5354842900859138,-66.98257460362782,-0.020014008904544772 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark14(-16.439266046741395,-0.42466434930303476,-1.7763568394002505E-15,-1.0 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark14(-16.446148704979986,-1.4118232847049998,1.5707963267948966,1.3401590328135147 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark14(-16.44979173271143,-0.37024720754917745,-57.0953155766497,0.9836757395704602 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark14(-1.648235144665307,-0.4407826881326773,-3.6592706106642674,-1.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark14(-1.6483457156761752,-0.8427661402608293,-27.773508704588316,0.9311133110227829 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark14(-16.543446054574286,-1.5705839855303316,-11.087467032986998,0.04449217860440631 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark14(-165.4372283712132,0.3193018080707829,164.79612233164363,-0.3998715278028181 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark14(-16.543870627529692,-0.030274326791233652,63.7722092357761,-0.5408456648351114 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark14(-16.545934007238934,-0.5325627267474624,-13.151845036874912,-1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark14(-16.59732295429282,-0.999371821207589,-1.5707963267948983,12.407590998075136 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark14(-16.626902094263297,-1.5707963267948963,-37.72905598482227,1.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark14(-16.64992585100874,-0.2031033405482997,31.800559277428356,-0.3984238885049922 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark14(-16.65377846183734,-0.10831190727424292,-1.5707963267948966,0.25609795676648506 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark14(-16.681745538007263,-0.06882534931995014,-1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark14(-1.6701366594356308,-1.5228797259366311,-3.552713678800501E-15,-0.05367575138609826 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark14(-16.74037880569965,-0.16734621531888585,1.5707963267948966,-55.83897954493349 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark14(-16.759200894557193,-1.5707963267948912,-21.490877953878083,-0.9900173965034588 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark14(-16.79160511173907,-0.24880152802878114,-1.289658767879497,-1.0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark14(-167.91953618835458,-1.0919124589069469,-199.2056474348028,0.999963605240071 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark14(-16.792644044890785,-1.0085432599578183,-18.209563327045874,1.0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark14(-168.18447181002034,-1.5707963267948415,-51.95716784368655,-18.25974811261912 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark14(-16.881106909353193,-0.14206876827075962,37.588913365185135,2220.2416520767856 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark14(-16.901270800796585,-0.16505402661178933,8.809222816072175,1.021141769523762 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark14(-16.910798704349236,-1.557854185720869,1.5707963267948966,75.6440326747728 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark14(-16.928237824899767,6.453310522010185,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark14(-16.951230888383936,-1.2176254114129696,-88.94284269395796,1.0 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark14(-1.6968710686268924,-0.10224261904245657,-17.35955316143034,-1.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark14(-16.99104982262095,-0.49275767446872426,-1.5707963267948966,1.0000000000001075 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark14(-1.7071748428827693,-1.4910490074174074,-49.86039060977272,1.0 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark14(-17.073564300376674,-0.16875614433326724,-100.0,-45.173363921705146 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark14(-17.09608437397614,-0.03686023762533153,0.0,0.0 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark14(-17.12036177569313,-1.1597443734455055,-56.53105318066063,-1.0 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark14(-17.139593179490475,-3.552713678800501E-15,8.116852058964443E-21,0.7068085189008518 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark14(-17.1643972542105,-0.04152954708185359,-1.5707963267948966,-1.0033624864699781E-7 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark14(-17.16851500044539,-1.5707963267948948,-84.59568627528259,4.440892098500626E-16 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark14(-17.17854525864714,-1.4985121073913665,1.5707963267948966,0.015132010487393464 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark14(-173.07431975594565,-0.9073728408108579,-7.572622792484026,68.76656940903675 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark14(-17.3426441066682,-0.0455500866517887,88.76511411361236,-0.4648014956944806 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark14(-173.7207234628487,-0.22989691265807535,0.0,0.06255432099936256 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark14(-17.37320604144502,-8.881784197001252E-16,-18.109873518619395,-91.44418216407247 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark14(-17.41680927643168,-0.7938279476177343,-87.02224629272918,1.232595164407831E-32 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark14(-174.32563545254862,-0.763423913708711,-79.2162180595681,-2285.773783729924 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark14(-17.453685872042634,-0.5416597616713026,-1.0576740676170686,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark14(-17.467610935679616,-2.7755575615628914E-17,-1.4750605879388332,-0.06190226713766048 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark14(-17.488886395118428,-1.4909842076053543,-1.5707963267948966,-79.86287488509197 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark14(-17.49003083788481,-1.230718700928866,-1.2316802906711803,0.5887417815260227 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark14(-17.498382702755183,14.895228403082932,-5.551115123125783E-17,1.002598153354507 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark14(-175.05514313480816,-1.0832157204218622,0.2746626787433446,-2111.1071261017646 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark14(-17.514958055894212,-1.2543840087142382,-30.240622358006092,-100.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark14(-17.594479784148174,-0.5956445953108526,1.5707963267948966,0.3547691578351917 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark14(-17.640384565649736,-1.136131751202953,0,0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark14(-17.68189202381503,-1.4491730744278926,-26.745161483267157,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark14(-17.707001130156527,-0.13313078314970073,33.28268986241068,-1.0 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark14(-17.711132758952875,-2.220446049250313E-16,0.30878490789054425,-0.19725320384832085 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark14(-17.723902798879443,-0.17077789688556733,-1.5707963267948983,-0.9999999999999996 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark14(-17.75154906740085,-0.21183046070834383,1.5707963267948966,0.061826563401906065 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark14(-17.75170173196928,-0.4880941162834366,46.31027682924096,0 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark14(-17.762685001961188,-93.10810053484013,15.502380708538155,0 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark14(-178.25747398733418,-0.4793068740723455,-0.33895691912551734,1955.9272508026863 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark14(-17.89662865559022,-1.5707963267948946,44.71107186832361,-0.5543472843057822 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark14(-17.910762434362482,-1.421737143531507,-1.5707963267948966,-16.047901645503266 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark14(-17.92735406682,-1.5707963267948957,-35.22689938102867,87.9821739831184 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark14(-17.96676041293302,-0.3727587890344335,-32.70228154068653,-100.0 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark14(-17.990006235386105,-1.5707963267948912,-68.63413782117902,-6.385849173763069 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark14(-18.002336837981687,-0.23731552542447176,90.4514456844172,-1.0 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark14(-18.030747599745954,-0.28202751381454294,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark14(-181.60627019713147,-1.2978693437711197,88.39954591713607,-2149.931171222016 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark14(-18.18615976650024,-1.5707963267948912,-50.69165607037747,-1.0 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark14(-18.260832004455143,-0.14596498788209822,18.06029062201346,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark14(-18.280781721452072,-0.07675022480974872,-35.260763940395634,2212.229072568649 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark14(-18.396128587437506,-0.041464992149287214,-0.7380969278941978,0.0 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark14(-18.427460330261603,-0.9152254748138624,-76.4314663547489,-1.0 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark14(-18.492419111665697,-0.883183774408438,-96.40124751834992,-91.11661502240062 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark14(-18.538019824685108,-1.2029809918942647,0.410836523537526,0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark14(-18.581753644117804,-0.41913546268151336,-27.335584946780415,0.4682063192463656 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark14(-1.8590066407785018,-1.5707963267948912,-47.30670794654547,-20.361725205374427 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark14(-18.60618600222773,-0.18769388659098274,-66.45436783733362,-49.66430688535808 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark14(18.64189796709475,85.32073543803693,10.917910186868696,0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark14(-18.65433971854867,-1.5267831411363686,-95.59272543023658,-0.8000766942288615 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark14(-18.688576304142682,-1.445629932850861,-46.007625605483824,69.90234428947907 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark14(-18.69931966873004,-0.7272172401220027,-26.490749079656453,-0.9557929720024226 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark14(-18.756587359137985,-1.3576604177252674,0.06150577807409719,-2.5444420607441702 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark14(-18.79200210506474,-0.8744493963640627,-0.10231870153080053,81.21407412582909 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark14(-18.822345214246667,-1.5707963267948948,1.5707963267948892,-1.0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark14(-18.851252241737875,-1.4498515959258778,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark14(-1.892816625217245,-0.030417749834020746,-52.5594135778824,0.042530846764782956 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark14(-18.99628130409687,-0.7468805895315143,-73.80532132405634,6.8836851080954915 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark14(-19.076497639732427,-1.2800385586444287,-77.82554282593344,-0.9604866587235117 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark14(-19.147219011608478,-0.41402384166856876,-16.266758301030418,27.215786871956045 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark14(-19.149536604008766,6.585656451658491,145.28352780097447,-0.5540858448702931 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark14(-19.15606439346128,-1.5707963267948948,88.38722307869631,0.0 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark14(-191.70915681477715,-0.691563741990668,-10.615718214424724,-14.378292360593669 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark14(-19.18895432124603,-0.7699413154847363,-22.808083657383712,-2120.424728307232 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark14(-19.21361207945335,-0.5662766126915367,-20.937947685770148,0.05595769148016905 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark14(-19.23311962506844,-0.4441303082396433,-83.36804528224921,-2142.4263886793174 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark14(-19.2340971409663,-1.5707961385835563,32.56236356597076,2.710505431213761E-20 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark14(-19.23600952981912,-1.5707963267948912,-74.23497191231228,-2374.1568771250513 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark14(-19.2399787743939,-1.5707963267948946,-1.5707963267925433,2166.890412596022 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark14(-1.9342969831758197,-1.5451704236878596,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark14(-1.9342994474138768,-1.1050051870583992,32.980114236608124,96.03233770037305 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark14(-19.395704926005486,-0.05822374168386579,-88.23951879749345,0.9965158733123154 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark14(-19.486970791362808,-0.050455866411153086,-9.569404360353005,-0.08570975849258122 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark14(-1.949543458250914,-0.4090062561538322,-84.40658718232311,0.8759544338020661 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark14(-19.503772459983033,-0.19711412303207965,-77.6095970377066,-0.05321057948438689 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark14(-19.513320231758538,-1.226234900850749,-71.31566844433422,-0.10471584080505458 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark14(-19.56340788913077,-1.5697964318140387,-74.94554561765443,0.9999999999999999 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark14(-19.5696391183341,-1.5049881485009167,0.0,-1.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark14(-19.573174736535847,-0.792104937241355,-48.26266855235104,-1.0000000449725823 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark14(-19.590102910299304,-1.5707963267948948,-50.161835507393405,0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark14(-19.6306640229123,-0.11457779778096289,13.008718819276481,1421.057094252191 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark14(-19.630692027090245,-3.608567069102556E-15,44.462911639463115,1.0 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark14(-19.64436607840194,-0.3982546999643097,-37.898949597264775,-78.39891768213047 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark14(-19.667772412049317,-0.3574423295799116,-46.86644436370757,42.74596235889342 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark14(-1.9685481484938805,-1.3971526441351918,1.5665466750403247,-1.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark14(-19.73378819269736,-1.307346712469274,-31.306223390684735,-62.87420160582975 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark14(-19.757676773770847,-0.05279631537473645,-63.38707265487525,-53.938478377922046 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark14(-1.9851798961040998,-0.5209468980754524,0.0,1.0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark14(-1.9876660014634098,-1.533124154994674,-45.141693867407724,5.445886404041843 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark14(-19.97354933504051,-1.5707963267948948,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark14(-1.9977594625258457,-1.5700204928248822,1.5707963267948966,-2.1929513996012744E-16 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark14(-19.980162806318816,-0.6152634854536814,-76.73136610123399,-44.85554021255445 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark14(-19.984902542123184,-0.5761316785613313,0.0,0.5500743747751907 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark14(-20.018277104223124,-0.1318609484775529,15.610599145939275,1.0 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark14(-20.018996990967327,-1.5700255724784755,1.5707963267948966,0.00975408548087163 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark14(-20.02562381358983,-1.3496453101809733,88.4852370039985,0.8218182853161817 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark14(-20.079859406260127,-0.8065908049165627,-22.489060393356553,-1.0 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark14(-201.7757315373137,-1.072510229598625,-157.52357523090149,-2.8787819767496156E-4 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark14(-2.0224978710243664,-1.5707963267948957,-1.5707963267948983,0.7514709930512333 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark14(-20.229876331311942,-1.4505221254688045,-1.5677503270947784,-0.29711599728306715 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark14(-20.273371177158282,14.438689353078267,-1.2499631792803931,1.0 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark14(-20.292761412749115,-0.633875167440183,-1.5707963267947065,-2239.4629122214214 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark14(-203.14962469255445,-0.944330466473177,-122.6457180061044,-1.0075679652475857 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark14(-20.331973310911927,-0.10034000925276665,1.5707963267948966,-0.029163989967495113 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark14(-20.392496418573685,-0.37337723006729906,-8.88190495481414,40.669372965077294 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark14(-20.426368339789267,-3.552713678800501E-15,0.0,-1.0 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark14(-20.42830726406975,1.7112171413195385,40.33240255225134,1.0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark14(-2.0469183922713903,-0.40608335064929935,-1.4857774700769937,-1.0 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark14(-20.516844244052898,-0.474347153613893,-27.729590316538925,10.798686562850381 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark14(-20.530972583451003,-0.06163320325700012,-1.5707963267948966,-75.14141220200838 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark14(-20.544538851962887,-1.5358629330254494,1.5707963267948966,-0.02362862625010953 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark14(-20.564655427254593,-0.31821808937752494,-2417.16316569642,0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark14(-20.57059642115499,-1.4273648688396396,-8.265012488871097,-1.0 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark14(-20.584411721421386,-8.881784197001252E-16,-95.76506670996835,0.1537949698705363 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark14(-20.619086906340478,-1.537349851683949,51.4417436222395,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark14(-20.684779648131823,-0.6217380562315782,-69.37871402905327,-81.03882780060438 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark14(-20.700543005081993,-1.5707963267948948,-29.825615943583735,44.900031474505 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark14(-2.071634608809488,-0.5463713009894304,-4.952369679559333,0.025599864626450336 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark14(-20.73986876561242,-0.6248168406027437,0.0,-0.6004085070806704 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark14(-20.74200810592035,-2.836970374480503E-15,0.0,0.9999999999999991 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark14(-20.74616618265928,-0.3572448513289554,0.1215627427844837,-1.0 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark14(-20.796935029510507,-1.2146909255728553,2364.8232577846534,0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark14(-20.820026883530527,-1.5478310778772837,0.0,-56.25237013664822 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark14(-20.83186728507693,-0.46199034961101715,-1.3755736104387049,-1.0000013728431663 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark14(-2.084396098675027,-0.33810551804327965,-52.666867922740664,7.578732687712035 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark14(-20.90808611846468,-1.5707963267948963,-11.207937067060612,64.91293240607152 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark14(-20.94332269747104,-0.12714662835204793,-10.11790866137428,-8.975412824551931 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark14(-20.979326574191116,-0.506470756887653,-38.41764022312275,0.9999999999999987 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark14(-20.990892754665282,-1.382712738795068,-38.804526587296785,-0.27875566255522966 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark14(-20.993479459561854,-0.3350304898623726,1.5707963267948966,0.9999999999999982 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark14(-21.021898537775456,-1.41643284876786,0.0,-0.9999999999999964 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark14(-21.02873519913754,-0.07054017519646083,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark14(-21.082334019029428,-0.39971226682847183,0.0,-2046.7232895207017 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark14(-21.084655538993708,-0.8357824588675014,-130.68079624335368,42.10995828092303 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark14(-2.119012462696951,1.698182955919665,77.86254838291528,-0.050843687626750664 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark14(-21.228349461474735,-0.29649811720978914,0.0423681462328116,1.232595164407831E-32 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark14(-21.228657044219545,-0.06458895587665076,32.83717938483525,-1.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark14(-21.233860048647287,-1.5707963267948948,-20.592688387738818,-70.77757223890579 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark14(-21.241335032376355,-0.4705611207185668,69.31330874339642,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark14(-21.29302080274073,-7.105427357601002E-15,44.01411960257116,-0.2720017298001063 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark14(-21.30558900514381,-1.077971693695501,-1.5707963267948983,-1.000000000000007 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark14(-21.32003582014067,-1.1102230246251565E-16,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark14(-21.34797777643648,2.8436726693804597,181.61738320153592,0.6840199877330484 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark14(-21.38510193821393,-1.318632397505441,-1.5707963267948966,79.59623721999164 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark14(-2.1390921716444034,-0.3867003693871639,39.27917436482824,-1.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark14(-21.4182062075261,-0.30637210842699397,32.6840659735992,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark14(-21.42218209364264,-1.5707963267948912,-91.62464484629278,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark14(-21.644850381593493,-0.6389546822985114,0,0 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark14(-21.672301724236135,-0.9928247429379705,-12.589409971922027,0.03633145802515485 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark14(-21.680366604494242,-1.5707963267948957,-11.68713225313414,0.0 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark14(-21.71747848444735,-1.4313443484833313,-1.5707963267948966,-2.3583250997808936 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark14(-21.791443854234192,-0.5635262948507269,0.0,-0.0085888651678665 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark14(-21.79149895561917,-1.371079667839812E-14,-55.07052666026408,1.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark14(-21.796335016336293,-0.4586784317976874,5.374300886053671E-138,0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark14(-21.79912781239821,-1.3923341876953528,-1.5707963267948966,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark14(-2.180745019461108,0.12592262652879727,-1.449778130295904,1.0182154987257772 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark14(-2.1873146018037204,-0.9584883519938563,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark14(-21.89649618906357,-1.2664452761528469,0.0,43.71762546855004 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark14(-21.910371344993806,-4.440892098500626E-16,16.904664345676437,0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark14(-22.020278119470294,-1.4683950211491397,32.53323644410565,0.0626334486328063 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark14(-2.206094402137255,-2.794199628697744E-16,-1.331323562095261,1.0 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark14(-22.171799318932514,-1.5707963267948948,-96.12986897926636,56.67740069856069 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark14(-22.210553771001855,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark14(-22.27726525983526,-1.5707963267005343,0,0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark14(-22.282669236356313,-0.04324313094113896,-67.76563394991666,2248.117825988941 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark14(-22.28692441556559,-0.3727180075130887,0.0,-0.9765997095556493 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark14(-22.331572320419035,-2.220446049250313E-16,-77.60700385316117,29.64437519842109 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark14(-22.349132767657963,-0.6653462354554672,-1.5279944082826704,-0.3642605116312257 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark14(-22.385140353230454,-1.543988407611728,88.21917810036263,-98.63299796772576 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark14(-22.416423032860557,14.467359376896766,-0.11398948156018196,0.002892616915489125 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark14(-22.456392007903844,-0.10430173354723568,15.638894929402774,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark14(-22.522817069196016,-0.9989053312909009,-15.508689357612406,0 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark14(-22.539779752138767,-1.1744359077704434,-79.8348512768797,-1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark14(-22.549106254501936,14.441264636419895,1.962717795826349,0.905702505697351 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark14(-22.589438865717728,-0.002251431211828134,25.171913299252736,1.0 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark14(-22.630131401936268,-0.4488475223734345,0.0,-0.3840037437162629 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark14(-22.728689631626235,-1.560552224773602,-14.211733059188752,0.9865175263892141 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark14(-22.81609144205353,-0.007370553283546077,34.10943209574066,0.0 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark14(-22.84374752783465,-1.2729707555650949,0.0,1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark14(-22.864836139030487,-0.28361862907567104,-78.2530356724726,-1.0 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark14(-22.86669890977869,-0.054744572653472004,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark14(-22.873498888662496,-1.087278777594947,1.5707963267948966,0.8941246529638813 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark14(-2.2933757039444123,-1.3698332776299955,0.0,-0.7131186389850046 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark14(-22.963276571533456,-0.0043756216889795935,-64.46892143557247,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark14(-23.003439397426376,-5.092262365924708E-16,-98.6048225276208,0 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark14(-23.04086052680627,-1.4635305253682134,0.3478783081293601,57.39052376279085 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark14(-2.306221623357597,-1.7763568394002505E-15,0.0,0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark14(-23.070304704650436,-1.3794954026413655,0.0,-100.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark14(-23.07903242896353,-1.3593527275345556,-61.00555123330295,-0.028289901291431926 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark14(-23.108535676838798,-0.7783193470365007,-56.90215265014527,0.8736268439254575 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark14(-23.142152822781828,-0.5354328304541297,45.093553907638736,45.267383083696515 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark14(-23.309333173662537,-0.5685264325091453,-1.5707963267948994,-32.526831884505825 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark14(-23.382823943550406,-1.5707963267948912,-62.49626020982358,-1.0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark14(-23.434716659415017,-1.1324382997721634,0.5661978755643254,29.002141435090664 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark14(-23.463496054692335,-0.895169331889085,0.0013781018375087998,1.0 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark14(-23.463614048192504,-0.15688550534469314,1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark14(-23.466346059839186,-0.47531699162618035,88.19328164635688,-31.25181677184669 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark14(-2.3477881547393236,-0.8791952102496392,-0.4727778056510987,32.728478493903815 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark14(-23.48194599266782,14.429288572099509,84.17321502680038,0.057031379794638314 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark14(-23.486764752259106,-2.2189193939342947E-4,-1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark14(-23.48940629219445,-0.7800488032879329,-50.60170390013058,-0.13564690905182442 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark14(-2.3548384012143515,-0.4913172535894865,-74.62987922800295,0.5575327157461193 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark14(-23.5508245279769,-1.5707963267942908,-44.35099524070545,0.025514047441148987 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark14(-23.559552806043595,-0.5928980266673445,-12.722369033039403,-54.02433277935605 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark14(-23.709090681562397,-0.03404412082588015,0.0,-0.15931760696072228 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark14(-23.711165889912373,-6.05093238646999E-4,32.6803155508573,-1.0 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark14(-23.733856166534096,-0.26064509764775856,63.1869972943852,-1.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark14(-2.3739900317671947,-1.4276266533264133,-100.0,-1.0 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark14(-23.7433110300402,-0.3670735340413059,-9.816339969473574,-8.293402371664751 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark14(-23.769560640911244,-1.3312056354216946,-60.203084233941674,89.25322587889298 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark14(-237.7341324884395,-0.4250642796837467,-95.39897797790724,2074.2924412922557 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark14(-23.845100124867677,14.471942675045739,33.970398250736054,-0.9961737797012293 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark14(-23.86234910180478,-0.07805620043522773,63.05751340210807,-100.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark14(-23.863438268580644,-0.5025291715511093,-23.664258413634087,-0.7295730880776271 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark14(-23.888113743324038,-1.2916975036482023,1.5707963267948966,-62.5638724191726 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark14(-23.9171837189717,-1.5707963267948912,-159.47573896463905,2312.4592998151697 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark14(-23.918765480323664,-1.5707963267948961,95.3295279159259,0.9999999999999998 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark14(-2.392733717796027,-0.9189145444956888,-68.4407852121924,2128.0498172130374 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark14(-23.940757740576075,-0.2814838422884826,-72.5014476767566,-65.18783568341705 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark14(-23.960817605866392,-0.8256359869429762,-6.744452753758388,1.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark14(-2.3973116738269367,-7.789660890527526E-4,44.011939475213794,-1.0 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark14(-2.399211140775991,-1.5707963267948961,-1.3484204636311923,1.0 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark14(-24.128123224214804,-1.1403291159447535,-68.42258006600998,-2.3054882540093296 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark14(-24.144860108666435,-0.6935100679963426,-1.5707963267948912,-0.6699046441576098 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark14(-24.1493976228372,-0.7093862150556283,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark14(-24.182968470743695,-1.4282687703105965,37.74125027658138,-65.29911673779895 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark14(-2.4213990901728213,-1.5698361305013895,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark14(-24.216384251423708,-0.07811720546024936,0.4472581729587404,-0.0221476677288493 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark14(-24.22230720977791,-1.0425060011793268,-69.90235222001536,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark14(-2.429058139207797,-1.5707963267948961,0.0,0 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark14(-24.295674307452103,-0.2935042504632328,-24.007626975149932,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark14(-24.39167931109602,-1.1102230246251565E-16,59.426132496323355,0.028433660072711656 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark14(-24.540102673162465,-0.06455384451656723,-57.54844612194612,-1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark14(-24.55576729281273,-0.025094833911195595,-1.5707963267948963,-84.77191123401447 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark14(-24.56952331510431,-8.881784197001252E-16,-52.56014482315513,-0.3929788365310767 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark14(-24.649222036620007,-0.10966285208520131,58.17982022787672,-2090.1922522496534 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark14(-24.65437205603986,-1.5707963267948961,-10.809929631568435,13.572463571749335 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark14(-24.71103179871335,-1.1974585295340887,-129.83032739617713,0.9595128778602274 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark14(-24.725611103740363,-0.20515814594207918,-83.62824849661914,0 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark14(-24.753224496743925,-0.1904661377149006,-94.29805137566196,44.81831562979055 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark14(-24.800846667086983,-1.540087463963156,-17.01968766970459,-61.16616210561028 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark14(-2.4808618468820534,-0.6955845580070164,-0.4572725598281266,0.26519851362163616 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark14(-24.863747869473478,-0.8969495441594438,-30.36647423392317,0.010568495192678272 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark14(24.87195996340344,28.370791233879146,-92.62880623440269,0 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark14(-24.87913769679343,-0.2882708521954829,31.932529479236138,1.0000052955901646 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark14(-2.488467804215574,-0.08372621330664953,-125.97415559164956,1.0 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark14(-24.91222921593345,-0.41378476813527443,-1.5707963267948966,0.314012183470762 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark14(-25.080353200195432,-1.3436212936884493,31.75668494876183,-9.834008504279671E-17 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark14(-25.082281171382398,-1.1472582211864992,-74.66124327194971,0.05210925850968376 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark14(-25.164214183181734,-1.5309726327427127,31.77304505286176,-28.81689267408609 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark14(-25.180771121456882,-0.5159249046027261,-31.491831803703583,-0.76556904943572 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark14(-25.19959133656795,-1.570796326794202,-43.381584881047395,1.0 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark14(-25.339425567437758,-1.3747772418712714,-15.892420420841447,7.105427357601002E-15 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark14(-25.349481854695618,-0.2775707348830709,1.5707963267948966,99.91453309167358 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark14(-2.5438987793722845,-0.07637047640090791,-36.06769570251335,-0.6515459384291076 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark14(-25.519040410006934,0.4630155994413382,0.03627050623400629,0.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark14(-25.55767162447682,-0.977368026976951,0.14595307112905243,-0.9999999999999999 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark14(-25.55844051763588,-1.4602596215445167,57.9593326825593,-0.06132013504687095 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark14(-25.59439363988196,-1.2903664533749035,0.0,-0.2500284259360289 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark14(-25.620812268377794,-0.8728771533417575,-93.20010430151231,-0.9946270000121342 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark14(-25.691173263908098,-0.6996357782396352,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark14(-25.695378220882677,-1.5445177713664777,-53.964456590436676,0.7731260581168248 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark14(-25.73386602957404,-0.8335901883842379,31.724451518703397,-0.775271912892384 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark14(-25.739083974583117,-1.079823340564673,0.6625197397773883,-45.1772589384601 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark14(-25.789397683561802,-0.7183768331126734,-88.3978334694381,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark14(-2.5804838790022213,-0.14084681743955846,-40.89948633872842,99.14440429136964 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark14(-25.883751443763288,-0.37379319374861775,8.710886284411856,-56.58521195769528 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark14(-25.9078501590764,-1.4220312116113547,-54.28449766764319,0.0 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark14(-259.6601885762692,-1.2992134043564856,-67.884696603192,0.9907349533993939 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark14(-26.062904087393743,-1.4256388060173393,-90.53250449319397,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark14(-26.08674786513774,-1.5707963267948948,-12.28780721978765,-0.9733331073648781 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark14(-26.09106871028698,-0.7017493024224226,57.40730214116607,-0.6067165389299731 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark14(-26.14161880299502,-0.7494385102538752,-73.64887983105939,-0.9979354153267577 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark14(-2.6169582352179503,-1.411930346120106,1.5707963267948961,98.6411749207769 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark14(-26.18660569688218,-1.4189320921993944,0.0,0.0 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark14(-26.203095837461756,-0.06445897713250148,0.020701136347852176,1.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark14(-26.256128078878362,-0.5056879089091967,-1.5707963267948966,-0.9999999999999998 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark14(-26.392170287051886,-0.12301052068609664,-62.13894322322045,1.0 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark14(-26.46436526696401,-1.5641201120079746,-1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark14(-26.465937306898994,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark14(-2.647801624761866,-1.5707963267948963,0.7695325027568051,2210.921840931878 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark14(-26.491626230693655,-0.2259267144708559,-46.15462251093452,-0.9999999999999998 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark14(-26.49761955212358,-0.016155012054577977,0.0,1.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark14(-26.58745099818824,-0.062398358396266895,1.5707963267948983,-51.83854851001394 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark14(-26.59286765972836,14.579473908191254,1.5707963267948966,0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark14(-26.635236578919443,-0.5423463740989584,62.98063935181523,-0.051669224984290094 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark14(-2.6651712553603417,-0.35981190008176744,-6.712437213571367,0.03188595359682822 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark14(-26.706937388619387,-0.5962585901755902,0.0,1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark14(-26.721936422548588,-0.08391473268584623,-0.122276340170735,1.0 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark14(-2.673518817092429,-0.34830027711126066,-69.07485373667174,-0.017684578652089424 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark14(-26.753835964152827,-1.4964695336639438,0.0,-0.02871828907673786 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark14(-26.84080274424407,-0.041843192729185616,-6.024203387266525,1.0 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark14(-2.685285191972527,14.429687794845783,-1.505917843615799,0.01840741956046099 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark14(-26.85736466120679,-1.2244417245004717,0.0,10.207545043702865 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark14(-26.9123326744943,-0.06953103285044392,-66.27750090152095,-0.007384353028551061 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark14(-26.937767395535428,-0.5139685361589753,71.92264207759872,-0.9999999999999823 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark14(-26.945756500329104,-2.1027994774015485E-5,-1.062792541294674,0.0804450715731871 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark14(-26.951234059945712,-1.2060808532176885,-9.18818083738391,-0.3622043225917508 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark14(-26.967034091008042,-1.2230148948912565,-25.95136833019618,5.551115123125783E-17 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark14(-26.98433236179835,-0.5475708293231737,82.82158162055194,1.1282453289795582 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark14(-27.026534032432757,-0.8915153754235743,-1.0891724026232126,-0.502752057166912 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark14(-2.7120142149729105,-0.39333108475948475,89.68735958730117,-2179.75502048907 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark14(-27.14500713902971,-0.3831208194017221,-8.938952557462635,-0.06255252820585523 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark14(-2.7216273454564237,-0.08487481156256954,-1.5707963267948966,0.06255924994168872 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark14(-27.316760268910205,-0.3848072230418048,-74.66511027069325,-1.0001221550456687 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark14(-27.333123239072975,-1.5183373647318579,-21.121823466625074,-1.0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark14(-27.366215129435247,-0.001650702400595952,-0.9843453629925643,0.025180093211177923 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark14(-2.738094977204434,-1.3844972979222134,-32.78300093365923,0.3620893089042855 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark14(-27.38187808821476,-1.4538775263141321,-80.5044895983378,-0.06255314858263791 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark14(-2.7533457731573776,-0.2415008508370704,-7.491433863380423,0 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark14(-27.555459215416448,-0.03708534488840863,20.809140986437324,-0.40000105062228386 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark14(-27.59919149675423,-0.0786897763890811,20.82929872206958,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark14(-27.613655765430167,-0.0012782137368454547,-79.73337468827029,0.020339318840249865 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark14(-27.624660391133055,-1.5707963267948912,-73.54553843104182,-0.045034405716670195 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark14(-2.770563708366784,-1.5470849811085723,1.5707963267948963,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark14(-27.706330396917068,-1.5707963267948948,-28.165685776117094,-0.764382729365936 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark14(-27.708033313033656,-0.897942874679812,-1.5707963267948966,-0.6280073220515945 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark14(-27.7429973549713,-0.08657163220745234,-58.37392233820753,-1.0 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark14(-27.78341134519333,-3.552713678800501E-15,-44.40892745409511,-1.0 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark14(-27.78977381735092,-1.7763568394002505E-15,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark14(-27.790965586223535,-1.1629045850249362,0.6696938453738788,1.0 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark14(-27.828426629273096,-0.1462491050987368,19.390940809468105,-0.553209387118901 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark14(-27.829227225023388,-1.5707963267948912,39.147859620721604,6.682615136925648 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark14(-27.841441394593446,-1.5203390711368225,-1.5707963267948966,-53.64685434666572 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark14(-27.863020076478094,-0.4545733701146896,-80.3702676371041,1.0 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark14(-27.890167408444736,-1.5707963267948948,-20.674351508270437,0 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark14(-27.935762519903733,-1.345898482089678,88.38837346043972,85.45678286406213 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark14(-27.96299394214428,-0.5137601436550718,-32.93097775603678,94.06932337190014 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark14(-27.970702026822522,-0.5181479211381657,-25.91001210252682,-0.3326810151003743 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark14(-27.984270675499378,-0.05618051982888063,-49.7420327783332,0.026005736885851963 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark14(-27.984800195270903,-1.2268090576011432,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark14(-27.99460464930616,-2.220446049250313E-16,-13.997782244994571,2.710505431213761E-20 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark14(-28.080471499630665,-0.809518245301271,-10.559953519874156,1.0 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark14(-28.08745473262521,-0.3290968565687482,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark14(-28.099331159882816,-0.08274924446304652,65.51208512235026,-1.0 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark14(-28.10548766595536,-0.7305596623681291,9.529275983922629E-4,-1.0 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark14(-28.15811259036655,-1.1510699632175798,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark14(-28.18415566048962,-1.5707963267948963,88.35374950181368,-0.9451297864066781 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark14(-28.209754471092232,-1.4385917060931097,-0.6551013404361399,1.0 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark14(-28.25012555816489,-0.5260362046183161,-0.015708940114991243,100.0 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark14(-28.25552971194272,-0.10905702812423222,0.0,-35.50838023948432 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark14(-2.8306879127244096,-0.003093353287298317,-3.008420979288111,0.13468359573960864 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark14(-28.318456612245765,-1.4865362556209316,-89.29696552645606,1.0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark14(-28.372831350600777,-0.01756655276656427,-32.13725688419325,0.1349815496558251 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark14(-2.838546119227601,-0.03239833369034118,1.5707963267948966,-0.24760099041192174 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark14(-2.841683791570668,-0.15471314092856392,-1.3875162008219473,-1.0 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark14(-28.43490318290107,-1.5707963267948957,-100.0,35.51418118607945 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark14(-28.47209816518424,-0.26313175722360144,-33.73964247477604,-0.0507410489420846 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark14(-28.516196718780115,-0.3652002289790772,-41.73411232118756,-30.46463021074323 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark14(-28.67848785791108,-1.5707963267948963,0.0,-100.0 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark14(-28.826118545201616,-1.0248881260242553,-24.234140795007733,-1.0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark14(-28.874507481073657,-0.5183925107464106,72.14360935565901,-1.0 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark14(-28.916811857996176,-1.4779037939323223,-93.28611355735418,-1.0 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark14(-28.939440332747157,-7.421085998339451E-4,-83.78340054017539,-1.0 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark14(-28.9626628470389,-1.510528889896083,-1.5707963267948966,-0.0010815076977147098 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark14(-29.004067592123526,-0.07734202319177268,0.0,-22.995249830828683 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark14(-2.9009739733924005,-0.4744745181819551,0.42027327136508263,-0.9999999999999998 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark14(-29.0246079246169,-1.3314617870108865,38.93768809221135,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark14(-29.036581773773527,-0.034805953145281024,-13.067476335506468,0.7453532326390073 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark14(-29.141659086206587,-0.1507840779944516,0.0,-1.0000000000000002 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark14(-29.15718511092302,-1.3911210019539038,-40.41907967589602,1.0000000000000004 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark14(-29.296971483159407,-1.1102230246251565E-16,70.74160657184896,-0.05176644152515339 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark14(-2.934831551718048,-1.5707963267948948,-21.047816085373587,49.378120456681955 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark14(-29.356335481896707,-0.7079763123817915,-10.668256128093532,-0.06074679449543979 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark14(-29.38033929256575,-1.3370652205849698,163.41646960849772,1.0002771236454315 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark14(-29.42671342588968,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark14(-29.443060660303047,-1.5220722444193509,-18.853206883014128,-82.90972559538017 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark14(-29.446826772201234,-0.0638088412781395,-74.93754279419413,1.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark14(-29.48273920755814,-0.42270205676633876,-3.1807255784944743,-2059.0269751592914 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark14(-29.493356104632824,-0.7794495516040104,-100.0,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark14(-2.9498765005369876,-0.24392459281571632,-68.57868774362277,47.316951999486946 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark14(-29.51241518767482,-1.0670819230183999,-66.18209165650362,0.3748723871734043 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark14(-29.53141954164728,-1.5707963267948961,-1.5707963267948983,5.717635540890997 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark14(-29.580480726032345,-1.5707963267948912,-9.065412778665873,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark14(-29.625162778495913,-0.10639404165636379,-45.27072881746022,-2101.102196346141 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark14(-2.9647981181946506,-0.11816412553615895,-1.5242757957828035,-71.35355480662903 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark14(-29.903119047412602,-0.3555001925567495,39.935148459091835,-9.388397977732613 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark14(-29.905756470861476,-1.1183788591892863,95.77462985978829,-1.0256890515125217 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark14(-29.958419483217845,-0.013954332697134864,14.69731181779073,100.0 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark14(-29.968985916847373,-0.21012108545400565,-59.15110613374155,86.72683850907066 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark14(-29.989429523026825,-1.4032780555327748,19.981961884799112,-0.054707478177827465 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark14(-30.091552484282495,-1.1905326604308772,-7.796976538432249,1.0000002598674258 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark14(-3.0101946316173405,-1.5707963267934228,-53.88798777147294,-0.056224646938207085 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark14(-30.136249612624137,-1.5707963267948912,-94.16368833977108,0.11624872143008957 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark14(30.166769103415902,-75.12930999535342,0,0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark14(-30.20840171341859,-0.7052173025825405,-64.34591442339979,-18.775406270119056 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark14(-30.214852017965384,-0.2329433265790621,-69.58978686215075,-0.250325829068563 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark14(-30.30058512083089,-0.08240344292053658,71.0439197640628,0 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark14(-3.0309034049867747,-0.2731762424724653,-74.98010998464437,59.82989407902454 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark14(-30.333151693795713,-1.5707963267948963,-87.62821544760699,100.0 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark14(-30.400478030898398,-0.06936106017148154,-0.011723527636833965,-0.29348788237744583 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark14(-30.465019968632973,-0.4811602777942574,-48.30566952738971,-0.06262816317972433 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark14(-30.494397402634732,-1.373441660210008,-57.77591888159172,1.0 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark14(-30.51976253030341,-0.16766190846548107,1.5707963267948966,0.8391162687180822 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark14(-30.544061954396025,-1.5270520709316961,-33.05629865556626,-1.0 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark14(-30.555887827013244,-0.018599932177004064,-62.231670670375806,12.635662605978567 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark14(-30.60587329674562,-0.4874704253680022,-1.5707963267944116,-0.11245376860972112 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark14(-3.061784443853856,-0.7647514549855272,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark14(-30.655649563389225,-0.857272076413095,-68.94947961486464,-1.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark14(-30.69506988211279,96.56088279696937,-98.95243824890704,0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark14(-30.74077558611978,-0.8863985116095277,32.18051614030159,-10.372002195875359 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark14(-30.788726425870664,-0.41853379653881984,-8.4132702394799,-1.0 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark14(-30.89890066727296,-1.2974324405511994,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark14(-30.937571789222275,-1.281801175446223,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark14(-31.01773608919862,-1.5707963267948948,38.820788953023744,-1.0000000000000002 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark14(-310.43470119573055,-0.14990954695947034,37.82187248536256,0.0 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark14(-31.078219366791913,-0.04054097749269011,-4.75858467446018,-1.0 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark14(-31.091923955880343,-0.32610001780289877,-85.0166774648039,-0.0016612046476149889 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark14(-31.112136339919676,-0.7056347048474088,-9.811345902348705,2150.061618300138 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark14(-31.15571277707772,-0.24482867290656063,-0.008044802415926722,0.7360325494348979 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark14(-31.1638562922026,-0.3555807400341984,32.6146726876164,0.7657475796146694 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark14(-31.20076221582609,-0.8887952637718889,38.70578153528512,-20.261888182391715 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark14(-31.210340089924397,-0.16688695044783963,-33.34610049322508,-34.10301810391804 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark14(-31.212793007013182,-0.9455466157238951,-37.49991826590405,-1.0 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark14(-31.233148374730888,-0.06601445319072738,0.0014275707544759188,0.0 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark14(-31.241862189923935,-1.5707963267948486,-48.117873074909646,-1.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark14(-31.248065912739264,-0.09913293993415923,-31.904490637398418,-1.0 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark14(-3.129862754548032,-1.5707963267947562,45.05552809792861,75.20507842198197 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark14(-31.34994774979997,-1.348967329210393,-72.0544198447187,-0.9791672834984269 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark14(-3.1375336917945535,-1.327126622307189,-96.01373337504371,0.7738726099621537 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark14(-31.422119917482796,-1.2781135306043314,1.5707963267948966,-99.37064230021107 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark14(-31.446950468752824,-0.8062493798628995,0.6065930732189748,68.65224992603979 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark14(-31.477049571227035,-1.4373278379875396,-31.956833585573868,-25.453212569875372 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark14(-31.525457228146685,-1.5707954693082202,-1.5707963267948968,0.04727829158618835 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark14(-31.54546387471062,-0.7435034933465259,-36.63934953020123,-1.0 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark14(-31.557854073558783,-1.4604779127501246,5.551115123125783E-17,1.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark14(-31.613619678991626,-1.088840526280553,-44.513374741261615,-0.3721468928427787 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark14(-31.7281018627515,-0.5012241140166207,0.3541453173547673,-52.14586692158463 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark14(-31.801052611059326,-0.04607087964038042,-43.67278897404719,-1.0 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark14(-31.824467741467465,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark14(-31.939232049030373,-0.13736193065193103,64.7652729731094,-1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark14(-31.948810841282665,-1.1493899893344421,51.33721309587594,-0.3767449465176689 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark14(-31.993022091052964,-1.5707963267948912,-37.72130552110102,-1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark14(-31.997435111518907,-1.2890574467441667,-36.318499204012156,46.67464001144092 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark14(-32.24837297906841,-1.570796326794896,0.5759209535550732,-1.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark14(-32.27017264306505,-1.5283385939796899,1.5707963267948966,0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark14(-32.308407917701274,-1.5490130598078657,1.5707963267948957,28.219448809759555 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark14(-32.44838388051639,-1.1381025047290054,13.718874781914474,-0.04075595633398562 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark14(-32.47071659701946,-0.35303681920262164,1.5510918254133632,-3.370552723927089 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark14(-3.2628553397659097,-1.3702089842086425,-24.283449793741923,58.14355384881668 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark14(-32.63946654922913,-0.0582824476107178,-1.5707963267948966,-1.0000003825588093 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark14(-32.659608727773715,-77.53168602588116,-76.52167312180265,0 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark14(-32.72126811558733,-0.248688594356415,-3.552713678800501E-15,-0.056848570965128076 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark14(-32.72659042215796,-1.3559322803202174,-51.37175899599144,5.06642435443066 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark14(-32.73168577621372,-0.8851965530813156,-64.24787650340777,-2142.455289770668 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark14(-3.274610824928196,-0.06014501603535749,100.0,6.776263578034403E-21 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark14(-32.75412284305487,-0.981992641831221,-43.6103352309555,1.0000000000000002 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark14(-32.898845498711864,-1.5707959339029962,-11.087298974476235,-1.0002284059353397 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark14(-33.03671274998352,-1.3247193163607112,1.5707963267948966,-0.8494971194803218 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark14(-33.03836533232662,-0.5944735473335767,1.5707963267948948,-3.6457809513693604 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark14(-33.04932207434219,-0.6404192484304058,39.225929336085585,-1.0 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark14(-33.07478588704811,-1.1115859725202544,-6.229346445587765,0.30867228475535097 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark14(-33.07479659259187,-0.10918540179187788,1.5707963267948966,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark14(-3.307701312278672,-1.5707963267948961,-12.301708547491696,0.6925518487363735 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark14(-33.09661762693653,-0.999747165242932,-60.78769935774217,0 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark14(-33.14480292336853,-1.5707963267948912,-72.7023504498258,0.1087807204462351 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark14(-3.3159733392796684,-2.220446049250313E-16,0.200457742143838,1.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark14(-33.19018855170401,-0.9672531493507766,-22.47559089317658,15.113084849009397 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark14(-33.228939816351186,-0.5665637978151623,-71.41648922995805,-1.0000126489297232 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark14(-33.246145237791154,-0.026999957502844424,95.03929646780321,63.406467959784834 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark14(-33.288648173305425,-0.2695584445913387,0.0,0 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark14(-33.28865762726957,-1.0487419252717722,-4.440892098500626E-16,3.4471780038203457E-31 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark14(-33.32424685423894,-1.5558288234133975,0.13321668103087406,-1.0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark14(-33.333520512505046,-0.4872781152548171,-21.13285333695996,-1.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark14(-33.48027104198691,-0.3272882364266648,-1.172245206610008,68.75118296449804 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark14(-3.355463640374694,-0.08408236621753007,-93.87115807666808,28.739410710595166 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark14(-33.56683884039475,-1.5620101510895914,-25.05095386217593,-1.0 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark14(-33.58172417897478,-1.5707963267948841,-55.48713755878077,-0.7099265114287518 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark14(-33.59068457060215,-1.5574032384544951,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark14(-33.61986271113077,-0.29281906000582314,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark14(-33.62234276879927,-0.6296210430348026,-43.65052607777393,1.0 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark14(-33.626257463534394,-0.5161111798198252,-46.72089488790972,1.0214785178356398 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark14(-3.3641344791609247,-1.3499178213355187,-31.548872373908075,-1.0000243598667358 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark14(-33.65409874484622,-0.12392426181011441,45.229931567385755,1.0000000000000036 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark14(33.779594402721585,-1.4479418179870436,0,0 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark14(-33.854804695296494,-0.07252960784572546,-1.427130370686926,96.19598242736774 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark14(-3.388750347598939,-1.09699123456301,0.0,-1.0 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark14(-33.89007851320552,-0.9901366548574901,-31.854072049017248,0.8506925674326038 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark14(-33.9035597604875,-0.07095574140924146,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark14(-33.92290466232207,-1.4458964629191513,-53.02042092090109,0.8359428155601188 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark14(-34.01976301862351,-1.1102230246251565E-16,46.43652892764442,1.0 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark14(-34.02942338591587,-0.49828029708282084,-56.111329383815175,-1.0 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark14(-34.04283981549412,-1.5707963267948948,-53.48630651035458,-63.498917539625836 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark14(-34.04752434811104,-0.32646522792937577,-11.953291461915816,-1.0 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark14(-34.10954577193391,-1.4638794774332968,-22.297841988226754,-17.0474693388593 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark14(-34.15714002204935,-1.0527074240018872,0.0,88.2940360727829 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark14(-34.17337992655744,-1.5707963267948948,-17.673317813528676,-0.017679779401325924 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark14(-34.189775286135905,-0.8096575678445888,-35.633275959834734,-6.953418319097235 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark14(-34.22946187780541,-0.9056334620661783,44.188643567616,-0.047464508804530264 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark14(-34.231586249479925,-1.186992717233933,-0.1101306568603215,-0.9810762529299072 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark14(-34.255620694343975,-0.9266331268384623,-0.10334506245954075,0.9049179496555204 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark14(-34.35796971069442,-1.1008508055360657,-79.84974396430121,0.05063634150970442 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark14(-34.36494396679471,-0.02062951421564714,1.5707963267948966,17.10651802829758 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark14(-34.48337607480412,-0.7647441377816303,-0.23092919862710826,1.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark14(-34.48514944294858,-0.04958884905377131,-88.83605179213707,0.48024378229562836 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark14(-34.513475698715524,-1.7763568394002505E-15,-15.145475174232189,-2138.4739413330226 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark14(-34.524881038986656,-2.220446049250313E-16,-42.59153078415747,76.46103186478437 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark14(-3.4532625368397576,-0.729723866697699,-20.31313241709624,-1.0001844248738603 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark14(-34.6249174316133,-0.3049613574651682,-41.454519445442266,0 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark14(-34.7125083859041,-3.944304526105059E-31,-1.5707963267948946,-5.297725375932461 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark14(-34.74788116221254,-2.220446049250313E-16,-1.5707963267948957,0.7050625429194071 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark14(-3.4773849261036,-0.9412881718198662,88.42368969658686,-1.0 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark14(-34.789758156750494,-1.1312937096134936,-28.922392920848708,-1.0 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark14(-3.4823228895328024,-1.2221337419038667,0.0,0.9873377289259913 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark14(-34.948924157043734,-1.1102230246251565E-16,44.45255320813474,-100.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark14(-34.95926937633948,-0.2128005943797581,0.27010858280736555,0 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark14(-35.05290300162181,-0.15323540659075355,1.5707963267948966,-51.48938844445417 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark14(-35.12252984496396,-0.19529716785661444,0.7253287748852617,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark14(-35.19173487515628,-1.2248758852116097,-54.409489615848614,0.0 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark14(-35.2559977577683,-1.4179502304754477,-1.5707963267948966,-0.3754909901157325 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark14(-35.285769112991254,-1.5707963267948957,-0.4620270798207216,-1.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark14(-35.306097706988695,-1.2129087397346405,0.0,-1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark14(-35.35087303698199,-0.04326460670218084,0.0,-0.0016802217698261013 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark14(-35.361354158183346,-0.6120325346278447,-15.732646232246298,-27.638034053400254 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark14(-3.5367245076057845,-0.7186899385940478,0.0,26.172937728565678 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark14(-35.395578448355515,-6.437566963048073E-16,31.829720953574117,-9.53072659996136 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark14(-35.39988521333919,-1.5690711259477776,-5.9586311215404635,0.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark14(-35.41055636446451,-0.4136946768963039,-78.6103779616703,0.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark14(-35.41177129035008,-0.9761528819723813,-65.33314726258953,-0.9820500552043386 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark14(-35.414801253830774,-0.27866123286695504,-1.5562974029512178,-0.26754523732529556 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark14(-35.479454931624346,-0.5393367213032684,31.670007177565793,0 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark14(-3.550542098454441,-0.39506033507395916,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark14(-3.5520000716685027,-0.2529926271302887,-4.078331259928248,0.9565801057934861 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark14(-35.52901152232198,14.71356400980109,575.9370668204474,0 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark14(-35.54282228906707,-1.5692372178163514,37.85093004793504,-88.96632517732645 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark14(-35.57721479143214,-0.18017065345912942,1.5707963267948966,-1.0000000000000009 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark14(-35.59331752736086,-1.5707963267948957,1.216358494083849,-0.026860235682451883 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark14(-35.62481738454084,-1.002818367833349,-24.15417724816074,0.5759077476336696 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark14(-3.5689529092366885,-1.5682543611789284,-35.80085530822386,-0.9999999999999996 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark14(-35.71825597060257,-1.5707963267948963,-67.16211528044192,-95.57019788035626 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark14(-35.77499138416828,-0.5904804319557896,45.522676440207164,-0.04959662280560193 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark14(-35.799949036621314,-0.3983766455427288,-0.3923068330439976,0.02919764105113065 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark14(-35.814538658440014,-7.105427357601002E-15,44.90918675297251,-2279.0950676890793 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark14(-35.8238160885726,-0.01026819271684673,46.96634030842491,-86.64670595380731 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark14(-35.93210182100522,-1.5707963267948941,-60.659358608456856,-1.0 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark14(-36.02908311000704,-1.5707963267948948,-66.29873240872367,-0.677672544767422 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark14(-36.03343592507689,-0.4078874967454302,-16.487582703759003,-1.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark14(-3.606539103857276,-1.5707963267948912,-17.07569669440986,12.212360948281297 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark14(-36.095345137126046,-1.3308428732665674,0.0,-67.95720449047312 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark14(-36.12207243181213,-0.1112387103601182,-44.41429846024276,-1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark14(-36.177356772749945,-1.3989777918198818,-76.28405974889156,-15.907522266184372 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark14(-36.18552786037977,-1.5405004325592453,-65.00754007180637,83.18382042469213 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark14(-36.24578682632336,-0.0685577634694373,-1.43430121115948,115.3016697011576 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark14(-36.246490053144505,-1.236914454314943,-1.5707963267948963,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark14(-36.33138619158687,-0.2840003280182788,-31.676014648495737,0.05024844067288514 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark14(-3.6397550847429336,-0.709671417121521,-85.86832699786484,0.05723506786836596 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark14(-36.558660402527515,-2.220446049250313E-16,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark14(-36.56163792785356,-1.3730154637536618,0.0,0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark14(-36.61838296155886,-0.21489587133022292,57.79552692230445,-1.0 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark14(-3.663006844722098,-1.3582167536810954,0.36017242628318513,1.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark14(-36.74463411689035,-1.5707963267948948,-38.79325256969222,65.05208730531137 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark14(-36.74638010047004,-0.0922125562522804,0.07136245222994284,1.0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark14(-36.76578973551762,-0.21493943822086925,20.22683641433415,1.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark14(-36.775801906791024,-1.7763568394002505E-15,-10.176391204717014,0 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark14(-36.78371784941628,-1.5707963267948948,95.4256156711347,-0.6958163793297487 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark14(-3.6801739716311563,-0.23155610430779267,-1.5707963267948957,0.6308669535298957 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark14(-36.82628925415697,-0.06367714509438827,-1.5707963267948948,81.922682873712 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark14(-36.835384089693534,-1.4397664676621893,-1.5707963267948966,47.029592716454545 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark14(-36.84018447081071,6.429207516763285,33.70929120522206,18.52233416655458 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark14(-36.84607361093882,-1.264149403996687,-53.5490668826583,-1.0 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark14(-36.950218026599224,-0.0013271123876832797,-1.300983963871662,67.9930170796234 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark14(-37.01258665192408,-1.5707963267948963,-73.86767484548943,1.0432532715543792 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark14(-37.04928679255568,-1.5661597123717055,-65.97037437284283,0.0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark14(-37.17457358952349,-1.5707963267948957,-0.3058450530735186,-32.9287951974472 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark14(-3.719497891738044,-0.5392548411373581,91.80294813659825,0 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark14(-37.28688701936371,-1.0234939604198372,0.28896371100888546,0.058410180412240616 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark14(-37.301365592388215,-0.2688189339468311,31.298891570867205,100.0 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark14(-37.32961634533257,-0.6802455561742011,-13.353631627862548,39.68306419153983 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark14(-37.33406636372973,-0.045528807828756734,-77.90372430099438,-23.495618009554704 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark14(-3.743847582950181,-0.7287558362936206,32.592079461128726,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark14(-37.52669523626656,-0.7510059645489016,-1.2017784348389091,1.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark14(-37.53628913559462,0.6893208280004834,45.36231074753466,-1.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark14(-3.758427526907738,-1.7763568394002505E-15,-88.28873052518783,17.616212245329194 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark14(-37.64391882490319,-1.5707963267948941,1.5707963267948966,-78.55760869674141 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark14(-37.6550238293015,-1.4217564451131324,1.5707963267948966,0.038666988568092975 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark14(-37.6678962447787,-0.19092085856130706,-58.13319411216919,-0.04917635346084117 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark14(-37.754056251807484,-0.5083092632206497,0.314911536543087,0.92075475452941 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark14(-37.75926967152711,-1.1143840300017676,-96.38237143237646,-2.2573615732545083 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark14(-37.81158775108155,-4.2842970193658264E-15,15.427473740642768,82.17950953660511 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark14(-37.844116300726725,-1.492097687243757,1.5707963267948966,0.6129805475138141 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark14(-37.84997993711511,-0.8836222622798999,-52.11664742441849,-1.0 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark14(-3.7856636580105683,-1.5295649194744732,-40.95996709319668,-1.0 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark14(-3.7874789478492414,-8.881784197001252E-16,1.5707963267948948,-82.44852337776243 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark14(-3.7879499416732902,-0.4282545260725844,-0.5813731173061788,0.06518740459002442 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark14(-37.91074922941027,-1.5555472932654821,-100.0,1.0 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark14(-37.9221466110001,-8.969203612449654E-7,1.5707963267948966,-0.010408307243119882 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark14(-38.068458260260726,-1.2188939733726283,44.3831514509208,46.97337688016276 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark14(-38.12302556384841,-1.4339966376359163,-3.649226843496258E-4,-63.26915815008506 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark14(-38.13883394755222,-1.3216726060302422,-55.17746411466962,0.0 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark14(-38.20258478855876,-1.1102230246251565E-16,20.913489012746616,-1.0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark14(-38.208526560566156,-1.0708236338569426,-4.242880082656013,1.000002961766132 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark14(-38.25415513314895,-0.04694826662619114,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark14(-38.272668800534746,-0.5013760822124302,0.0,1.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark14(-38.28222466491431,-0.4866860465006566,-62.74838071946724,65.63640071132957 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark14(-38.31078509050495,-0.38995025735208183,-38.820968261702646,-44.277730722352054 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark14(-38.390847653319156,-0.9288071557701212,-0.47533123645619657,-32.87653040422555 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark14(-38.40293836015106,-0.6696607578130704,-0.11764500366409748,45.51409679299924 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark14(-38.48839015612205,-0.2206325918627125,-61.28659994514827,-0.659404209152844 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark14(-3.849298578623234,-0.6793611874627786,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark14(-38.51966956236683,-0.7184556703709388,0.0,-13.956960847450578 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark14(-38.539982719381484,-0.16585510634086964,64.89541162899701,0.011612804352772007 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark14(-38.62041869305048,-0.5440184731476756,-50.378821694784165,33.160496243668945 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark14(-38.6334862285571,-0.07144288500372772,52.794554132207374,-1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark14(-38.63840065802521,-8.407062545552935E-4,0.0,0.9935029478314245 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark14(-38.649188400652314,-0.8358965295070715,-0.19799796834379485,-17.415639113688027 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark14(-38.665015681270816,-0.11315528841822853,-75.99697845626653,0.717974947027706 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark14(-38.761073309951534,-1.0813949580310473,-44.26167362126858,-0.864811802584373 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark14(-38.87617479359812,-1.0398463249483068,-192.20313848524444,3.3478730253625777 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark14(-38.87639714450493,-1.2250856115662745,57.519777270694995,-0.0408579275130204 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark14(-38.914611112386126,-3.2385269003577325E-16,4.808782854007986,0.7820768772487011 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark14(-3.892654955300472,-1.1236598405115559,1.5707963267948966,-1.0000004381842575 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark14(-3.8994804101473113,-1.5540772859161587,-95.305888727893,1.0399665654339572 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark14(-39.021169954759095,-0.041125520375326116,50.30850890968981,1.0 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark14(-39.070090927290074,-1.5707963267948948,-30.466474874370284,0.00883803113674761 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark14(-39.08141507006337,-0.17597300793229068,-8.397308988600072,0.9318954786747793 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark14(-39.10282971241112,-0.4363244245526008,-4.620187222735851,-2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark14(-39.213139012808554,-1.5707963267948912,-40.83579367746892,1.0 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark14(-39.25754494173028,-0.4060942284219589,0.0,-0.7218171135690605 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark14(-3.930004928581001,-0.5653134062961986,0.0,-1.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark14(-39.32058849981013,-0.1367453702465845,68.99249115125309,0 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark14(-39.38137801449779,-0.6322015406730515,-12.241168016394028,-27.81727638268947 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark14(-39.388104661987846,-1.3938779215830925,-1.734723475976807E-18,1.000000001274304 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark14(-39.41636174227134,-1.5707963267948948,-41.731515864565274,77.0275602922616 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark14(-3.9536876140855153,-0.054886925760049124,12.032407681187225,0.9981417823957097 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark14(-39.53929435404199,-1.5335851631685955,1.5707963267948966,80.41118481784233 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark14(-39.64783063105037,-1.5277071468671806,58.05927199505561,-0.20129311159367014 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark14(-39.6655303922639,-1.1858632760506065,-1.5707963267948966,0.058056442328716984 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark14(-39.68778686273984,-0.06352682403724627,83.70667254131888,0.9523595503269633 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark14(-39.712687166901645,-0.597136603980662,-62.69289277394935,1.0 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark14(-39.723652108134175,-0.3706364425652824,1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark14(-39.763632046582124,-0.42159201918613753,-66.20938714005747,1.0114854615815374 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark14(-39.80507804057192,-0.025266229517553966,27.82339564191053,-8.613153053492617 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark14(-39.9012796702193,-0.17102677766973273,-33.3251961141859,90.26012484593221 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark14(-39.904834406600465,-0.6126137684137795,-74.49104469552603,-0.02536445767071971 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark14(-3.9917865460944495,-0.3814013309665274,-1.5707963267948983,-44.765589572396 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark14(-40.05123010797708,-0.011094447112475744,33.830878750631285,-125.60758328667148 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark14(-40.26385233684586,-0.005481893335796006,-1.5707963267948948,1.0 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark14(-40.30897463470993,-1.5707963267946887,0.9715979020167946,3.115913508510971 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark14(-4.037427017465745,-1.5707830463647379,-11.325499916106047,-5.111059060586336E-5 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark14(-40.453555901561366,-0.3658325146646991,33.3771688816219,-67.58373255020197 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark14(-40.47972065341677,-0.00695850621237544,0.0,0 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark14(-40.50182568903011,-1.0903779784898804,-53.66196106404649,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark14(-40.507381643289186,-0.04221062133732821,81.0105933417004,1.0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark14(-40.50740704648442,-1.4768134740694032,-46.164756194016874,0.9847620962135384 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark14(-40.52218680086501,-0.2952277779423099,89.68709958844232,-100.0 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark14(-40.587189890483586,-0.4241579194318238,65.68086516249367,-0.4345246657184021 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark14(-40.63654175529435,-1.5414922228343046,-1.4839785170138344,1.0 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark14(-40.651449005088445,-0.3841853582403887,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark14(-40.7800133378415,-0.31046306739210405,-45.36333363665528,-1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark14(-40.786814288251776,-0.5375647560323937,-10.001612673110984,0.32415947867893635 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark14(-40.820093211379046,-0.3086901173622749,-44.07350840262705,0 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark14(-40.90015543059388,-1.570423982263181,-73.6515949494826,0.6601738832708256 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark14(-40.932619601447925,6.696724122750866,2.225320701258486,8.673617379884035E-19 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark14(-40.96900508936573,-3.552713678800501E-15,-1.5707963267948948,95.96200351640348 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark14(-41.12343815192118,-1.462040086576656,-109.59934556839828,1.0000000385740302 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark14(-41.161152274461685,-0.36449375422096897,-0.42346605971077333,-0.11153998919876074 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark14(-41.215666569852544,-1.4230785671044106,1.5707963267948966,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark14(-41.29477179975213,-0.029291467896148185,-93.31809635240121,1.0 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark14(-41.38071916589065,-1.5707963267948961,-51.948186815843044,-0.25224610804331765 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark14(-41.39092070188448,-1.5511726260923855,-0.9923839833550275,1.6766612308856235E-17 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark14(-41.47367367705914,-0.15326255977902817,-4.644737185822493,37.267040841598224 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark14(-41.487718450609314,-0.27039992859847556,-53.84591330932658,0.023082083365714084 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark14(-4.149871436999352,-0.03443677198192087,-32.21845731874433,-1.0 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark14(-41.50369260338236,-0.03621918059325513,100.0,0.9999999999999964 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark14(-4.151295881945641,-0.10948161476787632,0.0,1.0 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark14(-4.178867749840222,-0.25970743479633285,-26.322608854026257,1992.4213578157464 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark14(-41.80859109292603,-0.22710261890011013,2.220446049250313E-16,0.05397012100557741 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark14(-41.81102926661103,-0.05327970344439659,1.5707963267948966,-56.82671023031551 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark14(-4.184870873833058,-0.47395957108242515,1.5335580560029705,-0.9618528587279601 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark14(-41.90336526425074,-1.5707963267947278,-61.88270744544822,-0.2937705787682795 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark14(-41.96690873542788,-0.056542315505136984,-62.45141007676579,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark14(-41.96969047695932,-0.7573619311527064,-65.23885510423955,-2086.1162874220886 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark14(-42.00271565838428,-0.07808622878844107,14.793237220516367,59.20860187302222 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark14(-42.00901903508488,-3.469446951953614E-18,1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark14(-42.04127256193752,-0.1304554443360846,-34.473600947640136,1.0 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark14(-42.12095197162523,-1.291883497873428,1.098180874829934,-0.7564024697323423 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark14(-4.21337855847942,-1.426015820884004,-31.073901416740192,-0.9899792753454799 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark14(-42.135172495894665,-0.0011441456169891697,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark14(-42.155751701629335,-0.027376006336830086,15.52689273183533,-1.0 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark14(-42.18372351058458,-0.19485917690743323,0.0,0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark14(-42.22182792849058,-1.4971684315086327,0.07836890887432091,0.7331709239836082 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark14(-42.254353173110246,-0.006450830873408213,70.1242597540753,1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark14(-42.26731059826409,-1.1904310425567988,0.0,-0.1720493059365209 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark14(-42.2794338497782,-1.2390475246996557,0.0,-0.9918390608873602 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark14(-42.304924416616764,-1.3944819418714003,-75.5577545957652,-100.0 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark14(-42.413283688751015,-1.462883201115644,-72.45384076411612,0 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark14(-42.44691791866083,-0.09672777104619543,100.0,0.0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark14(-42.46383751368283,-1.0659808006833222,88.23171484793261,-1.0 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark14(-42.4707113628227,-0.035771023155319805,1.4141936755958522,0.7369953744572637 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark14(-42.51387448409396,-0.3850637007915818,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark14(-42.53755933598779,-0.2505675186243883,-84.57915127514434,0.7827239589908803 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark14(-4.258716705661281,-0.7284592909585689,1.151428441221368,-1.011974131459886 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark14(-42.668031661296695,-0.03187457227909854,-123.84862890036824,-1.065228951886564 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark14(-42.68456734514464,-1.217848954500326,-1.5707963267948966,51.82997045920007 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark14(-42.707798193582704,-0.9932304267290086,-95.34076052260863,-1.0000000000000004 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark14(-42.71101609378923,-0.1245803725495022,-64.35632703539919,-57.558456753723526 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark14(-42.71603631208425,-1.3469137699969627,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark14(-42.75486038289735,-1.5707963267948948,-24.75264451883912,-2231.0854118843063 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark14(-4.276330934153965,-1.514780163736107,44.38026123238484,-1.0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark14(-42.80999122670183,-0.3683135398189116,74.27478831906828,12.667247606438941 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark14(-42.83276594476005,-1.4774302466633775,0.0,-0.3360893921807442 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark14(-4.287834075402316,-0.48477575374281623,23.9648183852929,0 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark14(-42.921945127112956,-0.1071109665664502,-19.88056927625443,1.0 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark14(-42.94412548238875,-0.43895301969984857,-44.55004065370407,-5.3912584879475317E-17 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark14(-42.98848794550112,-1.5707963267948912,-19.38396412324255,94.92786868326034 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark14(-43.00010961516212,-0.9470990256152982,-93.3692491147875,-1.0 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark14(-43.022660949335716,-0.7595495849532479,-19.75052620302439,34.01999115735731 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark14(-43.03359567667552,-0.06495654990949007,38.572830544249214,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark14(-4.30709956951503,-0.09772699211789182,-11.228108461420522,57.89079372220103 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark14(-43.261941789729214,-0.8530141238332378,-10.835761494396806,0.8477340335233663 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark14(-43.29343314330798,-0.007450696561312849,-46.34401730806553,1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark14(-43.30027242917009,-0.45442052850737463,0.8422740522192518,79.56454441787683 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark14(-43.30377143987223,-1.570796137071635,-14.096702396500989,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark14(-43.349859571557985,-1.5707963267948961,0.0,-1.0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark14(-43.369772832655244,-0.53874151248658,1.5707963267948966,-8.542901449084667 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark14(-43.373385193240125,-1.0060934536263246,0.0,-0.011209310581334009 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark14(-4.343298423926273,-2.220446049250313E-16,-27.230559219976755,-1.0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark14(-43.55314574214715,-0.04963859036264706,-65.66379359300957,-61.773572251545914 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark14(-43.61719263690241,-1.5581834657698863,-81.01858980643465,1.2196916463628004E-16 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark14(-43.67419738953828,-0.044033329947229305,-26.022631616586963,-1.0000000000000009 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark14(-43.6951687749088,-2.525476728452722E-4,-1.5707963267948966,44.35050721366511 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark14(-4.372044912237427,-3.1882632951894807E-4,53.12768024747213,5.8774717541114375E-39 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark14(-43.830704352155124,-1.5707963267948948,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark14(-43.904270504849386,-0.7240857548958338,-0.9543534342297436,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark14(-43.91276459593152,-0.01670108942012058,21.084707853035866,-1537.3790302774341 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark14(-43.92620697226225,14.433370252432198,55.79460329364359,-46.261050565551976 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark14(-44.00655200940503,-0.6913987170866069,-90.28010251581073,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark14(-44.03934628434394,-0.8403012261384233,-37.69079556706879,0.0 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark14(-44.049366318466895,-1.518334994778463,-88.28177344289898,-1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark14(-44.098524494007016,-1.221601206647734,-0.4681202948144243,-1.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark14(-44.15051277581226,-1.5463888670842096,0.0,1.0 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark14(-44.216174691621895,-0.7135119581624103,-1.5707963267948966,-36.41286139366787 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark14(-44.22293919491378,-1.3306138757209045,-1.5707963267948966,57.15598995067805 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark14(-4.4227885932520925,-0.034129716743937284,0.0,-0.2662093417921944 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark14(-44.30592343363982,-0.9434168030896642,-34.80126155266825,-0.04619894156495695 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark14(-44.3436324898524,-1.5707963267948963,1.5707963267948966,-0.48311065269710074 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark14(-44.40559599448839,-1.5707963267947305,0,0 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark14(-44.44445277932476,-1.1131810057110851,-36.922054798293175,-43.20125960912187 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark14(-44.53358531190764,-0.9925141405945465,95.5800375064022,-1.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark14(-44.595558152368696,-0.00375140076569499,52.866488686194515,0.6264340814843952 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark14(-44.61904081005927,-0.08920959978450513,0.0,0 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark14(-44.68684309000878,-1.4367587939510003,-0.3895708878511408,-6.949453802158062 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark14(-44.7091626898382,-1.3294424409253958,-0.66465504145893,0.9999999999999999 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark14(-44.816040124749605,-0.4734305346172576,-117.81551701724301,-1.000000000000007 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark14(-44.99708685202866,-1.1340819958545252,0.0,-0.48870469106098824 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark14(-45.00526113512186,-0.15990129448668444,-54.91702223796124,0.8355371048072883 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark14(-45.015918637570216,-0.45587739482657463,-1.397760166416873,-0.911187807810678 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark14(-45.02384027011624,-0.7012964986059902,19.357046062827106,1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark14(-45.05002740219095,-0.1886147670180094,-70.98725514389619,0.27118365119283183 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark14(-45.12820741073956,-0.11566791910358254,-55.99852467017961,0.6418989152601076 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark14(-45.145220228716454,-0.021086985593011143,-31.712549746148493,0.0 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark14(-45.20630387461747,-1.5707963267948948,-36.825420269888994,-24.83636900129705 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark14(-45.269474016865765,-0.4078704456738023,-1.9811046794945495,0.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark14(-45.291517590183325,-0.6067921853212415,-70.77716103155771,-1.0 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark14(-45.331665094670086,-0.17279522270051262,84.0676417182142,1297.1657599228447 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark14(-45.393555288767686,-1.1097001560687247,-5.856026417773226,-8.248132883526587 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark14(-45.45843599132468,-1.5707963267948948,-77.72714331218393,-63.12086161309668 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark14(-45.471724725941655,-0.7896260926102627,-56.89037426424698,67.58954348638282 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark14(-45.58273015373335,-1.4110176775293257,-1.5707963267948966,0.18066820501966196 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark14(-45.58982392579726,-1.5707963267948963,1.5707963267948966,1.056357431332989 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark14(-45.60384024026172,-0.07782925749308793,31.83745340287029,70.22717923797711 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark14(-45.616814375842225,-0.6575225247929035,-0.7405854454494829,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark14(-45.621718885460645,-1.1586858441238537,0.0,0.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark14(-45.634167632797805,-0.7362778111607102,1.5707963267948966,-0.5833694457476097 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark14(-45.67292613782446,-0.03599710673641032,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark14(-45.68912889761396,-0.3382108756376928,-1.5707963267948966,705.4671653019127 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark14(-45.71301624481945,-0.7067058408897636,-91.27567381406732,0.10782508565134641 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark14(-45.751143652087414,-0.6854017811727822,-0.6056991237175768,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark14(-45.82037671420627,-3.552713678800501E-15,1.5707963267948966,1.0000000000000133 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark14(-45.82980919087002,-0.8238406775355114,-57.28546070218417,-1.0 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark14(-45.84737073334926,-1.5707963267948912,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark14(-45.95901227860444,-1.2592707261428753,-54.06830496560358,-1.0663136801386197 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark14(-45.967231399767925,-1.4704524761143714,31.46620877937246,-0.022738465309099405 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark14(-45.9790535559158,-1.178189244088968,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark14(-46.002153426161165,-1.3784336587031834,0.3683998061035971,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark14(-46.0553208803307,-0.14363861704430525,72.10211006294902,0 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark14(-46.07030682777332,-1.4299277557754273,-29.880665947538116,-1.0 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark14(-46.101942215618436,-1.5707963267948957,-2.40415327194205,75.72213237000324 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark14(-46.14312051253394,-1.373348911792045,-96.3100647569342,-1.0 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark14(-4.61840433656157,-1.5707963267948948,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark14(-46.22271713775684,-0.569953889990453,1.5707963267948968,0.0 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark14(-46.234873356164904,-1.2281107484149758,-51.43714240566108,0 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark14(-46.245712706499226,-1.5707963267948961,0.39880032942179483,-0.08033405961185247 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark14(-4.624925507650254,-0.048687354998531385,-14.22356238869331,-100.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark14(-46.25228864002438,-1.1649277846956891,1.3270297905321513,-1.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark14(-46.31731590144326,-0.13071999835376577,100.0,0.2569747801656508 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark14(-4.633565728035679,-0.22854038398932017,2384.7607298972007,0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark14(-46.37590323489582,-1.538574028060109,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark14(-46.39009020958044,-0.9092715530052661,-86.90882198304168,0.03099584395024437 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark14(-46.408187877241076,-1.4832135177217918,0.06640760549296418,-0.9999999999999996 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark14(-46.42781523133662,-1.5669601752315725,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark14(-46.51078589428019,-1.1543141591754413,1.5707963267948963,75.07489377948372 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark14(-46.52358178235293,-0.2255296762383301,-27.404334222410434,100.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark14(-46.53239261321371,-0.023729227968363756,-47.74127511444428,-45.170021649991554 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark14(-46.57955377461394,-0.22565339813666555,-1.4856152190373566,-30.713186085929784 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark14(-46.596113928768155,-2.996976694875796E-15,82.21509724424376,-0.029647257633879764 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark14(-46.63055236224922,-1.1178667861762548,-62.06811836477159,-0.5358577533378353 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark14(-46.69403587481747,-1.5461517767466375,-58.319493351742594,0.8050786730870836 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark14(-46.74790181205826,-0.19127117107551106,-32.36284196289755,1.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark14(-4.676204521137205,-0.4015324777753708,-24.120900015598288,-16.120250297403146 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark14(-46.94821870624283,-0.7374712289529586,-33.13131020167131,-1.0000007556551638 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark14(-46.981021073375736,-0.04551849503302538,-109.48631012861433,-0.6555678722159586 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark14(-47.03375051811422,-0.40621930863698097,1.5707963267948966,0.03407014768385285 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark14(-47.1831551216723,-0.6978847084617854,-62.22079347906808,-50.72206366794143 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark14(-47.184543031666884,-0.0046529703790970005,-67.39334861407767,-0.14255730566102987 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark14(-47.21585761899496,-0.9307846874601842,0.0,18.660825067517067 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark14(-47.23110202141465,-1.2649673278710765,-36.847114571933744,0 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark14(-47.23730163260033,-0.04255801554068839,-52.69581114478905,0.6635173232109433 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark14(-4.733493709809624,-1.3512463560501455,-88.31514702537547,0.06053359699623027 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark14(-47.420464525382904,-1.4624339378977225,1.5707963267948966,35.44795333056508 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark14(-47.430379501172126,-1.5062210718253912,1.5707963267948963,-0.06255639067590434 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark14(-47.43524745396648,-1.5629889945540085,-45.30643255741454,-1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark14(-47.43619087462395,-4.1045368012983762E-289,0,0 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark14(-47.44134073297722,-1.1308312718853755,-1.5707963267948966,0.9999999999999971 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark14(-47.44472158772359,-0.019554669079750956,-9.486496292050525,-0.10760853239091239 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark14(-47.47229492893406,-1.5542556239900154,-15.111551310916477,0.01323566050031355 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark14(-47.48576559699248,-1.0258036503174077,-92.7460434584536,0.04256908081199583 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark14(-47.52912084362753,-0.48253768884568127,-1.5707963267948966,1803.9547239359533 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark14(-47.62498990305969,-0.9354080627706693,-19.62128705005641,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark14(-47.64455800302369,-1.1812285247245735,1.1137471907692373,0.01591515774232563 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark14(-47.6896009941301,-1.5707963267948912,-34.09718262022278,-1.0 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark14(-47.80055030324743,-0.3981894353493562,-18.131433003075216,-88.10721357026247 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark14(-4.7819846933757635,-0.9338479460459536,1.5707963267948966,-28.59935517956336 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark14(-47.91398761044049,-0.06499054629429295,13.61153185125378,-0.22669567559157416 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark14(-47.983302551999444,-0.4473228748396796,-43.1365450672144,-100.0 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark14(-48.0137415851339,-1.7763568394002505E-15,-60.726615424003995,28.239128546073857 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark14(-48.02692053758232,-0.17882990416461403,0.7222120296727227,-0.9222877527957857 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark14(-48.14130745503701,-0.06291609632553284,-23.70688670609091,0.9538112862134372 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark14(-4.8191865933132405,-0.26857608859092086,74.93226889938737,0.020437630315960742 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark14(-48.21936930094374,-0.03701354599397856,-45.29367364493861,-0.8946247731016419 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark14(-48.27266849699473,-1.2786241412585737,-67.62012534970665,1.0000000000000002 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark14(-48.36346169562571,-0.717610210641303,-56.3397570020605,1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark14(-48.394929095712214,-0.4609418437620745,-1.5707963267948957,-53.1854304748048 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark14(-48.400760387566976,-0.44053338301165823,-11.673590544282447,-0.890465339479906 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark14(-4.847694554229577,-1.5623386568992763,-1.5707963267948961,0 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark14(-4.855180458887759,-0.48049073720696006,88.50665073418,0.9999999999999929 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark14(-48.56284295513403,-1.7763568394002505E-15,53.53595480657707,0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark14(-48.5678729049259,-0.24730065485491015,-1.5707963267948966,-0.019449730002243593 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark14(-48.58612078736506,-0.4377958828847106,-62.95978100148492,-0.033008286615492696 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark14(-4.871903358210604,-0.7745522824476592,-17.693084415845675,45.021793129621514 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark14(-48.74919693665527,-0.054371041356772176,-71.50983151141553,-0.7749495542655545 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark14(-48.75459302351458,-0.5798507529836883,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark14(-48.81212237058479,-0.18216154114250505,1.5707963267948966,-0.02410701700033688 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark14(-48.863743296136995,-0.2613681838712704,-1.5707963267948966,-0.038465597334530977 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark14(-48.996103544698954,-0.5441957715413623,-31.659012096794278,-0.05922251550447484 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark14(-4.9008841829119865,-1.569727713779253,-99.28388287062259,-0.9790833470279428 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark14(-49.03162147367381,-0.03387496563455006,1.0679105145187038,1.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark14(-49.03784768564478,-1.5707963267948948,1.5707963267948948,-24.152008639130333 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark14(-49.077875428669586,-1.5707963267948963,-1.5663161635882374,0.0011036184260001108 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark14(-49.155254491585026,-0.9055847800312975,63.87602026409081,0.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark14(-49.17348163027422,-0.7160468292925231,-1.5707963267948966,-74.55236056461034 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark14(-49.17803400598266,-1.5356537480359114,-82.44925487618326,2190.731445191488 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark14(-49.19479410486633,-0.03267020005143195,-1.538106028084092,1.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark14(-49.19989354411876,-0.7529251303464863,-1.3514923031197696,1.0 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark14(-49.21933551337036,-1.5707963267948961,38.76059616425928,100.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark14(-49.25459515314492,-1.2816572329961704,0.0,2247.2235031892633 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark14(-49.308394844894664,-0.2558074231965478,-19.133070977055727,25.355280524962495 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark14(-49.3163652498106,-0.0377519939159315,26.968829992318007,0 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark14(-49.31706545557374,-1.2116363874814575,0.0,74.58048841004276 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark14(-49.40565507578939,-0.37390117723654015,-4.863286647921015,-0.9476135687565619 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark14(-49.41142123954469,-0.13415559431263832,100.0,0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark14(-49.48019260876318,-0.5884519053316382,1.5707963267948966,91.25574168685205 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark14(-49.542672120583674,-0.3249595368212866,-74.30915722732988,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark14(-49.54890153266949,-0.18287560880147044,-1.5707963267948966,1.0132795030988884 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark14(-49.556396041292984,-0.49244902286866765,0.0,0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark14(-49.57490896684511,-1.162676581637796,0.0,0.642081589954671 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark14(-4.9605036666786795,-0.47430593849360925,-8.259692738940357E-14,1.0000000000000013 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark14(-49.70541366117167,-0.0960025501238293,-25.125832264503245,0.9999999999999929 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark14(-49.7099689880988,-0.010649232278524087,-44.38683125263111,-62.91034642668471 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark14(-49.78044198034945,-0.059242075122436955,-32.54507618516625,-100.0 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark14(-49.7825001149983,-0.4242545935630121,88.2968049373447,5.2710989716152616E-82 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark14(-49.78288329336859,-1.5707963267948948,-1.5707963267948966,-0.7798326752995282 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark14(-4.984509818219579,-0.0053001030867169015,77.60428817625873,0.03683207367275887 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark14(-49.87091763009852,-0.7057814684642238,19.41621025926721,-27.89008759303129 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark14(-49.89530720191611,-0.4510209171988561,-1.5707963267948963,92.6898873934246 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark14(-49.93179528149507,-0.14130300896544765,-1.5707963267948966,47.45861144096086 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark14(-50.04684397838193,-0.22281539017825858,0.30650497421331124,1.0000000000000142 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark14(-50.05548226313878,-0.46703043650486153,0,0 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark14(-5.00778642640849,-1.0081929850782525,-15.083075238711558,96.55927199667676 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark14(-50.10046350466229,-0.1709105919533821,-1.5249590361083685,0 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark14(-50.10966250138477,-0.6192095713642284,-0.6571713797913301,25.79598337843889 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark14(-50.12935694670989,-1.071385356660905,-39.51283714428295,-1.0 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark14(-50.14586806524842,-0.405171425886921,-89.81757890366991,-0.7092590411596618 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark14(-50.16488849063197,-1.52890012498317,-5.099051409564019,-0.6737757363918415 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark14(-5.027784942241093,-1.5657822031681703,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark14(-50.2850720138115,-1.5707963267948912,-45.21386685212071,-1.0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark14(-5.030110230837792,-0.4127405306298192,88.11423589267432,-100.0 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark14(-5.033129051585902,-0.5077119122976222,0.0,0.05422592393038534 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark14(-50.369419577520745,-0.034176887108175014,34.19009025335002,1806.6267521701561 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark14(-50.45702097760326,-0.5015804397489684,-45.17913699594903,-18.87763958611947 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark14(-5.045770438252864,-1.1102230246251565E-16,65.20863715346589,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark14(-50.4739186953315,-0.483250257124893,56.91847516319244,1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark14(-50.504680139868974,-0.7781183614571264,0.0,-11.826009009803812 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark14(-50.50472592364889,-1.3681762259130958,1.5707963267948968,1.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark14(-50.50751542026562,-0.8424036100379095,-19.35474845713716,-0.06256344134663075 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark14(-5.051429467105237,-1.5230585410907087,64.03884934687355,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark14(-50.52780723467504,-0.5999814508012997,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark14(-50.551800315679046,-0.8249517485242926,-67.21636915723673,-0.05189114683232653 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark14(-50.56444944696989,-0.5398888761117743,45.93755884714321,-86.85716113541166 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark14(-50.56996207811861,-0.8013685708752671,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark14(-50.60534943685124,-0.9130425881233042,-1.5707963267948966,-48.881586584683554 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark14(-50.66125495725618,-0.7422953457514296,-33.03295146814329,0.010314565743873683 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark14(-50.704478610104225,-2.220446049250313E-16,-1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark14(-5.074999835791802,-0.04899718636742007,-90.77864600875989,1.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark14(-50.84598172028214,-0.4573824148731858,-41.844374737054345,-1.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark14(-5.087016598446565,-1.3668315319722089,-27.919297180468575,-1.0 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark14(-50.88227255988994,-1.5707963267948912,-4.471789705128392,21.14720031817741 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark14(-50.97512423033944,-1.7763568394002505E-15,-76.46997973752713,-1.2994080970767957E-14 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark14(-51.04902090543577,-1.348821008202961,38.90724586772758,45.23227748374907 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark14(-51.06650013232063,-0.6241588910345388,-96.02898523554195,-0.6875950788364591 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark14(-5.122937574868132,-0.22302594831861078,1.2329882018886593,-94.15144316669696 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark14(-51.24225671992916,-0.6910058814883331,0.0,-29.024260257611715 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark14(-51.25965810983365,-1.156999411401146,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark14(-51.41604301093147,-1.0506640688478104,1.5707963267948966,-34.97702808074922 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark14(-51.41805151013777,-1.5707963267948957,0.0,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark14(-51.461251130827456,-0.1288975482840399,0.654025843301133,1.0 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark14(51.478993626148096,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark14(-51.488464897825324,-0.4840267865442863,56.59180198342602,55.04450238240625 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark14(-5.158214174729077,-1.5707963267948915,-1.5701152588665916,1.0 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark14(-5.167432308741486,6.43837949140524,-0.8369029284474719,100.0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark14(-51.688319774399666,-0.8929792657272702,-67.83070439931892,8.086713942503096 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark14(-51.71952326592906,-1.1102230246251565E-16,90.04207226171984,0.7735861418133699 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark14(-51.730010556328864,-0.4514815647063416,-0.8899112662674546,79.54743837325275 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark14(-51.741138327438584,-0.8018301934420983,69.31020920090702,-0.623916389215662 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark14(-51.7443834453125,-0.5904415857406483,-44.80112224431036,36.81594754777794 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark14(-51.7716258527274,-0.009246785887441433,-8.219514628027639,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark14(-51.78218466986633,-0.03349459526747284,0.0,-1.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark14(-5.183062402535034,-1.4996537042807683,-19.405249968779202,-1.0 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark14(-51.91585796688693,-0.847923664945526,-1.5707963267948966,2083.9451228076573 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark14(-51.94398834656897,-1.3375308918395792,14.429402955850193,0 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark14(-5.1957701578148106,-0.06559128491775557,-84.32743634499361,-1.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark14(-51.972332936314466,-0.2663707462336472,-17.87444919896143,0 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark14(-51.99316145126194,3.9889006955183106,-15.590325598473314,0 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark14(-5.199824000583848,-0.9096424955755649,-39.022972089754376,0.9533962268641433 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark14(-52.02013742120833,-1.0220147869896727,-7.3215479110850765,-8.331676435568951 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark14(-52.039697161696935,-1.3236891947844474,1.5707963267948966,-0.21836654052708582 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark14(-52.10171295675527,-1.5707963267948963,0.0,0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark14(-52.13300219577779,-0.3552938172488488,52.17535923396962,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark14(-52.16824180945453,-1.1264797592965485,31.956638551707258,-1.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark14(-52.182729736099354,-0.49143363826385456,-0.009043302470351629,0 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark14(-52.28003345267826,-1.5707963267948961,-1.5707963267948966,-71.16619057840705 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark14(-52.3284798267739,-1.5707963267948961,-34.00220714721482,-0.06255272439821069 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark14(-52.33192322111536,-0.16567617129108747,1.5707963267948966,-0.25987461785885535 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark14(-52.339863843310134,-0.31305079798571006,-89.1286261190232,1.0 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark14(-52.377745379291234,-0.7373721806176302,-14.513311145288593,53.30938482993012 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark14(-52.45727471169702,-0.9089461014401792,-9.912408643529638,17.158166943437607 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark14(-52.580835777969014,-0.47862534329676976,-23.958275640751403,0.17573955382130443 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark14(-52.58762191113952,-0.3298924530293989,0.0,0.554062570023226 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark14(-52.594797337317274,-1.5696456589749854,0.0,-1.7220724074339476E-5 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark14(-52.60268202945415,-0.513707794643175,-9.846405858511645,-0.5610017174690004 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark14(-52.61334075956821,-1.5306086230777407,-2.220446049250313E-16,-0.7268942644955927 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark14(-52.61379447566093,14.439913185935957,-0.948800439686849,0.6407891396869896 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark14(-52.61960103413856,-0.46938451044532237,32.455612067026536,-46.704160999395334 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark14(-52.637507913962175,-1.1104248087113666,-100.0,-0.11891667000744865 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark14(-52.66699762336351,-0.8539091511127805,-58.25754502075654,-21.858235567305456 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark14(-52.70152296371889,-1.5707963267948912,-0.3681858589467497,-60.47493413481952 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark14(-52.71118852587959,-1.1555170246461817,-56.29698065704666,0.8946203311996279 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark14(-5.277849889349073,0.7453157315714216,0.084459125820427,62.78707151986469 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark14(-52.947883289392976,-1.5707963267948957,-64.59304398592896,-0.5524564847723674 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark14(-53.065798591468365,-0.10178752241669248,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark14(-53.115142546434065,-1.3918940458832878,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark14(-53.13875580603345,-1.432888872189046,-1.5707963267948966,-13.136060730539125 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark14(-53.22325657168979,-1.5707963267947171,95.4296424123017,-29.502308778609304 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark14(-5.330648393879855,-0.6497820590959413,13.326358086537786,0 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark14(-5.333459576680856,-0.0936266974167389,-1.5243553711263653,-2.1494539088584326E-15 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark14(-53.36194721916621,-1.3991154096363503,-20.38416023538771,-0.10676787003241883 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark14(-53.52216075745688,-1.5707963267948912,1.134088453706596,-0.014835961691621602 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark14(-53.57820830268965,-1.3477550374660663,-2442.8862785179354,0 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark14(-53.59775455759683,-0.037118156842693775,96.61122327563035,71.23714260376514 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark14(-53.653098751141215,-1.4640399257400816,-66.29319217637908,-11.395228274904513 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark14(-53.67556739345336,-0.9504745186462871,0.0,0.0 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark14(-5.374084372882066,-0.30044629929219646,83.7871891756353,0.0 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark14(-53.75196324709153,-0.9300084480274448,-46.2040350856063,1.0270279434039544 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark14(-53.82950053660417,-0.2711746853453827,-18.795622587177725,0.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark14(-53.86371613009168,-0.47724574620293936,-0.2631802751291694,-0.40442210735036 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark14(-53.97264289034872,-0.1394052560975576,-0.24833239455578782,1.0 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark14(-53.99508740193851,-0.901066929912399,-8.349857598234358,0.010978657022563107 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark14(-54.01017117769052,-1.0713495431474647,-88.23112604370556,62.279850447223424 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark14(-54.08134476713768,-1.5707963267948957,12.669991971679949,-1.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark14(-54.08694730025077,-0.07525661412720495,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark14(-54.15834593507008,-0.47472554276958845,-19.411991716216363,0.4716444840622156 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark14(-54.17948720712176,-8.751372027143574,97.36039415232813,0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark14(-54.265818147923035,-0.3593250302930461,12.663450426254983,-1.000037071719005 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark14(-54.268192695136065,-1.5707963267948952,-0.154860383729428,-1.0 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark14(-54.31208215858216,-1.5547567844589913,1.5053086093160046,2.8451311993408992E-160 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark14(-54.329159881869565,-0.9365040928444269,-28.215355311631654,1.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark14(-54.41402358316642,-0.1099983511977833,-85.84240825716793,0.09965871782063007 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark14(-54.41486497549012,-1.393512258664645,-1.5707963267948966,1.2013432151851338 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark14(-54.41930565367828,6.434836511250862,52.34831849993125,-0.0076782131295526634 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark14(-54.45185413155726,-0.5363932900495315,52.602262325351546,-0.7809901365214245 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark14(-54.456400137454324,-0.03189566137915011,0.0,-1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark14(-54.490784924849194,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark14(-54.516296002719514,-0.1722273811869967,-84.45683720337796,1.0285307132852268 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark14(-54.5753132063027,-0.302118342187198,88.33150496732725,-1.0000003874361565 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark14(-54.60105256986825,-0.5798319711334594,0.931990402930886,41.02743179564109 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark14(-54.79020672356557,-2.069945191634081E-16,-0.24522922594363833,-1.0000000000000002 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark14(-54.81681583213361,-0.022442949087860906,96.13744812113947,0.999430568952909 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark14(-5.486306646514703,-0.012723498368002892,1.0529819443092692,0.0 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark14(-5.486538240586675,-1.5707963267948912,-21.584040421727195,-0.01329909829855741 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark14(-55.02162945469547,-0.8968945635929657,-1.277375689695921,-1.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark14(-55.02895700339769,-2.220446049250313E-16,-1.5707963267948966,0.0019451378656530128 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark14(-55.059929872812766,-0.9388508270350103,0.0,-0.010015039163299268 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark14(-55.155173087464036,-0.3669235202927465,0.7965304475776893,100.0 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark14(-55.16137927335659,-0.07637333193012452,-51.9524522916676,0.0 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark14(-55.1666567404934,-1.5229713600487584,-64.9921524625855,1.0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark14(-55.19557004558516,7.6560303999612325,75.04004635467318,0.0289078286105183 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark14(-55.20823917110062,-1.3881797431454692,-1.5707963267948983,4.0607069397050388E-115 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark14(-55.25745111158816,-0.006524178008915261,-23.667842505181923,66.96534798528697 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark14(-5.527650845635744,-0.6205714001024589,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark14(-55.303760340061366,-0.8722745183740074,31.819598702848584,0.0 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark14(-55.32428709724618,-0.4449406263903817,2.220446049250313E-16,-73.1819351198569 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark14(-55.340523642629265,-0.45799179135032797,-69.62452603721658,0.9436200195612514 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark14(-55.348020102689354,-0.34737517286817887,-0.3095694809139903,88.77457762154967 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark14(-55.372547489775705,-0.025011463460715644,1.5707963267948966,0.1378426520974667 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark14(-55.46648762149145,-1.2587368063399282,32.84901112356443,1.0 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark14(-55.50696258885018,-1.287611311765527,-31.571157673229575,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark14(-55.53985562222336,-1.5707963267948912,1.5707963267948957,1.0 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark14(-5.561545542895281,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark14(-5.562788167244969,2.4617716566031613,39.46181792169686,1.0 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark14(-55.68445033296313,-0.4352403322906373,-1.5707963267948983,-29.274769747153105 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark14(-5.576368960008867,0.3355397478961145,50.186874939112094,99.90401535038299 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark14(-55.76411498780554,-1.3011275469660524,0.9577429693264627,-59.80591841476433 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark14(-55.78850448842293,-1.4977520680310183,38.84546280737763,-0.8007869100223282 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark14(-55.830835566094336,-0.38523047015027756,-13.187520231303523,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark14(-55.90562180537436,-0.6100909668644975,0.0,-1.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark14(-55.941180248013616,-1.344719842416406,-1.5707963267948966,-2346.1818143460437 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark14(-55.947061741869646,-0.186512143626996,-20.76812849878848,-6.584939620889085E-16 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark14(-55.97871491599537,-0.17039673506346745,-48.8609945881592,0.918442401346762 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark14(-56.031303321857834,-1.5142328656496373,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark14(-56.073067892618454,-1.3373228938520942,1.7763568394002505E-15,3.0045953910087653E-15 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark14(-56.08358492777931,-0.5334255046145353,-43.88338050675963,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark14(-56.10611083670251,-1.0602609361108595,-2.6907990310659216,-2.477869258436826 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark14(-56.11860688936159,-0.14965992341250178,1.3925085072136392,0 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark14(-56.19873837410156,-1.4762402047561107,-63.34216491966213,1.0 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark14(-56.21251908832174,-1.5423931104096955,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark14(-56.2135350901422,-0.08886827033740752,-70.16427853872995,-1.0000000020221456 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark14(-56.218587234850425,-0.8766144049347588,0.0,1.0 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark14(-56.25058584049805,-1.5707963267948912,-5.3057554340477395,-64.0921905394638 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark14(-56.255474268337395,-0.9998514401508274,-228.36580351894116,0.06260926764990049 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark14(-56.26391644249931,-0.7292962120002286,-33.944910579744345,-1.0 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark14(-56.29081374693567,14.429371254402646,95.25717397462124,-19.85317587953511 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark14(-56.41522442003062,-1.5323340446060167,-71.38180182105282,-1.0 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark14(-5.644930186331093,-0.4270589391474683,-0.052747365993273,36.64394448415346 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark14(-56.4804934417986,-0.8786227102784447,37.86245520841996,0.9944674999966284 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark14(-56.4898277447991,-1.1339956764747758,-13.883206372005176,-1.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark14(-56.49413451950548,-1.5453969770707006,-1.5707963267948966,55.52590880841811 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark14(-56.49732323358619,-0.0838584777684681,-76.81919617059383,-0.025173849252715805 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark14(-5.650040640466415,-0.13095551203151257,1.6223249759869773,-1.6242827758820155E-114 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark14(-5.668000050933845,-0.46175143069543423,-37.2260817863844,0.006742321691695752 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark14(-56.764335838292716,-1.5518514253370028,-84.64796343116052,-1.0 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark14(-56.80352005474858,-1.5707963267948877,-88.39782330717064,0.6102222316900703 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark14(-56.81044118417133,-1.5477553805216868,-23.57527684553782,1.0 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark14(-56.82545107199785,-0.3544654973800935,7.882132232631627,0 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark14(-56.87767177749676,-0.29624294049506905,-100.59234727129169,1.0 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark14(-56.899683001908365,-0.5936951106100317,-64.18984692314855,60.54401900227092 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark14(-56.900495695497895,-0.6612534530108825,0.0,-0.974241829839128 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark14(-56.963950063098935,-0.10377802876698135,-48.455026731583104,-1.0 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark14(-56.996602677177236,-0.17391678454369242,-69.10175035893059,0.9999999999999982 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark14(-57.23528941308032,-0.2006621462364523,5.784832104431857,0.0 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark14(-57.30906328010735,-1.5707963267948948,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark14(-57.31925629240902,-0.6158336811658582,-61.28977946965297,1.0 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark14(-57.33070019742979,-1.316214905016652,-42.59572378776506,0.0572568916029122 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark14(-57.37962832045862,-0.07173444454869281,23.74938735714619,0.3739407067233578 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark14(-57.382790244758326,-0.0617683298079893,65.01950673439016,1301.3031343526325 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark14(-5.739756284794374,-1.1001267657528295,-13.353434665678478,-1.0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark14(-57.47359864687857,-1.01586959229989,-72.52301945803676,-17.815729780038737 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark14(-57.56336311508382,-0.014525172345167009,68.87262678628262,0.001029976408984238 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark14(-57.678704691719005,-0.755542851775038,0.0,35.29336723193741 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark14(-57.68894788831674,-1.568163238467822,-7.847861387383287,-0.8762311541350548 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark14(-57.729049646560924,-0.5928653925588669,-72.21374368919692,0.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark14(-57.78874943610719,-0.6984497238393402,-48.68391660837943,-1.0 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark14(-57.806793546167604,1.838419820738603,84.74585111308161,1.0 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark14(-57.81319120714103,-0.19405865934919453,51.35865335363877,-0.047037805221204765 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark14(-57.83891427954966,-1.1211715275841196,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark14(-57.87510902969394,-1.3586547559507376,-56.87215395081308,75.41330779952084 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark14(-5.788999183115702,-1.5140290461333044,88.16848933790129,73.3963338660698 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark14(-57.987942118420975,-1.1561523941179355,-11.081922047526579,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark14(-58.03620529872687,-0.26250651365328936,-0.43770122993086885,0.11271757981500319 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark14(-58.07312076201406,-0.02277499189359886,0.0,1.6490156610373958 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark14(-58.19055649820383,-0.7254700499615154,-100.0,1.023240855531783 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark14(-58.20416730504793,-1.5680412447584808,-36.55019777632702,2209.177500937392 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark14(-5.822878017406888,-0.11881832327510666,-32.66241456105338,1.000000000252715 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark14(-58.23982955979265,-8.881784197001252E-16,-60.393289782342016,0 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark14(-58.3218418015267,-1.5707963267948948,-8.17742267683866,-0.008246912735055683 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark14(-58.334991537997595,-1.5707963267948957,-1.5707963267948966,0.9660189962838028 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark14(-58.362671303841324,-0.7480437903780346,-30.66823145849746,0.03969316704031532 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark14(-58.37613630696238,-3.552713678800501E-15,-73.38035064081626,33.44154638254682 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark14(-58.3767739801043,-0.03583555956646475,37.89363613745251,1.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark14(-58.382706538439,-0.011668993605439937,152.26106201107916,-0.739848167287212 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark14(-58.42927260410089,-1.138977282989337,-53.35339762802202,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark14(-58.483088761150995,-0.9339812413675157,-1.5707963267949125,-1.0 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark14(-58.521214201808235,-0.6173024087649713,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark14(-58.54536513256975,-1.4845902918751648,1.5707963267948948,0.01068609968812917 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark14(-58.554173259461024,-1.5707963267948948,-98.76282075717637,0.4145823828482378 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark14(-5.860282287017622,-1.5707963267948963,1.901197379625762E-17,0.6934869378895882 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark14(-5.860547864682339,-0.30715298760382154,39.0123680177428,0.9009512284447324 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark14(-58.612500723253326,-0.4500136043786509,-1.5707963267948966,-1770.4136514684376 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark14(-5.86493328267258,-1.3153530409258403,0.10382614631294876,0.03161389948851964 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark14(-5.867802317407898,-1.2026664647205065,-75.52681487432228,-99.91551885433313 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark14(-58.680022826918645,-1.5707963267948952,76.76369726648674,0 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark14(-58.7198316813669,-1.5707963267948912,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark14(-5.877805377592903,-1.104355384476316,-0.28007539211999716,-52.83186631347262 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark14(-58.78277379053281,-0.16769150154577026,0.0,2.1647882438484477E-4 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark14(-5.882511013844302,-1.5707963267948912,32.77835459864366,0.0 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark14(-58.834046999709805,-1.3372302397346774,-20.485769979790163,0.05576968385403447 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark14(-58.87936533963383,-0.036577124957121274,149.69335402978695,17.96876022842087 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark14(-58.90319435107363,-0.8133921911196165,-48.76843571196467,1.0 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark14(-58.90500741389184,-0.039242935983839544,-1.5707963267948966,0.4238596226503324 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark14(-58.9844723724555,-1.435302294375396,-18.466566898754564,-0.8382516345692999 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark14(-58.99406591960017,7.0695937810819816,11.326833311230962,27.822236809464258 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark14(-59.0360998139478,-1.5707963267948912,-45.33017538558501,0.06259818692691074 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark14(-59.04423714479952,-1.033758360634432,-30.425067901453538,-0.05481125250198833 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark14(-59.06577824152106,-0.8238947432441438,-0.08501202368764434,0.9162273433126927 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark14(-59.088021391647544,-0.09949843007056086,-1.502343699824448,-1.0 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark14(-59.18595822119703,-0.21295575557440108,-70.94197525283487,0.9306181658092869 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark14(-59.211291973553486,-1.5707963267948912,-45.181542998578756,1.0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark14(-59.230838042924546,-0.2750878462347953,21.188880638620233,-78.13604195921641 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark14(-59.27664655233041,-1.0082581213507482,1.5707963267948963,92.62457150206505 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark14(-59.28330850697661,-1.3117998341743347,-12.43827849264136,0 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark14(-59.284919163040854,-0.1114201222112981,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark14(-59.30510882545692,-1.5707963267948948,1.5707963267894698,2307.1838196688864 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark14(-5.934701570339612,-1.5707963267948961,-44.38694371499264,0.2122667959696951 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark14(-59.42841228354481,-1.5707963267944365,-63.09798442424632,42.72995024942253 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark14(-59.469150422081626,-0.7943641827673529,-4.972343380840378,0.1272005562904398 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark14(-5.947648037396387,-0.033335065620605064,-39.401207437709175,-0.04168780426133681 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark14(-59.495923880002955,-0.007176266930600875,90.38548130471229,-1.0 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark14(-59.50989291874733,-1.5707963267948912,-78.93131067598523,-85.14314070613611 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark14(-59.645118575666075,-0.0246602161733478,-88.35643188372562,-1.0 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark14(-59.732295096313706,-0.11009869541830478,-1.5707963267948983,-0.8989336189945112 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark14(-5.976678383947263,-0.3089642782628147,59.08735387200196,0.04037589775012029 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark14(-59.76747113172699,-1.4943869762262998,0.530043363191713,-1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark14(-59.79019257730421,7.045788204483412,83.03804399123166,82.5892866380769 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark14(-59.813199211807984,-0.10964247161584365,0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark14(-59.82377085420606,-0.259166867714273,26.275043091682697,-1.0000000000000036 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark14(-59.83615630631837,-0.0405771142254272,-100.68442315727978,-0.4040822503724435 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark14(-59.861208702314954,-1.2754234608311457,-37.67985234663043,0.9999999999999996 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark14(-59.914130059797024,-0.7233240498160036,-53.764853898029315,-58.17072567110158 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark14(-5.994846323780095,-0.10109535464457053,-0.23470412093406695,1.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark14(-59.96779773380411,-0.48138595082420654,77.61188261279113,33.23208215270063 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark14(-60.091869800251054,-1.5707963267948912,-96.382779291151,1.0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark14(-60.19748629988233,-2.220446049250313E-16,-67.15462097195153,-0.10988195866578832 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark14(-60.258098403615044,-1.1181377960607197,-22.34170588393945,-0.924059902401809 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark14(-60.26975617332122,-0.2054367669211122,9.367100775229392,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark14(-6.03189691400088,-0.3192787176255931,-2.5355640972937032,-7.624192405803546 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark14(-60.33378449101241,-0.42085360714003367,-2360.7217315660096,0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark14(-6.03593392867527,-7.105427357601002E-15,-43.30449935115875,61.30397443599438 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark14(-60.38287491848946,-1.570796326794893,-50.00209569419869,1.0 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark14(-60.38971669087249,-1.568752218454303,-65.02013492690045,1.671806464682195E-6 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark14(-60.39621390342545,-1.5707963267948912,-19.384933474766683,42.39138470262466 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark14(-60.509592277736125,-1.5570293628379102,-72.21266963099565,77.77576823808624 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark14(-60.5647656811302,14.429243670691363,27.581845072094154,14.48647794769591 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark14(-6.057001519437874,-0.9892400852217208,1.5278172011436941,-1.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark14(-60.67870417526969,-0.6935680988695216,44.54491622008891,-0.5075265873451099 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark14(-60.69138864680749,-1.4241046216367421,-6.795562961677206,-1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark14(-60.724494486145005,2.758251152133942,1.278306051264952,0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark14(-60.77782904832091,-1.5447391324056028,0.7158163816532268,-0.10899935252962134 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark14(-60.78169521986874,-0.8330781463166508,-0.086810332155557,-1.0 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark14(-60.7937205908113,-1.544575933716826,1.4373277844160275,-0.055530167671613284 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark14(-60.996869207053805,-0.2528866218303249,-1.5707963267948966,7.105427357601002E-15 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark14(-6.102998608647425,-0.059258902225002075,-54.19843288641819,0.7708405273458032 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark14(-61.07277253463171,-1.5707963267948912,-77.33849805573874,57.77780241427095 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark14(-61.08222596949441,-1.5707963267948912,56.84829123328358,-1.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark14(-61.11833810308978,-0.4321528832727739,50.39008783089935,-1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark14(-61.13417902289372,-0.40718875075641303,-54.8065485606728,9.888515694225848E-10 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark14(-6.120760396998607,-0.029123169528631365,-47.89227682961804,-0.9484071357603798 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark14(-6.125370560845793,-0.15521454717157812,-31.730546102863187,0.3621902079535381 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark14(-61.3940151548589,-0.028369437896309812,13.461835827155431,1.0 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark14(-61.52794773362335,14.431368263472443,59.685723472240774,-0.16114307741634093 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark14(-61.65949327313306,-1.570796326794893,1.5707963267948966,3.7092061506874214E-68 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark14(-61.719493904508596,-1.1744381440540521,-4.3164543494966985,-36.72113976016102 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark14(-61.74109668714155,-1.5697686199651315,-136.217133562985,-0.7062166633414435 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark14(-61.746928072050856,-0.2808864017291869,37.699205683211076,1.0 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark14(-6.188382530610847,-1.1547261168422525,0.298416188004111,-0.6368719846328297 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark14(-6.191968873139703,-0.2802973118980937,76.91390227356236,1.0 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark14(-61.961673510463775,-1.2807490159518267,2435.944345397661,0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark14(-61.9845478651412,-0.6759140381181591,-1.5707963267948966,0.36395393292231365 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark14(-62.01371660278431,-0.29090315871325567,42.634860812432294,0 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark14(-62.027574958865216,-1.5707963267948912,45.34308607407032,37.05365023770162 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark14(-62.05199451043865,-0.8036919177924565,0.0,-62.3421539874512 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark14(-62.05378788343647,-0.48614093633045635,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark14(-62.054987518699384,-1.109929881597642,-1.5707963267948912,-2.5988524414112248E-113 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark14(-62.06166367287496,-1.1244589545775454,1.131576074072214,-36.65941454379655 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark14(-62.06911809985632,-1.358189974623558,88.13175602028477,-0.029538669054626293 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark14(-62.117310621012976,-1.5707963267948948,-38.74612994491514,-100.0 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark14(-62.12201440250834,-1.5707963267948963,-68.23135585617965,-1823.5624201034047 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark14(-6.212633266433926,-0.7181704316579004,-59.86321196411913,-0.04182706880420284 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark14(-62.12701148967038,-0.3423746136001292,-31.977680506558546,0.34019176008159424 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark14(-62.14690674050229,-1.5707963267948948,-25.612826964377454,-0.5183520884505128 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark14(-62.21418809804234,-1.2245938738354503,-12.798746002829612,65.49078982285671 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark14(-62.2301252797331,-0.1213042078523614,1.5707963267948983,-0.13976959414757595 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark14(-62.25959802729366,-0.0014897857835129038,-33.67047397872897,-1.0240299557836365 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark14(-62.31122909283878,-4.930380657631324E-32,-1.5707963267948966,0.9542846191232187 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark14(-62.32141437026194,-0.49636089892606605,-71.37781170724362,-1.0 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark14(-62.336541862845806,-1.5707963267948963,-81.57413801337367,-41.573989309091296 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark14(-62.49234509375978,-0.5289478183152128,-85.5447448969482,7.73485478311214 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark14(-62.55244864922667,-1.5590002638509737,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark14(-62.67519615351937,-1.5479041230189774,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark14(-62.733450072200384,-0.548243491161396,1.406615246411472,-88.93645748105337 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark14(-62.741726365168915,-0.47671250999331694,1.374830447659261,1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark14(-62.7854959796989,-0.37229093391662343,-1.5707963267951008,-0.975383265927771 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark14(-62.793439508702,-0.8536325336134964,7.5659017835868525,0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark14(-62.80334161703565,-1.1102230246251565E-16,61.989709788129346,1.0 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark14(-62.82837427931849,-0.12725837492309278,-12.271264019835186,0.9999999999999991 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark14(-62.82879899822886,-1.5707963267948963,2.445342339262377E-16,-0.7198430849468265 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark14(-6.283777849126878,-1.2891338585878698,44.468951776654336,2147.2333976499754 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark14(-62.94542293686537,-1.5378424195498839,-1.5707963267948961,17.76368260888888 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark14(-62.957869168545884,-0.7948169536218838,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark14(-62.99550035014215,-0.7990470068529109,0.0,1.0000000084911567 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark14(-6.308576662192257,-1.7763568394002505E-15,-122.59940114772706,96.16378139655369 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark14(-63.09762546548421,-0.8952585946733128,-53.96412560384173,1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark14(-63.10853896353936,-1.5707963267948957,-1.5707963267948966,40.145801382696646 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark14(-63.12961319965496,-0.08603239323979274,-18.978823289630135,1.0 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark14(-63.187908806244636,-1.4579309939351428,-0.6057194077576287,0.057007268687363034 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark14(-6.323510787873919,-1.4773170568586749,-88.05451789894701,-1.0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark14(-63.28004221298033,-0.10495192044216217,-44.10064417617182,-0.26971649467648934 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark14(-63.31373498281021,0.6043960111208614,100.0,0 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark14(-63.318776647054754,-0.21884668617271485,19.47274085573412,1.0 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark14(-63.32412874558253,-0.6639892253672828,-100.0,-1.0532936096846106 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark14(-63.356961135132316,-0.0114615894880559,0.0,-1.0 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark14(-63.41697303299674,-1.570796326794678,-1.5707963267948966,-57.733844578551604 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark14(-63.46645096764585,98.94727211722477,-86.03700139031108,0 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark14(-6.350075958422293,-0.989586692452063,-96.01810488419174,-1.0 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark14(-63.51550314967522,-1.3545413832526836,83.07089800344193,-0.9358724903219994 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark14(-63.53598196339705,-1.2699004170785624,1.5707963267948983,-0.9735053919970724 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark14(-63.60011180637149,-0.6602832936748609,-4.777661700445143,-1.0 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark14(-63.609207970820066,-7.105427357601002E-15,-54.601228474848845,-0.8275960666456657 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark14(-63.64962726609876,-1.4557502620508855,-100.0,38.78523371702414 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark14(-63.673321381224405,-1.0266703389616882,-62.9111782697908,-0.9644325150854403 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark14(-63.734775200968386,-1.2233957298346956,-38.97201351760916,1.0 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark14(-63.751006210787565,-1.2585393893775338,-1.5275324628577152,0.9999999999999998 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark14(-63.76776661909925,-0.06679541150622725,-63.76648497108647,1.0000000210227775 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark14(-63.78294714957474,-1.1874549733885116,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark14(-63.80131523430608,-1.3036181891162306,3.864326621787155E-16,-1.0 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark14(-6.387406801050198,-1.0653426257554237,1.5707963267948966,-0.9999999999999964 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark14(-63.87478959956562,-1.5707963267948963,1.5707963267948963,2.6079920068986127 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark14(-63.8936868660972,-0.3439214980122507,-25.78987312453376,0.01600401402268744 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark14(-63.9059781332693,-0.5585381918477847,-9.219281156010098,-57.99902857410844 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark14(-63.96732246975464,-0.47519772280746425,-79.9348210771496,-1.0 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark14(-64.02460449619504,-0.1108705999691093,-29.06246804935003,55.82323699204511 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark14(-64.06197100601037,-0.7171814574991713,-31.123741511678155,1.701687883345228 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark14(-64.07538562874912,-1.1538949338565723,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark14(-64.19375386145981,-1.5707963267948912,-1.5707963267948966,0.8832690310907935 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark14(-64.21417372758643,-1.3541681306983522,-31.16077311140026,1.0 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark14(-64.2524265735712,-0.46348055771341695,94.83858221307297,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark14(-64.30578926856285,-0.9101224802237318,-100.0,0.09475168944773316 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark14(-64.31112825774254,-0.48623062327638206,-92.24065811181012,-0.36209657777043636 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark14(-64.3238787199129,-0.3763884495270955,-0.4317985333085572,-21.362759130359617 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark14(-64.35403842094355,-0.5759881020089014,-24.045046383309497,1.0 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark14(-6.440851069261889,-0.1427477749366981,-1.5707963267948966,0.16312769813883643 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark14(-64.4706101079262,-1.3895854330062403,-73.44538297640017,0.06255264900469816 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark14(-64.52431618094158,-0.5860684585803831,-29.447954132213024,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark14(-64.60885166172571,-0.978435340384326,0.0,-33.62046989315915 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark14(-64.70651173210909,-0.7315547922929605,-81.15665668367167,-1.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark14(-64.7308257868687,-1.4552193372988946,-157.46565178106218,-0.028553781102971687 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark14(-64.78477839235977,-0.6126283827794485,1.5707963267948966,0.8910909891901171 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark14(-64.86884662022335,-0.3239856461498768,61.268491893024475,0 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark14(-64.88779649465779,-0.8478460488666687,-24.86282531505934,0.6629607168424787 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark14(-64.90163124019,-3.552713678800501E-15,-166.05069119172686,79.25070449804937 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark14(-64.91760312813896,-1.1322307109273162,-76.53285752202524,-1.0 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark14(-6.492752001739916,-1.3184319696197715,-52.559284161656024,81.89748367792066 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark14(-64.95322818729677,-1.5707963267948961,-1.6331095568331762,0.5607987504710319 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark14(-64.9920692872083,-0.550037935097933,-85.92277977144067,0.9999999999999996 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark14(-65.01928233256491,-1.5707963267948912,-59.58631749343801,1.0 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark14(-65.1096545262189,14.430054912993448,15.482623008969227,-0.9546311951008246 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark14(-65.13806583615212,-0.7896609218917783,-37.29770700329935,-1.000214685903078 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark14(-65.28382886466447,-1.5707963267948948,1.5707963267948966,1.232595164407831E-32 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark14(-65.29378763778693,-0.997962473204722,88.1742607807638,-61.318523120964755 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark14(-6.5404009619149095,-0.32547000659813785,-1.556535479309468,92.81902228647566 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark14(-6.546452286303522,-0.3594097749495272,12.218601662272476,1.0002584636096852 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark14(-65.6099286188979,-0.33804501778411034,0.0,-1.0000000000000004 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark14(-65.63861029410316,-0.5677545217415119,-56.25887679441534,0.22663510587379754 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark14(-65.6601603701393,-3.552713678800501E-15,-0.6745026718699212,-2168.838847092563 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark14(-65.67976111604715,-1.5698615198796662,-57.44409222763892,-0.6449952774783618 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark14(-65.6830542361306,-0.44175273528544196,1.5707963267948977,0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark14(-65.74953931082617,-0.02194694864738711,-61.90287256844831,-0.7015749953052752 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark14(-65.77354078409195,-1.2176972277881504,-92.8357691196303,-24.0528997104012 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark14(-65.79975254827531,-1.4693004512018082,1.5707963267948966,0.35333169573337386 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark14(-65.81679672552154,-0.1698875894887708,39.182455521577424,-1.0 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark14(-65.82213115029514,-0.36435664555688163,1.5707963267948948,78.29193082425815 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark14(-65.8901410639294,-0.7322885599631103,-64.92064497620079,-100.0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark14(-65.91943756798848,-1.172358042402271,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark14(-66.05392831376281,-0.7913829584161176,1.1886132634318674,0.0046644513733834075 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark14(-66.06650200805548,-0.9190428955759522,-0.9208864858763072,1.0 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark14(-6.609602208921601,-0.5232931242201148,-83.35428486198259,0.8459770783481234 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark14(-66.09809441275357,-1.0113615514893546,-153.47064155461268,0.47822232018154853 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark14(-66.15487204348749,-0.40295974618033925,-1.5707963267949978,0.22441095541407385 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark14(-66.1727547242835,-1.3046480554478994,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark14(-66.26373805338461,-1.5707963267948948,67.20426933875848,0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark14(-66.27618628601333,-0.5428650972524559,23.881306816062217,0.5246437821235075 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark14(-66.28242272616642,-0.9689576714242961,-49.94324723891944,-22.780846359908914 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark14(-66.28943300770791,-1.5707963267948963,-14.072887242987633,-1.0353998010525751 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark14(-66.30367589518471,-1.2869279619319856,-0.16764346860539325,1.0 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark14(-66.33241949592536,-0.23179095399925442,-9.527228860544795,-0.620856831248541 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark14(-66.33546936313057,-1.5705965394097432,1.244419860962466,0.9999999999999987 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark14(-6.645021464702525,-1.5707963267948912,-95.52973486930149,-0.3974724138860637 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark14(-66.46829204930188,-0.007612998382163283,-10.943622644622259,0.03353024349694233 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark14(-66.47648486635968,-0.584283885064508,-12.784719723761782,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark14(-66.58459871441238,-1.5707963267945786,-36.195711068507165,0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark14(-66.65883379872945,-1.3442207725943347,1.5707963267948966,0.9999999999999999 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark14(-66.67196722513081,-3.552713678800501E-15,-1.3399344349547064,-0.6755347176631046 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark14(-66.68260368217184,-1.16303125919849,-63.85438575625044,1.0520048398145212 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark14(-66.68743395678706,-1.5707963267948912,-67.03302246816472,41.9913083083185 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark14(-66.7129494067335,-1.5707963267948948,-32.757031172081874,21.744961370933815 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark14(-6.679246164297907,-1.5707963267948948,-46.267629550443196,88.66511110742523 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark14(-66.79351724395671,-0.6983584710404507,1.5707963267948966,4.7946064666187285 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark14(-66.85901921323787,-3.552713678800501E-15,-9.064933417611414,-60.640780292152826 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark14(-66.89315617133168,-0.7980652113071018,1.500691847227198,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark14(-66.90547745637107,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark14(-66.94362885453971,-0.813684360819057,-74.8822262936528,-0.9999999999999982 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark14(-66.95651518900166,-0.10117512247612222,1.2629424876164892,1.0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark14(-66.99328751517875,-1.5707963267948948,-30.08074141624338,74.7496000915005 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark14(-67.04516678140652,-0.32959464147369344,-1.5707963267948983,0.815364594918897 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark14(-67.04746374792342,-0.7891619778423815,-40.85454794469547,0.9469207864168047 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark14(-67.05238919168676,-1.5594989312851073,1.5707963267948966,85.56949180675534 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark14(-67.07456707488404,-1.2626673231358307,-54.81733362614111,0.014506950485019876 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark14(-67.07787839088618,-1.0083052388189813,-0.9161437921679163,86.77151912337604 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark14(-67.20682843212947,-0.3475147486162944,1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark14(-67.46548172959534,15.35506581931945,17.895018507567464,0 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark14(-67.58181956661974,-0.3067458705511742,25.934882477982285,0 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark14(-67.58702189161814,-0.5376612439283247,9.285399881847823,-1.0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark14(-6.75895004953783,-1.5707963267948948,-66.91349264371564,-1.0 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark14(-67.6293176159265,-1.2436343448683194,0.0,0.6837617988766709 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark14(-67.7179729417812,-0.3416433766443845,1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark14(-67.75172167104205,-1.5704238271407844,-64.58049619111529,0.9410024073625995 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark14(-67.79892664470952,-0.9466841230409777,-71.05030890324342,-30.756625486611796 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark14(-67.85176948168844,-0.010340906587545625,-28.318568052411194,75.19333197450061 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark14(-67.87446261395728,-1.0270990965363893,0.0,-0.7251963270364747 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark14(-67.87663348341935,-1.5707963267948948,44.48582076442577,-1.0 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark14(-67.88057394233358,-0.8299888846716392,-11.389384701780816,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark14(-67.89024100843886,-1.5707963267948961,-100.0,0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark14(-67.90729894862807,-0.17211188949751222,-3.266032623839492,99.86198760102798 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark14(-67.93945120933328,-1.3165700203548596,1.0531026004971855,1.0 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark14(-67.94201279850844,-0.488225354187248,52.43066650208264,0.045645016399954885 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark14(-67.94923134431146,-0.14085775263013584,-82.69682647142162,0.2674801765792598 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark14(-67.99236621536315,-0.025325524070884033,-33.14250382213973,0.9946654284573374 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark14(-68.03589145250277,-1.3355134999547273,7.105427357601002E-15,13.190865547015946 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark14(-68.06531950794499,-0.769157595901903,44.44947515264776,0.0 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark14(-68.1075968162824,-1.569211378665496,-31.774339358368223,-1.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark14(-68.13953888712305,-0.0011034585124052201,-36.35933745848088,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark14(-68.14117080307719,-0.24191812230571985,-62.77119653863831,-1.0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark14(-68.1823456164386,-0.9022449163177475,-9.850890790743655,0.05586397311999125 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark14(-68.19603848654279,-1.5707963267948963,-1.1102230246251565E-16,-1.0000671576921745 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark14(-68.23218908739253,-0.6802467767761105,-0.6441474395417868,1.0 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark14(-68.23360862672558,-0.12920373853540934,53.22398811755601,-99.6115966840731 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark14(-68.24836122511492,-0.6538046110307408,0.0,-0.06288370137568977 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark14(-68.27502634112327,-1.5707963267948912,-121.2719697147191,36.187858584494165 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark14(-6.833114720074347,-0.1368934064602294,1.3604911722315893,0.9244367915413474 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark14(68.3890906742673,14.39471934301686,-22.697918194739074,0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark14(-68.49058917313965,-1.282892013551432,1.5707963267948966,-0.06255935519981182 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark14(-68.49886896995949,-0.31327808070540586,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark14(-68.50780193866183,-1.332198418079479,-95.67422049789982,1.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark14(-6.852071846420699,-1.5447685881359328,-53.873707501231415,-20.37545079513133 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark14(-68.53488897226842,-1.5466778682401436,-15.166090087944411,-0.2896272846743235 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark14(-6.853787708072647,-1.5452869891978291,1.5707963267948966,1.0000000718299638 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark14(-68.72469376199379,-0.2832344370612587,-0.12689136983613894,-1.0 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark14(-68.8080167917721,-0.1925302026881411,40.58341446951035,35.48169948284879 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark14(-68.81467971061664,-1.5614453235173635,-41.665398401959166,86.42334124137638 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark14(-68.83888673946606,-0.31144570512769193,-11.349828155437512,0.0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark14(-68.88208122676174,-1.5523501903270667,-103.95996883173572,0.26284510203645883 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark14(-68.90325566425768,-1.5707963267948912,-191.77469521107952,0.026303591483370692 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark14(-6.891301902433495,-0.09646838771468608,-10.819318697212609,-1.0546939277441454 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark14(-68.9187043355842,-4.440892098500626E-16,-1.5707963267948966,20.590321368742636 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark14(-6.896923780339031,-0.5375808881224031,88.38179560994558,3.469446951953614E-18 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark14(-69.03426191876133,3.2241914215766694,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark14(-69.06694175492358,-1.4340542609714249,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark14(-69.23750498554642,-1.3964071966619163,1.5707963267948966,-45.340577222028045 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark14(-69.24013691569097,-0.41431578241264166,50.81357548077295,-62.775106146966 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark14(-69.29340652857752,-0.810819726622356,-62.42094079608567,1.0000055150137748 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark14(-69.30855212429361,-1.566509315413561,-67.33853564945498,0.4174329474557222 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark14(-6.9327722472617666,-0.6213832876500107,-72.28441537804244,2252.9431794233515 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark14(-69.43911147603445,-0.32356751554816454,-64.99271020632393,1.0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark14(-69.44915475957748,-1.1457178339024954,-24.749096757614836,-0.022367946144946277 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark14(-69.59047843924355,-1.5707963267948948,-53.747718450573146,1.0 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark14(-69.60419190419177,-7.0447773547954876E-15,-1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark14(-69.64116607703735,-0.18029410805489965,-100.0,-0.04954317905768596 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark14(-69.64136048132865,-0.7142302263471545,-56.0435483586925,34.97467255701716 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark14(-69.65174581221606,-1.5707963267948961,-38.01400780485737,-0.27272387516167385 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark14(-69.65584539084495,-1.5706917451168263,-14.996797886785714,-0.6640205176615464 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark14(-69.67272365090132,-1.140451559839823,-122.59753032139973,-0.7236635316857996 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark14(-69.8395849416967,-0.15657566853779148,-64.03406640890918,-8.086682717633895 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark14(-69.89269301012307,-0.20218878989606226,-80.23040015028943,-9.689914304800357 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark14(-69.93899573840068,-1.3520820346639773,-16.723938373047776,1.0000147228013745 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark14(-69.94688388459133,-1.5707963267948806,0.0,0 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark14(-70.18228995444267,-2.220446049250313E-16,0.1856796340739999,45.672953058042204 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark14(-70.21693403499151,-0.5352018878883342,-54.44289848510703,0.0 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark14(-7.027639021495254,-1.5703943994604226,1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark14(-70.28121240919234,-1.5707963267948912,-19.35784386138711,-0.9366246477895382 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark14(-70.28393364226417,-1.2480576326304251,-41.660710557907976,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark14(-70.29403728027368,-0.9508575739089551,-83.97758981447485,-16.05651686604659 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark14(-7.032427636713127,-0.5708559037615418,-21.79469918646555,-7.01378991682689E-192 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark14(-70.34132384472959,-0.05254819446680677,21.166074290628153,-1.0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark14(70.37168343405472,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark14(-70.40388423798173,-8.881784197001252E-16,1.5707963267948966,60.13284635949708 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark14(-7.043068651879565,-1.376025486731949,1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark14(-70.57135248797564,-0.10752296441453046,87.7619568240008,1.0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark14(-70.6623267781838,-1.030784337925699,1.274641118052879,-1.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark14(-70.70049105230191,-1.250229489166067,-100.0,-39.31924917537411 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark14(-70.72789591114304,-1.1102230246251565E-16,94.27582055989234,-100.0 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark14(-70.75153702032189,-1.5707963267948912,-39.90163148750263,-0.8047500706741822 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark14(-70.75737280079001,-0.5118620751328293,-1.5707963267948983,0.05855546204781226 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark14(-70.77460449931823,-0.6630003888620108,-28.968816074638198,0.013615033461378018 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark14(-70.90141680111526,-0.24116360737439635,-0.8362176371050771,22.868425340123167 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark14(-7.090960793245923,-1.4891761316358512,-42.869849816031966,-1.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark14(-70.9727707525192,-0.6727955473850638,-59.62121475458666,-49.243601559820505 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark14(-70.9754057976664,-0.7305614437319664,-1.784494346141333,-1.0000108294453032 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark14(-70.99665518973951,-0.45658375535371726,31.51620847705511,0.7053884217313962 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark14(-71.18491994521794,-1.570796326794894,-100.0,-1.0 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark14(-71.21965791940963,-2.773051146865524E-4,44.23765398341894,0 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark14(-7.12344935659242,-1.1108434005722654E-16,-5.719181314322035,2.0790819531289798E-112 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark14(-7.1307107432837515,-0.142653357004503,-1.5707963267948966,0.20157352856955413 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark14(-71.346766821282,-1.2377084754424676,-16.8102195225765,-0.9957124615166907 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark14(-71.35342608293445,-0.48627892180836946,-93.80239080860424,-0.9999999999999991 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark14(-71.44879368474086,-1.5707963267948912,95.77603227646193,1.0 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark14(-71.54463791590248,-0.8274181515748067,-0.9213295828298558,0.1329820718512376 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark14(-71.55391696181537,-1.0957229258448717,69.18177017988165,-0.9560044659315289 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark14(-71.55765125970481,-1.2536553695354993,-29.80274941676776,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark14(-71.59833157239706,-0.7209418010029651,0.0,1.0139508422432888 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark14(-71.60025382788565,-0.5403449596132553,2.003962399013119,-1.0 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark14(-71.65391358960855,-0.4774620925761959,-57.29930361418925,-0.39904327599067013 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark14(-71.68392817318932,-0.3259233741806062,-94.05649342802995,0 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark14(-71.69790987195552,-1.1238264323394234,-90.65195414404685,7.889828184693126 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark14(-71.83786686177145,-1.5707963267948963,31.625501795076108,2.1382117680737565E-50 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark14(-7.1840441663248855,-0.5642720406030218,-0.339368619625656,52.495916795568135 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark14(-72.12026823193565,-0.6667352011754607,31.681562305209,59.86785812318689 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark14(-7.2127604578090825,-0.9503069732504651,-61.82561521006438,-1.0 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark14(-72.13556683708273,-4.440892098500628E-16,45.35843437530465,-4.1002661789349907E-143 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark14(-72.16812022870303,-1.0729539996724413,0.0,-3.1906057309417974 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark14(-72.18735650707936,-1.3265403463133065,1.5707963267948912,-29.484269348697723 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark14(-72.24086866011582,-0.8041809573208965,-10.796773548745858,79.48620888328915 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark14(-72.32155540573422,-0.5642746877734665,13.703943613006864,-100.0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark14(72.35486563813856,62.320442551478266,83.50449738298894,0 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark14(-7.24083624823043,-0.8466192518514912,0.0,7.614973948990745 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark14(-72.43479190302376,-0.973294370766724,1.5707963267948957,-58.81887117997813 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark14(-72.44376144719958,-1.5707963267948912,-54.54104563213471,62.013143747399404 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark14(-72.4593895601934,-1.2616403783774643,-49.81261277008223,51.68595281963201 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark14(-72.49040040870293,-1.1520073811442382,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark14(-72.50593653208327,-0.6021497539240755,-77.19505394791182,-1.0 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark14(-72.52229092652,-0.8532349354641633,-91.57736553072593,-0.08858737950691964 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark14(-72.5675235919155,-1.491062051493408,-1.5707963267948966,-0.9989625063712677 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark14(-72.64051571642437,-1.116192773505233,-21.197780394023397,-37.23337582679784 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark14(-7.274934364446608,-1.1985874453002054,0.0,1.0 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark14(-72.86400871334436,-0.29011187470636457,1.5707963267948966,-0.007765580690664575 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark14(-72.87665820533857,-0.36134903380044747,-36.76196834678931,-1.0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark14(-73.1421092385767,-0.9792327656985131,-43.075462370913066,26.53323229814775 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark14(-73.20208368834184,-1.0725261109494648,-100.0,0.06255272227026343 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark14(-73.24218854991649,-1.1102230246251565E-16,-16.9129902306298,0 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark14(-73.34410589743817,-1.5707963267948948,-71.19940863732698,8.012253143909097E-17 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark14(-73.37158925117193,-1.5707963267948963,0.0,-1.0000001267253669 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark14(-73.40503360784346,-1.1102230246251565E-16,-1.5707963267948912,0.3763640831805435 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark14(-73.41995631620907,0.9962096750546177,-16.014199654090287,0 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark14(-73.45508976131288,-0.5586288362855059,-75.80515963776404,-76.81371478629005 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark14(-73.5070567208773,-8.260687916052335E-5,-79.02226320534402,0.9688114302752235 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark14(-73.53688295076492,-1.5707963267948948,95.42624132111104,-0.8228639883747857 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark14(-7.360952553079841,-1.394329624161216,-10.790002308338618,14.299982899375465 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark14(-73.65395498658252,-0.5986380544829051,-94.32549967715154,-51.4788050897089 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark14(-73.670632239404,-1.5707963267948961,70.25664927750415,-1.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark14(-73.82675635491913,-0.432624668823423,0.0,65.9609449510292 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark14(-73.90223818993987,-0.3906921421542161,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark14(-74.00035561757562,-0.8375399651455557,-68.72209783735535,-8.274425073174797 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark14(-74.03965431068,-1.5707963267948963,-31.747025545361417,51.503503647038556 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark14(-74.04882216913145,-1.5707963267948912,-65.77884241447177,-0.21149366813804882 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark14(-74.11715739652799,14.46413837443447,100.0,0.44621327288682266 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark14(-7.416199185312505,-0.018816072773087757,-77.86136046979576,-1.0 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark14(-74.16483455155479,-1.20189753631022,25.779807181889097,-1.0 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark14(-74.17920281790738,-0.585593383479388,-88.39902081576226,-1.0 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark14(-74.26235573562754,-1.4805952180158164,-135.43151351046933,-60.30982567062186 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark14(-74.2963635936351,14.429798050356837,-1.1036009610862099,0.0 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark14(-74.30333422507618,-0.34607789373501074,95.59330618360431,0.0 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark14(-7.434957195535999,-0.12240115062788122,-0.8806572923668221,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark14(-74.39631636530227,-8.881784197001252E-16,-37.80963756023882,0.5933663968864231 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark14(-74.44290420830319,-1.1331088857845206,0.0,-1.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark14(-7.451088459264227,-0.6691034335103038,95.36513998117923,0.7371132164638325 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark14(-74.53794725085783,-4.440892098500626E-16,-49.3553154134744,-2281.7346700653748 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark14(-74.55152633259956,-1.141111799806099E-14,-1.5707963267948966,-74.1232103969485 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark14(-74.7021927545456,-0.02200208311500236,27.79897099934567,3.989111396724685 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark14(-74.71378893786388,-1.564839854957367,-93.41181627438375,-1.0 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark14(-74.73446972525038,-0.2428674342115108,57.725594618268104,82.15622171106764 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark14(-74.846206126264,-1.5707963267948912,44.28652743818631,-1.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark14(-74.85996016463385,-1.5707963267948912,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark14(-74.88218879559062,-0.2810679074716719,-0.7645350628237272,1.0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark14(-74.90531223337402,-0.040849664048977566,19.311401457402233,-14.949571437119737 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark14(-74.92522651526943,-0.8014497891412223,0.18293220482595784,0.9999999999999998 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark14(-74.9330483389552,-0.3156594733660011,-7.105427357601002E-15,2138.852412424755 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark14(-7.497462522419677,-1.3193803124610377,20.207077818716478,-0.057362486836518733 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark14(-74.98334984909346,-3.552713678800501E-15,-6.664485358491362,57.27025546471168 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark14(-74.9877453648516,-1.4387910519021816,-2.9396148614138706,0.986887175004124 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark14(-74.99211808046819,-0.8925182625095377,-44.31201209840606,-1.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark14(-75.1158195466197,-1.5707963267948948,-1.5707963267948966,-0.5132385188329573 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark14(-75.22547425325432,-1.5483044823971936,-1.5707963267948966,-0.40279974827613163 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark14(-75.24430468690512,-1.2522883374308351,-45.470344060893225,0.9999999999999999 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark14(-75.25540876024826,-0.07189980975834104,-1.570796326794897,0.05612296938819855 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark14(-7.527492356268151,-1.359111806457254,7.827574926101872,-0.06255742915169138 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark14(-75.2998069012297,-0.3552859804727746,1.2700643431615656E-15,-100.0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark14(-7.53048237750312,-5.025275831841634E-4,-45.42797197370473,-0.9981760214699434 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark14(-75.32149060691378,-0.7378511068255531,-92.45931201998602,-93.3331589959882 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark14(-75.37654534413667,-0.6746541543519964,-56.04060068060856,0.38818125990475605 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark14(-75.39875582727473,-1.5707963267948948,-1.5707963267948983,27.643750304758257 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark14(-75.41157040611961,-0.5305912775932856,32.868439715876605,0.0 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark14(-75.41319978714736,-0.8757120431198118,-84.55847738128553,0.04416025674927693 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark14(-75.47972211815767,-0.8086886519107815,-44.44056864989767,6.938893903907228E-18 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark14(-75.60066589689055,-0.15305285858055317,33.75299413873483,0.0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark14(-75.62382367106292,-1.1102230246251565E-16,-2365.486167422815,0 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark14(-75.65794676299448,-1.5707963158953286,-1.1245154682140018E-4,-0.9116077560840888 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark14(-7.571476093168899,-0.9018844572960092,0.0,6.776263578034403E-21 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark14(-7.575681948442369,-1.0710706323858228,-73.37705904680494,100.0 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark14(-75.76725536349524,-4.440892098500626E-16,1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark14(-75.78936799460556,-1.387493138138498,1.5707963267948966,-0.806622242093846 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark14(-7.5797861191013665,-4.440892098500626E-16,-20.000978478743903,0.3083267983782749 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark14(-75.84977816566114,-1.315596075645178,-0.6327103503354152,-0.04073440181362302 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark14(-75.97332421433629,-5.551115123125783E-17,-1.4903520379148238,-6.961592038217688 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark14(-76.05846886262306,-0.958477972920308,-1.5707963267948575,-1.0 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark14(-76.11335498426308,-1.1102230246251565E-16,50.445375571508066,-0.04311495422566547 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark14(-76.11889448195906,-1.3831973136770475,1.5707963267948966,-0.772369507728949 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark14(-76.18539856117002,-1.334027921984641,-34.820811022188764,24.367856491180675 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark14(-76.2768758697768,-0.5796045159012806,37.71920234405162,0.9904898389468778 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark14(-7.631153518688421,-0.34230837771639705,-78.02703712835269,1.0 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark14(-76.33514842174156,-0.3592589386394316,-86.23299065620299,55.74130702059577 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark14(-7.633863610880922,-1.491817411252597,1.5707963267948963,4.015292250421853 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark14(-76.407733284036,-0.8945230863123044,-0.45070626618170473,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark14(-76.41547429369929,-1.5707963267948817,-1.5707963267948966,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark14(-76.44283189795772,-1.447055124886444,-52.36760465793347,-0.019793391238349806 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark14(-76.47349310465529,-0.4683276596008211,33.118085283492064,2.0679515313825692E-25 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark14(-76.5920765822786,-0.5449943762240428,25.821042448986383,-35.33482106615104 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark14(-76.72452101075538,-3.790009786576176E-4,-9.625492805090445,21.575049143196793 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark14(-76.73822650281913,-1.0334806902904308,-93.5483876095765,-0.736529915545352 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark14(-7.686366884938082,-1.2893994234938102,-49.03705606630847,1.0 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark14(-76.94571914782871,-1.3069415404692677,88.11080831912075,-0.048838555529572364 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark14(-76.96265989005965,-1.5496026770781814,-67.16830284143975,-0.19380064483695025 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark14(-76.99366519775488,-0.15173129275045888,-55.836979067793074,-2.310163427493704 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark14(-76.99988016541792,-0.040737564172452466,-1.0685567194528056,65.26901978075001 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark14(-77.0433982809003,-0.06763199903308248,-23.494227106352298,70.45613705118453 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark14(-77.09964422054637,-0.84633823306189,-123.072009674095,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark14(-77.1997855854894,-0.6411628280070918,1.5707963267948966,-9.573044641854647 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark14(-77.29951486670787,-0.32683908494315184,59.220931194119885,42.493784353549415 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark14(-7.729966157060147,-0.4603450451100918,-73.40428121976296,0.5369169961322626 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark14(-77.3018786386566,-0.8936177819475797,-100.0,-84.1810946393443 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark14(-77.31488900996445,-0.25959547334629035,0.30181815595387534,-32.87345910814018 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark14(-7.7425486405529,-0.20481006908702054,0.0,-7.470601987621976 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark14(-77.47768836552346,-0.13978390998100565,-93.95630924248125,-1.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark14(-77.60839780111782,-0.9974461225821244,-7.405957893294547,1.0 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark14(-77.66303488780521,-0.7875715890528667,0.22265092190984603,-1.0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark14(-77.68558819366056,-0.09586649921901869,7.331380479183906,-2.529662092498029 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark14(-77.79410754377469,-1.5707963267948877,-38.3279248175241,-7.299620277552904 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark14(-77.85780069476324,-1.5351348673757348,-11.164221884356596,1.0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark14(-77.86290472535177,-1.4468523001889526,1.5707963267948948,-95.83690464790101 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark14(-78.02698802546281,-1.4953441315625127,-0.5452650364148646,-9.937641465356322 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark14(-78.04406857198705,-0.2128969208569388,1.5707963267948966,-1.0000004305765855 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark14(-78.08990401327051,-1.6243482364508566E-4,0.0,1.0601218098398406 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark14(-78.10820047931286,-0.44593431300104375,-61.4462539438976,-1.0 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark14(-78.2052189800469,-1.56487690747786,0.0,19.405512820251914 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark14(-78.2080529603065,-0.9503396986219043,1.5707963267948948,-1.0000000071924977 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark14(-78.21999183158815,-0.6178514408319558,-95.47091178677988,2181.2804785579397 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark14(-78.24055185122226,-1.4670091971130477,0.0,0.9739321710720394 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark14(-78.2449313731276,-1.5707963267948948,-46.171739360148514,-18.887359881377122 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark14(-78.25034755548495,-1.4253692719029576,-0.004747573269104484,-0.06255256134616283 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark14(-78.26445678052897,-1.5707963267948948,-75.70294339082433,-0.291216517016361 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark14(-78.29149060043068,-0.024843747590912013,-50.83547428123102,-27.322940353361435 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark14(-78.33978350548094,-1.164833719809795,0,0 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark14(-78.35909755693356,14.443531171534524,50.98530745586325,-40.73862637393236 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark14(-78.42439943084926,-0.25156764512115104,-7.064290360147325E-17,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark14(-78.43543002719895,-1.1102230246251565E-16,3.1351000936816824,-1.0 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark14(-78.60755113713333,-1.557803898044121,-1.5707963267948966,-69.11012980429419 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark14(-7.863278395581347,-1.3601964176494754,1.5707963267948983,2097.0403876801633 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark14(-78.69487229730643,-0.19702084974876594,-19.422780490838058,0.1927190510484934 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark14(-78.83506013526333,-0.5723278844470916,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark14(-78.83637924259577,-0.8852569953444629,-7.219443006066186,1.0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark14(-7.886902036022845,-0.18419786723884793,-73.69336304171777,-74.3654909382109 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark14(-78.9090182564106,-0.01888932276939149,-44.153637402268465,-1.0 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark14(-78.966594117305,-0.07696164904604459,88.7216813154101,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark14(-79.0183513516542,-0.7673560203672163,-1.5707963267948966,0.998908234307829 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark14(-79.06618265237014,-1.1102230246251565E-16,39.43415107818418,-1.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark14(-79.0883283625025,-1.420115070541764,0.0,0.9965854857498921 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark14(-79.1285018913666,-1.5707963267948957,-18.734891242443297,1.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark14(-79.1501325582989,-0.10610558669893244,-12.773890344659465,1.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark14(-79.1583880089777,-5.204170427930421E-18,1.5707963267948966,-1.0451218093130876 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark14(-79.19709591285944,-1.38585035524288,-81.89095620035928,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark14(-7.926571904936395,-0.8241496712381876,-14.354328920321997,-1.0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark14(-79.2850998272973,-1.5707963267948912,-38.73349715728381,-1.6225746201012186 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark14(-79.29860715891417,-0.8603247734855309,-74.61237670933588,43.8659324341175 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark14(-79.38176271043875,14.448007952925096,15.495572259204408,-68.10545678167213 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark14(-79.50538403862448,-1.5707963267948963,-1.5707963267948966,-0.0743867075301779 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark14(-79.53920592887242,6.430266120546684,-1.5707963267948966,74.90012451421319 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark14(-79.63194186375529,-1.5707963267948948,-45.30636810015246,47.52666537148621 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark14(-79.66078950991857,-1.5306285672947824,-135.32164458221035,-0.6792972849518 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark14(-79.70884406313775,-1.4522117728266113,0,0 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark14(-7.97254888671192,-1.2259162249727464,-63.03624384033669,37.58366048576926 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark14(-79.75505129140144,-1.280789197569426,-3.3466247946833936,0.8966450794892565 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark14(-79.81175109769227,-1.4345223058595695,-42.55786254679319,0.9999999999999903 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark14(-7.986896133861533,-0.041214300904607995,-94.87178448397698,0.952341738229375 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark14(-79.93906056894659,-1.0892465795314674,-78.4605759953396,53.423553081128006 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark14(-79.97603466279844,-0.2593520664163741,-0.7463932028694964,75.74709695777614 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark14(-80.01224222893448,-1.5707963267947989,-31.893417909390482,0.3718034087895461 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark14(-80.0717635222846,-1.7763568394002505E-15,57.36887153823945,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark14(-80.08015866927073,-0.6103675522117874,0.7853870964947066,57.80160728723269 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark14(-80.24200808289483,-1.1822260058280738,-44.0151314098673,0.2472323763482014 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark14(-80.30529541478742,-0.5339510573059318,-55.23064361193748,0.9999999999999982 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark14(-80.36779296395132,-1.0053201352464174,-26.331128260715257,-0.5557447462558289 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark14(-80.46905850572148,-0.1329357731838814,0.1286203941425655,1.0 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark14(-80.47807591598671,-0.47064331128435327,-63.990255046572024,-1.0 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark14(-80.48466706999669,-1.233553365815348,108.02000106126354,0 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark14(-80.52502020933001,-0.8196582858693304,0.11021619039219764,0.33323502730672283 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark14(-80.57390435867782,-1.487879410476437,1.5707963267948948,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark14(-80.576448002123,-0.5248378998465648,32.91482611635698,-1.0 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark14(-80.65224911275821,-0.47735821803115175,-63.6262836386482,-82.01225261846115 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark14(-80.66582952111656,-1.3256695707435726,-21.85590133883957,-0.8712263757206931 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark14(-80.7081824311898,-0.0037021878850873524,37.90830318608988,0.29229904220315667 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark14(-8.07892519582556,14.430563374157394,58.12937852859372,0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark14(-80.82412903857318,-1.083838784050272,53.61107375766878,0 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark14(-80.87100140381173,-1.0023465223966657,1.5707963267948966,-0.6723773615998347 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark14(-80.9235101524682,-2.1620280058711972E-16,-95.56202079386392,-0.9999999999999997 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark14(-8.108216478591686,-0.37295152410819193,1.5707963267948963,-0.6884128093727725 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark14(-81.13636255696308,-1.5707963267948957,-9.856586690209031,31.81624448480686 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark14(-81.2171396641369,-1.5707963267948841,-59.666660732725454,-1.0 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark14(-8.128736976543783,-1.2112732226278393,-56.53287317035196,34.7062220898334 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark14(-81.3623950594915,-1.0877487415032434,-32.3854014905528,1.82877982605164E-99 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark14(-81.40569594280075,-0.16720463218242337,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark14(-81.40572670437516,-1.2455356874899985,0.0,0.8085793710218496 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark14(-81.41718896595545,-1.1302951812892688,1.5707963267948966,-0.4497828829694877 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark14(-81.43432606390608,-7.105427357601002E-15,-49.62807836804932,81.50762975927404 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark14(-81.43643450072855,-1.7763568394002505E-15,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark14(-81.44487163280796,-0.3063753722439884,0.28325540949376504,-0.019519526321049713 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark14(-81.45276157032227,-1.5707963267948963,-1.8506959618821017,-0.03282645215286964 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark14(-81.4917487229163,-0.9614141853790863,-87.24698601229674,1.863202016924319 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark14(-81.52935035620114,-1.449909617894627,1.5707963267948963,35.400039663893956 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark14(-81.63088382859563,-1.2307037193905366,-70.52245063450052,-0.8601115658915055 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark14(-81.64046962473225,-0.9527458238199911,37.82948699826369,74.34831896383832 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark14(-8.170667000511909,-1.1102230246251565E-16,100.0,1.0000004929301292 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark14(-81.76250956739631,14.507015221540982,93.32083460039011,0.0018152536881242147 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark14(-81.7888373077365,-0.07040410213000092,6.3666911051102275,1.0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark14(-81.88748831816359,-1.1678550706683382,0.0,-48.73324233954717 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark14(-8.195541538070533,14.432567805731772,77.04247846080914,66.31397568974046 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark14(-81.97212914260561,-1.355437200789317,-100.0,-1.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark14(-82.01453958286383,-1.570792918669623,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark14(-8.202652893188414,-0.08419376311045002,15.534686515077716,-1.0 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark14(-82.0960859906392,-1.9721522630525295E-31,0.0,0.9999999999964488 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark14(-82.10416237042249,-1.090230077539595,-1.5122835026714812,1.0 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark14(-82.19355961365551,-0.5704706874189931,-18.919315073164178,-90.43210375330654 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark14(-82.26196221526159,-5.459125421930812E-16,26.54972342691742,-100.0 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark14(-82.30673855462157,-0.5181447714829204,-34.69670145207908,0.025907605908631323 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark14(-82.49147022705097,-0.9563679403409019,-77.40640620426342,2233.194322368106 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark14(-82.49198508113267,-1.2885914866293826,-79.8350462563193,-0.3128156017184458 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark14(-82.49391228173856,-0.5112731832304378,-97.97519086284012,0.45448276170472546 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark14(-82.70860226729422,-8.881784197001252E-16,0.939029393234109,-37.766801798845506 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark14(-82.74184317004934,-0.5483545481067326,-50.65968573082698,84.74972668041511 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark14(-82.78880037047885,-1.2162382072413718,-46.31121820682893,-1.0 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark14(-82.96755750605575,-1.4761121559963866,44.444391279223844,2061.9963788930486 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark14(-82.96831245962372,-0.1013943873947919,36.78425724933396,0.9860329860977542 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark14(-8.29747176853104,-0.7860889278499098,1.5707963267948983,12.291815876445526 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark14(-82.98889235227927,-1.5707963267948912,-22.52697272646114,-0.07918397367539098 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark14(-83.033464009271,-1.5707963267948961,-95.65836741457342,79.94532922557825 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark14(-83.09193785469074,-0.6980732080375303,-38.49636626686657,-0.008593954004798454 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark14(-83.3057131445524,-0.7536806400642588,-0.001673659084877821,1.0 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark14(-83.31615023144141,-1.5707963267948912,-27.478064546904932,57.63626860345431 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark14(-8.334614875970829,-1.4844183914830036,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark14(-83.37217764018733,-0.032132730060298126,0.8414645749493966,1.0 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark14(-83.46334853757752,0.009653687635145309,-1.5707963267948983,0 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark14(-83.46874882492365,-1.0990950676743836,-95.68560229311748,1.0 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark14(-83.50183871484013,-0.39236425702939826,-12.963041064350403,1.0 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark14(-83.54574882920595,-0.5624394276282648,-0.3684817057411757,0.0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark14(-8.364489818879083,-1.5686400968946113,-69.61616072198734,-1.0 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark14(-83.66792069550779,-1.3666401315125376,0.0,-0.14192207366655651 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark14(-83.71052231272772,-0.33342340267772347,-101.86519095580431,81.23779041238049 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark14(-83.8088795982805,-0.042079613343797846,-72.7052073263522,1.0000037606608576 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark14(-83.96598152260934,-0.1561877998699145,18.001716093806195,1.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark14(-84.1686014427001,-0.21521040436599748,-152.61747813382604,-0.04120568815333936 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark14(-84.19381117414935,-0.4277127951403745,-58.104791920743324,0.0 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark14(-84.20087885390905,-0.0747329799323718,-64.56340353718296,0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark14(-84.2590757706726,-0.819781518165072,-77.67638771435321,1.000000000019805 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark14(-84.31670578771502,-1.0806015883401712,-1.4876643693691076,57.120895489854476 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark14(-84.33858560481977,-3.552713678800501E-15,-49.187988578383624,-88.43193402965399 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark14(-84.68621350450317,-0.6699103423180373,45.5342298736366,0.9256333143720757 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark14(-84.74492902913609,-0.2086425663285001,-0.25839564248052427,0.5206737586264629 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark14(-8.484293785319132,-0.05020171512497335,0.0,73.26838728665187 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark14(-84.84874760475556,-1.518123463225788,-57.653009171855714,-1.0 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark14(-8.486511221490332,-0.36348997200634614,100.0,1.0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark14(-84.87926941334582,-1.3109947861864897,0.0,1.0 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark14(-84.91171781698193,-0.5245790365288895,81.99082361184315,-0.0976927851006853 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark14(-85.01162212099986,1.7790506496182334,7.13200208100943,0.7011624275330327 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark14(-8.518154355222435,-8.881784197001252E-16,-51.811242774324406,0.04089337959967798 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark14(-85.18292382556173,6.435099877596429,7.256946871247951,1.0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark14(-85.24229680441371,-0.02957663426891262,37.71754567904454,-1.8991135491519597E-65 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark14(-85.31821728958833,-0.28523331669765145,-32.779705817324995,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark14(-85.36041918458062,-1.5143289504522441,88.85145894735456,-0.9950722002920607 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark14(-85.44452745330163,-0.12399579059377594,45.32799800941499,3.944304526105059E-31 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark14(-85.44525150955576,-0.04633980153808692,-95.78911330089865,0 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark14(-85.4698231466789,-0.23639658961476306,-88.19334313158969,-1.829567780285202 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark14(-85.52699692320405,-0.03238120371075654,67.55386049269171,36.390145336329695 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark14(-85.55309716730042,-0.9195100295616363,-49.76156223034827,1.0 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark14(-85.58828694663188,-0.7124123823173245,-100.0,-0.9913495759786355 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark14(-85.7789815118409,-1.48387279343515,0.0031890145986821525,0.28120554274756915 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark14(-85.79794148710508,-1.0313872902345866,-1.5707963267948948,0.4274891622460024 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark14(-85.90734664934624,-1.3938640413249241,-0.2537861444733347,-1.0 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark14(-8.598136535557234,-0.14891954838678312,-88.26213637215312,0.0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark14(-86.16143162721602,-1.5707963267948957,12.598097534887742,0 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark14(-86.21968262571035,-1.5707963267948912,31.929764865078397,-1.0 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark14(-86.3525258052976,-1.5707963267948961,0.8465155288315245,-28.3523451651889 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark14(-86.35788476050655,-1.0614750845661192,-77.39856936790537,-1.0 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark14(-86.39543297424936,-1.0252694942005434,-64.80400573109087,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark14(-8.64056220061784,7.3245433062867,45.60615712980686,0.0 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark14(-86.46697909689819,-1.4633960385716511,13.44700371803367,-0.38465515789492066 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark14(-86.49995783871158,-0.793706037162142,-1.5707963267948983,4.495997547141911 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark14(-8.654472541152927,-1.5707963267947456,-21.501374019011635,-91.1650347896841 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark14(86.57466474531824,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark14(-8.65961584894492,-0.19091026714859677,38.97878168913675,0 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark14(-86.75422864109815,-1.5707963267948963,13.812534309797964,11.077750449306619 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark14(-8.68253612660449,-1.5707963267948963,31.771969720529096,31.861746340693145 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark14(-8.686182161345187,-1.0149824204802038,-4.865987393627346,-24.58207223844778 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark14(-86.97459915998448,-1.2783845824157791,1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark14(-86.99983728309249,-0.985134324693283,-1.5707963267948966,2211.506334329149 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark14(-87.08004690002247,-1.5707963267948948,1.0405794533202624,11.68979955918342 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark14(-87.08883480612096,14.434492939297797,72.19704386640235,-963.494601255899 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark14(-87.14700576633153,-0.6542193295817228,-36.91920835277365,1.0 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark14(-87.19408231807721,-1.4074554387329181,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark14(-87.2249096178472,-0.2159164248690928,-44.28750303806146,43.62464295159871 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark14(-87.22633975343187,-0.5434682965967476,13.334707161550647,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark14(-87.22765811861838,-0.7293618602543983,-32.10930041521665,-11.158848193949437 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark14(-8.73206920457556,-4.440892098500626E-16,1.5707963267948963,-0.6709495103063744 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark14(-87.33537047457068,-1.5303009117512811,-6.257297408867277,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark14(-8.734263052550993,-0.4825137181381111,88.45931369405116,-9.50986249809192 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark14(87.3858916539507,54.45723106781648,23.044716178196296,0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark14(-8.745774053976366,-1.5142103451066502,0.09447592026545559,1.0 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark14(-8.748270767960875,-0.007219617562595149,38.7732512934399,-0.8437261756291025 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark14(-87.64983870302324,-0.28276394087356693,-78.18738976873824,20.56950675752418 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark14(-8.767152154476928,-0.11567190476253586,-0.3319900941646381,73.88187209858191 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark14(-87.80229495798056,-1.2377700558713887,-53.772107374356,0.18075006500083335 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark14(-87.83840159570398,-0.4620804732353889,-87.93398421744365,0.2745870699213092 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark14(-88.06046399077604,-1.2371150787697553,-39.69210806850713,1.0 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark14(-88.06260196170918,-1.3643283091559517,-28.14982106659496,-2.380744306267392 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark14(-88.06350761971315,-0.002076790517715107,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark14(-88.11412657063131,-1.2352169976520946,-92.80143191466993,-0.9464949121043434 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark14(-88.2148635533459,-1.3443274681535227,-1.535529489176787,1.0 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark14(-8.823569108479148,-1.5707963267948912,-82.06980436140638,-88.44857995051873 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark14(-88.38312396684321,-0.5268673120203211,45.176481901954986,6.57900188162574 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark14(-88.39233077428284,-7.105427357601002E-15,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark14(-88.49210921443138,-1.5358341105722795,0.0,1.0 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark14(-88.50964382760816,-0.80001464709947,-37.09155933190465,-31.26624099757352 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark14(-88.51811359287186,-0.38692158565551504,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark14(-88.6084951955076,-0.09995175544625265,19.481389882280013,52.728348264969256 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark14(-8.863494248451198,-1.0540436773880328,-58.69612316015051,83.25280982759438 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark14(-88.74066522193611,-0.7778499434038517,-66.32774173940686,40.27465950555336 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark14(-88.9260205895187,-1.028295258353094,-75.64934941180607,0.9652136385851987 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark14(-89.00638227788622,-1.5707963267948961,54.294773413680325,0 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark14(-89.0574360736683,-0.2548632365123171,6.844683205168191E-147,1.1113793747425387E-162 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark14(-89.10827112674448,-0.6321731143848597,0.0,0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark14(-8.927990672461942,-0.6615084831612349,-70.6959721137609,10.481562828930668 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark14(-89.32340989660668,-1.2112891558226104,-9.548917314456304,0.045545269379449305 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark14(-8.932566120306205,14.429280729957974,-0.0636364470832862,0 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark14(-89.33956775472701,-1.4900056414614649,-1.5707963267948966,-0.0625763779624875 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark14(-89.34471570570427,-1.5707963267948557,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark14(-89.41794856086221,-0.004430589326862783,-49.720251400805004,0.05347956677427093 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark14(-89.44127432052959,-0.16652747932141054,-1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark14(-89.506802550763,-1.5214671381136022,-53.49179178713782,-0.59219753344563 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark14(-8.953660712781408,-0.9905354781548941,-98.12879446001179,-86.97742937160893 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark14(-89.73911449975627,-0.9937504094176666,-58.0247238205317,30.391713905845265 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark14(-89.7426320045802,-1.570796326794838,-2.7399569637603634,-2098.3049029885888 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark14(-89.78665501286117,-1.5707963267948912,-73.54049249308864,-4.6816763546921983E-97 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark14(-89.83765914164577,-1.0801739597367084,1.5707963267948966,-0.9999999999999964 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark14(-90.08797869199763,-0.5402652415587426,-5.683437975155556,-52.54310099423609 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark14(-90.14854900823433,-0.11563227086660358,-1.5707963267948966,-97.43912872478617 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark14(90.17067405266931,0.512073401036389,-72.190052917698,0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark14(-90.21926602358471,-0.37622014253074676,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark14(-90.26620191008561,-0.4017605755709031,-64.49179250817141,-25.963720591412606 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark14(-90.29655354955607,-0.05603507493714689,-74.56634099487388,0.9999999999999999 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark14(-90.32239055935983,-1.1735460512364722,0.0,-5.571939822038132 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark14(-90.3493836189543,-1.296057646828984,-1.5707963267948983,0.8137203687914598 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark14(-90.36391603214282,-1.4973212026339802,-78.29082918936732,-93.79299937816282 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark14(-90.41185362027831,-0.3328297132876773,65.28172481206656,-29.9704690113173 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark14(-90.44429860818936,-0.907428084336617,-42.53986340982203,0.2627354351217829 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark14(-9.055923985812832,-1.2479851108370508,-8.493377525683215,84.85321508118554 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark14(-90.565622608078,-0.2979411297931397,40.07537870309986,-115.88625197940245 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark14(-90.58213234571471,-1.5707963267948948,-1.5707963267948983,83.81577289850023 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark14(-90.58679144532108,-1.309150674484923,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark14(-9.060394865626165,-0.6024385017857901,-37.82129633638316,-0.01515887733854182 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark14(-90.67022388920824,-1.4330731468263185,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark14(-90.79318281638373,-0.5468140598840954,-4.433809129899217,0.0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark14(-90.79903833354345,-1.5673047349593325,0.0,0.46798350277109746 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark14(-90.80920663262508,-0.5730732495535822,-27.042098014510398,-47.39349962581967 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark14(-90.82447359915658,-1.5707963267948948,-66.38798264037175,0.9999999999999952 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark14(-90.89205370574102,-0.9013913009250225,0.0,-1.0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark14(-90.9366808693211,-0.2611499909913079,-65.24011992205834,1.0 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark14(-90.95947999689167,-0.45738104950405517,0.0,0 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark14(-91.01305781481537,-1.5707963267948961,-19.836696436329625,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark14(-91.04269469423232,-0.11502103495029303,-1.5535275611013928,0.12398053106698015 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark14(-91.06029903327477,-1.5561768531570492,94.36281562871612,-0.1344665506441972 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark14(-91.14724490414181,-0.20202599185094794,-1.175614790467809,65.34841745972679 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark14(-9.127230949232072,-0.435648706181631,-42.861176432883795,-0.9948402844130195 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark14(-91.3804555355451,-0.8277589904981865,13.311078579252708,-1.0 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark14(-91.50816615103216,-0.019948623154475306,58.19637603036247,-0.14713532863672274 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark14(-9.158311398767895,-0.11031871260350701,-68.85881872697297,0.0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark14(-91.59242752871204,-0.24383324932898387,-66.52865155240976,-22.383683147451535 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark14(-9.16601362354767,-0.6876908064005156,-32.45975194916633,-1.0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark14(-9.183902485819456,-0.04715444660080892,1.5084507319716323,1.0000000000000009 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark14(-91.86876122634317,-0.9060710062997446,-25.43356528146745,1.0 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark14(-91.87283549281273,-1.0683710441073657,0.0,1.0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark14(-9.189533184539656,-0.7761535469670158,-31.669742014251355,-1.0 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark14(-9.195975422844043,-1.5707963267948912,-1.5707963267948966,-0.7855854595714822 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark14(-92.03796560928694,7.226605687535607,70.71232316418255,-0.011310026657508798 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark14(-92.03886882868986,-0.0031392010241262924,0.44117894008939434,94.05119389364863 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark14(-92.1443970661898,-0.04070027319360392,-74.71824795180795,-0.8506514441248949 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark14(-92.2047204940147,-0.31927791935334104,0.0,91.30693980516546 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark14(-92.22689288039618,-0.7871509194175487,0.08768851239423882,3.533238863366101 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark14(-92.24201711880966,-1.5124209968062072,-1.5707963267948966,-0.5719034801647824 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark14(-92.25553965231887,-0.690711271499012,-25.54163719196501,0.0 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark14(-92.29663643905177,-4.440892098500626E-16,1.5707963267948966,0 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark14(92.34639570218809,-3.4801838428670777,0,0 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark14(-92.40289546006277,-7.105427357601002E-15,0.0492879888404143,-1.0000000000000009 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark14(-92.41239252439796,-1.4950387081242775,1.5707963267948966,-20.51324921907389 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark14(-9.246932339595432,-1.5552358293928774,88.30182025645729,38.53586429532058 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark14(-92.56433762911297,-0.5346924757885106,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark14(-92.68478055350796,-0.002300092336456311,122.05365395091616,-0.7798988676162049 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark14(-92.75267836405972,14.429290709725215,-0.3432729466714257,100.0 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark14(-92.7840617275105,-0.8194108025180471,-32.76371513018938,1.0 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark14(-9.28177520659717,-1.5707963267948912,-78.44915381269483,-0.8187679167759949 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark14(-92.86317551388436,-0.8817965187853347,-27.063430284370057,-1.0165702892077346 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark14(-9.287410655726537,-0.011879176267447715,-80.24571827751605,-0.062649210495022 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark14(-92.91860669248865,-0.5124826505549251,31.88422478783525,-2283.9806768761337 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark14(-92.95057557812771,-0.6146526828734853,-0.1359641024145195,5.1977048828224496E-113 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark14(-92.96184181874489,-0.5263336803695289,-45.12485342051099,-8.552847072295026E-50 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark14(-92.97034552615372,-0.32875489251154155,-5.875191240821678,-1.0 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark14(-9.302560062741097,-1.470834110906836,-0.07466861277068304,-0.15143191352986562 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark14(-93.08089358734287,-1.060045488177448,1.5707963267948966,14.054539216338528 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark14(-93.09368162674323,-1.532233374987639,-0.2878314640619917,0 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark14(-93.22993996173179,-0.5831728663371815,-62.223886354575505,-0.15381246995990827 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark14(-93.35819885571094,-1.1808966182088847,0.0,-1.0 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark14(-93.3829010814088,-2.3259959972033173E-7,32.75987543648319,-0.04830888771057009 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark14(-93.38919792644325,-8.881784197001252E-16,-32.50525457963818,-5.833519771394622E-17 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark14(-9.347289031009893,-1.5446585126490875,-2.05582770380839,-1.0 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark14(-93.51829904860321,-0.7850639780725877,-61.41582125593564,-19.040258352432687 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark14(-93.61951150296225,-0.6705677945382212,-33.092734295560106,1.0 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark14(-9.365489752955856,-0.7611550239753088,0.8722477065667833,-40.21624011528749 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark14(-93.69405401575318,-0.2813534239174056,-99.89096166431901,-93.33845103135194 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark14(-93.69533122405102,-1.1328816624572404,-100.0,100.0 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark14(-93.70378366405181,-0.024560143850314284,1.570796326794893,0.5397296996977494 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark14(-93.7088688491117,-1.7763568394002505E-15,0.0,-1.0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark14(-93.72768449810455,-0.11447064253916778,-89.59371951762422,0.0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark14(-93.84456031288988,-3.552713678800501E-15,-1.5707963267940492,21.75329676955871 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark14(-93.87148234527575,-0.5943673627987074,44.06741173718572,-0.9999999999999959 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark14(-93.94328553838598,-0.39633947494846256,37.85399208641786,0.27098122500885746 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark14(-94.01046556358145,-1.5487325252028958,-68.40818603315839,25.660332298911868 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark14(-94.01598133471303,0.9194048341730942,34.53476227569563,1.0000170468706158 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark14(-94.08660660977294,-0.5544577495437354,85.25432657408129,0 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark14(-94.12772193746909,-1.4784543338659093,1.5707963267948966,0.7977541602980879 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark14(-94.14460867813649,-0.6226729229306984,-70.73119019922275,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark14(-94.2300499700836,-0.027950665055055043,-97.08821910413602,0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark14(-94.26618416620491,-0.9376449022121989,-1.2425552453782094,-1.0 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark14(-94.30839761257566,-4.440892098500626E-16,0.23636075215106886,0.0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark14(-94.36562952536111,-1.4347714873474342,-75.09970679502524,0.06258984786229572 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark14(-94.38188910060545,-2.7755575615628914E-17,-68.6080565783282,1.0 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark14(-94.4601031520619,-1.5707963267947664,0.0,0 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark14(-94.64723028287918,-1.4740050706281167,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark14(-9.465164658831984,-1.305102342251407,0.056247335024397556,0 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark14(-94.70337949608916,-1.471313045507367,95.66733900231712,-0.3621244869071554 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark14(-94.93824889864169,-0.17221316434344472,-44.19324010026329,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark14(-9.498255894446515,-1.4954103321835066,44.54748269557942,-0.970398041033195 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark14(-95.06530551557009,-0.8940164193683321,-1.5707963267948966,-74.49928999784836 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark14(-95.21670919434277,-0.051294654385399305,-48.78137419204339,0.6246894753992587 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark14(-95.21984164136977,-1.3276754625099723,-24.275373880741128,-1.0 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark14(-95.25800692014299,-0.7377812160855508,-40.287258520625855,-1.0 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark14(-95.31483256532665,-1.254022633197454,-1.5707963267948966,0.04965663258555342 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark14(-9.545196940864788,-0.09661764098758971,31.850218031199333,-37.87851699296928 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark14(-95.46241166666059,-1.5707963267948963,44.35030324492478,0.9870702939835124 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark14(-9.548646851514285,-1.320030622518317,-134.1274137089565,2133.0663764467276 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark14(-95.50456541689353,2.8499354806939112,77.4895130909257,-0.9999999999999982 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark14(-95.50845224502484,-1.5447676184125463,-1.5707963267948977,-0.6422023056534882 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark14(-9.56618281692694,-0.6608200070868939,-86.96508089684195,21.839785811641605 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark14(-95.67252539857303,-1.3400441612388505,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark14(-95.75041231605283,-1.3852717534959638,1.5707963267948966,-79.47321401307174 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark14(-95.75471803714791,-1.224291608080157,-1.5707963267948966,-1.0000000000000007 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark14(-9.57622561657705,-1.568375805622764,-1.5707963267948966,-33.54414439477519 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark14(-95.76385828516565,-0.9211053046526807,-10.914190020574054,21.977745541214546 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark14(-9.578318385830187,-0.004160638141087247,-90.3839867748566,-3.1876724678607786 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark14(-95.84301518276584,-0.6723211646885577,1.5707963267948963,46.823554824085704 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark14(-95.94466457709922,-1.429581264057048,-73.6308910570882,-0.02081061134689649 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark14(-96.0346065966386,-0.5572037306779427,-97.1192351823023,-0.3142402957776804 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark14(-9.617588074697863,-0.08250164871176113,-31.307658764013908,-1.0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark14(-96.24260585611422,-0.8355314240535135,-1.5707963267948966,-62.61685943478801 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark14(-96.31649208766079,-1.3419145886999644,-21.7451426850038,-60.817734611144104 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark14(-96.37979396955842,-1.5707963267948963,-1.5707963267948966,87.5035234395983 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark14(-96.50365156682346,-0.4115449104175433,-45.087162084494864,-10.017811827233569 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark14(-96.54412299112978,-0.1181189829545065,52.712331898884756,48.927804134440734 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark14(-96.54755968119497,-0.6777741951405091,-5.061962393326439,-1.0000662243005152 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark14(-96.66576443888451,-0.05234734344432573,-49.100961591490034,1.0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark14(-96.7274593234094,-1.518354604826668,-164.93257382880228,0.06059415785104773 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark14(-96.73897006544344,-0.8709361327949718,1.5707963267948966,-1.3050608935997049E-54 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark14(-96.84616403995727,-1.5696910214924131,2.808007374696569E-17,1.0 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark14(-96.8901063712282,-0.3934282754218198,-4.3368086899420177E-19,0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark14(-96.94262619346634,-1.3107130791996076,20.170015082078287,-1.0 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark14(-97.0879721786601,-0.778470458807611,-40.4403776057614,1.0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark14(-97.17027414449899,-0.860772999545771,-0.9832712779976029,-1.0 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark14(-97.27654945206545,-0.27341639778580806,0.8843179565754101,1.0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark14(-97.29909948152158,-0.7915147719652003,-41.270812264042135,-70.80289189551931 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark14(-97.30284982447438,-0.7766903418190261,-7.929121903056483,-36.629916117971085 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark14(-9.748733174047317,-0.0802536719643157,-54.04213491505166,1.000580026927853 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark14(-97.52532224886168,-0.595871048222028,-7.095545060660882,1.0 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark14(-97.54862519524956,-1.3762871529640117,-10.854068729625908,-93.17818304188836 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark14(-97.61978450167734,-1.5348910166432406,-1.5707963267948966,76.51434951366963 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark14(-97.69048682535245,-0.47119078875802956,-46.01608288919559,1.0 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark14(-97.78916263866711,-1.5263706384181006,-34.69147399736869,-28.076856844982295 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark14(-9.778999504123178,-1.0289488812943852,-81.60675916271293,37.08940575803996 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark14(-97.84910860812114,-1.0278948635496221E-4,-1.5707963267948968,1.0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark14(-97.85385945781964,-0.9238459720264495,1.5707963267948966,-40.51553279754858 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark14(-97.87661953441777,-1.1820294081366738,-20.876444911892328,0.003161183223155284 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark14(-97.92462282760728,-1.1744148473648226,-95.66721894202605,87.39572379063775 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark14(-97.94884962138767,-1.489138833619689,-0.7817880105929904,-47.57383226709058 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark14(-98.01973619254143,-0.6389623567767194,44.41143577499075,1.0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark14(-98.04109624556118,-1.4025771927721706,1.5707963267948912,0.062581192430093 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark14(-98.05634914204464,-1.5707963267948948,-1.9462578608970727E-15,-75.9450415924425 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark14(-98.12256692432985,-0.2843581155005535,-71.71694369558362,0.42992565609763 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark14(-98.12983792314776,-0.41026483810009684,-27.624285299209106,-22.37099770358037 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark14(-98.2173354709684,-0.9988717987343048,-1.5433473353929106,-0.577696726568542 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark14(-98.23956886006093,-0.7349731701293651,-122.26826832628029,-0.007980787698828706 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark14(-98.26309533026239,-1.3493310213844285,-1.5707963267948983,24.926925906731 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark14(-98.3143795900599,-0.20557099365587347,-1.5707963267948966,-9.183549615799121E-41 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark14(-98.3933710169698,-0.07758554822322705,-1.5707963267948968,-1.0 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark14(-98.42837713083895,-1.5602337800354853,-67.20484284376474,0.9999999999999996 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark14(-98.46880723667792,-0.9166019108450811,-61.76069656797903,-0.6741062331339245 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark14(-98.46988374081604,-0.641576665999902,-10.013769360396148,-0.25348514057284177 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark14(-98.48097469183871,-1.5707963267948963,-0.030036591996111084,0.9423587093637914 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark14(-9.849243160669863,-0.8155011256810526,0.0,0.6366536579799047 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark14(-98.51471565166506,-1.5707963267948948,-81.32614586013878,-1.0 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark14(-98.5717544583582,-1.0605631117990115,0.40935602357309286,-5.636429815863688 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark14(-98.67996741468461,-0.13021850865033255,63.910848106262065,1.0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark14(-98.69293912289376,-0.4626687094463193,-9.779597856627738,0.0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark14(-98.74970706226965,-1.5707963267948912,-72.10718103996066,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark14(-98.7538161822926,-1.1814031758209649,-35.71556926788344,-71.82789010356669 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark14(-98.75543998258784,-0.05874717903559412,31.98542753735739,-84.04369305202982 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark14(-98.80413024598171,-1.5653797888649104,-67.5473659396854,0 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark14(-98.81269843862279,-1.1868128882227829,45.310702525118145,-0.46111827514522574 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark14(-98.81885865590714,-1.2442188361769988,-80.05953430966285,-0.271124585109078 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark14(-98.96096298216837,-1.5707963267948912,-37.7951853693488,22.931181080845263 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark14(-98.97581503432792,-1.0445798606892254,-46.518337114930986,-94.27787213935228 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark14(-98.9776123270971,-0.21278306027059518,-99.15479769682013,1.0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark14(-99.04340204137849,-1.5546563453529658,0.3262046084482376,0.9963498198605587 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark14(-99.0798017236976,-1.5707963267948957,-45.24262670823065,78.71468366321642 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark14(-9.911906216312296,-0.27977281084908384,-47.04470469780018,0 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark14(-9.914202245303557,-0.7603438399075728,38.70726027631437,0.8337427087145244 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark14(-99.21949745709806,-1.2356291200605054,94.51843181618554,-0.5934370424035729 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark14(-99.22245645645458,-0.0010293908042665334,100.0,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark14(-99.24755299064246,-0.31493030918647485,0.0,0.3796713661985375 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark14(-9.930707286002118,-1.5707963267948912,0.0,0.9984194400034635 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark14(-99.33144194852737,-1.5707816592113293,-21.4067237986858,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark14(-99.33607848168495,14.92825501847502,44.06492642483361,0.37744235448541164 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark14(-99.34378465023202,-0.05807474562767112,-27.52993881417963,63.019410600772375 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark14(-99.38026717857366,-0.13262032226677933,27.899832810480564,-100.0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark14(-99.39168168610188,-1.1027332606162048,-53.699201479278,1.0 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark14(-99.39730434492937,-0.2103374124237209,0.0,1.0 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark14(-99.39958910217375,-1.5168723520401177,-44.098158583143075,0.353485252586871 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark14(-99.50460712519967,-1.4210854715202004E-14,-40.11180953431068,1.0 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark14(-99.55602170607315,-0.34296188038843933,-44.196737441855305,2.1084395886461046E-81 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark14(-99.60957382069715,7.539280992246867,70.66885476710883,-110.57956096855325 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark14(-99.6107484803861,-1.3614953638559548,2.220446049250313E-16,0.9683375284399683 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark14(-99.64546609128865,-0.11053921983212697,49.93113519731966,0.0 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark14(-9.966833148724916,-0.31651149216874885,-30.251872120741734,1.0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark14(-99.66894406572041,-1.337685990887001,0.0,-0.9235954123917661 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark14(-99.67285663872035,-1.0904320197116175,-1.5707963267948966,1.0000000257612578 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark14(-99.7079343810396,-0.060405745679904976,-101.87224244887415,0.12780670757358803 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark14(-99.73202963029995,-1.5707963267948948,-13.262863529343175,0.06256671399308997 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark14(-99.75101851296395,-0.035380213820953355,0.5985626002408357,-0.2903909204994344 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark14(-99.75203772823156,-2.220446049250313E-16,-10.794248508923808,-31.99348025124378 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark14(-99.82855157644892,-0.5590633412545971,-2.768628465149291,0.6994824214454483 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark14(-99.85760379363519,-0.6100269752966758,0.0,-77.11305652399567 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark14(-99.87815307316899,-0.9551263667319692,-1.2572202291279648,-1.0392318183952627 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark14(-99.87831310460172,-0.22188640420680716,0.0,0.5319846104803231 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark14(-99.88269687031698,-0.26477230703353477,-86.08403601040149,-0.6485210312861038 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark14(-99.88391734505345,-0.023155247081405803,-32.457614240210546,-0.998775117369743 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark14(-99.88966040287293,-0.016130187193455547,-89.71526113989302,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark14(-9.992349063387863,-1.415994412755872,-72.5155617364345,31.428582665937256 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark14(-99.92895848055387,-0.9656306794621542,-130.02442457855085,-81.17619029953025 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark14(-9.993006424745191,-0.9066433408203918,-79.9340228470335,34.04974330530898 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark14(-99.93769553744194,-1.5707963267948912,-4.494557435081685,1.0 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark14(-99.93881346917979,-0.007300569951182709,-95.61132895323856,1.0000000865317737 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark14(-99.9816830941459,-0.5118436043302245,13.04512182538649,1.0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark14(-99.98358529845638,-1.1102230246251565E-16,38.91900454197872,-3.4704340738366346E-10 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark14(-99.9923134901398,-0.2898858624060627,-88.01479526329638,0.9774488676636749 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark14(-99.997627567863,-0.9659037596872504,-6.606053261544616,21.23898011490934 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark14(-99.99889076915339,-6.91990171916604E-4,-31.882687248823018,0.6969125766845505 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark14(-99.99998402123087,-1.4724069131364654,-11.029403625327138,8.470329472543003E-22 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999746040524,-1.0079040424642283,-9.912930204744555,8.470329472543003E-22 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999946,-0.08260020336787818,27.4729312664251,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999983,-0.029417034832135154,1.5707963267948966,-0.9999999999998492 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999999,-0.04871704320551537,34.41660975463816,-6.681911775230489E-52 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark14(-99.99999999999999,-1.5707963267947427,1.5707963267948966,61.06527348872701 ) ;
  }
}
