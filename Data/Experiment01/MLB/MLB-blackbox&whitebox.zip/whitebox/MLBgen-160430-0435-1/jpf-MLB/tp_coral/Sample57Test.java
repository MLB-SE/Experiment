import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.002856231324409597,4.299839542291068,-25.990045803088734 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.010466914730515062,-40.102050304093474,-93.4864930246082 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.012473047841391027,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.014708899923792472,24.676296252052126,0.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.01683572194479909,-27.312826851601812,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.020519949455461317,-62.841453528343635,43.46919470335049 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.02183297328810596,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.027127329001242657,1254.7645069922078,-1148.1486262109247 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.0373670608283726,0.48879794343948335,-3.2135902940626266 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.037707012087059094,27.82387740274115,-23.52866857180741 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.04345820065534123,-1.0250665447337477E-143,1.6472184286297693E-83 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-0.5367584127241734,-1.1102230246251565E-16,-1.5112205509764451,-1.6305158361543142 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.6937966347248858,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.7961603259647632,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-0.9140069212328541,1210.0838435330795,-1299.370966380515 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.0033090065202630026,8.881784197001252E-16,-13.816373498305438 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-0.003809469609936042,0.1990599745125365,-7.755596567321588 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.010446828111094549,0.07190900524529138,-10.404191945333592 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.04503246397268328,-38.32834372547461,0.020806083856876333 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.05314930961554337,-69.91106754125305,0.022468492930221018 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark57(0.0,100.0,-0.05521388313653101,0.04992816477659123,-15.859433555510376 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.06046782616815305,0.0015990162708190009,-34.656244751248224 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-0.17748195885783274,-6.4663523758851245,0.1371728336480545 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-100.0,-5.551115123125783E-17,5.170163941339982E-4,-4.09255417103007 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,2.6610641591314934,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,-40.098121792590156,51.671511170529726 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,-46.43905428181439,36.38915455952764 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.1102230246251565E-16,-51.94462319641403,0.030239825224169414 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-11.255713504180772,-0.017778564673033043,1.7135565507404895E-6,-6.809212584554123 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark57(0.0,11.753652192176538,-1.1102230246251565E-16,0.3044021569973978,-3.9961307383929885 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-14.488310825184954,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1454.0717672356939,0,0 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark57(0.0,16.937395844872167,-0.02550370171386359,0.3018520313116835,-3.7175657374588624 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-1.7763568394002505E-15,85.14058377856027,-77.1818740554543 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-1.8991135491519597E-65,-1.8180195426798492E-15,-7.4607596690664835,0.08488244424804525 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-1.9259299443872359E-34,-0.05804754967484854,-3.678103610064994,0.37741498992642053 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-1.9331046979430375,-1.1102230246251565E-16,0.07745391048979935,-15.881365511470634 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-20.479644552825008,-2.4688740102136145E-44,-88.99090989082642,0.017651110593931207 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-2226.801989986333,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark57(0.0,22.613869901367554,-1.1102230246251565E-16,0.29052806188305563,-4.286218715720585 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark57(0,0,25.723134487083897,54.28100792434475,95.10220653554785 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark57(0.0,28.702483221245807,-0.02390521867778117,-7.619121207896617,0.11866896048711982 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-3.0456199630307923,-0.027733160001726403,0.006636639728764909,-70.21004688641807 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark57(0.0,34.91028727825907,-0.05792392466583334,-4.406992649317835,0.3552254913430509 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-35.93465529703042,-0.05083187416317316,-76.20853946048574,0.020611815131417858 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark57(0,0,3.6093958780312647,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-36.70809081996433,-0.028420213341596605,-13.580791897404628,0.055796698461607716 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-3.771270049604486,-0.0572007427121493,1.1102230246251565E-16,-7.747202935644698 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-38.37855674854058,-6.539899111686574E-5,-4.1309787265932,0.32097461055597054 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-3.8514057312058902,-0.003698337462503597,1.8106476887775705E-34,-13.142967881550163 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-42.28280264041943,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-44.677782234224196,-0.008857943660341427,-3.198105381823076,0.032876255609306834 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark57(0.0,4.471226094910573,-0.04007943991181705,-2.114916363454052,-1.045436778118505 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-46.826479103056684,-0.06183854866576647,-38.62209849300324,0.040670921262318416 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-47.440921278283675,-0.0029637953973202635,0.18973055537181174,-6.770545262553981 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark57(0.0,49.48353096929155,-1.1102230246251565E-16,0.06993364237199273,-22.461240020067336 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-52.147282505444544,-0.022580383936809334,0.11192422144005576,-14.034462840765135 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark57(0,0,55.33803625020249,0,0 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark57(0,0,57.64659892612275,-54.43377306242026,-80.11429797616788 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-59.067100480277965,-0.03218925691344719,9.154548781718508E-4,-7.059057210508842 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-59.79953116400555,-0.020255760804216122,0.0786937488572994,-3.921960434767822 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark57(0.0,60.639867430509504,-0.0035864289745698406,0.08252720113002188,-14.148897815489194 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark57(0.0,67.13389822909303,-0.0440380409853753,0.006120686796214414,-63.28663328911922 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-68.2712149671155,-0.010607890405732583,0.0814451503777533,-13.583733697973685 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-70.90842708820722,-5.551115123125783E-17,-4.334059955305828,0.2792081133760497 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-75.74450005889943,0,0 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark57(0.0,76.1374395888311,-6.885300439294857E-4,-7.9043423886494635,0.16667822290647588 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-78.26563482808703,-0.05111030687899891,0.22227866608196026,-6.801267949471935 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark57(0.0,78.32933728693028,-1.1102230246251565E-16,8.223058130474311E-4,-10.264427137301954 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark57(0.0,8.014781625506657,-0.18662360856512727,0.10625885325302396,-7.156483666075745 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark57(0.0,83.76465638156058,-1.7832915497132857E-15,-1.3469078694638552,-1.7966504608178644 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-86.13846558361801,-0.009578223229714647,-4.2783806058286,0.3670734078457774 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-8.881784197001252E-16,-63.765602678662624,57.44751919632526 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-8.957171939239885,-0.169042854052411,-3.704213041601173,0.42218708945955313 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-9.316293361816207,0,0 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-96.33894475262403,-0.029525567318417476,0.0967033139428997,-16.24345911994704 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark57(0.0,-98.76820472910812,-7.132134127839024E-4,-7.06916371889232,0.030336240099525198 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark57(0,0,-99.92269432204112,0,0 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.003730559978593312,-76.12310852585851,0.020634947221858442 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.013636550945811064,-9.191991082709677,0.15202539754144653 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.019103445731447035,0.039619924193895636,-1.5396199241938957 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.029471730892819292,-1.7975378890297655,0.22674156223486897 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.04484430721990907,0.06909804671822856,-31.485265566003125 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.04947936234781014,0.020327265935458014,-57.184508972810455 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-0.05271915908749625,-9.539295310944242,7.968498984149345 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.05441007643166945,0.08703213555007151,-9.87471436546106 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark57(0,-100.0,-0.06184665303146003,-4.0796173384025565,0.2487321582106331 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-1.1102230246251565E-16,-0.7808290519838721,0.7808290519838781 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark57(0,100.0,-6.232050228612007E-4,0.25965132038813915,-1.8304476471830355 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark57(0,-11.345512716133182,-0.028109498421735324,0.002755098854737126,-14.461955256941003 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark57(0,-12.008804604953768,-0.055672035429237876,-0.14355831805437266,-1.3564416819456284 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark57(0,13.095436947366535,-0.06090334472637349,-7.68552543658633,6.11472910979143 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark57(0,-16.25967021516607,-0.04926697853405436,0.01731142359905724,-26.612259327238338 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark57(0,24.845407945717245,-0.06004733095605874,0.9413644549940801,-0.9413644549940802 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark57(0,27.87671116724741,-0.043672959071045986,-100.0,0.015707963267948877 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark57(0,30.419038866642314,-0.002775347175956409,-3.6400232667424586,2.1400232667424586 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark57(0,32.146580238811616,-0.047376233834460095,-2.9323650468831213,1.4323650468831215 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark57(0,32.884552396431275,-29.827374572599567,54.13659536430359,73.55174198295055 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark57(0,-40.36899338906569,-0.059514935128688815,-14.077683014054983,0.11158060067318099 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark57(0,41.975441618810606,-0.03720195757115603,-0.03836062561134668,0.038360625611337795 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark57(0,-42.56986229748388,-0.03650810934984692,-0.1466656893608933,-1.4241306374340033 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark57(0,44.40057238701675,-1.1102230246251565E-16,-6.484355523061467,0.023498581284080222 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark57(0,-46.93067034958489,-0.006379410959736412,0.19769724507183623,-7.5319057170584465 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark57(0,-47.46087690940338,-0.014040369813006492,0.8550985298801564,-1.76860570422485 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark57(0,-48.83228353892514,-0.05058427683752986,-1.919704715149578,0.8182489288059607 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark57(0,56.11262133315413,-0.01180242112926666,-53.9300074283335,0.0291015494521297 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark57(0,-58.794016940671916,-3.469446951953614E-18,0.4433582263772351,-3.542950673612552 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark57(0,6.326450113418175,-0.006805438452349585,0.055570727854307236,-20.812233282582184 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark57(0,65.91597516699468,-0.034846461689638314,-1.8886121303463186,0.7039678583222434 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark57(0,67.23306856762153,-0.0468407953794199,-35.296607033554835,0.0445027570297718 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark57(0,69.40135643090248,-0.028436931768760512,-42.01151514667525,0.03738966141332334 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark57(0,69.5058043833478,-0.05160074451062287,8.881784197001252E-16,-5.279771091695551 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark57(0,-71.56221508609558,-0.06224013045281719,-26.08002613980393,0.006213435052096982 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark57(0,77.16351307500634,-0.026212679359427067,-20.522447103019122,-2.9687014721094287 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark57(0,-85.11185110095809,-0.003120523849534873,0.0466128648708235,-33.698772455793375 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark57(0,88.18336995064894,-0.5165443888107772,-3.6513230907262098,3.6504405623578386 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark57(0.9395276655776035,20.91317572180715,-0.005473476129702726,0.004571384986088177,-3.162190399025217 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark57(0,-96.21374685034083,-0.9889215678292413,2.654498251789539E-4,-2103.0789184815044 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark57(0,-98.92214786891488,-0.052843756094745786,-0.7802357709855867,0.780235770985584 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark57(0,-99.0954519003327,-86.52606302275186,51.12863511243077,-27.1577493476062 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark57(0,-99.36132491198705,-0.9999999999999959,-3.8756309645508242,3.8756309645508242 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark57(0,99.9991799904899,-0.9929167399218956,7.576030730937649,-7.575689002810359 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark57(100.0,85.24490404362297,-0.050507107823576536,-53.43201394706108,9.30371160556609E-16 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark57(20.267963697966657,-20.244033491341092,-0.06107231335643937,0.37729634748709606,-3.9767023843397995 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark57(2.465190328815662E-32,-31.383087271141097,-2.432608875233186E-16,0.4066211571195819,-3.810623027888714 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark57(25.97437467001466,24.35142591071066,-0.033329914392268734,-10.005970143091439,0.007026694914656906 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark57(27.564047263902452,-9.850625397054515,-0.029364997065407947,-38.37928716722419,0.0409282308957617 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark57(28.081743887154545,-79.80402700917925,-0.0020077851414102843,-4.173642752854754,0.15476769437009352 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark57(2.9764398413891334E-18,-90.20878096423915,-0.04309096079669894,-2.835216624467441,-0.3064769470546359 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark57(35.59131060432206,84.48155897142634,-0.06179133261202427,0.024338703197726352,-63.67989174937867 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark57(3.7739853170855335E-62,25.643962003090145,-2.7755575615628914E-17,0.05897118002266932,-26.63667788555417 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark57(3.9056959800629274,22.65241199466996,-1.1102230246251565E-16,0.020616169185062816,-41.53585492054653 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark57(40.09407711572144,-1.8482625371989236,-0.052985800961749735,0.14862218926731585,-10.527322277210637 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark57(4.134469950117872E-25,-68.03049112512417,-0.01151871029444593,-0.9237782516268682,-2.2224838556404922 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark57(46.393246685394345,3.8236289253921747,-0.05478012941917913,6.954419795644401E-5,-42.1354460358355 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark57(49.196601315349994,-45.042236200207086,-14.171524450253756,-16.251041234395274,91.72006439993905 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark57(5.520200269114608,-1.0552955619120932,-1.1102230246251565E-16,-31.95850667616021,0.006221223645365445 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark57(-56.74083463126002,-5.903178649546177,-2.1166985902884572E-4,-44.0057284498572,0.0024518490850247154 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark57(61.0704218925542,59.42260957943159,-0.0073749678861608214,-13.18863649609488,0.1156825523914282 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark57(-6.432698672092926,48.39114576433204,43.64881166197017,-30.66760024017698,-73.9513309234389 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark57(-65.7727785107964,10.984525063764039,-12.565479573858255,-31.080129006191754,78.23000089677319 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark57(7.418412301374843E-68,-100.0,-6.180533794618582E-18,0.05504718087491016,-4.008035225160678 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark57(77.33766535905151,-6.807086310988041,-0.03974435530947998,-7.50620525247613,0.08383170199685791 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark57(-78.19592037969436,99.99940648021716,-0.030713800936612197,-2.2838070653319162,-0.990884877167453 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark57(78.60369016593161,77.39423309217965,-0.027389459726925622,0.028599891368872123,-53.554904552518984 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark57(89.69252526897304,28.340039887865373,84.83275428894001,37.613783334191965,-13.743737665928407 ) ;
  }
}
