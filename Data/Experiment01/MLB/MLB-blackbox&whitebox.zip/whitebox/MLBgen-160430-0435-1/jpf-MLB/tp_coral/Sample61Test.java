import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,3.0567829936686053 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-81.32754972290574 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-100.0,-100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-1.7859177988785547E-102,100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(100.0,1.9259299443872359E-34,-58.016954038651626,100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-2.166848767722792,18.37547060723469,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-3.0647347761090806,84.46684280933728,-13.436644282265064 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-5.551115123125783E-17,100.0,-100.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-6.938893903907228E-18,18.07471516271331,29.484167160777435 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(14.744601581321717,-14.264182475195014,-9.191355328015742,-19.1319521034862 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(1.4884504613855944,6.588873714519077E-83,-99.99480998413333,-99.99824108727229 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(22.726180147255334,11.461596110137634,-53.46064910903963,69.08000601795771 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(22.817487772800064,44.88115249353075,3.8864204923779226,27.242252251290495 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(2.292472098137563,-6.681911775230489E-52,46.19642500727776,100.0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(24.277841540089014,-15.011796447869983,-135.1208058632821,56.189581021179976 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(25.5779206814373,-4.276423536147513E-50,44.82198830069646,-49.1421508140565 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(2.650623463903031,45.06233738580164,68.45287080449333,35.03215245582612 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(35.39369375212817,-100.0,70.36230022332154,-0.35393693752128175 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(42.22337893589602,8.673617379884035E-19,-22.642173146615477,83.41157743316164 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(-45.99597324115612,0.0,-99.96486675366833,0.7529710806561667 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(49.09056218016963,82.3196649302204,83.15790705524057,-60.078902450492855 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark61(-49.56688075660549,69.70131475732288,-76.25831350624568,30.70658508540754 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark61(52.91829853527253,64.29876667569582,-11.615771586590114,55.696986808010735 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark61(55.897236228140855,-48.690531417559235,-2.062020482366947,2.789760765522658 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark61(5.664709041808705,-2.2712493458248835,-3.404017720067613,34.809754215746885 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark61(58.297612509531106,-1.3603082124012346E-7,11.171125811116163,-159.6271928540143 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark61(59.254926040975775,2.220446049250313E-16,-63.07779292492537,-54.20916454311052 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark61(66.80665890497903,47.46828964582838,-46.459293555332515,-35.806698864203184 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark61(70.35236905401905,-60.28230433984301,83.12329090852722,-24.48020650504897 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark61(7.192232587720354,5.421010862427522E-20,-83.04126309361318,-11.547996252295547 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark61(72.81415280428034,2.694849442285822,7.291499417454787,-47.09159276625072 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark61(72.84625612291032,-48.01526508096438,50.11367346863332,25.216182885469692 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark61(74.44366353191901,-8.218355069142717,28.656587121024415,38.31467443753894 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark61(84.42619337517546,-5.934729841099874E-67,73.53090140735345,92.73883177400987 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark61(86.59252197346413,-2.2323972485981933E-103,19.60731279277002,-100.0 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark61(8.663758319253475,8.881784197001252E-16,-8.354018970035028,57.89382878754813 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark61(8.854186588822316,14.325803993754164,42.62784124971968,41.1823810830287 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark61(90.66705662394511,23.977493158140817,-50.912013144416846,-47.22812874009692 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark61(92.15519157463949,1.3684555315672042E-48,-82.33448675960946,-100.0 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark61(93.54160567765214,2.996272867003007E-95,-78.83368974390359,-62.489795971253685 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark61(93.61842638301289,-89.56400012243655,22.32028361900838,36.770164455084654 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark61(94.5462350103522,-1.1102230246251565E-16,12.975454050579984,47.5285630783182 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark61(96.59876269814654,-79.02755890776237,19.005610454131244,-54.764226653037085 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark61(-99.13727315765199,-79.26471329652179,95.80119986765149,-80.40104722919308 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark61(99.9996845214152,-6.681911775230489E-52,19.98087305314689,5.821823577548509 ) ;
  }
}
