import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0,13.067948916280514,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.5707963267948957,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0,-1.5707963267948966,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark13(0,1.9721522630525295E-31,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark13(0,2.491828581669182,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark13(0,-2628.07590644743,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark13(0,-2719.1685948169106,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark13(0,-2.9111077152172697,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark13(0,3.474674122583423,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark13(0,-46.77006581126562,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark13(0.4803840928272507,-28.161147898536186,51.95750330952109,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark13(0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark13(0,51.561343480794676,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark13(0,-54.67480796495501,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark13(0,-57.313187534535516,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark13(0,-70.99368896826368,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark13(0,-77.66531966293375,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark13(0,-91.49087935949373,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark13(0,-93.54972538287281,0,0 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark13(0.9999999999999991,-0.2637297041783597,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000009,-0.5356706666790391,-70.64194614473121,-70.03744483929228 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000009,-1.7763568394002505E-15,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000009,-3.610388751729659E-276,0,0 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000018,-1.3610651864936,-0.4338753477470361,-65.90269798478413 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-0.007809509153640954,-1.5707963267948966,2.465190328815662E-32 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000036,-0.5332677562480486,1.5707963267948961,-16.124926527046046 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-0.1029771396717715,15.556010533516343,-1.0 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-0.10385191052717871,-0.9740377780463785,-0.3110176764636091 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000142,-0.5107311857667362,1.5707963267948966,53.92577274036066 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark13(-1.0000000000000329,-0.7331677457452843,95.49997759646246,-1.0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0023423715774878746,-10.59912854590459,-0.8700608606162699 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.0038585818800202275,-100.0,1.000000320444278 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.008327487283696717,2.6973624781117054,-0.9999999999999999 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.02433614337585524,-69.73987726260569,-0.05130004948309233 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.02614850355495437,-95.9376474081413,1.0000028953927707 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.02728575606728564,-21.581794985892344,-0.7563309832341074 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.030285039671570625,-1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.034578285346659764,-1.5707963267948966,0.0632332582790878 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.04304554434243289,-100.0,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.048154148383271256,13.159956961646369,-1.0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.051152686654698534,-0.6021424512391046,1.0000012709307506 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05158577593597388,0.3202085401730521,-8.713420233794182 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.05844867058994374,-59.42424866984306,0.045405420486646975 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.07594936752006798,-37.42008912365657,-0.8966001601910847 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08182903491168703,-98.71168755508297,0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.08634226105208744,0.0,-52.750905874992775 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09315843274993693,1.5707963267948966,-9.561401714487081 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09429180832724171,-6.253904772618448,-92.3046836912638 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09903152396665295,0.0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.09921373574395959,-32.57423317612623,-1.0000000000000009 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.10185360376878105,1.5707963267948966,1.3552527156068805E-20 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.10318253635449277,1.5707963267948963,-1.0000841842288248 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.10628787255099083,-9.959765095552248,-13.843605533414852 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.10948260966424078,-46.95781229235994,0.297213426149719 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.12169142428691362,1.5497950430564549,-1.0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.13489668117790377,26.24775655613388,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14202480613359844,1.4799525535927665,1.734723475976807E-18 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14362947989511654,-72.59228866737413,-0.6468366325069921 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14450194230955898,0.0,1.0357196640828008 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.14736761674139898,1.5707963267948966,6.159982225710338E-20 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.147401125122818,0.23920325227005051,1.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.15500357296682243,-73.57891263757861,1.0 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.15705939236653121,35.1496362882898,0 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.18743512032651216,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.19558681063067002,-0.6159931248375834,-1.0440045746935924 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.21596553923260323,-53.77157888561734,-61.47870354796445 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2209553487222422,-45.23170916907434,0.012838758036068404 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.22301826101192412,-41.719318725847465,0.3532823323433174 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2277208615897216,1.5707963267948966,-2.5988524414112248E-113 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.23774461501566604,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.23839092541238271,0.966647733865522,0.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.24166748795816334,-77.20822787665719,-1.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.25561083667861034,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.25895892367546375,-100.0,100.0 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.2681291646144848,0.0,-1.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.271638753672546,1.3687149725311087,0 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.28484179746064053,-62.7868916186076,-0.7373974192539039 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.28519430635939913,-84.08823603742937,75.25385855957589 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.28832461503194523,-63.30059206221243,1.0 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,0.3002290928185397,1.5707963267948966,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3384252768339197,-44.422419736035025,-0.6407746584399396 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3518925286985489,0.29601173080674104,0 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3803535484337971,1.5707963267948966,-1.0168656879882039 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.3826956278714695,0.0,-0.910789234113782 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.40590460382421073,70.26840671791437,-18.5563952343705 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.41328594054854007,38.31805276967853,0.06286931881782794 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.42427399716568015,-14.6728360859827,-1.0 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.42903905473282183,1.5707963267948963,0.9287538492212729 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.42939997607993985,-71.80352837570145,0 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,0.43487561149488285,1.5707963267948966,0.8541463566958384 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4832031341828298,45.023189297942025,-41.53021331023987 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.4842143212980265,1.5707963267948966,-1.0000000000000002 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.48680063115785044,38.90744983204186,-0.6264405948406548 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.48707076462709464,0.0,-0.6996927351654003 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5030810944593187,1.5707963267948966,-70.84555118497829 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5140539090546792,-44.40648396287854,-1.0 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5226746591807476,-28.39664369309723,0 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5405683940851631,38.52070323421998,93.64201529404099 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5428542710821143,1.5707963267948983,-0.9837301256796267 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5495752352302052,-1.5707963267948966,-66.7623136989475 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5509286427707774,27.264605527822436,-0.0625593275151308 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5579478601176077,-9.822623016892535,-0.6199064190401843 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.558572474852917,0.11309402044869485,54.4641017114355 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.567477942198242,1.04620354501079,-1.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5833127477420106,-45.181989392575474,-2019.043757158648 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.5977204079497663,0.0,1.0 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6081821175910614,-10.85323014207652,-17.183449063115013 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6139181335527771,-2.6595163810094675,-8.552847072295026E-50 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6147232304236698,-15.00500422944144,6.6530622500127355E-111 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6245870488853918,-41.71015255545412,-1.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.642513771093558,1.5707963267948966,25.01401717180378 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6446299575261918,1.5707963267948937,0.3896074357713667 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6577124838648726,-52.22710824327985,-1.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6626814071858823,-8.153961263486838,1.0000002681975915 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6661572452119635,-30.331188759513264,77.32080110875866 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.67348354336981,-1.5707963267948966,1.0000000124132171 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.690890277785737,19.544961418796575,18.881223919136616 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.6956922668031069,-84.449553291128,1.0 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7049599711737085,-38.750830815161464,-1.482653629403767 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7270345262534743,-57.05414947067916,-78.49258027083957 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7309935799197248,-41.93945745213562,1.232595164407831E-32 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7346619635344891,-1.5707963267948974,0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7426372284323888,-66.8751863658712,-0.7939869568062795 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.74491623189255,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7481625678696713,-1.5183544572190268,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7611198942773174,-54.182880182390235,55.913138998399035 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7684594352744951,0.0,0.9999999999999999 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7749841102286582,-5.328826891505761,0.03988209973264016 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.7810163677213744,-1.1102230246251565E-16,1.025382806846796E-5 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8159057517320651,-99.0417591382804,4.5082903407156913E-131 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8200993158456515,-75.39546157611082,0.5311010922759478 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.8275351685204317,-63.18954639251106,-0.17082376869019936 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9227405998858302,0.0,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9423430651302864,-14.380596845803623,-1.0 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9451617937838576,31.47994973573887,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9460613794500649,-8.156601433393107,0.37765343639760085 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9566805872451147,32.799587819481886,-0.846246333095379 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9717536149314643,-0.024321622066782532,-0.09991983170723318 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9769939966736496,0.5350872175110535,-0.9999999999999994 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9782676085934665,0.1686505497915906,74.01521228760086 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-0.9852032586594026,-53.17240111594171,44.86113032488396 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.000245810666356,39.01306860009231,-0.01093501645276717 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.007488486184495,-50.13797673649008,100.0 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.011311673525768,1.5707963267948912,0.9640597645677675 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0218134375999453,90.36990370381092,-0.4273310678817068 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0236691032227987,-96.63685707893714,0.9999999999999942 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0260539668612512,0.0,2.710505431213761E-20 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0277500144443792,-0.2807932748732924,-0.03962799380645371 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0287534091662467,-32.46216269048543,0.9999999999999929 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0290288646569241,-55.625009111825335,1.0 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.070991544804884,-33.325725722805984,156.87781651843977 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0740997082080925,-79.17806909290393,0.0625527908203257 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.081418075583235,-15.142269021527,1.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0946294100487537,1.5707963267948966,-1.0000000083368263 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.0990683116782618,-51.24697172410466,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.103806364467451,-24.86315182898906,0.0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1091989841489176,44.017683554580366,-0.36208951311343873 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,0.1337678979522166,-1.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,1.5293670783427056,-1.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,1.5707963267948966,-3.349044734609504 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1102230246251565E-16,51.916287916096714,0 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1223687328369607,38.76921850726396,-0.06261110201697306 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.141604957332036,-1.7763568394002505E-15,0 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1479731746070319,-5.676411752335609,0.6437197201996374 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1524104130713535,51.69811800808833,1.0000000004858058 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1571131953926124,45.33061681354086,-1.0 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.1705682912557296,-54.97831155729982,0 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.204029405455087,-2.365527919043984,0.02199450490683315 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2130397761770206,-100.0,-0.999999999999998 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.214400366484955,-30.996141039564847,-0.46945735981776493 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2446214400089133,7.9115058061858115,-0.7432229519330471 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.248438085376137,-8.087756343628485,0.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2496086960156327,1.5707963267948966,-0.02024231542378399 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.2611215262449453,1.5707963267948966,80.01116939855373 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.298262407782158,-32.674830976906996,1.0 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3014336440610488,-1.5707963267948966,-1.0000350516284515 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3077720558870638,-1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3090544275004765,-14.785039564531331,61.581719969407885 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.312064679633243,-28.257192413725395,0.3622213569022813 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3137094138322558,76.4571112873655,-0.05723486531245675 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3142503505762259E-4,-39.51356110854264,-0.9999999999999999 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3207708435762489,-12.13260460618414,1.0 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3219384400908056,32.618484458388686,-1.0000000000000002 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.334628840388438,-100.0,-92.94952201652143 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3424081706833395,-8.228252641347837,0.06268350386016186 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3550601503795976,-58.74681364186389,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3565382855713262,-44.27457258968393,-0.9755987368960102 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3705046610145255,83.8698694529798,2.465190328815662E-32 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.3851860087938968,-88.98622339082087,76.79297662990606 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.388410624729755,-56.77738165724063,-0.06256068527804744 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.405891563287752,-19.524484486649055,-1.0 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4061545582913253,63.32577826972537,0.040415219440122184 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4078732030588466,-29.817368175670197,68.87652371113091 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4134759720937882,95.69280583726146,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4136729849231484,-5.382767760842585,-1.0 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4179807649333394,1.5707963267948966,-0.06256845590206747 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4260055396141174,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.428835329352091,-100.0,-0.06258291678587811 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4413535494992686,-1.5707963267948983,-0.011112628933554487 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.463522824692106,-14.463647131673,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4499772746735042,-2.3632803304284287,-0.1969441936740799 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4559439162769958,1.5707963267948966,-84.62281031696543 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.461228056972613,-32.53930426352508,0.9987043138846589 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4691747838104683,-12.060719095939602,0.8388023498978522 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4859234982195293,-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4903276375344694,-1.5707963267948966,-3.7547415196088903E-8 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.491072286804974,0.0,1.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.4955872585410783,-6.2805215804635175,1.0000055917121435 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,14.97111714404182,-7.271070757285384,-0.005182599808275512 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.502752859817267,-66.02143434001492,1.0 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.508985452541107,0.0,-0.06255368226479853 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.519363282994809,0.0,0.9883955573248897 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.519448984657568,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5201125092102363,45.02376238423632,96.50717151071663 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5226947587661745,-0.2434968396005324,61.64502109180794 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5259398029026967,75.84613956353247,-0.9995989014338851 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.529718960148761,32.42980400704187,0.05661613150428535 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.530976888902826,64.36855833890228,28.81256767798953 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark13(-1.000153396820259,-0.7510600368885855,-1.5708644802790779,2.710505431213761E-20 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5364765196928045,-29.15742685696354,-1.0 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5374243855716165,-24.808614471804923,-0.572458828376428 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.540342735827926,-49.162096467298625,-1.0 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5425083616613369,-94.17465496617213,0.0 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.54649719813748,-100.0,100.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5489433287415686,-100.0,0.003987202812335555 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5507157054534613,-2480.487742645588,0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5520277117484707,44.3910219064925,-99.21921454358862 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5582635761389318,-11.607679712638117,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5634131186880569,-93.25907223301638,-1.0 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5658439113128355,-1.4446384275089117,1.000000193422392 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570501964339395,0.042372079845685605,-0.49000333948697494 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267083471,20.86738645918769,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267947171,-100.0,1.0000000000003617 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794774,-45.46391308352994,25.980720639852628 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948664,-34.799991151289554,-1.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948697,0.0,-1.0 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.57079632679487,-14.243451644387989,-100.0 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948735,1.1336285188869653,-37.25233393517398 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794877,-52.25657966186545,-55.23033861587508 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948846,1.5707963267948966,2151.538963388343 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948877,26.040345856354904,-22.489933307450485 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948895,-100.0,0.9227136850730547 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,0.0,-0.34896249476882346 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-11.280178531180024,0.9999999999999988 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-1.5707963267948966,-0.5059892109326967 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,19.38426415693812,0.999999999999903 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,25.233340564862118,1.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-38.80219328365284,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-40.34742150231773,-0.3621530230544895 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-72.24987271706772,-77.89297423261621 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948912,-94.80536560579253,-1.0 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948928,95.66218670061048,-3.2005342185370482 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.570796326794893,-20.49720981585773,-0.9346546078577054 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-100.0,-100.0 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-100.0,-1.0000000007081777 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,12.864829318407406,1.0 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,13.59068633439415,-1.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,1.5707963267948966,-54.53711688461946 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,2441.903549791438,0 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-26.023751362977503,-0.6575306101084692 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-29.880371880400077,0.03027732881714185 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-33.10742843711924,1.0 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-39.656199548285606,-2090.7886621900902 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-72.84188459568988,5.421010862427522E-20 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-74.4018542551346,0.32802341470804475 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948948,-99.92341372768837,-1.0 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948952,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948957,-1.650210273889392,-0.8630610612650356 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,1.5707963267948983,-51.499879062189585 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948961,38.87745625709678,2.926047721682624E-98 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,0,0 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,0.0,-0.02104780184731969 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-15.833880886254006,38.6640114069561 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.5707963267948963,-70.9320319889764,2.2892199284607484 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.7763568394002505E-15,-1.5707963267948966,-47.69735997195255 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.7763568394002505E-15,37.770389908302,-1.0 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-1.7763568394002505E-15,-51.279684828571526,-100.0 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,2.773727435510956,0.0,0 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-3.552713678800501E-15,-100.0,0 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-7.105427357601002E-15,-42.309052562933886,-100.0 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-8.881784197001252E-16,-96.37133563150886,-62.386073933490025 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark13(-100.0,-9.159975460718119E-4,0.31116814607835264,-81.93736085023833 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark13(-100.18768279781332,14.443352822895477,0.6604832226498308,0.0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark13(-10.05950886763817,-7.105427357601002E-15,-6.188928412551537,1.0 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark13(-100.59540595074182,-0.6212292810320683,32.75489658974311,-35.548999326782976 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark13(-100.66120496102732,-0.7701007724042341,76.04786000948626,-1.0 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark13(-100.89685032203136,-0.23182072950915578,1.5707963267948912,0 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark13(-1.0,-0.9131470155738945,0,0 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark13(-100.9353789315127,-0.07515290248405293,-1.5707963267948983,-2177.335977361665 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark13(-10.096480270191083,-0.5549683409887773,-1.5707963267948966,90.48794650676592 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark13(-1.0101148789287084,-1.011063270601155,-41.858100145833085,0.01683851302196144 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark13(-101.05250996882576,-1.376117089144342,0.0,-1.0 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark13(-101.1097623444994,0.9607670536787881,0.0,0 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark13(-1.0112371289959157,-0.8325390169298613,1.5707963267948966,22.466907324121266 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark13(1.0,-1.1331952219870876,0,0 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark13(-10.16686888793789,-8.881784197001252E-16,1.5707963267948983,70.51268320294652 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark13(-10.270310487427679,-4.440892098500626E-16,32.77223183273819,-1.0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark13(-1.0281389198033182,-0.008433459830260665,-1.5707963267948966,11.972417345531028 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark13(-1.0300851509095323,-0.3029727932042457,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark13(-10.304974345202808,-0.5509777898761425,44.43029853670653,-1.0 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark13(-10.400934547029308,-0.9235979808735237,-97.84418783894829,-0.6228439617434809 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark13(-10.40136096628899,-1.4501385417363302,-44.950662337147975,-0.030113581242806622 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark13(-10.450150064015013,-0.5900966565385746,1.669441426105615,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark13(-10.45299979693302,-0.02147112777401039,1.5707963267948966,10.43740920559915 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark13(-105.34518798601721,-1.464452953109418,1.5707963267948966,-2077.7582973270837 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark13(-10.57575162297118,-0.786405209583312,-70.158049017873,0 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark13(-10.689692999065,-1.4496710246638174,31.780923208624895,-48.32231030130726 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark13(-106.94054149735138,-2.220446049250313E-16,0.0,-2209.0897413720886 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark13(-10.73231806378175,-1.458863875020436,95.8889830302967,-100.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark13(-10.736286284732467,-0.7873793442680518,-45.908146691428875,55.560853122407536 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark13(-1.0737199987135462,-1.3799683416207804,44.77660523630797,-56.39364831932308 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark13(-107.63015302716038,-0.891430807983113,-1.5707963267948983,45.83687309297867 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark13(-10.807801183882733,-1.3517170690451397,-45.531311387704264,-1.0 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark13(-10.817058849337812,-0.12152353958681772,-46.06296172763642,8.74510818408584 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark13(-10.885139151222745,-0.9730181137787539,-32.31552052141843,-56.470377293773154 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark13(-108.90338091616772,-0.04050246929205148,-26.046598078638826,1.0000000000000036 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark13(-1.0892370335276587,-0.05041976260977349,-39.86058910039969,-1.0 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark13(-1.093263979793174,-1.048537581348185,-0.8032733121710436,0.9381782180897229 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark13(-10.937466818324708,-1.2830754605087125,0.5128101129791032,-3.8355333718084665 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark13(-10.941065803355826,-1.4496895859560244,0,0 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark13(-10.962918731600169,-0.7762161513918695,1.1904917094855583,-0.9977697791963809 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark13(-1.0984988814642251,-1.5534852537843598,0.0,1.0000000264253974 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark13(-10.992869356235968,-0.347513215778435,63.02752217802536,-1.0 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark13(-11.042229161122464,-1.5707963267948963,-67.19247344681392,0.5697263182700444 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark13(-11.063176515157895,0.19201872918425245,-2.631289782447778,186.13805077285798 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark13(-11.13085143204809,-0.2717597058471064,-66.55951361502063,-1.0 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark13(-11.131136571836976,-1.5707963267948948,-53.19776408745608,-0.6851166378866946 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark13(-11.141060551142367,-1.0511194909510941,-95.40503541866752,-0.03435084101465723 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark13(-1.1152376004047795,-1.1705645957402027,57.68904339844411,1.0 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark13(-11.158859757840192,-1.5019097721669643,95.44697591323245,-81.47767185476005 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark13(-112.24627329988465,-1.3498308666987158,26.731517526981563,-1.0 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark13(-11.297479216377639,-0.9254823940767096,31.787400392703482,-1.0 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark13(-113.08785339641588,-0.029543352075845325,-0.386202744568548,0.0 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark13(-113.21170556671176,-0.3692861070864162,-1.2280211665513536,2019.1428764929738 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark13(-11.37112296219862,-1.009021678284262,-39.2374084361497,94.58312682660232 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark13(-11.400253087252137,-3.1509065016364E-4,-78.22201383091124,0.8890283241201417 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark13(-11.40136030472108,-1.570796326794877,-2.7660950409845384,-1.0 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark13(-11.407287834570965,-0.19495499150256135,14.432849629399065,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark13(-1.1418064607049963,-0.32585541856996,-37.77443357877005,1.0 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark13(-114.4450198315477,-1.5707963267948948,0.0,2259.998650341343 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark13(-11.475497809981713,-0.042367540892413125,-75.00756463368585,55.15468884419714 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark13(-11.528246810447413,-0.7444355090420604,0.0,-0.05438856263991706 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark13(-11.53906624534636,-1.177107988661337,31.77627711210779,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark13(-1.1595698450158463,-1.3995713957626212,-34.18923072465409,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark13(-1.161353606837344,-1.5707963267948963,94.38984389586516,32.16973413053107 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark13(-11.619964275153546,-0.01091719674769635,-49.20423071424888,0.025626955122291406 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark13(-116.2058533617261,-0.46597231298252706,-95.37624640912802,1.0 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark13(-1.1635249441437168,-0.38372449056266056,-24.646468477296242,-1.232595164407831E-32 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark13(-11.653522591071429,-1.3005974613839681,-78.79074602340668,0.0 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark13(-116.56968489260936,-0.1533314530685015,15.396087852145882,-438.1097827714216 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark13(-116.94481919988269,-1.035363775236793,1.5032180818013996,0.0 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark13(-11.71750131097329,-1.5707963267948912,31.96184503512461,0 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark13(-11.768128248595577,-0.7700350867068568,32.259837324762586,0.1967332721658668 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark13(-11.8013377976819,-0.013690024805563814,-68.69266792277654,0.47834635118705265 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark13(-11.80698461703293,-0.19694698281318423,-37.53798589872679,0.943159058440481 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark13(-1.184639699541271,-0.2769874709291784,-83.7470510854202,1.0 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark13(-11.8922252109693,-1.5707963267948912,-9.5480996194321,19.629374793543086 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark13(-11.906056133225341,-1.4615914659725746,95.48541802397285,-0.7724453268839682 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark13(-11.958650928523156,-1.3835539751604387,-57.006281267458704,20.428842150424714 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark13(-119.65423229444052,-0.16571537389759255,1.354210261309173,2023.8521542450028 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark13(-11.975816314848583,-0.704174710204327,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark13(-12.003996426745362,-0.6523766425550463,1.5707963267948966,-94.81720040050979 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark13(-120.42910375425889,-0.139393434084371,-86.88894738516211,50.141549798216715 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark13(-12.048545042607898,-0.35482275579940437,-29.913924843482228,-0.04224629319681661 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark13(-120.48673692891694,-0.7395741509955784,-45.40406589035895,1.0 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark13(-1.2080325499618685,-0.3790382683185442,-65.80301143411884,0.0 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark13(-12.100261583981876,-1.267507506675507,1.2539424052374066,0 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark13(-12.103197695439826,-1.5707963267948957,-24.46886253151487,55.125406392490696 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark13(-121.42915646559578,-1.4210854715202004E-14,31.709688501184218,-2274.683361450213 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark13(-12.171248007938003,-1.3624461427356274,1.5707963267948966,-0.808744329911596 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark13(-1.2188008337847194,-0.4965396824800961,-85.75989489841751,0.25504623344194943 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark13(-12.212986324396425,-0.6822276776109271,1.5707963267948966,0.7251475207205829 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark13(-123.21114406829678,-1.273247610174799,1.405272085508031,1.0015192909825872 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark13(-12.360331405114295,-1.5707963267948912,-5.28202474546256,51.34631414516275 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark13(-12.368447796721568,-1.0817998846307515,0.0,-1.0 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark13(-12.382573330620534,-1.1102230246251565E-16,1.4489929652526543,-1805.6762577649079 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark13(-1.242129335411306,-0.693468935215698,-35.85767974194468,-45.33865817823091 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark13(-124.96397282386296,-1.4121313053411098,-1.1314977973813325,84.39609145352608 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark13(-125.38457795922677,-1.5337520365556705,7.707488049455056,2.710505431213761E-20 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark13(-12.609084373171747,-7.105427357601002E-15,-58.300788809075804,-42.21678779922808 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark13(-12.616210027493878,-1.5707963267948957,-87.01963349965645,2308.3803816047603 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark13(-12.66352796478266,-1.0602823568759474,-53.051530200410255,-1.0 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark13(-126.69864500191184,-0.10990082747499426,1.5707963267948983,1500.0505407119088 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark13(-12.673688545361554,-0.8260075714970977,-96.40461080709946,-0.9991319611925636 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark13(-12.715801242501385,-1.291499187101918,31.441835569812675,-1.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark13(-1.2729945734822792,-1.02659678051109,88.35299416835011,-0.7399860124279695 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark13(-1.2776202770421463,-1.42683432000515,-16.060446688631686,74.65684027219018 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark13(-128.3946475459578,-0.2123464582178205,-174.1890239036454,-1.0029703835968975 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark13(-12.8639861195355,-1.5653339903921513,0.7316799003415363,1.0 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark13(-12.86426564546814,-1.5703346573626664,-60.74170305121049,0.3700185816734356 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark13(-12.971871255973127,-0.7568408882086439,-100.82357356626571,-0.8091863672400024 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark13(-1.3004660973509992,-1.5465653512188433,19.110143226830143,6.70919341333648E-4 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark13(-130.16226749728844,-0.7839402449253594,0.008913321320713763,66.09409805304769 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark13(-13.059979953402461,-0.5976516741455536,0.0,0 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark13(-130.78108596106648,-1.5707963267948961,-1.5707963267948963,-2027.7246044940443 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark13(-13.08019088911669,-1.5707963267948912,-33.8145960465428,1.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark13(-1.3099083683914015,-1.2710490159476948,-18.385696795424465,-0.9549678232505281 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark13(-13.10206478465841,-1.0741852534872693,-1.5707963267948983,0.1369864383369901 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark13(-131.32803434216612,-0.7160314048406917,52.6023835187108,-0.04762878350507371 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark13(-13.133462639586394,-0.09746202707844065,-2.6859305262333684,-78.27543213680515 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark13(-1.3212349476305145,-0.47501170484917304,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark13(-13.223017204556156,-0.7976970989910627,1.5707963267948961,0.9940751268669676 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark13(-13.224831541388678,-1.5707963267948912,-4.221106425006575,-1.0 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark13(-13.270040966684434,-0.2887298190323975,-95.32652213962885,-0.0625611288950317 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark13(-13.271476927350587,-0.1507727994613915,45.06097749373569,0 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark13(-1.327701329080881,-0.5346584240518097,-27.29309431535694,-6.600957121936709 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark13(-132.8593786586941,-1.1274518222916043,-110.08634762138193,-0.35339465612523213 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark13(-132.9283744680152,2.517917514400009,1.5707963267948966,243.62643030443226 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark13(-1.329428449780238,-0.014735755113370493,0.0,-0.026532900133872717 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark13(-133.25235790199457,-1.5707963267948912,-15.512604946814196,2369.1163897063466 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark13(-13.373586970000572,-0.007675970183587965,-67.81123206391345,-0.014326781726799893 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark13(-13.375459994271136,-1.453147362188643,0.35750686182702573,1.0 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark13(-13.414812145289474,-0.3746868280457756,-0.673198621808656,-18.651867039439097 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark13(-13.431684861943708,-0.24858611553958712,-67.34823552849357,-1.0 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark13(-13.444159821125167,-0.7313494309767772,-0.6797964555725057,1.0 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark13(-13.497225640891555,-1.4597889192508708,-14.442195851820664,0 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark13(-13.51761909791502,-1.374492716997544,-37.886329236170276,-48.9527824385806 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark13(-13.542220146011841,-1.0667060799321952,0.5415319871871492,-3.871302707352304E-15 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark13(-13.629792695957013,-1.480054789212483,-1.1561257309295097,24.702922375894367 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark13(-13.654231176718017,-1.5707963267948963,-1.5707963267948966,-89.75664343958474 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark13(-136.72101100404495,-1.1042378430299646,-88.17639647603873,-1812.0949370093576 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark13(-13.698794962892947,-0.33582381099683456,75.75122399672023,-1.0 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark13(-13.705170986031664,-1.5439962578665303,1.5407439555097887E-33,-0.3697171370842938 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark13(-13.713532021880496,-1.1792927619189688,70.72363251197044,0 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark13(-13.720292736845106,-1.1274378178520903,-0.8048013952103547,-0.0471946287633494 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark13(-1.3731884076237313,-0.6527654606002222,-93.0706990164199,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark13(-1.3751659690028042,-0.033138025849835245,0.04506168309870704,97.34478440248691 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark13(-13.762291448826772,-0.16164886550226581,-26.051165518438665,0.2894802057717347 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark13(-13.800269522421365,-1.5707963267948948,84.24078342535307,2245.5211684154488 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark13(-13.815364231754494,-0.44764201924063496,-38.82081384169307,-25.10772038469196 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark13(-13.81616131672801,-0.05155193054233975,-19.831813159819475,1933.6503029803164 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark13(-13.82248768704632,-0.08328531863163513,-0.019517027001858152,0 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark13(-13.846269633467635,-1.3612638538112105,0.0,0.9999999999999929 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark13(-13.938744231444915,-0.8487334368766397,-1.5707963267948966,1936.6444266224942 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark13(-139.47423827742227,-1.2771330746436445,83.2360405680816,7.888609052210118E-31 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark13(-13.957064908616385,-0.9029281529811025,-53.88500356360101,0.17780232745987679 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark13(-140.1079024422688,-0.04114440450510978,1.5707963267948966,0 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark13(-14.07181366716847,-0.7861297716754915,-76.12666930070439,11.135617357363069 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark13(-14.078757503020569,-0.3111274748696893,-114.30605604025739,-1.0 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark13(-14.09854252679026,-0.2972252330352861,-7.501397315705826,1.0 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark13(-14.121931864185571,-8.881784197001252E-16,1.0485842717723957,-18.7516469421492 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark13(-14.170268116801935,-2.6425730498576095E-17,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark13(-14.234984707664026,-1.5707963267948963,0.11067695725951668,-0.06255295080127947 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark13(-14.25858541139192,-1.146987648272318E-14,-5.608759933836782,-1.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark13(-14.316310151536797,-0.0030018455393452763,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark13(-143.3031215901842,-0.011061862872745833,-97.61600318496654,1.0003048226641844 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark13(-143.61324037683153,-1.4946450859316476,32.5658413484065,100.0 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark13(-1.4380797628228041,-1.2747081346294862,-45.3942791960594,-1.0 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark13(-14.384182870090497,-0.28732454205876906,0.0,-1.0 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark13(-14.46783374998435,-1.1444700806435035,-12.057552583332885,17.878290027925317 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark13(-1.4483737359681912,-8.881784197001252E-16,-48.11609921534852,-1692.2273798920885 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark13(-1.4585670586870392,-1.570796326794896,-2.875304057149336,-0.4425330716218904 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark13(-14.586687270284942,-0.09313775552070491,-48.92950178201214,1.0 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark13(-1.4616273898550338,-0.1030322360968359,71.71626761800036,-1.0000000014716597 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark13(-14.629129422863413,-1.5707963267948957,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark13(-14.647021138816399,-0.5851733764210962,37.798802473380334,-0.3443045422986214 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark13(-14.716060816636027,-1.5702444717826087,-1.5707963267948966,-1.0000000000000002 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark13(-147.60325148112483,14.47986892893762,0.48108426530134635,-0.5486152724318023 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark13(-14.775219413620817,-1.5707963267948948,-3.818413092662087,-34.74167551417983 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark13(-14.776871221130925,-0.703734384349695,-1.5707963267948963,1.000000000000007 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark13(-14.787694868762445,-0.006177360729978697,-10.057482830396856,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark13(-14.854599324999787,-0.2920918336955982,-38.144083446499785,33.3954872751615 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark13(-14.856987935419937,-0.6195066050937044,-53.81988163972357,0.4597972013151974 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark13(-148.8573056933787,-0.37068794933336546,-47.119317460714036,-1.0 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark13(-14.925059058274375,-1.5473524010643318,1.5707963267948966,-11.133399590671672 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark13(-1.4925878559270194,-0.470335415537974,62.89303305408298,-0.9399332995285942 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark13(-149.41265364627924,-0.6487587397338154,-0.35181240206575526,-49.47439310246831 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark13(-1.494466029827223,-1.1662426684384182,-68.91241011524323,-1.0 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark13(-149.77198722947819,-0.2605755703220234,-89.42633183724513,2106.2680794396992 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark13(-149.94432024215786,-1.0220709408606474,-94.99845659112647,-2170.6447281797023 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark13(-15.091043825689127,-0.5046296065871507,-52.335051415411456,-0.016420521902094976 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark13(-15.115972817989553,-1.213718541262278,-35.29917301454484,-0.9999999999999999 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark13(-15.226579993871404,-0.04064628221754358,92.67057940908325,0 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark13(-15.25849256228092,-0.06919250873899149,-98.34476662541812,-1.0 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark13(-15.317904484935127,-0.7666492104329308,-88.10705925576633,-0.31487543122705297 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark13(-15.323676332861336,-0.4692268766260216,1.2136192987083576,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark13(-15.330700400829656,-1.2810059532554048,19.551386050366006,-1.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark13(-154.1968284823804,-0.7709467811670404,-11.731816924636016,2205.7733303989785 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark13(-154.29615182598434,-0.3112036131298177,0.0,-2151.194667829158 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark13(-15.438056007493163,-1.7763568394002505E-15,0.0,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark13(-15.500135632346243,-0.186567263194706,-0.29060112252790304,0.8508682046170469 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark13(-15.551885240982548,-0.3670672803535784,-46.447482614895236,-1.0 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark13(-15.599890224010757,-1.5707963267948963,-98.53449788413984,0.9999999999999991 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark13(-15.633409407312461,-1.497991441492601,-100.0,-0.19014030436676255 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark13(-1.5652065192348914,-0.04815356637119336,-0.6829805059703751,-54.902406943323314 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark13(-15.659465340357166,-0.46767512117686616,0.3868843323177984,1.9066560082940072 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark13(-15.691006103961122,-1.5707963267948957,-23.00046755845777,-1.0000887586158964 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark13(-15.749403107615962,-1.1102230246251565E-16,1.1102230246251565E-16,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark13(-15.758045710365243,-3.552713678800501E-15,-90.43551133887023,-0.06255295864578496 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark13(-15.772877707042479,-8.881784197001252E-16,-18.589264484811064,0.7726333740716949 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark13(-15.781120385753411,-0.5859379833119078,-141.82470910101688,67.8666798348224 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark13(-158.1969508178158,-1.340405987153258,26.20375677546747,2149.4292270603637 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark13(-15.828124832494304,-1.1970110778832683,69.94782332647732,-25.470222681901433 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark13(-15.843821757780038,-0.6538353382763091,-80.19379863450327,-100.0 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark13(-15.849030656067393,-1.0113483862665187,-0.006505027576287237,-59.97687892788524 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark13(-1.5870035519342043,-1.5707963267948948,39.09161744726626,0.9933102942022504 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark13(-15.880185826030136,-0.3150100909888001,0.09572142589768856,8.673617379884035E-19 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark13(-15.891204488068738,-0.8826447981531793,72.38965130244901,0 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark13(-15.947015827439628,-1.5707963267948883,-0.017018542819365122,-0.6007778503446279 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark13(-15.967794448765737,-0.9563400006924754,-70.78779439776733,2234.23433348187 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark13(-15.986259837514542,-3.0141360326213513E-15,-1.5707963267948966,-38.79425567306471 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark13(-1.6103624066427593,-0.0016969873146557013,52.893584551195886,-0.040126053923799504 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark13(-16.122010288236908,-0.9693013778338413,-42.44786899618723,-1.0 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark13(-16.133583140197956,-0.0011420164674237052,0.4339949327224708,-1.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark13(-161.53300430536575,-0.5981328224529951,-60.082335991019804,2214.532535301936 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark13(-16.18624499627948,-1.1382520450748224,-73.3315447220722,1.0842021724855044E-19 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark13(-16.189078444370104,-0.42169917424709524,19.394864048634474,57.78729976974452 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark13(-16.197839115803887,-1.2926104576177921,-35.461963847371734,0.35076245234656867 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark13(-1.6201023623914095,-0.23443087377301733,1.5707963267948983,-69.60985980565687 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark13(-162.35464553275398,-0.1486439958334292,-19.360252197173427,55.598594691610316 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark13(-16.28055807230593,-0.023938181674022223,-0.09907872508615334,1.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark13(-16.362597442432794,-0.6316635219241681,88.15026062102254,-9.23121758697583 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark13(-1.6368996113478715,-1.3835779196196938,0.0,-1.0 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark13(-1.6387870878063897,-0.19929801908018627,-22.029212901692134,2209.538450460927 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark13(-16.410195458743154,-0.6846453629272001,0.0,-60.67017032687243 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark13(-16.4365636936744,-1.3963906474562737,-60.991858971353395,-1.0 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark13(-16.46159445549517,-0.06842125450208192,-88.35172200479288,-1.0000000000000002 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark13(-16.48172643233776,-0.5114672857760952,-42.51119000400399,-54.486669937822406 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark13(-1.6516071811337252,-0.8182438897776305,1.5518903667210586,0.36505245118771884 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark13(-16.539134392792334,-1.4231467286293054,-16.243583099216536,23.532787523972786 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark13(-16.543506126119382,-0.13436243778216106,1.5707963267948983,1.0570001202820876 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark13(-16.57769711762364,-1.5399852886743226,-0.3152468656236253,51.66758852700141 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark13(-16.601410431539282,-1.4325157591749793,-33.66697778433794,1.0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark13(-16.605133779345486,-0.026924717447248593,-1.5707963267948966,0.5102104283939709 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark13(-16.617820876526004,-1.3918749740442158,-4.399480794999314,0 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark13(-16.652992668023792,-1.5588794679457887,0.0,-0.5821879012347647 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark13(-16.719716457560295,-1.7763568394002505E-15,0,0 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark13(-16.751618664433387,-0.8098866646147823,-10.370312923212857,1.0 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark13(-16.844809854032018,-1.488247454925108,-70.65361950798629,1.0 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark13(-16.847176093880847,-0.582800034331565,82.8205441795368,-51.77803114672492 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark13(-169.1282292808053,-0.10673259717774997,-42.87080844648259,-82.90898367809743 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark13(-16.920553318062208,-0.9306610667709255,-25.483353470951755,-0.4361835208503021 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark13(-16.9840275435753,-0.10737182727631439,-20.974145679579703,0.09897429350576026 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark13(-16.99668012430604,-1.5707963267948948,-26.14423300802264,96.1266765790706 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark13(-17.0323852224367,-0.4269800051393429,0.0,-0.9802761693575975 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark13(-17.07168415005896,-1.5707963267948963,1.5707963267948966,29.379063535970534 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark13(-17.1055042517406,-1.1465477418384555,-1.3877787807814457E-17,1.0 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark13(-17.112041251470707,-0.5274100031744648,0.0,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark13(-17.165669614931826,-1.1063641008224554,-32.74967233812734,2133.0281201524826 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark13(-17.184920986331058,-0.5076034442396145,72.05625834330628,-165.2512163138275 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark13(-17.19525473538114,-0.11013262762869418,-95.3478176382418,1.0 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark13(-17.20654703573597,-1.1357196872784114,57.49454259492788,-0.0212736515998882 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark13(-17.220472955566542,-1.566814441434901,-10.964237200175315,-1.0 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark13(-17.243520412355785,-0.5416909754691712,-1.5707963267948966,-0.011770668067646956 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark13(-17.253221508060104,-1.5652053458307833,-21.87931921945077,-0.061967103576878124 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark13(-17.254663099369964,-0.3666994898537017,0.0,0 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark13(-1.728682961306312,-1.131028807077066,-8.294756205832414,-0.9115252403287697 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark13(-17.32332784177663,-0.6494862270571351,1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark13(-17.33267560046347,-0.6153246047347527,-49.30936410799337,7.105427357601002E-15 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark13(-17.390652065948647,-2.220446049250313E-16,1.5707963267948966,-0.6985958949569906 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark13(-1.743359825263667,-1.5707963267948912,34.37578712436802,0 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark13(-17.451853281763718,-1.114391769496183E-16,-44.54409171071267,1.0 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark13(-17.47037043019435,-0.15322071299499385,1.5707963267946923,7.440107504041492 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark13(-17.47198384808752,-1.5707963267948912,-14.570298867642776,-1.0 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark13(-17.512541414073098,-1.5707963267948912,0.0,-0.059060280446983596 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark13(-17.528395079644678,-0.6372352431337956,-2.681844495028422,1.0 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark13(-17.568481025761503,-0.26586877035895196,-16.590417713552398,0.9305848083717275 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark13(-17.664543131922322,-0.9450260242129828,0.0,-1.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark13(-17.690604329535763,-0.6858690595723379,-1.5707963267948948,-0.8680487475475338 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark13(-1.770073444398959,-1.5707963267948948,-60.34802765956757,-99.60955427520237 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark13(-17.72045657550214,-0.4182382753293612,0.0,1.0 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark13(-17.904606704969463,-1.2237508518769575,-58.97804443220911,0.7086247794373874 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark13(-17.95990625137602,-0.34892018968907673,45.52480199360289,0.759356466331009 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark13(-18.014809584869383,-1.5707963267948877,-0.40209574082404154,-26.70524750283272 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark13(-18.017405752003032,-0.8618062081513372,-49.15866605089841,-4.3368086899420177E-19 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark13(-18.034833386253737,-0.3137477082011777,0.7668898974978773,0.39458390383825015 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark13(-18.065112613165347,-0.46485478327846796,45.49466532729403,-0.05321525940581073 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark13(-18.07682604877416,-0.4299676734597857,-53.781924018213935,-0.2289458951121438 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark13(-180.85033757589514,-0.21584274856866403,38.024662903634834,62.79218568838755 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark13(-18.114620315024098,-0.9236369633374814,0.0,88.84806291365777 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark13(-18.160033256822704,-1.0214546155590407,1.5707963267948966,0.8231978419979737 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark13(-1.8177300582581757,-1.5512598916002585,-11.0161131137436,1.5048720331294885E-15 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark13(-18.178597463258892,-0.7934197672756932,-20.866028442293864,-31.848993696624326 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark13(-182.59465354255286,-0.03152224245444319,-74.76443112473514,1946.2172919704158 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark13(-18.26099454600292,-1.5376360288479602,-95.39374227420811,0.006230576556476214 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark13(-18.275645511221768,-0.09659162277986716,-1.5707963267948966,59.79510097850721 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark13(-183.17909497221896,-1.4480144655702105,0.0,18.768305239466514 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark13(-18.323977237265225,-0.9277536235669499,-65.12676242596825,-1.0000161958537157 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark13(-18.32956680172107,-1.5707963267948912,37.825981095842344,-0.33145073238589595 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark13(-18.360748792769943,-0.025720292584524462,1.5707963267948966,-44.610350001545 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark13(-18.379029369329896,-0.6127235156217737,-9.164738910826898,1.0 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark13(-18.38939617003996,-0.5132356006588185,1.5707963267948983,53.74238033752948 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark13(-18.423253037618586,-1.5707963267948948,0.45753382471728726,-0.9999999999999949 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark13(-18.464810098589876,-1.1564124431733243,-6.707198760774816,-0.973599780329056 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark13(-18.466577955963523,-1.4802260242241538,-0.7536742560772487,-100.0 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark13(-18.641560514246862,-0.42466907656340425,-45.43706230526996,99.33292860478466 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark13(-18.659894119116437,-0.25697023770821714,0.1565439201430835,0.0 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark13(-18.70134149782022,-0.11023842416596087,-5.713016225900096,2.514920250632306E-17 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark13(-18.761919935955397,-0.7045103547183663,-68.0573429655975,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark13(-1.8886132321003597,-0.10867285543986878,88.35220024104902,2063.1494230889234 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark13(-18.940152844023217,-0.013326848317242942,0.0,0 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark13(-18.973966834337446,-0.8002030539369641,-1.2793368694696023,-11.681339904807075 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark13(-18.975913863899677,-0.0013777760501995108,-13.372257636483944,0.3716099519890039 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark13(-19.03271422229903,-0.008094514881713097,-7.785077520414397,1.0000000000000142 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark13(-19.039295916285823,-0.9283699980097121,-30.931363996699332,-1.0 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark13(-19.039375326899805,-0.8018153158393961,-1.5698972721845381,9.741631075125175 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark13(-19.049660660101225,-0.23073993218195185,-84.67292869029635,0.1856193905399589 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark13(-19.111828284256546,-0.2870867186040904,-86.0937919710729,31.11481204828155 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark13(-19.14754192575393,-7.105427357601002E-15,-83.58418810641692,99.88683226871336 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark13(-19.16627990758982,-0.9008235797342494,0.0,59.15136426364505 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark13(-19.25615791624103,-0.2424466829146168,-18.31298578278342,-51.97558645314302 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark13(-19.26868188954916,-1.395497943886697,75.96700815011712,0.05655932515064292 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark13(-19.306516552219758,-1.0804157211923773,-100.56131628631422,86.81388640954853 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark13(-193.51139342014412,-1.1102230246251565E-16,1.5707963267948966,-1421.375921829955 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark13(-19.360059314721585,-1.3075873760396315,-1.5639085322919781,1.0 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark13(-19.368518726851686,-0.47844500432286796,-100.0,1.0 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark13(-19.4028104526476,-8.881784197001252E-16,1.5707963267948966,-30.548073153899537 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark13(-19.40591619022244,-0.07082075094619486,1.267034628470805E-15,-0.7488031523191084 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark13(-19.409683307478332,-0.5749894540447416,-1.5707963267948963,44.91999220928213 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark13(-19.62541122681565,-0.8080899532774877,-1.5707963267948966,76.78446046313961 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark13(-1.9627869154883977,-0.23546098687317119,76.82150319393969,1.0 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark13(-19.639192223116858,-1.4861597905354198,-1.5707963267948966,0.3213999487728918 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark13(-19.750648104638344,-1.5535712999588258,-100.0,100.0 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark13(-1.9754182748329612,-0.8753012835704652,-26.72957431521074,-1.0 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark13(-19.977654224709564,-3.4429025879929978E-15,1.5707963267948966,-5.70799186932915E-14 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark13(-20.07407203431339,-1.5195487840385506,-21.266348923252593,-1.0 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark13(-20.12148096116432,-0.19321613448328737,-1.5707963267948966,-0.5492593925052489 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark13(-20.149829351916093,-0.6870375905001529,-67.10341606262358,23.176222382634396 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark13(-2.020005120420988,-1.2820234166672662,0.0,0.6379490604059999 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark13(-20.272863154352308,-0.6504770315559062,-53.743626004451144,-0.03819455958827689 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark13(-20.297715371193732,-1.5707963267948954,-4.692576616326374,1.0 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark13(-20.32814328427156,-1.2107858552916841,63.33563275947027,0.4354826759390103 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark13(-20.3706396076858,-1.5707963267948912,64.35061398234365,-2118.9091777049275 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark13(-20.469488051224616,-1.5707963267948912,-71.49167589207684,0 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark13(-20.47477955332281,-0.6046367584768841,32.34785866726446,0.9999999999999982 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark13(-20.483411963211392,-0.04880201319293309,-1.5707963267948963,57.146565755862994 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark13(-20.515697446915702,-1.5063228952238332,-32.48861389056574,0.0 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark13(-20.529707643022462,-1.546158315106894,83.1075964905449,0.0 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark13(-20.574276954493058,-0.9396999916522423,9.190819757501664,-0.664813195800037 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark13(-2.065004462743949,-0.6636928116604497,-11.976320025622007,-1.0000068487252025 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark13(-20.68014607154172,-0.9470631589167801,-94.64488986174375,48.877750491545655 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark13(-20.682120727392146,-0.030306737461709782,1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark13(-20.72007724163621,-1.5707963267948948,21.08701939799488,-0.6524470772329771 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark13(-20.731907469493105,-1.4175413788162046,1.5707963267948966,-0.9814219771429743 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark13(-2.0795454306203283,-0.11503504788327332,-45.460605297963895,-18.266633168124052 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark13(-20.817306786254818,-1.4884201363241252,0.0,0.7706433612056536 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark13(-20.891348988156953,-0.7009280606890798,0.0,-0.9235497970760935 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark13(-20.94416296738312,-0.16693343022814128,82.79671392399997,-29.53719146806202 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark13(-20.980290909868437,-0.034039980712337395,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark13(-21.035083318320744,-0.5719593216081673,-1.5707963267948948,0.17112948154093544 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark13(-21.065921778888793,-0.9090368598305589,-115.4947071571275,-91.84880710566327 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark13(-21.111401013018224,-0.882752465676377,-15.6576474258149,0.9999999999999964 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark13(-21.13915872561406,-0.15935844710754563,14.412025728773013,0 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark13(-21.203750276912658,-1.2297125680667278,-31.25022599369361,43.83858287311418 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark13(-21.22245076445408,-0.43505023996316994,-1.5707963267948983,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark13(-21.26871955433191,-1.2131904413737686,-19.355851236215692,0.9930568316238346 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark13(-21.274205442009297,-1.143376114778613,-38.68951433482396,1.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark13(-21.2855077734529,-1.5707963267948912,-15.099529761005904,0.011370292012972445 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark13(-21.3322750835864,-1.5707963267948961,27.660876243329344,-90.74567912659367 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark13(-21.35895133480051,-0.6647351843619533,-15.910859564921509,89.41013994542267 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark13(-21.40992932300207,-0.4012595747976046,0.0,0.8971777685641863 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark13(-21.533897539267173,-1.5505278482554954,82.02835270439792,50.72569703161025 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark13(-21.571703042006803,-1.5707963267948912,-64.89727685376775,94.15526414136454 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark13(-21.594246517550744,-1.7763568394002505E-15,44.14188027704165,0.0 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark13(-21.610347696791894,-0.9716061271300558,26.380083080911074,0.37604835200454145 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark13(-2.1655061823977193,-0.14473783372173799,-95.8510653513475,1.0 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark13(-21.681028168422614,-0.16339804140169828,-136.3526320519697,2158.146190740195 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark13(-21.696289913565693,-1.40129703342691,31.762384164078895,1.0 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark13(-21.696809147449947,-1.4974814516097208,77.93323612693457,-17.02128446967111 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark13(-21.72500956008932,-0.09128442158327142,0.06620145877417491,-47.12048618302627 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark13(-21.78443903936691,-1.5707963267948957,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark13(-21.79505956582892,-0.6346515626853186,-59.907723454096605,-0.06256862638935051 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark13(-21.80208366810444,-1.5707963267948912,0.0,46.51130008978174 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark13(-2.183448660497694,-0.4209570299122898,0.0,1.6217683996951477 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark13(-21.843291818115052,-0.5011398127152921,-33.665467416199064,0.01677039220840814 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark13(-21.84350536085236,-1.037356191394055,-0.12578235387002756,0.009055502713977974 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark13(-21.893029913962508,-1.5707963267948948,-53.93772257588134,0.3520600735816395 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark13(-21.954025269611662,-1.2206232990196222,-59.0590062387386,12.857983923731855 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark13(-21.959321839567167,-1.5348169413548234,-36.13207409540341,36.35360196736712 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark13(-21.99366301164946,-0.6748072537047216,-1.6467081780252641,-0.02811376385402469 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark13(-22.00249055303577,-1.5707963267948912,-10.621817316719543,-97.43151032379657 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark13(-22.012097613497883,-0.3810479810696544,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark13(-22.017225984667835,-0.12452288587901705,-8.881784197001252E-16,0.5142160935133945 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark13(-22.24270788622917,-1.0857005443890415,-29.165701414176468,0.15705341299084874 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark13(-22.290337656956165,-0.11459312809926597,-53.97236446096324,0.047343827217963375 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark13(-22.297557380768872,-1.4561987579099056,-51.70442027402153,-1.0 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark13(-22.313620689733373,-0.16984528780482133,-25.33792759008492,-88.41194272694929 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark13(-22.319309757990524,-1.1984365855553198,-9.980190301202768,1.0 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark13(-22.349407436810548,-1.5707963267948943,-3.552713678800501E-15,-0.19395454074029295 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark13(-22.350208184568928,-0.3518582817393753,-28.75027556221678,-57.786891430654634 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark13(-2.2351313167436215,-0.32536052123501713,-58.22440390602275,0.9932313125800531 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark13(-22.37267053138913,-1.0528033254953364,-138.18175544709788,-0.00280876200085642 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark13(-22.378091625181447,-1.5457167150283062,1.5707963267948966,0.5789165552282887 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark13(-22.394088964370933,-0.9417896177771942,-78.39440781658499,1.232595164407831E-32 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark13(-22.399489271268177,-0.9450741961746891,-38.49402187026203,-0.05470712899900203 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark13(-2.2438364837922196,-0.2736542104109491,-11.47579768494873,-17.70465653550137 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark13(-22.440440481668023,-0.5455828047891685,95.47160538806075,-21.477799571986232 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark13(-2.245508450819699,-1.5707963267948948,-86.48859009074168,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark13(-22.477914131219727,-0.004262258042475619,-13.099204122595793,0.3740497018057848 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark13(-22.497485843322345,-0.5977567053833752,1.5707963267948957,0.0 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark13(-22.50344906501249,-0.16793778614161337,-5.132035848951988,0.44445425728171384 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark13(-2.250981727203266,-1.242236571020788,-40.046869044389986,-56.53614608734443 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark13(-22.546632460583425,-0.9259189286574379,-26.658115787110226,1.0 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark13(-22.62694064846545,-0.33547960295730594,-40.24208918929282,-46.601597354394684 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark13(-22.649167148477485,-0.5480708681111698,1.5121719758927168,0.0 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark13(-2.2667474187297216,-1.570796326794864,32.734450668412514,0.06237188865214863 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark13(-2.2672748867194996,-1.5135246420303652,1.5707963267948966,-10.18201552839615 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark13(-22.714312708105076,-0.3346017747436457,-43.58212120734545,-81.74751457882228 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark13(-22.730837323589462,-1.5707963267948921,1.5707963267948966,-4.2351647362715017E-22 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark13(-22.770440639932097,-0.4942802648115743,-21.8157770792853,0.0 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark13(-2.2785167345606117,-2.2428070313025267E-16,0.6377105339914693,-0.032024564322280735 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark13(-22.78527355883743,-1.7763568394002505E-15,-86.0471840505674,88.08057327273582 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark13(-22.79059219785131,-2.6021552223002404E-15,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark13(-2.2829283643094342,-0.42918780079732244,69.28484131627211,28.146651780110744 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark13(-22.838954939034586,-1.3593333426950096,1.5707963267948966,-0.059372846873357865 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark13(-22.878763866176,-1.3854299946790043,-66.24483870211034,-1.0 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark13(-22.882595814295758,-0.05633120389232668,0.0,-1.0 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark13(-2.288496924083457,-0.5453928649898654,1.4233057897076407,0.051879999456247994 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark13(-22.887429165514945,-0.14340690218015253,-71.90094474325346,1.0 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark13(-22.900428343738938,-1.2081181142912087,-53.78904494890253,0.9473992575375958 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark13(-22.907124046959986,-0.9616905496094026,39.22093372753101,1874.8460212715167 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark13(-22.95491058056241,-1.4667773725664512,-0.35708253090728936,-0.9919160106491057 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark13(-22.961290494564167,-0.9722887622923437,-40.05798641138733,-2.5248513272711897 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark13(-22.979021630709717,-2.0605988130014043E-16,57.96470862618759,0.03894441219057347 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark13(-22.994800481293222,-1.387347876719227,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark13(-23.000639458454742,-1.5707963267948963,-1.5707963267948983,-2014.6947159856484 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark13(-2.3007239131009687,-1.2428562163159285,-25.341766577241174,1.0000000000000036 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark13(-23.0772680185634,-1.4551589882010634,27.227877259733418,1.0035655391052555E-16 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark13(-23.09321954064438,-0.8351990495936863,4.440892098500699E-16,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark13(-23.19034403390698,-1.0941560401571973,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark13(-23.289901336314465,-7.105427357601002E-15,-75.00688498999968,-0.014026473271017553 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark13(-23.316392339034913,-0.5162678259501705,-51.7924768833226,1.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark13(-23.44051278085519,-1.0943825325296803,-1.5707963267948966,-0.9894798219002925 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark13(-23.471062340713335,-0.0360175082347779,-1.8259565002759235,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark13(-23.510874761223818,-1.5707963267948963,-1.017852920744423,51.10701399824475 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark13(-23.566881353078813,-0.5885947520647697,0.46813977970460874,86.51369717877003 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark13(-2.3763402038166204,-0.04876548185999709,-1.5707963267948966,0.6943495654412518 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark13(-23.76504481792164,-1.2233158745230062,32.84555130364835,1.001341004070302 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark13(-23.839131024958377,-0.6866166184754096,69.96616969180374,0 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark13(-23.854461203430777,-0.0057744035899235935,1.5707963267948966,-0.149423369773091 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark13(-23.8860907494269,-0.6652974412700434,-131.52168573092595,-56.01017392207475 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark13(-23.955119245770817,-0.30989984704539264,-43.92549019869348,-0.7719666136235759 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark13(-23.956163617549638,-0.9731234102279975,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark13(-23.979442572442483,-2.220446049250313E-16,1.9131727660485893,-0.11335195759690841 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark13(-24.00203441261266,-1.1951855852601483,-25.780860642047564,1.0 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark13(-24.060053591861497,-1.5138660657994842,-47.05576292529101,-0.5864428636058349 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark13(-24.060081201770256,-1.3734608802013222,0.6473844455733591,-1.0000000000000036 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark13(-24.065120162533745,-1.1102230246251565E-16,74.36898881746461,0 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark13(-24.066257478900255,-0.22672317597998415,1.5707963267948977,-0.9433389753396562 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark13(-2.413414708315628,-0.05736318050889011,-129.89300894844567,-0.4911288347524092 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark13(-24.197371816041436,-0.46461738509620193,1.5707963267948966,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark13(-24.20602943338088,-1.570788215425542,-3.0050887654673812,-0.48164391688110775 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark13(-24.259712999421108,-1.4541573891206232,-68.80290412184117,-1.0000000005710776 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark13(-24.260007486112713,-1.4297836609396675,-62.81160827682381,-0.6128847925831109 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark13(-24.297067769770628,-0.2119306390761544,1.5707963267948966,84.08776355661972 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark13(-24.344697110766297,-0.9944804121564261,-67.70284605223488,66.25221191538859 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark13(-24.415183754484783,-1.1344534530254435,1.165786207117513,-34.41228461094619 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark13(-24.447873010345347,-1.1370690346258614,1.5707963267948966,-22.39642878694411 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark13(-2.4504513939494643,-1.1565647263099716,1.5707963267948966,5.421010862427522E-20 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark13(-24.51360439977352,-0.4690139488718962,1.5707963267948966,-47.21486362049698 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark13(-24.54711492575929,-0.04888369626969184,-89.85578666949101,-6.325702883874056 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark13(-24.55963999081248,-1.2245694062120045,0.48413262278919694,1.0 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark13(-24.578246573273837,-0.7504844638964494,-70.90874769225096,0.8057347752611178 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark13(-246.00681724895588,6.4328367581729475,1.5707963267948966,-0.7897850725593948 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark13(-24.6372311981523,-0.6961921314690319,51.868316889127584,-1.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark13(-24.64637265878953,-1.5707963267948961,-1.5707963267948932,-1.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark13(-24.73443633635506,-0.6741190605415643,1.5707963267948966,-1.3234889800848443E-23 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark13(-24.825325112417563,-1.4388482045981363,-84.6211814838029,-0.9999999999999982 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark13(-2.48671147269566,-0.12340091169137546,-1.5707963267948937,0.762095815063557 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark13(-24.920145468954377,-0.6267718278039326,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark13(-24.932007119552722,-0.1436201763394111,15.170870964456839,-3.1587301655876523E-176 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark13(-24.957911311050086,-0.8968846030780364,-1.5707963267949054,71.7313366943109 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark13(-25.017043118011742,-1.5627865625650061,64.57346184001132,-22.40854057327475 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark13(-25.12505195545232,-4.440892098500626E-16,-1.5707963267948983,-72.16155802209316 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark13(-25.150504518691363,-1.465929050480182,-59.0188914567005,0 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark13(-2.5172086618385023,-0.2158907005309083,19.72023109516315,5.703198672712623 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark13(-25.215468682185023,-1.5707963267948912,-86.47976727101556,-1.0 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark13(-25.23616625188997,-1.1825185066933408,32.93597585070306,-2183.648068922363 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark13(-25.27549692193292,-1.268512334209022,-1.570796326794606,-1.0 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark13(-25.309015841154746,-0.7250336342506651,83.56878507129832,-1.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark13(-2.5389439086924406,-1.555815618988967,1.5707963267948966,-64.3143456514758 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark13(-25.438377574591232,-1.0758560654214708,50.666742425073885,0.7633126652167603 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark13(-25.439693619557588,-0.9707175561479096,-99.99999999999991,-2.2013136429275836E-134 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark13(-25.47570932270228,-1.4747832473536115,-45.062913130847036,-1.0 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark13(-25.5249001538266,-0.2515290782325721,-21.119882905164904,-0.13162529845176008 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark13(-2.553265678994247,-0.6751938099966613,0.9469978551112357,0.5772968820489692 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark13(-2.5545645390726435,-0.9058832431925591,-37.93061115228373,-46.36467200156625 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark13(-25.56327173359729,-0.4070896728773634,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark13(-2.5648845847490818,-1.5707963267948963,84.09271067331551,-1.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark13(-25.738291115023696,-0.520929509144493,1.2126055254866708,-28.877043018043764 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark13(-25.739072992964964,-0.19927585224768762,-0.8245305035335023,-0.8789792341362356 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark13(-25.76942742042239,-0.8849597116616673,-49.75211293604684,-12.513278193401376 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark13(-2.577795922328303,-0.5543321416789043,1.5707963267948912,-3.4728174496144675 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark13(-2.585529088878701,-1.5707963267948877,37.75446624865151,-3.2141347853809776 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark13(-25.985925684411566,-1.046036974497846,-1.5707963267948966,-0.0039715219422185866 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark13(-25.986034474420066,-1.21925292054452,-2.220446049250313E-16,1.0 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark13(-2.5995630542561012,-0.5055446438879362,0.0,2237.4482942954583 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark13(-26.071351102675592,-1.4101406456343857,0.7168895556357424,40.77591953425276 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark13(-26.07374292667207,-0.5205185261891678,-1.1812977797111388,26.900907445824807 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark13(-26.13122999726502,-2.3720394560745152E-15,-55.26469217403085,10.81101935477109 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark13(-26.196123567878416,-1.3159698510260416,13.19416169101976,0.9999999999999991 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark13(-26.32603920849316,-0.7503968485284893,-13.462061551429196,-1.0 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark13(-2.6339520810521826,-0.04586928924319132,-58.476358243621036,62.04307315807476 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark13(-26.342721256752576,-1.5707963267948963,-37.6679524389401,-0.0734729303961356 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark13(-26.380824723044196,-1.415543821396114,-68.04029606819047,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark13(-26.415922851702167,-1.0689675338401914,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark13(-26.443585523147693,-0.46873950766457884,-37.73786523841412,5.421010862427522E-20 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark13(-26.44561108589842,-1.5707963267948934,0.09802109230876394,-0.17002745733494473 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark13(-26.52132737486893,-1.0549474106834724,-55.89580554210956,42.478747420750715 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark13(-26.6761583873323,-0.016196330496552933,-36.82283635404553,0.04699509960326126 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark13(-26.712177669665724,-1.2463282610475996,-12.171340603523124,0.9864902468388297 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark13(-26.74074943182835,-1.1102230246251565E-16,1.5707963267948966,-45.0752171547633 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark13(-26.75020097654183,-0.5521500583042482,1.5707963267948963,-8.922413923324382E-10 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark13(-26.819679320731765,-0.2772661894632564,-0.39417960931470986,17.39205158587084 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark13(-26.82625510594131,-0.18110222218572858,0.0,0.0 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark13(-26.842659893614567,-0.11084877205311466,-9.631093066250884,-75.53196367497311 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark13(-26.882543372599343,-1.5707963267948912,-68.7154999955209,0.9023054837417517 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark13(-2.690136154731448,-0.8607127715127634,-0.34332890247306125,-1.0 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark13(-26.93182055792314,-1.53017109349391,0.0,-0.9644276339693096 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark13(-26.957880167814047,-1.5707963267948921,0.0,0 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark13(-2.6958324766885897,-0.18980167243000845,-100.0,0.7438522173573223 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark13(-27.09039060121605,6.429362449546056,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark13(-27.096012658857713,-0.24806670552898424,-0.11141702844555378,0.06255715843851004 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark13(-2.7097336077135257,-0.42318706420703944,95.69771163947057,20.878249232654355 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark13(-27.114727935672555,-1.7763568394002505E-15,-38.867216406463285,-40.1534877392027 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark13(-27.27015994083517,-0.27588888848373533,25.41006345230021,1.0 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark13(-27.380833365524367,-0.0694114884773388,0.0,0 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark13(-2.742198058955947,-1.4985928263125927,-0.33835678750612885,2121.114188866899 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark13(-27.443052650137584,-1.4735917343069325,1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark13(-27.44413540036416,-1.511819316852467,-45.00546894938433,1.0 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark13(-27.4693409373543,-0.7350755933073385,57.71583423631238,0.0 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark13(-27.47195076118008,-1.5060597309420416,0.0,-0.8432517551554894 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark13(-27.474944340695004,-0.822301549828393,-10.398731830456697,-58.10500157634526 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark13(-27.51380872379038,-0.36334907678122064,-44.24107724194896,1.0 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark13(-2.755994533732718,-1.2719716252841105,-163.8071742098009,-0.42659679568659215 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark13(-27.663544908818583,-1.5707963267948963,-5.752792645065743E-17,0.3716905330700191 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark13(-27.672181943162528,-1.234697569126205,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark13(-27.686670937798567,-0.3972760024958639,-1.5707963267948966,-0.2885403629136497 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark13(-27.745347986230975,-1.192852105838876,-36.768927651469426,-0.013662198481164031 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark13(-27.761443708522304,-1.3410818036814058,0.230306465049112,-0.01640941471958999 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark13(-27.801034364662076,-1.104704463601234,0.0,0.0435175505389378 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark13(-27.828342489070778,-1.125056780759813,-44.42009138540212,-88.31449200687867 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark13(-27.833547926050514,-0.9075894114864558,1.560824725002519,0.967678835422515 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark13(-27.841220014027904,-1.5707963267948948,-43.91008743306881,-32.23129520562155 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark13(-27.909777100539163,-0.6757836833775687,-24.121731061131143,1.0 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark13(-27.999510707172178,-1.1728159548426014,0.0,-1.2605515827954452 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark13(-2.802224048274091,-1.5707963267948961,-32.91554294998501,61.212478318137414 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark13(-28.043241162654148,-0.00789571126892663,-28.380483941036587,-37.740237176286314 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark13(-28.07039452167493,-0.5296866892776997,64.72289362346868,0.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark13(-2.807544378309203,-0.176780591155992,-1.5707963267948966,-37.59466395790405 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark13(-28.077076104069995,-1.1939483579856103,-88.74478555404247,0 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark13(-28.08704954477433,-0.0798579328455061,1.4567589131008123,0 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark13(-28.148664208526725,-1.3247547754509565,-80.69482659781207,-1.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark13(-28.201809150788954,-0.5857097378786844,57.681644180655,-1.0 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark13(-28.23530360654351,-1.5337593827030835,-72.61507160858027,-1.0709019298637985 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark13(-28.38162285002536,-0.29579235026351425,-49.28763145646755,8.673617379884035E-19 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark13(-28.39353305639133,-1.570796326794861,-1.5227444076194752,-3.64673231513331E-15 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark13(-28.411594360064992,-0.8635329605633097,-18.520480109684257,-78.29909504951638 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark13(-2.843569591704849,-0.011124481804083368,0.760140776223647,29.069828960453606 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark13(-28.49338328324101,-1.4886483740106478,1.5707963267948966,-0.803474991925107 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark13(-28.537800258553233,-1.035799132063687,-1.5707963267948966,63.15381317767748 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark13(-2.857245570238769,-0.7100018693850979,-40.72379966792088,0.9229783995756707 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark13(-28.627623264220937,-0.055617412554327256,1.5707963267948966,3.552713678800501E-15 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark13(-28.634759719278453,-7.105427357601002E-15,-32.86969813954724,0.8291356559505192 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark13(-28.660438036732486,-1.4434995339686376,7.465029056225719,-45.27383325683053 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark13(-28.684596415606862,-2.4380739505429046E-15,-1.5707963267948966,-40.32315232602993 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark13(-28.698960420338352,-1.2216440745122128,-97.47510980089858,0.43522690549705595 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark13(-28.722715454617603,-0.07446275174355436,0.0,-1.0 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark13(-28.771466941566356,-7.948476872036651E-19,-66.29344039985227,0.010576618888949589 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark13(-28.789781340571608,-1.0408085861219583,-32.22861457569502,-1.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark13(-28.824953935058446,-0.34321517307095206,-58.86238389397753,-7.139822727146949 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark13(-28.853182560011064,-1.1852544754529823,0.47699253864274027,-2270.9569945349695 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark13(-28.88136833471851,-0.29276407976508523,-1.5707963267948966,0.3446852120910038 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark13(-28.939837882385483,-0.6719962500214327,-6.7069737679623245,0.18705227955953704 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark13(-28.995874491285726,-0.3136290510770992,-5.771827661169228,-100.0 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark13(-29.112057880066864,-0.9379495336777963,50.831382864816135,-62.602787830987985 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark13(-29.11722431577583,-0.04680613101632039,-0.941235644742186,-1.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark13(-29.198351968870956,-1.5707963267948912,-27.055642055598497,63.94757653790411 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark13(-29.379380105256317,-0.44427051695938263,-73.71618166673076,-0.6217644342765558 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark13(-29.388364200284737,-0.024902172262320044,1.5707963267948966,0 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark13(-29.436208343226433,-1.5707963267948948,-68.62437487388274,80.29552073114125 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark13(-29.452980586885033,-0.0938164020692152,-74.65081576962751,-0.4508945876070811 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark13(-29.50282429925587,-1.5707963267948948,0.0,0.9714118546563008 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark13(-29.51110575260561,-0.5190807813227183,62.96379753013349,2359.4184662565995 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark13(-29.57604906852525,-1.5707963267948963,88.29900106000002,0.01968726782726825 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark13(-29.644217274707565,-0.4423761704068524,1.5707963267948966,18.92371503163101 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark13(-2.9670122915759594,-0.6153365108906438,7.750684775005965,0.9999999999999991 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark13(-29.698641751109562,-0.9265845632518586,0.0,-1.0182643116265595 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark13(-29.726990049966773,-0.8418881599564438,7.258977900666963,1.0 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark13(-29.729994735859822,-0.37455380312099035,-7.788214297823115,-0.18939433550117113 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark13(-29.795227353183037,-1.4366557173431935,-2.220446049250313E-16,0.5415200036195689 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark13(-2.9796364801968407,-1.3682401519676186,-15.98437488668407,-1.0191286983353256E-7 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark13(-29.80548747585518,-0.41557704977978177,0.0,-0.01715707422760193 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark13(-29.841700075284177,-5.590400886974264E-15,-93.4541802330307,-1.0 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark13(-29.870738416037266,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark13(-29.923902657565208,-1.5707963267948961,75.97161688978366,-2204.2104083445074 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark13(-29.949736778354836,-0.21112061732833656,-44.048451191688386,0 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark13(-29.98780656517005,-1.570796326794877,-71.35029063585138,-0.9211361797247603 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark13(-30.023949329847277,-1.5707963267948948,1.5707963267948966,29.17100325574799 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark13(-30.035384500805314,-4.193037167149397E-16,50.45750659036424,-81.52381382811463 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark13(-30.06871915272049,-1.5271542530709268,101.93289145975226,-70.50152424765028 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark13(-30.11623876095561,-0.9038274448098655,0,0 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark13(-30.126750623033313,-1.4708163177310913,-0.8497699519112151,-1.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark13(-30.130071566975257,-1.5707963267948912,-71.57369097528554,0.014916290279059774 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark13(-30.167473521263815,-1.5707963267948912,-31.692590302474528,7.077092789272669 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark13(-3.0171787306427924,-1.559522142434475,0.4481568714840338,1.0 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark13(-30.17598413084134,-7.404140682729099E-4,1.5707963267948966,0.03386396479238035 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark13(-30.195338475667516,-1.3435489513165964,-44.34145893003565,-1.0228917780834281 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark13(-30.28179378465417,-0.491770259049147,0.0,-4.332163699792201 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark13(-30.300041922054817,-0.11398601657925092,95.28379178263349,57.453766390371634 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark13(-3.033829746905397,-1.3903582840374185,3.1080719233865057,-103.73936267098767 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark13(-30.3685297649058,-1.0742737338736301,-2.1946360428790825,-1.0 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark13(-30.39835278518634,-1.2466043396209725,-100.0,-1.000000011261304 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark13(-30.41097708668126,-0.5674266400407504,-73.58950233447456,0.014344088592623705 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark13(-30.428501661887505,-1.5707963267948948,-131.63189210538343,0.9601870862428079 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark13(-30.445582948809445,-1.5707963267948934,90.3416729504161,-1.0 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark13(-30.487270498719322,-1.5324571682995591,-46.463437606561826,-0.6052364054345771 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark13(-30.490227360050895,-0.0259080661280785,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark13(-30.503556516051518,-1.5707963267948788,0.0,0.0 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark13(-30.529301957522215,-0.8018548993238089,13.980771096218234,-0.9999999999999997 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark13(-30.552090467341216,-1.3178410907011153,95.26753983669732,0.9999999999999991 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark13(-30.60738375336578,-1.5707963267948954,88.33711957348197,-1.0 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark13(-30.656653132300235,-0.01818513682626436,0.0,0 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark13(-30.706751530109884,-8.729182798510177E-4,0.9982127078629706,97.08378314252758 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark13(-30.723838866593134,-1.5707963267948926,-37.68881263511493,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark13(-30.767801429782025,-1.340842784127939,-3.161075694360889,1.0 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark13(-30.817697139652033,-0.05651087342143679,-76.81490849594212,81.35645354568778 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark13(-30.883845076126676,-1.1532935355893414,0.0,-1.0 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark13(-30.949635520174343,-0.14031825194676495,1.5707963267948966,0 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark13(-30.964496357368247,-1.020294027949359,-38.08098302169623,-57.25850253088098 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark13(-30.973230350685807,-0.24512623347883883,-68.82091465856246,1.0 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark13(-30.99010932788986,-1.0770188997690235E-5,-1.5707963267948966,-0.7007332475275355 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark13(-31.0286528912325,-0.3198444241151354,64.16305339143378,-0.04794492689834739 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark13(-31.070535868790287,-0.4599109443208328,12.789268536610177,-1.0310784492178364 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark13(-31.092922924021398,-0.067388215420747,-49.58981387461356,0.9291337619410297 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark13(-31.121415476522586,-1.1438893084737725,-45.401766052563275,-0.8712459065762703 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark13(-31.19339218211166,-1.3623268797735464,50.90962151501496,-0.5288999730489944 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark13(-31.19489287696259,-0.30014986451667836,-31.831855006268903,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark13(-31.206009310024495,-0.07112648828546797,-36.80668311384846,0.1446040647321034 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark13(-31.24178600035103,-0.44870259347903096,7.847583400557234,-1.0 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark13(-31.26099444317459,-0.256317035707541,-46.668714501144315,0.816530327968394 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark13(-3.133517240483594,-1.525672372683587,14.119002362347384,0 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark13(-31.43192976501112,-1.5707963267948963,-31.46686252416653,7.105427357601002E-15 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark13(-3.1441417855750444,-0.8789129142635248,0.4993244255150163,-1.0 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark13(-31.44509516983602,-1.2698635992369065,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark13(-31.539417132387214,-1.570796326794877,8.965149675588592,0.0 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark13(-3.1549057720105385,-0.668525844655419,-0.73776018960238,-0.06262668533867372 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark13(-31.568663652255594,-0.7392301949762299,65.88791406044697,-26.808651271626346 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark13(-31.593691613239912,-0.3883107028200641,0.0,0 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark13(-31.597922650441838,-0.8346497482417863,-33.12415348947486,2.459902179261761E-4 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark13(-31.62860605635676,-1.2701365673189788,64.13782840521606,-1.0000003243007989 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark13(-31.665457593255443,-0.3540943456090861,-23.856417461974914,-72.01507213028194 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark13(-31.714658418291368,-0.9668932234565091,-0.6676748815415747,-0.015743793346558732 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark13(-31.725612383831233,-0.8399783959108769,-31.472536046113373,-20.136262330862593 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark13(-31.73761072558024,-0.015425973000522581,0.0,1.0 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark13(-31.756965268549237,-1.5707963267948912,0.8238762077454993,1.0 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark13(-31.815069778333566,-95.2258855457062,30.779778498636517,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark13(-3.184837453838426,-1.5707963267948961,53.35826909611536,-61.38878883262487 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark13(-31.88553321933125,-1.4479256279463728,1.500145078842855,-0.28557001908952895 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark13(-31.886818038657097,-0.7251642589549062,-27.120382812798745,-1.000000000000007 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark13(-31.89647197455466,-0.3779363893088574,-116.10353830532777,73.28561402108922 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark13(-31.900841297730437,-0.9912285317950249,-51.008467709193894,1.0 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark13(-3.191213615318795,-1.3779528172849278,1.5707963267948966,-20.14026659099189 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark13(-31.931748201800016,-5.366110881425878E-17,1.5707963267948966,-55.189401157193196 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark13(-31.933237081153237,-0.258555099193714,-66.91713155609942,-20.904781859586585 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark13(-31.965776500039276,-8.116415553831302E-5,-20.476360393040288,18.111558264307615 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark13(-3.1969468157731873,14.430330042916374,1.5707963267948966,8.881784197001252E-16 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark13(-31.9823054168273,-1.4308890011598385,-37.76660930330981,1.024651606461675 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark13(-32.03859696784297,-1.1090485568823252,-0.75868645593524,43.365628439530205 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark13(-32.052254249336954,-1.5478833513214842,-45.07959418641309,-64.1401780489987 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark13(-32.144524696563764,-1.4751519788862537,1.5707963267948983,76.24095401868794 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark13(-32.175158843071,-1.570159373732806,-30.13921913870936,-0.8941743636598485 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark13(-32.201807072933086,-0.9435614061676019,13.864283932150201,0.029601842959544933 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark13(-32.26131970763273,-0.07939350683663804,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark13(-32.2836399782402,-0.40434006199904604,-32.63738747026664,-11.853561057420123 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark13(-32.33929936139647,-1.5707963267948948,63.482446384626975,-0.9999999999999996 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark13(-32.36345364320127,-0.1133985072107362,1.4926108060311896,1.0 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark13(-32.39378493438364,-0.9522993337904846,0.2322015245542467,-0.044004043459596846 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark13(-32.43997035456017,-0.7886571671395843,-3.2447074420338824,-1.0 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark13(-3.2472220304607045,-0.3081828936093375,1.5707963267948863,-0.1537111296240692 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark13(-32.47310563852966,-1.4280262517383835,0.0,1.0 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark13(-32.52955956804784,-0.12512861126253602,0.5047233499363607,1.0 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark13(-3.2548952384498144,-1.5621553200752212,-1.5707963267948966,-12.215232886394006 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark13(-32.55741920399353,-0.9409751996231461,2.6810024068345086,58.812242080224664 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark13(-32.57392692308329,-0.9083532349682208,-75.65931225369397,4.33494212636341 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark13(-32.589781535473044,-0.6591905987196176,-48.52501340509439,-1.1084251410642736 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark13(-32.70994390701466,-0.704669972594937,-1.5668264314042715,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark13(-32.76999320704081,-0.9945190329123268,69.43945401100287,0.13873953640462844 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark13(-32.77080772766116,-0.07667413905410611,-97.1778988382952,-0.40827708940325835 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark13(-32.785909845194304,-1.5707963267948948,-82.23560890940338,0.0 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark13(-32.823617347932405,-0.6585637943766426,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark13(-32.847838392649436,-1.445379991884048,-44.250190254572665,27.308014377843648 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark13(-32.91968860229049,7.040213116726503,43.14488491663793,0 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark13(-32.921647117371926,-0.07331923404621934,0.0,0.012933395496140976 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark13(-32.97190080900673,-0.3375277713762235,-1.08335453297143,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark13(-32.987056679134156,-0.9733241702348501,0.0,-0.5263062544712607 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark13(-3.301750393046632,-1.2560845822591016,38.92523384474023,-42.67105977195147 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark13(-3.3035991764614896,-1.5419064946379921,2.43591836856458,100.0 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark13(-33.1990854886551,-1.5686754733825918,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark13(-33.201210106376834,-1.0806472671589038,6.6311751526966844,-0.8445441111029639 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark13(-3.326732957779342,-0.5694757145841091,1.5707963267948966,-52.65310263550218 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark13(-33.388554327052596,-0.1786523615157363,-27.656627131435222,1.0 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark13(-3.339223297331722,-1.0946573688485588,1.5707963267948966,0.23866932811942831 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark13(-33.40609068499296,-0.8401670885270743,0.5631471546269594,1.0 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark13(-33.600759684819096,-0.8843584454510527,-1.5707963267948966,-0.018999135242961374 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark13(-33.62804024314894,-1.5707963267948912,-124.68425304224154,15.06934654128557 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark13(-33.664604926985646,-0.2750553171345549,-9.662868641156214,1.2695569126297983 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark13(-3.366496434227623,-0.2862200104384864,-9.966114818047146,48.453708688190005 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark13(-33.77564157514493,-1.5543066484735337,-72.72758951553202,40.88758842752105 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark13(-3.3861028187524282,-1.5707963267947562,-12.059832518263619,0.9999999999999996 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark13(-33.905921723168014,-0.6840903471253436,-23.161354172143103,-0.9330466909950529 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark13(-33.91000318141294,-0.07342447089189374,0.6484430943355266,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark13(-33.92702112914879,-1.5630041210423113,-19.401547637715908,3.6805886957306903E-4 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark13(-33.97107725290341,-0.6804939622571555,-30.36118689223315,1.0 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark13(-33.99582930250983,-1.1102230246251565E-16,1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark13(-34.00544605002097,-1.5707963267948948,50.29893022766603,-0.9568381873416829 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark13(-3.402554800670547,-1.4425180572430012,-1.5475553254688363,-8.236092143148846E-84 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark13(-34.0373619489752,-1.5702401923456866,-83.76118633975373,0.9780510032405 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark13(-34.09971164766192,-0.16408407773472966,1.5707963267948968,0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark13(-3.4131139880551356,-1.3478429925886068,-63.71129741053835,-1.0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark13(-34.19023670717391,-1.5707963267948912,1.5707963267948966,-22.535260536520013 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark13(-34.2584861753465,-0.6398924342934147,-40.539509798641205,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark13(-34.284645512303044,-1.5707963267948948,1.5707963267948983,2165.5242836541142 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark13(-34.319226371545376,-1.2853114882790881,-38.29333698342759,-1.4595056084853355E-4 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark13(-3.4361395555064753,-0.2637261768226254,1.5707963267949054,0.03851939487254267 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark13(-34.426481585616074,-4.194701947782909E-16,64.7404792775678,-0.04499028470336036 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark13(-34.42908296518825,-1.1624281667909584,-45.28211315190922,-0.04320764035118858 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark13(-3.4459140891053943,-1.157050836148325,44.20799061476822,32.990971643042144 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark13(-34.587291848575134,-1.3211498774643786,-73.57721051447487,-1.0000013508698973 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark13(-34.588318809452815,-0.8315280757740648,0.40308654161725466,0.09761676668353642 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark13(-34.615625187634855,-1.2146637772699258,-3.463197161533181,1.0000000212702471 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark13(-34.65520671018234,-5.0762190962733567E-14,-1.5707963267948966,53.64730269680546 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark13(-34.67759786640407,-1.3508780713716013,0.0,0 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark13(-34.70114161082061,-1.4959540252118249,-4.32788901395436,-1.0 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark13(-34.70628132445556,-1.4392707621387568,-7.936292998209794,-1.0 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark13(-34.72469981480339,-0.6744862003158125,-69.80234098350373,1.0 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark13(-34.74773152276401,-1.5707963267948963,-62.38915197741329,-2076.3241398051014 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark13(-34.782584322692685,-0.9756382762052832,-21.094580391657225,0.06255730469260351 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark13(-34.79880562126414,-1.2367115739317454,-32.741576940419776,1.0000164987198206 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark13(-34.84069989793274,-1.3510135386648559,1.5578525956838298,0.9959103936252443 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark13(-34.8643628322787,-0.026111916271940684,-12.113942249011645,-1.6940658945086007E-21 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark13(-34.952215671250435,-0.6967112164395637,-38.360772350272285,0.03490716258770965 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark13(-34.95302359002062,-1.5707963267948963,76.69112292244458,-1.0 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark13(-34.96585166790321,-1.5707963267948912,-2.05954290882795,0.7880642930200693 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark13(-34.979413225258455,-0.26445206514438624,-70.66480731589355,-44.45181491615984 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark13(-34.98953797587572,-1.2761859895860166,-3.552713678800501E-15,0 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark13(-35.07950452850552,-7.791633216504251E-15,-0.059850258280409796,-1.0 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark13(-35.095123094454195,-1.5572223005430121,1.5707963267948966,-28.79215652973286 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark13(-35.184949938027025,-1.558966087242922,-62.48480554383291,0.9703459617704561 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark13(-35.21685876510864,-0.731447831722188,-45.59021177988214,0.9930033949916491 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark13(-3.525842512418445,-1.3054701211733264,-45.339437835714115,0.7947593980091275 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark13(-35.2764313568459,-1.5707963267948948,-1.5707963267948966,-0.18399608434775017 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark13(-35.316165670805546,-0.4979395107349659,20.738872190450696,5.4795233725210076E-194 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark13(-35.32138888399072,-1.5698247882763101,-24.69561766979687,1.0 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark13(-35.327101760325206,-0.5724177031007348,-7.934340220034386,-32.350635466156675 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark13(-35.36520853826663,-1.5707963267948912,-15.268200097234441,-1.000000005477027 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark13(-35.46876170463338,-0.7523084562242547,-63.476360349345526,-0.6690261696658373 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark13(-35.48150428569666,-1.1240679707537802,1.1184058531879668,1.0 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark13(-35.49419302893411,-1.5707963267948961,-1.5707963267948966,-0.06255259000312584 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark13(-35.67162128224109,-0.6176558035166577,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark13(-35.69489929513721,-0.8139517001778558,-3.552713678800501E-15,-1.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark13(-35.73246856732652,-1.7763568394002505E-15,-46.05435394795114,3.3001586594946417 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark13(-35.749634433598445,-0.5640423377267172,0.03463810696326736,0.0493494809714876 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark13(-35.77765509978124,-1.154362431989365,-92.84048652130303,-1.0 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark13(-35.81363488847286,-0.8263648589187653,32.71290626504755,-0.17751888316929243 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark13(-35.84333679077947,-0.7182221256812262,45.465902977764536,0.0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark13(-35.919743398138955,-0.9310994098659024,-45.11667443986843,-32.94445427894037 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark13(-3.592782334531364,-0.08989278828153968,-44.55657905640296,0.29859066867411865 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark13(-35.9377429005024,-0.4481655134001835,-60.35855034354145,-0.960437618437248 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark13(-36.09822889491343,-1.5707963267948895,1.5707963267948966,-1.0009440035204542 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark13(-36.15736110728522,-1.4195161366419864,0.0,0.8165116706759334 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark13(-36.165654987197506,-2.7755575615628914E-17,0.0,8.358418863073856 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark13(-36.185725832580374,-0.36621628450754556,-31.449020956473483,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark13(-36.24267673962772,-1.5707963267948957,-52.789103343663044,-0.9999999999999982 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark13(-36.27408988769472,-0.13866231087864636,31.783293760840337,0.013159900628850973 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark13(-36.29122966516002,-0.7212105305067539,-100.0,-2.9568086032981482E-8 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark13(-36.312607825727525,-1.3421581078609237,-1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark13(-36.33011487297748,-1.3769937115536975E-15,-14.308351231393079,1.0 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark13(-36.36101505242284,-0.6659772177668156,-32.698817563015574,8.22042283682753 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark13(-36.39726058843118,-1.5707963267948912,-11.523986559153627,-28.384780304895713 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark13(-36.40398262800221,-0.0706881021927498,25.42879334223176,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark13(-36.43937755110198,-0.4332107821206609,50.96467219766013,63.481770948277465 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark13(-36.45069903103637,-2.220446049250313E-16,-0.30886111938551153,-1.0 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark13(-36.53926505677539,-0.6419110200353977,-17.302629421823134,96.77208421749793 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark13(-36.546570985299034,-1.5707963267948912,-92.8062592124948,-0.04135533403875957 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark13(-3.658017080074252,-1.5707963267948912,-2.575882352350492,1.0 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark13(-36.637323105294584,-1.5707963267948803,-58.39442026245004,86.4852792916515 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark13(-36.644563663628034,-0.8223926608710238,3.944304526105059E-31,-0.016419113699475213 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark13(36.664475265292936,-0.84078692740961,0,0 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark13(-36.70605980985465,-1.423690162782331,-13.994208026993718,1.0587911840678754E-22 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark13(-36.81688430049562,-1.0204772395538562,-1.1834314388715144,-1.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark13(-36.81915192990864,-0.2052406244420002,-65.5423656503395,55.88059393082365 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark13(-36.83540313036021,-0.28243022477381435,-69.86385137069371,0.9898567937472285 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark13(-36.8436647236094,-0.48628828625256204,-35.590554624820484,1.0 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark13(-3.685681841487968,-0.8995434755158144,-1.5707963267948966,1.1869459682199748E-66 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark13(-36.8865471616417,-0.7347308884894872,-95.64887063428694,0.0 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark13(-36.98023619884525,-0.3248317061663897,45.37123519414041,-0.953723420410272 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark13(-37.01139923151121,-0.7383352557478724,0.44917829335549353,1.789703311903616 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark13(-37.05380717709194,-1.5663396464751738,-9.854753012319208,-1.0 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark13(-3.706719293314587,-1.5707963267948963,-33.87007430947674,-1.0000000000000002 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark13(-37.10704522476635,-0.696540578167549,-33.390104740309525,-0.007070578030251018 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark13(-3.7128058809893503,-0.5085372704242883,-75.92003307778073,0.0472572179122207 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark13(-37.18672661517078,-1.545166014608456,-32.441866704962735,5.058692000080142E-6 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark13(-37.203466764831525,-1.073990372237911,-74.5975407492655,-0.25366178372543235 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark13(-37.25590752324951,-1.5707963267948957,-1.5707963267948966,-0.7544664041625817 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark13(-37.36629506695902,-1.4879661828805186,-32.91566856444406,0.9680787363074801 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark13(-37.36636083025138,-1.5707872635504307,-1.170280381487994,0.0 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark13(-37.366573844256195,-0.04250797531408225,-37.14350418487866,1.0000000000000036 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark13(-37.397787782480094,-0.5323157668056702,1.5707963267948968,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark13(-37.411223372498625,-1.045275208517128,-177.2451408454402,-1.0000000076438158 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark13(-37.63098457053182,-1.333774385654106,0.0726506915219749,-22.106643594278736 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark13(-37.63951054320431,-1.5416042744097302,-14.92011733727223,43.19572116891402 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark13(-37.673030334165276,-0.061646565429659676,0.0,0.00186857512302524 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark13(-37.695682039542945,-1.394668337574589,-4.440892098500626E-16,-0.046576990057250994 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark13(-37.75337503971573,-0.5582271479876385,-57.84057748959472,-45.36150196908155 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark13(-37.75463820365563,-0.050172520602301124,-47.32915143753941,0.38776099698439515 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark13(-37.85704167963049,-0.5961823254357936,1.5707963267948966,-0.5018269441846473 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark13(-3.7865275934494798,-1.5682310756846558,-74.42649351642874,0.0 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark13(-37.920777651409686,-1.570796326794893,-96.85221573352067,-43.29274449621886 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark13(-37.95718258150695,-1.5108227691214309,-1.5707963267948963,-0.9871834205709159 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark13(-37.967465012392545,-1.1393579359806985,-92.19118373767823,3.2626522339992623E-55 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark13(-37.98460409356042,-0.31340248724156927,-1.2351690058973848,0.8820709683780709 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark13(-38.03300916026255,-0.5565128353534305,76.69807185863726,-53.856982590191734 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark13(-38.0917445759389,-1.5521117103922428,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark13(-38.109006001251196,-1.2698909901452358,0.0,-61.386923087398394 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark13(-38.13269817403729,-1.0591447586938223,-1.5707963267948948,0.03137384334487688 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark13(-38.13654906463583,-0.7842726501164776,0.0,90.62563013450485 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark13(-38.15720917936357,-0.7187678176820965,-31.87844752626529,0.36685251698718047 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark13(-38.192913764978684,-0.9931176093583689,-4.422661858865297,-18.36782612896768 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark13(-38.206206665848924,-0.002175562607237924,1.5707963267948966,-0.47457266590517877 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark13(-38.209646712966524,-7.836170960239432E-4,-12.260473233176803,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark13(-38.2108739743636,-1.145593755991527,-0.5519938057806,-0.34962804052708196 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark13(-3.830269462240831,-1.5707963267948912,84.05053534241733,-0.8706450688014791 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark13(-38.33873690547318,-0.7322790723960249,-79.2490760571936,-23.841927227815674 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark13(-38.36373844355361,-1.4285991188878482,0.0,0.47838086417279624 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark13(-38.413907566237846,-0.8227570498828501,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark13(-38.47239628263305,-0.4657009923241935,95.60569492443166,-0.9999999999999964 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark13(-38.475171099991414,-0.07132438445107754,-44.06669555339546,0.023737460853368475 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark13(-38.49225292182266,-0.1333953495620549,0.21313622115049866,-23.095891316529478 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark13(-38.509242554244906,-1.5707963267948912,-90.31587022413106,1.0 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark13(-38.52235938564854,-0.007797056652164907,8.881784197001252E-16,-0.6782371172962107 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark13(-38.57147418248407,-0.47841046890852734,0.3986483028182631,-1.0 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark13(-38.64970130482614,-0.39269047568792814,1.0489217879361699,1.0000000000000036 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark13(-38.65233208511593,-0.1733910799140373,-63.474586332827876,-0.009445117196095082 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark13(-3.866033681510623,-0.6929629313527393,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark13(-38.66372486749225,-1.5707963267948948,-70.7426442301157,-50.51864960454338 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark13(-38.7097791010445,-1.5707963267948912,26.647290499488847,-0.007236429007349443 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark13(-38.753861027418274,-0.07635622260476094,1.5707963267948966,23.01745756841668 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark13(-38.80638185159105,-1.5707963267948912,-14.940988850029655,-1.0 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark13(-38.82078674449742,-0.9650908095004457,-19.41870244250444,0.9999999999999988 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark13(-38.820966108251504,-1.433378911959424,0.9831863552537645,-0.9249602146504947 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark13(-38.976896303412325,-1.0857279482306517,0.0,1.3177747429038154E-82 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark13(-39.01863938696579,-1.1998263718909992,-10.310016125506365,1.0 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark13(-39.0895748098302,-1.498988361927864,-38.95321564714105,1.0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark13(-3.922869864028912,-1.5707963267948948,-14.97724492392329,0.0 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark13(-3.9230638536947424,-0.3562360648282576,-2.7755575615628914E-17,-1.0 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark13(-3.9251945888579396,-1.0977108888772062,-15.686176223881509,1.0 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark13(-3.9256457653499224,-4.5670171315443625E-14,38.98813890687104,1.0 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark13(-39.35072249200276,-1.5388097957022304,-9.026063618225095,0.01882357320170179 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark13(-39.36068040231624,-0.19119875374654222,-91.9802139750629,0.068310494816708 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark13(-39.37258537439462,-1.4614478308766634,-0.7860781088912506,1.0 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark13(-39.42229973017734,-1.5707963267948868,65.82672482239047,1.0 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark13(-39.436482283730456,-1.5041785018778637,44.0810251018518,-0.9642087735380762 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark13(-39.452499416388676,-0.30783270436822685,0,0 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark13(-39.61004773814968,-0.10983591113140889,25.80369865187538,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark13(-39.625726272851644,-0.5151440709997819,-42.954687579593,-0.0336553592265334 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark13(-39.65457544253961,-0.18518423044188737,-1.5707963267948966,-88.90565884380692 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark13(-39.7126349310539,-1.2430922507048607,-62.46871830589634,-1.0 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark13(-39.728625126561944,-1.0537026675816037,-58.971323716109204,-1.0 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark13(-39.77727273244447,-0.9897055570316056,0.0,-0.9759082084465236 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark13(-39.82085539928681,-1.5334238031428067,-56.021906419386234,-1.0 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark13(-3.9893525007302073,-1.5707963267948948,1.5225683734400128,-2109.9801462426276 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark13(-39.933611107914665,-0.49808959132437247,0.2597237169066692,-1.0 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark13(-39.97074678022091,-1.2648905718751493,-9.644577903190383,1.0 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark13(-40.039374322683564,-0.05550404511015939,0.0,47.60524745231635 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark13(-4.018503882673514,-0.8236992776933763,164.38543158950694,-1.0005703385963147 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark13(-40.19382146597168,-0.9978207819112441,-8.55012667415253,-36.46327733105578 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark13(-40.223466689784026,-1.0202187348432141,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark13(-40.23056092399163,-0.7092606231165648,1.2265354967427216,-37.60669622881857 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark13(-40.26734278101782,-0.5844658749279956,-4.297405755998424,-137.26691326293712 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark13(-40.28848889654148,-8.881784197001252E-16,-1.144776287037314,1.0438988038773434 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark13(-40.32352511856706,-1.5707963267948912,-44.98452317930591,-0.9440398240977548 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark13(-40.34849512476824,-1.4282634366899285,-1.5707963267948966,-1.0553244977563159 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark13(-4.039121954129648,-0.7003781409124292,-79.98210869993461,-1.0 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark13(-4.043197148668887,-0.475360971545868,0.7078764853334887,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark13(-40.45121532543319,-0.9662407868488365,-10.607216318450693,-0.259170407329276 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark13(-40.46702513441056,-1.2721812669832586,-33.750571386903815,-0.07405753332705067 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark13(-40.538397867261125,-0.15775325508816793,-46.03770317840538,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark13(-40.577583069918056,-1.2123744995875718,1.5707963267948966,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark13(-40.59007161924294,-1.0758578274709052,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark13(-40.722412711517904,-1.278087686549152,1.0676328858812847,0.05673855980637385 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark13(-40.78342327011966,-0.8865431426520712,0.0,0 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark13(-40.79019696417768,-1.5707963267948948,-0.802162239766862,0.9028820608913093 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark13(-40.86730476615463,-0.5834772818340926,-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark13(-40.90619687498545,-0.022426737432147004,-44.55211795690812,1.0 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark13(-40.92245755575464,-0.3341464822683595,13.355910982077322,0.19604296432785467 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark13(-41.03691588977247,-1.2186517328178357,-0.8110772329854523,-0.9974870835904985 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark13(-41.04909026110841,-1.5707963267278762,0,0 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark13(-4.1075732546102435,-0.002683390083045623,-1.5707963267948948,-0.6564877487331635 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark13(-41.087443293991626,-1.5707963267948963,-89.68870695292857,-1.0 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark13(-41.15837943818644,-0.2505446269738547,44.437821804712655,0.0033241287635324772 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark13(-41.178134014827016,-1.1326827434316424,-9.406377151621626,1.0000000000000009 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark13(-41.25838357618494,-0.3848995387277325,32.644658007315286,24.976334166817594 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark13(-41.25996864971499,-1.27844203993817,-70.23662865809922,0.02327826754859852 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark13(-41.32350290690995,-1.5707963267948948,1.5707963267948963,-1.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark13(-41.34941610483028,-1.481423255464125,1.5707963267948966,-83.1023748614755 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark13(-41.45832347873126,-1.5668383867367393,-7.136065489095623,-1.0 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark13(-41.463990137166405,-1.5707963267948912,-24.86669190507321,0.9062577204226988 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark13(-41.58175825298641,-0.15269310616963036,1.5707963267948966,42.45964601997991 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark13(-4.16016555399954,-1.5707963267948912,88.57284788427035,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark13(-41.61536207085249,-0.5023079774292221,31.49021515833732,-0.019163703927922035 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark13(-41.710614144447305,-1.1228518727248766,0.0,25.760751081641004 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark13(-41.78172260787318,-0.031773921255045794,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark13(-4.1799167583895205,-0.28639057444584615,-0.5417865025438496,-1.0 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark13(-41.8028168435346,-0.15634676951152748,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark13(-41.87926356815664,-0.3309652113443486,38.11454263090073,-0.8614476468052352 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark13(-41.96159407461351,-0.7955933423253987,-95.14400572819861,-0.5612076163471755 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark13(-42.010963256057195,-1.5707963267948948,-9.91452159281428,-4.814108463751718E-10 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark13(-42.04470164793045,-1.570796326794895,0.0,60.846476491537395 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark13(-42.120191905099276,-1.5707963267948963,-63.672390996873816,-67.20883984317416 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark13(-42.12314889661656,-0.8903574801981904,51.716204387181605,-3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark13(-42.125158500382746,-1.3912367783609643,-18.673138349818373,-76.98788695071295 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark13(-42.19125475077616,-9.944520294545591E-33,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark13(-42.320976705646636,-0.24144274213572525,0.0,-5.362773418356001 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark13(-4.235820174150591,-1.276512779482548,1.5707963267949019,-0.9964278594746996 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark13(-42.382136715367835,-1.7763568394002505E-15,-27.083788827166114,1.0 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark13(-42.431150352652864,-1.5707963267948841,-31.64857858389129,0.05367655662430294 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark13(-42.49010269164048,-1.5679116341028783,-1.5707963267949054,1.0 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark13(-42.49012355590884,-1.452020227552019,-45.56831641460265,-0.030163767262476347 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark13(-42.51218939859097,-1.3374974026028965,-101.8968486177364,-1.0000021770172562 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark13(-42.53703899640819,-1.2171977013948938,44.13789146798334,51.37356032511525 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark13(-42.547028916627156,-1.5707963267948963,33.20361007695183,-2099.1808213098952 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark13(-42.606618518362005,-0.8657868348601845,69.47949466856352,0 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark13(-42.621711522310775,-0.47491875550187146,-88.46877076784725,92.63859788688367 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark13(-42.767238837399596,-0.19913194507764606,1.5707963267948961,38.89671873447875 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark13(-42.77842091377067,-1.5065537768367416,-1.4506070652615406,2.3408381773460992E-97 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark13(-42.80256372140119,-1.2105142032913643,-42.98623121324769,1.0000020830299672 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark13(-42.839368366680134,-1.361179878120616,13.804152120472144,-0.01121503239705822 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark13(-42.93475486226752,-0.602946864811448,19.20168287566408,-3.4211388289180104E-49 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark13(-42.95830154256777,-3.552713678800501E-15,-86.37583091409871,29.88520090483099 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark13(-43.00888630556832,-1.5707963267948963,9.989215867578993,0 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark13(-43.01594686146983,-1.3810007454402378,-52.623743778791614,-26.834061893823254 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark13(-43.04267224872807,-1.4326894596893365,-84.36013634422294,-1.000000000000007 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark13(-43.073265155811264,-1.5707963267948948,-18.362560964061057,-1.0 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark13(-43.08984471750234,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark13(-43.12183521470218,-1.5707963267948963,1.5570562443003402,-1.0 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark13(-43.170209106333964,-1.4935433795043078,-35.2143447124855,0.19527409530324547 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark13(-43.23755873693243,-1.3890784135694147,1.5707963267948966,-85.69148506220685 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark13(-43.259181106172285,-1.5622006783342994,0.0,31.225949536494 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark13(-4.333149200120047,-1.5707963267948593,-71.54781424061314,2389.8287468929802 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark13(-4.3361955061340005,-1.0587446953502966,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark13(-43.438252837226194,-0.8825754752638539,-0.22613312034411198,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark13(-43.5530986090369,-1.2311187251782987,-1.5707963267948966,0.7321707751326856 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark13(-43.638756618888834,-0.46383883744854054,-26.329461019069356,1.0 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark13(-43.665066302308404,-1.4806481177295996,31.63524502911526,-16.78145895040133 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark13(-4.36660429918517,-1.548744843043623,-90.19632989993582,-2126.161749112171 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark13(-43.6998725955087,-0.4290379551319215,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark13(-43.729213139552215,-1.5707963267948957,59.05737154294553,95.8769319636269 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark13(-43.794666567022404,-1.0033675647503073,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark13(-4.38817909740513,-0.38282135725862826,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark13(-43.94105489802028,-1.5707963267948948,32.9158325343052,30.81647660378726 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark13(-43.94919085102651,-1.5707963267948948,69.3109583105873,-49.5004602112371 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark13(-43.98385659093848,-1.1837159296146407,57.38515753299614,-1.0 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark13(-44.01522588106534,-1.3461785258230223,63.18844441533992,1.0 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark13(-44.027691594895714,-8.881784197001252E-16,-49.57324894610454,2366.717000019958 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark13(-44.07138255303429,-1.5707963267948948,-9.493693467967029,86.27897725183871 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark13(-44.10433058689989,-0.9734603869300621,72.0780575941298,0 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark13(-44.11611866544646,-1.5707847281245468,20.102285889613917,-0.995834581040639 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark13(-44.11735311047277,-0.3937110574874436,-31.33225460330151,1.154122327223217E-128 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark13(-44.13588962616141,-0.8585033990280991,56.954361065848765,16.098393807905467 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark13(-44.18368712332231,-0.7865238234559762,3.0265526206687703,1560.3117220736742 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark13(-44.18581450520461,-1.2893290480644157,-66.71369528280522,60.82388551543212 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark13(-44.19525000383978,-1.4649495570024003,-8.123529934916121,-0.9425606858585645 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark13(-44.208514711941056,-1.185072828804575,77.78404730508055,-31.814852444364945 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark13(-4.4256161463898565,-0.5553848712352094,-15.78439344454965,-1.0 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark13(-44.27193004182381,-0.7012910873668212,1.5707963267948966,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark13(-44.33462374504613,-0.2236899284400622,-69.74832993268677,0.2539261679785818 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark13(-44.367129677033994,-1.5707963267948957,37.895466041300025,0.8970580016242824 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark13(-44.43361747247643,-1.4760792861753655,-1.5707963267948966,-0.34677184109705195 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark13(-44.45106654396104,-0.8474108490079307,-38.28988228900068,-2.0303534698525194E-115 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark13(-44.45604217546215,-1.5266184385744717,-73.77049636195842,-0.0625527009383196 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark13(-44.55903758142224,-0.5667615531743841,-44.195046766839255,1.0 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark13(-44.572282102730405,-1.0656873172829,-122.78635370636755,-0.628621930665999 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark13(-4.457866417488777,-1.298426764875569,-76.1184046252568,0.05610357402072941 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark13(-4.460901404067829,-1.4770144843574902,25.774583422691244,-1.0 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark13(-44.631443262638655,-0.9325837467850621,13.064179708827293,1.0 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark13(-4.467760423073438,-1.0089819513651748,6.421323059722487,0.6271006733959885 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark13(-44.69508096745541,-0.1730720831853887,-100.0,1.0 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark13(-44.71571136009387,-1.567757607745217,0.0,-76.74632945231534 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark13(-44.78978754829925,-0.6958969628723501,-1.5356948591695498,-40.57106296087336 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark13(-4.484026133360205,-0.0032277040494406157,6.581648599227592E-4,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark13(-44.84975165173051,-0.37914901430654613,-6.894250486158371,-1.0 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark13(-44.91745661619946,-1.4964794923215565,2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark13(-44.94503604168577,-0.05147449946840411,1.0899514570044797,-1.0 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark13(-45.02410962861602,-1.5502805720902968,0.0,0.06224337049736848 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark13(-45.03394670741015,-1.452387398661358,-66.03881535229259,0 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark13(-45.0536146870953,-2.220446049250313E-16,37.930852569847964,50.54659570494951 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark13(-45.07595749710413,-0.47089730019325277,0.0,0.9910133794505375 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark13(-4.508726876664902,-0.030643742166191517,-94.14580241259596,2.220446049250313E-16 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark13(-45.11050020421545,-0.46213555767535297,0.0,0.2076751870445328 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark13(45.12466443541544,73.8718021692222,21.516308146011554,0 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark13(-45.25610908649025,-0.21212339339822672,-74.63627003934104,-45.8863318824483 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark13(-45.270597980306896,-0.9038866502598538,1.3747368454769036,0.05097733057438569 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark13(-45.276617071112504,-0.26354542504382467,-1.0469262802679666,-18.826701586313213 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark13(-45.48605258431441,-0.2151046996710766,-32.564273705857325,7.31511930420656E-99 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark13(-45.64055087857386,-0.5282192915481974,-37.13719024580311,-1.0 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark13(-45.6795650872785,-1.1603460064842013,-75.39769161113003,31.580165683441408 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark13(-45.70911602185581,-0.8437611971435494,0.0,-0.8323925318227756 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark13(-45.7253250540081,-0.7143886868921439,-62.11348399556409,-1.0 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark13(-45.74814027335873,-1.2658511649258626,45.00432303769784,0.1585422102014994 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark13(-45.782372298752776,-0.6199755209965097,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark13(-45.80500743672502,-0.5661998176188854,-23.40105615151315,-0.7139772939264104 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark13(-45.82402586262605,-4.440892098500626E-16,1.5707963267948966,-78.30352858577272 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark13(-45.85644319600574,-1.308543086045833,-62.533314098657385,1.0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark13(-45.919310270496986,-0.04494273198463422,76.45386127228382,1.0 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark13(-45.96670956343094,-1.5707963267948912,-89.61866127198364,-62.36374225043717 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark13(-45.999733106716896,-0.9053177934998677,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark13(-46.06619524997537,-0.21103078383971718,7.766985429234225,-0.36223205819869875 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark13(-46.068526011659,-1.5490318151544487,-136.22471216525878,0.9999981048217956 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark13(-4.61387508124242,-1.5578246093133612,-0.5880184479982932,-1.000000330853552 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark13(-46.214930504715824,-1.5088204536731613,-9.54584616828365,-9.205460328303063 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark13(-46.218090661130205,-0.11391909061911965,0.0,-33.777906910974096 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark13(-46.26042312923184,-0.2638588779132629,88.30191684674836,-9.505722958937618 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark13(-46.261696534814064,-0.49499977385015215,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark13(-46.29044935760451,-0.3148841325898205,0.0,-8.199723071873706 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark13(-46.308974051116046,-0.3133785273422771,-46.22150497229909,18.14873276969982 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark13(-46.32023280189943,-0.03316718096705704,-66.47409936141781,0.8987922039634708 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark13(-46.348712568221515,-0.0811011264523249,45.314345054670596,-0.8543623827762745 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark13(-4.635663249994245,-0.6304185396691498,-96.47014236269152,4.316251084871951 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark13(-46.47831436605064,-1.1247332672243857,-10.796218742491522,-1.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark13(-46.48839098832542,-1.5601054666197987,-5.842018221766182,0.0 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark13(-46.490949703486706,-0.5584689288709237,-1.5707963267948966,4.552109992493186 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark13(-46.50325471329832,-1.2127603635747657,-88.35951323523425,1.0 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark13(-46.598503097663084,-1.5707963267948948,15.22412502583788,-1.0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark13(-46.60836057221343,-0.983666509256313,-89.93350431162435,-1.0 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark13(-46.6167706436093,-1.2852671922656311,-44.437923528805236,-1.0 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark13(-46.68789442281689,-1.0355940486595188,158.18255484065122,0.9999457327941107 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark13(-4.676498474291294,-0.23853266236821574,6.699140732766063,0 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark13(-46.78360543982119,-0.4934380865129593,-97.50281288052713,0.0583425591749848 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark13(-46.808872471364054,-1.4360958467740559,-44.44811179482228,-3.2944368572595385E-83 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark13(-46.844896693450195,-1.5707963267948957,-76.61160309890576,-29.43623041827243 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark13(-46.911903470864395,-0.9619625680702661,-74.32009791281617,1.0 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark13(-46.93009936742008,-0.2751865544686798,32.48553167830899,61.729397338001945 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark13(-46.933801498130606,-1.1684844688337854,-21.81220714667453,-0.9999999999999998 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark13(-4.695700621539566,-0.21759312087495258,-59.1977893005625,-1.0 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark13(-46.96380607962114,-0.03454683173124452,-33.063002248940336,-0.8516989318929028 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark13(-47.00273581731284,-1.7763568394002505E-15,-4.993150848696089,0.2551906390680546 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark13(-47.0188288823254,-1.5707963267948948,-1.7763568394002505E-15,-17.95101502044514 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark13(-47.03713784426686,-0.10357715952464241,-100.0,0.9999999999999993 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark13(-47.062793829425665,-1.472113045818471,-29.62228676584779,-12.431791179587464 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark13(-47.140759245976035,-1.5707963267948948,0.0,-49.52949920361496 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark13(-4.718688601260528,-0.6681225190012331,-48.070733308339676,-0.9999999999999997 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark13(-47.21539407204869,-1.5707963267948912,-13.957524297788211,35.94503431806746 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark13(-47.28493117633097,-0.4498042216510223,-87.38109593118682,0 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark13(-47.31333937411057,-1.3137027651409123,-39.363545806021975,0.5038053006921057 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark13(-47.332878212983346,-1.2853573075199964,-3.608479517861244,-0.933667061920104 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark13(-47.41193120653699,-1.5698715118435675,1.5707963267948966,-0.02941589657881588 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark13(-47.55137028054439,-0.9645409064282663,51.450932501549104,1.0 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark13(-47.575622456122545,-0.283488671241809,-11.121130282342833,57.71877902078532 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark13(-47.5972275470538,-1.1406058774024166,0.0,1.0 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark13(-47.63383449599162,-1.5707963267948948,88.34884507457546,36.58420433639148 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark13(-47.66094441630382,-8.193351085769363E-4,-37.72317969093639,0.09539332938489364 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark13(-47.74499691571104,-0.07799290986153619,-61.40377147405533,-1.0000000000000142 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark13(-47.75532361772515,-0.727102619105179,-18.348556015867963,59.78396606952404 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark13(-47.77809551577619,-1.3324837697426726,88.17887309974557,6.931106654256155 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark13(-47.81754370186142,-1.0343938412231835,-39.183517490510326,-21.602757226378714 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark13(-47.837217122232204,-0.14845208801386978,0.2621831697122533,-96.53444170501061 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark13(-47.87209821073111,-0.16601839139816588,-54.96464898089609,-0.27752233829281003 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark13(-47.93082868431574,-0.24544615214203652,-1.565416836341714,-10.271359532447963 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark13(-47.93904709904429,-0.04118848642483727,1.5707963267948966,0.35256189307426355 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark13(-47.94805179152917,-0.8404096121531623,-76.57035196185014,-1908.4219212726807 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark13(-47.95111585409923,-0.7203270549555493,-27.792969348973187,0.8701240513990421 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark13(-47.97586069723973,-0.37129773097540647,-73.53742837308005,52.24501086573527 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark13(-48.03090378887677,6.432502447538071,1.5707963267948966,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark13(-48.132804954558765,-1.5707963267948963,15.213817666400825,-22.689187469450793 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark13(-48.14708389117624,-1.051704460453152,-38.972972490530175,1.0 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark13(-48.14800078242838,-0.44351729180889343,-86.24384098258717,-1.0 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark13(-48.16651376637141,-1.1102230246251565E-16,1.4491817535791578,-1.0 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark13(-48.20147823252471,-1.5707963267948906,-1.0525277741152639,-41.084633461400585 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark13(-48.23776439520746,-0.07442060965914485,-100.0,-82.08704066879085 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark13(-48.32122301483428,-0.19295372931281596,37.70160862162973,94.2437105827006 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark13(-48.33090373724544,-0.0010770189486614932,32.89876878738582,0.4134695917054848 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark13(-4.833270101938737,-0.09420856955097046,-34.38144773533956,1.0 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark13(-48.34189613585187,-0.7831495074938495,-0.5671594546111487,1.0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark13(-48.369943299249776,-0.6020940568711146,-1.1184746041903557,1.0 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark13(-4.844419634250293,-0.18299691600083412,0.5086779107876516,-1588.354971324255 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark13(-48.48004225075856,-1.0162860279923738,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark13(-48.52223589284503,-0.0024550498577023045,-37.32393888766697,0.9999999999999996 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark13(-48.624930457327366,-0.35798516018486914,21.402385789657792,-1.0 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark13(-48.702585138036326,-1.5707963267948948,-85.88413769613696,-1.0 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark13(-48.7878881882126,-0.13819060210980405,-48.820750547328515,-0.9999999999999982 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark13(-48.852669608787465,-0.715422669965709,-55.157913824054106,-0.9560570223638161 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark13(-48.858268504940185,-1.5707963267948912,0.25215761164522776,-95.72359399484314 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark13(-48.93749936831286,-1.0874487306460647,0.950671436779789,1.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark13(-48.946030460666606,-3.7035263519507943E-4,1.182752857555616,-47.057850930145506 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark13(49.05327092410488,5.427468764083528,0,0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark13(-49.09395536159549,-0.110823050373492,-28.533546026055195,-1.0 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark13(-49.255155551955845,-1.2170294178968957,0.0,-71.57637059749185 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark13(-49.27458339672613,-0.7717153817131701,45.2572918315997,-1.0 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark13(-49.390236703884376,-1.0210739714799661,-99.03045030501214,-0.06264731439433437 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark13(-49.39836277742781,-0.29842563884765916,1.3171595781429937,-1.0 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark13(-49.46412342051705,-1.359346864235441,31.955393939365962,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark13(-49.52718966639218,-0.8289690724078878,-22.744350506289276,0.0 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark13(-49.57235789371681,-1.5321325033489945,-1.5707963267948966,0.17863771471884773 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark13(-49.64205915178068,-0.6212325764214768,-10.584950168164557,0.0 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark13(-49.67068235691974,-1.5707963267948912,69.6865481387494,1.0 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark13(-49.69864100810855,-0.3310917735320198,-0.2719953540438714,0.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark13(-49.716052906009864,-1.5707963267948963,-48.13306116629037,-0.7331542089499734 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark13(-49.7200541345701,-0.5228140746189046,-95.81441035989278,-1.0000009240322345 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark13(-49.741947429947814,-1.0099616830509566,-6.031724665294676,2.1175823681357508E-22 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark13(-4.975007375700962,-1.452722749095279,-1.5707963267948948,-1.0 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark13(-49.79546651064566,-1.2530256370573292,0.0,-53.08797711483896 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark13(-49.808104014535004,-0.28849115997092767,-1.5707963267948966,-15.013465132699023 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark13(-49.860390513682965,-1.0383206443400055,-89.16453234871547,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark13(-49.92593175502209,-0.35403592575690035,0.0,-0.30032313273618605 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark13(-4.993339105639755,-1.5707963267948963,-5.0697891938662405,0.20606270778211844 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark13(-50.046189395741514,-0.0644364697073031,0.008599204603391395,-1.0 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark13(-50.10702971188408,-0.6369922421622469,-40.4568990627973,0.05314439571118612 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark13(-50.17905269710323,-0.9516249936120329,-1.5707963267948966,62.558747039993534 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark13(-50.183033121802,-0.09226415188315128,-75.08084627578852,-1.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark13(-50.22589795427734,-1.0956530049111048,57.46281463086481,79.1901230390236 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark13(-5.027076645103747,-8.407006157137853E-5,1.5707963267948983,0.4757826170407622 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark13(-5.0273227258931,-1.3337647420845253,0.031186660994153414,0 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark13(-50.33165253442813,-0.6724826174888414,-1.1582163379152166,53.41699244485249 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark13(-50.47336305684665,-0.393658787925105,-57.43594869051793,-0.011825505429089167 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark13(-50.528120080215054,-0.17164986878468447,-48.732263879407675,0.06255325433193307 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark13(-50.54982871633783,-0.5133287282769043,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark13(-50.59221356851019,-0.6992171885259673,0.0,28.22934733220214 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark13(-50.60375191522612,-0.9984380083353273,-21.523835879958817,1.0 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark13(-50.60756243151888,-0.2598576999709197,-96.07744086110571,-0.7803209447111581 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark13(-50.67264354877083,-1.471765447067491,-0.5046934536613179,4.930380657631324E-32 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark13(-50.679269505245514,-1.2105491121687484,38.73536097882501,-1.0 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark13(-50.684887281823436,-0.07936885874644185,-38.7347997252097,81.27221592226388 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark13(-50.698366954326175,-1.566235662026809,1.1640459719338512,0.10787633078419079 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark13(-50.755957653865586,-1.5707963267948912,76.17619961903489,61.98600017937804 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark13(-50.75910254944719,-0.24869023838763127,-80.47941798992078,90.18714787440393 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark13(-50.76690961201561,-1.168416018240897,0.8566224943256077,0.726265697744169 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark13(-50.79583384528216,-1.0114790870927222,32.72030960566667,1.0 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark13(-50.861357008953824,-3.552713678800501E-15,19.82667789768155,18.910471609753117 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark13(-50.8713516954955,-1.5707963267948961,-29.73412572629332,0.61010220019029 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark13(-50.88588648307646,-1.181812516145909,-12.899910466310338,0.3503669116739756 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark13(-50.906288219018286,-0.10987820354293196,-31.695646036182538,-1.0 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark13(-50.97281536922241,-1.5707963267948912,-1.3422379068902472,0.9964612122501184 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark13(-51.039383653677945,-1.2027744237111546,0.0,4.843515844916466E-16 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark13(-5.117107725752529,-0.31482655697927775,-73.74629833080874,1.0 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark13(-51.1753139411665,-0.24030524113312976,0.8987444507996294,0 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark13(-51.36614989186239,-1.113070708807328,0.0,-0.143114241648568 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark13(-51.372399506693014,-1.5707963267948912,-95.81065366000425,78.17472438109178 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark13(-5.139675639114415,-0.6410623572753664,-17.910012939037188,0.03977778351865679 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark13(-51.40797176142299,-1.2289762404238238E-15,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark13(-51.41071916901996,-1.0142501027619057,0.0,-1.0 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark13(-51.450903965626225,-0.13359831583155693,-9.819436046595083,35.92624765020091 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark13(-51.47301467991066,-0.6050526627939756,9.147100445862065,-1.0 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark13(-5.14809448269794,-0.31812547741675457,-96.08591450566821,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark13(-51.49052340060996,-0.777620764680996,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark13(-51.518930145591405,-1.5707963267948912,-1.5707963267948983,0.7691892939141272 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark13(-51.5304659343035,-1.5707963267948957,1.570796326794703,0.0 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark13(51.54943754386042,-8.172449768139757,11.20874697530698,0 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark13(-51.55365759064218,-0.4051234531058858,-36.2845895257992,-46.70555451930881 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark13(-51.578918556514566,-1.4877387298441853,90.52371575823834,-52.62815783576272 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark13(-51.71572316632446,-0.37145787670642694,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark13(-51.75389183159992,-0.10812424900935724,0.0,56.14906391657264 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark13(-51.777375651928025,-0.29493739307976075,58.809369634180854,-0.02711605328491662 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark13(-51.8725121891964,-1.3115580013467465,-45.43394409084486,-0.7317373770439994 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark13(-51.87616440280499,-0.020342295136779542,-55.843645911642646,38.56668782781544 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark13(-51.91107296131876,-0.9894013179882477,38.41848699617387,16.548963562260425 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark13(-51.926081742853754,-0.5597695500475764,-77.44721894980424,-1.0 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark13(-51.93544970818938,-1.0812696777165443,-0.046947108706507604,1.0 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark13(-51.97046051378739,-0.7172721611718125,1.5707963267948966,44.72920536000458 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark13(-51.985577125147444,-1.2260533634706898,-32.73451932148993,1.0 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark13(-52.05973474429192,-0.4050582087501607,-93.25626401138838,-0.5634548121899683 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark13(-5.208495292179798,-2.220446049250313E-16,0,0 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark13(-52.10828130186978,-0.6674785800645857,-74.29587092344146,1.0 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark13(-52.154077370060854,-0.8069620052692661,0.3441184013964136,-21.061396800256414 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark13(-52.231157370123036,-0.5530928517251856,0.6968829720757356,-0.9999999999999929 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark13(-52.3664841995785,-2.220446049250313E-16,-56.310088150787195,49.68860709989204 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark13(-52.386063247137066,-1.271336382243846,1.4813948466478883,0.0 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark13(-52.45833074957672,-0.5633743415792098,-73.68478144810558,-21.457829073749977 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark13(-52.47304040597014,-0.8455753360180083,-4.2809561919446395,0.9999999999999997 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark13(-52.52890131116624,-1.064636326731984,-52.95385775648982,-0.7346698236869224 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark13(-52.59918790271339,-1.5081054391083306,0.7229787839774197,56.384486100647045 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark13(-52.67061051395468,-0.10381964671785217,-0.7040773629737257,-49.69690356680482 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark13(-52.671186742309416,-1.35281803866159,-94.28810107909266,1.0 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark13(-52.69515504913724,-1.0472066490362184,7.617723151138922,0.045205730353607754 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark13(-52.7172467918828,-0.31896637151683205,-58.25314073872158,1.0 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark13(-52.75726455943435,-0.18148218071377814,-7.01237649432673,59.12778784788745 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark13(-52.787228257369996,-1.5707963267948912,-1.4677144356070213,1.0 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark13(-52.79966722918997,-6.267786609038504E-6,1.5707963267948983,-0.054631290500831264 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark13(-52.80279898025496,-1.5707963267948948,-0.12464441115142977,0.013582588778773014 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark13(-5.283017280491329,-0.04164250053187657,-67.44158636345323,-8.851627428812662 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark13(-52.92249143703232,-0.1493960647411745,1.5707963267948966,13.436538187553726 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark13(-52.978562844362564,-0.04956716895916456,-11.19785362721666,0.2612001324888016 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark13(-53.090821063656776,-0.0722480795695477,-30.720820225999162,-0.047851007813279875 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark13(-53.125005878571166,-1.5707963267948877,52.523940584498746,-0.48659472476856647 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark13(-53.134474577919086,-1.1095646266967523,-14.833120673509399,-82.6821162016314 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark13(-53.20200096435346,-0.2726724484765626,0.0,-68.58031185568122 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark13(-5.326002855564429,-0.04228299490690435,157.12521983677775,73.7143978034415 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark13(-53.41250558121203,-0.45094794778121794,-28.45723668851506,-30.1145931365595 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark13(-53.48000935840498,-1.5707963267948963,-100.0,1.0 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark13(-53.669671906115376,-1.0854154822807738,-51.58991745151154,1.0 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark13(-53.71644217980516,-1.4576026939006506,-1.570796326794897,0.0 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark13(-53.71703710651457,-0.3006490696257653,-75.09244180634798,0.0 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark13(-53.85368880383753,-1.085068572636068,0.0,0 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark13(-53.88364281032063,-3.552713678800501E-15,1.5707963267948966,0.9457930834377928 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark13(-53.896634927684744,-0.2811400765930581,-91.19539426096469,-0.013403163954906538 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark13(-53.912524959120574,-1.1849608377075527,-60.00798457344152,-1.0 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark13(-5.392018062094803,-0.1311705344453431,-1.3987888548269423,-1.0 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark13(-53.922328414944005,-1.513220054733228,-59.82592615290228,69.78909703728435 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark13(-53.96515920169397,-0.05064350092176573,-58.44480873233767,6.508168443843715 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark13(-53.97988394881915,-1.1372904698854618,45.063756206803056,-0.0010614775533921428 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark13(-54.07446116776701,-0.9188641532401027,-33.80934885137012,87.46837303160768 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark13(-54.07924745565316,-1.313136507783938,-100.0,1.0 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark13(-54.082419708857294,-1.5707963267948952,0.0,1.0 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark13(-5.410194387112185,-0.00895739341861577,0.9697394094775262,59.98554134423121 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark13(-54.140298674063665,-0.5580423441399501,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark13(-54.16395695114345,-1.3824235758566878,-82.91492529837879,-93.9533724064058 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark13(-54.184598942367,-0.7252837144309341,-76.318349592822,-0.7865088437999066 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark13(-54.2354978771272,-1.5707963267948948,-65.36792089913008,-0.1556976794383543 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark13(-54.40402997718679,-1.1497570975289266,-100.0,4.424186157439689 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark13(-5.4521017708099695,-1.157030315058293,0.0,0.0 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark13(-54.61456436939561,-0.4459466389701348,-100.0,0.06255252950120119 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark13(-54.621352230507505,-1.5707860469494843,8.881784197001252E-16,-0.09340057329109464 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark13(-54.640909545537916,-0.05732748993628202,-75.19404477337193,0.05346475174947332 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark13(-54.65639499122837,-1.346244986505457,-53.67305707046137,0.0 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark13(-54.66990719583002,-0.16863293759350978,-0.973954589926535,1.0 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark13(-5.46710447592605,-0.3799168915124185,-67.05510638804311,-33.640521397540134 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark13(54.73797018781937,-6.412762241794795,0,0 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark13(-54.73949821018146,-0.004380949845208093,0.0,-1.0 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark13(-54.803255420240575,-0.9555272098657319,-14.275962807214604,0.28522153265676775 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark13(-54.81074927475395,-0.24180589610969208,0.21316551619166058,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark13(-54.83013936008539,-1.0246209026988018,-4.228482889509625,-1.3177747429038154E-82 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark13(-54.854679192250124,-0.4756292945609929,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark13(-54.87920976670546,-1.0367740541102282,-96.92989353517864,1.0 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark13(-54.88404793318707,-1.5145123582808915,2.9151320890048282,0.05421608515493992 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark13(-54.90154394164993,-0.9940573183960408,26.310051840412527,-0.06361596607021272 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark13(-54.907731900147496,-0.18943200261704934,-4.808930955390878,1.0 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark13(-54.94703523634258,-0.8316752422757783,75.43874507111039,1.0 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark13(-54.95920398205967,-7.105427357601002E-15,-1.5707963267948966,0.9999999999999996 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark13(-5.498574298217948,-8.881784197001252E-16,0.0,-1.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark13(-55.02631763303913,-1.534135403857922,0.45352098021063725,1.0 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark13(-55.02917207098771,-0.8886628680319694,18.91499508324553,-56.985891611728135 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark13(-55.1653631726966,-1.2373213335316002,-1.0727100188413332,1.0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark13(-55.235523525626945,-0.3032352171787798,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark13(-55.244404526507935,-1.148793153836039,-8.311416044243412,80.20761506260126 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark13(-55.26417309030783,-0.6449439957787776,-85.96759663251366,-0.9135940016443924 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark13(-55.294243843398505,-0.22627829617312045,-1.5707963267948983,-7.1595140196766 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark13(-5.531248513742067,-1.401450676359209,-130.17439035821923,0.6518400537076801 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark13(-55.379034494334945,-0.1994137184203607,-5.411923382901483,0.8487061726233522 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark13(-55.49955335387821,-1.5707963267948912,-53.367666246003125,1.0000000000000009 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark13(-55.50440747976776,-0.024582233816939685,-1.5707963267948966,-5.556896873712694E-163 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark13(-55.72181796256725,-0.9561048262819358,-71.47349452785785,-1.0 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark13(-55.748033416797625,-1.2466314691894633,83.70850384492844,77.43434098616305 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark13(-55.757946246660325,-0.1530006331944498,-13.356520657913201,12.977572329506899 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark13(-55.76872208126196,-0.900026420724445,-17.69674310234305,-1.0 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark13(-55.775992864425355,-1.4469178141158048,-99.99876334123991,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark13(-55.79283578533041,-1.5707963267948912,69.24623202324271,-9.590108274191335 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark13(-56.00094052098737,-0.4816834488044677,-123.82125018985381,25.86872972097727 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark13(-56.13655132640133,-0.08788597672588541,-19.02889932648557,0.0 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark13(-5.6181117890607055,-1.2351793383127847,64.63359547307225,-36.61093410891652 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark13(-56.1812673382136,-1.4289752352370613,-1.5707963267948948,-1.0000000000000018 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark13(-56.25861173435708,-0.7257893534519726,-41.0036327608812,-49.80463326714512 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark13(-5.6275293188833455,-0.020337406293146672,31.726247388656457,-0.8114882885996053 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark13(-56.28410899419983,-0.6991831064655074,77.73569141558187,-2139.83976937177 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark13(-5.636378824567151,-0.5209799098468677,-9.220860932945982,-1.0 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark13(-56.389322170245016,-0.23917501866051794,64.23478738952389,0.6758067057502108 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark13(-56.39295753497784,-0.329318734201002,-1.5707963267948966,-6.923321125012792E-15 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark13(-56.40079668070294,-0.16680472338217134,0.0,-0.6011009552297487 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark13(-56.429277018511954,-1.5293474152866053,-7.76229201022799,-34.76429029333192 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark13(-5.644550493743966,-0.3560717135975727,1.5707963267948966,0 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark13(-5.652502723167329,-0.08307949340985113,-12.011197781750965,-0.1987048821179609 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark13(-56.608585308284205,-0.8152713960945358,-72.69065201631656,-1.0 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark13(-56.73361212355974,-1.4850235397743603,51.57621726374177,38.171284658351254 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark13(-56.76159602953029,-1.8565746953694223E-18,1.5707963267948966,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark13(-56.76577713780168,-0.5511641273544051,37.779707770937506,-1.0 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark13(-56.83188345712718,-0.09279396447807614,1.5707963267948966,-0.49160945573497195 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark13(-56.85827316280172,-0.021970052850789346,1.1888614135126971,67.8689396577566 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark13(-56.90610827117098,6.595265651462129,1.4444246945483163,-67.17502061370678 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark13(-56.95277689023884,-1.569925326799357,-62.845664319868575,-1.0000325443049571 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark13(-56.98532225731732,-1.5707963267948335,-1.5707963267948966,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark13(-56.98710016092944,-0.7429546701401197,-1.5707963267948966,62.426143050274725 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark13(-57.002163526930396,-0.2129248951165738,-100.0,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark13(-57.109140951859054,-1.1685791714859397,1.5707963267948966,-0.9907013378333505 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark13(-57.11170846464184,-1.4464686313093866,0.0,0.8208362391531958 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark13(-57.16677795820289,-1.0308570375265076,-58.809680401740124,-0.08892549970497154 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark13(-57.19865217115911,-0.26473206033176666,-122.60270054021679,4.0766669893646315E-7 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark13(-57.24504795472203,-0.6058642262020584,-73.46752400922438,-9.045580941523633 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark13(-57.24985413961872,-1.5707963267948963,0.6835975842484958,49.1051713422975 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark13(-57.255774767176625,-1.3809139189721142,-1.5667719669671103,-2.710505431213761E-20 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark13(-57.265830033643105,-0.8711411024444883,-57.44221581023037,0.9837659757376847 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark13(-57.29796482827218,-0.8603757841477495,-89.07393001849152,-39.19693110838087 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark13(-57.315906263811826,-1.2379860829657094,-1.423356269863529,-0.9671108803574882 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark13(-57.44108587267919,-1.5707963267948961,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark13(-57.46052769864791,-0.5424712546815282,-94.17899417217126,1.0 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark13(-57.51031474614788,-0.408203970032913,-1.5707963267948966,66.71370661448735 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark13(-5.754533203202687,-0.2620352335379579,-64.0751274456929,-1.0 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark13(-57.55323442020514,-0.7583571195305172,27.266498562454903,-0.9761680264368229 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark13(-57.557971221937095,-0.732026444342277,-4.411606655050381,1.0 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark13(-57.5649134840596,-0.1325601741378859,-4.6514569413338815,-1.000000033072271 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark13(-57.56619869125601,-0.4357614994268442,-37.484570731829805,-25.589764706333774 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark13(-57.59521476505667,-0.6512794484013754,1.5707963267948977,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark13(-5.761537815174499,-0.618439499278786,0.12329235968499441,1.0 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark13(-57.66964211112157,-0.9694699680165044,-66.35390913077973,34.37900211390321 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark13(-57.68577888106983,-0.6824819682421346,-92.96698571924945,63.30692365828902 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark13(-57.751685254760375,-0.17537255649105757,-1.5707963267948966,51.9542187348918 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark13(-57.77488626306172,-1.5707963267948961,-32.5034983434701,0.8160001026766278 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark13(-57.80778891400509,-1.5707963267948963,-30.23015598600418,-0.7865927275902349 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark13(-57.83221222210994,-0.795501620722316,2.051265779859108,155.56400511087975 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark13(-57.88868426845185,-0.6264317581752178,-23.10073597812059,0.0 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark13(-57.90599233173107,-0.2709688947284121,-28.440299420252465,80.39092259557265 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark13(-57.94065819274691,-0.25648443254069825,-32.96237248854929,-1.0 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark13(-57.978956260111474,-0.1570633488826373,-71.39367512489835,1.0 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark13(-58.00021080900908,-1.1262953468647725,-1.5707963267948966,1.0000000000000002 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark13(-58.02766932922561,-1.4308619599074908,-0.2235886266649768,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark13(-58.03711411916899,-0.3222026863071945,-1.5707963267948966,0 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark13(-58.11456799084998,-1.5707963267948912,-84.71858448657062,-81.18829069987466 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark13(-58.153855815517964,-1.5707963267948593,0.0,-100.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark13(-58.19533795939027,-1.5707963267948912,-73.70505613163243,93.2461085620541 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark13(-58.22356762947046,-0.9957637155041434,-11.414940888415341,-0.038494787988583135 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark13(-58.26695145433084,-0.12944692873006944,-21.684631114630722,-1.0 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark13(-58.27186753528113,-1.5707963267948948,6.59323358444108,-0.9938322778075698 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark13(-58.302333952750836,-0.8179401563677928,-75.28605676472819,-43.82266253412982 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark13(-58.338311045336006,-0.39291057725603235,-75.67983994106066,-0.9999999999999999 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark13(-58.38659219226074,-1.444199713318946,1.5681405707988416,0.03618079128399804 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark13(-58.40174728256516,-1.4091548494511803,-0.19898806234205205,0 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark13(-58.40260509783937,-0.5772585461806949,53.33717116264714,-0.011721622625404958 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark13(-58.4586552034164,-0.939894207694171,31.82198861792159,8.162487759712306 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark13(-58.48616425530209,-1.5707963267948912,-55.34217523945898,0.7985739926150046 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark13(-58.5050818535012,-0.35032735618085525,-0.49322053744828676,1.0 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark13(-58.55093209411669,-0.035271174725298844,-1.5707963267948966,-14.757748834596205 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark13(-58.58835659947259,-0.16676640493635142,-9.3713424869905,28.282359695656368 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark13(-58.60107965688993,-1.5707963267948961,1.5707963267948966,-12.417273979242118 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark13(-58.608340802442804,-0.8307815537986964,-76.37992089124734,6.938893903907228E-18 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark13(-58.67536336676888,-1.2238083991972575,-72.69792424820919,0.06991684277589166 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark13(-58.71335401550777,-0.5148671260905413,31.578845766920267,1.0 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark13(-58.728248040186344,-1.0181427909300111,-8.64750719759877,0.8752784083208347 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark13(-58.78055856613125,-0.8944181164985814,-77.24156263582371,-80.65188755729835 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark13(-59.03402307388096,-0.5658659721432436,0.7747814930814954,-52.4108439790763 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark13(-59.05238251785732,-1.052644236752183,-0.5059271477985746,89.81014183051971 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark13(-59.09893839301336,-0.5261019484808003,52.72631645055742,-0.40163139621306243 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark13(-5.916725718069329,-1.5400780838816546,-17.976317690095364,67.71908900489586 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark13(-59.18327561528994,-1.655651925532532E-5,0.8219209420346829,-0.7461663085528079 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark13(-5.919601909115487,-1.4501892237084621,-1.5707963267948963,70.36722453898874 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark13(-59.26990181457148,-0.050590559945453875,-88.47661021225949,-13.061664841502655 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark13(-59.31806480306294,-1.5473139581166153,32.014430327357445,-1.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark13(-5.938566751993605,-1.0229950184211987,-91.18262935557667,0.0 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark13(-59.435901522693015,-1.5199619203948782,-0.2782372232172563,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark13(-5.944641362927693,-0.4536275033389421,-8.85027997332475,1.0 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark13(-59.57198806169201,-1.101522774675262,-89.0171683285797,-0.8942708817595578 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark13(-5.961923901529516,-1.4659974454380946,-17.44777089098521,-1.0 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark13(-59.670484981295814,-0.929674796883297,-9.642323729392961,-0.02437454760209956 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark13(-59.70600864370565,-3.8621215196399324E-5,-43.11139866604639,-0.010485891177853108 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark13(-59.76207955544439,-0.19739578899534882,-25.229921956224814,-2.1300115693306196 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark13(-59.78511947974915,-0.1824446843631614,-4.729945251313973,-0.8746791393237556 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark13(-59.82863660923406,-0.05093184009335516,-93.18872261072022,11.564050388751667 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark13(-59.83492211606425,-1.2229089637524164,-0.6585350081182451,-1.0 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark13(-59.876155521113304,-1.1541909227263865,64.88406391937517,-1.0 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark13(-60.000925305712386,-9.901777672321864E-19,1.5400630584685702,-2.2227587494850775E-162 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark13(-60.065792163378305,-1.1098798661284701,157.5563442606151,0.0015874077835524858 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark13(-60.215189556839775,-1.5707963267948963,-7.219714887969875,0.1340564404856952 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark13(-60.2549984738351,-0.018571333648795846,-88.68322041768828,1.1270963180143632 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark13(-60.31805673831579,-1.2426680572354067,-79.13006753051555,-1.0 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark13(-60.424285042023016,-1.5707963267948912,-30.244943868982148,-1.0 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark13(-60.44232795206085,-1.4724211682384722,-67.22846564905345,-1.0 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark13(-6.044517561969883,-0.30147484454539614,0.0,25.054914824912117 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark13(-60.471986597251274,-0.1244784123499296,-0.5227538123216142,-0.9366251780974054 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark13(-6.047477307011962,-1.0879397376280906,-88.52467267891802,-29.968213788298897 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark13(-6.050696336358875,-0.46440043906402184,-87.64620422828122,-0.0457703970839434 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark13(-60.56911058240205,-1.0845219495641811,-55.45152239731127,-71.96407525978562 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark13(-60.60338610870424,-0.03320678633411944,-65.65649039333164,11.79003080015164 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark13(-60.64435858738405,-0.09095552541283336,-100.71483776674724,4.004927676469097E-4 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark13(-60.72311583625208,-1.3418258713008022,-63.534469772750846,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark13(-60.73377283860049,-1.5707963267948948,32.07227013661335,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark13(-60.75713098647579,-8.881784197001252E-16,-72.25835513887566,-1.0 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark13(-60.9976462789086,-1.1900247307240903,-6.0654655861546445,-0.36210529666434976 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark13(-61.029186310254254,-1.518374846892315,0.0,-0.9176895073947037 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark13(-61.067010358684726,-0.016568050967433676,69.19554580578985,1.000007395084328 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark13(-61.080751761103045,-1.499772615812883,0.0,1.0 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark13(-6.108165028471114,-1.1591571180598081,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark13(-61.12315615042427,-1.5707963267948948,-1.5707963267948966,53.37197068041806 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark13(-61.27311707121979,-0.36379335170592053,38.67883371937421,-1.0 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark13(-61.29839004030553,-0.36189864585805287,-18.257224300145666,-0.7482391353685748 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark13(-61.29938357027815,-0.3458213515827192,-0.8346712363330967,-2211.854684083793 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark13(-6.129986921957917,6.482471101232766,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark13(-61.34257350456536,-1.570796326794893,26.755489118485002,-52.88223156283784 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark13(-61.35807698461997,-1.5707963267948912,88.45642548810508,-42.358437157054766 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark13(-6.140287364025172,-1.5707963267948963,-31.98635982958811,1.0 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark13(-6.140694029573504,-1.5546667384733024,-53.266001129803676,5.934729841099874E-67 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark13(-6.140767058788988,-1.3867792398774117,-1.5512068568770108,17.06471341435717 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark13(-61.414338958305635,-0.8196904770029761,-37.706531020707246,-0.9365324389411717 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark13(-61.488106579144116,-0.568613439241007,-53.7740236907445,100.0 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark13(-61.538411436519624,-1.5707963267948912,32.10301428184498,-0.9026105616826839 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark13(-61.58569601448243,-0.0018448791024889837,-14.470607512914562,-4.086011571119456E-4 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark13(-61.59642980711067,-3.501917613799657E-4,-43.71251924281233,-0.9533953381138035 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark13(-61.602490154475,-0.7632741259009684,-9.850581956844156,-1.0 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark13(-61.61259744070889,-0.2702360957625828,1.5707963267948983,0 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark13(-61.6279229951673,-0.8327498804879895,-1.5707963267948983,34.306738442414265 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark13(-61.630194617881656,-1.5707963267948912,1.5707963267948966,0.9999999999999826 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark13(-61.689313276968434,-1.4511944274295625,88.34185490971319,-1.0 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark13(-61.7633675213997,-0.4737730498310102,0.0,4.3368086899420177E-19 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark13(-61.86929995069384,-1.5707963267948912,-31.404934017981255,-1.0 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark13(-61.87040370817718,-0.9401478635796597,-88.25324133271123,2070.409770853635 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark13(-6.189998819845063,-1.5707963267948957,-43.141764705671015,78.898695709244 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark13(-6.191204465424573,-2.220446049250313E-16,88.9805237406493,-60.71042255069633 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark13(-61.98120303240773,-0.5518112360925211,-36.59377445601152,1.0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark13(-6.198566920150171,-1.3046689040154542,1.5707963267948966,0.24796131062453242 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark13(-62.017140762855206,-1.3710477365182512,-123.6536242767915,-0.6054962148043828 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark13(-62.0439424295294,-1.570796326794634,1.5707963267948966,0.15104827820818223 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark13(-62.050187683062944,-1.5707963267948961,-90.79592392248674,1.0 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark13(-6.224250045161533,-0.9261119475616804,25.173268690988696,1.0 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark13(-62.25209697973442,-1.5707963267948957,-65.51424962438222,-1.0 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark13(-62.30976951110267,-1.5707963267948912,-60.204607344555086,-80.52440636308745 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark13(-62.33546757121855,-0.5318189473119025,-3.2380080610258943,0 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark13(-62.42202981616891,-0.6133586145484259,88.55706468415825,-0.4814487874188337 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark13(-62.46527871306176,-1.5707963267948912,-50.83014425260579,-0.5652628220766803 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark13(-6.250304982343161,-1.0570486218558242,-11.759252155166331,-99.30489275536456 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark13(-62.51791946158579,-0.31725460866015287,-77.15498788187118,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark13(-62.626924848598364,-0.16361215737753865,-33.38351313934226,1.0 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark13(-62.67625231222813,-0.12199401656061547,-1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark13(-6.268342031942203,-1.5707963267948948,0,0 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark13(-62.690403007581466,-0.4660366536957099,-0.8406982477035195,85.79890107819624 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark13(-62.769179646862526,-0.19000788130360868,0.5853674096912914,-1.0 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark13(-62.8110655396157,-0.0018675258651301677,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark13(-62.825349135905824,-1.5707963267948886,-0.14585858075327285,0.7703376883421875 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark13(-62.873350460486435,-1.5585393180516294,1.5707963267948966,39.34758048096426 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark13(-62.90189939375047,-1.5707963267948948,-38.62680478526786,0.0 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark13(-63.01029130391469,-0.40252674000049804,0.0,-35.668633482464074 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark13(-63.12679231485867,-0.4310482249364993,-4.028986530638779,1.0 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark13(-63.13650510908165,-0.31627421386505955,-68.52767404853859,-1.0111983022445377 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark13(-63.138662779891426,-1.5680665148830584,-65.97829344517496,0.9180253833927606 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark13(-63.14252361113664,-0.11035735781405687,-9.786358150031976,0.9479977127323751 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark13(-63.24136722818647,14.43066007463964,1.241598919278695,-1.0 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark13(-63.25621564713402,-1.5206968011346067,0.8505607895465221,-1.0 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark13(-63.28865653218823,-1.5144782751748718,-18.068214681761958,0.02277629313364149 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark13(-63.298568051837115,-0.009908747996936135,7.853134006945316,-1.0000716818659332 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark13(-63.37195825839785,-0.8566661623654356,1.2917729960855435,45.81223179401621 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark13(-6.346973379627023,-0.2037520034397473,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark13(-63.501872316538645,-0.49206605167565654,-10.671469954102463,0.26586337153588585 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark13(-63.53344286974481,-0.11527133543287606,0.28397221865778566,-0.9306351934474704 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark13(-6.35727895858296,-0.8552955524154164,44.63594669462067,0.8958513981345224 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark13(-63.59368106679781,-0.8692924220450493,-34.293865120492086,1.0 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark13(-63.61265475019756,-0.4186000369766742,1.4699639064796313,0.6288736894373272 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark13(-63.638347076490604,-1.47522345732468,-101.58992531263475,6.269676783622592E-6 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark13(-6.366305714611078,-0.3117430495325353,-44.33129901482028,170.92089020697364 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark13(-63.68521065622614,-0.3166783451241173,44.215056797503635,-96.36178389336953 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark13(-63.68868938111674,-0.13072794703905083,-65.45512456691309,-1.0 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark13(-63.71205417134291,-0.2358219061862057,13.961429670421666,-0.9707597412143202 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark13(-6.378447850693251,-1.2932603481400315,-53.87248366529725,-100.0 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark13(-63.80397002282966,-1.033254556504155,88.73269103749118,-0.6482461099137938 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark13(-63.82508307259617,-0.6625073981325411,-66.68690844805892,-0.16543732443447312 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark13(-63.88204149458038,-0.29262492070088797,-1.9946516639376455,0.0 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark13(-63.89699938778791,-1.2046031038258964,-58.97653387713974,0 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark13(-64.01082034388891,-0.6575833397295017,-84.74465773059758,-1.0 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark13(-64.01890254125968,-0.682196265608636,-96.88923976654888,100.0 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark13(-64.07236079929658,-0.02388523397152444,-54.79869666670807,0.01010905092253344 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark13(-64.13908787172001,-1.4470962616301064,-20.767303170739225,-0.6424250285932991 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark13(-64.14482166540341,-0.6186828817724905,-34.993132763583574,-1.0 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark13(-64.15881924083966,-0.38085836967655723,-67.28580482118839,8.470329472543003E-22 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark13(-64.17273247689168,-1.1863943977938236,-49.23239498668755,52.711661580311635 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark13(-64.1844976199991,-0.9802006361606379,1.5707963267948966,0.8102347528364311 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark13(-64.2015486051361,-0.924824101953228,-91.48523663237853,-1.0 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark13(-64.32173397781071,-1.0639940034176048,32.544541817519104,-62.543436322642336 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark13(-64.33025045126712,-0.17044605901903398,26.739663389762953,3.552713678800501E-15 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark13(-64.42200020654262,-1.5693065224200131,-69.68626382786394,0.05814150791694615 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark13(-64.45994811547989,-0.5350399129121604,-9.56207842400309,-0.38220446554633125 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark13(-64.480307937129,-0.01596649224559593,-1.5707963267948966,-0.08566187303956235 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark13(-64.51286609698656,-0.6741123934654758,-37.03794120558908,-1.0 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark13(-64.5239484363407,-1.5707963267948846,-0.050745629172186855,-1.0000060227697207 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark13(-64.53046376778616,-1.5707963267948948,-51.01461039935465,-0.09854419361964606 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark13(-64.5320937324858,-1.5391851850879132,-14.78492673159218,-53.57368178223423 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark13(-64.59952322717116,-0.13696774023170125,-3.8730785624820285,-0.8251724841456078 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark13(-64.60704740435936,-0.43927203112705004,-6.986245629872176,-9.97435363333706E-15 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark13(-64.6188366428029,-1.4957539207511257,77.89942517836712,-57.497907338068764 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark13(-64.69336682211342,-0.32978348874491054,57.21932929780323,0.20885015283719355 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark13(-64.72187143532872,-1.9721522630525295E-31,-65.34006481013775,1.0448133610498807E-15 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark13(-64.73347714489232,-1.3921466881207185,81.70437373343906,-0.05659794194734455 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark13(-64.76379939798005,-0.2855415443485277,21.101452550687938,-0.819732125528336 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark13(-64.7659214700459,-1.3535627987007612,0.0,1.0 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark13(-64.81348507137712,-0.4505416381968508,-1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark13(-6.4837497220061895,-0.7114319504325479,-161.53124695809117,1.0000000000365648 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark13(-64.85734217129007,-0.8960525441571967,-79.65870057651792,0 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark13(-6.489045053188322,-1.5707963267948948,1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark13(-64.94568569269472,-1.4710672688298863,-1.5707963267948983,1.0 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark13(-65.00734850258237,-1.5707963267948961,-1.556754825980414,1.0 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark13(-65.03921378283655,-0.45909075127859467,-33.363882759735304,0.03244487522655723 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark13(-65.11563498787713,-0.9474011348182934,-52.885229973335434,-40.89494706848924 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark13(-65.22905179308893,-0.8844728973151911,-66.21537265112916,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark13(-65.45408495398753,-0.9346942001370843,1.5707963267948983,-1.0 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark13(-65.46243320034473,-0.406587885108169,-56.97216205758825,-0.8563910821309075 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark13(-65.47457974034587,-0.2803362156300886,0.0,-1.000031693008221 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark13(-65.53041567272818,-0.7473106174227073,-100.0,-1.0 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark13(-65.680652422029,-0.7580328690868483,-104.39507912411851,-0.6975033515837001 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark13(-65.72304205537748,-0.33714307957765577,0.9769744484857377,-1.0 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark13(-65.73656889167457,-0.4115183180244131,44.41986707948585,-1.0 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark13(-6.5774418477800225,-1.4821550520274895,95.35840956646923,-49.455704299618766 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark13(-6.579549852685227,-1.5707963267948948,-100.0,-61.732167117755445 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark13(-65.80270727469457,-1.5631967858094202,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark13(-6.584778662285432,-1.3444550982174144,-4.2615725179294595,1.000001368922775 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark13(-6.594308646642071,-0.6919828847631779,-37.75390252574329,-0.13587154878836732 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark13(-65.95583895647006,-1.1551447994555275,0.0,-1.0 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark13(-65.96036337986395,-1.4560904550743623,1.5707963267948966,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark13(-65.96832996867946,-0.2447736607407782,69.2331891596682,0.39313870576494736 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark13(-66.01308561774945,-0.41937586986673203,-129.85788508394518,-0.2565162409221067 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark13(-6.60358418397071,-1.2422566855204804,-96.55452953531571,-1.0 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark13(-66.05302565574007,-1.5347363728247776,-31.72893234515518,-98.97674229607972 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark13(-66.06470085580507,-0.3842180454838007,50.266925247029924,83.54099622706241 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark13(-6.60688469190502,-1.530254174159073,-19.630051496244235,0.9689659636194183 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark13(-66.16981801654472,-1.102272589745946,-1.5707963267948966,64.15944251436258 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark13(-66.21885083945911,-1.299550443980527,-122.79807969941791,0.08954022893747571 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark13(-66.29809842010461,-0.2613654390155107,-21.436184172462205,-75.66588198740692 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark13(-6.630077492410193,-1.1701013077965374,-53.72260746428476,2211.671824840222 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark13(-66.38749335055141,-1.0799079751562597,-0.28031722535585235,-84.49615381690788 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark13(-66.4094599166621,-1.5707963267948961,-9.700799432279187,0.0 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark13(-66.44653242818192,-8.881784197001252E-16,-48.39058603631448,1.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark13(-6.653941894180672,-0.09588907594561391,13.764159943258477,-100.0 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark13(-66.664330850076,-0.07809314505451734,-14.429690574180206,3.3881317890172014E-21 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark13(-66.70563797006065,-0.36583256530130587,-1.5707963267948966,-83.65028554209218 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark13(-66.71298310701073,-1.5707963267948963,0.5673781014808897,0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark13(-66.75240938216595,-1.5707963267948912,-84.18944973358398,-77.81404878168779 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark13(-66.75475061028749,-1.1328313545145041,-64.5016742589574,-2312.4753256338886 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark13(-66.84121077115394,-1.1233566818276017,-100.0,-100.0 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark13(-66.88241209955544,-0.6216023230929468,-1.5707963267948948,-0.030544146488872242 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark13(-66.89722912113689,-1.2598831160430848,88.23008841737281,-0.022624667274334598 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark13(-6.697056688916041,-0.9256339316855218,-4.67768269470007,-2058.1744881870072 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark13(-66.97812115297175,-1.0421518557799319,-91.07005585435007,-0.960396020493245 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark13(-67.0022216940575,-1.5707963267948948,-31.572557150306277,-0.5402621429685148 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark13(-67.00841334256877,-1.0913838508062053,-20.728231846762,-1.0 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark13(-67.0931600478085,-1.570796326794893,-97.06818793546749,1.0 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark13(-67.10837646060799,-0.7880491806769232,95.583160484775,-1.0 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark13(-6.714406776129849,-0.48617432134099686,-41.24168927219023,-0.9999999999999991 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark13(-67.16086685275711,-1.139691025689297,0.0,-100.0 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark13(-67.21203793354013,-1.0747801898637865,-11.212564912103574,1.033260683165463 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark13(-67.2776785062908,-1.7763568394002505E-15,-20.107065697227124,-0.05417797509632951 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark13(-67.38191897248905,-0.026343085262959257,-94.69674927573645,1.0 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark13(-6.740857674593908,-1.480132153202594,-85.80518486821813,1.0 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark13(-67.42554627333745,-0.6312290830609127,-50.944248217427074,1.0000022865757972 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark13(-67.46279600538293,-1.5707963267948957,9.23970824633193,-49.24130832883327 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark13(-67.49165153788626,-1.5707963267948948,0.0,1.0001041342571086 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark13(-67.54921071090634,-0.9484635448814343,-95.78602025249035,0.06256061500223713 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark13(-67.55265783596161,-1.1518194945589235,-25.76856228261586,-1.0 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark13(-67.57043498948633,-0.6720596223676575,1.5707963267948912,-32.83454441793741 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark13(-67.6051079849226,-0.5715899246657261,-87.32473560697753,-1.0 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark13(-67.60607737785283,-1.7763568394002505E-15,44.437504092403174,1.734723475976807E-18 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark13(-6.768637558860134,-0.11165236049342606,44.12107463558042,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark13(-67.70445875838595,-1.3447051304052116,-39.362142667437006,-1.0 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark13(-6.771714743490309,-1.05399678314339,1.5707963267948966,-26.478767038543904 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark13(-67.71949044780668,-1.1268879216674463,-79.64691961498987,45.474094355383045 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark13(-67.8294012271985,-0.6772756983047825,-0.0027531214771322754,-37.206628764812024 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark13(-67.85652972993675,-1.3688274209527602,-6.931996682636773,45.51778966786683 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark13(-67.89226339450154,-0.13679734834910962,31.43304503594039,-0.9999999999999992 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark13(-6.801516734129652,-0.03234215647100593,-21.94166703676916,-3.2033329522929615E-145 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark13(-68.02203425066311,-0.3310906542294991,-88.27656679929962,-61.09133746756363 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark13(-68.06186211224271,-0.034046615872737426,-10.717389545792718,64.09608770821976 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark13(-68.08270562130056,-0.7108176249231101,-66.13403870593396,-0.016286285490751173 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark13(-68.09651769405819,9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark13(-68.34418887507687,-0.3311216971384144,-1.5707963267948966,-42.62722139447188 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark13(-68.35232901104061,-0.814940531277331,-97.46393848545674,0 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark13(-68.4532896558503,-1.5707963267948957,-1.5707963267948966,0.30315466282613124 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark13(-68.49351486624273,-0.259485446646688,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark13(-68.54645283249056,-1.570106374256019,-3.6086193534634106,0.9999999999999997 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark13(-68.55628292046353,-1.3737841919408242,101.86635498834603,-0.043369013773134735 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark13(-68.64880288625588,-0.6987025059490739,-93.24039812577374,0.6244866572168561 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark13(-68.66297798542271,-1.531334981902777,-98.6040884564543,-2.3738919364399497E-66 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark13(-68.67449331088753,-0.8703713579632539,0.0,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark13(-68.69545412655293,-0.9939371153001484,-48.75579653259721,9.857182517612179 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark13(-6.874051858473582,-1.475931200933848,-0.2865591375431169,0.41764837596817406 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark13(-68.77143494627984,-1.4026690534127604,-13.919356103590495,0.0 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark13(-6.878391753370881,-0.006381990122284388,1.570796326794897,0.04575692788729535 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark13(-68.79321222604031,-1.5016192434867337,-123.00135909532872,-0.9999995919504027 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark13(-68.7952727609078,-0.214324995430757,1.4671555341113367,-1.0 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark13(-6.880340562668756,-0.044642152174671684,1.5707963267948966,4.834251700607339 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark13(-68.82093845107372,-0.4289059865122964,-41.99363379308248,0.0010547427844329604 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark13(-68.86645289257116,-0.05987760047241153,63.5027550406878,-0.9929674346845989 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark13(-68.99240422553855,-1.5707963267948948,1.5565008730011953,1.000000957544292 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark13(-69.01723639346974,-1.5172592673332739,52.7730229164132,-1.000000000000007 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark13(-69.03772005632541,-0.0042025261752644625,-38.691649906857606,-0.9500709550561341 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark13(-69.05963614428799,-0.8674525834243646,0.0,1.0 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark13(-69.07026606043756,-0.17104718141691644,1.5707963267948966,-19.379095081263063 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark13(-69.10586496221396,-1.4468255534055727,-1.5707963267948966,-34.71983553530455 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark13(-69.18143073021292,-1.5657846561124655,31.600630412069293,0.7691500554925552 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark13(-69.23877641897309,-0.9594815776819068,59.129591893086726,-6.6174449004242214E-24 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark13(-69.32892095419896,-0.37571527382701053,1.5707963267948948,-107.44192791705811 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark13(-6.943722029982062,-0.2191546589027123,45.40087784831378,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark13(-69.48261828706029,-0.4742617132750091,-53.69279384646746,-1.7132875012175077 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark13(-69.5245339966489,-0.2569103846364286,-71.13941737849984,1.0 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark13(-69.5874253596732,-1.4056724332063846,0.0,0.011851054075012885 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark13(-69.64131142884358,-1.5707963267948912,52.453329517357844,0.8893818640357055 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark13(-69.67785823134068,-0.9940689496560459,-1.7763568394002505E-15,1.0 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark13(-6.971111384399578,-0.029074293467707422,-100.0,3.1558592618073114 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark13(-69.71906922730538,-2.220446049250313E-16,-20.117086672796226,41.789922214718636 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark13(-69.74053719974005,-1.5707963267948841,-122.84453488986895,-72.48750111228095 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark13(-69.81314507906097,-1.570771158663033,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark13(-69.82259369187057,-1.1558094567631498,-24.993101568399,1.0 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark13(-69.85032634994013,-1.0845388071936526,-0.12259429387805862,-1.0 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark13(-69.94247021911785,-1.2043361813449387,-4.402907589299613,-1.0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark13(-70.01517537901765,-1.570796326794893,-1.5707963267948983,-0.6217727762521212 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark13(-70.02269629642966,-0.6758499572943695,95.29003868627464,-1.0 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark13(-70.03367439693201,-1.468695545594673,1.1008329385955404,-1.0 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark13(-70.15899772396622,-0.44387762368911743,1.5707963267948966,-50.834118801985625 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark13(-70.21683476459172,-1.6153081566557628E-15,89.15302984332178,6.434446986835036E-86 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark13(-70.2959035773325,-0.8745436895485839,37.905133721664996,82.1098929184077 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark13(-70.36707815277245,-3.552713678800501E-15,-65.03673007494682,-23.844782831179103 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark13(-70.4406362910524,-0.013198100055153886,-0.5222431660566771,0.5796152015426276 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark13(-70.46423589952028,-0.1565380719721144,1.5707963267948968,-0.8612648373967478 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark13(-70.54259495047319,-1.5707963267948957,-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark13(-70.67285103138381,-0.13588095037914605,-85.06730012143007,-0.03949078742495963 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark13(-70.68119281006669,-1.0819130413258036,-82.56069071469574,1.0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark13(-70.68906533035909,-0.031953746992018625,-123.12506247727717,-0.013332954980051853 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark13(-70.8030781022454,-0.567470263097221,56.63531833315753,-45.30203211075718 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark13(-70.8155543790928,-0.01621743513015872,6.4400695441786056,1.0 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark13(-7.093077647190519,-0.8411221107668868,0.13138306775231517,0 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark13(-70.98646824870909,-1.5707416182698974,-19.410786939340568,-0.05020700610501189 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark13(-7.1031394081988,-1.140134142492144,-14.042082923362841,9.385620952798135 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark13(-71.09960756060043,-0.15901499992422147,1.5707963267948966,-0.9792804425742014 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark13(-71.12279648360706,-0.6652599598705913,-26.464971926991588,-1.000414366391883 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark13(-71.23576322474699,-0.36642845783849,0.0,0.9999999999999996 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark13(-71.2591801592539,-0.08591793099250644,-32.42633006297024,32.27372342296795 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark13(-71.27957056890062,-1.3619713676257312,1.110788639121675,1.0 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark13(-7.133446637696622,-1.064043819175263,13.751102475958227,1.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark13(-71.33899859938799,-1.5705261850531147,-61.266061992810464,-64.039311983699 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark13(-71.38039087968026,-0.19398121479531127,-38.881086671920144,0.03370134916395939 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark13(-71.4126235278404,-0.7758794436467521,0.0,1.0 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark13(-7.154018688274586,-1.0695400750907322,76.44372397530722,-1.0 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark13(71.5990976393542,-26.044851056134277,2.4060491578097754,0 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark13(-71.61012011287573,-0.4774923877006021,1.5707963267948983,97.53039597866712 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark13(-71.68890755155483,-2.6103977939362366E-4,-121.75000138200538,0.02354714960621937 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark13(-71.73452463313957,-1.4455202813655745,-0.30099173670442736,-0.871781924205238 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark13(-71.79012721573342,-1.206219123270866,1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark13(-71.87070782118967,-2.2298083536565195E-15,-1.411812254318788,-56.26148642268463 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark13(-71.87188979192058,-1.5707963267948948,-85.77756415662729,52.96372346164408 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark13(-72.01485097861244,-0.04035954787080953,-88.37141356755846,0.3164948817542206 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark13(-72.09942488371269,-0.6943566431675237,-1.5658984111775516,0.9999999999999999 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark13(-72.10622147688883,-1.158253654022129,0.8301293768165354,-0.00657182436684671 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark13(-7.210740511615156,-1.4378956338288314E-4,-33.25886937934687,0.5258678438849332 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark13(-72.10931201328624,-0.6991868790886716,-9.973945490350303,6.406665904585923E-145 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark13(-72.12919005691991,-0.553600065246568,95.26899209703149,-1.0007082806869032 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark13(-72.18996699909812,-1.538302051465179,-52.65681231782238,-95.49672570547337 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark13(-72.24160464904743,-0.33456148278504527,-14.490849202420932,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark13(-72.27593705858325,-1.071548384266615,-24.05762694025377,-1.0 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark13(-72.30307167202984,-1.570796326794895,-1.5707963267948966,1.646541767399441 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark13(-72.3787616125672,-0.983292660674465,-97.05846879170986,1.000000000000007 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark13(-72.38832337462236,-0.7312499453690112,-9.583689658212762,-1.0 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark13(-72.42703737405897,-0.5743646665685633,-39.263945461103276,0.0 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark13(-72.47734576071832,-0.4453934955793263,2364.8038954514323,0 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark13(-72.48502895332798,-0.2202958830662558,58.13505653556937,-0.3961868921924747 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark13(-72.54774731436635,-1.5707963267948948,-21.072241198533206,1.0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark13(-72.59285285152127,-7.105427357601002E-15,0.7626643343745029,1.0 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark13(-72.60891910226529,-0.9707955368966008,-28.019344607967952,-73.68045806051472 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark13(-72.63169549725133,-0.7529504006479248,-1.2754593758574584,66.73572434465143 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark13(-72.67296008519257,-1.1403498627858122,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark13(-72.70780692561205,-1.5111928485973154,25.36283160917057,53.25055179413306 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark13(-72.75025020210522,-3.865230442902201E-17,-100.0,0.028709556322382326 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark13(-72.78848881726391,-1.5707963267948948,-59.19875348321287,2392.528802986396 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark13(-72.85783510530396,-0.5897422360678855,-167.96403751435716,-0.055577146020334145 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark13(-72.90380165847309,-0.5497866737958199,-32.9218514573554,7.710960705593843 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark13(-72.92393725300214,-1.2154328215784376,-9.132592868976232,4.2351647362715017E-22 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark13(-72.97617600772305,-0.7367982486586127,19.407097903620745,-8.583428096452476 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark13(-73.04127904275448,-1.1427299510870685,-51.3677519210793,0.026319000553006247 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark13(-73.07179568031863,-0.8954761605542709,2.220446049250313E-16,0.36954515929839404 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark13(-73.10439704230579,-0.051074980848712107,-17.61094316243538,-57.955787499141465 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark13(-73.23600401787695,-1.4697521544560912,-15.321462300770094,0.3931197088997781 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark13(-73.24921118900797,-1.7763568394002505E-15,38.41845242573561,-1.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark13(-73.32888854596635,-1.5477492366261512,-61.806174716116985,-1.0 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark13(-73.34563022018455,-0.3171572478323318,-73.73428320897185,-0.02653978430555548 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark13(-73.63652892992219,-1.5707963267948912,-62.6962234631571,1.061210996991481 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark13(-7.36657591450232,-1.5707963267948364,0,0 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark13(-73.67375661680843,-1.1625538383357097,1.5707963267948966,39.91541216103576 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark13(-73.68229944749064,-0.7518836531664306,-56.32506448148697,42.32583824142887 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark13(-73.7194916698873,-1.5707963267948954,0,0 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark13(-73.76247688230222,-1.5707963267948652,-1.5037617383488255,11.335563464478211 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark13(-73.80115322173486,-1.2701401550202869,-1.0698511630440104,1.0 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark13(-73.91032686840911,-0.7918386499570744,1.5707963267948966,1.0000001735570905 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark13(-73.96171024123623,-0.354956529583902,-72.49720765383088,-23.365395064436555 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark13(-73.96764000343096,-1.3384270472693736,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark13(-73.98958723552293,-4.0344755043830033E-4,0.10893445712144549,-100.0 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark13(-74.00495045839465,-0.280388878676567,-20.480595978598615,-0.0467195773652509 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark13(-74.0632086247203,-1.55542595711704,0.8084377394858109,0.9782924049316932 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark13(-74.10643860034,-0.19267725057413765,-67.07491284676263,3.559096925924114 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark13(-7.412891208996129,-0.11032773799939496,1.5707963267948966,5.551115123125783E-17 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark13(-74.17769174187912,-1.4639594999151342,0,0 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark13(-74.22004893736724,-0.3279329547223653,-56.32281794084,56.869898655332804 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark13(-74.28108022881794,-0.03004558622035502,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark13(-7.431078589178962,-0.03814040887953316,47.87993119817526,0 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark13(-74.34298274048255,-1.3940874053606562,-1.5707963267949019,-1.000013904278207 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark13(-74.35593273976514,-1.4624110481455252,37.903030340117795,-0.7276162731045195 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark13(-74.3627572692521,-8.881784197001252E-16,-42.50835708617391,-1.0 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark13(-74.36406207366616,-0.5320115137649757,0,0 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark13(-7.447883692256628,-1.087014910752572,45.19640784337536,80.96572967447744 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark13(-7.448694609939057,-0.6891219737876293,-38.532693490514234,-43.60155969263098 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark13(-74.53637486185079,-0.05471933872713919,-33.238204963420934,1.0 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark13(-74.5484344080064,-0.22522639056688565,-5.855877897310705,-1.0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark13(-74.62934856497881,-0.8200815137137596,-66.70636995905191,1.0437574815165003 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark13(-74.68172961109316,-8.881784197001252E-16,-9.831389290594228,0.14025215260470247 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark13(-74.72952027019684,-0.7221299235912642,-128.90487983943382,72.54619336296717 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark13(-7.473980633607031,-1.3388193295702546,25.540234841254986,1.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark13(-74.79512551339066,-1.0399229268846697,1.5707963267948983,-0.04232863475577053 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark13(-74.86106096919791,-0.09844863102336762,-0.4488147175706162,8.881784197001252E-16 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark13(-74.86450857966298,-1.5685841288499518,0.0,33.08558468558912 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark13(-74.97006962314653,-0.9283242513790744,-0.23588047956494274,1.0 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark13(-75.09637229222207,-1.6638276383761384E-4,19.400133264950625,0.8613947589824494 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark13(-75.09659414008325,-0.29250448021254244,-0.051060169859823756,-83.28814192864355 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark13(-75.13249182365533,-0.6927079945447225,-9.58747257146976,-1.0 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark13(-75.23500725616258,-1.5707963267948957,-32.653645331087276,-1.0 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark13(-75.27815498404173,-1.5707963267948912,-0.5409668046992009,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark13(-75.30826334682075,-0.7190630681945294,1.3245713768448804,-0.3750664953286873 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark13(-75.33028389764591,-0.04740991518314086,-21.334795602072354,-0.04508578351699555 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark13(-75.35596863146574,-0.734797735723048,63.230063112213124,0.966723890684932 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark13(-75.38199694981435,-0.4139720373048114,-29.3867820226088,-49.4697307490394 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark13(-7.538470890930931,-0.5127344119097457,19.446658984254338,-1.0803621099123684 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark13(-75.39495671124747,-3.552713678800501E-15,-41.45144889959458,61.25639088746475 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark13(-75.40177996531769,-0.7502557719264873,1.0934223702736903,25.696463908837938 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark13(-75.43398086215522,-0.951003108200078,9.31274998471882,-0.7028419447030585 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark13(-75.5228887273533,-1.015349809715736,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark13(-75.58243286231226,-0.13201837551044598,0.11864255146352987,0.9053058331209332 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark13(-75.63015601598092,-1.5707963267948948,-1.5707963267948966,-0.14511611441282923 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark13(-75.68383980708877,-0.3406952286020982,-53.86442681350424,11.102607402514494 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark13(-75.75580396146401,-1.5707963267948948,0.7767052653183145,-1.0631976730258885 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark13(-75.75626941559754,-1.4765417372674392,19.92037689874884,1.0 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark13(-75.81574450258223,-1.0050833494702627,-49.408037439813214,1.0 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark13(-7.582027494127271,-1.5707963267948963,-100.0,-2298.9350626398204 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark13(-75.86571237936155,-0.8884832544332916,-74.37201136742661,-1.0 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark13(-75.89680848302906,-0.6311371156164538,-0.35439132755129094,-0.9999999999999984 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark13(-75.92504540916453,-1.5707963267948948,-51.23578038953595,-0.6587932285490052 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark13(-76.06882577541064,-1.5678045404412124,0.0,0.06256283146460458 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark13(-76.09713925381037,-0.08332444602488456,0.0,1.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark13(-76.15454644358996,-0.5190687472806133,-76.77167032037156,0.7445378454985155 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark13(-76.18695397377647,-0.5769614341752584,-42.48529738046296,0.3726785260014549 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark13(-76.25144684052498,-0.859460469262388,-43.65490885459568,-1.0 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark13(-76.25226696649635,-0.30909911971515847,-2397.2261922986563,0 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark13(-76.25234329255176,-2.220446049250313E-16,-95.4393664333456,0 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark13(-76.38406958386372,-1.5339064025326203,-32.05487870696972,-1.0014373825862168 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark13(-76.44064131211279,-1.5707963267948948,0.24325569080700188,-37.36543556801337 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark13(-76.45166412325472,-0.8132594675044587,82.98941804916183,-73.90276020044526 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark13(-76.45523507913418,-1.246688951532455,-26.775749121150195,-1.0 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark13(-76.4607687889012,-0.41773539206991,95.60321167633256,0.06346766800531865 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark13(-76.543969256616,-0.4752856690115531,-0.37196003381157144,0.24602787204640852 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark13(-76.59928598314058,-1.2678287317808208,-92.14900649491146,51.37857243005689 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark13(-76.68171951799536,-1.5707963267948948,-11.554324748045914,-0.2884021145534632 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark13(-76.85016473990203,-1.2907852166100307,0.0,0.16988622522814373 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark13(-7.68905165980749,-0.41650205545152097,-31.819849959483278,0.0 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark13(-76.92129228847371,-0.44483480491713867,-1.5707963267948983,-35.794245238724145 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark13(-77.00919557042226,-0.11727512540552665,-44.37464926969651,64.07943653097497 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark13(-77.04318829876456,-1.402188390940804,65.95851404381298,-1.0 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark13(-77.0470008619998,-0.25855854759109975,25.67577249603267,100.0 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark13(-77.10286683283425,-1.5707963267948912,-48.475769074284344,-84.99344996716731 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark13(-77.1259974718837,-1.083713165908161,-0.030670184990398364,99.36372751000454 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark13(-77.229355885548,-0.6756555594553968,-44.09626205294492,1.0 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark13(-77.2784168746657,-0.53125482869041,-36.668480282182145,0 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark13(-77.29764468080883,-1.3071778044704119,-45.530498919209215,0.9276086780170648 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark13(-77.31169134221533,-1.5250089393017991,-1.4930684365709506,-0.040028240172759084 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark13(-77.33055981602503,-0.2635825403548566,44.25569079024903,-0.06255323993291348 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark13(-77.5235687173766,-0.254971797880323,-43.95528182505111,-66.61363108083015 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark13(-77.52938410075824,-1.5697534728855689,31.724302814156243,1.0000000000124496 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark13(-7.753770165222292,-0.6142893873838435,-67.2786648664515,-100.0 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark13(-77.54120381560281,-0.897892988935439,0,0 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark13(-77.54949773886366,-0.47397850587322177,-0.387141569431218,-1435.5035511907756 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark13(-77.55286996011809,-1.4420552856151438,1.5707963267948966,0 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark13(-77.55384276005867,-1.1677136273971653,-1.1804244145288434,-0.20844790044201222 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark13(-77.63055044346005,-0.43936187652523073,31.83883443095339,0.050576517009041005 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark13(-77.63464164243447,-0.7000341577133435,0.21357291494824804,30.34990674593443 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark13(-77.6643016087136,-1.5311990148350616,0.0,0.0 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark13(-77.71644007558872,-1.5707963267948912,-32.448283521060816,30.038671824420646 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark13(-77.7473429450773,-0.28344967666879084,-73.71304319658064,-0.6740921022329189 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark13(-77.74748928300691,-1.211198389039523,7.002211115668112,1.0 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark13(-77.8738067141761,-1.1486636875594942,-20.051773998359884,-1.671383362386906 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark13(-77.9193319856353,-1.5707963267948963,0.0,81.10841891223768 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark13(-77.92774128629219,-1.5427538474430469,-71.88116051679528,0 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark13(-77.95599073763023,-0.13869659986181215,-122.5707453839663,-8.268682417027192E-4 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark13(-78.16917049907617,-0.3176148238648143,63.25558304502785,-1.0 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark13(-78.19793848495709,-1.5661029854501964,-100.0,0.5372979829263795 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark13(-78.33781852338801,-0.7771860973263088,-42.22884714502551,-0.05126664593949415 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark13(-78.34796462271538,-0.6012897521237006,1.5597474421886617,31.068468169589323 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark13(-78.3568768050957,-1.5707963267948961,-0.9145701865666089,0.8936018559639233 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark13(-78.40541225517242,-1.3092316369298425,88.21650742037475,0.8853660343977197 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark13(-78.49641632042643,-1.3187766104525291,-28.798257549336384,62.49770229340362 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark13(-78.50791639958074,-1.5707963267948948,-1.0532908486049941,0.13885990328323872 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark13(-78.5391053073639,-0.8276633279531791,38.954883341458746,-0.1883604589972201 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark13(-78.55732846053324,-1.5707963267948963,1.5707963267948966,1.0000000005320997 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark13(-78.70648120729567,-0.00478076985995953,1.5707963267948966,0.062143137525364156 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark13(-7.872942731671731,-1.1964672171933892,-15.363094335859827,-0.12990475776785182 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark13(-7.891103481767821,-0.47959638482716604,-40.28877145069494,-1.0 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark13(-78.92615639616407,-1.3830526581877558,-1.567653030918916,-1.0 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark13(-79.07948203745393,-0.008124968850666072,1.5707963267948966,0.7918064614257957 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark13(-79.12949242591557,-0.04751917352330974,0.0,-1.0 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark13(-79.14905440267935,-0.22008150729297427,-99.28250248616382,-0.8389747372466387 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark13(-79.18055017560353,-1.0110485739973,-100.0,-68.78607176654315 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark13(-79.18535446899088,-0.20446129406666458,108.06644139077645,-35.44230928177136 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark13(-79.20216008371023,-1.5707963267948963,-78.12407540412387,0.0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark13(-79.28687314365479,-0.32322721916175357,-14.975293521734168,0.0 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark13(-79.40427778744059,-0.3284282751054288,-15.363571936056815,1.0 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark13(-79.42188434378679,-1.29312845458678,158.61306944898325,-0.8556749809765076 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark13(-79.43198727458407,-1.4714465684003906,-162.35069170528618,0.9999918726333855 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark13(-79.46982994383664,-0.5758369920886981,-34.29193596760163,97.30582369921417 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark13(-79.47283036210453,-5.804919253777364E-15,-18.972696906343046,1.0 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark13(-79.47502245249433,-1.5707963267947953,-63.212442418860235,-33.10692182899598 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark13(-79.49296631235646,-1.2555303537318614,-1.298335270597879,-18.10574071289885 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark13(-79.54990915008713,-1.5707963267948957,14.039748332065358,0.0 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark13(-79.71559686173605,-1.5539757535191376,-66.04643871744693,-0.05215336712846996 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark13(-7.9814710544635945,-0.42289503949083906,56.668045822235456,-1.0 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark13(-79.89573960015815,3.3319420311865033,1.5707963267948966,2.1684043449710089E-19 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark13(-7.992560076102155,-0.21560916716527664,-2.6092819019357734,10.117869937497986 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark13(-79.97445066770933,-1.3199039812020426,-0.4917908074836568,0.03529756635312462 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark13(-80.07124676778324,-0.5404513503915583,0.0,0 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark13(-80.08881003744466,-1.5707963267948912,-13.664683370715332,0.4063472660576858 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark13(-80.19800148339377,-0.20866295578199867,-32.12878389755595,69.7282242525427 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark13(-8.032638889196036,-1.7763568394002505E-15,-32.67833923555538,-40.889941273727445 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark13(-80.33018632880031,-0.03349364111185816,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark13(-80.39033302153648,-1.1846661311834197,-42.352727353112144,0.9155698192708017 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark13(-80.39477280824774,-1.03174913811171,-84.34680605509953,-19.11624244603796 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark13(-8.043053913014091,-0.6959421003436481,-46.47526094508192,-1.0000144041508348 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark13(-80.440172341999,-0.27246210091627704,-1.5806095779398572,-0.6885439230182597 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark13(-80.44194684300648,-0.23172290576055707,1.5707963267948966,-35.463294576158404 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark13(-80.58630270577218,-0.6966753533937055,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark13(-80.63338435356972,-0.1086058196436971,-47.001186914616156,0.9963143972997974 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark13(-80.67166312452694,-0.10554145176925345,1.5707963267948966,6.53465806958404 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark13(-80.6731158868964,-0.049102163734190185,-62.22901520837767,62.55737134395224 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark13(-80.69370955957784,-0.043959256087100475,-86.16846864767076,0.6684105663160126 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark13(-80.79639998349995,-1.5656000194403354,-24.009087785555792,1.0 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark13(-8.081239777616453,-0.7022613947784786,-1.5707963267948966,0.03860777400916675 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark13(-80.88248950721535,-0.9454357728020674,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark13(-80.89336822782792,-0.5433657488904104,-81.51373887956736,-1.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark13(-81.06630242289415,-0.5372907239998811,0.35883279171959226,0.15181592506411948 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark13(-81.06807823726636,-0.2870150227375366,0,0 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark13(-81.16679347831216,-1.5707963267948957,-2.357640797474498,-1.0 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark13(-81.21703347882936,-0.38637308462634223,0.0,-1.0 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark13(-81.21721453319087,-1.0328402742958,32.70938337783718,51.62663203454534 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark13(-8.127913883260419,-1.5707963267948948,69.68648314288623,-1.0 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark13(-81.34045019642126,-0.7364936204705672,-19.74059650155631,-23.008906750547737 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark13(-8.137951381320672,-0.11861375729029944,-2.4814354260412235,-0.05091887455249458 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark13(-81.38508159248006,-1.3739446980237235,-4.504539515495508,-0.5936840626563312 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark13(-81.39713374907632,-0.4902554647752986,-1.5707963267948966,-25.059560115507146 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark13(-81.42945410534581,-0.16099430189919905,-1.5707963267948966,-0.39499762290980334 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark13(-81.43275855004619,-1.5707963267948912,-68.42350430561504,-45.354752203460016 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark13(-81.47502832817612,-0.4302941296531628,-4.518630106138033,24.195456565029446 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark13(-8.151406849579782,-1.160185595125009,-78.18731523722144,-73.50541594207469 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark13(-81.6002248285855,-1.003235877581913,0.0,-5.796180503241984 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark13(-8.168151261354954,-0.638236543599953,-3.7334951718598717,0.01620782296133008 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark13(-81.68617523968166,-4.3842184216590596E-16,-99.20816635458496,0.34662306604305115 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark13(-8.170463873332984,-1.5707963267948963,-1.5707963267948974,3.970713920428519E-18 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark13(-81.7526586837377,-1.2965352278981346,-5.3564493149809635,0 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark13(-81.85497099922584,0.4497374590561901,1.5626519215644992,-76.72827038940444 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark13(-81.92337315213223,-1.5707963267948948,0.0,1.0 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark13(-81.95168261910638,-1.1303623935410858,-31.49390234290938,-86.49512060221178 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark13(-82.00552924782743,-1.2052025999773432,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark13(-82.01355641073783,-1.5707963267948957,-1.329990751447168,-0.24802978859015312 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark13(-82.04590136766475,-1.5707963267948963,-77.39697052282649,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark13(-82.0834560189371,-0.20953088681473694,-39.656731500919676,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark13(-8.212670040723593,-1.526539630446551,21.29201566967415,-1.0 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark13(-82.20099729590673,-1.5707963267948961,0.0,63.729743208537315 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark13(-82.2135381046054,-1.269299763339347,-0.8305399360920971,-70.7108845035658 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark13(-82.34249132037749,-0.2527877390766191,-13.85397636497226,1.0 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark13(-82.44295928215267,-1.4629040195252694,0.03090941736391004,-1.0 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark13(-82.48331041357174,-1.5447757977236627,1.5707963267948966,1.8546030753437107E-68 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark13(-82.65103820587287,-0.17111752160870683,0.9436995280115088,1.0 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark13(-8.271377516397195,-0.820447578549713,-1.5707963267948966,89.54838294410442 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark13(-82.7679147306065,-1.5180215118295368,-34.764045500146544,0.04817290591270185 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark13(-82.78863549357038,-0.5464314178196648,-67.80860159639471,0.6561264683403893 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark13(-82.8614528334426,-0.1141468578255811,-43.01751019161191,39.401057972428426 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark13(-82.87284674446312,-1.3288864901734456,38.86669138906453,0.0796956071033561 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark13(-82.92401988638004,-3.552713678800501E-15,-60.440164544756975,-0.027621002862508074 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark13(-82.93435410065241,-0.004645619833609812,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark13(-82.98226658727981,14.439247666436756,1.5707963267948983,-131.1832535340213 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark13(-82.98290696512785,-1.5707963267948937,-27.25982528586361,0.24084340186135964 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark13(-83.08905197275865,-0.4335587745736643,-41.42998834432644,-1.0 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark13(-83.10728601839226,-0.3439163136739556,-1.5707963267948966,-2094.88418303793 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark13(-83.11144395804425,-1.5106345929536722,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark13(-83.27734333273776,14.465652201523568,0.19330073885346388,0.0947896133017212 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark13(-83.33180108327404,-0.451881621694659,-21.877621165916963,1.0 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark13(-83.42998011502087,-0.24580611678090444,-77.78704642881576,-1.0 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark13(-83.55579901171453,-0.2800245774443228,0.0,1.0 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark13(-83.57378653617803,-0.04093697149396005,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark13(-83.60808410784432,-1.5707963267948912,-2.2736361653156365,-28.964805068902308 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark13(-83.61189111533652,-0.8660754423316206,2.220446049250313E-16,-1.0 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark13(-83.67226873328491,-0.7955296765282177,-0.8673959614328303,1.0 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark13(-83.6791564310274,-0.5560016387082548,-76.65451475670534,2.710505431213761E-20 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark13(-8.36905619230901,-0.2689480163662654,-74.51135944314153,-1.0 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark13(-83.78187577611575,-7.105427357601002E-15,-89.0222260379152,-11.167203912346762 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark13(-83.80188712948264,-0.30569216943164806,0.5028870546073351,0.4858629382517125 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark13(-83.88502694567026,-1.5544079211561481,38.11256400896915,-1.0 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark13(-83.895512394643,-0.9743233103828751,1.0770935899294596,-1.0 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark13(-84.00373314902885,-0.5401504090206148,-1.5707963267948983,0.7322130729965324 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark13(-84.19215646729809,-2.220446049250313E-16,1.8439891363346408,-31.487831463790037 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark13(-84.20765770649652,-0.022274442708463474,44.01195520472217,0.8965103485119535 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark13(-84.2711423166918,-0.1407623389054585,0.4472615913880086,2022.8706715828657 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark13(-8.431035174216772,-0.3553198024297852,-1.5707963267948966,76.99874720235604 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark13(-84.37818325786273,-0.22083216828343666,163.62971653615716,-49.96202081689201 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark13(-84.39605550260482,-1.4510397799490493,-0.1401851125468322,0 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark13(-84.4055204549772,-0.6956542056053169,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark13(-84.42435524488118,-0.49268079227367334,-1.5707963267948966,-0.3670837817574599 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark13(-84.45351974356379,-0.025283660685191847,-55.76813519074042,0.03873140816234899 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark13(-84.53183010773232,-4.3368086899420177E-19,-37.74761390606696,0.9569248004551419 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark13(-84.57793404615546,-0.37942735635563835,0.0,71.30571064724376 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark13(-84.59669493854804,-1.5707963267948948,-0.030868252912543297,1.0 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark13(-84.6378650197764,-1.0530552616990576,-2.939160371697291,-0.36212360185923 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark13(-84.69959710074153,-0.23230604314444747,-39.2000879402872,-0.1410302762109361 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark13(-84.8009038365745,22.044041033629426,53.80102114240688,0 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark13(-84.90490270511009,-0.9075043296330573,71.95592100456746,-81.8316161321752 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark13(-85.01191881811076,-4.008527900430303E-4,1.5707963267948237,-0.9308233779842676 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark13(-85.07478311903984,-0.06710815411149085,1.5707963267948966,-81.3649078779638 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark13(-85.13217609583543,-0.7083150583151804,31.66699816674113,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark13(-85.15787559603952,-0.6950961678863541,-8.023603404972874,-26.35433991917681 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark13(-85.35089827468983,-1.5707963267948957,-84.73852568927947,-54.080412151754985 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark13(-85.37991421535914,-0.14144186738428516,-18.393043624824216,-0.4319979771090914 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark13(-85.39483603990503,-1.5707963267948912,-80.19216371588908,-0.3738514845238392 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark13(-85.42062922876902,-1.4033828341122967,1.5707963267948983,-0.13817027295038375 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark13(-85.48783882525538,-1.5707963267948963,-66.0249317194471,-0.04958379591875678 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark13(-85.59890835689787,6.7890818032796085,1.5707963267948966,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark13(-85.60609970395647,-0.794209616165364,-1.5707963267948966,1.0047071517811 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark13(-85.65868480005456,-1.546130402017387,53.01412667826998,-1.0 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark13(-85.67437500903034,-0.25784209720071716,0.0,59.99652113437983 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark13(-85.69947711247212,-1.2862155795258678,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark13(-85.8784558565361,-1.5707963267948948,-63.28096577387408,-55.940441442319866 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark13(-86.01711370518194,-1.5707963267948963,39.14071009373902,-1.000005334464805 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark13(-86.1016536365955,-0.14147056883429004,-53.743551100181996,0.0 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark13(-86.15864480210149,-0.16340883622084879,1.5707963267948966,0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark13(-86.21458265508812,-0.008518447744579273,14.031902598322759,-0.8829636349160432 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark13(-86.29248530275461,-0.8518670074076272,-68.67927731354537,1.0 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark13(-86.29419647897866,-1.2268936927834109,-23.413267859038726,-1.0 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark13(-86.3313342253513,-1.5707963267948912,-53.78475710269193,-0.04740953854945877 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark13(-86.33886916898936,-1.2935896560756168,-40.53145457834959,-0.9999999999999998 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark13(-86.43416519049539,-1.5707963267948912,1.5707963267948966,-0.03347081223164325 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark13(-86.45392626797187,-1.7763568394002505E-15,-91.07598989714127,1.0 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark13(-86.54437973811162,-1.5707963267948912,-0.14278365131715987,6.231269301183346 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark13(-86.56101555025975,-0.34184402648399725,-80.58376990024783,-2442.029847029457 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark13(-8.656382153492526,0.10231192267960244,-52.637835564163915,0 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark13(-86.6107951621956,-1.2470011492723092,-10.47043564060376,14.164993360984546 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark13(-86.67939477283375,-0.6394457462221439,1.5707963267948912,-1.0 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark13(-86.71389106209938,-1.523242691839222,1.5707963267949054,-1.0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark13(-8.676597801521721,-1.5562808947782938,-0.284347473925869,-100.0 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark13(-86.95218835664778,-8.881784197001252E-16,1.5707963267948968,-26.09236840382583 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark13(-86.96060224583972,-0.019769674850607544,31.767385718494488,0.44955097777105535 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark13(-86.98876060299699,-0.02132175005799199,37.812863878396996,-56.75752691014553 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark13(-87.20561519168419,-1.3813071435528124,-1.570796326794897,2089.053101834266 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark13(-87.2479549372708,-0.10174934722415974,-66.89390174744165,4.273048854243865 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark13(-87.26958047348135,-1.5707963267948948,7.848630907373136,-91.55875197415348 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark13(-87.29687925506175,-1.5409753175968888,-130.19233493498473,-25.456718050179703 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark13(-87.52960138413773,-0.7952873740765244,38.73038604953088,-2.4074124304840448E-35 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark13(-87.68463081116806,-0.41812236360763066,-6.633723227086755,79.07074254706227 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark13(-8.77078956965826,-3.552713678800501E-15,-1.5707963267948966,-0.6726490535200421 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark13(-87.72490150732197,-1.5707963267948948,64.26380005917878,0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark13(-87.76252075724615,-0.4238652940331087,-1.5707963267948966,75.22082869318422 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark13(-87.76798388244653,-0.7066537711604858,-61.548843458469804,0.9793029875675099 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark13(-87.82886015692952,-0.8256582980454817,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark13(-87.89301990897155,-1.5707963267948957,-59.027228388510935,42.97648041200125 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark13(-8.79283209242897,-1.5707887485399652,1.5707963267948966,-0.6058112932507613 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark13(-8.797223254300665,-0.6363198653713908,-25.45097197446688,39.53601988929499 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark13(-8.79921762567134,-0.29422364223199127,-100.0,1.0 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark13(-88.05524514632637,-0.09137191286673563,-99.13883883154469,-58.42857433456106 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark13(-88.08664054438458,-0.20268037263651803,0.31141178426490196,0.9999999999999999 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark13(-88.11416980310881,-1.5707963267948888,-1.2539242552019927,29.570650695457353 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark13(-88.22794359213351,-0.03284105446187105,-55.47015397541146,-2240.269648607114 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark13(-88.30074199937246,-0.03361595259461425,0.0,-82.47700580535259 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark13(-88.36633058344188,-93.90959438224394,-55.370793988815656,0 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark13(-88.40831750636679,-1.5707963267948948,-100.0,-0.056467828987135205 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark13(-88.41444840395715,-1.3410741521231273,-90.08509371663729,38.31833268340441 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark13(-88.42459532357431,-0.7607850794435645,-0.8072507997065802,47.67071688084222 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark13(-88.45296806861217,-0.31555729635725793,0.0,-0.5440899592938557 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark13(-88.53891147170383,-1.2638711692508515,-46.18734407809799,0.00808401267864801 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark13(-88.55436656131685,-0.21427153491898765,0.0,54.838375705478825 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark13(-88.5647591853216,-1.568245482057529,39.052339793186775,-0.9602931641650183 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark13(-88.63399486242376,-1.0858146132185738,0.9615487877384317,0.0625737326532896 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark13(-88.67189945899094,-0.2603455089364246,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark13(-88.72286332744088,-0.7609987593864882,-34.23992918390986,0.7665697354376864 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark13(-88.80421994439206,-0.022412836120579982,-32.47338531261731,38.70962943766348 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark13(-88.8149701059072,-0.559633577476029,-69.25044594999565,1.0 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark13(-88.8632383407201,-1.4492572057119497,-59.76424093225033,0.6525175075921703 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark13(-8.886450006520821,-1.4142419946918519,-16.276964635436556,-1.0 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark13(-88.8763661170453,-0.7734578604784635,-1.5707963267949694,0.36209052439093636 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark13(-88.88535190284964,-0.007043449392440948,-44.347066383588576,13.30000207037692 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark13(-88.9030727387323,-0.12992175246745757,-46.34608349485627,66.02639889464042 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark13(-88.9280859382948,-1.0412938105384697,153.36537547627398,-0.24535925587689414 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark13(-8.90070252132734,-1.552436753393547,-91.73366482200663,-2.88471905801077E-16 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark13(-89.06296506541024,-0.6884629276406047,1.10896902194098,25.833603492328084 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark13(-89.12104890560042,-0.6979076368953496,-29.857182522602493,-0.2634425626813319 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark13(-89.13118720667131,-0.10939952227668097,-1.3994359469845534,-0.052597369808140115 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark13(-8.916318306396857,-0.11439968137730006,-1.570796326795037,-0.37461059883120695 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark13(-89.2193422708969,-0.10483377027411524,-1.5707963267948966,-28.85902723897766 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark13(-89.27133365851914,-0.8253644432195943,-163.53056714781462,-0.4328764672154297 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark13(-89.34469790622197,-0.3554523938778329,-20.509593339509497,0.05644499630429316 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark13(-89.36475299655635,-0.3753241512511494,-28.084036193083435,-0.01006299624163983 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark13(-89.3955840263968,-1.570796326794836,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark13(-89.4143498009497,-1.5707963267948957,-95.34184638888881,-5.903549976651817 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark13(-89.5323065363247,-0.5903429149175382,0.0,0.9756345421078927 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark13(-89.59643185350497,-0.07765715755665337,1.2663565225972704,-0.4832612312246988 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark13(-89.63941309707747,-0.24963541767511221,-59.52667128328291,-1.0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark13(-89.81956758627095,-1.5707963267948963,-66.37440117221053,3.7056666147154376 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark13(-90.00854762288053,-1.12257554377196,-100.0,-1.0 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark13(-90.09363900363915,-0.8363993025315088,0.0,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark13(-90.09627861558036,-1.0541002153172097,1.5707963267948983,-1.0000066252705437 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark13(-90.11280766005466,-0.013577845922402671,-8.602715444558163,-0.008036588442034462 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark13(-90.13373716858041,-1.5707963267948877,0.0,-1.0000000071233779 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark13(-90.17888452624845,-0.03327301064043553,-93.50226501004018,-51.935924128684746 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark13(-90.20061146315057,-0.17157885877489332,1.5707963267948966,-40.629404746119846 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark13(-90.21207205463159,-0.3346684363027528,-55.0432473225992,-29.056604594941774 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark13(-9.022975025902554,-0.5243909757759688,-74.30375992218926,40.00724265325701 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark13(-90.24133883227186,-0.9083300803903521,-95.69697556830081,-1.0 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark13(-90.33462947313838,-1.4923536639404156,-73.41748232311035,1.0 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark13(-90.37003002734741,-0.31192114765944995,-30.69781881678881,0.9702652684232203 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark13(-90.4508951787392,-1.2183629054361518,-27.62134345455705,0.9731994581750572 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark13(-9.047116541541417,-1.2045291244847456,0.0,1.0 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark13(-90.50719550874918,-1.4339111527776425,1.5707963267948966,-2205.3991334017783 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark13(-9.051400929531471,-2.304669455323991E-16,31.44123023508743,1.0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark13(-90.56866169001461,-0.3921173781723222,-2.604055866875484,95.20103499507235 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark13(-90.65675854137095,-0.6842765879282394,32.24029396300467,0.058833467979216354 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark13(-90.70967863042682,-1.132191882462775,0.0,1.0 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark13(-90.71329071362615,-1.476750575609742,-63.99808252397161,0 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark13(-90.8001639878705,-0.596385702854841,88.77178948677289,0.0 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark13(-90.83206435767642,-0.006750509291121133,88.30366970687805,0.005152259513379474 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark13(-90.88710383308364,-1.570796326794893,-100.0,31.271598676142673 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark13(-91.01690912987961,-1.5707963267948948,-95.6702959229035,-0.9999999999999984 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark13(-9.116107925629962,-1.266105548620537,-13.792719118180614,47.456857399049426 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark13(-91.17684768749197,-0.24489171337253168,-9.862265258448376,7.247469743216058 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark13(-91.27405271627136,-1.570796326794887,-31.521543899977942,-0.05300212387681859 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark13(-91.34124363321467,-0.06742797510970044,43.99840019874746,-1.0 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark13(-91.36954669259332,-1.5707963267948963,-0.856708883082738,-100.0 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark13(-91.39107272687166,-1.5707963267948895,2468.143401495952,0 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark13(-91.39555938753475,-1.2584760380721174,127.65456645359312,-0.0026036993316246575 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark13(-91.6544236579077,-0.6582886312740727,0.25839633739634943,2239.2850881196036 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark13(-91.68608350765537,-0.5365170202840994,-27.709947695749456,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark13(-91.79788781980866,-0.06379138492633046,0.0,0.01957869374570332 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark13(-91.79830300434797,-0.0025726600188200736,-57.353359313974,59.83339862635107 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark13(-91.91756705213082,-1.031210123784991,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark13(-91.93933843560878,-1.5707963267948961,0,0 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark13(-9.207984491993784,-1.5707963267948912,-5.949040669976597,-0.36934113446650274 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark13(-92.11848951735871,-0.8233752867759576,-1.5707963267948983,67.71548692298671 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark13(-92.12641357765759,14.429203713727716,1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark13(-92.15075791678326,-9.904435840487257E-14,1.5707963267948966,0.13930595210275953 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark13(-92.15411580113033,-0.6345047789061512,1.5707963267948966,-4.5811526785839065E-9 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark13(-92.17753715567056,-0.9540286070065682,1.5707963267948963,4.1002661789349907E-143 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark13(-92.21014856425782,-2.220446049250313E-16,0.0,-100.0 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark13(-92.22003560529171,-0.16407527342313427,-31.91807206823087,-0.7229363310325632 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark13(-92.25350358816095,-0.5111829055273134,53.363815619796696,-92.12326851947942 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark13(-92.27003794821997,-0.8320425020087124,-0.34313336173676556,-1.0 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark13(-92.29386422464121,-0.007810424276585322,-72.21975979789778,0.20884834370706082 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark13(-92.4191844554868,-1.5707963267948963,-1.5707963267948966,-3.46173911527166 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark13(-92.41923058171268,-0.964244625692487,39.48615166625229,-65.15231558732918 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark13(-92.47613937317918,-0.7170110581442817,-62.4386555360114,-1.0 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark13(-92.49842715385488,-1.5616604158017369,1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark13(-9.250042357902611,-0.0015509033854488891,-43.58100093636161,-1.0 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark13(-92.53299789297246,-1.5707963267948948,-9.465203266322858,-0.328292870094387 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark13(-92.57989266124416,-0.6243081244943445,-100.0,-1.0 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark13(-92.61669524278365,-1.0163705701000036,-1.5707963267948966,-67.8034147756297 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark13(-92.618793321528,-1.5707963267948912,4.440892098500626E-16,0 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark13(-92.7558486182284,-0.7281126846282511,-30.156536487888502,1.0 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark13(-9.27706236976925,-0.8708617265768991,-37.76014379653378,1.0 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark13(-92.94840324496741,-1.0500621107658747,-41.04995478176503,5.567186752411459 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark13(-92.96160025491572,-1.1501441171151479,1.5707963267948966,0.9999999999999937 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark13(-92.97500295672772,14.512001859653623,2415.576563182744,0 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark13(-93.0414126173392,-1.503173737590343,1.2280492584978222,-1.0 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark13(-9.316303681189932,-1.1309574602695658,-51.45214623576822,-0.5874569826263185 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark13(-93.23317109962652,-0.3834972167949058,0.0,-22.119617355023337 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark13(-93.34556401740474,-0.042726746832917155,-100.0,-76.96801006794556 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark13(-93.40505209571901,-0.12354578613899037,-36.96750198657721,-92.86343321610553 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark13(-9.342472853356286,-1.5406729484894577,-11.009280952204058,-1.0 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark13(-93.49533017003004,-1.5707963267948948,-0.12329334069510346,-1.0 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark13(-93.54382906209189,-0.8579924549358999,2.625384854792795,-0.9324548174719796 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark13(-93.57356122085936,-1.5707963267948912,-50.76281464075547,0.06259232783805277 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark13(-93.71574258941713,-0.015365089415664923,-0.18061048628125353,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark13(-93.72925270825843,-0.3875582279541879,-8.047661661568341,8.854457287630709 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark13(-93.77565014191664,-0.9494507533610379,-80.41273908950734,1.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark13(-93.82725353888723,-0.8654394304613559,-0.6034499808425835,-0.014114120557646992 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark13(-93.85262509303962,-0.5643354653028364,-59.32145761736897,-1.0 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark13(-93.8872338309574,-1.055272418943789,-27.75160410029864,1.0021428642719599 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark13(-93.89347217516556,-1.5707963267948948,-100.0,100.0 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark13(-93.96532994393755,-0.660925859717767,-1.7885071797598848,-0.03714904718704315 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark13(-93.9664829712512,-1.5707963267948912,-101.70317386932025,-0.25751619525046643 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark13(-93.99355121904523,-0.004901211091603708,-1.5707963267948966,0.7827765080307956 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark13(-94.0026887562711,-0.03690744159301389,-22.7458333515939,-61.72209817366308 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark13(-94.20711147967029,-1.503380575211956,-89.79156284475027,31.07030991883869 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark13(-94.23762588641993,-1.1033648153378182,-31.96791597877249,-0.3258665251721836 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark13(-9.425205842443901,-1.2200377935777582,-123.67348652277174,-68.31370215398562 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark13(-94.29818819092401,-0.497973010309206,-57.78503917070761,1.0000040690552776 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark13(-94.37304985981628,-1.1386688230478486,-42.9336836870802,-5.770611636116085E-129 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark13(-9.441700420536002,-1.1102230246251565E-16,1.5707963267948966,-36.683507597051 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark13(-94.48483161289758,-0.7176476523571154,1.5707963267948966,0.0464870029711017 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark13(-94.56462264130442,-0.003159921215859912,-31.543640827470323,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark13(-9.45965925058362,-0.2728108631730066,58.971185413028905,-1.0 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark13(-94.83932315100364,-0.2258842337797499,0.0,1.734723475976807E-18 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark13(-94.87483292871974,-1.0233254561720746,-77.73775275545123,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark13(-95.24810761062011,-1.5707963267948912,-66.27673298445842,-72.05134062724511 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark13(-95.35742130218114,-0.26855058998410186,-45.04367475112264,0.21323225916267463 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark13(-95.40935804769529,-1.5401988220328013,95.84298767012433,0 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark13(-95.41889935439994,-0.9018414334178022,-90.18431556497347,0.013340669333618216 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark13(-95.42797157024208,-0.18657293016316825,-39.796634983311385,12.785684765109394 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark13(-95.52379989116699,-1.0209068033415654,-4.336897549463551,51.50977053172976 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark13(-95.53425513472109,-0.12505099306805967,-48.88640513242204,-29.7448666143492 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark13(-95.65829507568398,-0.016980513329822366,-20.934048476907947,-81.78181876797674 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark13(-95.67232074287013,-1.1888631876910618,-11.84984317295203,-6.274707076539897 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark13(-95.89976998788886,-0.5078509469336508,-34.66931260504529,-2194.414264041221 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark13(-9.593141064419708,-1.5707963267948912,-72.61089203714022,-1.0 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark13(-95.96631916176756,-1.2947909170045022,19.394954992715398,0.0 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark13(-96.02918471967794,-1.1673806117357404,1.5707963267948966,25.8719875136606 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark13(-96.03107468767594,-1.1442945012462789,59.2434798658164,-1.0 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark13(-96.05189299020961,-1.1276757737375618,-81.46562709307646,-0.6276569065450945 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark13(-96.12747154114611,-1.1777460890529432,-1.5707963267948966,0.957786474014727 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark13(-96.15403920434534,-0.04156332333034696,-22.165627837496473,-50.18276924122007 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark13(-9.624761897117764,-0.17602593642006534,-20.388274599889233,1.0 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark13(-96.2968802156561,-1.144683593455337,138.73905354918756,0.3101387011784551 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark13(-96.30661648050662,-1.5142568382058854,-41.85616121800288,-56.243309846398134 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark13(-96.34367996302737,-0.5218061944970918,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark13(-96.41536892236991,-0.1846690340685342,-1.5707963267948983,0.5276459488754457 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark13(-96.42992096054044,-1.2295257833840219,-1.8751052567606479,-0.9256834378445272 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark13(-96.44491365310786,-1.568485587659366,1.5707963267948966,-0.9400423812202561 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark13(-96.48628791466058,-1.1959042070080175,-91.38752293511763,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark13(-96.50015421185309,-0.004766101004140872,1.5707963267948966,0.06256668824490134 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark13(-9.652439069484902,-0.24115671972042912,-57.770776849123486,0.40492013297893314 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark13(-96.56038662863828,-1.34289249131461,1.0130493381447845,0.457873399726739 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark13(-96.59422169762472,-0.04588230619415641,-11.289469006051034,-0.19848281941854973 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark13(-96.59557142339003,-1.5707963267948946,-12.34107365280552,-1.0 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark13(-96.60595206631422,-1.5388936468216283,-1.5707963267948966,0.9882798432576155 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark13(-96.64607681897914,-0.2723435024871963,0.0,0.8357683047313946 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark13(-96.759590863822,-0.1691636688946832,-67.45672757537722,-1.0 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark13(-9.676377019775883,-0.03648277144645773,-21.938794336787208,0.6087241416059141 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark13(-96.81828429523688,-0.14418707496341704,-54.86478633762989,1.0 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark13(-96.89820912698622,-0.9761708927501376,-110.50184800265441,1.0000000381786078 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark13(-97.02041328936194,-0.7914966138293504,39.06693056524242,75.43798380406378 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark13(-97.03450819449185,-1.5296441955379383,-1.5707963267948983,0.8685693503325487 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark13(-97.06177889842269,-0.6223976278207606,-88.10278205440495,86.59390201510213 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark13(-97.17546726246663,-1.5707554000819992,0.19898796338674174,-0.03716066292940421 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark13(-97.33547607527046,-1.1612838772964384,-57.08033265198025,1.0 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark13(-97.3394034570925,-0.38896139679508157,-0.5635493132063344,0 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark13(-97.37223197981729,-0.8290979434970923,-42.6850161161689,0.0 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark13(-97.43885316867275,-1.5232649112152332,-4.372112134495326,-0.9999999999999999 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark13(-97.49262172421687,-0.354527302293833,-86.49851190288905,-0.5705401553584973 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark13(-97.64044311432131,-0.04010411667165137,-10.37072790910571,0.24387035033795712 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark13(-97.65466839502211,-0.21256291218409365,-66.20509270096004,-2142.123907295278 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark13(-97.67010808664647,-2.220446049250313E-16,1.5707963267948966,0.9987978372585363 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark13(-97.67952609411151,-0.41234862501665126,0.23416778145310022,1.0 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark13(-97.70047390404876,-0.059524018084232744,-73.80243073766772,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark13(-97.77106654153687,-8.881784197001252E-16,57.59256423913875,1.0 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark13(-97.85637929544248,-0.5072327590119841,-97.00313238397034,98.163415818951 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark13(-97.86018737718037,-0.6501994118586293,-42.11262750361096,0.05060854172582532 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark13(-97.8671022632344,-1.5707963267948912,-20.810250286694227,0.9421415704457358 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark13(-97.9036694423837,-0.13729425899700878,-28.10129941968023,0.9280299794420266 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark13(-98.03519523544709,2.483050463527572,1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark13(-98.10031908356932,-0.06783072266311117,-2.428864666527194,-14.441679266644144 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark13(-98.17276179681392,-0.4878155451728752,-1.5707963267948968,0 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark13(-98.24568847548456,-1.5235227780211313,-6.465992691588106,0.8329031675224132 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark13(-98.39273717191926,-0.9587533333375926,0.10306628331200766,-1.000000316698508 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark13(-98.42022451874598,-0.8610465337880078,-1.5707963267948966,0.7034033183666595 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark13(-98.42078098869759,-1.0096957889427594,-20.801625978382503,-77.97299078778238 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark13(-98.43534445800998,-1.0287363043233566,0.0,0.36217748989825205 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark13(-98.44036372947727,-0.11754046508551094,37.90065854961725,0.8098888037131008 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark13(-98.44856592997387,-0.007072427117303319,-1.5707963267948966,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark13(-98.45433375891739,-1.3464891995282269,0.0,0.4133966791441543 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark13(-98.65730402637185,-1.16288906461169,63.57564346418215,91.69216350459902 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark13(-98.78578616680481,-1.5707963267948948,1.299761694178016E-15,-72.15575503074028 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark13(-98.80846827507588,-0.004251438342220934,-1.5707963267948966,-0.9206037330146064 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark13(-98.87782062348131,-0.23398789487345298,-73.44767231794995,-1.0 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark13(-98.9469633111388,-0.9229947547490385,1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark13(-99.00357713019335,-1.2559604150214945,-71.76621730980236,-26.388865531552668 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark13(-99.01764289861347,-0.001795994447376284,21.632831226506852,0 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark13(-99.03147112531376,-1.5707963267948961,-56.1440430236734,-83.68255339057905 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark13(-99.1522732536505,-1.547410753304886,-9.791188712759435,-0.753388263207055 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark13(-99.18618890183271,-0.4643124103951237,-74.64116072242737,-0.7839026510370479 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark13(-99.206119831963,-0.1737707234738326,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark13(-99.25089265488045,-1.531234000885583,-55.313515704702645,-42.16572034432975 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark13(-99.34802742269643,-1.5707963267948888,-1.5707963267948966,1.0 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark13(-99.38687137012951,-0.011715695226002852,-44.46970822582184,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark13(-99.39068023533548,-0.6652604760086952,-6.76017121705743,1.8033161362862765E-130 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark13(-99.39431415876065,-1.5707963267948948,6.798930192281219,16.658862923211302 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark13(-99.45435137226998,-2.785581808319378,-0.4993624105548804,0 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark13(-99.48615014431394,-1.435061120338567,0,0 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark13(-99.53124696358138,-0.5680583863007191,-1.5707963267948966,0.2388254443435396 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark13(-9.955165668006837,-0.3659632609670558,0.8346068832092375,-66.82596238408496 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark13(-99.56667093659057,-0.3369621948936643,1.5707963267948966,0.6284465944997216 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark13(-99.57377172021732,-1.4398653861291095,164.93122337815407,0.6311009422423268 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark13(-99.58035000484827,-0.8015213745769072,-38.81639904126292,0.9999999999999999 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark13(-9.960559325333996,-0.9152385427989647,8.991393283666033,-0.3938863253156919 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark13(-99.60808833571454,-1.0964280928402388,-60.14308757687435,-1.0 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark13(-99.61312871316403,-1.5707963267948912,-15.638975600323821,1.0 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark13(-99.62467786258226,-1.2634121511074865,-88.1704548345078,-0.3624973141154989 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark13(-99.7047460181241,-1.2859222875947156,-66.44567456394472,0.9999999999999982 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark13(-99.71513430161073,-1.5707963267948963,-95.76828239323338,0.9999999999999997 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark13(-99.76435253306144,-1.3758596887585042,-1.5707963267948966,-87.76324265953106 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark13(-99.86221048756214,-0.18328772090142,-76.0609520704907,0.8667601422567857 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark13(-99.9335389473632,-1.5298883221989883,1.2313258598051307,1.0 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark13(-99.93876501936036,-0.0035978451363453947,-77.56778629843203,0.9611897423613471 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark13(-99.9399988854464,-1.5707963267948957,-1.5707963267949125,0 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark13(-99.95285593321873,-1.066909781447364,-10.506361969606786,1.0000172413211634 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark13(-99.95848993145164,-0.356602576531932,0.028054209582351768,-1.0000328628839308 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark13(-99.96164111158134,-0.009557693427807998,-41.297821433654505,-96.16504304261304 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark13(-99.96392493293064,-1.5707963267948963,-90.54544011389774,-0.0627935064945293 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark13(-99.97230189649002,-1.306963467071643,0.7452407286160688,-0.9953558544245266 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark13(-99.98076289307333,-7.105427357601002E-15,22.257450664945353,0 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark13(-99.99014061488296,-0.29918947569738963,-80.01502280633741,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark13(-99.99908166917147,-0.6613246387555072,-1.5707963267948966,-1.0 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark13(-99.99969331659432,-0.042056811579293946,1.5707963267948966,-77.71169433395463 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark13(-99.99982700502207,-1.2448386235223652,1.5707963267948963,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark13(-99.9999991424522,-0.8334527687886694,-32.67784627831591,-5.293955920339377E-23 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark13(-99.99999999999915,-1.1577451383570904E-14,-37.37366938290731,1.0 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark13(-99.9999999999999,-1.5403188174705789,-1.5707963267948966,-0.9944509571549558 ) ;
  }
}
