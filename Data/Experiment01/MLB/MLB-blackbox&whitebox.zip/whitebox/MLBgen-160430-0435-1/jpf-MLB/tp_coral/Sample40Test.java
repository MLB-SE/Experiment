import org.junit.Test;

public class Sample40Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark40(0.0011058535171828308,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark40(-0.8214131283361183,27.349143361767076 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark40(-10.860078209380376,58.69615235036986 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark40(-1.6484952795234162E-38,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark40(22.38824735885629,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark40(-3.262787586556382E-9,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark40(-4.779035803854051E-38,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark40(-5.108915476405296E-5,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark40(-5.23884419283371,32.6843326696212 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark40(-6.512107444088889E-36,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark40(-72.44701846320132,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark40(89.4908350459811,0 ) ;
  }
}
