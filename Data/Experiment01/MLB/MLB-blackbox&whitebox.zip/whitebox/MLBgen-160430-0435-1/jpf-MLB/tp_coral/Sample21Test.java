import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(-0.0014898053462310903,0.7515576442945988 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(0.0,0.20570343343391073 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-0.0024520603140093045,-231.698065889841 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(0.007604877906755402,-217.0925243501914 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(0.007623295585970986,206.1897720583185 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-0.008559881502743517,183.53089705375714 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark21(-0.011930334126259389,-136.92013418593248 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark21(0.013489475079631935,-116.44606814134076 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark21(0.013895617615836211,117.75778077525814 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark21(0.014580278353054721,145.9963439226724 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark21(0.015495310964974664,-135.00729774987332 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark21(-0.015594674534416129,-101.05273079685243 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark21(0.015707963267948967,100.0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark21(0.01570796326797061,-99.99999999988248 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark21(0.017528981886966083,-89.61138398818717 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark21(-0.017772651246174113,88.38278009495289 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark21(-0.01785331762761515,-87.98344148458037 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark21(-0.018033690831956047,87.10342998735547 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark21(0.0182287639112792,86.17130573644725 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark21(0.018356037034010245,-85.57382641386657 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark21(0.01880932011448394,-83.51159516846786 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark21(0.019639034756764318,79.98337730187394 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark21(0.020304184437161865,77.36318253295286 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark21(-0.020996625522518197,-74.81184655649885 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark21(0.021886710394105138,147.1296006968901 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark21(0.023251007447553068,67.55820496544578 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark21(-0.023968607618792753,-65.5355685143472 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark21(0.024743275292411264,63.48376713395976 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark21(-0.026950046366870595,-58.28547770982166 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark21(0.03038336870672064,-148.32243819808633 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark21(0.030422303440896522,-51.63305039825774 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark21(-0.03334794696284327,-47.103239325200406 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark21(0.033676895946321284,93.50550694057466 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark21(0.03450724441584929,3.1313618364947615E-11 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark21(0.03559998701484801,-44.1235084199233 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark21(0.035804804046415756,87.7942213146943 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark21(-0.03599340038736313,-60.85910158100745 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark21(-0.03695446925901813,42.50626130725907 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark21(0.040385412790903914,80.88547569363749 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark21(-0.04117455565318061,-79.33522540242554 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark21(-0.041764431965172794,37.6108629492382 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark21(-0.04508686269118513,-72.45114166192668 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark21(-0.046148566287756786,70.78430044647173 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark21(-0.04676439388562936,-69.8521365867616 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark21(-0.04763542114523655,68.57499749537544 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark21(0.048265090490442475,67.45141555432447 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark21(0.0497777460950104,31.556196292952496 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark21(0.05012165317801791,-31.339675114383663 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark21(0.05386314902820388,66.35634424934098 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark21(-0.054842044450092935,28.64219127031897 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark21(-0.05537512132717364,56.78485806674709 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark21(0.059611635584537775,-54.7979034891369 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark21(-0.06130398491591984,-25.623070489614832 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark21(0.06894148585375613,8.881784197001252E-16 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark21(-0.0704699329659273,48.06526483607737 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-71.47007000288106 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark21(-0.07328718326016542,-21.789633601640332 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark21(-0.07428631344206066,-21.14516462066777 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark21(0.07527388913928242,43.39654276228624 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark21(0.07587805345403664,-59.00316344206 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark21(-0.07619927307923469,-27.17606406351948 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark21(-0.08041336014037137,-19.53402176022574 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark21(0.0,82.03424797187978 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark21(0.08718480657396102,-6.546939424277816 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark21(0.0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark21(0.09250081476560605,-16.98143233413935 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark21(-0.09698409089129285,-103.06412342209377 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark21(0.0,-9.805558295845529 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark21(-0.09816645893500568,-16.00135467690543 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark21(-0.1024603548511176,-38.08070829012635 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark21(0.10623038750963265,-100.0 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark21(0.10901736661624399,-100.0 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark21(-0.1105350631735664,14.210842077580155 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark21(-0.11516124177441169,14.256144486533572 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark21(-0.11678840731698469,-13.449933626815152 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark21(0.11695242706673525,-13.431070788283606 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark21(0.12008814870590623,-27.20162388066663 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark21(0.12614225824667497,21.23481766898621 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,12.561960668698575 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,-12.829807481238156 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,14.414495751823274 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,32.3724496607817 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark21(0.12634012757103655,83.58297202894236 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark21(0.12713604152208063,-12.355240166275635 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark21(-0.1314710091817014,-23.895716779893466 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark21(-0.13278824411347456,82.44604047686659 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark21(-0.14612798173963723,22.354327000671056 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark21(0.1538864664680442,-21.228348410553476 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark21(0.15657540975177595,-61.2353931104009 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark21(0.16600396897346137,99.25788222012896 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark21(0.19251675356535553,3.180623962505192E-16 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark21(0.19880170312599724,-47.40793707260927 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark21(-0.19896253906585254,16.9209224105401 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark21(-0.2146869851204087,7.316681660576258 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark21(-0.21896476786061553,-2.6067292379901885 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark21(0.2249342570014474,18.79418808746542 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark21(-0.22736094587191558,-18.220691555827607 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark21(-0.2371271922077618,89.76517837411113 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark21(0.2385104828651359,-45.96903220574805 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark21(0.24727857218757085,13.212962816811121 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark21(0.2506315039296881,12.534718101110167 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark21(0.2819584310651702,5.571020951070025 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark21(0.3003517357907722,34.97838850832671 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark21(-0.3231803588605757,-7.653583527106115 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark21(0.3254520375145794,-4.826506353411688 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark21(-0.3496077623615328,67.39537115185047 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark21(0.3525397006150017,-100.0 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark21(-0.37913242800332436,-8.615967697073277 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark21(-0.38712767027150713,-4.057566656742157 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark21(-0.394770391546228,3.9790125106455836 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark21(-0.4056717876575832,-6.782915970258614 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark21(0.4279214302535559,-79.7269000501561 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark21(0.4483728793389724,-10.509977738466421 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark21(0.49468703905436795,21.437449701969513 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark21(-0.5036208391612439,-3.119005816778713 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark21(-0.5097225582602154,3.081669236214184 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark21(-0.5254189200846121,-8.312067780748986 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark21(-0.5337356756368453,2.943022920325958 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark21(-0.5381718573037102,6.079861119365332 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark21(-0.5544873160390906,-2.8328805391179728 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark21(-0.5600676745242192,-64.30412435227609 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark21(0.5634502651900353,-2.7878171754256154 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark21(0.5756952997163243,-2.728520325890269 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark21(0.5850774768091228,18.609395342154837 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark21(-0.6108295103994124,-2.5715789758876846 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark21(0.6193854190873569,16.25058908110951 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark21(-0.6374968582820963,43.456743245691406 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark21(0.6496146110049263,23.686063191394 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark21(0.6700550657072801,-4.8751107566050464 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark21(-0.7147168106525257,100.0 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark21(0.716724729448668,-4.383262534205393 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark21(0.7377307052632047,-2.129227258115108 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark21(-0.7447807906044829,-166.60997610958304 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark21(0.754980409254209,-21.109001430469107 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark21(-0.7558510162625014,-85.75441840539108 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark21(-0.7587804052087322,71.13767180501986 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark21(-0.7622889829676057,22.666799488295137 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark21(0.7689178720582277,-2.1241490540829706 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark21(0.7705005095072059,-36.69573067512213 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark21(-0.7798095978689004,-84.6204042841486 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark21(0.7853980507120972,42.04319236904044 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981401214374,100.0 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981632977778,-11.665323746550298 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633967662,20.197385624484454 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark21(-0.785398163397422,100.0 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974385,100.0 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974385,-12.3117203292678 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974385,-93.83726694400431 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974456,-19.97385943824102 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974456,59.883154223244425 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974474,-35.26471659823505 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974478,68.56829743819225 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974482,100.0 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974482,-2.0000000000000906 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974482,26.1178537811824 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974482,-45.44103997657349 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-100.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,100.0 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-10.102438011745889 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-10.228443702905604 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,11.14909671059901 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,11.928645248727662 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,12.549551443689829 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,13.29859413975474 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-18.699257276771363 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-19.00170074620054 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.0000000000000036 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.000000000000014 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.000000000000014 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.000000000000451 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-2.0000000000013216 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,2.144451795348303 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-2.1466162371871036 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,2.4099266919382174 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-26.760701182686276 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,27.384137281574986 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,28.986087080874853 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,29.61770319755702 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-3.1188754979203175 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-3.1617780455023374 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,3.2052305535416266 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,3.3228411168009444 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-3.510868365875113 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,35.558507912016154 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,35.658644232870124 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,35.872171107256584 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-35.99944665582737 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,4.088885303256398 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-4.103347408874171 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-42.01253681053866 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-43.75143904185136 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-44.12478115666618 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-4.479675421183895 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,51.4189204458269 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-51.99229444143749 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,52.132170764356914 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,52.38487951014248 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,52.93812823353294 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-53.51067224125931 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,53.98173353198738 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,5.407448106457949 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-5.428303626223882 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-5.762523363522188 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-67.42573691578367 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-68.61342018005129 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-68.77927454778848 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,68.80794985793018 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-75.93088009801572 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,77.04595779772963 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,-82.7048735102122 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,83.97101452305317 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,84.69675487585148 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,85.7455768898409 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,91.04906760744036 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-92.84970988806506 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,93.7646912689176 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,-93.77184341853028 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974483,98.08454300060684 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,99.61796528312706 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974483,99.99999999998414 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-100.0 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,-12.548051556719612 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,13.677039845035146 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,2.000000000000007 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974484,2.00000000000016 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,51.329037505211204 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974484,52.16011845638913 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,-100.0 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974492,12.683976003948345 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-1.9999999999999991 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,2.000000000004217 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,2.8338730425974603 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,29.845582828362865 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974492,-60.2105342533446 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974527,-100.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark21(-0.7853981633974527,-4.147202113062146 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark21(0.7853981633974527,42.39916306505133 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark21(0.7853984473857916,-4.921334384631294 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark21(-0.8195832497687835,10.066304699023567 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark21(0.8326232861692854,-100.0 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark21(-0.8548009217393187,-1.8376165570793908 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark21(-0.9117382909684849,-3.481730947193583 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark21(0.9832364365208353,-4.144050584645277 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,-100.0 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,100.0 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-100.0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark21(100.0,100.0 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark21(100.0,-11.898193090774459 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark21(100.0,37.42162367596315 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark21(100.0,46.47986330986098 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark21(-100.0,4.998601715132466 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark21(10.050858407557168,-53.31074447313134 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark21(100.58662276991114,-75.04219914412629 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark21(10.091839143383382,19.298918169005344 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark21(10.130449796262411,-96.49150518337098 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark21(-10.258516085034202,-35.24771604171707 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark21(10.267645009790755,48.71094742407473 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark21(10.309427411602215,92.1850192645887 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark21(1030.9809455990835,39.743081526472054 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark21(-10.347782822237235,-95.57784572165903 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark21(1.0355965612286866,1.5168033436990371 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark21(-10.358663095286175,18.96817464288121 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark21(10.42417074202038,90.61873780416258 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark21(1.0428494582609886,1.6371789339073786 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark21(104.40787610241077,-35.718156381636405 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark21(1046.5061853792038,-65.39909397129126 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark21(10.657748471648759,-74.66251711540735 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark21(-10.72020438318038,0.14652671447751686 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark21(-10.769772356601464,-40.61481551183779 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark21(-10.791522150206774,0.14555836562549018 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark21(108.2807952599061,-56.19723336086042 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark21(10.83960874871401,-19.556747686483675 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark21(-10.847634046383092,-36.767752560000304 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark21(10.86923415999324,-0.144996111752981 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark21(10.86923415999324,-23.896300449615797 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark21(-10.995574287564276,-0.29353844332288276 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark21(-11.120574287564224,-0.19318165542092913 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark21(-11.132404587669987,-79.3156887623378 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark21(-11.23579836039076,-87.62238126743956 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark21(-112.44395237047884,-1.5969113833042783 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark21(113.09733516341547,8.423189686169598 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark21(113.2236756568036,-25.728400740058564 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark21(11.533480584073828,40.44975891339289 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark21(1.153629028112995,1.361613038954772 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark21(-1.1548608932512572,-2.7213345850547364 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark21(-1161.0555123044867,130.1419256798271 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark21(-1.1621486316831389,-72.16122815016799 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark21(-11.670217318122711,0.13459872116996507 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark21(11.70313933881748,39.453277331440546 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark21(11.719939331133872,-52.72888462155969 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark21(-119.37807876530253,0.0715438836986948 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark21(1197.1027952497711,9.981317450328817 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark21(-1.2015561010328493E-9,-0.007061719143239743 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark21(12.049702814894232,88.25830795072588 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark21(122.52211342643206,-0.014425841883795013 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark21(1233.595188813425,1495.6711905426303 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark21(-12.345894591810818,-82.67635278865515 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark21(12.429563273419571,-14.99348394026931 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark21(-1247.592960869927,-1317.183163850352 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark21(-12.52738282337971,-20.657640983492428 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark21(-125.5373660160207,-4.491135471325534 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark21(-12.566492684671674,11.340649527199016 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark21(-1.2657588301930467,81.3120638793119 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark21(-12.684334657215413,95.41314801576218 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark21(12.708429892389109,68.48019478780185 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark21(1.2838873807447584,41.14092269029524 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark21(12.84978373571091,0.12224301662212156 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark21(-1.2853981633997165,-1.222041583526233 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark21(12.963786707019015,-37.13610844075319 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark21(-130.20360540486953,0.004352690506070496 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark21(13.066370614360379,-0.8342061791395023 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark21(-131.1374141375859,22.731345180606986 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark21(1313.1655057668713,-1244.5998763665455 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark21(-13.2268767126369,75.84662803219095 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark21(-13.298580239474967,23.4670550547917 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark21(13.321241901267484,65.06084411993848 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark21(-1.3393234345425071,12.571268828638637 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark21(13.464110213891445,-0.1166654388475108 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark21(13.53246790379805,47.9754977884774 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark21(-13.566370614359384,14.1972324940279 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark21(13.566370803412443,0.11578604059497653 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark21(1.3588912898565342,-48.101500971977714 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark21(136.21917863627186,0.004189315435798799 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark21(13.668138616000732,-49.780836232737414 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark21(-13.701836180388767,42.395067149146485 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark21(-138.1190439150156,159.4649657686106 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark21(138.56672622696925,-147.8924460102865 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark21(-13.895769163788103,-39.94749438135533 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark21(13.903690429615576,15.209155563044256 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark21(-1395.3761824181065,-184.54376948918454 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark21(-1409.263479970997,1269.0859530756672 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark21(-14.095753469581851,74.17142732944009 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark21(-14.136855306732317,-56.309334167061785 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark21(1.4162385439209577,-2.924375868300669 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark21(14.169647003192411,85.39828265943893 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark21(-14.173084391451367,-30.896400672538434 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark21(-14.176297602505176,-9.158085057922989 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark21(14.238906586022939,-83.69363724715483 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark21(14.250725238538081,96.76840762177201 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark21(-14.263507068725106,0.1930989684761038 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark21(14.27498455622731,-2.951129625051067 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark21(-14.328946379473479,0.10962399364441211 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark21(-14.383761366511806,35.628450503590585 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark21(-14.509202330944234,-44.42522132698543 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark21(14.527637554958574,-25.218294753476076 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark21(-14.586804947596946,26.45735340713469 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark21(-14.592899105294777,-65.5542750077133 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark21(-146.49461768364966,10.400995665210733 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark21(147.30696998334275,-19.26178450154015 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark21(-147.52408318978348,74.11944074887994 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark21(-14.754049406584018,-50.932424288707985 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark21(147.6548539106632,-0.01854230990198591 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark21(-149.21160529477737,63.98496589701941 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark21(-14.92899389548073,37.77260626894432 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark21(-149.35174195702098,-94.2109147189568 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark21(-14.983999158842224,100.0 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark21(15.097926156550685,0.10404053579990236 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark21(-15.12040308437335,-91.3127765320671 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark21(-15.193390008766837,-19.992280870502043 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark21(-1.5197077108176131,85.79024387119361 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark21(-15.216215782440505,-93.02213769525906 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark21(-15.236735435503718,77.42616951381578 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark21(15.273222353553418,5.554857154412527 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark21(-153.8248239378711,41.88794999129599 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark21(155.49021271102097,1.1067113734842118 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark21(-15.585877956480454,-0.10078330724653052 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark21(-15.634831842556583,1.8879684460817714 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark21(15.707963220482124,-0.10022806470204158 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark21(1.5707964965773862,-54.09005497978829 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark21(1.5837492793679302,-2.9754640092182982 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark21(-15.895643343973825,-8.436883173225468 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark21(-16.018194769769508,-37.411894679815845 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark21(-1.6020742958162408,-18.369914403090984 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark21(16.161363086156197,5.612635121933181 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark21(16.190644398279616,-100.0 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark21(-16.203630268365174,45.955754468780505 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark21(-16.22862319259677,-0.09679171844420864 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark21(-16.262740088991958,57.37016494768318 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark21(16.279591109821112,0.09648868427950674 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark21(-1.6332962891985723,-1.9756480880373033 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark21(16.35946530854108,-81.60784006102544 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark21(16.46835670643216,-5.825613715231697 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark21(-16.495314556346415,96.56756325396009 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark21(16.516346677970944,-66.76640401647637 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark21(16.81767805660992,23.36172481242304 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark21(168.87426975505514,-58.38597289627516 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark21(16.91160172925106,264.0618597917651 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364543659333,0.9882311430343423 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971364543659333,-1.27999960778692 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark21(-1.697136454365933,-57.95837159004809 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark21(-1.6971550250032281,9.925704101713443 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark21(-16.972894273107514,-66.42697859816506 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark21(-17.018033836148142,-42.36655779044147 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark21(17.018327690427085,-48.194147881355384 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark21(17.01892255839455,49.92047659418003 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark21(171.2461317130191,92.92902209281087 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark21(17.152419467172827,-12.998369407971067 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark21(-17.230367533961015,-0.09116441211708981 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark21(1.7260843801104764,1.4895341692323334 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark21(17.33153612700332,42.91320886549133 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark21(-17.3374239207701,-8.880030931982786 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark21(-17.38965276546223,-2.848052674186344 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark21(-17.4050997223149,25.824392510153686 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark21(1.745454758432799,-0.8999352857505604 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark21(1.7519687669423871,-36.963094806089835 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark21(-17.583476457470393,-40.90952172604791 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark21(17.587141987818626,-72.04335426993285 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark21(17.589470192193517,-54.75367221441993 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark21(-17.63846479544597,-100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark21(17.675884783151936,45.393815083173976 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark21(-18.173532535029665,-34.86562765512883 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark21(-184.69035051183388,-45.63393189668652 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark21(185.5341115495038,-29.133176323790416 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark21(-18.630168016337095,-85.23379720632633 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark21(-18.72466385641904,-0.15320512965963562 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark21(18.849556862493234,7.895705663198009 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark21(-18.849756854502235,5.205162638903913 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark21(-18.862781933838452,-0.5718765412025659 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark21(1.8888238204279162,0.8316267032464779 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark21(-18.948369760095957,-13.207193822811789 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark21(18.974555920084864,-71.35642832377924 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark21(-18.97455592153895,61.099403102144834 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark21(19.097240065349975,-12.995899868038608 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark21(-191.54101447847415,82.08304535823845 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark21(1.9202683834430803,-0.8180087431208068 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark21(19.353907843908218,0.1038697949187295 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark21(20.106299592745586,-26.984951142705697 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark21(-20.28001478856372,0.0 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark21(-20.340575819012315,53.3397908513534 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark21(2.0417791722633325,35.949766419348805 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark21(-20.53361168051839,0.07649878410265387 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark21(2.0592704407516527,66.10887709398189 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark21(20.602325260571504,148.9450190002123 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark21(-20.654220242568652,-61.04401979733253 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark21(20.736028385778734,2.2767996687581604 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark21(20.745844145647176,-65.26735784793495 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark21(-20.788924156236675,-7.66734782310057 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark21(-2.0820849724618564,4.55397895810086 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark21(-2.096410383153331,1.0695044203103445 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark21(-2.1066556200001596,58.159536056516465 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark21(21.222155372553882,-38.692504372756474 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark21(-21.297256416180787,56.26099335061053 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark21(-2.134189561155271,46.28239728445124 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark21(-21.675831147921073,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark21(21.705584820854007,-2.4298456313276326 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark21(217.7594947835562,-100.0 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark21(21.853185799219844,-10.178359754400677 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark21(2.1961400317509825,1.4744113242985792 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark21(21.99114855364033,-6.731574812931789 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark21(-22.099108313012184,29.395547765176314 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark21(22.115064337730644,-28.272891217700206 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark21(-22.230805151477337,81.21224342923335 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark21(22.326163768475592,42.34959633226657 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark21(-2.2360052592201356,0.0 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark21(22.57193138762968,-4.541536011485022 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark21(22.622893818018966,-59.57883523914549 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark21(-22.64438624125903,-2.845337415979671 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark21(22.744656139242466,-34.08235083601974 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark21(-22.772632001340405,-15.093319277281935 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark21(22.943225607498036,56.31043730807093 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark21(23.04764114317574,-19.015055487031532 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark21(-2.3152582466814753,-2.0353621403310376 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark21(2.3365372320130504,1.8074299319609608 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark21(-23.5619449019103,-0.0686334791923319 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark21(2.3561944901919265,28.449679265887028 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark21(2.3561945286474675,-57.41732670938437 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark21(-235.97812771969149,-33.615577435833416 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark21(-2.3667514275411037,22.001876407201323 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark21(23.822252040473966,30.20113319782051 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark21(-23.834535538815004,28.40193152378137 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark21(-23.839351727775338,40.40161522100461 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark21(2.409863440786417,-1.3311678369800077 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark21(24.12993785510953,-73.59708623296939 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark21(-24.472562538210514,0.4294295002767399 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark21(-2.4487309765380445,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark21(-24.599432299146436,5.03325324526536 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark21(24.84734306531975,96.216135607506 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark21(-24.959226681438736,98.06229508483526 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark21(-25.039413728844803,100.0 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark21(-25.103789467971943,18.106645539180914 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark21(-25.116933865155943,143.9684748074501 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark21(2.5193562974519494,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark21(25.21532931592512,52.452636671534094 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark21(25.259081356289382,0.06300724165895963 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark21(25.259081356289382,74.28828850125886 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark21(25.298034244290776,-76.98620069567943 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark21(25.382741228718356,-0.06188442425012397 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark21(-25.412285889627412,-55.71296724864696 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark21(-25.436316970382762,-25.375173379711754 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark21(-25.546375545874703,-12.462629729825721 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark21(-2.5660030956578255,-26.15867323364036 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark21(25.855334077309777,-74.14153053143949 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark21(-26.01971918846438,57.84288763628521 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark21(-2.603185376932089,0.6034131647766685 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark21(-26.262813751850672,-78.61619936846058 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark21(2.6342361248173627,0.5963005032070932 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark21(2.646755150408694,-1.205568231915141 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark21(-2.650063858158454,27.660603981241415 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark21(-26.578406132137758,-87.8082138559914 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark21(-26.6678718287434,-77.17573223243346 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark21(-26.680256065352708,0.0 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark21(-26.695335967580508,52.563535691650706 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark21(-26.703537555513147,27.654000242630723 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark21(26.738193755569515,75.59765488530313 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark21(-26.74839063622636,24.06003132945159 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark21(-268.9674541701653,-100.0 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark21(-27.396251130786055,-64.12673879615245 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark21(-27.577100242511918,-10.126122190563876 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark21(-27.581604056530324,13.274853999650073 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark21(-27.84140977992604,-0.05641942485065243 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark21(-28.048844473650625,-33.08623243319809 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark21(-28.082811451759568,0.05593443980828283 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark21(28.083437446092418,-22.459438628089785 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark21(-28.12655035083933,100.0 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark21(28.274333882308127,0.05573773304285427 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark21(-28.27433389294735,-21.68246600713603 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark21(-28.289958882318917,0.05552695868131041 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark21(28.400674009879175,0.10500754309661763 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark21(-28.699981367756862,58.97622135247482 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark21(-2.8705032090851574,93.93362964713285 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark21(-29.000840733034806,-12.934913109370356 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark21(29.113011746752772,83.20490139290808 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark21(-29.316563485992653,23.26944943771882 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark21(-29.36684310697646,-89.92069041771018 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark21(29.467321666966967,45.768219047652366 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark21(29.601576619367137,83.09673049237406 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark21(29.718790081532,41.33477955744728 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark21(-29.90554266574948,-17.30191343805305 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark21(-29.906923983501628,-24.035764547535592 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark21(-29.9530771330287,54.47875531692003 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark21(-29.977782198975667,34.94391494182249 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark21(-3.016700588470071,30.573488370731184 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark21(30.36815340100893,-62.846018717502666 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark21(-3.040018930435309,-50.334383614666336 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark21(30.424165827422456,-22.009092795989883 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark21(-30.568941485853756,8.881784197001252E-16 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark21(3.06192088466143,-52.32658934242603 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark21(-30.709641606190445,-38.14229584377622 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark21(-30.82182410111949,12.511778313235354 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark21(-30.883413395209654,19.819253217949104 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark21(3.092322197067938,41.553046419813214 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark21(30.995138689425175,15.55702313176181 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark21(3.1186800666623182,95.69795389801942 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark21(31.257390451048966,-0.05025359776129951 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark21(-31.297153504570566,69.52507306766411 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark21(-31.323080333451955,-45.237154185101986 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark21(3.141592653587336,0.9990165556404786 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark21(31.415926535896006,63.33458828318129 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark21(31.415927603344404,-35.11753098773064 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark21(31.41638599607882,-10.289421038447742 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark21(3.1448620127181073,-26.86154895606205 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark21(-3.1575803604009423,3.552713678800501E-15 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark21(31.589930955972,31.95020927878285 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark21(-3.1616379617440202,-44.894303303436665 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark21(31.6574362625598,-5.038230242832114 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark21(31.66546236915866,-74.25512664861695 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark21(3.2140876336977744,0.48872230810870576 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark21(-32.19922326774349,-51.37115557589888 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark21(-32.297332029315285,5.549802269333196E-16 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark21(-32.4527978418687,73.62485219886042 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark21(32.45712588120061,-8.030530209426786 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark21(32.55957075772044,-21.475383198021532 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark21(-32.5612179799496,31.021503206302043 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark21(32.634039877818935,-65.59976150014539 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark21(3.266592643618388,-16.81255600573832 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,0.7201246814567808 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark21(3.26793278116083,1.0937867008061204 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark21(-3.2724665305486127,33.765382486089905 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark21(-32.76350185139542,14.656769491656341 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark21(3.2836526632072176,48.31522858250627 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark21(-32.9665077949919,-75.42659089066963 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark21(-32.97295147839826,-1.1985553725252505 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark21(-32.986722805397704,17.250584655015274 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark21(-32.986722862626024,6.987761526773523 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark21(33.13054207302207,-41.44537298505442 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark21(-33.13748836247547,-12.63370605230405 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark21(33.20598829697387,-66.36243388630645 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark21(33.44989609621401,94.15816930297402 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark21(3.3516807969343354,28.71736153123898 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark21(-33.82761805517664,27.167730664635044 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark21(33.910577712446454,-42.90967145121183 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark21(33.97445764555338,57.41549954559851 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark21(33.98824090821579,4.00420250891791 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark21(-34.10385405969509,-48.55631242051288 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark21(34.252501456869474,90.92279029668342 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark21(-34.34099531381794,32.33219834965439 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark21(-34.44648788862233,-1.5630433657228524 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark21(-34.454605646166094,-0.04559031506343558 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark21(34.464333213941266,34.00268730085796 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark21(-3.4557973645291122,83.08895182160532 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark21(-34.56533623644462,39.562206465292014 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark21(34.68385931705876,-0.0454413243336915 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark21(-3.469446951953614E-18,86.38935375182996 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark21(-34.80751918948773,-10.600452760852193 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark21(34.81609585000892,-4.197564614594702 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark21(-349.5906294840931,78.84270978261742 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark21(-34.9660488804096,63.308138075311575 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark21(35.12424100672155,-42.952613080180654 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark21(-35.42072659532177,-2.9223355047286645 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark21(3.552713678800501E-15,-6.300251886360101 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark21(-35.531040950215484,-68.67376024112748 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark21(-35.77805208399778,-36.531774264193515 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark21(36.08373612824577,59.82862597087539 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark21(-3.652075639935375,33.597181275000516 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark21(36.53101256655893,-98.98074487772656 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark21(36.89825826759789,-16.075868820213387 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark21(3.69252316213997,-36.582361039394236 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark21(36.94161863655434,47.71899888600076 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark21(37.69782896699227,-42.26657914682349 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark21(37.699111843179004,-1.6144086894153045 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark21(-37.701258278152594,-23.770798933804898 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark21(-37.79685678281664,-100.0 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark21(-38.03753793809055,63.162659913706094 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark21(-38.21488390766188,60.90444343484944 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark21(-3.8374201667604098,-19.33133261735209 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark21(-38.4473945682577,-9.537783221269105 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark21(38.45751714414604,-43.02707492728612 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark21(38.46679936514234,13.610902583039817 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark21(38.47745483974282,-7.785201979630287 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark21(38.7542834254234,12.070429709117803 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark21(-38.983552824349644,-59.120606498240356 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark21(39.03518287671437,-100.0 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark21(39.0589273230745,-151.92225506077568 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark21(-39.22952300765235,28.073104027777987 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark21(-39.268000112999836,-71.48347317137356 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark21(-39.26990816985502,-84.90844130238291 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark21(-3.926990816987874,-100.0 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark21(3.9269908173321393,7.291674257830625 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark21(3.9269916226599073,-39.20951979161997 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark21(39.35688935066224,-79.88796090351948 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark21(396.9599888171158,-61.58093571324795 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark21(-39.719850955946455,95.15814259774902 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark21(40.16262116371878,0.039110901661331354 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark21(-40.35836820477567,-57.509016934298145 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark21(-40.71436436909627,0.044603160478897605 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark21(-40.71436440131771,28.810404009709828 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark21(4.074599528533571,1.1565281317549891 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark21(41.05198977949491,-0.1914207008744495 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark21(41.14540804209733,-84.66492165852894 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark21(412.4995302253316,134.41087718735142 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark21(41.33400616385927,-31.549237495076653 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark21(-41.41871462874314,46.4690587181438 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark21(-4.151720175889523,70.68146317991167 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark21(-41.660579732523196,-17.35331570825089 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark21(41.67077077810944,-91.77916498302574 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark21(-41.75474425831153,64.3528494559672 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark21(41.7938190804863,-42.44464938685688 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark21(4.1805724388905,-0.37573713881436355 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark21(-42.21621768147194,-40.55408244418965 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark21(42.28516069589117,54.286532935639976 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark21(42.28516069589117,-8.842338797797106 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark21(42.298583353884396,-32.88498530276675 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark21(-42.34151144336813,-2.1264094633875077 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark21(42.35081793561005,-38.74464338012269 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark21(-42.35425333223477,-27.430547441103627 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark21(-42.3801766253194,83.09816191925722 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark21(42.41795625724612,-77.08946255174997 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark21(4.252672429629868,30.19678919552257 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark21(-42.61533505971798,0.19473786462762643 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark21(-42.64074359556829,71.83446623400854 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark21(-4.265930538028599,-16.971083286451673 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark21(4.2720509925997945,58.169551339248756 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark21(42.83161763727472,20.14944243102225 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark21(42.87459223478902,16.775118937579826 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark21(-42.94079531546234,-62.27247854566071 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark21(43.14797943724252,-66.50061410496576 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark21(43.168005207335455,3.11155892036912 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark21(43.19689898685966,0.4793778100543813 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark21(43.3640916984389,2.080218364657455 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark21(-43.85595702268607,-0.33501939026945715 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark21(-43.85595702268607,18.13181850915699 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark21(-43.9343937603107,-28.893013142529767 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark21(43.97238094122714,-38.5184937337286 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark21(440.8884588188588,29.73564036002992 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark21(-44.18048559199421,-56.91882519408542 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark21(-4.426990817452366,-12.062208523933991 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark21(-44.28597138421355,-0.035469388560255055 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark21(-44.33124324404189,98.51540985584509 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark21(-44.50447844161693,-79.56750531045924 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark21(-44.59970380299521,0.03869761925573978 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark21(-44.616233288682935,-57.96519337952368 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark21(-44.646500729673626,-64.63951850234248 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark21(-45.15849060672712,49.768787314562644 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark21(-45.22011162176122,-22.154914312636066 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark21(45.408844873796795,21.64728257075736 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark21(-45.436598601287855,-26.232643133062993 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark21(-45.48452843730785,35.32546812305023 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark21(-45.50519167501313,60.155091055853894 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark21(45.51436013248545,-0.21591889127577701 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark21(-45.51500145132198,136.01307910511082 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark21(-45.553093477051995,1.0430168419376302 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark21(-45.55452226516244,77.1703977950614 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark21(45.605065371966816,-188.74126524488653 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark21(-45.60626293110015,-44.41270254977947 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark21(-45.62531409474859,-72.5325912868382 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark21(45.70493757658048,19.170480157875417 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark21(4.586048852813653,29.26018704520688 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark21(-458.6673474857841,99.98061147235316 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark21(45.996661089058456,84.73980522024678 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark21(46.146167318265405,-87.06846334982914 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark21(46.16341131504761,-53.563887769053615 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark21(-46.244309780335215,-89.4430239096074 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark21(467.04464536378316,-0.22197560689980378 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark21(-4.709917680945118,86.04496473086917 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark21(4.712388980384703,34.09409042137897 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark21(4.7123889842368385,-73.69645568964532 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark21(4.712418565087305,-52.41223838430318 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark21(4.712633121009691,0.3333160648277138 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark21(-47.13951480696494,-40.69662531917836 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark21(47.19036480655137,-72.51742425641012 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark21(47.20503566744452,41.70249085150451 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark21(47.250229931417934,-90.65098020569266 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark21(-47.25648292317879,77.36232625747479 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark21(47.26226860260509,10.952423507510943 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark21(-47.36326061860434,1.8924876270748143 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark21(47.392453051876885,4.704177526053338 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark21(47.39315286482554,23.260941552654664 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark21(-474.647214013068,5.36775148311776 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark21(47.60077112814335,-45.1797415675471 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark21(-47.77905009545928,81.97622854180332 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark21(-47.79113197391647,3.859668140648864E-11 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark21(47.7983670854168,48.549031726382 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark21(4.785680504840343,-0.3282284149989032 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark21(-479.2035855888107,-71.81723511441355 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark21(48.019942220813675,-28.45332435977967 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark21(-48.2849812991392,100.0 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark21(-4.837370490038508,10.870403095369713 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark21(-4.838748743415268,-0.3543754283421148 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark21(-48.758386627281915,70.03757935855307 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark21(-49.065705322806245,-3.5214907884078794 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark21(-49.074605732723974,93.4762955850625 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark21(-49.09708059668017,100.0 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark21(-49.14883969694222,-6.457607316244557 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark21(49.23779263995868,-29.805682536238862 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark21(49.30188127709948,64.9290996545493 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark21(-4.934571284526458,-0.9591931374497288 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark21(49.90727212581422,45.28950680482217 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark21(50.069314219607435,39.739203968016284 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark21(-50.13950070792208,-96.82716040429278 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark21(50.15983235905003,2.9750029860016336 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark21(-5.016092570652475,-0.9186970652855777 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark21(-50.180327114979285,0.0313030308312392 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark21(50.2044463823391,97.31070543780723 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark21(-50.26548245743669,-0.031364059612307926 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark21(50.35565936169769,0.0 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark21(5.051647155969704,33.98884188544366 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark21(-50.59235715985834,-73.19830649252512 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark21(50.846365109531746,0.030892991532652007 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark21(50.900625970307374,29.07756479774334 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark21(-50.903200767691146,88.1831238387243 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark21(-50.92428181926327,11.064837178266515 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark21(-50.9245404932631,-100.0 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark21(-50.9245404932631,100.0 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark21(51.02127162909458,-40.91982315364336 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark21(51.07956720049163,14.811372965013891 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark21(51.31657997337928,41.47755493003231 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark21(51.32770163748668,-20.407778385298037 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark21(-5.1359802138463495,0.30584158454507027 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark21(51.42042143875881,-57.60124730310787 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark21(-51.48564843384036,-42.65157435156765 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark21(-5.148693290915318,-0.3050864059497371 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark21(51.73667741539958,17.85253505897424 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark21(51.7441898125992,-100.0 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark21(51.89877878423514,-12.894776772207447 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark21(-5.21238980734614,-1.8310080092791903 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark21(522.2335671922589,22.86561877146392 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark21(52.22781547814557,-91.95608641447745 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark21(-52.44460889457042,-88.25116532484887 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark21(52.45887676133026,0.029943384680946927 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark21(52.489793309419156,99.29203502860321 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark21(-52.510314309653864,84.04359811753034 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark21(-52.56797149271405,28.9892983788057 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark21(52.947829091312116,31.845548592544986 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark21(5.3051279655932095,70.67636705562376 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark21(-530.6153688920579,-55.79031570103425 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark21(-531.6438080787616,127.37074919737492 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark21(-53.417414116543064,-90.48473895658134 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark21(-53.4984914573146,-74.29143384185232 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark21(53.53341523859752,0.02937928104545051 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark21(5.36225274020714,-23.051912359247126 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark21(537.5759159240037,-28.72324933778644 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark21(-53.76151720110481,6.85606678893766 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark21(53.76345962502634,61.398954805763026 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark21(5.387753169482739,33.34251137837864 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark21(-5.408036119116009,-12.017604745692182 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark21(54.246776078772314,17.511551032647922 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark21(54.29057870743799,178.38498013741446 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark21(-5.444541676229704,-0.2885084586004716 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark21(-54.55256935762938,62.275241164706216 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark21(54.6994486219908,32.995670430976425 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark21(54.80749549218434,12.329909097396154 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark21(-5.483163411869165,-33.91486709115354 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark21(54.83363418297088,-92.53345550387688 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark21(5.49778714370868,-22.31988457776392 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark21(-55.03107901652321,-48.67360367616755 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark21(55.09847944480825,-79.1819369294318 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark21(-55.122706809270674,29.01094222700769 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark21(55.1228819719488,-8.598057640477279 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark21(55.147359157685955,0.1563343104701076 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark21(-55.3191543233235,-57.51467020594156 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark21(-55.764971457776994,-6.677790767223557 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark21(55.779641339984465,0.02816074627015297 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark21(55.793233583740665,-6.5621997584811576 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark21(55.82802775950307,16.81809388948436 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark21(55.839096996365555,-94.1498959738395 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark21(55.91252919511933,-70.96351704328526 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark21(-5.60165401457904,85.65259174270233 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark21(5.606538071110606,0.0 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark21(-56.29160054014009,34.107165748617234 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark21(-562.9638795280977,-52.39354741403835 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark21(-56.3385902230086,-23.800332462210545 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark21(56.484042282542966,-15.186822463352149 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark21(-56.50440874493202,-59.98188632857611 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark21(-56.50911074453569,-4.510153591850838 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark21(-56.54302265663722,59.524807717857335 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark21(56.73608787368089,29.762468908044614 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark21(57.01633065760046,15.797308052358574 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark21(-57.26759252635936,20.996819163266608 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark21(-57.40594252631255,-99.99288654933245 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark21(-5.765468015519005,0.2724490574862699 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark21(-57.798278012113144,-40.283742485634974 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark21(-57.99653513443323,36.970580389096455 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark21(-58.11946409141116,-0.07736823081526953 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark21(-58.12642807290827,-64.45299521462678 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark21(-58.1357352340562,141.07927138739788 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark21(-58.162492445687604,-31.601910662943354 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark21(58.16273556664146,-16.13810777813964 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark21(-58.21784333184243,-0.26428453703212856 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark21(-58.244464091398946,26.699645680804757 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark21(58.253412610006905,45.572562757525475 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark21(58.6330270080844,13.580234813439034 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark21(-58.701050100315214,-40.58509957419319 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark21(58.82265329474163,-14.053296471435885 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark21(-58.895915461041156,-40.05635908468701 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark21(-59.0247893178854,-0.026612485109183126 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark21(59.104429541957686,185.8897567670832 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark21(-59.12141188827638,48.71309185965465 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark21(-59.25805746898919,37.80865534311519 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark21(59.424263287674165,-84.42836723414344 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark21(59.47504848877696,-103.18141375454434 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark21(-59.56392029063503,-0.07358543916200233 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark21(59.581644894196955,88.11125557473002 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark21(-59.61066176299161,-5.222308899845302 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark21(59.6299484301953,16.105004599407152 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark21(59.65884449164099,-100.0 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark21(59.67643107908768,0.026325971611314003 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark21(59.680854671626776,18.688247864282715 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark21(-59.76471850712024,-17.509415337716415 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark21(59.816600545777106,0.06609160173146655 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark21(-60.0369261880894,11.519508356968203 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark21(60.3334498827796,-18.055271414833825 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark21(-60.723954372781776,42.66963639988887 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark21(-60.731964276298356,71.83567003450665 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark21(61.12285299266621,-6.612578018718413 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark21(61.18778648381917,-23.788309581545008 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark21(61.26105674500097,-10.825499696837378 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark21(61.36254123692284,59.6216326003557 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark21(-61.36487675245071,-32.61139948006264 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark21(61.374909385542,10.806990411755748 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark21(-61.387396872572005,-10.484261775533005 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark21(-614.5135129007581,104.8475421801856 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark21(-61.4548110409508,31.219625193698164 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark21(61.760938753945936,69.744127721457 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark21(-62.04833812094296,-80.6738952905615 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark21(-62.0554265358345,0.17614085072281108 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark21(-62.20965931599717,11.78785474704187 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark21(62.21033623649251,-91.7478227519509 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark21(-62.445416025167454,45.45456084998142 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark21(-62.455577565944616,7.07598690837159 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark21(6.256471441176862,70.04781786131718 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark21(6.283185307179585,-0.2559183129699498 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark21(-6.283185784016824,-66.63213679794049 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark21(-6.283188431668129,-0.30479886222108543 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark21(-6.283200565968664,-0.37884613397798717 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark21(-62.89435690792759,-0.024975155228919146 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark21(-6.330283358569687,-12.134229486310772 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark21(6.345685307179586,65.99708137945984 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark21(-6.363198096054191,31.981994971377247 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark21(6.3752156161574645,-64.5183937850279 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark21(-63.77992402854693,21.4179432151451 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark21(-63.95603723233559,-35.60245287996777 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark21(6.39705066610135,61.35023145997346 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark21(6.409525434750623,-0.6885400115523661 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark21(-64.19812238363963,-16.107342859204387 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark21(64.22171081401024,69.3370498494248 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark21(-64.52764939859075,-36.87129623159953 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark21(-64.5289895261618,-80.20085403521158 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark21(-6.459012662425146,40.37217895661315 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark21(64.8635654243445,-9.455007158190014 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark21(65.02513006152705,-89.69404222445753 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark21(-65.07257250248804,-63.10861301608837 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark21(-65.1873331158231,24.719651551356456 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark21(65.18804756198821,-0.024797884198245093 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark21(65.21117719284689,12.650602449032135 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark21(652.4008701403922,-100.0 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark21(6.53318530717959,-0.3201622196348203 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark21(6.533185740704417,0.24044586232583148 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark21(65.56907843281158,-15.39422719652994 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark21(65.97344083944346,0.02383582045261079 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark21(-65.97344606624608,92.81701581438755 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark21(-6.598277568132403,-62.35794124652243 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark21(66.35236359454672,-88.86347440266078 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark21(66.39231991427383,-100.0 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark21(-66.7632707283794,-63.845705833247436 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark21(-66.88935923028184,-93.9827165450879 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark21(66.8927618526337,76.71617065866161 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark21(-67.03012387967776,45.595692414263084 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark21(-67.23127855885373,91.33751654669484 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark21(-67.62357325058011,-73.06119015644259 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark21(67.62785337897748,1.049575179908568 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark21(-67.66927777418346,-15.011487974925945 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark21(-67.67058217975159,32.93146767744495 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark21(67.74505143533057,-10.15995435504216 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark21(-67.8221346288086,-0.040489152418137636 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark21(-6.79646628404484,-31.95562883842669 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark21(68.18165060577579,46.688797771122125 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark21(-68.43876460882856,-74.01238067184465 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark21(-68.48549522134944,-8.484384424960624 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark21(-68.55490826230665,78.61409556132716 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark21(-68.71620046467413,74.40112250004464 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark21(68.83156481578385,-60.910238062912875 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark21(-69.13066337897554,0.022722135880822947 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark21(-69.24477805938542,-79.06803100966269 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark21(6.9458916636133985,-23.79368908487553 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark21(6.979660885292006,-18.47379643267753 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark21(69.81496727210245,0.02249942080002343 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark21(-70.3700668409109,-73.79755761488532 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark21(7.046297706915212,91.55195263304921 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark21(70.4993521138882,66.17501304422723 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark21(70.51163828872201,-29.11485707975207 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark21(70.52671344114908,-58.06404161128842 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark21(70.5594945781993,0.037129507047509946 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark21(70.59064386648996,-14.886815773651577 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark21(70.60684758547413,5.22479745699653 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark21(70.61848380555944,-98.35668782611565 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark21(-70.67283333720968,99.9832035204458 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark21(-706.7827569583334,57.24518099174163 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark21(-70.75811302252977,26.987993630360734 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark21(-71.22372879802103,-80.1390964064304 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark21(-71.2422328711646,-3.588436331808026 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark21(-71.50344280157918,-17.59881865132084 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark21(71.57492147210198,6.348127871945408 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark21(716.714105054651,172.90034840907782 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark21(7.174844031619841,-102.91296723973436 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark21(7.175449831531623,-63.2937965394477 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark21(-71.8985590639222,6.159885836272691 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark21(71.97003432764504,-58.95846963750224 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark21(-72.23636413991312,-90.15389917753708 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark21(-72.25663402175911,10.566710168200984 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark21(-72.45720889833727,3.520166109044908 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark21(72.54954424788572,-0.14543762430576437 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark21(-72.60451653059556,26.798975932133384 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark21(-72.76260158772865,-15.951823009241183 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark21(72.81680884286585,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark21(73.02409883345865,-86.19266442275035 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark21(73.13947790129376,-81.39617713586654 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark21(-73.19197444080316,-0.04140718530249668 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark21(73.22115249748559,-99.17360035116434 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark21(-73.3240401148538,12.47168420266417 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark21(73.55772791192331,-65.3020724460558 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark21(7.360331422698721,55.26927832927572 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark21(-73.73168081040629,78.94571672571982 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark21(73.75568679258276,-9.212352413132948 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark21(-73.80541921797425,-17.08120774164365 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark21(73.85930816429072,40.898007269592995 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark21(-73.91856533998784,-13.03344517968184 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark21(-73.9424357662888,40.84648449645359 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark21(73.95242735937532,-0.02124063290190037 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark21(-7.3988603313133625,0.28140478887445397 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark21(73.99738941589251,-22.3740234825939 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark21(74.03601862261262,-3.8572226842886295 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark21(74.0435041807313,-44.27313572605945 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark21(74.23568194136374,-2.3935671770272364 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark21(-74.2675635084439,2.582986469248212 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark21(74.30950656346894,56.363576330534215 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark21(-74.3596002332972,49.95271184578931 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark21(-7.448468113169951,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark21(-74.7688288259879,17.92254737292292 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark21(75.02695835970735,-22.651350442755387 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark21(75.26741434180144,-95.64510258063835 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark21(-75.50839174075671,42.63916142528117 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark21(-75.53340412880277,-59.851027301736586 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark21(7.575694411602882,11.117995549619787 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark21(-75.83620689873891,68.3195502678874 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark21(75.9225371515591,31.139941708174746 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark21(-76.06607337878255,0.02092563656842117 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark21(76.36083664387729,0.12632340525816765 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark21(76.45109186482685,93.05831244264192 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark21(76.6392960930093,-49.791002269138794 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark21(7.694314824644441,0.20415025412837642 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark21(-77.0741682980453,-0.1914343182982562 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark21(-77.0824915208645,-13.48415728438676 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark21(-77.11999343751408,0.020368211364898817 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark21(-77.15706770700837,21.151662002642617 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark21(7.7276415064034465,31.206353656739612 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark21(7.729089568854762,-0.2234459393769015 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark21(77.34835480815792,-73.72132879039508 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark21(-77.72987602999657,51.941336763024935 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark21(-783.1885861983427,134.02246861618517 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark21(78.44977495978222,-86.7155423353581 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark21(-7.85398139953904,-0.20665794735278953 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark21(-7.853981631812412,-58.148037954989256 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark21(7.857692348596847,-15.634625863050672 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark21(78.57889632971604,-62.10183219570587 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark21(78.59845191981512,23.05613180740845 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark21(78.6079709237287,-33.378768593697416 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark21(78.66223360497645,-82.95046385925393 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark21(78.66525203087144,10.598691262905845 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark21(78.66615646731587,-0.019968012284888204 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark21(-79.02718030846722,-37.01891871876397 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark21(7.920264628536561,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark21(-79.21558425547191,-49.83974132861292 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark21(79.23122077291424,30.247215386210712 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark21(-79.27461167985162,-43.09211314697151 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark21(794.719619195423,-292.17033770254733 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark21(-79.69860070804573,0.0 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark21(-7.98032176154552,9.097677756440042 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark21(79.85201290742822,-10.60012866430261 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark21(-8.000525888506061,48.907313800102884 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark21(-8.001252985730714,3.3539988454816974 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark21(80.06579957656736,-48.12707828665895 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark21(-80.23695279411076,-67.46756762817081 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark21(-80.30585070611153,-25.874393979533046 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark21(-80.41614622547495,59.5929299686444 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark21(80.5406423679003,91.85715994112348 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark21(-80.60305504839349,-83.19857650069102 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark21(80.89699952546579,36.85700887266862 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark21(-80.9148094566638,60.30225157439884 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark21(80.96567339427936,-50.08820783851602 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark21(-81.00978803395813,9.997492212969334 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark21(-8.105571586945654,0.338389472072558 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark21(81.12135409298762,-59.741839244725206 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark21(81.25303553262799,42.113999592918134 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark21(81.47070453782294,-69.12383872662778 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark21(-81.48762733767147,-51.247096110111414 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark21(8.164309960980734,-0.192397928862298 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark21(81.70724305225156,-6.883713380454969 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark21(-81.7948841248198,98.50209925330633 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark21(-81.80346887910224,-74.14458948351108 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark21(82.11397296517572,-56.09839345429979 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark21(-82.12113090544344,57.345145946537286 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark21(8.24333396183399,-18.506567378482394 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark21(-82.49907536559384,-3.849092475457965 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark21(82.88463899818292,48.71524987384507 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark21(83.17442428467879,-10.23905171845918 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark21(83.29845387569219,-16.31754394003562 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark21(-83.45583444212794,73.67585380789302 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark21(83.46394442189279,48.81128383429092 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark21(83.46748423878617,62.6219843490035 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark21(-83.7769657219689,8.592527875327917 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark21(-83.8787872931208,-15.060234260877195 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark21(-84.03760348352696,-55.13151537808798 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark21(-84.17349038145635,100.0 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark21(84.76809060432063,-21.68509722466693 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark21(84.79558549451342,100.0 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark21(85.25600673015614,47.292686769867544 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark21(85.60154135669637,7.823341896739095 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark21(85.60839981032187,65.72959485031691 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark21(-85.95978040089274,55.91959645907468 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark21(86.27861647715596,13.726689610706158 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark21(86.3940421143444,7.445013962245276 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark21(86.86490328129243,16.231313647526008 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark21(-86.891828204978,-15.508021687625137 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark21(87.03743096096835,-40.99505877267207 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark21(87.34370653185883,64.77983094240736 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark21(-87.36321899845697,-14.078390631440985 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark21(87.74706526070077,-22.11819201282661 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark21(8.776270614776893,16.058160042205518 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark21(-87.83825417294318,-81.09813615597791 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark21(-87.9215209707365,22.26139959353499 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark21(88.118819434347,-61.94496556639797 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark21(-88.4794587358476,-60.172019964700866 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark21(-88.6220031238744,-83.20044077112738 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark21(-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark21(8.881784197001252E-16,15.497234353809958 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark21(89.20666645496951,-50.90616050696208 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark21(8.92264926286623,70.18741242018416 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark21(-8.927011367003189,-0.1759599335340063 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark21(89.40905049973807,-1.382873820276047 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark21(89.40905049973807,-8.193541526065907 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark21(-89.53538862468012,23.742714657161965 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark21(-89.59637879718935,28.910271435561114 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark21(89.642601460317,47.969822097150995 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark21(89.65610788106883,-90.0526834892018 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark21(89.7494800192834,-25.181124310517514 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark21(89.95342999231067,-61.06834525056313 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark21(-90.4262431443264,-88.28123638105816 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark21(-90.4409290774623,17.537617718600714 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark21(9.048119924365935,64.00239587225934 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark21(905.2645497232568,56.619438346772604 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark21(-906.7048602809997,-24.0413983421451 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark21(90.70441809950977,43.046467109408695 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark21(90.81630822258128,60.32265670022676 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark21(90.98281338007197,89.34229259483277 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark21(91.0337277345192,68.10589059848523 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark21(-91.05821363608062,-40.732600989449175 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark21(91.106186946935,0.03280041456563443 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark21(91.23252708167504,12.14927563381951 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark21(91.30232842618645,15.092742681197961 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark21(91.42112513720649,53.29015716780302 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark21(91.54183311646597,9.98181648692045 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark21(-91.58261424251545,39.27855186487492 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark21(91.7423584687015,55.50952300024707 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark21(9.186441007317761,-0.1709907379303508 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark21(91.97640489374588,50.25401266286253 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark21(9.204442589814168,54.19310114646626 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark21(92.12121386818761,0.3239767362575918 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark21(92.49129839021498,-49.49451632456494 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark21(925.0446543843162,-170.6121014743343 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark21(-92.62409135143889,85.02833128743026 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark21(92.67699091029344,94.34400213676234 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark21(-92.80332340846994,5.23870091423148 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark21(-92.80332340846994,61.225564707179906 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark21(-92.81163841701026,76.93952777595149 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark21(93.0349089617441,98.56095590289792 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark21(-93.1066937926379,45.505912147841414 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark21(-93.13634881743363,66.15732443051269 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark21(93.18605501020521,79.87711246644264 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark21(-9.343684093405852,-23.708792930473983 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark21(93.52696326657565,17.76184167599976 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark21(-9.395904432215366,13.173055270732576 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark21(9.411691334104008,39.88838709248268 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark21(-94.12143948012276,-37.47297264506279 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark21(-94.12915891468339,-41.75442993704033 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark21(-9.424777962363079,0.16666666667103286 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark21(94.36739693902865,21.750906929424715 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark21(-94.61925369717116,-31.591140672997966 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark21(-9.479879487882746,-32.70352086878896 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark21(-94.84459510084659,18.806002084106964 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark21(9.487277960763873,16.366249035169645 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark21(-95.10736794521463,100.0 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark21(-95.11338886365928,-37.00508688011439 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark21(9.51457997126451,-76.26093500583004 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark21(-9.535442359729803,-20.097365067641533 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark21(95.49315508331858,-38.916926375241204 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark21(-95.67567888864829,50.343089990007115 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark21(95.81231458047637,-9.019519966988117 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark21(95.85244507102587,-56.61139473847834 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark21(95.92266326202,76.94533266961156 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark21(96.6039740978848,5.444260228261692 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark21(-96.70288291076068,-7.452194071220376 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark21(-9.679583030133601,0.1628591015421137 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark21(-97.04846146370991,70.14916821070884 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark21(9.707514867645955,18.974905967003934 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark21(97.3791319136177,90.62217770028508 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark21(-97.38940277886172,-0.01612902720394383 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark21(-97.40798952940901,30.34064665512622 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark21(-97.4504798103506,20.444241450543416 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark21(-97.69636678045723,-4.614486297153837 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark21(9.770295528749443,64.77028523808481 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark21(-981.5578787893396,-158.4669105088412 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark21(-98.29023630748328,-12.618552751969503 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark21(-98.31481660474519,68.2131783403511 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark21(-9.837618062465944,25.866937497036496 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark21(98.63046883165245,-77.95751925549354 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark21(98.63102313033522,28.521738646316926 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark21(98.83382846050745,10.974852843820337 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark21(98.8705707664692,9.37376150388128 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark21(-98.99628780669514,36.83957925950605 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark21(99.04113329320916,56.50339627094927 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark21(99.07920344641906,-41.381376706875805 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark21(-99.08278587002624,-47.21134372087656 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark21(-99.13173454444215,-57.20730952281563 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark21(-99.21016858807849,-0.03256147353901356 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark21(-99.23527709131214,17.619799810488118 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark21(99.74556675147593,11.068584006004617 ) ;
  }
}
