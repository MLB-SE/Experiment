import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(0.07894686625344605 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(0.1495758580347184 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-0.4594121195149672 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999991 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(-0.4999999999999999 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000001 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000004 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000000000018 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000000001027631 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark31(-0.5000001361019201 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark31(0.8410640638854465 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark31(-0.8683330558849889 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark31(-1.079686111131096 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark31(11.672346237026858 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark31(-19.841212617634852 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark31(-21.5 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark31(-2435.8019505588445 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark31(2617.898150285839 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark31(2629.786506546061 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark31(-2728.201704872694 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark31(2.8263302192274318 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark31(-33.5 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark31(38.25966517104976 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark31(4.572473655376893 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark31(50.97343991111893 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark31(-5.5 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark31(-60.200911241079694 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark31(-60.589489691698176 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark31(-60.72205767095136 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark31(74.29306932049298 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark31(75.2567266779086 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark31(76.73744295133781 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark31(83.71908174985526 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark31(-84.16724221957537 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark31(-95.95334594320965 ) ;
  }
}
