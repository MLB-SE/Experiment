import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.00377319370721807,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.004350597100211573,10.291272933853111,-100.0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.007802627459131541,0.0,28.156236186146575 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.011918945436666625,100.0,-100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-0.014369792620055222,-0.0035566300069673224,-1.3340299390297226,-0.23676638776517542 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.017292390566575833,-78.13917836173786,100.0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.03645098964161246,-100.0,19.990783462679286 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.03887530723402477,-0.19873148234692728,-1.0436149121743592E-16 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.05004546477473637,2.8903092724758666,-0.5434699814837938 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.051018864163476896,-51.15577425145992,16.829278708848605 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.05364900227579317,-65.02538834325507,92.9248988398505 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.054465772257792644,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.05879361552825538,67.0921932613767,-62.61946628445539 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.4252565590786379,1255.9098280655942,-1162.75239282627 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.6079489200390231,1498.1688376843815,-949.5163027599152 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.7504369888614946,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.7693200905627151,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-0.9999999999999991,0,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark60(0.0,100.0,-8.919444587180717E-14,-1.6019579112862203,0.03116158449131845 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,0,0 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,-1.1050338472370214,-43.097212447372776 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.1102230246251565E-16,96.28721682821453,-30.26930847717737 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark60(0.0,122.7291581013082,-0.009741437868166614,0.027750052467785835,-56.60516601251058 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark60(0,0,12.958370561021695,36.12186282443247,-4.074917661506291 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark60(0,0.14917936307467983,-45.30728404444637,85.43720353343971,-16.477982437055587 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1.4959210824804438E-14,-4.5522099189454387E-159,5.3224498000101884E-110 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-1.5273595007289773E-47,-0.05053693275339716,-30.55781261207885,3.7659245234681144E-6 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-1945.4055329165242,0,0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-2.465190328815662E-32,0,0 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark60(0.0,26.643505074100617,-0.009925725788181768,-3.3289669969812534,0.20302503861301888 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-30.89821020159964,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-37.30808010285549,0,0 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-39.11209337985706,0,0 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-40.22094505381025,-0.010266374436607953,-20.433552600180537,0.025221320245496975 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark60(0.0,42.82436056637882,-0.05613824771510613,0.04421872803807325,-3.1358024412564305 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-4.440892098500626E-16,-18.821243516387316,0.005618813134829952 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark60(0,0,46.23880171006277,-2.7768123098549324,-60.239093644208054 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark60(0.0,48.0321838809908,-0.0622581722591119,-9.446349548895626,0.13464245089862234 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark60(0.0,-5.438478227659159,-0.06247344858587607,-9.351730656788405,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-59.16776567302908,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-7.269520494324794,0,0 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-779.2522902311629,0,0 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark60(0,0,-8.881784197001252E-16,0,0 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark60(0,0,97.03757637465571,0,0 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.011205141305565203,-0.2171052621912466,0.2171052621912466 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.01171760361012946,-10.904432809251736,9.40417002348015 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.028772685918365903,-1.6311694299924095,0.06037310319751321 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-0.05613244301493932,-15.011614444480132,13.511614444480132 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.06091805949300444,-7.871348158027189,8.881784197001252E-16 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark60(0,100.0,-0.9999999999999996,-3.148857857079564,2.7755575615628914E-17 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-2.278595498573649E-4,-6.8882808866653225,5.317484559870426 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-5.551115123125783E-17,-18.654177817346376,0.08420614096076103 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark60(0,-100.0,-8.766429610628192E-6,6.938893903907228E-18,-100.0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark60(0,-10.771035413075303,-0.05243135882096732,2.220446049250313E-16,-53.16200292871416 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark60(0,-1.240546025856688,-2.7755575615628914E-17,0.7057097697636365,-2.2258389979793 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark60(0,-12.936406476425006,-0.4337014125813585,4.170198598746344E-6,-1758.8540542017167 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark60(-0.13311140785779219,-27.515880371433013,-1.3877787807814457E-17,-11.215556531539505,0.022414521420612843 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark60(0,-138.25316619154208,-0.05472459827017934,-1.719127934775444,0.12051382794618043 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark60(0,-178.12715390024786,-1.6221755158605185E-4,-0.7714764894091212,-11.740928114069579 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark60(0,-18.94971631749681,-0.02366854680028113,0.00465733787493925,-40.41378621844562 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark60(0,24.39003766459569,-0.012509589557189171,3.552713678800501E-15,-100.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark60(0,-2.454397071453478,-0.05220840196514681,0.08863177290501767,-13.66628686133137 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark60(0,28.174936846853708,-0.05661745806562155,50.5077183650325,-0.007124092619334802 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark60(0,-32.11992722948529,-0.001518311243709828,0.6030244202930978,-2.1736910956029454 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark60(0,33.027388495529095,-0.0226561787139265,-6.902628906508049,6.902632006344387 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark60(0,-38.38478482099934,-0.042640940451854126,0.02510716745027275,-62.56366154828139 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark60(0,40.65232582966068,-0.04176734402239008,8.881784197001252E-16,-60.22784241552523 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark60(0,-4.166040966979471,-0.03111849007488554,-2.3705501809031215,0.6621349909621006 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark60(0,-41.73342149407711,-0.01745580739783778,0.004846002197811394,-34.75887601255069 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark60(0,-49.12189539604378,-4.198979588885531E-14,-1.5391819640626578,-0.03161436273223885 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark60(0,-54.855842819944066,-0.03636658697987338,-0.07392542947754278,-1.496870897317354 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark60(0,5.771502806111869,88.66658562645583,-0.08465654929183586,90.05243043822975 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark60(-0.6314219386542419,-4.4689142221487925,-0.03285022619353742,0.5064712838077163,-3.10145190263394 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark60(0,67.67221751230072,-0.4613574298314168,5.399840896389501,-5.552959782576948 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark60(0,-70.59191733506627,-0.13842933703737584,-4.5450437223917985,3.045043722391798 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark60(0,72.10656006087748,-0.04372684165164904,-137.39526872209692,0.011432559915138567 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark60(0,-73.89635181297372,-1.1102230246251565E-16,0.03701256587165468,-41.005783730235514 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark60(0,74.20848968228526,-0.009568436855596787,0.2461317719475365,-11.170909732716916 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark60(0,-75.348734814778,-1.7057062832877403E-16,0.10028158335509364,-15.663856455404783 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark60(0,87.88072742683639,-0.04347157984861799,-21.03623293473272,0.07467098941470596 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark60(0,90.25169242492542,-0.020491682152931512,2.4293878914884544,-2.429387891841991 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark60(0,-93.00758917141037,-0.030589455807238736,-11.247819592574595,0.11857087264163602 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark60(0,97.31009453635744,-0.03028160111115047,0.03413892148060292,-21.651169016580397 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark60(0,-98.66343627433093,-0.031007320795055193,-0.4258185959568051,0.21572141310291348 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark60(0,98.73123639538727,-0.06236348225691612,-84.96649652948929,0.009322066455136648 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark60(0,-99.10298256850446,-2.9658013701714634E-4,5.421010862427522E-20,-1.405725430044747 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark60(0,-99.86367868908675,-0.029369630420773327,8.076804914868735,-9.647601241663631 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-0.017673757713708604,-63.185986655860304,0.024859884444786484 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-5.551115123125783E-17,-2.4171008964152847,0.5798034556367817 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,100.0,-5.551115123125783E-17,-77.38094682443548,3.552713678800501E-15 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-51.48151100792601,-0.021655300758089746,-41.49203597418845,0.03785777896683484 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,70.18415475242004,-2.7755575615628914E-17,-3.995572521506212,0.11316442521238734 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark60(-100.0,-97.33715965698698,-2.141159231291294E-16,-19.276062240403245,0.08148948199090313 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark60(-12.66966819962659,-36.631819349895125,-0.0035445280794211,-13.750263764991294,0.10780497819215022 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark60(150.05235656514236,-0.9838126375132532,-0.02440186063421912,0.06882229081129704,-17.54711242713135 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark60(-20.614858079365153,1.4210854715202004E-14,-1.1102230246251565E-16,0.20237644600237187,-7.761754679576111 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark60(-21.002868797935253,-29.803836952648933,-0.024953262503880413,-44.7970849953253,0.02641079132721821 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark60(-21.146454769189432,-100.0,-0.038720810738367556,-6.955678137127467,0.0010228369016369722 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark60(-21.997929053253515,-22.083424507374026,-0.0024931811492663325,0.028842688797004627,-20.468165392626958 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark60(-23.094560854440434,-10.130909081935481,-0.03142431665859818,0.41591163616120547,-3.37574980710194 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark60(2.326331861999429E-19,30.660674381403865,-1.1102230246251565E-16,2.316390989720618E-13,-94.77781772165113 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark60(-24.626364506971257,42.36389709903204,-0.03034756031186392,-3.59861793906963,0.08878447444302096 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark60(-25.993347853857,-97.34074262206681,-0.025837977638176232,-67.8232167915596,0.01687898310935406 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark60(-2.886100619821171E-35,43.375415787557536,-0.0014440036338988348,-76.66632020442051,1.3376161787939017E-22 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark60(-2.967364920549937E-67,100.0,-0.018013408644957346,0.04329698935583989,-18.862578511554403 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark60(-32.150877895919464,0.2269715466422591,-0.028192159578878467,0.0017576717479688142,-3.9607033341642475 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark60(-32.79220488867503,-100.0,-0.05853367720659329,0.020688696889757274,-75.92533909530873 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark60(34.40386990410059,-0.007932571156615609,-9.315982900047366E-30,-2.7250245228864998,7.957953510450916E-29 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark60(-34.8718168192182,-149.52691844365958,-0.02794257189617491,-4.188750154694866,0.37500358550492763 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark60(-36.73277161703963,100.0,-2.711039696437238E-46,0.04441277668602772,-35.368118005759996 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark60(-38.239782863469564,-100.0,-0.03227307738492691,0.2908412956174615,-5.400871026447817 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark60(-38.69697224555951,1.5213384314306775,-0.019536644891505892,0.01759425043570051,-89.27895692604018 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark60(-42.72592770421121,-36.97185255804073,-0.028089010121448384,0.027141322145816826,-6.875452004099452 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark60(-44.256560276017574,-26.021207695462568,-1.6508648270285864E-4,0.3906246172223007,-3.5532955349489708 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark60(-4.49797041355909,100.0,-0.0019217575003289966,6.700799992083995E-17,-38.5866648099827 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark60(-48.684632763563656,0.1956142085114596,-0.0296508249106201,0.6288104696745833,-2.4980441683927452 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark60(-49.406628643985705,36.91472485873112,-34.57467900990858,12.531414649001718,-90.50810926343833 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark60(-51.18638051135228,100.0,-0.010141822390547292,-1.6491179388173585,0.0783216119514627 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark60(-54.789366106390446,63.8384821010716,-1.1715270042398314E-11,0.026716607523839513,-53.390134026780146 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark60(-57.9924073972184,-59.400951058760924,-0.05606005803334808,1.601031660395069E-5,-18.97800858680193 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark60(-59.024759621530485,-56.771386728522245,-30.516822541953758,-60.146389148706334,93.08043348443769 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark60(-62.24922776289186,63.32076861504353,-2.7755575615628914E-17,2.5429055285658612E-17,-27.575677098257707 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark60(6.239870717807946,100.0,-0.0428801109582341,0.015707962858667955,-100.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark60(-62.95144593898214,25.479754840805086,-7.105427357601002E-15,-52.65556214706355,0.029831536550833704 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark60(-63.0675381900023,-46.71499814107894,-0.013861221897698547,-21.247766238143125,1.1062146672259671E-16 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark60(-6.468694376561546,-70.87487846499594,-0.018067321104166367,-2.859699751479489,0.04102511937757081 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark60(-6.509717850742737,-80.60709797149904,-1.1102230246251565E-16,0.03196380936374239,-49.14296381008637 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark60(-65.68526264776132,-66.54866438912242,-1.3877787807814457E-17,-43.51598159040951,0.03609699860570448 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark60(-6.582725791590253,-19.463466398999216,-0.06164488311481456,0.1429513178480551,-9.298324243870288 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark60(-6.985312738859992,-46.482731254317514,-0.053280874586272876,0.0011922790216584433,-1.6474827589434782 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark60(-7.015055835171154,-7.071761217186889,88.43621109154952,-57.792291183911296,26.298858017918874 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark60(-70.91946058330123,100.0,-0.013429175542526825,-1.7201368766661889,0.009180110961520702 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark60(-7.497309038626677E-18,-100.0,-0.007452232122489414,-1.4959522527545244,-0.07602307001304003 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark60(-77.16860533513066,-25.291859919230593,-0.04990995627569343,0.0010207613446956143,-63.35327436700386 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark60(-7.802983795573461,-42.811034375275405,-2.1032294118958776E-12,0.06489118593686506,-24.20662073156098 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark60(-79.63351093765826,-98.12185611887288,-0.0408122194427335,0.019121557557855162,-82.14792764879152 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark60(-81.04292934355648,32.12707582640876,-0.0312749579112544,-9.314945505861873,0.16863183212466437 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark60(-81.63460022864332,-76.78061868791248,-0.06071818122829695,-42.13421390038482,0.03323329186506685 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark60(-89.50422981537776,-98.81500977630826,-0.017719281419497246,-0.5440909666513885,-1.0267053601435094 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark60(-90.1703969087578,14.825910878908662,-0.0015688377394701832,0.025511165325301958,-61.57289589734975 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark60(-90.64121357084537,-68.29885894199973,-0.060920199466750244,3.552713678800501E-15,-49.503939103771046 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark60(-91.48724313762698,6.804697001519434,-0.06225543079889334,-10.368449232047215,0.15130786198933624 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark60(92.00905535056239,43.15454973264727,18.100448069906776,3.555214925494326,11.224722553065774 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark60(-9.2906685796864,-95.02856011993394,-1.3877787807814457E-17,0.022284102857665675,-70.489547496167 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark60(-96.20273488867622,-2.3477154152233397,-0.06035599089541954,-38.1440499649281,0.041180638349601395 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark60(-99.3840398578829,30.71769922106622,-0.04148047463385162,0.05125893388057145,-21.30438114514098 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark60(-99.62762835757094,-79.67973865326938,-0.054476330695999504,0.11508797296638844,-13.648657512228915 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark60(-99.99853508296914,-84.6732541643893,-4.7894161916342055E-4,-33.464545126476565,6.938893903907228E-18 ) ;
  }
}
