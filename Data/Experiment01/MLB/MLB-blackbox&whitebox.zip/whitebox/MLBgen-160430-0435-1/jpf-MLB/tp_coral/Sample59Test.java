import org.junit.Test;

public class Sample59Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.017575157841526745,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.019206984668664162,-11.258291138767191,76.90429055383376 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.02031666691569982,37.27954304575828,12.656422549952694 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.026104581383717164,1.8928834978668395E-270,-0.018832253775717872 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.030659308414834885,100.0,-37.008479228580434 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-0.04150940461102692,-0.04944989742065341,-12.620030981032079,0.04652040778889191 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.04564092076406734,17.59060591735123,-3.697612975518979 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.046656013097314375,33.76688492902048,-24.385186754247954 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.058238217950400364,-0.2633257348110641,6.0728922717083265 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.05871755109679905,65.35394728968907,-16.55890747341735 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.06017543629022204,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.06082462995080257,100.0,-100.0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.30423936735722723,-1214.0608259729643,1155.3092440753935 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.5448967626859336,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.9203391945457234,-1030.0330436872393,1449.8182741889443 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-0.9792591672773399,0,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-0.019850046875757865,-3.412380714810808,0.17886109074856277 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark59(0.0,100.0,-0.030005485014786587,-16.50583107984938,0.05962724441427376 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark59(0.0,100.0,-1.3877787807814457E-17,2.0756445385222537E-4,-22.097164008909328 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-100.0,-4.5637897437041965E-20,0.0929715679083074,-16.8954483841717 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.039030320439167,0,0 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,0.0,-2.1316282072803006E-14 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.1102230246251565E-16,-2.881198761306074,4.930380657631324E-32 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-11.519414714104787,-0.013243097525908082,0.05488383821264251,-28.62038038792013 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.3877787807814457E-17,0,0 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.3877787807814457E-17,-0.1709214584605394,9.190164540735802 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1.3877787807814457E-17,-100.0,100.0 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark59(0.0,15.371283201458455,-0.08428381968815471,0.6045137858627996,-3.9002509105434195 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-1738.286319524766,0,0 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-29.179481454116043,0,0 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-3.359553337848875E-4,-0.04256823939170557,36.9006646561227 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-34.556850564538514,-0.04344228982303932,0.5502923448377228,-3.80901300987557 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-35.8456646633573,97.1480032270587,25.86080599767628 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark59(-0.03734777254067122,100.0,-0.04771870303330957,-4.773292000912125,0.3290802922793592 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-41.24998901801205,-1.1102230246251565E-16,-16.487495048227444,0.052821329082124294 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark59(0.0,41.40560342751006,-3.477723037557264E-16,-56.88106696228121,1.0557071143318811E-20 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark59(0,0,46.89260626546775,-31.76699074310534,46.08674848062188 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark59(0.0,47.88150953602706,-0.0266402453438929,0.06815743491875431,-23.046588073898786 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-4.930380657631324E-32,0,0 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-5.216346192910346,-0.02299354308870282,-10.834595257035673,0.13600581863278258 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-56.94540415613976,-2.5052771786153292E-14,1.5777218104420236E-30,-44.40367528076721 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark59(0.0,59.35167104169298,-0.026992610054012225,-54.06409763048552,0.02056941111623728 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark59(0.0,70.45341643150113,-2.125044741527229E-4,0.021588255984888234,-72.76161114937582 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-7.097404883116132,-0.047914561714753987,-4.585377097288964,0.3425664440387261 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark59(0.0,7.558195203567489,-0.013359129796258758,0.04992554465215888,-10.53519304002942 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark59(0.0,-75.66345513634217,-1.5675694019203084E-33,0.08268125156194192,-4.5984600744299655 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark59(0,0,75.86943112389861,0,0 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-77.41358495883968,0,0 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-81.69783530889119,0,0 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-880.8730922526084,0,0 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark59(0.0,94.81405818585804,-0.045142490361360026,-9.928141714310252,0.1582165496822811 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-98.0228418485006,0,0 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark59(0,0,-9.860761315262648E-32,0,0 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.0254796145023896,-25.56377499470864,1.0682598071576344E-5 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.03114016412122489,2.452304339026185,-2.452304339699058 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.04800769143251335,0.40129893522885657,-0.40129893522886917 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-0.0535624451241532,-65.35975163541572,0.024033082860437815 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.061475557026140014,0.2082230485773641,-3.684743892503173 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark59(0,100.00201920757475,-0.020814455425957473,-45.18679563852096,0.029632510355392477 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark59(0,-100.0,-0.28113526653800136,6.902565427155902,-8.473361753950797 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-4.2713638015983284E-14,0.6170431882816002,-1.8750252526712572 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark59(0,100.0,-7.189399377267514E-5,-29.54285465908656,27.972058332291667 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark59(0,-12.606290812264831,-2.942809596934026,-13.293879230676083,-3.5268258894269593 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark59(0,13.600534784992888,-0.019290155405982723,-3.4975120830056294,3.4975120830056294 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark59(0,20.061632510735397,-1.7763568394002505E-15,-8.881784197001252E-16,6.776761149176128 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark59(0,20.87614134426427,-0.05218594837350739,-22.625762782946953,0.007142702336338277 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark59(0,-21.68038087469739,-67.95323395340947,-66.46822638880258,-13.533046504494493 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark59(0,-26.677521835846832,-0.04023323263432488,-0.9942791632171648,0.33824120475803277 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark59(0,2.712068011125679,-3.4846888759122697E-4,0.21406834871781502,-7.227040602065497 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark59(0,-31.787722546574287,-0.04463192756949502,-32.170561782975426,0.0488271338682722 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark59(0,32.53064008845541,-6.821828707684492E-17,43.4441382802425,-0.009803634549201745 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark59(-0.3555335462245992,-19.696730256596684,-0.060742036402098715,-70.08717245396059,3.363745557516136E-16 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark59(-0.3773098359633309,24.374912085160858,-0.04115343976017183,6.938893903907228E-18,-26.60435417292886 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark59(0,42.49752954181915,-0.8209083078180088,-1793.6019014754731,6.095474990770413E-6 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark59(0,-44.572732190039616,-5.3387887933373354E-12,-5.365457600141387,0.2885378515044025 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark59(0,44.72616272439275,-2.0194397396533917E-5,-40.018649424248466,0.03923072431709457 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark59(0,-48.99894535970015,-0.03640193696593841,-16.21415265745756,1.4210854715202004E-14 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark59(0,-50.518189521875456,-0.2008790100763641,4.573609333342842,-5.760398052535999 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark59(0,51.30542714771083,-5.551115123125783E-17,-28.26037204004854,0.0026530777544424428 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark59(0,-60.350512159264774,-0.011436217689511363,0.8432941337119325,-44.75479495717414 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark59(0,-62.895014193559064,-0.05061944272731078,11.188286546635743,-11.18828654554905 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark59(0,67.55191147477636,-0.014098272427935932,0.05059797374526958,-30.798661843289807 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark59(0,68.61348562928809,-1.1102230246251565E-16,0.061384626084308724,-6.7764038185363145 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark59(0,69.72979407265271,-0.28298898869543326,1.8468503766765065E-4,-2162.073191017383 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark59(0,73.55733200207312,-0.03416942695941381,0.17425182679700038,-0.17425182679713414 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark59(0,78.01089095846665,-0.061098331868231326,0.3451614561828994,-4.550903059009402 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark59(0,78.04504974894209,-0.013487271366210094,1.7763568394002505E-15,-16.907545081758897 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark59(0,-78.2944137206422,-0.010371585920748216,-1.726285843827931,0.9099282905035899 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark59(0,99.49653966172781,-0.0358613119933406,0.1373023071435675,-11.440421938084478 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark59(0,-99.9986390241629,-0.12118207363335909,2.939764597383861,-2.9399061961464414 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-100.0,-0.049691799841429296,-7.190286432185664,0.14227064868624456 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-100.0,-0.05782152053720263,-16.753920906387265,4.770048006192962E-4 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark59(100.0,100.0,-0.06104916079316351,-4.362863351953758,0.2541285295055004 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark59(100.0,15.222881666021191,-1.092736193687302E-12,-15.81683824812335,0.00791546481380534 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-21.29033102271618,-0.028411373015684242,0.39321423666149036,-3.8518522130423616 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-4.102746341444719,-0.04249939817866476,0.03829734965915513,-41.01579719680136 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,41.26760605739944,-0.03824872390169304,-98.47441911621699,0.015951313456757564 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,44.020849001548825,-0.04642853511960413,-1.9194369361604522,-1.2224106406593895 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,70.4346745202283,-0.04744749705597641,-19.917330365527153,0.07404535077961356 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark59(-100.0,-70.62582679951936,-3.552713678800501E-15,0.043813486208541974,-35.851890883960635 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark59(100.0,76.48711411471653,-0.020768537718036162,0.01844161474000603,-84.97032570394937 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark59(-10.7569701420236,8.395846595575037,-0.03771597283360704,-10.702935975857367,0.0010617433797131398 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark59(110.68792087033847,99.98160125981525,-0.04943001436049055,0.02650603157568772,-28.800856889518887 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark59(-13.824474460255157,-22.883651841971208,-0.04824045639300678,-10.708670403781937,0.146684533893211 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark59(-14.921994933585282,-23.723277512205016,-5.6150540942272765E-15,-16.946068534155458,0.029630686336351263 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark59(-15.545997145298438,100.0,-0.00618078919724414,-2.2940627205595625,-0.9740735168170978 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark59(-1.6940658945086007E-21,64.09594196236158,-0.00812129418477836,-35.037658570810336,0.0448316580160328 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark59(-19.131086520044757,-130.9426556694051,-0.014249052207923267,0.03240611481396538,-48.47222000577383 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark59(2.5308106578350932E-14,1.4140329541837493E-14,-0.15906081685242346,1.29290087619792E-13,-4.5353613556638805 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark59(-26.603095814969,-35.70971308640178,-0.06013790784358841,-6.987323311318516,0.09510505538980318 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark59(27.082637683109112,-98.6789285591301,-0.05124309340653405,-2.2337836118999723,-0.9081916341999389 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark59(28.189486739965787,-54.97111694683581,-51.1294943189581,27.34445024950051,90.56305406616022 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark59(-28.97795762817799,80.11299478633828,-37.84696280139666,-12.781771616141356,28.74129132876135 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark59(-32.36669457828735,-65.8191842315875,-0.0316467050064454,0.21392506235494224,-7.342741002401112 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark59(-32.67393248755283,-11.459237311109646,-0.0595428346600069,0.019918186670172013,-78.86241618305563 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark59(-37.43452011191046,62.10039907881386,-0.03977855491773363,-41.56874449885707,0.022242852648266642 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark59(-4.04031302466561E-34,39.65041591531366,-0.05934039497210447,-16.57255183421983,1.7763568394002503E-15 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark59(41.14698002800078,26.478348799231373,-0.025208403366950627,-94.52989431097336,0.016616926721520917 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark59(4.123278254881374,-1.0704926597474824,-7.614438271686715E-33,-3.9125901543530177,0.25885002733804185 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark59(43.919779841190646,97.95068842387327,-2.7569825047479846E-5,3.1554436208840472E-30,-3.8030386900291973 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark59(4.412262942214239,-16.391022831078132,-0.047204872167719875,-13.829118413661917,0.11358615059967175 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark59(-4.440892098500626E-16,-95.79698279983414,-0.04950015290537842,1.8054616069327255E-11,-16.222737929970336 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark59(46.742353461610634,91.39923514238352,-1.1102230246251565E-16,0.3198809361718627,-4.9055526823557045 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark59(-4.7450489701242584E-5,100.0,-0.042122409428224844,0.0019134933329063354,-34.88769062026527 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark59(-47.904939921200295,10.041160080401845,-0.05826886784245229,-37.95374168281467,3.469446951953614E-18 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark59(-55.649662258201275,62.90062827147617,-0.011735084505261367,-9.470773994893868,5.2174891931489054E-5 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark59(-57.632414722304226,39.3329332048439,-39.51876462459736,-86.06911066121081,-48.41850090146662 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark59(-58.42666016488942,-17.74586307187589,53.489667202981025,-26.053694147420885,49.6264152293779 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark59(-6.028035671060784E-7,3.306825802604905,-0.01597357090599175,-3.058777067342076,-0.0909238621077502 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark59(61.16431975470135,-100.0,-0.00430007603208693,-92.00521907430358,5.551115123125783E-17 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark59(-62.87885281525882,63.992114473144404,-7.342067861043029E-18,0.15034391647695688,-10.44802053587344 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark59(-63.53544938293396,-99.95982957314699,-0.022506516731174098,0.2226773906115581,-7.054134784321313 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark59(-65.4033414412063,59.67332204100211,-0.05895687864652756,0.018894644048078186,-82.98643618359364 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark59(-67.63686306429867,-100.0,-5.551115123125783E-17,0.016569230041763243,-4.184946564013014 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark59(-69.04593563925188,-70.24393036752146,29.6997400249912,-6.424543888603381,-68.02855152545335 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark59(69.04747809213065,65.84398012015653,-0.05250125492668767,-28.645963896077586,0.05483482184413324 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark59(-73.23659662683248,8.331293350151753,12.997323995161764,14.85117621020919,-6.411776374149625 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark59(-76.86964125806259,-85.33276234400623,-11.137492771316971,36.15735686945075,15.753253698178597 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark59(-83.73157332884098,-50.32959119392093,63.86292765687949,57.79665640612964,32.978607985770424 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark59(90.87855216150493,14.868206821033269,-0.06102137790037024,-4.460854701473103,0.35212900484657617 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark59(-97.42015485210938,23.454464360325733,-0.013486381341992225,-0.23759770022147422,-3.9234095271842433 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark59(-99.9077305213117,-31.991904536350454,-0.04514305049011823,2.7755575615628914E-17,-3.1685951514729482 ) ;
  }
}
