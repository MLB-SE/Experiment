import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-0.0013753273973850328,-0.4365655134636416 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-0.005736556070729648,18.814789166553837 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(-0.00926653298883906,4.440892098500626E-16 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark02(0.01165321926236533,-1.5707963267948966 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark02(-0.012011770994206472,-50.33588325561145 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark02(0.012215347510545142,-98.96185182667686 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark02(0.0157377642810701,54.12628932991913 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark02(-0.01687175010473041,23.00524313614602 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark02(-0.017234807070198872,-3.711599761895863 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark02(0.01822670323589648,-73.09764806653983 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark02(-0.018941401934361703,0.07904747715790555 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark02(-0.019712776224726187,1.5707995257677265 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark02(-0.021711521599350664,-4.6713961322667155 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark02(0.024665805968304255,-42.109968949264264 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark02(0.024778741603533883,-73.84856341631837 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark02(0.026763317082463985,52.28530723150982 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark02(-0.031924531324873655,1.5707963267948966 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark02(-0.036278165441203214,0 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark02(0.04786030424801424,1.5707963267948966 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark02(0.05400938565328182,-38.99952410288624 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark02(0.06285739076290975,15.92561387640427 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark02(-0.06705002059885712,67.52099018942417 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark02(0.07259010501007035,-86.81026182088391 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark02(-0.08264201178250585,1.653438338677745 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark02(-0.0885146586993919,1.5707963267948968 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark02(0.08987208829647819,1.5707963267948966 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark02(0.09173276814108348,-62.95568020674524 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark02(-0.09939367293023715,14.839501546758484 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark02(-0.1019497748630358,-69.29540829481034 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark02(-0.10757521585479157,-41.65319455996297 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark02(-0.1087751570884998,-37.72330918074225 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark02(0.11609673030191753,78.8596592308707 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark02(-0.12141539502166637,-0.9869733795364425 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark02(0.13470591116102582,1.5707963267948961 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark02(0.1351252552188522,1.5707963267948963 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark02(0.14446873992801768,1.9430215026353892 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark02(-0.14618771588210588,1.5707963267948966 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark02(0.16217234466983488,0.5239565491404502 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark02(0.1706483521879499,-27.45664599172726 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark02(-0.17914690973701286,44.979496323837026 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark02(0.18824518808004154,32.98672286269283 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark02(-0.19525888801776414,11.32781522757837 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark02(-0.2001271532002651,-1.5707963267948968 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark02(-0.22589022723649071,6.927658918741585 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark02(0.23220199434048538,0.0 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark02(0.23697141034238012,-81.25324140676882 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark02(-0.2612240471746884,100.0 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark02(0.2721996346576129,3.2665926535897936 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark02(0.27534716195487285,-1.2954491649439381 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark02(-0.28060391197079054,16.818230725081683 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark02(0.28272110725934874,0.009418823628499884 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark02(-0.28317308530026164,95.28307185426885 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark02(-0.29190889338485926,1.5707963267948966 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark02(-0.2996218897703926,-77.55295452267549 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark02(-0.3036563914544814,0 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark02(-0.3170529147557706,-0.5689037127805016 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark02(0.3298272776452303,62.25139673289081 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark02(-0.3315757841548075,-0.08016831530783859 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark02(0.3381932521575929,1.2326030747433083 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark02(0.3491926371329986,45.203900840025426 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark02(0.35856562979578394,0.0 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark02(0.3594193515539552,45.46033173153546 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark02(0.37735419606724513,-0.02609147300428665 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark02(0.3875053883579884,-2618.2682010601275 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark02(-0.3894833269321052,11.183780370075747 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark02(-0.41332770218410975,-1.5707963267948974 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark02(0.41642270943628135,0.0 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark02(0.47058210066635586,-185.43711067586403 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark02(-0.47412211408285926,-0.17229909152635658 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark02(0.47618505094594277,-1.6186146517815763 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark02(0.4831745268668691,5.809753325960512 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark02(-0.4991844350572934,-1.5707963267948966 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark02(0.5001356932253032,22.601127628239425 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark02(0.502424840939176,-0.5662198795978389 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark02(-0.5046525198100533,0.0 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark02(0.5070093276200233,8.143065541086386 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark02(-0.5082459933055077,-59.99701618573137 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark02(0.5082478065688605,92.95125635894435 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark02(-0.5095344255312804,-52.34581320987742 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark02(-0.5107722499425538,-96.34153350943426 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark02(-0.523858076774693,-1.5707963267948966 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark02(-0.5248512979010276,4.1875376823681085 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark02(0.5263647582152089,-98.67548818343211 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark02(0.5297478707355673,-0.31860676470582 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark02(0.5336832697335026,42.71997136181841 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark02(-0.5479891222449293,-73.93312493879517 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark02(0.5524149857633858,-1.5707963267948966 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark02(-0.5575266985274416,19.405483204876113 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark02(-0.5608981086672077,-0.13916816246329472 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark02(0.5652695268223243,-33.51970333578427 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark02(-0.5659049839878989,1.5707963267948966 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark02(-0.5799444942219567,-10.995574601916775 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark02(-0.5846886604834111,-49.662722702108404 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark02(0.6036460805190211,100.0 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark02(-0.6103429142638134,-46.16343639143785 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark02(0.6161213025880831,-39.20404003629787 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark02(0.6242344678544072,66.27492829486621 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark02(0.628456495544234,82.33329985471889 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark02(0.6348390971428859,-36.76315461330131 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark02(0.6595234364763627,0.0 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark02(0.6638954681569665,1.5707963267948966 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark02(0.6683370312862706,-39.484165848393026 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark02(-0.7194185557185335,0 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark02(-0.7285285431535506,0.0 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark02(-0.7386457410309217,-1.5707963267948966 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark02(0.7495115855844947,13.464271686205613 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark02(0.7787148473532695,32.50115191622527 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark02(0.7869757647331127,-2443.726715057374 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark02(0.8117288195955543,-1.2876351036906273 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark02(-0.8531262263827535,16.42563336820905 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark02(-0.8856750418456499,0.5682731653502527 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark02(0.8917477177924837,29.485590956180005 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark02(0.8983149949295686,100.0 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark02(0.8990781739702753,56.1090380733278 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark02(0.9048548563162615,15.72563993021015 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark02(0.9118317554126398,1.5707963267948966 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark02(0.9244076919903668,43.33590851528655 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark02(-0.9314092738431299,-95.17164162431246 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark02(0.9325759612701092,-69.41096236250971 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark02(0.9433237611735688,100.70625995739447 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark02(-0.9476051480310925,0.07785270751584981 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark02(-0.9667494166620116,0.0 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark02(0.9906748201708243,0.0 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark02(-0.9985742434959677,-0.005553670262186278 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,0.0 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark02(100.0,0.0 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,-1.5707963267948966 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark02(1.0000006123233996E-10,1.5707963267948966 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-0.26753299026670974 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark02(100.0,0.4965368582252439 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-100.0 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,100.0 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark02(100.0,100.0 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-1.5707963267948966 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-1.5707963267948968 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark02(100.0,1.5707963267948968 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-1.5707963267948983 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-1.5707963267949097 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark02(100.0,2596.5954694925053 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark02(100.0,2623.24214565147 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,3.2665926535897936 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,37.91839769836788 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-5.139252284742241 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark02(100.0,54.97787144093881 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-56.62841126975895 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark02(100.0,-61.72579523363444 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-7.659811503758848E-12 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark02(100.0,78.17795953812961 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,-86.39379820892391 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark02(-100.0,8.881784197001252E-16 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark02(-100.38161078678868,-4.861844155588873 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark02(100.52979825544513,0.0 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark02(10.075662758310472,-68.13404998830123 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark02(-10.083130955660224,-48.950771754141485 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark02(10.10859880589759,53.526215870007576 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark02(10.151239423744045,0 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark02(-10.160531407613139,-73.82747321093919 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark02(1.0171401245787253,0.0 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark02(10.187202336233852,-4.953239953519358 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark02(10.221324866870688,0 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark02(-10.282804424192847,53.708046447321614 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark02(1.0293553320843575E-4,58.05729689861386 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark02(-1.0295313480650474,0.536794803773361 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark02(103.46346078025988,29.461620966507525 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark02(-103.67212388161848,-1.5707963267948963 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark02(-103.6986665232324,51.9003221898379 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark02(-10.375064636462302,5.899206413831903E-15 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark02(-10.395658089190295,60.76030747690041 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark02(104.064935536038,72.51593014196277 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark02(-1.0408219280796605,-23.876056512285242 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark02(104.23290896789075,-1.5707963267949019 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark02(-104.45164897910712,-136.38482304292742 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark02(-104.52447735513834,100.0 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark02(104.75139936342649,2.6496381219699137 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark02(104.96198814811372,21.709782828344334 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark02(105.04455299539798,13.833944386537361 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark02(10.534017692518233,0.0 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark02(-105.46510215506976,-44.53033403659023 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark02(-1.0548495900707135,-91.28487180336317 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark02(-10.54920620353073,28.63770231761373 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark02(10.559425754584925,98.54410200560716 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark02(1.0575387942082002,-6.7964428399699415 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark02(-10.582980394480888,-67.22234946968979 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark02(10.583436044412778,0.007523047792169858 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark02(-105.88321923340473,-92.51269489110867 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark02(-105.95737246587785,-6.997203877952066 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark02(106.2133427850824,-44.159590847199354 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark02(-10.632709663856517,-68.67047335626226 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark02(-106.70044864856088,4.5641018153434345 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark02(-10.67473197231233,52.04204011585213 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark02(106.81314425385503,-1.571802295092838 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark02(-106.81569331360917,-23.561975462180087 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark02(-10.705999247999541,1.570796326794897 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark02(-107.41093420641715,1.5707963260076225 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark02(-107.43426921912291,72.68738032018305 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark02(107.67062440350196,68.03189123446606 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark02(-10.786052828786564,-69.32455983823394 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark02(10.790633170183481,0.05082078185181655 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark02(10.792429531998735,71.1938873680744 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark02(1.0810525150229948,-24.64299741673386 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark02(1.0814071018455174,-0.007966964484404149 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark02(108.2201004963319,-144.6781081182558 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark02(-10.831781873370517,30.35014574634522 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark02(108.35774907440435,-3.221816743653805 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark02(-1.0842021724855044E-19,-29.84513220642268 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark02(-1.0842021724855044E-19,67.54424229138239 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark02(10.843188127227105,99.17235467395666 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark02(-1.0864696632325979,0.0 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark02(108.86636561804048,4.545197176955142 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark02(-10.888768669716399,85.07131137595596 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark02(10.91494388719019,62.95860726219499 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark02(10.915565961128564,-52.88474055571551 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark02(1.0921700402430905,71.2930019101716 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark02(10.92457473185766,0.5366815520595122 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark02(11.009928139938665,-15.43696643532924 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark02(110.15486042676369,-66.26090399224805 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark02(1.1078501600273827,-0.46294616699143465 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark02(-110.92510960815714,1.5707963267948966 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark02(-111.03334187291954,-22.47590619055574 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark02(-111.60786892592301,-0.856607370041526 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark02(-111.63563857258251,-3.1415926535897936 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark02(-111.73099076913103,70.0073642986221 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark02(11.180709277548083,38.31730295922509 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark02(111.95882256424147,10.134368545319035 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark02(-112.05750411711355,100.0 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark02(-112.06769414774391,-50.44326840526674 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark02(-11.20778000183735,-78.77826227215368 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark02(-1.1210387714598537E-44,-0.5493290598488577 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark02(1.1223215410271363,-31.864401321896324 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark02(112.55791200360338,0.7327878364892797 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark02(-112.70196980298786,9.42477796076938 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark02(112.76573575320685,0.0 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark02(-112.80690357815728,44.098014254107596 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark02(-112.8174299214336,61.2682813884029 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark02(1.128356148890615,3.872883287837837 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark02(-113.09696791131434,45.55309362635804 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark02(113.09720068154006,0.5589657888089336 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark02(-113.09732577364198,-4.712381349587612 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark02(-113.108264518893,1.5707963266622695 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark02(-1.1320388267486439,-34.99627668929858 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark02(113.32822241952519,58.52857142932144 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark02(1.1427550036760028,-0.008244702209666444 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark02(-11.430060065556832,-44.41678292848722 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark02(11.437265838984104,-0.09624557454774174 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark02(114.39478824698412,12.29302700494541 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark02(114.4464942234676,73.70098414712811 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark02(11.456373129531201,0 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark02(114.66577029266439,0.0023616052778251385 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark02(1.1472084424045201,0 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark02(-11.527145317956197,88.90894032874886 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark02(-1.1552585780851874,-100.0 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark02(1.155795910875991,0.41500041616692684 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark02(-116.23812581379697,1.5707963267948963 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark02(116.23892786819295,-45.55504664991895 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark02(11.642404325159873,-68.75082450869272 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark02(-116.73521382359442,-37.9968037597258 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark02(117.24302563650897,95.2578103411459 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark02(-117.44412326843664,-0.5690275089510425 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark02(-11.791828928518783,-55.75241312352186 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark02(-118.00151767056613,-65.28313482520032 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark02(11.802784195892784,71.89287228131508 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark02(11.817591371318624,78.02148235928281 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark02(11.817778810734623,3.963797176623649 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark02(-118.26834361142377,81.14468298005364 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark02(-11.871878341008799,107.40269719909368 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark02(-118.99854360212284,-1.14885221850734 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark02(-11.915594753539672,67.54481737294951 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark02(-119.28465335834554,44.992383991839105 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark02(1.1929190649616033,38.07698910518185 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark02(-119.32795748274623,171.21679962065284 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark02(119.35158772254212,0.0 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark02(-119.50830428598991,-0.0066453395407280996 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark02(-119.74592469706414,22.315976787170833 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark02(-119.82829484768628,-228.21324788972166 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark02(-119.99044075809579,73.2175074375545 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark02(1.206601729326999,-50.86266022468546 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark02(120.77801322207952,-105.37607771735605 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark02(12.212535484757762,-1.1102230246251568E-16 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark02(122.52778146460531,-1.5786089116099389 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark02(122.57929829582241,0.28095427638002285 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark02(-122.69710301089167,-164.76296345098194 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark02(-12.27472970579177,-1.5707963267948966 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark02(-1.2294907928086882,-47.03649831526193 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark02(-122.97547798476961,1.5707963267948966 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark02(-12.30313251809045,-1.5707963267948966 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark02(-1.232595164407831E-32,0 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark02(-1.232595164407831E-32,-7.853981633974482 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark02(1.233332568773649,0.5358050300180893 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark02(-123.36154498404218,41.08289345113661 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark02(-12.346776193194017,10.725339860478527 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark02(-12.418343755187308,-73.53889162066567 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark02(-124.71130852574365,26.591663601685298 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark02(12.472112989698322,183.9241924508438 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark02(-12.546448110779536,1.5707963267948966 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark02(1.2561915640877745,-1.5707963267948957 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark02(-125.66355997823764,-10.96269335039855 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark02(12.566369971998824,45.55309344789021 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark02(12.566370614050877,-158.65024664011762 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark02(12.566370614359172,0 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark02(12.566370614580284,0 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark02(-12.566370614595812,-29.845130209103036 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark02(-125.66370706693671,0.0 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark02(-12.568323739363535,-1.5707963267948966 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark02(12.568323744991726,-32.98564023821748 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark02(-12.568328097856813,-155.5086474767259 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark02(12.568329091050042,-98.96009318484893 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark02(1.256912394323308,-61.02600589971859 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark02(-12.574604029122199,12.317469804723174 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark02(12.578460744781282,0.20787497802527355 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark02(-12.597620614359174,-70.70110125626222 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark02(-12.597620614359197,98.96014235261578 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark02(12.598295906044822,0.0 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark02(-12.598907803478639,-1.5124575372073796 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark02(-1.260577388125122,79.85998191452438 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark02(12.6686838004251,-0.31468939749491653 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark02(-12.681264028262666,1.5707963267948966 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark02(126.85671341467254,-0.5873803725997959 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark02(12.715208381459936,173.1481505604716 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark02(12.74047621377856,-64.49271347067221 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark02(12.767169994662325,20.12396773143766 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark02(128.80654126175148,42.42713246903054 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark02(-12.882481978236676,77.96049118247086 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark02(1.2908055606764421,-58.25641130843026 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark02(-12.93323170357111,-88.36663139901371 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark02(-12.938895913350134,-31.957699399974196 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark02(12.94544687134692,350.66665713214206 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark02(12.965357843545743,-1.5707963267948966 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark02(12.981080363183805,72.45263382224354 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark02(129.85253129209505,-66.49700955706702 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark02(12.99262743593799,56.063701269245456 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark02(129.93973399978145,-187.75329883550694 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark02(-1.3001189664254436,-9.926325816709934 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark02(13.021274471377208,13.682263084247356 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark02(-13.029507318890488,59.100649814824976 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark02(1.304351255729105,-0.14976315629933656 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark02(-13.06637062642598,86.3937979396972 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark02(-1.3086265321790027E-7,41.71309052512193 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark02(-13.113953743025363,-2.570796326794897 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark02(13.119622304218282,78.28740948358161 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark02(-131.8307911960975,-28.223255629716945 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark02(-1.3234889800848443E-23,45.55309347090067 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark02(13.259973817698807,-75.77739831743426 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark02(-133.02042764174047,1.5707963267948968 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark02(-1.3315694353198637,55.43003960818 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark02(-1.332021217758637,-76.8445371145046 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark02(-13.327635550044278,85.67885601875554 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark02(133.67049266153862,-10.183613390588391 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark02(133.9315038840465,22.325994214277237 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark02(-133.9551310322065,74.26939848793577 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark02(-13.410922449171593,-75.01352336140779 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark02(13.46637862587983,1.5707963267948963 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark02(1.3489463895209308,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark02(13.498235286701664,0.29914036629906837 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark02(-1.3536272220441483,0.010668534719001508 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark02(-13.553818604195584,-1.570796326796259 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark02(135.8019274111078,3.10046489532541 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark02(136.15163239472548,1.5707963267853393 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark02(1.3632596633207896,0.0 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark02(-13.637602348212816,25.663057183817074 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark02(-136.56635599586733,-31.794595498668983 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark02(-1.365980004108964,90.13953863247832 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark02(-1.3674804571504227,0.0 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark02(136.94868083368954,48.170538401181716 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark02(-13.722803568080664,0.0 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark02(13.73454335242861,100.0 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark02(-1.3771892003515895,3.1259379786786314 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark02(-1.3794582248439602,-66.16478382681078 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark02(138.2298926779225,-0.5707961555514182 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark02(-138.23398301827757,1.5707963267948983 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark02(-1.3877787807814457E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark02(-1.3877787807814457E-17,26.703537555513236 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark02(-13.887546630441207,-1.5707963267948966 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark02(13.896935938988044,-12.818517170921368 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark02(13.913860255032603,-0.15218437348718217 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark02(13.917049323581395,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark02(-1.3946850988148913,-62.09665611457322 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark02(13.988828416601606,-11.122071846281127 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark02(-139.89442681704986,-31.394327758630467 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark02(14.00830995154837,-1.5707963267948983 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark02(-140.20092718670338,-0.5667216655299626 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark02(-1.404153992051023E-11,-1.5707963267880498 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark02(-1.409263389452652,-1.5707963267948777 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark02(-141.06009263281692,14.42997535955191 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark02(14.133295870638369,0.013508802589204602 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark02(-141.37009378896946,-117.81363075961727 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark02(-141.37141561737272,1.5707963267948963 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark02(141.37163839887052,92.67698317813694 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark02(14.1371669402524,0.0 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941150028,0.0 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941154069,50.824900630896536 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark02(14.137166941168374,-98.74674713496294 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark02(1.4224455277919992,-1.5707963267948968 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark02(-14.232498789452492,0 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark02(1.423831660172035,73.48403769333123 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark02(-14.244097545400805,0.019973807792125493 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark02(1.4285998645177937,22.50751165533834 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark02(-14.330833089534465,-1.5707963267948966 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark02(-14.36612226856396,-0.25672862269980057 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark02(1.4396562161061808,0.0 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark02(14.424148021912087,40.25107353179649 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark02(-14.431321992151936,69.76613516087386 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark02(-1.4444428351976442,90.97983346330022 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark02(-144.51326206474585,1.5707963267948966 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark02(144.55460005063114,-11.378577472880451 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark02(1.4460698799267666,-81.87247068116187 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark02(-144.64962543349344,29.993075578182957 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark02(14.505048379120778,32.75470113196558 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark02(145.16890785887745,42.46021870559626 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark02(1.4522534704837198,-0.013320978473822298 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark02(14.537043848956714,-100.0 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark02(-14.575302449964358,135.5784868422994 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark02(1.4588089259437493,-14.429255361745426 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark02(145.93349095910364,65.55399538920977 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark02(-1.4611113434831857,-65.05324898171527 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark02(-1.462873453346053,1.5707963267948968 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark02(-146.30359965167304,-1.5707963267947598 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark02(14.634890368170776,1.5707963267948966 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark02(-146.41906701644302,-1.5707963267948966 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark02(146.53060833003198,-40.015388209918726 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark02(-146.62759525354667,-23.38522721548135 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark02(-146.69276069174398,42.765268421346946 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark02(147.32665605432004,-101.1705965673656 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark02(-147.64629464482744,-1.5707963267948963 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark02(-147.6546334255332,70.68583470577032 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark02(147.68610472024423,1.5707963161596787 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark02(148.2592380724638,1.5707963266780198 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark02(1.4832825088748745,76.22898838823062 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark02(-1.4845509814190936,2490.549590199193 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark02(-14.864694204020992,44.376044290994514 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark02(-1.4910235561021163,0.0 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark02(-149.1982266667228,0.04204927602461704 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark02(-149.28579978060552,79.99537520040775 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark02(1.4935426785887338,-45.38166629476564 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark02(149.52341576733738,10.74152910668019 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark02(-15.03588425386872,44.06797391370802 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark02(150.8042600113836,61.261053115741184 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark02(1.5132573790807664,0.0 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark02(-1.515813324823771,-1.5707963267948966 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark02(-1.5164041750988897,14.030251053913757 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark02(1.5182030673056346,1.5707963267948983 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark02(-1.5208609080761586,23.567844093176 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark02(15.246373255781293,1.5707963267948948 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark02(-15.260446383402694,16.166196957594266 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark02(15.28826695026082,0.0 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark02(15.366729874784198,1.3543597793485251 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark02(-15.377290923510479,-29.51445786455882 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark02(153.7861967127639,4.864232293419727 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark02(-1.5407439555097887E-33,-14.137166941154067 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark02(-15.43982660239276,1.790899914996487 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark02(1.5472937533053288,45.65938190589284 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark02(154.7656621248014,-2572.4279008766875 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark02(-154.77601063663573,61.67465262630428 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark02(15.493037851352874,-265.24638086662856 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark02(-155.17994795174093,0.4299858209585651 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark02(-155.19272378788884,-7.496930191598111 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark02(1.5525594763164747,74.85529394179028 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark02(155.3142593221651,-9.61935499078187 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark02(-1.5567925544689682,-107.15828806072248 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark02(-1.5590394498492675,-135.31045433370508 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark02(156.07616028454115,0.12540332586435707 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark02(-156.7059305120426,1.5707963267948983 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963260428763,-18.27971959653712 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267868117,-27.790997881050178 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267900524,0.0 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267933174,-26.70623726712391 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267937393,-15.770965321479823 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267942482,157.07962890685104 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267944898,5.696086849483464 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267946496,1.5707963267948968 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948521,111.52653921990155 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948806,-94.62759800134745 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948841,1.76412339865567 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948895,-73.90511928330415 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,-0.5886087698340722 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,100.0 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,1.5707963267948966 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-36.37104916865055 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-44.330304981772464 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-53.48629951056354 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-71.85943408064786 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948912,-82.23271858682565 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,-83.4061031960357 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948912,96.27878425631263 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,0.0 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark02(1.57079632679489,-36.93633812438306 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794893,-79.69451870934239 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794893,81.63211426032325 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948941,8.881784197001252E-16 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948943,-1.5707963267948966 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948946,-1.5707963267948966 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,0.0 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,0.014159696270403975 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,0.988154306190121 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-100.0 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,14.584678632890004 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-1.5707963283116821 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,24.142135569440015 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,2550.0288547525593 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,2633.280128524111 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-32.48344974308969 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-40.65436396095278 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,53.72527854372393 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948948,-72.35383212689334 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948948,-83.24930391384383 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948952,0.12357784277330347 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-0.0352329829868115 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,1.781118714372659 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,-2579.584094583257 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,-27.276286028601945 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948957,41.083698995045395 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948957,93.22204384698773 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794896,0.0 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,0.0 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,45.056015598619645 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,55.392652433408784 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794896,-1.5707963267948966 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,-61.74461672264049 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948961,82.43328191541237 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948961,-87.48290755654746 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,14.97037324915103 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,1.5707963267948968 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948963,34.853636850948604 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948963,4.1986763804328366E-5 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark02(-15.707963267948964,1.5707963267948966 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948966,0 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.0 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.20488477109009723 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.21462283574109187 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.2261445092042199 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.49451640882659414 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5704298193085228 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5705925342211985 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,0.5707381604860654 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.5707928606673113 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-0.6648827095909969 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-100.0 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,100.0 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,10.499867136128172 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,10.995696357876778 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.1169774820796228 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,11.684594366794698 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.2150372292212896 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.2754562788045394E-15 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,12.90136555115613 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,14.137166941117853 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.4422696593839879 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-14.430119888742503 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-14.833077417254275 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5063092149447939 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,15.707963267947042 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267947573 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948948 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.570796326794896 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948963 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948963 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948966 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948966 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-1.5707963267948968 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.5707963267948968 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,1.570796326794897 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-17.230392071858887 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-172.7875959442728 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,19.34453975457708 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,19.420352248333653 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,21.58117763398898 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-21.703808989666495 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-21.99114857513037 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2501.7157011998547 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-2527.7233634173585 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2588.9408780854947 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,2602.5023325352577 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-26.70353755551315 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-27.24531793156835 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,28.27433388235552 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,28.854542644438396 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,29.845131074592235 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,30.050048702246045 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-31.029537192802515 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-31.41592653589793 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,3.1415926535915966 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,32.619515716907394 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-32.986722862692815 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-34.5575191894873 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,36.261147437022714 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,37.65736657448017 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,38.95566117615897 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,39.328629069544405 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,42.573887480673406 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-44.06818362009503 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,44.3299050757706 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-45.36164552401108 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,45.54653515848437 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-45.553093477051995 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.712388982247336 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-4.712389218923833 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-47.21136438758047 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,48.66446267239 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-49.696404107784666 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-49.74242358875405 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,50.886170701247906 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-53.082476576926275 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,53.4354231930046 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,54.978848000321385 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-55.07241834157344 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-55.42611537834708 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-56.694200722382185 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-57.52908433414719 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-57.655574799577344 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,59.69026041820424 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-60.363543193119774 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,6.123233995736767E-17 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-61.2630098701303 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,61.761056745002065 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,64.40264939859074 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,64.73444429625485 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-66.19845340269319 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-67.47392251292081 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,68.28150444754277 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-69.16702264012415 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-70.6858344705911 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,71.55829841191499 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,72.1630715683205 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,72.25663103256667 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-73.2984495595148 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,73.3182971780185 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,73.67123691832853 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-73.90636052245989 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,75.70523173782382 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-77.29649051239781 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,78.66869032715985 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-80.05053320853517 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,80.11451891653974 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,81.55259108176276 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,84.8230016469259 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-88.24980887849532 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,91.10618695409882 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-92.67710535121151 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.424777959978787 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.424777960769399 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.424777960774032 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-95.65875783095323 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,95.81857593448868 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-9.596761107930163 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-97.38937226010634 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,97.38937226127797 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948966,-97.38937226128482 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,0 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948968,0.05340848427783868 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark02(-1.570796326794897,0.0 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794897,0.0 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948974,3.554253475118344 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,100.0 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-124.09962473965402 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,1.5707963267948968 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,1.5707963267948974 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,15.811114475849777 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,21.74459020242511 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,-2602.8016724046806 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-3.6484035104523307 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,41.51646508478095 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,46.6209249328424 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,-59.02120201415717 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,-6.468025781097299 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-7.28565407583513 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,7.926680535526973 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267948983,-99.1030123450786 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267948983,-99.50323230474083 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949019,27.691441577550215 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267949019,32.89198370346241 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267949019,-84.26230022630189 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267949019,88.60652188605295 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267949054,12.40132921674605 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949054,-45.36240292279208 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark02(1.5707963267949268,-100.0 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark02(-1.5707963267949339,53.799252494544035 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark02(1.570796326794948,0.0 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark02(-1.570800126783201,65.97344575692438 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark02(15.708025548011047,45.55309151131687 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark02(15.70855583844652,-1.5707958247144775 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark02(-15.723588293046433,-10.995574287220618 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark02(15.72358829547084,-1.570791544643025 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark02(15.77688809897809,0.0 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark02(-15.805529268639447,1.5707963267948983 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark02(-1.5845683589175075,20.64129144172058 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark02(15.858864836044221,31.752722046074126 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark02(15.87561049994847,-69.7034236736497 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark02(15.90459918599245,-1.5707963267948961 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark02(16.007295338614124,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark02(-160.2207478301875,1.5707963267948963 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark02(-16.033171604216555,0.0 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark02(16.041602245710635,1.5707963267948966 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark02(-16.064988495084105,1.570796326794897 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark02(160.83621103120976,-28.25188567847682 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark02(-16.08548355751111,-0.3740760947534554 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark02(16.10493984431625,16.1716023062616 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark02(161.9194351074628,-15.580549821147438 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark02(-16.204654092826864,-1.8948658330886587 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark02(16.207963267948973,-4.6830028043767395 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark02(16.256578494752503,-1.570796326794897 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark02(-16.295827002463525,-15.727452104637024 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark02(-16.29968682389375,-21.59327791808418 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark02(164.06279205977677,36.8282895892594 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark02(16.40685315565529,-58.81835397924812 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark02(16.422397333769993,2594.329681451549 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark02(-164.72842469848626,-66.17863533987276 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark02(-16.521049752226407,-79.66987151204245 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark02(-16.646825414619954,-11.009202750407407 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark02(16.68414160219139,-77.20178438002606 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark02(-16.706875782494805,-46.04237684549825 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark02(16.707544902199473,-48.82956618887033 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark02(-16.70795471398752,0.0 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark02(-16.72089051216004,-97.75935501446628 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark02(16.763697105495524,-53.544028315536885 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark02(16.774115657988716,-61.58517897547304 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark02(-168.11850864872483,24.949181595019468 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark02(16.817084862504156,-44.46635856271187 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark02(-168.35090485798816,75.12252579485347 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark02(-168.57610657642473,-41.2223022403699 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark02(16.862421763307587,-1.5707963267948983 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark02(16.885964848157457,0 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark02(-169.1530795747216,41.727017226561145 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark02(-16.920318933118338,-15.507079005055644 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark02(-169.23920225376662,-14.429228765457985 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark02(-1.6940658945086007E-21,0.0 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark02(169.6460224886547,124.09290981607425 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark02(-169.64646241066424,32.98672250541124 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark02(16.96658920571401,-16.596003320818568 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark02(17.002266294603643,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark02(1.7201998558265155,72.38640199791368 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark02(1.7265997779805105,58.11394097551448 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark02(-17.275963736220007,33.598520398163686 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark02(-172.87004672525413,48.7440196957203 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark02(-173.26137921800034,44.03239122155483 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark02(-1.734723475976807E-18,1.570796326714036 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark02(-1.7390730826061627,78.37153958453061 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark02(-17.424874968493185,-1.5707963267946923 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark02(-17.425145378781664,-99.7261522872337 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark02(-174.427773524482,40.49578810774571 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark02(-17.49277827008133,24.822927884912005 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark02(-17.50375823714153,-0.2758101770700785 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark02(175.9127138748845,19.513218322014737 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark02(17.616947875999983,-2.8034043726350766 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark02(17.67002131547457,-57.981459536024204 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark02(17.68141513515155,-53.73634243499125 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark02(-17.74790737190395,-71.9407443361278 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,0.0 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,18.718135312377782 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-3.027564273010171 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark02(-1.7763568394002505E-15,-52.29021820506958 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark02(-17.764502319151404,0.0 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark02(-17.770001126459356,1.5707963267948966 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark02(17.795063616426532,83.42997133131811 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark02(179.07126954952452,39.26990712554848 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark02(-17.956665741454046,-5.201090919751451 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark02(-17.95760899837242,-2.4361878181414056 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark02(180.78381490741742,1.175634595611173E-14 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark02(1.8088546953003686,0.0 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark02(-18.089157237683892,68.42280350418989 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark02(-18.108852768892145,30.554885136752738 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark02(-181.9872168458072,79.60814836802624 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark02(-182.08967309668944,-21.983255156126155 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark02(-182.2072951828401,36.12831551627348 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark02(182.21236810924432,-2.288781326847626E-13 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark02(-182.21379912084333,-80.11085689062386 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark02(182.57301767510944,-2528.829500248101 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark02(183.09941740763475,-7.853981627291601 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark02(183.47206604950708,16.69146454390537 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark02(-183.5843593234776,53.703762788002564 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark02(-184.9467783028077,-8.261174550078138 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark02(-18.522168312442005,0.023250105916230446 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark02(-187.3461766782224,-100.0 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark02(18.77031373582696,-0.2884121301124621 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark02(-1.8820821807708654,-65.39900577716188 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark02(-18.832482287701595,-1.5707963267948963 ) ;
  }

  @Test
  public void test776() {
    coral.tests.JPFBenchmark.benchmark02(-18.849551008756887,42.41150082241104 ) ;
  }

  @Test
  public void test777() {
    coral.tests.JPFBenchmark.benchmark02(188.49555548188098,102.10175639536872 ) ;
  }

  @Test
  public void test778() {
    coral.tests.JPFBenchmark.benchmark02(188.49555921538754,-1.5707963267948966 ) ;
  }

  @Test
  public void test779() {
    coral.tests.JPFBenchmark.benchmark02(18.84958643911754,-1.5707963268910219 ) ;
  }

  @Test
  public void test780() {
    coral.tests.JPFBenchmark.benchmark02(18.85064180094591,-4.712388588709966 ) ;
  }

  @Test
  public void test781() {
    coral.tests.JPFBenchmark.benchmark02(18.878054498717166,0.0 ) ;
  }

  @Test
  public void test782() {
    coral.tests.JPFBenchmark.benchmark02(-18.95756272224196,84.13502883179063 ) ;
  }

  @Test
  public void test783() {
    coral.tests.JPFBenchmark.benchmark02(18.98481698323633,-26.17024888200006 ) ;
  }

  @Test
  public void test784() {
    coral.tests.JPFBenchmark.benchmark02(-19.022305707633418,70.73637890705294 ) ;
  }

  @Test
  public void test785() {
    coral.tests.JPFBenchmark.benchmark02(-19.062246910303273,0.0 ) ;
  }

  @Test
  public void test786() {
    coral.tests.JPFBenchmark.benchmark02(-19.07325197444479,79.84973783068807 ) ;
  }

  @Test
  public void test787() {
    coral.tests.JPFBenchmark.benchmark02(19.095367704472476,-48.38480851235867 ) ;
  }

  @Test
  public void test788() {
    coral.tests.JPFBenchmark.benchmark02(19.097457288467965,-11.434776819513942 ) ;
  }

  @Test
  public void test789() {
    coral.tests.JPFBenchmark.benchmark02(-19.101276339517483,95.81857593448869 ) ;
  }

  @Test
  public void test790() {
    coral.tests.JPFBenchmark.benchmark02(19.144502028256923,-11.465840890964031 ) ;
  }

  @Test
  public void test791() {
    coral.tests.JPFBenchmark.benchmark02(191.86391565591282,75.20669848387763 ) ;
  }

  @Test
  public void test792() {
    coral.tests.JPFBenchmark.benchmark02(1.9228438803826648,0.0 ) ;
  }

  @Test
  public void test793() {
    coral.tests.JPFBenchmark.benchmark02(19.30612774603366,2629.680667826169 ) ;
  }

  @Test
  public void test794() {
    coral.tests.JPFBenchmark.benchmark02(-19.349555921538762,-27.190375078569296 ) ;
  }

  @Test
  public void test795() {
    coral.tests.JPFBenchmark.benchmark02(19.349555921538762,45.3604322608195 ) ;
  }

  @Test
  public void test796() {
    coral.tests.JPFBenchmark.benchmark02(19.349555922685095,-7.5131881292306035 ) ;
  }

  @Test
  public void test797() {
    coral.tests.JPFBenchmark.benchmark02(19.36184298019413,-1.5707963267948966 ) ;
  }

  @Test
  public void test798() {
    coral.tests.JPFBenchmark.benchmark02(-19.480973732794865,-26.703537555513243 ) ;
  }

  @Test
  public void test799() {
    coral.tests.JPFBenchmark.benchmark02(19.53922277609357,-141.4274216895786 ) ;
  }

  @Test
  public void test800() {
    coral.tests.JPFBenchmark.benchmark02(-19.55003116426962,5.079495697536871 ) ;
  }

  @Test
  public void test801() {
    coral.tests.JPFBenchmark.benchmark02(19.55246226811426,-0.0020421068426105284 ) ;
  }

  @Test
  public void test802() {
    coral.tests.JPFBenchmark.benchmark02(-19.633124925215824,46.44413606420218 ) ;
  }

  @Test
  public void test803() {
    coral.tests.JPFBenchmark.benchmark02(-19.678870684094946,2626.0769373072035 ) ;
  }

  @Test
  public void test804() {
    coral.tests.JPFBenchmark.benchmark02(-19.711052743698914,-87.43073312134484 ) ;
  }

  @Test
  public void test805() {
    coral.tests.JPFBenchmark.benchmark02(-19.824849850172924,0.0 ) ;
  }

  @Test
  public void test806() {
    coral.tests.JPFBenchmark.benchmark02(-19.865248836744925,2.4467270931756047 ) ;
  }

  @Test
  public void test807() {
    coral.tests.JPFBenchmark.benchmark02(-19.907335939781678,-191.12413556062916 ) ;
  }

  @Test
  public void test808() {
    coral.tests.JPFBenchmark.benchmark02(-19.913198567331893,0.4999565125196073 ) ;
  }

  @Test
  public void test809() {
    coral.tests.JPFBenchmark.benchmark02(19.915127669945562,76.38554308881106 ) ;
  }

  @Test
  public void test810() {
    coral.tests.JPFBenchmark.benchmark02(-19.917221013405594,96.3464827988399 ) ;
  }

  @Test
  public void test811() {
    coral.tests.JPFBenchmark.benchmark02(19.958311702726842,56.019215385590826 ) ;
  }

  @Test
  public void test812() {
    coral.tests.JPFBenchmark.benchmark02(20.003172780521126,63.526254956203786 ) ;
  }

  @Test
  public void test813() {
    coral.tests.JPFBenchmark.benchmark02(20.06180316544659,-24.995561139228087 ) ;
  }

  @Test
  public void test814() {
    coral.tests.JPFBenchmark.benchmark02(-20.079596550071585,-67.77528650194586 ) ;
  }

  @Test
  public void test815() {
    coral.tests.JPFBenchmark.benchmark02(20.10813454114113,-45.24705584320461 ) ;
  }

  @Test
  public void test816() {
    coral.tests.JPFBenchmark.benchmark02(20.138462379873417,-50.311853178367684 ) ;
  }

  @Test
  public void test817() {
    coral.tests.JPFBenchmark.benchmark02(-20.14750243786881,-158.4596346025953 ) ;
  }

  @Test
  public void test818() {
    coral.tests.JPFBenchmark.benchmark02(-20.158439382468146,-36.878021153001725 ) ;
  }

  @Test
  public void test819() {
    coral.tests.JPFBenchmark.benchmark02(-20.333012000095536,73.65969408741057 ) ;
  }

  @Test
  public void test820() {
    coral.tests.JPFBenchmark.benchmark02(-20.399425154811453,0 ) ;
  }

  @Test
  public void test821() {
    coral.tests.JPFBenchmark.benchmark02(-20.412906725876113,1.5707963267948966 ) ;
  }

  @Test
  public void test822() {
    coral.tests.JPFBenchmark.benchmark02(20.431403407983897,-55.96934873696941 ) ;
  }

  @Test
  public void test823() {
    coral.tests.JPFBenchmark.benchmark02(20.4336714786867,1.5707963267948966 ) ;
  }

  @Test
  public void test824() {
    coral.tests.JPFBenchmark.benchmark02(20.436672108945658,0.5053028719622391 ) ;
  }

  @Test
  public void test825() {
    coral.tests.JPFBenchmark.benchmark02(20.461900850646533,-1.5707963267948966 ) ;
  }

  @Test
  public void test826() {
    coral.tests.JPFBenchmark.benchmark02(20.482730238193113,-101.54524501240255 ) ;
  }

  @Test
  public void test827() {
    coral.tests.JPFBenchmark.benchmark02(20.487483499793726,-2613.25573912791 ) ;
  }

  @Test
  public void test828() {
    coral.tests.JPFBenchmark.benchmark02(-20.508889726144304,71.2314970615005 ) ;
  }

  @Test
  public void test829() {
    coral.tests.JPFBenchmark.benchmark02(20.509779986422487,59.73582289326359 ) ;
  }

  @Test
  public void test830() {
    coral.tests.JPFBenchmark.benchmark02(-20.532293814932643,-1.5707963267949037 ) ;
  }

  @Test
  public void test831() {
    coral.tests.JPFBenchmark.benchmark02(-20.54700892209856,-2507.1410202566763 ) ;
  }

  @Test
  public void test832() {
    coral.tests.JPFBenchmark.benchmark02(20.573818770950574,1.5707963267948966 ) ;
  }

  @Test
  public void test833() {
    coral.tests.JPFBenchmark.benchmark02(20.588346951541403,14.429288015958846 ) ;
  }

  @Test
  public void test834() {
    coral.tests.JPFBenchmark.benchmark02(20.628479328895576,-99.49674760712261 ) ;
  }

  @Test
  public void test835() {
    coral.tests.JPFBenchmark.benchmark02(-20.654324463401164,-30.64916762723007 ) ;
  }

  @Test
  public void test836() {
    coral.tests.JPFBenchmark.benchmark02(20.66524825757881,0.0 ) ;
  }

  @Test
  public void test837() {
    coral.tests.JPFBenchmark.benchmark02(20.676418694330394,-1.5707963267948966 ) ;
  }

  @Test
  public void test838() {
    coral.tests.JPFBenchmark.benchmark02(20.67806817265334,1.5707963267948966 ) ;
  }

  @Test
  public void test839() {
    coral.tests.JPFBenchmark.benchmark02(20.712740824116054,56.77176402298272 ) ;
  }

  @Test
  public void test840() {
    coral.tests.JPFBenchmark.benchmark02(20.718510121649643,100.0 ) ;
  }

  @Test
  public void test841() {
    coral.tests.JPFBenchmark.benchmark02(20.72120881364861,0.0 ) ;
  }

  @Test
  public void test842() {
    coral.tests.JPFBenchmark.benchmark02(20.726501531066376,74.10751513892909 ) ;
  }

  @Test
  public void test843() {
    coral.tests.JPFBenchmark.benchmark02(20.737370425703034,-90.50400112942802 ) ;
  }

  @Test
  public void test844() {
    coral.tests.JPFBenchmark.benchmark02(-20.74591441340614,2618.6663787417256 ) ;
  }

  @Test
  public void test845() {
    coral.tests.JPFBenchmark.benchmark02(-20.74734886225935,-45.157878994061946 ) ;
  }

  @Test
  public void test846() {
    coral.tests.JPFBenchmark.benchmark02(20.759607345357843,1.5707963267949054 ) ;
  }

  @Test
  public void test847() {
    coral.tests.JPFBenchmark.benchmark02(20.76122897615112,-1.570796326794897 ) ;
  }

  @Test
  public void test848() {
    coral.tests.JPFBenchmark.benchmark02(-20.77504188708781,44.34090047021115 ) ;
  }

  @Test
  public void test849() {
    coral.tests.JPFBenchmark.benchmark02(-20.800481510189,67.89693964157172 ) ;
  }

  @Test
  public void test850() {
    coral.tests.JPFBenchmark.benchmark02(20.81131936781742,41.448854106524635 ) ;
  }

  @Test
  public void test851() {
    coral.tests.JPFBenchmark.benchmark02(-20.84487652765202,1.5707963267948966 ) ;
  }

  @Test
  public void test852() {
    coral.tests.JPFBenchmark.benchmark02(20.86588949666787,0.7438277446234762 ) ;
  }

  @Test
  public void test853() {
    coral.tests.JPFBenchmark.benchmark02(-20.866328988659006,49.253240739034396 ) ;
  }

  @Test
  public void test854() {
    coral.tests.JPFBenchmark.benchmark02(20.88157546556161,-43.52162514286643 ) ;
  }

  @Test
  public void test855() {
    coral.tests.JPFBenchmark.benchmark02(-20.909292744225905,59.20131992252673 ) ;
  }

  @Test
  public void test856() {
    coral.tests.JPFBenchmark.benchmark02(20.929131829085932,36.27228334197309 ) ;
  }

  @Test
  public void test857() {
    coral.tests.JPFBenchmark.benchmark02(-20.933426117910486,-53.92316915641455 ) ;
  }

  @Test
  public void test858() {
    coral.tests.JPFBenchmark.benchmark02(20.96447868709765,17.912652280556 ) ;
  }

  @Test
  public void test859() {
    coral.tests.JPFBenchmark.benchmark02(20.974002883851217,-25.818097897996722 ) ;
  }

  @Test
  public void test860() {
    coral.tests.JPFBenchmark.benchmark02(20.9844676535449,32.443854921766 ) ;
  }

  @Test
  public void test861() {
    coral.tests.JPFBenchmark.benchmark02(20.98865216783967,95.28413215597676 ) ;
  }

  @Test
  public void test862() {
    coral.tests.JPFBenchmark.benchmark02(20.98883423823021,0.0 ) ;
  }

  @Test
  public void test863() {
    coral.tests.JPFBenchmark.benchmark02(21.02288854574745,-16.45889629361251 ) ;
  }

  @Test
  public void test864() {
    coral.tests.JPFBenchmark.benchmark02(21.038775302394548,-0.4736194929599545 ) ;
  }

  @Test
  public void test865() {
    coral.tests.JPFBenchmark.benchmark02(-21.08034583342413,83.06479732274764 ) ;
  }

  @Test
  public void test866() {
    coral.tests.JPFBenchmark.benchmark02(-21.0814623530178,14.0173174732505 ) ;
  }

  @Test
  public void test867() {
    coral.tests.JPFBenchmark.benchmark02(2.1175823681357508E-22,-39.26990816997242 ) ;
  }

  @Test
  public void test868() {
    coral.tests.JPFBenchmark.benchmark02(-21.202350539421232,-83.13275975819403 ) ;
  }

  @Test
  public void test869() {
    coral.tests.JPFBenchmark.benchmark02(-21.20450748049716,0.0 ) ;
  }

  @Test
  public void test870() {
    coral.tests.JPFBenchmark.benchmark02(21.250504144733924,-11.602122176343102 ) ;
  }

  @Test
  public void test871() {
    coral.tests.JPFBenchmark.benchmark02(-21.452143659449206,-35.79415870205567 ) ;
  }

  @Test
  public void test872() {
    coral.tests.JPFBenchmark.benchmark02(21.45754030748124,-1.5707963267948948 ) ;
  }

  @Test
  public void test873() {
    coral.tests.JPFBenchmark.benchmark02(-21.457774381498183,60.25981469613484 ) ;
  }

  @Test
  public void test874() {
    coral.tests.JPFBenchmark.benchmark02(-21.4790140095889,-2.082930892449266 ) ;
  }

  @Test
  public void test875() {
    coral.tests.JPFBenchmark.benchmark02(-2.1487717264198039E-10,58.728731683313185 ) ;
  }

  @Test
  public void test876() {
    coral.tests.JPFBenchmark.benchmark02(-215.0632279895153,-0.3289364720450564 ) ;
  }

  @Test
  public void test877() {
    coral.tests.JPFBenchmark.benchmark02(-21.514899699117475,1.2779509262349933 ) ;
  }

  @Test
  public void test878() {
    coral.tests.JPFBenchmark.benchmark02(21.573607627229038,-30.262671156893152 ) ;
  }

  @Test
  public void test879() {
    coral.tests.JPFBenchmark.benchmark02(-21.577458558613756,-40.56030472579084 ) ;
  }

  @Test
  public void test880() {
    coral.tests.JPFBenchmark.benchmark02(-21.582156149232404,5.818524711816477 ) ;
  }

  @Test
  public void test881() {
    coral.tests.JPFBenchmark.benchmark02(21.645296577729596,-49.88927583877853 ) ;
  }

  @Test
  public void test882() {
    coral.tests.JPFBenchmark.benchmark02(21.650650574081393,43.77785473309928 ) ;
  }

  @Test
  public void test883() {
    coral.tests.JPFBenchmark.benchmark02(21.675905359520286,-4.190412915881851 ) ;
  }

  @Test
  public void test884() {
    coral.tests.JPFBenchmark.benchmark02(-2.1684043449710089E-19,1.5707953725668284 ) ;
  }

  @Test
  public void test885() {
    coral.tests.JPFBenchmark.benchmark02(-21.691676830484894,1.5707963267948974 ) ;
  }

  @Test
  public void test886() {
    coral.tests.JPFBenchmark.benchmark02(-21.698912259080274,-1.8630326429476032 ) ;
  }

  @Test
  public void test887() {
    coral.tests.JPFBenchmark.benchmark02(2.1731991200491484E-8,1.5708281202308654 ) ;
  }

  @Test
  public void test888() {
    coral.tests.JPFBenchmark.benchmark02(-21.772450721037437,1.3005637143751033E-9 ) ;
  }

  @Test
  public void test889() {
    coral.tests.JPFBenchmark.benchmark02(-21.86959897452165,-146.69477097989008 ) ;
  }

  @Test
  public void test890() {
    coral.tests.JPFBenchmark.benchmark02(21.876160034733445,34.38182370652626 ) ;
  }

  @Test
  public void test891() {
    coral.tests.JPFBenchmark.benchmark02(-21.881259876678484,-60.25272097458715 ) ;
  }

  @Test
  public void test892() {
    coral.tests.JPFBenchmark.benchmark02(21.887836677285506,-74.10388529587358 ) ;
  }

  @Test
  public void test893() {
    coral.tests.JPFBenchmark.benchmark02(21.893927359273377,-4.932802404935305 ) ;
  }

  @Test
  public void test894() {
    coral.tests.JPFBenchmark.benchmark02(21.935403937813724,2.2083122178424886E-10 ) ;
  }

  @Test
  public void test895() {
    coral.tests.JPFBenchmark.benchmark02(-21.940120517786937,-10.557283294119472 ) ;
  }

  @Test
  public void test896() {
    coral.tests.JPFBenchmark.benchmark02(21.99077181080849,-10.996062568814278 ) ;
  }

  @Test
  public void test897() {
    coral.tests.JPFBenchmark.benchmark02(-21.991127595168642,-14.429285327091861 ) ;
  }

  @Test
  public void test898() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148003762515,36.12831683121456 ) ;
  }

  @Test
  public void test899() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148425072964,-1.5707960663312786 ) ;
  }

  @Test
  public void test900() {
    coral.tests.JPFBenchmark.benchmark02(21.991148550980412,89.53545168890417 ) ;
  }

  @Test
  public void test901() {
    coral.tests.JPFBenchmark.benchmark02(21.991148575028554,-1.5707963267948966 ) ;
  }

  @Test
  public void test902() {
    coral.tests.JPFBenchmark.benchmark02(-21.991148575216762,10.995574287552486 ) ;
  }

  @Test
  public void test903() {
    coral.tests.JPFBenchmark.benchmark02(21.991392715774722,-95.81856572143556 ) ;
  }

  @Test
  public void test904() {
    coral.tests.JPFBenchmark.benchmark02(220.075382433025,57.95556740977306 ) ;
  }

  @Test
  public void test905() {
    coral.tests.JPFBenchmark.benchmark02(-22.203332223971344,-0.25531466058940566 ) ;
  }

  @Test
  public void test906() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,0.0 ) ;
  }

  @Test
  public void test907() {
    coral.tests.JPFBenchmark.benchmark02(2.220446049250313E-16,0.7027326207107905 ) ;
  }

  @Test
  public void test908() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,-1.5707963267948541 ) ;
  }

  @Test
  public void test909() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,-1.5707963267948983 ) ;
  }

  @Test
  public void test910() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,-2580.820095472773 ) ;
  }

  @Test
  public void test911() {
    coral.tests.JPFBenchmark.benchmark02(-2.220446049250313E-16,91.0657585920147 ) ;
  }

  @Test
  public void test912() {
    coral.tests.JPFBenchmark.benchmark02(22.216505485023674,-1.5707963267949054 ) ;
  }

  @Test
  public void test913() {
    coral.tests.JPFBenchmark.benchmark02(-22.22255259061197,0.0 ) ;
  }

  @Test
  public void test914() {
    coral.tests.JPFBenchmark.benchmark02(2.2227731096343218E-14,67.54424205208058 ) ;
  }

  @Test
  public void test915() {
    coral.tests.JPFBenchmark.benchmark02(22.341555760075522,1.5707963267948912 ) ;
  }

  @Test
  public void test916() {
    coral.tests.JPFBenchmark.benchmark02(22.34463658942611,-1.8250987348280177 ) ;
  }

  @Test
  public void test917() {
    coral.tests.JPFBenchmark.benchmark02(-22.357883850323105,23.771493755660615 ) ;
  }

  @Test
  public void test918() {
    coral.tests.JPFBenchmark.benchmark02(-2.2415512146000457E-11,10.6891563136786 ) ;
  }

  @Test
  public void test919() {
    coral.tests.JPFBenchmark.benchmark02(-22.42248508240009,1.5707963267948966 ) ;
  }

  @Test
  public void test920() {
    coral.tests.JPFBenchmark.benchmark02(2.242368298161608,-1.5707963267948963 ) ;
  }

  @Test
  public void test921() {
    coral.tests.JPFBenchmark.benchmark02(-22.438351483690248,-87.26592331036893 ) ;
  }

  @Test
  public void test922() {
    coral.tests.JPFBenchmark.benchmark02(-22.451731639580203,-1.7981710701678332E-4 ) ;
  }

  @Test
  public void test923() {
    coral.tests.JPFBenchmark.benchmark02(-22.53329206554606,-5.255895272337974 ) ;
  }

  @Test
  public void test924() {
    coral.tests.JPFBenchmark.benchmark02(22.610889507206508,-82.15673044362306 ) ;
  }

  @Test
  public void test925() {
    coral.tests.JPFBenchmark.benchmark02(22.64033170221739,-13.44703846632001 ) ;
  }

  @Test
  public void test926() {
    coral.tests.JPFBenchmark.benchmark02(-22.640690828724388,-45.462061112652094 ) ;
  }

  @Test
  public void test927() {
    coral.tests.JPFBenchmark.benchmark02(-22.690731637184605,-0.5966617322059734 ) ;
  }

  @Test
  public void test928() {
    coral.tests.JPFBenchmark.benchmark02(-22.733150604270634,25.961535526506825 ) ;
  }

  @Test
  public void test929() {
    coral.tests.JPFBenchmark.benchmark02(-2.2748349193550776,6.399294720440615E-10 ) ;
  }

  @Test
  public void test930() {
    coral.tests.JPFBenchmark.benchmark02(22.76311081088565,-22.535124655413426 ) ;
  }

  @Test
  public void test931() {
    coral.tests.JPFBenchmark.benchmark02(-22.801074858286817,1.5707963268131906 ) ;
  }

  @Test
  public void test932() {
    coral.tests.JPFBenchmark.benchmark02(-22.853404320222538,-86.34572814199201 ) ;
  }

  @Test
  public void test933() {
    coral.tests.JPFBenchmark.benchmark02(22.910922096807923,7.596690415620131 ) ;
  }

  @Test
  public void test934() {
    coral.tests.JPFBenchmark.benchmark02(-229.23558540393455,-2.4571007647512127E-9 ) ;
  }

  @Test
  public void test935() {
    coral.tests.JPFBenchmark.benchmark02(23.167006114181383,78.14487755226267 ) ;
  }

  @Test
  public void test936() {
    coral.tests.JPFBenchmark.benchmark02(-23.186658205629357,-1.5707963267949054 ) ;
  }

  @Test
  public void test937() {
    coral.tests.JPFBenchmark.benchmark02(23.217825463838007,65.62932628759663 ) ;
  }

  @Test
  public void test938() {
    coral.tests.JPFBenchmark.benchmark02(-23.220799908742066,17.257779365328773 ) ;
  }

  @Test
  public void test939() {
    coral.tests.JPFBenchmark.benchmark02(23.39004394528756,78.0345740858387 ) ;
  }

  @Test
  public void test940() {
    coral.tests.JPFBenchmark.benchmark02(-23.555810231088373,-2.068790228706561 ) ;
  }

  @Test
  public void test941() {
    coral.tests.JPFBenchmark.benchmark02(23.576744856713148,12.720292396687611 ) ;
  }

  @Test
  public void test942() {
    coral.tests.JPFBenchmark.benchmark02(23.753466281093853,-1.5707963267948966 ) ;
  }

  @Test
  public void test943() {
    coral.tests.JPFBenchmark.benchmark02(23.83217118565432,6.145498040222023 ) ;
  }

  @Test
  public void test944() {
    coral.tests.JPFBenchmark.benchmark02(-238.38854188493286,-10.430243190339695 ) ;
  }

  @Test
  public void test945() {
    coral.tests.JPFBenchmark.benchmark02(23.975643127119397,138.04377028573936 ) ;
  }

  @Test
  public void test946() {
    coral.tests.JPFBenchmark.benchmark02(24.04122751924737,53.80745121670168 ) ;
  }

  @Test
  public void test947() {
    coral.tests.JPFBenchmark.benchmark02(24.1075013585631,-76.60740574717289 ) ;
  }

  @Test
  public void test948() {
    coral.tests.JPFBenchmark.benchmark02(2.4175028357675217,1.5707963267948948 ) ;
  }

  @Test
  public void test949() {
    coral.tests.JPFBenchmark.benchmark02(-24.193761082060973,0 ) ;
  }

  @Test
  public void test950() {
    coral.tests.JPFBenchmark.benchmark02(-24.296176701011195,-8.702998182816751E-10 ) ;
  }

  @Test
  public void test951() {
    coral.tests.JPFBenchmark.benchmark02(-2.4345910566240274,56.848506754734004 ) ;
  }

  @Test
  public void test952() {
    coral.tests.JPFBenchmark.benchmark02(24.351490879987963,-1.5707963267948966 ) ;
  }

  @Test
  public void test953() {
    coral.tests.JPFBenchmark.benchmark02(-24.38563861153428,0.46385689935766905 ) ;
  }

  @Test
  public void test954() {
    coral.tests.JPFBenchmark.benchmark02(24.397610543191092,38.9721088745675 ) ;
  }

  @Test
  public void test955() {
    coral.tests.JPFBenchmark.benchmark02(-2.440906443182527,-0.26644439778008905 ) ;
  }

  @Test
  public void test956() {
    coral.tests.JPFBenchmark.benchmark02(-24.481320870832416,-7.142364689078868 ) ;
  }

  @Test
  public void test957() {
    coral.tests.JPFBenchmark.benchmark02(24.591018144748283,13.12841901169017 ) ;
  }

  @Test
  public void test958() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,-1.5707963267948966 ) ;
  }

  @Test
  public void test959() {
    coral.tests.JPFBenchmark.benchmark02(-2.465190328815662E-32,45.553093477051995 ) ;
  }

  @Test
  public void test960() {
    coral.tests.JPFBenchmark.benchmark02(-24.65909375097891,30.29285620454321 ) ;
  }

  @Test
  public void test961() {
    coral.tests.JPFBenchmark.benchmark02(24.72305141774001,92.37146331805755 ) ;
  }

  @Test
  public void test962() {
    coral.tests.JPFBenchmark.benchmark02(-24.86861294726181,0 ) ;
  }

  @Test
  public void test963() {
    coral.tests.JPFBenchmark.benchmark02(25.00667202225047,-16.62540420080076 ) ;
  }

  @Test
  public void test964() {
    coral.tests.JPFBenchmark.benchmark02(-25.048551251799054,0.0 ) ;
  }

  @Test
  public void test965() {
    coral.tests.JPFBenchmark.benchmark02(25.050507558064353,10.350983839789919 ) ;
  }

  @Test
  public void test966() {
    coral.tests.JPFBenchmark.benchmark02(-25.06395230389677,-39.343112811898486 ) ;
  }

  @Test
  public void test967() {
    coral.tests.JPFBenchmark.benchmark02(-25.13274122866296,-1.5707963267953247 ) ;
  }

  @Test
  public void test968() {
    coral.tests.JPFBenchmark.benchmark02(-25.1327412287329,-1.5707963267948963 ) ;
  }

  @Test
  public void test969() {
    coral.tests.JPFBenchmark.benchmark02(25.132741228817444,-1.5707963267948966 ) ;
  }

  @Test
  public void test970() {
    coral.tests.JPFBenchmark.benchmark02(25.13274141833021,29.84513020904606 ) ;
  }

  @Test
  public void test971() {
    coral.tests.JPFBenchmark.benchmark02(-25.13279330372364,-0.4144658680640353 ) ;
  }

  @Test
  public void test972() {
    coral.tests.JPFBenchmark.benchmark02(-25.13280229598683,-1.5707963267948966 ) ;
  }

  @Test
  public void test973() {
    coral.tests.JPFBenchmark.benchmark02(-25.133537943014716,-58.119463927432236 ) ;
  }

  @Test
  public void test974() {
    coral.tests.JPFBenchmark.benchmark02(-25.13376841030004,-2599.3485535812038 ) ;
  }

  @Test
  public void test975() {
    coral.tests.JPFBenchmark.benchmark02(-25.133931227925242,1.5747026445195427 ) ;
  }

  @Test
  public void test976() {
    coral.tests.JPFBenchmark.benchmark02(-25.136647478726392,-1.5707963267948948 ) ;
  }

  @Test
  public void test977() {
    coral.tests.JPFBenchmark.benchmark02(-25.211723839786593,-65.04800723043667 ) ;
  }

  @Test
  public void test978() {
    coral.tests.JPFBenchmark.benchmark02(25.228813532339785,-90.43600349893761 ) ;
  }

  @Test
  public void test979() {
    coral.tests.JPFBenchmark.benchmark02(25.32653711726165,66.31522824595709 ) ;
  }

  @Test
  public void test980() {
    coral.tests.JPFBenchmark.benchmark02(-25.3687926450677,-13.724981103606453 ) ;
  }

  @Test
  public void test981() {
    coral.tests.JPFBenchmark.benchmark02(25.422711543676684,100.0 ) ;
  }

  @Test
  public void test982() {
    coral.tests.JPFBenchmark.benchmark02(25.432581968706216,91.16602022521477 ) ;
  }

  @Test
  public void test983() {
    coral.tests.JPFBenchmark.benchmark02(-25.45367714656539,14.458102859106495 ) ;
  }

  @Test
  public void test984() {
    coral.tests.JPFBenchmark.benchmark02(-25.47269213516001,-64.7426003051385 ) ;
  }

  @Test
  public void test985() {
    coral.tests.JPFBenchmark.benchmark02(-25.48714279022119,-97.7009627542359 ) ;
  }

  @Test
  public void test986() {
    coral.tests.JPFBenchmark.benchmark02(25.48726491385314,-14.09024434128267 ) ;
  }

  @Test
  public void test987() {
    coral.tests.JPFBenchmark.benchmark02(25.49204719833797,1.5707963267948966 ) ;
  }

  @Test
  public void test988() {
    coral.tests.JPFBenchmark.benchmark02(25.52053167344007,1.5707963267948974 ) ;
  }

  @Test
  public void test989() {
    coral.tests.JPFBenchmark.benchmark02(-25.52432453033177,-83.46926200587608 ) ;
  }

  @Test
  public void test990() {
    coral.tests.JPFBenchmark.benchmark02(25.52528222125288,74.355679010289 ) ;
  }

  @Test
  public void test991() {
    coral.tests.JPFBenchmark.benchmark02(25.544334448562154,-44.43958150719602 ) ;
  }

  @Test
  public void test992() {
    coral.tests.JPFBenchmark.benchmark02(25.58800462106924,-1.5707963267949054 ) ;
  }

  @Test
  public void test993() {
    coral.tests.JPFBenchmark.benchmark02(-25.621295655551428,4.6152533847227915 ) ;
  }

  @Test
  public void test994() {
    coral.tests.JPFBenchmark.benchmark02(25.622123294862746,2520.029128268814 ) ;
  }

  @Test
  public void test995() {
    coral.tests.JPFBenchmark.benchmark02(-25.633760004402344,0.0 ) ;
  }

  @Test
  public void test996() {
    coral.tests.JPFBenchmark.benchmark02(25.66900670557024,2596.0870672890533 ) ;
  }

  @Test
  public void test997() {
    coral.tests.JPFBenchmark.benchmark02(-25.67735912097468,-1.4423314036278194 ) ;
  }

  @Test
  public void test998() {
    coral.tests.JPFBenchmark.benchmark02(-25.710547635005625,0 ) ;
  }

  @Test
  public void test999() {
    coral.tests.JPFBenchmark.benchmark02(-25.71977642652945,74.76525163891498 ) ;
  }

  @Test
  public void test1000() {
    coral.tests.JPFBenchmark.benchmark02(-25.785268117876548,-1.5707963267948972 ) ;
  }

  @Test
  public void test1001() {
    coral.tests.JPFBenchmark.benchmark02(25.809884051192284,0 ) ;
  }

  @Test
  public void test1002() {
    coral.tests.JPFBenchmark.benchmark02(25.913993604567423,0.0 ) ;
  }

  @Test
  public void test1003() {
    coral.tests.JPFBenchmark.benchmark02(25.91839544717127,44.226388817103356 ) ;
  }

  @Test
  public void test1004() {
    coral.tests.JPFBenchmark.benchmark02(25.922007713503803,0.0 ) ;
  }

  @Test
  public void test1005() {
    coral.tests.JPFBenchmark.benchmark02(-25.945440122950487,-76.10184190742959 ) ;
  }

  @Test
  public void test1006() {
    coral.tests.JPFBenchmark.benchmark02(-25.992651304934995,-10.708190582238558 ) ;
  }

  @Test
  public void test1007() {
    coral.tests.JPFBenchmark.benchmark02(-260.3268911176568,-97.67604021250733 ) ;
  }

  @Test
  public void test1008() {
    coral.tests.JPFBenchmark.benchmark02(26.11525220990941,-74.70702697983727 ) ;
  }

  @Test
  public void test1009() {
    coral.tests.JPFBenchmark.benchmark02(26.132386725603354,-28.953108496254472 ) ;
  }

  @Test
  public void test1010() {
    coral.tests.JPFBenchmark.benchmark02(26.1585372163984,-0.0659408170489898 ) ;
  }

  @Test
  public void test1011() {
    coral.tests.JPFBenchmark.benchmark02(26.219837760784372,0.0 ) ;
  }

  @Test
  public void test1012() {
    coral.tests.JPFBenchmark.benchmark02(2622.846020220116,0 ) ;
  }

  @Test
  public void test1013() {
    coral.tests.JPFBenchmark.benchmark02(-26.326830524962553,-36.12831551630657 ) ;
  }

  @Test
  public void test1014() {
    coral.tests.JPFBenchmark.benchmark02(26.383497234852257,55.55116447784853 ) ;
  }

  @Test
  public void test1015() {
    coral.tests.JPFBenchmark.benchmark02(-26.387395125813455,45.22273447871041 ) ;
  }

  @Test
  public void test1016() {
    coral.tests.JPFBenchmark.benchmark02(26.419030403330694,-1.5707963267948966 ) ;
  }

  @Test
  public void test1017() {
    coral.tests.JPFBenchmark.benchmark02(26.481723437061476,-99.19325813454287 ) ;
  }

  @Test
  public void test1018() {
    coral.tests.JPFBenchmark.benchmark02(-2.6491287832624093,2.0707963267948983 ) ;
  }

  @Test
  public void test1019() {
    coral.tests.JPFBenchmark.benchmark02(-26.516097012986137,-38.19540636428457 ) ;
  }

  @Test
  public void test1020() {
    coral.tests.JPFBenchmark.benchmark02(26.537101506013208,-14.429758797237206 ) ;
  }

  @Test
  public void test1021() {
    coral.tests.JPFBenchmark.benchmark02(-2.6549009262493897,-21.266568552782825 ) ;
  }

  @Test
  public void test1022() {
    coral.tests.JPFBenchmark.benchmark02(-26.65256026780467,-9.475755246516126 ) ;
  }

  @Test
  public void test1023() {
    coral.tests.JPFBenchmark.benchmark02(26.72968430233943,-9.491294179385243 ) ;
  }

  @Test
  public void test1024() {
    coral.tests.JPFBenchmark.benchmark02(26.75035941841739,1.5707963267948912 ) ;
  }

  @Test
  public void test1025() {
    coral.tests.JPFBenchmark.benchmark02(-26.761672563498653,0.5706113137652952 ) ;
  }

  @Test
  public void test1026() {
    coral.tests.JPFBenchmark.benchmark02(26.778721643783566,-6.480033351188209 ) ;
  }

  @Test
  public void test1027() {
    coral.tests.JPFBenchmark.benchmark02(26.80441011672326,-57.07360883584731 ) ;
  }

  @Test
  public void test1028() {
    coral.tests.JPFBenchmark.benchmark02(-26.80715644264139,-1.5707963267948966 ) ;
  }

  @Test
  public void test1029() {
    coral.tests.JPFBenchmark.benchmark02(-2.681635972108449,-14.430062230857764 ) ;
  }

  @Test
  public void test1030() {
    coral.tests.JPFBenchmark.benchmark02(26.83934708142759,0 ) ;
  }

  @Test
  public void test1031() {
    coral.tests.JPFBenchmark.benchmark02(26.84999034875143,-45.95976661373971 ) ;
  }

  @Test
  public void test1032() {
    coral.tests.JPFBenchmark.benchmark02(26.88737230841984,0.0 ) ;
  }

  @Test
  public void test1033() {
    coral.tests.JPFBenchmark.benchmark02(-26.905462231224192,1.5707963267948966 ) ;
  }

  @Test
  public void test1034() {
    coral.tests.JPFBenchmark.benchmark02(26.91010237669926,-1.5707963267948948 ) ;
  }

  @Test
  public void test1035() {
    coral.tests.JPFBenchmark.benchmark02(26.91288891968913,0.007132267102164142 ) ;
  }

  @Test
  public void test1036() {
    coral.tests.JPFBenchmark.benchmark02(-26.92295092549193,7.0580143302886995 ) ;
  }

  @Test
  public void test1037() {
    coral.tests.JPFBenchmark.benchmark02(26.955429167084276,-81.54512174227824 ) ;
  }

  @Test
  public void test1038() {
    coral.tests.JPFBenchmark.benchmark02(26.958682558657742,-52.76768344710336 ) ;
  }

  @Test
  public void test1039() {
    coral.tests.JPFBenchmark.benchmark02(26.973539038068537,90.48286885138538 ) ;
  }

  @Test
  public void test1040() {
    coral.tests.JPFBenchmark.benchmark02(26.996256821219944,-1.5707963267948966 ) ;
  }

  @Test
  public void test1041() {
    coral.tests.JPFBenchmark.benchmark02(-27.015391896793574,-68.52331711821653 ) ;
  }

  @Test
  public void test1042() {
    coral.tests.JPFBenchmark.benchmark02(-27.016790606201578,-0.5940676791278067 ) ;
  }

  @Test
  public void test1043() {
    coral.tests.JPFBenchmark.benchmark02(-27.02267177620685,0.0 ) ;
  }

  @Test
  public void test1044() {
    coral.tests.JPFBenchmark.benchmark02(27.034976532059762,4.4167476239943255 ) ;
  }

  @Test
  public void test1045() {
    coral.tests.JPFBenchmark.benchmark02(-27.060034663947018,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1046() {
    coral.tests.JPFBenchmark.benchmark02(27.065997642089528,-1.4754945489059388 ) ;
  }

  @Test
  public void test1047() {
    coral.tests.JPFBenchmark.benchmark02(-27.09745161384589,9.052215137930531 ) ;
  }

  @Test
  public void test1048() {
    coral.tests.JPFBenchmark.benchmark02(-27.10177114189949,-1.5707963267948966 ) ;
  }

  @Test
  public void test1049() {
    coral.tests.JPFBenchmark.benchmark02(-2.71057129029532,0.0 ) ;
  }

  @Test
  public void test1050() {
    coral.tests.JPFBenchmark.benchmark02(-27.120262032697212,51.32651806966951 ) ;
  }

  @Test
  public void test1051() {
    coral.tests.JPFBenchmark.benchmark02(-2714.715008838853,0 ) ;
  }

  @Test
  public void test1052() {
    coral.tests.JPFBenchmark.benchmark02(-27.15479076190654,97.84062546744758 ) ;
  }

  @Test
  public void test1053() {
    coral.tests.JPFBenchmark.benchmark02(-27.15653217540654,54.08002797606604 ) ;
  }

  @Test
  public void test1054() {
    coral.tests.JPFBenchmark.benchmark02(-27.15820084140337,76.76388883091039 ) ;
  }

  @Test
  public void test1055() {
    coral.tests.JPFBenchmark.benchmark02(-27.173944224784293,84.77429531053521 ) ;
  }

  @Test
  public void test1056() {
    coral.tests.JPFBenchmark.benchmark02(27.18535345316935,37.21729594520561 ) ;
  }

  @Test
  public void test1057() {
    coral.tests.JPFBenchmark.benchmark02(-2719.340587040642,0 ) ;
  }

  @Test
  public void test1058() {
    coral.tests.JPFBenchmark.benchmark02(2724.742252234703,0 ) ;
  }

  @Test
  public void test1059() {
    coral.tests.JPFBenchmark.benchmark02(-27.248228959266946,-1.5707963267948966 ) ;
  }

  @Test
  public void test1060() {
    coral.tests.JPFBenchmark.benchmark02(27.254053987941163,-100.0 ) ;
  }

  @Test
  public void test1061() {
    coral.tests.JPFBenchmark.benchmark02(27.27086887955157,0.0 ) ;
  }

  @Test
  public void test1062() {
    coral.tests.JPFBenchmark.benchmark02(-27.287966463891422,-1.5707963267948966 ) ;
  }

  @Test
  public void test1063() {
    coral.tests.JPFBenchmark.benchmark02(27.315111161077077,-138.4735672848142 ) ;
  }

  @Test
  public void test1064() {
    coral.tests.JPFBenchmark.benchmark02(-27.317554275442845,-77.24838980540157 ) ;
  }

  @Test
  public void test1065() {
    coral.tests.JPFBenchmark.benchmark02(27.323167573775336,1.5707963267948912 ) ;
  }

  @Test
  public void test1066() {
    coral.tests.JPFBenchmark.benchmark02(-27.363677177485226,0.0 ) ;
  }

  @Test
  public void test1067() {
    coral.tests.JPFBenchmark.benchmark02(27.663468084801362,-14.430149494757032 ) ;
  }

  @Test
  public void test1068() {
    coral.tests.JPFBenchmark.benchmark02(27.681220998797148,61.85416962839136 ) ;
  }

  @Test
  public void test1069() {
    coral.tests.JPFBenchmark.benchmark02(27.742879416796033,-32.849472003689854 ) ;
  }

  @Test
  public void test1070() {
    coral.tests.JPFBenchmark.benchmark02(-27.743121543170986,-48.16960026726071 ) ;
  }

  @Test
  public void test1071() {
    coral.tests.JPFBenchmark.benchmark02(-2.7755575615628914E-17,0 ) ;
  }

  @Test
  public void test1072() {
    coral.tests.JPFBenchmark.benchmark02(-2.7755575615628914E-17,0.0 ) ;
  }

  @Test
  public void test1073() {
    coral.tests.JPFBenchmark.benchmark02(2.7755575615628914E-17,-1.5707963267948983 ) ;
  }

  @Test
  public void test1074() {
    coral.tests.JPFBenchmark.benchmark02(-27.767672065477058,0 ) ;
  }

  @Test
  public void test1075() {
    coral.tests.JPFBenchmark.benchmark02(27.77839486062004,75.80331853779498 ) ;
  }

  @Test
  public void test1076() {
    coral.tests.JPFBenchmark.benchmark02(27.783993232200956,-64.36153758091352 ) ;
  }

  @Test
  public void test1077() {
    coral.tests.JPFBenchmark.benchmark02(27.813553621071378,65.8359047969306 ) ;
  }

  @Test
  public void test1078() {
    coral.tests.JPFBenchmark.benchmark02(27.819458836714148,-0.4147148345782155 ) ;
  }

  @Test
  public void test1079() {
    coral.tests.JPFBenchmark.benchmark02(27.83472017718732,38.83029446486211 ) ;
  }

  @Test
  public void test1080() {
    coral.tests.JPFBenchmark.benchmark02(27.878757227514583,44.51692094852587 ) ;
  }

  @Test
  public void test1081() {
    coral.tests.JPFBenchmark.benchmark02(27.93336927326755,89.19442601837463 ) ;
  }

  @Test
  public void test1082() {
    coral.tests.JPFBenchmark.benchmark02(27.93899918983931,-1.5707963267948968 ) ;
  }

  @Test
  public void test1083() {
    coral.tests.JPFBenchmark.benchmark02(-27.959667992956625,100.0 ) ;
  }

  @Test
  public void test1084() {
    coral.tests.JPFBenchmark.benchmark02(-2.7975902659686884,1.9147987145222247 ) ;
  }

  @Test
  public void test1085() {
    coral.tests.JPFBenchmark.benchmark02(-27.991036059231043,-18.99295022469107 ) ;
  }

  @Test
  public void test1086() {
    coral.tests.JPFBenchmark.benchmark02(27.99396707723075,-86.53659858190883 ) ;
  }

  @Test
  public void test1087() {
    coral.tests.JPFBenchmark.benchmark02(-28.01255227012416,66.89432482485509 ) ;
  }

  @Test
  public void test1088() {
    coral.tests.JPFBenchmark.benchmark02(-28.013247640501305,53.97170664239019 ) ;
  }

  @Test
  public void test1089() {
    coral.tests.JPFBenchmark.benchmark02(28.0320372429216,94.28983444002081 ) ;
  }

  @Test
  public void test1090() {
    coral.tests.JPFBenchmark.benchmark02(28.043815059533642,0 ) ;
  }

  @Test
  public void test1091() {
    coral.tests.JPFBenchmark.benchmark02(28.058421518948457,1.5707963267948948 ) ;
  }

  @Test
  public void test1092() {
    coral.tests.JPFBenchmark.benchmark02(28.06512550118597,4.921597361404629 ) ;
  }

  @Test
  public void test1093() {
    coral.tests.JPFBenchmark.benchmark02(-28.132286344959027,20.843320926914814 ) ;
  }

  @Test
  public void test1094() {
    coral.tests.JPFBenchmark.benchmark02(28.135009076763936,90.01410314397157 ) ;
  }

  @Test
  public void test1095() {
    coral.tests.JPFBenchmark.benchmark02(-28.13690587157113,-2576.1997847171656 ) ;
  }

  @Test
  public void test1096() {
    coral.tests.JPFBenchmark.benchmark02(-28.145674862945093,-4.937365187923124 ) ;
  }

  @Test
  public void test1097() {
    coral.tests.JPFBenchmark.benchmark02(-28.221032922896853,-38.13159630849859 ) ;
  }

  @Test
  public void test1098() {
    coral.tests.JPFBenchmark.benchmark02(-28.221832071635006,-1.5707963267948966 ) ;
  }

  @Test
  public void test1099() {
    coral.tests.JPFBenchmark.benchmark02(28.238791059851962,50.13006494385587 ) ;
  }

  @Test
  public void test1100() {
    coral.tests.JPFBenchmark.benchmark02(-28.240262639799802,-1.6332963393238444 ) ;
  }

  @Test
  public void test1101() {
    coral.tests.JPFBenchmark.benchmark02(-28.248555336503387,0 ) ;
  }

  @Test
  public void test1102() {
    coral.tests.JPFBenchmark.benchmark02(-28.265021737372393,16.89865516464797 ) ;
  }

  @Test
  public void test1103() {
    coral.tests.JPFBenchmark.benchmark02(28.26901300821241,1.5707963267948968 ) ;
  }

  @Test
  public void test1104() {
    coral.tests.JPFBenchmark.benchmark02(28.274327958882576,-76.96902001326985 ) ;
  }

  @Test
  public void test1105() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333826209286,-32.986721141865154 ) ;
  }

  @Test
  public void test1106() {
    coral.tests.JPFBenchmark.benchmark02(28.274333882218833,-1.5707963267948966 ) ;
  }

  @Test
  public void test1107() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882307,45.55309013924361 ) ;
  }

  @Test
  public void test1108() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882307644,1.5707963267948966 ) ;
  }

  @Test
  public void test1109() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308042,0.0 ) ;
  }

  @Test
  public void test1110() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308134,1.5707963267948912 ) ;
  }

  @Test
  public void test1111() {
    coral.tests.JPFBenchmark.benchmark02(-28.274333882308134,1.5707963267948966 ) ;
  }

  @Test
  public void test1112() {
    coral.tests.JPFBenchmark.benchmark02(28.27433412072686,-29.845130460137582 ) ;
  }

  @Test
  public void test1113() {
    coral.tests.JPFBenchmark.benchmark02(28.274334192177747,29.84513031844642 ) ;
  }

  @Test
  public void test1114() {
    coral.tests.JPFBenchmark.benchmark02(28.274339108956973,0.5483371708326464 ) ;
  }

  @Test
  public void test1115() {
    coral.tests.JPFBenchmark.benchmark02(28.274342834163615,0.5705056604195834 ) ;
  }

  @Test
  public void test1116() {
    coral.tests.JPFBenchmark.benchmark02(-28.27827986945692,4.716334967478203 ) ;
  }

  @Test
  public void test1117() {
    coral.tests.JPFBenchmark.benchmark02(28.279354768645447,94.20143417967697 ) ;
  }

  @Test
  public void test1118() {
    coral.tests.JPFBenchmark.benchmark02(-28.2849519181735,-1.5707963267948966 ) ;
  }

  @Test
  public void test1119() {
    coral.tests.JPFBenchmark.benchmark02(-28.318120718481563,39.07034512262204 ) ;
  }

  @Test
  public void test1120() {
    coral.tests.JPFBenchmark.benchmark02(28.347750585877804,0.4577989671301369 ) ;
  }

  @Test
  public void test1121() {
    coral.tests.JPFBenchmark.benchmark02(-28.389187729033182,0 ) ;
  }

  @Test
  public void test1122() {
    coral.tests.JPFBenchmark.benchmark02(28.396929793725604,-0.24225687676181595 ) ;
  }

  @Test
  public void test1123() {
    coral.tests.JPFBenchmark.benchmark02(28.40566858599226,15.612553558325558 ) ;
  }

  @Test
  public void test1124() {
    coral.tests.JPFBenchmark.benchmark02(28.474829782017906,0.0 ) ;
  }

  @Test
  public void test1125() {
    coral.tests.JPFBenchmark.benchmark02(28.569777907633764,-31.452905576055585 ) ;
  }

  @Test
  public void test1126() {
    coral.tests.JPFBenchmark.benchmark02(28.608375778457116,-69.08845996100243 ) ;
  }

  @Test
  public void test1127() {
    coral.tests.JPFBenchmark.benchmark02(28.609433781427235,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test1128() {
    coral.tests.JPFBenchmark.benchmark02(-28.69444277264181,-145.83909755048336 ) ;
  }

  @Test
  public void test1129() {
    coral.tests.JPFBenchmark.benchmark02(28.702085934386407,31.407833021758545 ) ;
  }

  @Test
  public void test1130() {
    coral.tests.JPFBenchmark.benchmark02(28.756292136331524,1.5707963267948948 ) ;
  }

  @Test
  public void test1131() {
    coral.tests.JPFBenchmark.benchmark02(-28.77326586118147,2667.7286026305433 ) ;
  }

  @Test
  public void test1132() {
    coral.tests.JPFBenchmark.benchmark02(28.775796440612794,39.537939411001474 ) ;
  }

  @Test
  public void test1133() {
    coral.tests.JPFBenchmark.benchmark02(28.905433450742898,-2.570813818290541 ) ;
  }

  @Test
  public void test1134() {
    coral.tests.JPFBenchmark.benchmark02(-2.8906426965105823,-2630.6584418146585 ) ;
  }

  @Test
  public void test1135() {
    coral.tests.JPFBenchmark.benchmark02(-28.94258541165484,6.323717952468179E-9 ) ;
  }

  @Test
  public void test1136() {
    coral.tests.JPFBenchmark.benchmark02(28.966166138822576,-1.5707963267948968 ) ;
  }

  @Test
  public void test1137() {
    coral.tests.JPFBenchmark.benchmark02(29.02187873477713,0.0 ) ;
  }

  @Test
  public void test1138() {
    coral.tests.JPFBenchmark.benchmark02(29.029819450098813,0.0 ) ;
  }

  @Test
  public void test1139() {
    coral.tests.JPFBenchmark.benchmark02(29.070778644828728,4.3874070551996477E-7 ) ;
  }

  @Test
  public void test1140() {
    coral.tests.JPFBenchmark.benchmark02(29.072240171813824,0.0 ) ;
  }

  @Test
  public void test1141() {
    coral.tests.JPFBenchmark.benchmark02(29.123315981034153,-28.564940469474266 ) ;
  }

  @Test
  public void test1142() {
    coral.tests.JPFBenchmark.benchmark02(29.16778504076441,1.5707963267948966 ) ;
  }

  @Test
  public void test1143() {
    coral.tests.JPFBenchmark.benchmark02(-29.169000923980875,-57.33037475794934 ) ;
  }

  @Test
  public void test1144() {
    coral.tests.JPFBenchmark.benchmark02(-29.18575760997644,-41.70098073272973 ) ;
  }

  @Test
  public void test1145() {
    coral.tests.JPFBenchmark.benchmark02(29.21787980461545,30.03606933709264 ) ;
  }

  @Test
  public void test1146() {
    coral.tests.JPFBenchmark.benchmark02(-29.23628335169255,0 ) ;
  }

  @Test
  public void test1147() {
    coral.tests.JPFBenchmark.benchmark02(-29.23629695365795,0.281733051966433 ) ;
  }

  @Test
  public void test1148() {
    coral.tests.JPFBenchmark.benchmark02(-29.276221856734196,-1.5707963267948966 ) ;
  }

  @Test
  public void test1149() {
    coral.tests.JPFBenchmark.benchmark02(29.358226887132986,60.61109383491629 ) ;
  }

  @Test
  public void test1150() {
    coral.tests.JPFBenchmark.benchmark02(29.425942013460514,0.23510835190909135 ) ;
  }

  @Test
  public void test1151() {
    coral.tests.JPFBenchmark.benchmark02(29.458266294161746,-38.08258680013943 ) ;
  }

  @Test
  public void test1152() {
    coral.tests.JPFBenchmark.benchmark02(29.47960019547986,-10.922277844734959 ) ;
  }

  @Test
  public void test1153() {
    coral.tests.JPFBenchmark.benchmark02(-29.492823930888235,-65.20159422160211 ) ;
  }

  @Test
  public void test1154() {
    coral.tests.JPFBenchmark.benchmark02(29.50965998213789,-65.19722791795053 ) ;
  }

  @Test
  public void test1155() {
    coral.tests.JPFBenchmark.benchmark02(-29.530135172195706,-1.5707963267948966 ) ;
  }

  @Test
  public void test1156() {
    coral.tests.JPFBenchmark.benchmark02(-29.531765169706553,31.729291575618813 ) ;
  }

  @Test
  public void test1157() {
    coral.tests.JPFBenchmark.benchmark02(-29.592446703375614,0.0 ) ;
  }

  @Test
  public void test1158() {
    coral.tests.JPFBenchmark.benchmark02(-29.641812753265366,-105.27580164644374 ) ;
  }

  @Test
  public void test1159() {
    coral.tests.JPFBenchmark.benchmark02(29.67777890173133,99.91514831374721 ) ;
  }

  @Test
  public void test1160() {
    coral.tests.JPFBenchmark.benchmark02(29.719135629390934,24.278053546744488 ) ;
  }

  @Test
  public void test1161() {
    coral.tests.JPFBenchmark.benchmark02(29.76203562278117,1.5707963267948966 ) ;
  }

  @Test
  public void test1162() {
    coral.tests.JPFBenchmark.benchmark02(-29.76518313248973,1.5707963267948966 ) ;
  }

  @Test
  public void test1163() {
    coral.tests.JPFBenchmark.benchmark02(-29.769153410339364,-0.001723479530943671 ) ;
  }

  @Test
  public void test1164() {
    coral.tests.JPFBenchmark.benchmark02(29.783254114475234,-0.13464199566187984 ) ;
  }

  @Test
  public void test1165() {
    coral.tests.JPFBenchmark.benchmark02(-29.784395981245027,5.419503685597185 ) ;
  }

  @Test
  public void test1166() {
    coral.tests.JPFBenchmark.benchmark02(-29.91838808612722,6.356443185569748 ) ;
  }

  @Test
  public void test1167() {
    coral.tests.JPFBenchmark.benchmark02(-29.93674700762074,-95.56845796730691 ) ;
  }

  @Test
  public void test1168() {
    coral.tests.JPFBenchmark.benchmark02(29.95341235063509,-68.69512018977525 ) ;
  }

  @Test
  public void test1169() {
    coral.tests.JPFBenchmark.benchmark02(-29.98209302178297,-131.14941789082593 ) ;
  }

  @Test
  public void test1170() {
    coral.tests.JPFBenchmark.benchmark02(-30.038662178381006,-57.26117296651312 ) ;
  }

  @Test
  public void test1171() {
    coral.tests.JPFBenchmark.benchmark02(-3.011659598192267,-95.53483965463072 ) ;
  }

  @Test
  public void test1172() {
    coral.tests.JPFBenchmark.benchmark02(-30.13878674606991,1.5707963267948966 ) ;
  }

  @Test
  public void test1173() {
    coral.tests.JPFBenchmark.benchmark02(30.29636513535408,2.690357727568066 ) ;
  }

  @Test
  public void test1174() {
    coral.tests.JPFBenchmark.benchmark02(-30.342054964081314,1.5707963267949197 ) ;
  }

  @Test
  public void test1175() {
    coral.tests.JPFBenchmark.benchmark02(-30.56456479642253,-1.5707963267948966 ) ;
  }

  @Test
  public void test1176() {
    coral.tests.JPFBenchmark.benchmark02(-30.632675587272587,62.25043162738925 ) ;
  }

  @Test
  public void test1177() {
    coral.tests.JPFBenchmark.benchmark02(-30.800428572706736,-60.57784687774053 ) ;
  }

  @Test
  public void test1178() {
    coral.tests.JPFBenchmark.benchmark02(-30.810421269264538,-57.661624953046854 ) ;
  }

  @Test
  public void test1179() {
    coral.tests.JPFBenchmark.benchmark02(-3.0814879110195774E-33,1.5707963267948966 ) ;
  }

  @Test
  public void test1180() {
    coral.tests.JPFBenchmark.benchmark02(-3.083736248340605,14.431538078414036 ) ;
  }

  @Test
  public void test1181() {
    coral.tests.JPFBenchmark.benchmark02(-30.917434457037714,0 ) ;
  }

  @Test
  public void test1182() {
    coral.tests.JPFBenchmark.benchmark02(30.9627942175984,0.17142880620589604 ) ;
  }

  @Test
  public void test1183() {
    coral.tests.JPFBenchmark.benchmark02(31.127468364550765,-27.37736332224398 ) ;
  }

  @Test
  public void test1184() {
    coral.tests.JPFBenchmark.benchmark02(-31.208775135295852,82.271191516339 ) ;
  }

  @Test
  public void test1185() {
    coral.tests.JPFBenchmark.benchmark02(3.1276746700613245,27.111844516897904 ) ;
  }

  @Test
  public void test1186() {
    coral.tests.JPFBenchmark.benchmark02(-31.339898934448698,-67.46656466330596 ) ;
  }

  @Test
  public void test1187() {
    coral.tests.JPFBenchmark.benchmark02(3.1355334984010597,56.977381252138144 ) ;
  }

  @Test
  public void test1188() {
    coral.tests.JPFBenchmark.benchmark02(3.1415926299567953,-73.82742735822066 ) ;
  }

  @Test
  public void test1189() {
    coral.tests.JPFBenchmark.benchmark02(31.41592653499265,-7.853981532245919 ) ;
  }

  @Test
  public void test1190() {
    coral.tests.JPFBenchmark.benchmark02(3.1415926535572862,-136.65925914205587 ) ;
  }

  @Test
  public void test1191() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535897873,51.83627876212069 ) ;
  }

  @Test
  public void test1192() {
    coral.tests.JPFBenchmark.benchmark02(-3.1415926535897927,-1.5707963267948966 ) ;
  }

  @Test
  public void test1193() {
    coral.tests.JPFBenchmark.benchmark02(3.1415926535897953,1.5707963267948974 ) ;
  }

  @Test
  public void test1194() {
    coral.tests.JPFBenchmark.benchmark02(3.141592713195901,1.5707963267948983 ) ;
  }

  @Test
  public void test1195() {
    coral.tests.JPFBenchmark.benchmark02(3.1415928920411957,1.5707963257903486 ) ;
  }

  @Test
  public void test1196() {
    coral.tests.JPFBenchmark.benchmark02(-3.1435458407016856,-23.561944901923894 ) ;
  }

  @Test
  public void test1197() {
    coral.tests.JPFBenchmark.benchmark02(-31.447176535897935,0.0 ) ;
  }

  @Test
  public void test1198() {
    coral.tests.JPFBenchmark.benchmark02(-31.447176536239517,1.5707963267948963 ) ;
  }

  @Test
  public void test1199() {
    coral.tests.JPFBenchmark.benchmark02(-31.447177100025428,-86.3957512483684 ) ;
  }

  @Test
  public void test1200() {
    coral.tests.JPFBenchmark.benchmark02(-31.507735976489396,14.429310824720282 ) ;
  }

  @Test
  public void test1201() {
    coral.tests.JPFBenchmark.benchmark02(31.51396124098656,87.8839075102214 ) ;
  }

  @Test
  public void test1202() {
    coral.tests.JPFBenchmark.benchmark02(31.53111025498859,-2622.621292303775 ) ;
  }

  @Test
  public void test1203() {
    coral.tests.JPFBenchmark.benchmark02(31.536727410809902,1.4499954519836606 ) ;
  }

  @Test
  public void test1204() {
    coral.tests.JPFBenchmark.benchmark02(-3.1572177354656517,-92.68998786191545 ) ;
  }

  @Test
  public void test1205() {
    coral.tests.JPFBenchmark.benchmark02(-31.652864482100085,1.5707963267948968 ) ;
  }

  @Test
  public void test1206() {
    coral.tests.JPFBenchmark.benchmark02(-3.1673247422008757,-83.25220532012952 ) ;
  }

  @Test
  public void test1207() {
    coral.tests.JPFBenchmark.benchmark02(31.705487587026738,-1.5707963267948966 ) ;
  }

  @Test
  public void test1208() {
    coral.tests.JPFBenchmark.benchmark02(31.74237298026631,0.0 ) ;
  }

  @Test
  public void test1209() {
    coral.tests.JPFBenchmark.benchmark02(31.778080165608117,1.5707963267948966 ) ;
  }

  @Test
  public void test1210() {
    coral.tests.JPFBenchmark.benchmark02(-31.78069170813642,-0.14650509447302246 ) ;
  }

  @Test
  public void test1211() {
    coral.tests.JPFBenchmark.benchmark02(31.826587983704513,-46.97003800186723 ) ;
  }

  @Test
  public void test1212() {
    coral.tests.JPFBenchmark.benchmark02(31.82893023955168,-45.28235453592924 ) ;
  }

  @Test
  public void test1213() {
    coral.tests.JPFBenchmark.benchmark02(31.8558254633912,-63.55360794807092 ) ;
  }

  @Test
  public void test1214() {
    coral.tests.JPFBenchmark.benchmark02(-31.891700630464157,-11.977750395016159 ) ;
  }

  @Test
  public void test1215() {
    coral.tests.JPFBenchmark.benchmark02(-31.901561236179937,168.08393630007987 ) ;
  }

  @Test
  public void test1216() {
    coral.tests.JPFBenchmark.benchmark02(31.923424461132925,90.56508103462846 ) ;
  }

  @Test
  public void test1217() {
    coral.tests.JPFBenchmark.benchmark02(31.93994760788792,1.5707971118818522 ) ;
  }

  @Test
  public void test1218() {
    coral.tests.JPFBenchmark.benchmark02(-31.99617432992609,73.40794030120657 ) ;
  }

  @Test
  public void test1219() {
    coral.tests.JPFBenchmark.benchmark02(32.07822077518827,-51.062801172208246 ) ;
  }

  @Test
  public void test1220() {
    coral.tests.JPFBenchmark.benchmark02(32.127285011925586,-0.3877803675657075 ) ;
  }

  @Test
  public void test1221() {
    coral.tests.JPFBenchmark.benchmark02(-32.13046516264814,0.0 ) ;
  }

  @Test
  public void test1222() {
    coral.tests.JPFBenchmark.benchmark02(32.145588672998336,0.0 ) ;
  }

  @Test
  public void test1223() {
    coral.tests.JPFBenchmark.benchmark02(-32.19772215629715,41.81568408263408 ) ;
  }

  @Test
  public void test1224() {
    coral.tests.JPFBenchmark.benchmark02(-32.25316314226538,-61.104913093821864 ) ;
  }

  @Test
  public void test1225() {
    coral.tests.JPFBenchmark.benchmark02(-32.41081230453075,-54.76486226402915 ) ;
  }

  @Test
  public void test1226() {
    coral.tests.JPFBenchmark.benchmark02(32.43266747021378,-46.65675307419039 ) ;
  }

  @Test
  public void test1227() {
    coral.tests.JPFBenchmark.benchmark02(32.453720762143746,-87.49477950350884 ) ;
  }

  @Test
  public void test1228() {
    coral.tests.JPFBenchmark.benchmark02(-32.45658102603153,1.5707963267948963 ) ;
  }

  @Test
  public void test1229() {
    coral.tests.JPFBenchmark.benchmark02(-32.56190895076216,-8.28410764583576 ) ;
  }

  @Test
  public void test1230() {
    coral.tests.JPFBenchmark.benchmark02(-32.63959979544508,-33.254895967846565 ) ;
  }

  @Test
  public void test1231() {
    coral.tests.JPFBenchmark.benchmark02(32.649385868278515,-18.318999464547133 ) ;
  }

  @Test
  public void test1232() {
    coral.tests.JPFBenchmark.benchmark02(-32.65376676630483,88.74444675332907 ) ;
  }

  @Test
  public void test1233() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926535897936,23.4370843576743 ) ;
  }

  @Test
  public void test1234() {
    coral.tests.JPFBenchmark.benchmark02(-3.266592653591021,51.71140945460426 ) ;
  }

  @Test
  public void test1235() {
    coral.tests.JPFBenchmark.benchmark02(-3.266592653621894,42.45122935413487 ) ;
  }

  @Test
  public void test1236() {
    coral.tests.JPFBenchmark.benchmark02(3.2665926536221472,10.870582053261138 ) ;
  }

  @Test
  public void test1237() {
    coral.tests.JPFBenchmark.benchmark02(-3.2665926564635313,-101.97824947302814 ) ;
  }

  @Test
  public void test1238() {
    coral.tests.JPFBenchmark.benchmark02(-3.2666145346024495,-17.403781475655734 ) ;
  }

  @Test
  public void test1239() {
    coral.tests.JPFBenchmark.benchmark02(-3.2667797583365914,-51.83143528618712 ) ;
  }

  @Test
  public void test1240() {
    coral.tests.JPFBenchmark.benchmark02(3.267552671895426,-4.6201179432210635 ) ;
  }

  @Test
  public void test1241() {
    coral.tests.JPFBenchmark.benchmark02(-32.752839678365056,78.77893643949739 ) ;
  }

  @Test
  public void test1242() {
    coral.tests.JPFBenchmark.benchmark02(32.77477606055274,-45.04536722235387 ) ;
  }

  @Test
  public void test1243() {
    coral.tests.JPFBenchmark.benchmark02(-32.80855227026372,-12.774174530933607 ) ;
  }

  @Test
  public void test1244() {
    coral.tests.JPFBenchmark.benchmark02(-32.80856071645878,-1.5707963267948966 ) ;
  }

  @Test
  public void test1245() {
    coral.tests.JPFBenchmark.benchmark02(3.288688893738271,-58.26334419293811 ) ;
  }

  @Test
  public void test1246() {
    coral.tests.JPFBenchmark.benchmark02(-3.2909404484989295,-23.765917556345002 ) ;
  }

  @Test
  public void test1247() {
    coral.tests.JPFBenchmark.benchmark02(32.946406387974356,93.49937332427038 ) ;
  }

  @Test
  public void test1248() {
    coral.tests.JPFBenchmark.benchmark02(32.950720714961335,31.802630637269445 ) ;
  }

  @Test
  public void test1249() {
    coral.tests.JPFBenchmark.benchmark02(-3.296532321021317,65.48997713913317 ) ;
  }

  @Test
  public void test1250() {
    coral.tests.JPFBenchmark.benchmark02(-3.3057904194943313,-17.44295736047808 ) ;
  }

  @Test
  public void test1251() {
    coral.tests.JPFBenchmark.benchmark02(-33.06684722571464,87.49716116689487 ) ;
  }

  @Test
  public void test1252() {
    coral.tests.JPFBenchmark.benchmark02(33.113257659188186,-31.54246133318563 ) ;
  }

  @Test
  public void test1253() {
    coral.tests.JPFBenchmark.benchmark02(33.32223383949259,-67.41661612138506 ) ;
  }

  @Test
  public void test1254() {
    coral.tests.JPFBenchmark.benchmark02(3.332990551092422,-47.55993641931535 ) ;
  }

  @Test
  public void test1255() {
    coral.tests.JPFBenchmark.benchmark02(33.36241715645,0.04543010927983721 ) ;
  }

  @Test
  public void test1256() {
    coral.tests.JPFBenchmark.benchmark02(33.63757777755379,2.550878414139509 ) ;
  }

  @Test
  public void test1257() {
    coral.tests.JPFBenchmark.benchmark02(33.71852487323369,2612.7969878297386 ) ;
  }

  @Test
  public void test1258() {
    coral.tests.JPFBenchmark.benchmark02(33.745998530308725,-1.5707963267948983 ) ;
  }

  @Test
  public void test1259() {
    coral.tests.JPFBenchmark.benchmark02(3.385168483736166,65.01571824373796 ) ;
  }

  @Test
  public void test1260() {
    coral.tests.JPFBenchmark.benchmark02(3.3881317890172014E-21,14.137167060370324 ) ;
  }

  @Test
  public void test1261() {
    coral.tests.JPFBenchmark.benchmark02(33.925837719637855,-1.5707963267948966 ) ;
  }

  @Test
  public void test1262() {
    coral.tests.JPFBenchmark.benchmark02(-3.394965610876482,42.471343570551824 ) ;
  }

  @Test
  public void test1263() {
    coral.tests.JPFBenchmark.benchmark02(-33.990942477283696,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1264() {
    coral.tests.JPFBenchmark.benchmark02(-34.047502372569646,-73.31741054232748 ) ;
  }

  @Test
  public void test1265() {
    coral.tests.JPFBenchmark.benchmark02(34.260656943301484,-1.5707963267948966 ) ;
  }

  @Test
  public void test1266() {
    coral.tests.JPFBenchmark.benchmark02(34.423938385334026,-2.030435437844 ) ;
  }

  @Test
  public void test1267() {
    coral.tests.JPFBenchmark.benchmark02(34.459078996651215,31.707341243660977 ) ;
  }

  @Test
  public void test1268() {
    coral.tests.JPFBenchmark.benchmark02(-34.53069723660148,0.0 ) ;
  }

  @Test
  public void test1269() {
    coral.tests.JPFBenchmark.benchmark02(34.5366271177002,4.743638980848797 ) ;
  }

  @Test
  public void test1270() {
    coral.tests.JPFBenchmark.benchmark02(-34.557467700327486,-0.5703511061283272 ) ;
  }

  @Test
  public void test1271() {
    coral.tests.JPFBenchmark.benchmark02(-34.557512923387534,0.0 ) ;
  }

  @Test
  public void test1272() {
    coral.tests.JPFBenchmark.benchmark02(-34.55751588858091,-1.570795726612407 ) ;
  }

  @Test
  public void test1273() {
    coral.tests.JPFBenchmark.benchmark02(-34.55751886450174,45.55309347702101 ) ;
  }

  @Test
  public void test1274() {
    coral.tests.JPFBenchmark.benchmark02(-34.557519189955855,1.570796326794903 ) ;
  }

  @Test
  public void test1275() {
    coral.tests.JPFBenchmark.benchmark02(-34.557519488055355,67.5441993584407 ) ;
  }

  @Test
  public void test1276() {
    coral.tests.JPFBenchmark.benchmark02(34.55849575441685,0.5623338954158675 ) ;
  }

  @Test
  public void test1277() {
    coral.tests.JPFBenchmark.benchmark02(34.55858459889934,-0.5707124364825061 ) ;
  }

  @Test
  public void test1278() {
    coral.tests.JPFBenchmark.benchmark02(-34.56360014373952,0.11764360100651633 ) ;
  }

  @Test
  public void test1279() {
    coral.tests.JPFBenchmark.benchmark02(34.58496594187724,34.86373026067312 ) ;
  }

  @Test
  public void test1280() {
    coral.tests.JPFBenchmark.benchmark02(34.60916169623912,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test1281() {
    coral.tests.JPFBenchmark.benchmark02(3.4637720833761563,0.0 ) ;
  }

  @Test
  public void test1282() {
    coral.tests.JPFBenchmark.benchmark02(-3.4648348933454844,50.659993432884136 ) ;
  }

  @Test
  public void test1283() {
    coral.tests.JPFBenchmark.benchmark02(34.64937594732419,-1.5707963267948983 ) ;
  }

  @Test
  public void test1284() {
    coral.tests.JPFBenchmark.benchmark02(-34.694736212889715,31.529323287528328 ) ;
  }

  @Test
  public void test1285() {
    coral.tests.JPFBenchmark.benchmark02(34.71771499755516,40.18838474508981 ) ;
  }

  @Test
  public void test1286() {
    coral.tests.JPFBenchmark.benchmark02(34.75212537448448,-0.35857609930825485 ) ;
  }

  @Test
  public void test1287() {
    coral.tests.JPFBenchmark.benchmark02(-35.14054403334568,-1.5707963267948664 ) ;
  }

  @Test
  public void test1288() {
    coral.tests.JPFBenchmark.benchmark02(-35.18625196277563,-40.785975157262435 ) ;
  }

  @Test
  public void test1289() {
    coral.tests.JPFBenchmark.benchmark02(35.227048958642456,-1.5707963267949054 ) ;
  }

  @Test
  public void test1290() {
    coral.tests.JPFBenchmark.benchmark02(35.28194187719213,-73.1030046715222 ) ;
  }

  @Test
  public void test1291() {
    coral.tests.JPFBenchmark.benchmark02(35.3255342611869,-100.0 ) ;
  }

  @Test
  public void test1292() {
    coral.tests.JPFBenchmark.benchmark02(-35.411346427920435,-10.260481063909737 ) ;
  }

  @Test
  public void test1293() {
    coral.tests.JPFBenchmark.benchmark02(35.45623018654757,-49.74464414860071 ) ;
  }

  @Test
  public void test1294() {
    coral.tests.JPFBenchmark.benchmark02(-35.46670551170446,15.77876676580484 ) ;
  }

  @Test
  public void test1295() {
    coral.tests.JPFBenchmark.benchmark02(-35.46733576042244,37.10342803786699 ) ;
  }

  @Test
  public void test1296() {
    coral.tests.JPFBenchmark.benchmark02(-35.51525457406942,-32.951619908212066 ) ;
  }

  @Test
  public void test1297() {
    coral.tests.JPFBenchmark.benchmark02(-3.552713678800501E-15,0.0 ) ;
  }

  @Test
  public void test1298() {
    coral.tests.JPFBenchmark.benchmark02(35.68589687768042,-107.28292219850866 ) ;
  }

  @Test
  public void test1299() {
    coral.tests.JPFBenchmark.benchmark02(-35.746758607134026,147.6412437558467 ) ;
  }

  @Test
  public void test1300() {
    coral.tests.JPFBenchmark.benchmark02(-35.79304845771493,-47.40509005939575 ) ;
  }

  @Test
  public void test1301() {
    coral.tests.JPFBenchmark.benchmark02(35.8204097129148,-3.6166847947880996 ) ;
  }

  @Test
  public void test1302() {
    coral.tests.JPFBenchmark.benchmark02(-35.96458996447715,0.0 ) ;
  }

  @Test
  public void test1303() {
    coral.tests.JPFBenchmark.benchmark02(-36.05758594156194,-10.816212096784351 ) ;
  }

  @Test
  public void test1304() {
    coral.tests.JPFBenchmark.benchmark02(36.06525617139768,-1.5707963267948966 ) ;
  }

  @Test
  public void test1305() {
    coral.tests.JPFBenchmark.benchmark02(-36.128315516279535,0.0 ) ;
  }

  @Test
  public void test1306() {
    coral.tests.JPFBenchmark.benchmark02(-36.128315516284076,0.0 ) ;
  }

  @Test
  public void test1307() {
    coral.tests.JPFBenchmark.benchmark02(-36.15107161210814,0.5707952568719269 ) ;
  }

  @Test
  public void test1308() {
    coral.tests.JPFBenchmark.benchmark02(36.183030278701125,1.5707963267948966 ) ;
  }

  @Test
  public void test1309() {
    coral.tests.JPFBenchmark.benchmark02(36.18492667122891,53.35046395784705 ) ;
  }

  @Test
  public void test1310() {
    coral.tests.JPFBenchmark.benchmark02(-3.6196511917459624,-53.682767907769446 ) ;
  }

  @Test
  public void test1311() {
    coral.tests.JPFBenchmark.benchmark02(-36.21040108630859,79.9800554448363 ) ;
  }

  @Test
  public void test1312() {
    coral.tests.JPFBenchmark.benchmark02(3.621488931213321,-7.095768520662547E-6 ) ;
  }

  @Test
  public void test1313() {
    coral.tests.JPFBenchmark.benchmark02(3.6337621781305582,1.5707963267948983 ) ;
  }

  @Test
  public void test1314() {
    coral.tests.JPFBenchmark.benchmark02(3.6381894883656978,4.215792145495047 ) ;
  }

  @Test
  public void test1315() {
    coral.tests.JPFBenchmark.benchmark02(-36.49763393230326,43.612978733959444 ) ;
  }

  @Test
  public void test1316() {
    coral.tests.JPFBenchmark.benchmark02(36.56101410319659,1.5707963267948948 ) ;
  }

  @Test
  public void test1317() {
    coral.tests.JPFBenchmark.benchmark02(36.58876901014579,-0.02938790907830935 ) ;
  }

  @Test
  public void test1318() {
    coral.tests.JPFBenchmark.benchmark02(36.711486261621786,-38.95397123635334 ) ;
  }

  @Test
  public void test1319() {
    coral.tests.JPFBenchmark.benchmark02(36.72517190101317,40.699772469966064 ) ;
  }

  @Test
  public void test1320() {
    coral.tests.JPFBenchmark.benchmark02(-3.6741630019064644,-0.47874647856857033 ) ;
  }

  @Test
  public void test1321() {
    coral.tests.JPFBenchmark.benchmark02(-36.744640205231136,-17.792535256331533 ) ;
  }

  @Test
  public void test1322() {
    coral.tests.JPFBenchmark.benchmark02(36.75173739077623,0.0 ) ;
  }

  @Test
  public void test1323() {
    coral.tests.JPFBenchmark.benchmark02(-36.75992136125402,5.651579462038821 ) ;
  }

  @Test
  public void test1324() {
    coral.tests.JPFBenchmark.benchmark02(36.827698014063174,0.0 ) ;
  }

  @Test
  public void test1325() {
    coral.tests.JPFBenchmark.benchmark02(36.87586500228889,71.628092335042 ) ;
  }

  @Test
  public void test1326() {
    coral.tests.JPFBenchmark.benchmark02(-3.6909893176710966,0 ) ;
  }

  @Test
  public void test1327() {
    coral.tests.JPFBenchmark.benchmark02(-36.94974032939971,-62.010428258542184 ) ;
  }

  @Test
  public void test1328() {
    coral.tests.JPFBenchmark.benchmark02(36.95913602045687,33.39111870821253 ) ;
  }

  @Test
  public void test1329() {
    coral.tests.JPFBenchmark.benchmark02(-36.95975550283723,0.0 ) ;
  }

  @Test
  public void test1330() {
    coral.tests.JPFBenchmark.benchmark02(-3.7014171217519163,58.540226099921966 ) ;
  }

  @Test
  public void test1331() {
    coral.tests.JPFBenchmark.benchmark02(-37.02454692855918,0.0 ) ;
  }

  @Test
  public void test1332() {
    coral.tests.JPFBenchmark.benchmark02(37.03591234120725,82.83059433306767 ) ;
  }

  @Test
  public void test1333() {
    coral.tests.JPFBenchmark.benchmark02(-37.112386234579276,-2.575535160975137 ) ;
  }

  @Test
  public void test1334() {
    coral.tests.JPFBenchmark.benchmark02(37.13101321187085,-129.8079964926511 ) ;
  }

  @Test
  public void test1335() {
    coral.tests.JPFBenchmark.benchmark02(-37.158422176955796,-50.85537082986084 ) ;
  }

  @Test
  public void test1336() {
    coral.tests.JPFBenchmark.benchmark02(-37.182077373793334,77.93138273128653 ) ;
  }

  @Test
  public void test1337() {
    coral.tests.JPFBenchmark.benchmark02(-37.2749222376463,0.9884277135187095 ) ;
  }

  @Test
  public void test1338() {
    coral.tests.JPFBenchmark.benchmark02(37.461354150908434,-65.41366763993464 ) ;
  }

  @Test
  public void test1339() {
    coral.tests.JPFBenchmark.benchmark02(37.51440057190288,-23.163661366541916 ) ;
  }

  @Test
  public void test1340() {
    coral.tests.JPFBenchmark.benchmark02(-37.52748273228985,1.5707963267948966 ) ;
  }

  @Test
  public void test1341() {
    coral.tests.JPFBenchmark.benchmark02(37.664719309698256,2.0707963670356744 ) ;
  }

  @Test
  public void test1342() {
    coral.tests.JPFBenchmark.benchmark02(37.680133487026225,1.5707963267948966 ) ;
  }

  @Test
  public void test1343() {
    coral.tests.JPFBenchmark.benchmark02(-37.699111843010655,-1.5707963267948966 ) ;
  }

  @Test
  public void test1344() {
    coral.tests.JPFBenchmark.benchmark02(37.69911184307751,-1.5707963267948963 ) ;
  }

  @Test
  public void test1345() {
    coral.tests.JPFBenchmark.benchmark02(37.69911184316953,1.5707963267948966 ) ;
  }

  @Test
  public void test1346() {
    coral.tests.JPFBenchmark.benchmark02(37.69917289172223,-83.25220938188433 ) ;
  }

  @Test
  public void test1347() {
    coral.tests.JPFBenchmark.benchmark02(-37.69917605614261,1.5707963267948966 ) ;
  }

  @Test
  public void test1348() {
    coral.tests.JPFBenchmark.benchmark02(-37.701064968077524,0.0 ) ;
  }

  @Test
  public void test1349() {
    coral.tests.JPFBenchmark.benchmark02(-37.714736843077524,-1.5707963267948966 ) ;
  }

  @Test
  public void test1350() {
    coral.tests.JPFBenchmark.benchmark02(-37.72354561983231,-1.5953319084491626 ) ;
  }

  @Test
  public void test1351() {
    coral.tests.JPFBenchmark.benchmark02(-37.74892291770773,7.122702612108938 ) ;
  }

  @Test
  public void test1352() {
    coral.tests.JPFBenchmark.benchmark02(37.75886474261053,1.5707963267948968 ) ;
  }

  @Test
  public void test1353() {
    coral.tests.JPFBenchmark.benchmark02(-37.765280854665995,70.71629965752963 ) ;
  }

  @Test
  public void test1354() {
    coral.tests.JPFBenchmark.benchmark02(-37.80128173933615,-22.29695600907303 ) ;
  }

  @Test
  public void test1355() {
    coral.tests.JPFBenchmark.benchmark02(-37.81681830505444,-0.3002597162018157 ) ;
  }

  @Test
  public void test1356() {
    coral.tests.JPFBenchmark.benchmark02(37.86051213758657,-85.33021381714173 ) ;
  }

  @Test
  public void test1357() {
    coral.tests.JPFBenchmark.benchmark02(37.903661837329906,1.5659282690448026 ) ;
  }

  @Test
  public void test1358() {
    coral.tests.JPFBenchmark.benchmark02(37.99116181183947,-1.3896470183782492 ) ;
  }

  @Test
  public void test1359() {
    coral.tests.JPFBenchmark.benchmark02(-38.07306295208785,-28.274333882308138 ) ;
  }

  @Test
  public void test1360() {
    coral.tests.JPFBenchmark.benchmark02(38.12743694644206,1.570796326794901 ) ;
  }

  @Test
  public void test1361() {
    coral.tests.JPFBenchmark.benchmark02(38.147413029864396,20.420352248333657 ) ;
  }

  @Test
  public void test1362() {
    coral.tests.JPFBenchmark.benchmark02(3.8149570617872257,94.21290622439818 ) ;
  }

  @Test
  public void test1363() {
    coral.tests.JPFBenchmark.benchmark02(38.165858583098654,55.92579056297809 ) ;
  }

  @Test
  public void test1364() {
    coral.tests.JPFBenchmark.benchmark02(-38.23660496346014,0.07073854401028536 ) ;
  }

  @Test
  public void test1365() {
    coral.tests.JPFBenchmark.benchmark02(38.24545768383979,74.2424862650208 ) ;
  }

  @Test
  public void test1366() {
    coral.tests.JPFBenchmark.benchmark02(-38.252523648949534,18.8314125901164 ) ;
  }

  @Test
  public void test1367() {
    coral.tests.JPFBenchmark.benchmark02(3.831283609912399,-4.022698023932458 ) ;
  }

  @Test
  public void test1368() {
    coral.tests.JPFBenchmark.benchmark02(-38.388300585010484,84.99536962345314 ) ;
  }

  @Test
  public void test1369() {
    coral.tests.JPFBenchmark.benchmark02(3.840354137738018,-14.72603587061603 ) ;
  }

  @Test
  public void test1370() {
    coral.tests.JPFBenchmark.benchmark02(-3.841882067531581E-18,-45.55309347705198 ) ;
  }

  @Test
  public void test1371() {
    coral.tests.JPFBenchmark.benchmark02(-38.43459593467158,-34.54608692846489 ) ;
  }

  @Test
  public void test1372() {
    coral.tests.JPFBenchmark.benchmark02(-38.454782938583975,-3.453597653099022 ) ;
  }

  @Test
  public void test1373() {
    coral.tests.JPFBenchmark.benchmark02(-38.481593955351556,-0.22107781034298987 ) ;
  }

  @Test
  public void test1374() {
    coral.tests.JPFBenchmark.benchmark02(38.503771381029566,-2680.0021128442236 ) ;
  }

  @Test
  public void test1375() {
    coral.tests.JPFBenchmark.benchmark02(3.856425546069404,8.72273072106698 ) ;
  }

  @Test
  public void test1376() {
    coral.tests.JPFBenchmark.benchmark02(38.60994881397186,0.0 ) ;
  }

  @Test
  public void test1377() {
    coral.tests.JPFBenchmark.benchmark02(-38.61886617847261,37.241631931565934 ) ;
  }

  @Test
  public void test1378() {
    coral.tests.JPFBenchmark.benchmark02(38.653828393084154,-4.814030962289095 ) ;
  }

  @Test
  public void test1379() {
    coral.tests.JPFBenchmark.benchmark02(-38.69423841070543,121.95805686780696 ) ;
  }

  @Test
  public void test1380() {
    coral.tests.JPFBenchmark.benchmark02(-38.69885484212898,-2655.5574939677795 ) ;
  }

  @Test
  public void test1381() {
    coral.tests.JPFBenchmark.benchmark02(38.699619487459614,89.36806324371659 ) ;
  }

  @Test
  public void test1382() {
    coral.tests.JPFBenchmark.benchmark02(-38.70037443573905,1.5707963267948966 ) ;
  }

  @Test
  public void test1383() {
    coral.tests.JPFBenchmark.benchmark02(38.74351542728954,17.278759594743864 ) ;
  }

  @Test
  public void test1384() {
    coral.tests.JPFBenchmark.benchmark02(-38.745398552183374,26.690143315871737 ) ;
  }

  @Test
  public void test1385() {
    coral.tests.JPFBenchmark.benchmark02(38.762134224610755,0.0 ) ;
  }

  @Test
  public void test1386() {
    coral.tests.JPFBenchmark.benchmark02(38.79567096233245,0.0 ) ;
  }

  @Test
  public void test1387() {
    coral.tests.JPFBenchmark.benchmark02(-38.83870965149292,-0.5707960526372943 ) ;
  }

  @Test
  public void test1388() {
    coral.tests.JPFBenchmark.benchmark02(38.84370017519555,0.0 ) ;
  }

  @Test
  public void test1389() {
    coral.tests.JPFBenchmark.benchmark02(-38.8903500755894,-60.069818512219186 ) ;
  }

  @Test
  public void test1390() {
    coral.tests.JPFBenchmark.benchmark02(-38.93348153997096,-9.614198335481944 ) ;
  }

  @Test
  public void test1391() {
    coral.tests.JPFBenchmark.benchmark02(-38.94198328927102,-2618.6258950973097 ) ;
  }

  @Test
  public void test1392() {
    coral.tests.JPFBenchmark.benchmark02(38.94452106158582,-2716.3809064241127 ) ;
  }

  @Test
  public void test1393() {
    coral.tests.JPFBenchmark.benchmark02(38.95289761783772,-0.5570397046044314 ) ;
  }

  @Test
  public void test1394() {
    coral.tests.JPFBenchmark.benchmark02(-38.96215348433978,0.0 ) ;
  }

  @Test
  public void test1395() {
    coral.tests.JPFBenchmark.benchmark02(-38.97114015953565,-6.72014935119298 ) ;
  }

  @Test
  public void test1396() {
    coral.tests.JPFBenchmark.benchmark02(38.99761172523996,7.22168468093966 ) ;
  }

  @Test
  public void test1397() {
    coral.tests.JPFBenchmark.benchmark02(-39.00182237859141,-51.475285503366926 ) ;
  }

  @Test
  public void test1398() {
    coral.tests.JPFBenchmark.benchmark02(-39.10285399349493,0.5706898528464507 ) ;
  }

  @Test
  public void test1399() {
    coral.tests.JPFBenchmark.benchmark02(-39.190106767845414,0.0 ) ;
  }

  @Test
  public void test1400() {
    coral.tests.JPFBenchmark.benchmark02(39.212578363523754,1.849209031888179E-13 ) ;
  }

  @Test
  public void test1401() {
    coral.tests.JPFBenchmark.benchmark02(-39.21371990228262,0 ) ;
  }

  @Test
  public void test1402() {
    coral.tests.JPFBenchmark.benchmark02(-39.22360464826836,11.939612726373277 ) ;
  }

  @Test
  public void test1403() {
    coral.tests.JPFBenchmark.benchmark02(39.226507692180306,-81.63800851333866 ) ;
  }

  @Test
  public void test1404() {
    coral.tests.JPFBenchmark.benchmark02(-39.22741890400642,-37.47830388704353 ) ;
  }

  @Test
  public void test1405() {
    coral.tests.JPFBenchmark.benchmark02(-39.2415518239385,-1.444419169434907E-8 ) ;
  }

  @Test
  public void test1406() {
    coral.tests.JPFBenchmark.benchmark02(39.26855253456768,-157.08098838725368 ) ;
  }

  @Test
  public void test1407() {
    coral.tests.JPFBenchmark.benchmark02(39.279018532038265,-17.349988015424998 ) ;
  }

  @Test
  public void test1408() {
    coral.tests.JPFBenchmark.benchmark02(39.320466311218674,-1.5707963267948966 ) ;
  }

  @Test
  public void test1409() {
    coral.tests.JPFBenchmark.benchmark02(-39.351355515987805,-1.5707963267948983 ) ;
  }

  @Test
  public void test1410() {
    coral.tests.JPFBenchmark.benchmark02(39.435395179736446,1.5707963267948966 ) ;
  }

  @Test
  public void test1411() {
    coral.tests.JPFBenchmark.benchmark02(3.9454899906973253,0.004481514480992272 ) ;
  }

  @Test
  public void test1412() {
    coral.tests.JPFBenchmark.benchmark02(39.5543069063275,0.0 ) ;
  }

  @Test
  public void test1413() {
    coral.tests.JPFBenchmark.benchmark02(39.70937487004511,-13.01376708548463 ) ;
  }

  @Test
  public void test1414() {
    coral.tests.JPFBenchmark.benchmark02(39.727961599361095,-98.05182016786405 ) ;
  }

  @Test
  public void test1415() {
    coral.tests.JPFBenchmark.benchmark02(3.9761581811328597,-0.029227961698274338 ) ;
  }

  @Test
  public void test1416() {
    coral.tests.JPFBenchmark.benchmark02(3.981954006287997,77.65110268953686 ) ;
  }

  @Test
  public void test1417() {
    coral.tests.JPFBenchmark.benchmark02(-39.83833121836379,-1.4971638396527054E-4 ) ;
  }

  @Test
  public void test1418() {
    coral.tests.JPFBenchmark.benchmark02(39.968936700284914,94.9468081382617 ) ;
  }

  @Test
  public void test1419() {
    coral.tests.JPFBenchmark.benchmark02(-40.01646519046393,-28.990025028502828 ) ;
  }

  @Test
  public void test1420() {
    coral.tests.JPFBenchmark.benchmark02(-40.05948161827284,2506.4767748970467 ) ;
  }

  @Test
  public void test1421() {
    coral.tests.JPFBenchmark.benchmark02(40.17911642289255,19.992995864447607 ) ;
  }

  @Test
  public void test1422() {
    coral.tests.JPFBenchmark.benchmark02(40.31545596613947,1.5707963267948968 ) ;
  }

  @Test
  public void test1423() {
    coral.tests.JPFBenchmark.benchmark02(40.33931346318216,-44.06458227397421 ) ;
  }

  @Test
  public void test1424() {
    coral.tests.JPFBenchmark.benchmark02(-40.35145007059635,-1.5707963267948968 ) ;
  }

  @Test
  public void test1425() {
    coral.tests.JPFBenchmark.benchmark02(40.361433974005045,-2586.4335099797154 ) ;
  }

  @Test
  public void test1426() {
    coral.tests.JPFBenchmark.benchmark02(-40.427744686214155,47.46386150151946 ) ;
  }

  @Test
  public void test1427() {
    coral.tests.JPFBenchmark.benchmark02(-4.04577178664881,0.14757562439017388 ) ;
  }

  @Test
  public void test1428() {
    coral.tests.JPFBenchmark.benchmark02(4.057994876519544,73.4894720248006 ) ;
  }

  @Test
  public void test1429() {
    coral.tests.JPFBenchmark.benchmark02(4.059024797973499,62.205733699230265 ) ;
  }

  @Test
  public void test1430() {
    coral.tests.JPFBenchmark.benchmark02(-40.61297181405787,72.89199402053075 ) ;
  }

  @Test
  public void test1431() {
    coral.tests.JPFBenchmark.benchmark02(4.061607725476354,-65.15383445250649 ) ;
  }

  @Test
  public void test1432() {
    coral.tests.JPFBenchmark.benchmark02(-40.62598647221516,0.0 ) ;
  }

  @Test
  public void test1433() {
    coral.tests.JPFBenchmark.benchmark02(40.641281497860206,-37.195865839166316 ) ;
  }

  @Test
  public void test1434() {
    coral.tests.JPFBenchmark.benchmark02(40.65153501069787,82.28346969982073 ) ;
  }

  @Test
  public void test1435() {
    coral.tests.JPFBenchmark.benchmark02(-40.66853844513176,58.49438467711516 ) ;
  }

  @Test
  public void test1436() {
    coral.tests.JPFBenchmark.benchmark02(40.68058348439124,95.29556359923589 ) ;
  }

  @Test
  public void test1437() {
    coral.tests.JPFBenchmark.benchmark02(-40.84026320091408,36.12831646995694 ) ;
  }

  @Test
  public void test1438() {
    coral.tests.JPFBenchmark.benchmark02(40.840703243745715,10.995573859528918 ) ;
  }

  @Test
  public void test1439() {
    coral.tests.JPFBenchmark.benchmark02(40.84070449656731,-1.5707963267948977 ) ;
  }

  @Test
  public void test1440() {
    coral.tests.JPFBenchmark.benchmark02(40.84070449656732,1.5707963267949039 ) ;
  }

  @Test
  public void test1441() {
    coral.tests.JPFBenchmark.benchmark02(40.840704496570226,1.5707963267948966 ) ;
  }

  @Test
  public void test1442() {
    coral.tests.JPFBenchmark.benchmark02(-40.8407044966673,-1.5707963267948963 ) ;
  }

  @Test
  public void test1443() {
    coral.tests.JPFBenchmark.benchmark02(40.84071975545638,1.5707963267948912 ) ;
  }

  @Test
  public void test1444() {
    coral.tests.JPFBenchmark.benchmark02(-40.844610746667314,-117.80648307859026 ) ;
  }

  @Test
  public void test1445() {
    coral.tests.JPFBenchmark.benchmark02(-40.845999332776515,45.33976908559208 ) ;
  }

  @Test
  public void test1446() {
    coral.tests.JPFBenchmark.benchmark02(40.87882829429071,86.39379797371932 ) ;
  }

  @Test
  public void test1447() {
    coral.tests.JPFBenchmark.benchmark02(40.96578048118071,89.28441772665282 ) ;
  }

  @Test
  public void test1448() {
    coral.tests.JPFBenchmark.benchmark02(-4.097131653647395,13.392345057065327 ) ;
  }

  @Test
  public void test1449() {
    coral.tests.JPFBenchmark.benchmark02(41.05604538115688,12.901899746409427 ) ;
  }

  @Test
  public void test1450() {
    coral.tests.JPFBenchmark.benchmark02(41.0724595305175,-44.725283900861434 ) ;
  }

  @Test
  public void test1451() {
    coral.tests.JPFBenchmark.benchmark02(-41.08958827106546,2.298394409198877E-7 ) ;
  }

  @Test
  public void test1452() {
    coral.tests.JPFBenchmark.benchmark02(-41.15953220734872,1.5707963267948983 ) ;
  }

  @Test
  public void test1453() {
    coral.tests.JPFBenchmark.benchmark02(-41.203455165351336,100.0 ) ;
  }

  @Test
  public void test1454() {
    coral.tests.JPFBenchmark.benchmark02(-41.225464656554145,1.270015488452402 ) ;
  }

  @Test
  public void test1455() {
    coral.tests.JPFBenchmark.benchmark02(-41.24403947992536,-1.5707963267948983 ) ;
  }

  @Test
  public void test1456() {
    coral.tests.JPFBenchmark.benchmark02(-41.26123623419562,72.02597539890866 ) ;
  }

  @Test
  public void test1457() {
    coral.tests.JPFBenchmark.benchmark02(4.127334695871426,49.12270855740496 ) ;
  }

  @Test
  public void test1458() {
    coral.tests.JPFBenchmark.benchmark02(-41.29929934698594,0.0 ) ;
  }

  @Test
  public void test1459() {
    coral.tests.JPFBenchmark.benchmark02(-41.34954306556777,-32.32439986008116 ) ;
  }

  @Test
  public void test1460() {
    coral.tests.JPFBenchmark.benchmark02(4.141592651276208,-9.995574287515941 ) ;
  }

  @Test
  public void test1461() {
    coral.tests.JPFBenchmark.benchmark02(-4.141592653589794,-137.32142842843595 ) ;
  }

  @Test
  public void test1462() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589794,-91.76021813397328 ) ;
  }

  @Test
  public void test1463() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653589795,4.623420676133703 ) ;
  }

  @Test
  public void test1464() {
    coral.tests.JPFBenchmark.benchmark02(-4.1415926535897984,-48.868502287587084 ) ;
  }

  @Test
  public void test1465() {
    coral.tests.JPFBenchmark.benchmark02(-4.141592653590225,-51.116503347241554 ) ;
  }

  @Test
  public void test1466() {
    coral.tests.JPFBenchmark.benchmark02(-4.141592653593646,-164.49991436512593 ) ;
  }

  @Test
  public void test1467() {
    coral.tests.JPFBenchmark.benchmark02(-4.1415926536475745,158.29657950267517 ) ;
  }

  @Test
  public void test1468() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653689679,-46.50463047797949 ) ;
  }

  @Test
  public void test1469() {
    coral.tests.JPFBenchmark.benchmark02(4.141592653746721,-52.695140777308474 ) ;
  }

  @Test
  public void test1470() {
    coral.tests.JPFBenchmark.benchmark02(4.141593141618861,23.329484240148922 ) ;
  }

  @Test
  public void test1471() {
    coral.tests.JPFBenchmark.benchmark02(-41.45076854793959,136.42285875181113 ) ;
  }

  @Test
  public void test1472() {
    coral.tests.JPFBenchmark.benchmark02(-4.146117245607958,70.31808874974993 ) ;
  }

  @Test
  public void test1473() {
    coral.tests.JPFBenchmark.benchmark02(41.521361386470716,-1.5707963267948966 ) ;
  }

  @Test
  public void test1474() {
    coral.tests.JPFBenchmark.benchmark02(-41.530892339755795,-0.3783164436836298 ) ;
  }

  @Test
  public void test1475() {
    coral.tests.JPFBenchmark.benchmark02(4.153446990790327,217.3288350871015 ) ;
  }

  @Test
  public void test1476() {
    coral.tests.JPFBenchmark.benchmark02(-41.54657746393717,-5.92530883264935 ) ;
  }

  @Test
  public void test1477() {
    coral.tests.JPFBenchmark.benchmark02(-4.155471602177283,-38.256029221474115 ) ;
  }

  @Test
  public void test1478() {
    coral.tests.JPFBenchmark.benchmark02(4.157479275418183,37.88745092531871 ) ;
  }

  @Test
  public void test1479() {
    coral.tests.JPFBenchmark.benchmark02(-41.60072506527903,0.3220126222745599 ) ;
  }

  @Test
  public void test1480() {
    coral.tests.JPFBenchmark.benchmark02(-41.618803166008284,-24.97713535630652 ) ;
  }

  @Test
  public void test1481() {
    coral.tests.JPFBenchmark.benchmark02(41.66997833692102,-72.2397360816226 ) ;
  }

  @Test
  public void test1482() {
    coral.tests.JPFBenchmark.benchmark02(-41.69097033760245,-26.716976954906634 ) ;
  }

  @Test
  public void test1483() {
    coral.tests.JPFBenchmark.benchmark02(4.169770684253384,-1.5707963267948966 ) ;
  }

  @Test
  public void test1484() {
    coral.tests.JPFBenchmark.benchmark02(-4.177783536072527,99.99635947036491 ) ;
  }

  @Test
  public void test1485() {
    coral.tests.JPFBenchmark.benchmark02(41.80143173560715,-72.26857821216171 ) ;
  }

  @Test
  public void test1486() {
    coral.tests.JPFBenchmark.benchmark02(-4.1810059152237615,99.99958184951511 ) ;
  }

  @Test
  public void test1487() {
    coral.tests.JPFBenchmark.benchmark02(41.86504049749519,-81.81781296798269 ) ;
  }

  @Test
  public void test1488() {
    coral.tests.JPFBenchmark.benchmark02(-41.886317620762654,0 ) ;
  }

  @Test
  public void test1489() {
    coral.tests.JPFBenchmark.benchmark02(41.94746069690103,0.0 ) ;
  }

  @Test
  public void test1490() {
    coral.tests.JPFBenchmark.benchmark02(42.00734681502212,3.1497633081607113 ) ;
  }

  @Test
  public void test1491() {
    coral.tests.JPFBenchmark.benchmark02(42.02607925509337,1.5707963267948966 ) ;
  }

  @Test
  public void test1492() {
    coral.tests.JPFBenchmark.benchmark02(42.052743594884845,1.5707963267948966 ) ;
  }

  @Test
  public void test1493() {
    coral.tests.JPFBenchmark.benchmark02(42.07540316782172,-54.37025025032116 ) ;
  }

  @Test
  public void test1494() {
    coral.tests.JPFBenchmark.benchmark02(-4.208814377481718,-18.34598131842856 ) ;
  }

  @Test
  public void test1495() {
    coral.tests.JPFBenchmark.benchmark02(42.09592170903247,-0.2940063038204804 ) ;
  }

  @Test
  public void test1496() {
    coral.tests.JPFBenchmark.benchmark02(-42.11101120164068,0.0 ) ;
  }

  @Test
  public void test1497() {
    coral.tests.JPFBenchmark.benchmark02(-42.147719905600184,-44.24607806850266 ) ;
  }

  @Test
  public void test1498() {
    coral.tests.JPFBenchmark.benchmark02(-4.219675813882901,61.206974181802934 ) ;
  }

  @Test
  public void test1499() {
    coral.tests.JPFBenchmark.benchmark02(-42.26746639717276,-44.275869210878305 ) ;
  }

  @Test
  public void test1500() {
    coral.tests.JPFBenchmark.benchmark02(-42.27045079170214,83.25220532012952 ) ;
  }

  @Test
  public void test1501() {
    coral.tests.JPFBenchmark.benchmark02(-42.32233980826818,-180.9042998710348 ) ;
  }

  @Test
  public void test1502() {
    coral.tests.JPFBenchmark.benchmark02(-42.3854692089784,0.4999999994648468 ) ;
  }

  @Test
  public void test1503() {
    coral.tests.JPFBenchmark.benchmark02(-42.39665069223837,6.544004980900152 ) ;
  }

  @Test
  public void test1504() {
    coral.tests.JPFBenchmark.benchmark02(-42.47092414102938,-136.6015254317408 ) ;
  }

  @Test
  public void test1505() {
    coral.tests.JPFBenchmark.benchmark02(42.54593260892695,0.364828174901168 ) ;
  }

  @Test
  public void test1506() {
    coral.tests.JPFBenchmark.benchmark02(-42.55601024741862,-44.12680657490788 ) ;
  }

  @Test
  public void test1507() {
    coral.tests.JPFBenchmark.benchmark02(-42.564439024189035,-226.3600392512063 ) ;
  }

  @Test
  public void test1508() {
    coral.tests.JPFBenchmark.benchmark02(-42.594572781924796,73.44767247032937 ) ;
  }

  @Test
  public void test1509() {
    coral.tests.JPFBenchmark.benchmark02(42.621796009440885,0.00854552928061432 ) ;
  }

  @Test
  public void test1510() {
    coral.tests.JPFBenchmark.benchmark02(42.63621532957646,1.2564619705919151 ) ;
  }

  @Test
  public void test1511() {
    coral.tests.JPFBenchmark.benchmark02(-42.637737622181774,-1.5707963267948963 ) ;
  }

  @Test
  public void test1512() {
    coral.tests.JPFBenchmark.benchmark02(-42.6482561262001,-115.33074738543712 ) ;
  }

  @Test
  public void test1513() {
    coral.tests.JPFBenchmark.benchmark02(42.65485856524937,0.0 ) ;
  }

  @Test
  public void test1514() {
    coral.tests.JPFBenchmark.benchmark02(-42.658047054715404,-16.313056219734264 ) ;
  }

  @Test
  public void test1515() {
    coral.tests.JPFBenchmark.benchmark02(42.660746242578114,89.07208033675113 ) ;
  }

  @Test
  public void test1516() {
    coral.tests.JPFBenchmark.benchmark02(-42.71432501979498,1.5707963267948966 ) ;
  }

  @Test
  public void test1517() {
    coral.tests.JPFBenchmark.benchmark02(-42.7384378366541,-42.146147260540445 ) ;
  }

  @Test
  public void test1518() {
    coral.tests.JPFBenchmark.benchmark02(42.76434787718267,36.93050745421971 ) ;
  }

  @Test
  public void test1519() {
    coral.tests.JPFBenchmark.benchmark02(-42.80039836352705,-86.97611286730992 ) ;
  }

  @Test
  public void test1520() {
    coral.tests.JPFBenchmark.benchmark02(42.828552204503524,38.14314240498774 ) ;
  }

  @Test
  public void test1521() {
    coral.tests.JPFBenchmark.benchmark02(-42.82999554594697,-2393.149594100181 ) ;
  }

  @Test
  public void test1522() {
    coral.tests.JPFBenchmark.benchmark02(-42.83732960090752,95.81857593448869 ) ;
  }

  @Test
  public void test1523() {
    coral.tests.JPFBenchmark.benchmark02(42.85539393203808,0.0 ) ;
  }

  @Test
  public void test1524() {
    coral.tests.JPFBenchmark.benchmark02(-42.866552563296594,71.47680801643418 ) ;
  }

  @Test
  public void test1525() {
    coral.tests.JPFBenchmark.benchmark02(-42.86723768716406,72.74785879197488 ) ;
  }

  @Test
  public void test1526() {
    coral.tests.JPFBenchmark.benchmark02(-42.879713177136395,0.0 ) ;
  }

  @Test
  public void test1527() {
    coral.tests.JPFBenchmark.benchmark02(42.88133051751454,66.05473565736732 ) ;
  }

  @Test
  public void test1528() {
    coral.tests.JPFBenchmark.benchmark02(-42.889520608552914,2219.119755342166 ) ;
  }

  @Test
  public void test1529() {
    coral.tests.JPFBenchmark.benchmark02(-42.897472614258106,1.5707963267948966 ) ;
  }

  @Test
  public void test1530() {
    coral.tests.JPFBenchmark.benchmark02(42.90743791679339,73.4287568680495 ) ;
  }

  @Test
  public void test1531() {
    coral.tests.JPFBenchmark.benchmark02(-42.95263637342257,0.0 ) ;
  }

  @Test
  public void test1532() {
    coral.tests.JPFBenchmark.benchmark02(-42.96027376840905,-20.00006730537234 ) ;
  }

  @Test
  public void test1533() {
    coral.tests.JPFBenchmark.benchmark02(-42.98599792510067,1.5707963267948966 ) ;
  }

  @Test
  public void test1534() {
    coral.tests.JPFBenchmark.benchmark02(42.993202311883806,0 ) ;
  }

  @Test
  public void test1535() {
    coral.tests.JPFBenchmark.benchmark02(-43.03613671182255,-13.893442575130521 ) ;
  }

  @Test
  public void test1536() {
    coral.tests.JPFBenchmark.benchmark02(43.064963208145315,1.5707963267948968 ) ;
  }

  @Test
  public void test1537() {
    coral.tests.JPFBenchmark.benchmark02(-43.157300733980186,71.3511949869876 ) ;
  }

  @Test
  public void test1538() {
    coral.tests.JPFBenchmark.benchmark02(-43.18943126483238,100.0 ) ;
  }

  @Test
  public void test1539() {
    coral.tests.JPFBenchmark.benchmark02(43.253538990078766,6.19125662294438 ) ;
  }

  @Test
  public void test1540() {
    coral.tests.JPFBenchmark.benchmark02(43.277165932504595,-60.26692540223719 ) ;
  }

  @Test
  public void test1541() {
    coral.tests.JPFBenchmark.benchmark02(-43.34336385373727,11.325082111018148 ) ;
  }

  @Test
  public void test1542() {
    coral.tests.JPFBenchmark.benchmark02(-43.358198986728944,1.5707963267948968 ) ;
  }

  @Test
  public void test1543() {
    coral.tests.JPFBenchmark.benchmark02(4.3368086899420177E-19,54.97787143772225 ) ;
  }

  @Test
  public void test1544() {
    coral.tests.JPFBenchmark.benchmark02(-4.3368086899420177E-19,-67.54529753494619 ) ;
  }

  @Test
  public void test1545() {
    coral.tests.JPFBenchmark.benchmark02(43.412085754049485,-57.0783465531973 ) ;
  }

  @Test
  public void test1546() {
    coral.tests.JPFBenchmark.benchmark02(43.474468675242036,97.96683259877211 ) ;
  }

  @Test
  public void test1547() {
    coral.tests.JPFBenchmark.benchmark02(43.48482519064004,0.0 ) ;
  }

  @Test
  public void test1548() {
    coral.tests.JPFBenchmark.benchmark02(-43.775593305708746,-7.979592286551721 ) ;
  }

  @Test
  public void test1549() {
    coral.tests.JPFBenchmark.benchmark02(-43.858087326786645,-100.0 ) ;
  }

  @Test
  public void test1550() {
    coral.tests.JPFBenchmark.benchmark02(43.858716197782854,-62.26485738423655 ) ;
  }

  @Test
  public void test1551() {
    coral.tests.JPFBenchmark.benchmark02(43.89384257138596,-2.0707963486949263 ) ;
  }

  @Test
  public void test1552() {
    coral.tests.JPFBenchmark.benchmark02(43.982222558245375,0.5697117940729505 ) ;
  }

  @Test
  public void test1553() {
    coral.tests.JPFBenchmark.benchmark02(43.9822598460168,-45.55309347689342 ) ;
  }

  @Test
  public void test1554() {
    coral.tests.JPFBenchmark.benchmark02(-43.982297147583736,-117.80916146275612 ) ;
  }

  @Test
  public void test1555() {
    coral.tests.JPFBenchmark.benchmark02(-43.98229715025714,1.5707963267948963 ) ;
  }

  @Test
  public void test1556() {
    coral.tests.JPFBenchmark.benchmark02(43.98229836010735,70.6858347594011 ) ;
  }

  @Test
  public void test1557() {
    coral.tests.JPFBenchmark.benchmark02(-43.98230160289189,0.5614366635905311 ) ;
  }

  @Test
  public void test1558() {
    coral.tests.JPFBenchmark.benchmark02(43.98230504700011,-10.99557344425911 ) ;
  }

  @Test
  public void test1559() {
    coral.tests.JPFBenchmark.benchmark02(43.9904865979874,-32.98673812148926 ) ;
  }

  @Test
  public void test1560() {
    coral.tests.JPFBenchmark.benchmark02(44.01562846214107,88.44938286982678 ) ;
  }

  @Test
  public void test1561() {
    coral.tests.JPFBenchmark.benchmark02(44.03004063048493,5.4261675862850726E-5 ) ;
  }

  @Test
  public void test1562() {
    coral.tests.JPFBenchmark.benchmark02(-44.04362371052963,-0.9154849928874733 ) ;
  }

  @Test
  public void test1563() {
    coral.tests.JPFBenchmark.benchmark02(-44.04637982170408,-0.7636746068093515 ) ;
  }

  @Test
  public void test1564() {
    coral.tests.JPFBenchmark.benchmark02(44.06076043454166,-63.8894876482634 ) ;
  }

  @Test
  public void test1565() {
    coral.tests.JPFBenchmark.benchmark02(-44.074295175180886,-53.68689615981248 ) ;
  }

  @Test
  public void test1566() {
    coral.tests.JPFBenchmark.benchmark02(-44.090902272581324,6.123234069246633E-17 ) ;
  }

  @Test
  public void test1567() {
    coral.tests.JPFBenchmark.benchmark02(44.1356560008549,61.41596557710871 ) ;
  }

  @Test
  public void test1568() {
    coral.tests.JPFBenchmark.benchmark02(44.24836916388638,29.432164638463576 ) ;
  }

  @Test
  public void test1569() {
    coral.tests.JPFBenchmark.benchmark02(44.257198452414364,-0.03893667124496563 ) ;
  }

  @Test
  public void test1570() {
    coral.tests.JPFBenchmark.benchmark02(-44.32978546405546,-47.44983381640531 ) ;
  }

  @Test
  public void test1571() {
    coral.tests.JPFBenchmark.benchmark02(-44.39187465539523,-103.02486815111922 ) ;
  }

  @Test
  public void test1572() {
    coral.tests.JPFBenchmark.benchmark02(-44.40109220766313,10.576779230048789 ) ;
  }

  @Test
  public void test1573() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,0.0 ) ;
  }

  @Test
  public void test1574() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,-1.5707963267948966 ) ;
  }

  @Test
  public void test1575() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,2618.2289444886983 ) ;
  }

  @Test
  public void test1576() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,33.93563392117741 ) ;
  }

  @Test
  public void test1577() {
    coral.tests.JPFBenchmark.benchmark02(-4.440892098500626E-16,-35.437233889632154 ) ;
  }

  @Test
  public void test1578() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,-35.94151504806022 ) ;
  }

  @Test
  public void test1579() {
    coral.tests.JPFBenchmark.benchmark02(4.440892098500626E-16,44.426775821450626 ) ;
  }

  @Test
  public void test1580() {
    coral.tests.JPFBenchmark.benchmark02(-44.40907494485526,77.52049747508474 ) ;
  }

  @Test
  public void test1581() {
    coral.tests.JPFBenchmark.benchmark02(44.47246949943029,1.5707963267948966 ) ;
  }

  @Test
  public void test1582() {
    coral.tests.JPFBenchmark.benchmark02(44.48480055754861,-95.31607252731129 ) ;
  }

  @Test
  public void test1583() {
    coral.tests.JPFBenchmark.benchmark02(-44.485759209331334,0.0 ) ;
  }

  @Test
  public void test1584() {
    coral.tests.JPFBenchmark.benchmark02(44.53807700164911,32.43094301141854 ) ;
  }

  @Test
  public void test1585() {
    coral.tests.JPFBenchmark.benchmark02(-44.54198734308745,30.444717312110242 ) ;
  }

  @Test
  public void test1586() {
    coral.tests.JPFBenchmark.benchmark02(44.572759530693986,-1.5707963267948972 ) ;
  }

  @Test
  public void test1587() {
    coral.tests.JPFBenchmark.benchmark02(44.74090496764094,-20.184271620922498 ) ;
  }

  @Test
  public void test1588() {
    coral.tests.JPFBenchmark.benchmark02(44.77651661644949,-14.853008386080162 ) ;
  }

  @Test
  public void test1589() {
    coral.tests.JPFBenchmark.benchmark02(44.91253624730473,14.429223356842115 ) ;
  }

  @Test
  public void test1590() {
    coral.tests.JPFBenchmark.benchmark02(-4.493535784859944,36.12832241642313 ) ;
  }

  @Test
  public void test1591() {
    coral.tests.JPFBenchmark.benchmark02(44.99561452559854,46.792911032148055 ) ;
  }

  @Test
  public void test1592() {
    coral.tests.JPFBenchmark.benchmark02(-45.0061408885615,90.88309010752656 ) ;
  }

  @Test
  public void test1593() {
    coral.tests.JPFBenchmark.benchmark02(45.11022577624944,-0.49996984992224475 ) ;
  }

  @Test
  public void test1594() {
    coral.tests.JPFBenchmark.benchmark02(-45.1790945842325,32.44991914857467 ) ;
  }

  @Test
  public void test1595() {
    coral.tests.JPFBenchmark.benchmark02(45.18487859706385,-88.48888833739834 ) ;
  }

  @Test
  public void test1596() {
    coral.tests.JPFBenchmark.benchmark02(45.231490929691155,0.0 ) ;
  }

  @Test
  public void test1597() {
    coral.tests.JPFBenchmark.benchmark02(-45.2473276876423,16.008126078521997 ) ;
  }

  @Test
  public void test1598() {
    coral.tests.JPFBenchmark.benchmark02(45.26794371237596,-1.5707963267948966 ) ;
  }

  @Test
  public void test1599() {
    coral.tests.JPFBenchmark.benchmark02(-45.34253604156472,24.753991567067075 ) ;
  }

  @Test
  public void test1600() {
    coral.tests.JPFBenchmark.benchmark02(45.35192763075774,38.095797865244116 ) ;
  }

  @Test
  public void test1601() {
    coral.tests.JPFBenchmark.benchmark02(-45.37683370266914,79.30252109097401 ) ;
  }

  @Test
  public void test1602() {
    coral.tests.JPFBenchmark.benchmark02(-45.41227397848381,1.0180488642898808 ) ;
  }

  @Test
  public void test1603() {
    coral.tests.JPFBenchmark.benchmark02(45.43049495217204,88.3972901594622 ) ;
  }

  @Test
  public void test1604() {
    coral.tests.JPFBenchmark.benchmark02(45.46247978374125,25.648507215852263 ) ;
  }

  @Test
  public void test1605() {
    coral.tests.JPFBenchmark.benchmark02(45.48666146243396,1.5707963267948983 ) ;
  }

  @Test
  public void test1606() {
    coral.tests.JPFBenchmark.benchmark02(-45.487698736632666,-0.028997721457079288 ) ;
  }

  @Test
  public void test1607() {
    coral.tests.JPFBenchmark.benchmark02(-45.502310585125905,-36.82960278939926 ) ;
  }

  @Test
  public void test1608() {
    coral.tests.JPFBenchmark.benchmark02(45.553093477047035,0.0 ) ;
  }

  @Test
  public void test1609() {
    coral.tests.JPFBenchmark.benchmark02(45.62581805684804,90.58072024560428 ) ;
  }

  @Test
  public void test1610() {
    coral.tests.JPFBenchmark.benchmark02(-45.63511906953619,1.5707963267948968 ) ;
  }

  @Test
  public void test1611() {
    coral.tests.JPFBenchmark.benchmark02(45.65509478137702,-98.55784209609419 ) ;
  }

  @Test
  public void test1612() {
    coral.tests.JPFBenchmark.benchmark02(45.665855045256365,18.721128555121613 ) ;
  }

  @Test
  public void test1613() {
    coral.tests.JPFBenchmark.benchmark02(45.71066339785372,-83.80503159351716 ) ;
  }

  @Test
  public void test1614() {
    coral.tests.JPFBenchmark.benchmark02(45.77580506897422,0 ) ;
  }

  @Test
  public void test1615() {
    coral.tests.JPFBenchmark.benchmark02(45.85416218479824,-32.61864708151106 ) ;
  }

  @Test
  public void test1616() {
    coral.tests.JPFBenchmark.benchmark02(-45.85948119187479,-70.866517920895 ) ;
  }

  @Test
  public void test1617() {
    coral.tests.JPFBenchmark.benchmark02(45.90383516012139,5.7920756850184745 ) ;
  }

  @Test
  public void test1618() {
    coral.tests.JPFBenchmark.benchmark02(-45.912221196937374,41.199832216268156 ) ;
  }

  @Test
  public void test1619() {
    coral.tests.JPFBenchmark.benchmark02(45.98150800343279,2.5538325591806306 ) ;
  }

  @Test
  public void test1620() {
    coral.tests.JPFBenchmark.benchmark02(46.50804126365563,2633.1664065729187 ) ;
  }

  @Test
  public void test1621() {
    coral.tests.JPFBenchmark.benchmark02(46.61370459529142,-60.549993345425555 ) ;
  }

  @Test
  public void test1622() {
    coral.tests.JPFBenchmark.benchmark02(46.63530502722581,5.392621697727392 ) ;
  }

  @Test
  public void test1623() {
    coral.tests.JPFBenchmark.benchmark02(-4.685263385424278E-8,-42.41150463834005 ) ;
  }

  @Test
  public void test1624() {
    coral.tests.JPFBenchmark.benchmark02(-46.923739611613286,-40.857469678078466 ) ;
  }

  @Test
  public void test1625() {
    coral.tests.JPFBenchmark.benchmark02(-46.95297562433271,1.5707963267948966 ) ;
  }

  @Test
  public void test1626() {
    coral.tests.JPFBenchmark.benchmark02(-47.05887406532136,-46.45883339981871 ) ;
  }

  @Test
  public void test1627() {
    coral.tests.JPFBenchmark.benchmark02(47.108148204602514,17.78804337130491 ) ;
  }

  @Test
  public void test1628() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388807698612,-32.98672286264415 ) ;
  }

  @Test
  public void test1629() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388978524689,-42.41150463815948 ) ;
  }

  @Test
  public void test1630() {
    coral.tests.JPFBenchmark.benchmark02(-4.71238898038366,0.0 ) ;
  }

  @Test
  public void test1631() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388980394689,1.5707963267948966 ) ;
  }

  @Test
  public void test1632() {
    coral.tests.JPFBenchmark.benchmark02(-47.12388980407973,1.5707963267948966 ) ;
  }

  @Test
  public void test1633() {
    coral.tests.JPFBenchmark.benchmark02(47.123896621095575,-92.67699290297878 ) ;
  }

  @Test
  public void test1634() {
    coral.tests.JPFBenchmark.benchmark02(-47.123946924112666,0 ) ;
  }

  @Test
  public void test1635() {
    coral.tests.JPFBenchmark.benchmark02(-47.13138319850024,0.016328642221417385 ) ;
  }

  @Test
  public void test1636() {
    coral.tests.JPFBenchmark.benchmark02(47.13951484882262,0.0 ) ;
  }

  @Test
  public void test1637() {
    coral.tests.JPFBenchmark.benchmark02(47.13951488649093,-0.5687229794189183 ) ;
  }

  @Test
  public void test1638() {
    coral.tests.JPFBenchmark.benchmark02(47.15103656725091,-36.66829934241069 ) ;
  }

  @Test
  public void test1639() {
    coral.tests.JPFBenchmark.benchmark02(47.187282349727155,-73.82747650089836 ) ;
  }

  @Test
  public void test1640() {
    coral.tests.JPFBenchmark.benchmark02(47.30029063110072,0.5707955600282789 ) ;
  }

  @Test
  public void test1641() {
    coral.tests.JPFBenchmark.benchmark02(-47.36579705140725,99.20207583553584 ) ;
  }

  @Test
  public void test1642() {
    coral.tests.JPFBenchmark.benchmark02(-47.40805964758077,2527.66955994055 ) ;
  }

  @Test
  public void test1643() {
    coral.tests.JPFBenchmark.benchmark02(47.49598880387754,66.71194230482797 ) ;
  }

  @Test
  public void test1644() {
    coral.tests.JPFBenchmark.benchmark02(-47.549726767110336,36.23857996686465 ) ;
  }

  @Test
  public void test1645() {
    coral.tests.JPFBenchmark.benchmark02(-47.55872023056824,-1.5707963267948966 ) ;
  }

  @Test
  public void test1646() {
    coral.tests.JPFBenchmark.benchmark02(47.56540897899811,-16.805964367102618 ) ;
  }

  @Test
  public void test1647() {
    coral.tests.JPFBenchmark.benchmark02(47.58599540492,32.013018350163996 ) ;
  }

  @Test
  public void test1648() {
    coral.tests.JPFBenchmark.benchmark02(47.63263142233433,-82.5428500147644 ) ;
  }

  @Test
  public void test1649() {
    coral.tests.JPFBenchmark.benchmark02(47.640828744764825,-14.711256388837015 ) ;
  }

  @Test
  public void test1650() {
    coral.tests.JPFBenchmark.benchmark02(-47.68705749252935,0.0 ) ;
  }

  @Test
  public void test1651() {
    coral.tests.JPFBenchmark.benchmark02(-47.72410874506292,0.0 ) ;
  }

  @Test
  public void test1652() {
    coral.tests.JPFBenchmark.benchmark02(4.777274223533084,53.35325105865317 ) ;
  }

  @Test
  public void test1653() {
    coral.tests.JPFBenchmark.benchmark02(-47.80426538397165,-88.24632370428293 ) ;
  }

  @Test
  public void test1654() {
    coral.tests.JPFBenchmark.benchmark02(47.84148640535787,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1655() {
    coral.tests.JPFBenchmark.benchmark02(-47.858656106301,116.14992335270432 ) ;
  }

  @Test
  public void test1656() {
    coral.tests.JPFBenchmark.benchmark02(-47.91354960245893,27.560072978889977 ) ;
  }

  @Test
  public void test1657() {
    coral.tests.JPFBenchmark.benchmark02(-47.94774568639297,36.66044790637064 ) ;
  }

  @Test
  public void test1658() {
    coral.tests.JPFBenchmark.benchmark02(-47.986851353058675,42.03587829301307 ) ;
  }

  @Test
  public void test1659() {
    coral.tests.JPFBenchmark.benchmark02(-48.02001296275073,-1.5707963267948966 ) ;
  }

  @Test
  public void test1660() {
    coral.tests.JPFBenchmark.benchmark02(48.02004810739328,-20.420352248333653 ) ;
  }

  @Test
  public void test1661() {
    coral.tests.JPFBenchmark.benchmark02(-48.03266727676914,-0.3438207363718906 ) ;
  }

  @Test
  public void test1662() {
    coral.tests.JPFBenchmark.benchmark02(-48.064693078707556,-32.98672286269283 ) ;
  }

  @Test
  public void test1663() {
    coral.tests.JPFBenchmark.benchmark02(-48.06832275413498,-2558.744300577694 ) ;
  }

  @Test
  public void test1664() {
    coral.tests.JPFBenchmark.benchmark02(48.105287789007974,10.535079073531433 ) ;
  }

  @Test
  public void test1665() {
    coral.tests.JPFBenchmark.benchmark02(48.176821690373885,-91.58389671218373 ) ;
  }

  @Test
  public void test1666() {
    coral.tests.JPFBenchmark.benchmark02(48.17958937531826,-90.59109019898347 ) ;
  }

  @Test
  public void test1667() {
    coral.tests.JPFBenchmark.benchmark02(-48.19562340896106,1.5707963267948966 ) ;
  }

  @Test
  public void test1668() {
    coral.tests.JPFBenchmark.benchmark02(48.226433637509786,58.55813636943338 ) ;
  }

  @Test
  public void test1669() {
    coral.tests.JPFBenchmark.benchmark02(-48.24492054764089,-0.05907116218519042 ) ;
  }

  @Test
  public void test1670() {
    coral.tests.JPFBenchmark.benchmark02(48.26764659826166,-3.2665926535897936 ) ;
  }

  @Test
  public void test1671() {
    coral.tests.JPFBenchmark.benchmark02(-48.34256846892164,-35.03917179175899 ) ;
  }

  @Test
  public void test1672() {
    coral.tests.JPFBenchmark.benchmark02(48.380941308162704,16.678020819186344 ) ;
  }

  @Test
  public void test1673() {
    coral.tests.JPFBenchmark.benchmark02(-48.38436004714437,37.07310073415644 ) ;
  }

  @Test
  public void test1674() {
    coral.tests.JPFBenchmark.benchmark02(48.40718293477727,80.96362318135627 ) ;
  }

  @Test
  public void test1675() {
    coral.tests.JPFBenchmark.benchmark02(48.43526049696494,1.5707963267948968 ) ;
  }

  @Test
  public void test1676() {
    coral.tests.JPFBenchmark.benchmark02(48.46727778101513,0.0 ) ;
  }

  @Test
  public void test1677() {
    coral.tests.JPFBenchmark.benchmark02(-48.612916933656926,-82.07112555020487 ) ;
  }

  @Test
  public void test1678() {
    coral.tests.JPFBenchmark.benchmark02(-48.644945644880735,87.9148538127426 ) ;
  }

  @Test
  public void test1679() {
    coral.tests.JPFBenchmark.benchmark02(48.65428916395434,-1.5707963267948966 ) ;
  }

  @Test
  public void test1680() {
    coral.tests.JPFBenchmark.benchmark02(-48.69468613247062,0.0 ) ;
  }

  @Test
  public void test1681() {
    coral.tests.JPFBenchmark.benchmark02(-4.870467945334738,0.0 ) ;
  }

  @Test
  public void test1682() {
    coral.tests.JPFBenchmark.benchmark02(-48.72855150924003,-4.712388978522045 ) ;
  }

  @Test
  public void test1683() {
    coral.tests.JPFBenchmark.benchmark02(48.730188756082725,0.0 ) ;
  }

  @Test
  public void test1684() {
    coral.tests.JPFBenchmark.benchmark02(-48.73692276593314,50.3077190950953 ) ;
  }

  @Test
  public void test1685() {
    coral.tests.JPFBenchmark.benchmark02(-48.762643730297526,-1.5707963267948983 ) ;
  }

  @Test
  public void test1686() {
    coral.tests.JPFBenchmark.benchmark02(-48.77421693645661,-1.5707963267948972 ) ;
  }

  @Test
  public void test1687() {
    coral.tests.JPFBenchmark.benchmark02(-48.77850784097127,-2019.5804589027139 ) ;
  }

  @Test
  public void test1688() {
    coral.tests.JPFBenchmark.benchmark02(-48.78101030416377,-34.9119796787878 ) ;
  }

  @Test
  public void test1689() {
    coral.tests.JPFBenchmark.benchmark02(-48.78186767821972,4.0788538427496504E-16 ) ;
  }

  @Test
  public void test1690() {
    coral.tests.JPFBenchmark.benchmark02(-48.78627956574681,-7.5986035332031605 ) ;
  }

  @Test
  public void test1691() {
    coral.tests.JPFBenchmark.benchmark02(48.79091959390976,44.332507603213415 ) ;
  }

  @Test
  public void test1692() {
    coral.tests.JPFBenchmark.benchmark02(-48.81402491791547,99.92383779668234 ) ;
  }

  @Test
  public void test1693() {
    coral.tests.JPFBenchmark.benchmark02(49.05607618724774,0.0 ) ;
  }

  @Test
  public void test1694() {
    coral.tests.JPFBenchmark.benchmark02(-49.06152328070873,43.26184826750831 ) ;
  }

  @Test
  public void test1695() {
    coral.tests.JPFBenchmark.benchmark02(49.08923075440245,-1.5707963267948966 ) ;
  }

  @Test
  public void test1696() {
    coral.tests.JPFBenchmark.benchmark02(4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test1697() {
    coral.tests.JPFBenchmark.benchmark02(-4.930380657631324E-32,26.703537555420095 ) ;
  }

  @Test
  public void test1698() {
    coral.tests.JPFBenchmark.benchmark02(-49.30710852968471,0.6124223992168741 ) ;
  }

  @Test
  public void test1699() {
    coral.tests.JPFBenchmark.benchmark02(49.31959535667576,0.8445379149981624 ) ;
  }

  @Test
  public void test1700() {
    coral.tests.JPFBenchmark.benchmark02(-49.31988593961307,77.09614005842016 ) ;
  }

  @Test
  public void test1701() {
    coral.tests.JPFBenchmark.benchmark02(49.33996928082812,-1.5707963267948966 ) ;
  }

  @Test
  public void test1702() {
    coral.tests.JPFBenchmark.benchmark02(49.4549608051164,-157.50702233026837 ) ;
  }

  @Test
  public void test1703() {
    coral.tests.JPFBenchmark.benchmark02(-49.484639114826734,-1.5707963267948966 ) ;
  }

  @Test
  public void test1704() {
    coral.tests.JPFBenchmark.benchmark02(-49.66095681761993,6.911221768366812 ) ;
  }

  @Test
  public void test1705() {
    coral.tests.JPFBenchmark.benchmark02(-49.76098074717921,1.5707963267948966 ) ;
  }

  @Test
  public void test1706() {
    coral.tests.JPFBenchmark.benchmark02(-49.77670984761136,-1.082023717082824 ) ;
  }

  @Test
  public void test1707() {
    coral.tests.JPFBenchmark.benchmark02(49.778859702988214,59.88693824398811 ) ;
  }

  @Test
  public void test1708() {
    coral.tests.JPFBenchmark.benchmark02(-49.786298147949935,100.0 ) ;
  }

  @Test
  public void test1709() {
    coral.tests.JPFBenchmark.benchmark02(49.793000749033524,1.5707963267948972 ) ;
  }

  @Test
  public void test1710() {
    coral.tests.JPFBenchmark.benchmark02(-49.79388900070499,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test1711() {
    coral.tests.JPFBenchmark.benchmark02(-49.8117180610528,-1.2919933565533626 ) ;
  }

  @Test
  public void test1712() {
    coral.tests.JPFBenchmark.benchmark02(4.9817503712778235,0.5189863672205993 ) ;
  }

  @Test
  public void test1713() {
    coral.tests.JPFBenchmark.benchmark02(49.836431189842195,-16.99145233781468 ) ;
  }

  @Test
  public void test1714() {
    coral.tests.JPFBenchmark.benchmark02(-49.84715122508365,0.0 ) ;
  }

  @Test
  public void test1715() {
    coral.tests.JPFBenchmark.benchmark02(-49.864734957047716,73.45761005265165 ) ;
  }

  @Test
  public void test1716() {
    coral.tests.JPFBenchmark.benchmark02(-49.86907022828652,-44.14529712862312 ) ;
  }

  @Test
  public void test1717() {
    coral.tests.JPFBenchmark.benchmark02(49.88408785296845,88.9211866936399 ) ;
  }

  @Test
  public void test1718() {
    coral.tests.JPFBenchmark.benchmark02(-49.89623495831103,-15.707963267956401 ) ;
  }

  @Test
  public void test1719() {
    coral.tests.JPFBenchmark.benchmark02(49.89665416666885,-16.133737954398597 ) ;
  }

  @Test
  public void test1720() {
    coral.tests.JPFBenchmark.benchmark02(49.89904112204778,2.0092908041521014 ) ;
  }

  @Test
  public void test1721() {
    coral.tests.JPFBenchmark.benchmark02(-49.91103696903265,34.55751918948772 ) ;
  }

  @Test
  public void test1722() {
    coral.tests.JPFBenchmark.benchmark02(-49.92409706762121,62.052933291820295 ) ;
  }

  @Test
  public void test1723() {
    coral.tests.JPFBenchmark.benchmark02(-49.93203556793084,0.01641006254851713 ) ;
  }

  @Test
  public void test1724() {
    coral.tests.JPFBenchmark.benchmark02(-49.93978024553297,-3.14159265358979 ) ;
  }

  @Test
  public void test1725() {
    coral.tests.JPFBenchmark.benchmark02(-49.95049207113347,32.90838818601296 ) ;
  }

  @Test
  public void test1726() {
    coral.tests.JPFBenchmark.benchmark02(-49.97692239091215,-17.278759594743864 ) ;
  }

  @Test
  public void test1727() {
    coral.tests.JPFBenchmark.benchmark02(50.00036211781548,17.13890657647854 ) ;
  }

  @Test
  public void test1728() {
    coral.tests.JPFBenchmark.benchmark02(50.028222204213414,0.0 ) ;
  }

  @Test
  public void test1729() {
    coral.tests.JPFBenchmark.benchmark02(-50.05290136689576,38.294936769762224 ) ;
  }

  @Test
  public void test1730() {
    coral.tests.JPFBenchmark.benchmark02(-50.05448100066898,1.5707963267948966 ) ;
  }

  @Test
  public void test1731() {
    coral.tests.JPFBenchmark.benchmark02(-50.05610766464596,78.23782557629974 ) ;
  }

  @Test
  public void test1732() {
    coral.tests.JPFBenchmark.benchmark02(-50.05685363045711,-50.52073988006407 ) ;
  }

  @Test
  public void test1733() {
    coral.tests.JPFBenchmark.benchmark02(-50.06604894445904,1.5707963267948983 ) ;
  }

  @Test
  public void test1734() {
    coral.tests.JPFBenchmark.benchmark02(-50.07816194545238,0.0 ) ;
  }

  @Test
  public void test1735() {
    coral.tests.JPFBenchmark.benchmark02(-50.085679103930424,0 ) ;
  }

  @Test
  public void test1736() {
    coral.tests.JPFBenchmark.benchmark02(50.114082425797804,-14.429204098919797 ) ;
  }

  @Test
  public void test1737() {
    coral.tests.JPFBenchmark.benchmark02(50.16019594867572,-73.68624817627192 ) ;
  }

  @Test
  public void test1738() {
    coral.tests.JPFBenchmark.benchmark02(50.16608848767403,136.60461471690456 ) ;
  }

  @Test
  public void test1739() {
    coral.tests.JPFBenchmark.benchmark02(-50.19973339312695,-46.527827481475725 ) ;
  }

  @Test
  public void test1740() {
    coral.tests.JPFBenchmark.benchmark02(-50.210823173783254,-1.570796326794897 ) ;
  }

  @Test
  public void test1741() {
    coral.tests.JPFBenchmark.benchmark02(-50.22613454539257,-1.570796326794897 ) ;
  }

  @Test
  public void test1742() {
    coral.tests.JPFBenchmark.benchmark02(50.22747595735518,64.94515476075037 ) ;
  }

  @Test
  public void test1743() {
    coral.tests.JPFBenchmark.benchmark02(-50.23998141805904,1.1303940386815983E-6 ) ;
  }

  @Test
  public void test1744() {
    coral.tests.JPFBenchmark.benchmark02(-5.025267562379,-2608.386909507997 ) ;
  }

  @Test
  public void test1745() {
    coral.tests.JPFBenchmark.benchmark02(-50.26497657673302,-4.712142570578856 ) ;
  }

  @Test
  public void test1746() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548178818234,10.99557428756427 ) ;
  }

  @Test
  public void test1747() {
    coral.tests.JPFBenchmark.benchmark02(50.2654822040392,1.5707963267948966 ) ;
  }

  @Test
  public void test1748() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548241138728,174.35797799101945 ) ;
  }

  @Test
  public void test1749() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482446861014,-4.681115224743609 ) ;
  }

  @Test
  public void test1750() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245378002,73.82742575619838 ) ;
  }

  @Test
  public void test1751() {
    coral.tests.JPFBenchmark.benchmark02(50.26548245711226,14.137166840768852 ) ;
  }

  @Test
  public void test1752() {
    coral.tests.JPFBenchmark.benchmark02(-50.265482457336695,1.5707963267948977 ) ;
  }

  @Test
  public void test1753() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245734073,1.5707963267949054 ) ;
  }

  @Test
  public void test1754() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245735727,76.96902001294994 ) ;
  }

  @Test
  public void test1755() {
    coral.tests.JPFBenchmark.benchmark02(-50.26548245743166,-95.81857593458366 ) ;
  }

  @Test
  public void test1756() {
    coral.tests.JPFBenchmark.benchmark02(50.26548245743668,1.5707963267948963 ) ;
  }

  @Test
  public void test1757() {
    coral.tests.JPFBenchmark.benchmark02(50.26548269857989,1.5707963267948983 ) ;
  }

  @Test
  public void test1758() {
    coral.tests.JPFBenchmark.benchmark02(50.26790758788141,-4.714814378991667 ) ;
  }

  @Test
  public void test1759() {
    coral.tests.JPFBenchmark.benchmark02(-50.27329495751271,1.5707963267948963 ) ;
  }

  @Test
  public void test1760() {
    coral.tests.JPFBenchmark.benchmark02(50.28623774969914,82.66350686381469 ) ;
  }

  @Test
  public void test1761() {
    coral.tests.JPFBenchmark.benchmark02(-50.370924909233814,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test1762() {
    coral.tests.JPFBenchmark.benchmark02(50.37270631604588,-1.5707963267948966 ) ;
  }

  @Test
  public void test1763() {
    coral.tests.JPFBenchmark.benchmark02(50.395371707129755,0.0013702587218314675 ) ;
  }

  @Test
  public void test1764() {
    coral.tests.JPFBenchmark.benchmark02(-50.43513283560952,71.03254702649679 ) ;
  }

  @Test
  public void test1765() {
    coral.tests.JPFBenchmark.benchmark02(50.49666210532743,-10.778762661939567 ) ;
  }

  @Test
  public void test1766() {
    coral.tests.JPFBenchmark.benchmark02(-50.502058904790914,0 ) ;
  }

  @Test
  public void test1767() {
    coral.tests.JPFBenchmark.benchmark02(50.55745236099501,64.11067949513686 ) ;
  }

  @Test
  public void test1768() {
    coral.tests.JPFBenchmark.benchmark02(50.67296400293709,10.995684533855963 ) ;
  }

  @Test
  public void test1769() {
    coral.tests.JPFBenchmark.benchmark02(50.673060759339904,1.5707963267948966 ) ;
  }

  @Test
  public void test1770() {
    coral.tests.JPFBenchmark.benchmark02(-50.75670881238502,-10.475023438807327 ) ;
  }

  @Test
  public void test1771() {
    coral.tests.JPFBenchmark.benchmark02(50.76731045953659,-24.75666047012727 ) ;
  }

  @Test
  public void test1772() {
    coral.tests.JPFBenchmark.benchmark02(50.77987059920737,26.31935204013377 ) ;
  }

  @Test
  public void test1773() {
    coral.tests.JPFBenchmark.benchmark02(-50.91922553378645,28.806452621823595 ) ;
  }

  @Test
  public void test1774() {
    coral.tests.JPFBenchmark.benchmark02(-5.105851535827386,0.8441559458051107 ) ;
  }

  @Test
  public void test1775() {
    coral.tests.JPFBenchmark.benchmark02(-51.1134160868667,-46.40102710663317 ) ;
  }

  @Test
  public void test1776() {
    coral.tests.JPFBenchmark.benchmark02(-51.21535867808816,1.5707963267948968 ) ;
  }

  @Test
  public void test1777() {
    coral.tests.JPFBenchmark.benchmark02(-51.2716341535976,-1.5707963267948966 ) ;
  }

  @Test
  public void test1778() {
    coral.tests.JPFBenchmark.benchmark02(51.33230831448579,44.08097104477676 ) ;
  }

  @Test
  public void test1779() {
    coral.tests.JPFBenchmark.benchmark02(51.33663194277986,-0.30194595664276846 ) ;
  }

  @Test
  public void test1780() {
    coral.tests.JPFBenchmark.benchmark02(-51.3630283366154,2.668342206193008 ) ;
  }

  @Test
  public void test1781() {
    coral.tests.JPFBenchmark.benchmark02(-51.370507511900314,-1.5707963267948983 ) ;
  }

  @Test
  public void test1782() {
    coral.tests.JPFBenchmark.benchmark02(-5.141592653589794,1.5707963267948983 ) ;
  }

  @Test
  public void test1783() {
    coral.tests.JPFBenchmark.benchmark02(5.143391023871885,-43.89958082754697 ) ;
  }

  @Test
  public void test1784() {
    coral.tests.JPFBenchmark.benchmark02(-51.492072405840695,-1.5707963267948966 ) ;
  }

  @Test
  public void test1785() {
    coral.tests.JPFBenchmark.benchmark02(-51.49449230378291,-72.86683398941729 ) ;
  }

  @Test
  public void test1786() {
    coral.tests.JPFBenchmark.benchmark02(51.519426547005,-122.72453669186099 ) ;
  }

  @Test
  public void test1787() {
    coral.tests.JPFBenchmark.benchmark02(-51.62622452950515,-1.5707963267948966 ) ;
  }

  @Test
  public void test1788() {
    coral.tests.JPFBenchmark.benchmark02(51.65063559225035,0 ) ;
  }

  @Test
  public void test1789() {
    coral.tests.JPFBenchmark.benchmark02(51.66546640903327,-99.40908233596546 ) ;
  }

  @Test
  public void test1790() {
    coral.tests.JPFBenchmark.benchmark02(-51.73559525737141,14.559378162519153 ) ;
  }

  @Test
  public void test1791() {
    coral.tests.JPFBenchmark.benchmark02(51.76197634759012,48.24734536446567 ) ;
  }

  @Test
  public void test1792() {
    coral.tests.JPFBenchmark.benchmark02(51.80672817871098,-0.5025787281124998 ) ;
  }

  @Test
  public void test1793() {
    coral.tests.JPFBenchmark.benchmark02(51.80732902858517,-51.67165246259336 ) ;
  }

  @Test
  public void test1794() {
    coral.tests.JPFBenchmark.benchmark02(51.80876872154562,-0.946320156004955 ) ;
  }

  @Test
  public void test1795() {
    coral.tests.JPFBenchmark.benchmark02(5.18425973757533E-14,-164.9336211606699 ) ;
  }

  @Test
  public void test1796() {
    coral.tests.JPFBenchmark.benchmark02(51.86033832911531,-0.02405954903682715 ) ;
  }

  @Test
  public void test1797() {
    coral.tests.JPFBenchmark.benchmark02(51.90394410055029,48.568395258362244 ) ;
  }

  @Test
  public void test1798() {
    coral.tests.JPFBenchmark.benchmark02(-51.97329971579849,2621.6827946448957 ) ;
  }

  @Test
  public void test1799() {
    coral.tests.JPFBenchmark.benchmark02(-51.97544157465151,0.09238221229316018 ) ;
  }

  @Test
  public void test1800() {
    coral.tests.JPFBenchmark.benchmark02(-51.9914512772933,-1.5707963267948966 ) ;
  }

  @Test
  public void test1801() {
    coral.tests.JPFBenchmark.benchmark02(5.20590764153097,-71.0479877066981 ) ;
  }

  @Test
  public void test1802() {
    coral.tests.JPFBenchmark.benchmark02(52.108091825668964,-88.18123830038707 ) ;
  }

  @Test
  public void test1803() {
    coral.tests.JPFBenchmark.benchmark02(-52.24082359975086,-130.72509292024017 ) ;
  }

  @Test
  public void test1804() {
    coral.tests.JPFBenchmark.benchmark02(52.262169719112535,-73.62565086062122 ) ;
  }

  @Test
  public void test1805() {
    coral.tests.JPFBenchmark.benchmark02(52.344825769401524,0.0 ) ;
  }

  @Test
  public void test1806() {
    coral.tests.JPFBenchmark.benchmark02(-52.541931446414615,-16.255980466627882 ) ;
  }

  @Test
  public void test1807() {
    coral.tests.JPFBenchmark.benchmark02(-52.702209912568875,9.550206433013514 ) ;
  }

  @Test
  public void test1808() {
    coral.tests.JPFBenchmark.benchmark02(52.75089341878376,-1.5707963267948948 ) ;
  }

  @Test
  public void test1809() {
    coral.tests.JPFBenchmark.benchmark02(-52.934628135016126,0.0 ) ;
  }

  @Test
  public void test1810() {
    coral.tests.JPFBenchmark.benchmark02(5.293955920339377E-23,10.995574174786793 ) ;
  }

  @Test
  public void test1811() {
    coral.tests.JPFBenchmark.benchmark02(52.98428591163119,-77.52015567796815 ) ;
  }

  @Test
  public void test1812() {
    coral.tests.JPFBenchmark.benchmark02(53.10308456181497,1.5707963267948966 ) ;
  }

  @Test
  public void test1813() {
    coral.tests.JPFBenchmark.benchmark02(-53.11901770646694,-38.9579581818194 ) ;
  }

  @Test
  public void test1814() {
    coral.tests.JPFBenchmark.benchmark02(53.16347483220166,0.0 ) ;
  }

  @Test
  public void test1815() {
    coral.tests.JPFBenchmark.benchmark02(53.21886452450602,-50.226021569928434 ) ;
  }

  @Test
  public void test1816() {
    coral.tests.JPFBenchmark.benchmark02(5.326056757613046,40.227036719612606 ) ;
  }

  @Test
  public void test1817() {
    coral.tests.JPFBenchmark.benchmark02(-53.302189647545895,58.98890215656032 ) ;
  }

  @Test
  public void test1818() {
    coral.tests.JPFBenchmark.benchmark02(-53.330232276825576,-10.781483514804805 ) ;
  }

  @Test
  public void test1819() {
    coral.tests.JPFBenchmark.benchmark02(-53.407074795604224,-45.55309347696116 ) ;
  }

  @Test
  public void test1820() {
    coral.tests.JPFBenchmark.benchmark02(-53.407075108422184,45.55309347705153 ) ;
  }

  @Test
  public void test1821() {
    coral.tests.JPFBenchmark.benchmark02(53.407075110926485,-1.5707963267948966 ) ;
  }

  @Test
  public void test1822() {
    coral.tests.JPFBenchmark.benchmark02(53.407075110926485,1.5707963267948966 ) ;
  }

  @Test
  public void test1823() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511102647,1.5707963267948966 ) ;
  }

  @Test
  public void test1824() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511112487,-1.5707963267948966 ) ;
  }

  @Test
  public void test1825() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707511112648,-1.5707963267949006 ) ;
  }

  @Test
  public void test1826() {
    coral.tests.JPFBenchmark.benchmark02(-53.40707516574362,39.269908177323174 ) ;
  }

  @Test
  public void test1827() {
    coral.tests.JPFBenchmark.benchmark02(53.407976205122395,77.74499692527243 ) ;
  }

  @Test
  public void test1828() {
    coral.tests.JPFBenchmark.benchmark02(53.40904720879459,-0.569130982283567 ) ;
  }

  @Test
  public void test1829() {
    coral.tests.JPFBenchmark.benchmark02(-53.45195997110752,0.0 ) ;
  }

  @Test
  public void test1830() {
    coral.tests.JPFBenchmark.benchmark02(53.47130812286562,-78.08638419182313 ) ;
  }

  @Test
  public void test1831() {
    coral.tests.JPFBenchmark.benchmark02(-53.48298480160573,-1.5707963267948966 ) ;
  }

  @Test
  public void test1832() {
    coral.tests.JPFBenchmark.benchmark02(53.52624642970886,0.0 ) ;
  }

  @Test
  public void test1833() {
    coral.tests.JPFBenchmark.benchmark02(-53.53083015130036,61.84138215847034 ) ;
  }

  @Test
  public void test1834() {
    coral.tests.JPFBenchmark.benchmark02(53.54482272989507,-1.5707963267948968 ) ;
  }

  @Test
  public void test1835() {
    coral.tests.JPFBenchmark.benchmark02(-53.54822097418125,-1.5707963267948966 ) ;
  }

  @Test
  public void test1836() {
    coral.tests.JPFBenchmark.benchmark02(-53.54901944112738,-55.10852981069343 ) ;
  }

  @Test
  public void test1837() {
    coral.tests.JPFBenchmark.benchmark02(-53.62152227622166,0.0 ) ;
  }

  @Test
  public void test1838() {
    coral.tests.JPFBenchmark.benchmark02(-53.624142358087695,-1.5707963267948966 ) ;
  }

  @Test
  public void test1839() {
    coral.tests.JPFBenchmark.benchmark02(53.6477161331197,90.05126848763803 ) ;
  }

  @Test
  public void test1840() {
    coral.tests.JPFBenchmark.benchmark02(53.648015955567075,42.36473045447883 ) ;
  }

  @Test
  public void test1841() {
    coral.tests.JPFBenchmark.benchmark02(-53.67935293201269,5.995804670903439 ) ;
  }

  @Test
  public void test1842() {
    coral.tests.JPFBenchmark.benchmark02(-53.710148123068265,1.5707963267948968 ) ;
  }

  @Test
  public void test1843() {
    coral.tests.JPFBenchmark.benchmark02(53.73819346093583,89.14797189651799 ) ;
  }

  @Test
  public void test1844() {
    coral.tests.JPFBenchmark.benchmark02(53.74986917185302,-89.00927213078955 ) ;
  }

  @Test
  public void test1845() {
    coral.tests.JPFBenchmark.benchmark02(53.7519304340172,-41.03150024498055 ) ;
  }

  @Test
  public void test1846() {
    coral.tests.JPFBenchmark.benchmark02(-53.80578751769758,1.172083920232312 ) ;
  }

  @Test
  public void test1847() {
    coral.tests.JPFBenchmark.benchmark02(53.85004325311354,72.86816759536575 ) ;
  }

  @Test
  public void test1848() {
    coral.tests.JPFBenchmark.benchmark02(53.922768810357546,39.46918832993707 ) ;
  }

  @Test
  public void test1849() {
    coral.tests.JPFBenchmark.benchmark02(53.94603803850871,-53.7803730135917 ) ;
  }

  @Test
  public void test1850() {
    coral.tests.JPFBenchmark.benchmark02(53.96261406696138,6.458843633284488 ) ;
  }

  @Test
  public void test1851() {
    coral.tests.JPFBenchmark.benchmark02(53.96295039326763,0.0 ) ;
  }

  @Test
  public void test1852() {
    coral.tests.JPFBenchmark.benchmark02(53.9735978434949,-1.5707963267948966 ) ;
  }

  @Test
  public void test1853() {
    coral.tests.JPFBenchmark.benchmark02(-54.075319700677426,125.42602905209782 ) ;
  }

  @Test
  public void test1854() {
    coral.tests.JPFBenchmark.benchmark02(54.08124110017768,29.835566031825053 ) ;
  }

  @Test
  public void test1855() {
    coral.tests.JPFBenchmark.benchmark02(54.1933175821114,75.99433938895513 ) ;
  }

  @Test
  public void test1856() {
    coral.tests.JPFBenchmark.benchmark02(-54.1936899262359,73.10850207053754 ) ;
  }

  @Test
  public void test1857() {
    coral.tests.JPFBenchmark.benchmark02(54.19715174264195,-149.98110772511978 ) ;
  }

  @Test
  public void test1858() {
    coral.tests.JPFBenchmark.benchmark02(-5.421010862427522E-20,0.5707862184700333 ) ;
  }

  @Test
  public void test1859() {
    coral.tests.JPFBenchmark.benchmark02(-5.421010862427522E-20,-86.4016104737389 ) ;
  }

  @Test
  public void test1860() {
    coral.tests.JPFBenchmark.benchmark02(-54.22275420206291,-81.25556951920373 ) ;
  }

  @Test
  public void test1861() {
    coral.tests.JPFBenchmark.benchmark02(-54.237490246375515,-1.5707963267948966 ) ;
  }

  @Test
  public void test1862() {
    coral.tests.JPFBenchmark.benchmark02(-54.252821187315945,20.183940242016142 ) ;
  }

  @Test
  public void test1863() {
    coral.tests.JPFBenchmark.benchmark02(-54.27743668724623,0.0 ) ;
  }

  @Test
  public void test1864() {
    coral.tests.JPFBenchmark.benchmark02(-54.367990441677236,-96.70828664978421 ) ;
  }

  @Test
  public void test1865() {
    coral.tests.JPFBenchmark.benchmark02(54.407970626844396,44.384554971752024 ) ;
  }

  @Test
  public void test1866() {
    coral.tests.JPFBenchmark.benchmark02(-54.422495954160595,-85.59619488199215 ) ;
  }

  @Test
  public void test1867() {
    coral.tests.JPFBenchmark.benchmark02(-54.4291206182691,0.0 ) ;
  }

  @Test
  public void test1868() {
    coral.tests.JPFBenchmark.benchmark02(-54.44214675476158,25.593266697684115 ) ;
  }

  @Test
  public void test1869() {
    coral.tests.JPFBenchmark.benchmark02(-54.58597168051196,25.89784555905392 ) ;
  }

  @Test
  public void test1870() {
    coral.tests.JPFBenchmark.benchmark02(-54.66741105718145,-40.17723905332815 ) ;
  }

  @Test
  public void test1871() {
    coral.tests.JPFBenchmark.benchmark02(-54.794576763841604,-56.365373090087886 ) ;
  }

  @Test
  public void test1872() {
    coral.tests.JPFBenchmark.benchmark02(-54.87147489011166,0.0 ) ;
  }

  @Test
  public void test1873() {
    coral.tests.JPFBenchmark.benchmark02(54.885074734028024,-66.38541843471957 ) ;
  }

  @Test
  public void test1874() {
    coral.tests.JPFBenchmark.benchmark02(-54.905022730739475,0.0 ) ;
  }

  @Test
  public void test1875() {
    coral.tests.JPFBenchmark.benchmark02(54.90770230125372,-41.86368744116826 ) ;
  }

  @Test
  public void test1876() {
    coral.tests.JPFBenchmark.benchmark02(-54.92209113908248,13.906424406243225 ) ;
  }

  @Test
  public void test1877() {
    coral.tests.JPFBenchmark.benchmark02(-54.96962946032663,88.1681852574667 ) ;
  }

  @Test
  public void test1878() {
    coral.tests.JPFBenchmark.benchmark02(-54.97787143782439,0.0 ) ;
  }

  @Test
  public void test1879() {
    coral.tests.JPFBenchmark.benchmark02(54.98519461384916,1.5707963267948966 ) ;
  }

  @Test
  public void test1880() {
    coral.tests.JPFBenchmark.benchmark02(-54.99735192140767,37.71859233179175 ) ;
  }

  @Test
  public void test1881() {
    coral.tests.JPFBenchmark.benchmark02(55.002270898603,62.33461936271485 ) ;
  }

  @Test
  public void test1882() {
    coral.tests.JPFBenchmark.benchmark02(-55.01975385671442,-70.47816648761464 ) ;
  }

  @Test
  public void test1883() {
    coral.tests.JPFBenchmark.benchmark02(-55.029386442553594,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test1884() {
    coral.tests.JPFBenchmark.benchmark02(-55.03261659168297,1.5707963267948966 ) ;
  }

  @Test
  public void test1885() {
    coral.tests.JPFBenchmark.benchmark02(55.05322530496796,2285.5626959975475 ) ;
  }

  @Test
  public void test1886() {
    coral.tests.JPFBenchmark.benchmark02(55.06134574023787,0.0 ) ;
  }

  @Test
  public void test1887() {
    coral.tests.JPFBenchmark.benchmark02(-55.09441697589853,-1.5707963267948948 ) ;
  }

  @Test
  public void test1888() {
    coral.tests.JPFBenchmark.benchmark02(55.10925149518826,0.056824146148077244 ) ;
  }

  @Test
  public void test1889() {
    coral.tests.JPFBenchmark.benchmark02(55.132461303253336,49.2580760579672 ) ;
  }

  @Test
  public void test1890() {
    coral.tests.JPFBenchmark.benchmark02(-55.13827467604782,62.83185307179586 ) ;
  }

  @Test
  public void test1891() {
    coral.tests.JPFBenchmark.benchmark02(-55.14227910282757,90.30252781611537 ) ;
  }

  @Test
  public void test1892() {
    coral.tests.JPFBenchmark.benchmark02(-55.14508085321702,0.0 ) ;
  }

  @Test
  public void test1893() {
    coral.tests.JPFBenchmark.benchmark02(-55.19321624896363,51.75123586694727 ) ;
  }

  @Test
  public void test1894() {
    coral.tests.JPFBenchmark.benchmark02(55.20949834848443,1.5707963267948966 ) ;
  }

  @Test
  public void test1895() {
    coral.tests.JPFBenchmark.benchmark02(55.217774074694915,1.5707963267948966 ) ;
  }

  @Test
  public void test1896() {
    coral.tests.JPFBenchmark.benchmark02(-55.217977623325986,-13.934172229258479 ) ;
  }

  @Test
  public void test1897() {
    coral.tests.JPFBenchmark.benchmark02(-55.223362396096164,0.0 ) ;
  }

  @Test
  public void test1898() {
    coral.tests.JPFBenchmark.benchmark02(55.254850048017474,0.0 ) ;
  }

  @Test
  public void test1899() {
    coral.tests.JPFBenchmark.benchmark02(55.26588894852374,53.695092621376794 ) ;
  }

  @Test
  public void test1900() {
    coral.tests.JPFBenchmark.benchmark02(-55.27523235253873,0 ) ;
  }

  @Test
  public void test1901() {
    coral.tests.JPFBenchmark.benchmark02(-55.297603758766286,63.134792811945175 ) ;
  }

  @Test
  public void test1902() {
    coral.tests.JPFBenchmark.benchmark02(-55.31196821765182,1.5707963267948966 ) ;
  }

  @Test
  public void test1903() {
    coral.tests.JPFBenchmark.benchmark02(55.31804704741218,107.3686220863734 ) ;
  }

  @Test
  public void test1904() {
    coral.tests.JPFBenchmark.benchmark02(-55.33141394573042,-151.05589689024112 ) ;
  }

  @Test
  public void test1905() {
    coral.tests.JPFBenchmark.benchmark02(-55.33636014077978,1.9829440124561302 ) ;
  }

  @Test
  public void test1906() {
    coral.tests.JPFBenchmark.benchmark02(-55.341274031762225,-32.54929845683772 ) ;
  }

  @Test
  public void test1907() {
    coral.tests.JPFBenchmark.benchmark02(55.37733798738478,1.5707963267948968 ) ;
  }

  @Test
  public void test1908() {
    coral.tests.JPFBenchmark.benchmark02(55.41042456219324,32.07931477410975 ) ;
  }

  @Test
  public void test1909() {
    coral.tests.JPFBenchmark.benchmark02(-55.41611641690513,-7.203674510031998 ) ;
  }

  @Test
  public void test1910() {
    coral.tests.JPFBenchmark.benchmark02(55.42294223714416,0.0 ) ;
  }

  @Test
  public void test1911() {
    coral.tests.JPFBenchmark.benchmark02(55.44983985787945,67.27655261055543 ) ;
  }

  @Test
  public void test1912() {
    coral.tests.JPFBenchmark.benchmark02(-55.45269872815169,38.83327091266874 ) ;
  }

  @Test
  public void test1913() {
    coral.tests.JPFBenchmark.benchmark02(-55.45772532142531,28.274333882308138 ) ;
  }

  @Test
  public void test1914() {
    coral.tests.JPFBenchmark.benchmark02(55.49014212628372,31.475430727577066 ) ;
  }

  @Test
  public void test1915() {
    coral.tests.JPFBenchmark.benchmark02(-55.49710407865325,0.4040461428816669 ) ;
  }

  @Test
  public void test1916() {
    coral.tests.JPFBenchmark.benchmark02(-55.50293968572084,0.0 ) ;
  }

  @Test
  public void test1917() {
    coral.tests.JPFBenchmark.benchmark02(55.50416861219559,78.8603099271285 ) ;
  }

  @Test
  public void test1918() {
    coral.tests.JPFBenchmark.benchmark02(-55.51040911290394,-1.5707963267948966 ) ;
  }

  @Test
  public void test1919() {
    coral.tests.JPFBenchmark.benchmark02(5.551115123125783E-17,-1.5707963267948966 ) ;
  }

  @Test
  public void test1920() {
    coral.tests.JPFBenchmark.benchmark02(5.551115123125783E-17,-54.97787143772141 ) ;
  }

  @Test
  public void test1921() {
    coral.tests.JPFBenchmark.benchmark02(-55.520438216614565,68.08813222087622 ) ;
  }

  @Test
  public void test1922() {
    coral.tests.JPFBenchmark.benchmark02(55.536501133302444,0.0 ) ;
  }

  @Test
  public void test1923() {
    coral.tests.JPFBenchmark.benchmark02(-55.617651345140516,-28.351354431837805 ) ;
  }

  @Test
  public void test1924() {
    coral.tests.JPFBenchmark.benchmark02(-55.624721047537705,-46.31032283913612 ) ;
  }

  @Test
  public void test1925() {
    coral.tests.JPFBenchmark.benchmark02(55.64297803022167,1.5707963267948966 ) ;
  }

  @Test
  public void test1926() {
    coral.tests.JPFBenchmark.benchmark02(55.674598718114886,-22.716965508091562 ) ;
  }

  @Test
  public void test1927() {
    coral.tests.JPFBenchmark.benchmark02(-55.869688650077066,-91.57463880670451 ) ;
  }

  @Test
  public void test1928() {
    coral.tests.JPFBenchmark.benchmark02(-55.99347262393211,0.0 ) ;
  }

  @Test
  public void test1929() {
    coral.tests.JPFBenchmark.benchmark02(56.0076774072723,0 ) ;
  }

  @Test
  public void test1930() {
    coral.tests.JPFBenchmark.benchmark02(-56.023823499306936,61.498187713343526 ) ;
  }

  @Test
  public void test1931() {
    coral.tests.JPFBenchmark.benchmark02(-56.062274533039115,-17.796491732374474 ) ;
  }

  @Test
  public void test1932() {
    coral.tests.JPFBenchmark.benchmark02(56.10409331831067,6.12356486548042E-17 ) ;
  }

  @Test
  public void test1933() {
    coral.tests.JPFBenchmark.benchmark02(-56.13125700901607,1.5707963267948966 ) ;
  }

  @Test
  public void test1934() {
    coral.tests.JPFBenchmark.benchmark02(-56.13276429065262,2097.2930721647876 ) ;
  }

  @Test
  public void test1935() {
    coral.tests.JPFBenchmark.benchmark02(-56.15365298433747,24.59793698809314 ) ;
  }

  @Test
  public void test1936() {
    coral.tests.JPFBenchmark.benchmark02(56.22911958833613,2295.7432419171305 ) ;
  }

  @Test
  public void test1937() {
    coral.tests.JPFBenchmark.benchmark02(-56.295052126889985,100.0 ) ;
  }

  @Test
  public void test1938() {
    coral.tests.JPFBenchmark.benchmark02(-56.33914765932764,-54.25992314695167 ) ;
  }

  @Test
  public void test1939() {
    coral.tests.JPFBenchmark.benchmark02(56.359645021882514,53.73551377285159 ) ;
  }

  @Test
  public void test1940() {
    coral.tests.JPFBenchmark.benchmark02(-56.36096196923212,0.0 ) ;
  }

  @Test
  public void test1941() {
    coral.tests.JPFBenchmark.benchmark02(-56.37715702724889,1.570796326794897 ) ;
  }

  @Test
  public void test1942() {
    coral.tests.JPFBenchmark.benchmark02(56.42588281071653,82.58262990044457 ) ;
  }

  @Test
  public void test1943() {
    coral.tests.JPFBenchmark.benchmark02(-56.434749862150696,26.809427341368245 ) ;
  }

  @Test
  public void test1944() {
    coral.tests.JPFBenchmark.benchmark02(-56.435063841600176,-72.1511574769981 ) ;
  }

  @Test
  public void test1945() {
    coral.tests.JPFBenchmark.benchmark02(5.644318218758485,54.480477815788845 ) ;
  }

  @Test
  public void test1946() {
    coral.tests.JPFBenchmark.benchmark02(-56.46471764264971,3.1172064605148364 ) ;
  }

  @Test
  public void test1947() {
    coral.tests.JPFBenchmark.benchmark02(56.47880841405896,-11.448337257907127 ) ;
  }

  @Test
  public void test1948() {
    coral.tests.JPFBenchmark.benchmark02(-56.480398775398086,100.0 ) ;
  }

  @Test
  public void test1949() {
    coral.tests.JPFBenchmark.benchmark02(56.49173699867938,9.967845490485487 ) ;
  }

  @Test
  public void test1950() {
    coral.tests.JPFBenchmark.benchmark02(-56.52111432705886,18.84955592153876 ) ;
  }

  @Test
  public void test1951() {
    coral.tests.JPFBenchmark.benchmark02(-56.523972763170946,-1.5707963267890683 ) ;
  }

  @Test
  public void test1952() {
    coral.tests.JPFBenchmark.benchmark02(-56.529489016466016,-28.298188678542672 ) ;
  }

  @Test
  public void test1953() {
    coral.tests.JPFBenchmark.benchmark02(-56.53379888580578,0.0 ) ;
  }

  @Test
  public void test1954() {
    coral.tests.JPFBenchmark.benchmark02(56.54866294503862,39.26990816987241 ) ;
  }

  @Test
  public void test1955() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866647476457,-10.995574287059668 ) ;
  }

  @Test
  public void test1956() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866773534744,-17.27827116194971 ) ;
  }

  @Test
  public void test1957() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776451628,1.5707963267948966 ) ;
  }

  @Test
  public void test1958() {
    coral.tests.JPFBenchmark.benchmark02(-56.548667764531,-1.570796326809615 ) ;
  }

  @Test
  public void test1959() {
    coral.tests.JPFBenchmark.benchmark02(-56.54866776456189,-105.24335374003286 ) ;
  }

  @Test
  public void test1960() {
    coral.tests.JPFBenchmark.benchmark02(-56.548667764565685,1.5707963267948966 ) ;
  }

  @Test
  public void test1961() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776458579,4.270378511857658E-5 ) ;
  }

  @Test
  public void test1962() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776459684,83.25220530035192 ) ;
  }

  @Test
  public void test1963() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776461187,39.26990776268414 ) ;
  }

  @Test
  public void test1964() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776461625,0.0 ) ;
  }

  @Test
  public void test1965() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776461627,1.5707963267948963 ) ;
  }

  @Test
  public void test1966() {
    coral.tests.JPFBenchmark.benchmark02(56.54866776461627,1.5707963267948966 ) ;
  }

  @Test
  public void test1967() {
    coral.tests.JPFBenchmark.benchmark02(-56.58860292667245,-88.19667236900099 ) ;
  }

  @Test
  public void test1968() {
    coral.tests.JPFBenchmark.benchmark02(-56.62412806540102,0.0 ) ;
  }

  @Test
  public void test1969() {
    coral.tests.JPFBenchmark.benchmark02(56.648404478149814,-45.151812680055414 ) ;
  }

  @Test
  public void test1970() {
    coral.tests.JPFBenchmark.benchmark02(56.72393707357973,-1.5707963267948968 ) ;
  }

  @Test
  public void test1971() {
    coral.tests.JPFBenchmark.benchmark02(56.74276952651943,-10.896880646757381 ) ;
  }

  @Test
  public void test1972() {
    coral.tests.JPFBenchmark.benchmark02(-56.76327164780537,67.32963816888912 ) ;
  }

  @Test
  public void test1973() {
    coral.tests.JPFBenchmark.benchmark02(-56.77957817540721,54.16452330469707 ) ;
  }

  @Test
  public void test1974() {
    coral.tests.JPFBenchmark.benchmark02(-56.78059657849322,-49.42199765737352 ) ;
  }

  @Test
  public void test1975() {
    coral.tests.JPFBenchmark.benchmark02(56.854603215894855,0.63628439049356 ) ;
  }

  @Test
  public void test1976() {
    coral.tests.JPFBenchmark.benchmark02(56.86894830943514,5.2123889803846915 ) ;
  }

  @Test
  public void test1977() {
    coral.tests.JPFBenchmark.benchmark02(5.687704495005448,-46.42764321143119 ) ;
  }

  @Test
  public void test1978() {
    coral.tests.JPFBenchmark.benchmark02(56.899002562111946,-11.345909084953476 ) ;
  }

  @Test
  public void test1979() {
    coral.tests.JPFBenchmark.benchmark02(57.0924449139587,-92.1661207991707 ) ;
  }

  @Test
  public void test1980() {
    coral.tests.JPFBenchmark.benchmark02(57.103863891468364,-7.403641782317919 ) ;
  }

  @Test
  public void test1981() {
    coral.tests.JPFBenchmark.benchmark02(-57.11412419437653,1.5707963267948972 ) ;
  }

  @Test
  public void test1982() {
    coral.tests.JPFBenchmark.benchmark02(-57.136994845317886,0.0 ) ;
  }

  @Test
  public void test1983() {
    coral.tests.JPFBenchmark.benchmark02(57.33770294739472,-165.20409441257576 ) ;
  }

  @Test
  public void test1984() {
    coral.tests.JPFBenchmark.benchmark02(57.38127375782427,0.4899764671233534 ) ;
  }

  @Test
  public void test1985() {
    coral.tests.JPFBenchmark.benchmark02(-57.38300085535488,72.54027391900046 ) ;
  }

  @Test
  public void test1986() {
    coral.tests.JPFBenchmark.benchmark02(-57.53289505499806,0.0 ) ;
  }

  @Test
  public void test1987() {
    coral.tests.JPFBenchmark.benchmark02(57.54155441686689,10.000205513004175 ) ;
  }

  @Test
  public void test1988() {
    coral.tests.JPFBenchmark.benchmark02(57.552199025213525,1.5707963267948966 ) ;
  }

  @Test
  public void test1989() {
    coral.tests.JPFBenchmark.benchmark02(57.56703623869106,-90.229786149292 ) ;
  }

  @Test
  public void test1990() {
    coral.tests.JPFBenchmark.benchmark02(-57.61354951659035,-52.603598624619806 ) ;
  }

  @Test
  public void test1991() {
    coral.tests.JPFBenchmark.benchmark02(-57.80979173066877,-64.0026432141573 ) ;
  }

  @Test
  public void test1992() {
    coral.tests.JPFBenchmark.benchmark02(-57.83445527192246,-100.0 ) ;
  }

  @Test
  public void test1993() {
    coral.tests.JPFBenchmark.benchmark02(57.88935820628194,-74.97759934201913 ) ;
  }

  @Test
  public void test1994() {
    coral.tests.JPFBenchmark.benchmark02(57.90245259344479,0.2170114984308127 ) ;
  }

  @Test
  public void test1995() {
    coral.tests.JPFBenchmark.benchmark02(-57.9393051569902,0.0 ) ;
  }

  @Test
  public void test1996() {
    coral.tests.JPFBenchmark.benchmark02(-58.082501111545994,0.027904694007505726 ) ;
  }

  @Test
  public void test1997() {
    coral.tests.JPFBenchmark.benchmark02(58.0876330187802,-0.03183107577110587 ) ;
  }

  @Test
  public void test1998() {
    coral.tests.JPFBenchmark.benchmark02(58.116775715045684,-0.16108303946306723 ) ;
  }

  @Test
  public void test1999() {
    coral.tests.JPFBenchmark.benchmark02(-58.25177199800736,-1.5707963267949054 ) ;
  }

  @Test
  public void test2000() {
    coral.tests.JPFBenchmark.benchmark02(-58.25553055641321,-24.08374583862252 ) ;
  }

  @Test
  public void test2001() {
    coral.tests.JPFBenchmark.benchmark02(-5.829911320387357,13.774459498441747 ) ;
  }

  @Test
  public void test2002() {
    coral.tests.JPFBenchmark.benchmark02(-58.36178479341427,-123.58515191606209 ) ;
  }

  @Test
  public void test2003() {
    coral.tests.JPFBenchmark.benchmark02(-58.3712980549536,-8.510240159507521 ) ;
  }

  @Test
  public void test2004() {
    coral.tests.JPFBenchmark.benchmark02(58.51746780547117,-92.00748245002626 ) ;
  }

  @Test
  public void test2005() {
    coral.tests.JPFBenchmark.benchmark02(-58.51984338440741,62.26271795577125 ) ;
  }

  @Test
  public void test2006() {
    coral.tests.JPFBenchmark.benchmark02(5.862714595461355,44.43239534160739 ) ;
  }

  @Test
  public void test2007() {
    coral.tests.JPFBenchmark.benchmark02(58.6310897949127,32.42151499040139 ) ;
  }

  @Test
  public void test2008() {
    coral.tests.JPFBenchmark.benchmark02(-58.806778558084204,-49.65034649475095 ) ;
  }

  @Test
  public void test2009() {
    coral.tests.JPFBenchmark.benchmark02(-5.883536249382402,-32.0091563157941 ) ;
  }

  @Test
  public void test2010() {
    coral.tests.JPFBenchmark.benchmark02(-59.01889379511027,48.08172787864703 ) ;
  }

  @Test
  public void test2011() {
    coral.tests.JPFBenchmark.benchmark02(59.09564184271662,0 ) ;
  }

  @Test
  public void test2012() {
    coral.tests.JPFBenchmark.benchmark02(59.11820597469068,-18.530834139101813 ) ;
  }

  @Test
  public void test2013() {
    coral.tests.JPFBenchmark.benchmark02(-59.143826232676304,-15.096499232464195 ) ;
  }

  @Test
  public void test2014() {
    coral.tests.JPFBenchmark.benchmark02(-59.185274807125,-2.0757819379902327 ) ;
  }

  @Test
  public void test2015() {
    coral.tests.JPFBenchmark.benchmark02(59.20118306819293,1.5707963267948966 ) ;
  }

  @Test
  public void test2016() {
    coral.tests.JPFBenchmark.benchmark02(-59.28878993828302,0.0 ) ;
  }

  @Test
  public void test2017() {
    coral.tests.JPFBenchmark.benchmark02(-59.33295376584895,-80.0628042817246 ) ;
  }

  @Test
  public void test2018() {
    coral.tests.JPFBenchmark.benchmark02(-59.346498977856335,-100.0 ) ;
  }

  @Test
  public void test2019() {
    coral.tests.JPFBenchmark.benchmark02(-59.510244928247886,1.7509440038431292 ) ;
  }

  @Test
  public void test2020() {
    coral.tests.JPFBenchmark.benchmark02(-59.66428103339834,79.04359003574234 ) ;
  }

  @Test
  public void test2021() {
    coral.tests.JPFBenchmark.benchmark02(59.69026041813644,-1.5707963267948966 ) ;
  }

  @Test
  public void test2022() {
    coral.tests.JPFBenchmark.benchmark02(59.69026041820606,48.69465084811263 ) ;
  }

  @Test
  public void test2023() {
    coral.tests.JPFBenchmark.benchmark02(59.6902604182061,1.5707963267948966 ) ;
  }

  @Test
  public void test2024() {
    coral.tests.JPFBenchmark.benchmark02(-59.6902604258343,-1.5707963267950833 ) ;
  }

  @Test
  public void test2025() {
    coral.tests.JPFBenchmark.benchmark02(59.69026046095065,1.5707963267948966 ) ;
  }

  @Test
  public void test2026() {
    coral.tests.JPFBenchmark.benchmark02(59.69807582788305,105.24355609607585 ) ;
  }

  @Test
  public void test2027() {
    coral.tests.JPFBenchmark.benchmark02(-59.72653213512063,-1.5345246099804057 ) ;
  }

  @Test
  public void test2028() {
    coral.tests.JPFBenchmark.benchmark02(-59.739351408852414,-71.28891046413116 ) ;
  }

  @Test
  public void test2029() {
    coral.tests.JPFBenchmark.benchmark02(-59.75508038647095,8.616773505017733 ) ;
  }

  @Test
  public void test2030() {
    coral.tests.JPFBenchmark.benchmark02(59.815930789786314,65.49632467803553 ) ;
  }

  @Test
  public void test2031() {
    coral.tests.JPFBenchmark.benchmark02(-59.83475730125515,111.3094872577318 ) ;
  }

  @Test
  public void test2032() {
    coral.tests.JPFBenchmark.benchmark02(59.849947837250255,1.5707963267948963 ) ;
  }

  @Test
  public void test2033() {
    coral.tests.JPFBenchmark.benchmark02(-5.9961418679964,-0.34121994936177436 ) ;
  }

  @Test
  public void test2034() {
    coral.tests.JPFBenchmark.benchmark02(60.04386667779162,58.90859620725786 ) ;
  }

  @Test
  public void test2035() {
    coral.tests.JPFBenchmark.benchmark02(60.09214578649798,-61.26105674500097 ) ;
  }

  @Test
  public void test2036() {
    coral.tests.JPFBenchmark.benchmark02(60.13062749222681,1.5707963267948966 ) ;
  }

  @Test
  public void test2037() {
    coral.tests.JPFBenchmark.benchmark02(-60.26286718439039,0.0 ) ;
  }

  @Test
  public void test2038() {
    coral.tests.JPFBenchmark.benchmark02(-60.31481282212556,-137.28383283495222 ) ;
  }

  @Test
  public void test2039() {
    coral.tests.JPFBenchmark.benchmark02(60.32721100647905,-1.5707963267948966 ) ;
  }

  @Test
  public void test2040() {
    coral.tests.JPFBenchmark.benchmark02(-60.363315113954876,1.138573103523024 ) ;
  }

  @Test
  public void test2041() {
    coral.tests.JPFBenchmark.benchmark02(60.45356365401968,-85.63049473776731 ) ;
  }

  @Test
  public void test2042() {
    coral.tests.JPFBenchmark.benchmark02(60.561735294868896,0 ) ;
  }

  @Test
  public void test2043() {
    coral.tests.JPFBenchmark.benchmark02(60.56234317395521,-66.99088866004 ) ;
  }

  @Test
  public void test2044() {
    coral.tests.JPFBenchmark.benchmark02(60.65121549830871,-73.53883078489213 ) ;
  }

  @Test
  public void test2045() {
    coral.tests.JPFBenchmark.benchmark02(60.679930207911724,-35.84004220558852 ) ;
  }

  @Test
  public void test2046() {
    coral.tests.JPFBenchmark.benchmark02(60.71464698595946,61.64560066309946 ) ;
  }

  @Test
  public void test2047() {
    coral.tests.JPFBenchmark.benchmark02(60.754370596595656,6.3786171642457 ) ;
  }

  @Test
  public void test2048() {
    coral.tests.JPFBenchmark.benchmark02(60.77301207076085,-64.43471167859288 ) ;
  }

  @Test
  public void test2049() {
    coral.tests.JPFBenchmark.benchmark02(60.856092743942995,-9.24022664590342 ) ;
  }

  @Test
  public void test2050() {
    coral.tests.JPFBenchmark.benchmark02(60.9334271399984,0.0 ) ;
  }

  @Test
  public void test2051() {
    coral.tests.JPFBenchmark.benchmark02(60.952707028468126,42.809424504575674 ) ;
  }

  @Test
  public void test2052() {
    coral.tests.JPFBenchmark.benchmark02(-60.981579758853655,40.60754521714435 ) ;
  }

  @Test
  public void test2053() {
    coral.tests.JPFBenchmark.benchmark02(-60.98419408257667,30.20914255082664 ) ;
  }

  @Test
  public void test2054() {
    coral.tests.JPFBenchmark.benchmark02(-61.03939019205875,0.22166655339705507 ) ;
  }

  @Test
  public void test2055() {
    coral.tests.JPFBenchmark.benchmark02(61.04253521053897,-91.17299051417518 ) ;
  }

  @Test
  public void test2056() {
    coral.tests.JPFBenchmark.benchmark02(-61.05883055986021,0.2022261856386233 ) ;
  }

  @Test
  public void test2057() {
    coral.tests.JPFBenchmark.benchmark02(61.14350108028502,1.14837078461166 ) ;
  }

  @Test
  public void test2058() {
    coral.tests.JPFBenchmark.benchmark02(-61.16560350571366,1.5707963267948972 ) ;
  }

  @Test
  public void test2059() {
    coral.tests.JPFBenchmark.benchmark02(-61.172487632938896,0.002434136369177775 ) ;
  }

  @Test
  public void test2060() {
    coral.tests.JPFBenchmark.benchmark02(-61.215558023168825,-2637.470109761816 ) ;
  }

  @Test
  public void test2061() {
    coral.tests.JPFBenchmark.benchmark02(61.284378263975526,0 ) ;
  }

  @Test
  public void test2062() {
    coral.tests.JPFBenchmark.benchmark02(-61.34464801383086,0.0 ) ;
  }

  @Test
  public void test2063() {
    coral.tests.JPFBenchmark.benchmark02(61.35539682289763,17.743609428786783 ) ;
  }

  @Test
  public void test2064() {
    coral.tests.JPFBenchmark.benchmark02(-61.427581447288524,-0.4429431568664982 ) ;
  }

  @Test
  public void test2065() {
    coral.tests.JPFBenchmark.benchmark02(6.148581603492545,0.0 ) ;
  }

  @Test
  public void test2066() {
    coral.tests.JPFBenchmark.benchmark02(-6.162975822039155E-33,29.845252279415536 ) ;
  }

  @Test
  public void test2067() {
    coral.tests.JPFBenchmark.benchmark02(61.66027777877886,-176.45802552966643 ) ;
  }

  @Test
  public void test2068() {
    coral.tests.JPFBenchmark.benchmark02(-61.73914976037387,40.285734248677755 ) ;
  }

  @Test
  public void test2069() {
    coral.tests.JPFBenchmark.benchmark02(-61.8957321818747,2703.7657193548976 ) ;
  }

  @Test
  public void test2070() {
    coral.tests.JPFBenchmark.benchmark02(-61.912972494611715,-12.670135475851069 ) ;
  }

  @Test
  public void test2071() {
    coral.tests.JPFBenchmark.benchmark02(61.962100736245034,22.92676154322318 ) ;
  }

  @Test
  public void test2072() {
    coral.tests.JPFBenchmark.benchmark02(-62.02702246315709,-34.347970473592355 ) ;
  }

  @Test
  public void test2073() {
    coral.tests.JPFBenchmark.benchmark02(-62.048962977001544,-2579.861583741127 ) ;
  }

  @Test
  public void test2074() {
    coral.tests.JPFBenchmark.benchmark02(-62.0613616208908,-89.10058426553218 ) ;
  }

  @Test
  public void test2075() {
    coral.tests.JPFBenchmark.benchmark02(62.07631383743137,-0.33782570503337495 ) ;
  }

  @Test
  public void test2076() {
    coral.tests.JPFBenchmark.benchmark02(-62.08508661736101,-0.8240298724962993 ) ;
  }

  @Test
  public void test2077() {
    coral.tests.JPFBenchmark.benchmark02(-62.42933475490835,0.0 ) ;
  }

  @Test
  public void test2078() {
    coral.tests.JPFBenchmark.benchmark02(-62.493809587156335,22.702793002489855 ) ;
  }

  @Test
  public void test2079() {
    coral.tests.JPFBenchmark.benchmark02(-62.553311990407494,0 ) ;
  }

  @Test
  public void test2080() {
    coral.tests.JPFBenchmark.benchmark02(62.60523366655681,6.019045307601263 ) ;
  }

  @Test
  public void test2081() {
    coral.tests.JPFBenchmark.benchmark02(-62.66684942448828,-83.91407087416853 ) ;
  }

  @Test
  public void test2082() {
    coral.tests.JPFBenchmark.benchmark02(-62.69287247181985,0 ) ;
  }

  @Test
  public void test2083() {
    coral.tests.JPFBenchmark.benchmark02(62.72545542400016,-0.14342014937252523 ) ;
  }

  @Test
  public void test2084() {
    coral.tests.JPFBenchmark.benchmark02(62.80737575144732,-0.23494584779042263 ) ;
  }

  @Test
  public void test2085() {
    coral.tests.JPFBenchmark.benchmark02(-62.81414102966969,34.09489776863103 ) ;
  }

  @Test
  public void test2086() {
    coral.tests.JPFBenchmark.benchmark02(-62.82574699858059,11.198490475936612 ) ;
  }

  @Test
  public void test2087() {
    coral.tests.JPFBenchmark.benchmark02(6.282924449276074,92.67710535121658 ) ;
  }

  @Test
  public void test2088() {
    coral.tests.JPFBenchmark.benchmark02(6.283100688317749,-0.5707963045840635 ) ;
  }

  @Test
  public void test2089() {
    coral.tests.JPFBenchmark.benchmark02(6.28318519127073,-1.570796326726484 ) ;
  }

  @Test
  public void test2090() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185295552903,10.995574287555618 ) ;
  }

  @Test
  public void test2091() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185307079586,1.5707963267948966 ) ;
  }

  @Test
  public void test2092() {
    coral.tests.JPFBenchmark.benchmark02(6.28318530717953,-102.1011974813094 ) ;
  }

  @Test
  public void test2093() {
    coral.tests.JPFBenchmark.benchmark02(6.283185307179585,1.5707963267948963 ) ;
  }

  @Test
  public void test2094() {
    coral.tests.JPFBenchmark.benchmark02(62.831853071795855,1.5707963267948912 ) ;
  }

  @Test
  public void test2095() {
    coral.tests.JPFBenchmark.benchmark02(62.831853071795855,-1.5707963267948966 ) ;
  }

  @Test
  public void test2096() {
    coral.tests.JPFBenchmark.benchmark02(-6.283185307179632,1.570796326794903 ) ;
  }

  @Test
  public void test2097() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185307181042,-1.5707963267948915 ) ;
  }

  @Test
  public void test2098() {
    coral.tests.JPFBenchmark.benchmark02(-62.831853072039614,67.54424205251112 ) ;
  }

  @Test
  public void test2099() {
    coral.tests.JPFBenchmark.benchmark02(6.28318530727952,-1.5707963267949894 ) ;
  }

  @Test
  public void test2100() {
    coral.tests.JPFBenchmark.benchmark02(6.283185307301431,1.5707963267948966 ) ;
  }

  @Test
  public void test2101() {
    coral.tests.JPFBenchmark.benchmark02(-62.83185357985089,1.5707963267948966 ) ;
  }

  @Test
  public void test2102() {
    coral.tests.JPFBenchmark.benchmark02(-6.283200995680265,67.54424185657723 ) ;
  }

  @Test
  public void test2103() {
    coral.tests.JPFBenchmark.benchmark02(-62.83209721242166,0.0 ) ;
  }

  @Test
  public void test2104() {
    coral.tests.JPFBenchmark.benchmark02(-62.832098478361445,1.5707963267948966 ) ;
  }

  @Test
  public void test2105() {
    coral.tests.JPFBenchmark.benchmark02(-6.283235034329736,1.5707963267948974 ) ;
  }

  @Test
  public void test2106() {
    coral.tests.JPFBenchmark.benchmark02(6.284161869679589,-1.5707963267948966 ) ;
  }

  @Test
  public void test2107() {
    coral.tests.JPFBenchmark.benchmark02(-6.284161869679856,-70.6854635883867 ) ;
  }

  @Test
  public void test2108() {
    coral.tests.JPFBenchmark.benchmark02(-6.2841619940338935,-73.82742722295954 ) ;
  }

  @Test
  public void test2109() {
    coral.tests.JPFBenchmark.benchmark02(-6.2841620092278765,1.5707963782822034 ) ;
  }

  @Test
  public void test2110() {
    coral.tests.JPFBenchmark.benchmark02(62.86246738792573,1.5707963267948948 ) ;
  }

  @Test
  public void test2111() {
    coral.tests.JPFBenchmark.benchmark02(6.287091557210494,1.5707963267948966 ) ;
  }

  @Test
  public void test2112() {
    coral.tests.JPFBenchmark.benchmark02(-62.892723873224426,-100.0 ) ;
  }

  @Test
  public void test2113() {
    coral.tests.JPFBenchmark.benchmark02(62.91096104892304,-76.7483786212279 ) ;
  }

  @Test
  public void test2114() {
    coral.tests.JPFBenchmark.benchmark02(62.928366055827624,1.5707963267948966 ) ;
  }

  @Test
  public void test2115() {
    coral.tests.JPFBenchmark.benchmark02(-62.940575127018825,-2.5267654674455002 ) ;
  }

  @Test
  public void test2116() {
    coral.tests.JPFBenchmark.benchmark02(-62.9490902330716,-77.24789090441709 ) ;
  }

  @Test
  public void test2117() {
    coral.tests.JPFBenchmark.benchmark02(62.95025600991853,-37.81285605657572 ) ;
  }

  @Test
  public void test2118() {
    coral.tests.JPFBenchmark.benchmark02(-6.298810307180089,4.712388607775981 ) ;
  }

  @Test
  public void test2119() {
    coral.tests.JPFBenchmark.benchmark02(-63.063590377487856,28.18061664250564 ) ;
  }

  @Test
  public void test2120() {
    coral.tests.JPFBenchmark.benchmark02(-6.3108872417680944E-30,1.5707963267948966 ) ;
  }

  @Test
  public void test2121() {
    coral.tests.JPFBenchmark.benchmark02(6.31516062243702,-32.97094064956103 ) ;
  }

  @Test
  public void test2122() {
    coral.tests.JPFBenchmark.benchmark02(-63.161913406504894,64.7327097334055 ) ;
  }

  @Test
  public void test2123() {
    coral.tests.JPFBenchmark.benchmark02(63.229680280485766,-1.5707963267948966 ) ;
  }

  @Test
  public void test2124() {
    coral.tests.JPFBenchmark.benchmark02(63.26078842288997,1.5707963267948966 ) ;
  }

  @Test
  public void test2125() {
    coral.tests.JPFBenchmark.benchmark02(-63.26716710108264,-68.61577822169582 ) ;
  }

  @Test
  public void test2126() {
    coral.tests.JPFBenchmark.benchmark02(-6.331595014908668,-6.433291189488529 ) ;
  }

  @Test
  public void test2127() {
    coral.tests.JPFBenchmark.benchmark02(6.337893963714239,-73.86961975647718 ) ;
  }

  @Test
  public void test2128() {
    coral.tests.JPFBenchmark.benchmark02(63.38295346242711,0.0 ) ;
  }

  @Test
  public void test2129() {
    coral.tests.JPFBenchmark.benchmark02(-63.434982874453645,-73.26899688490793 ) ;
  }

  @Test
  public void test2130() {
    coral.tests.JPFBenchmark.benchmark02(63.62578303432026,-74.4648590910631 ) ;
  }

  @Test
  public void test2131() {
    coral.tests.JPFBenchmark.benchmark02(6.362977003976593,-143.02212005355233 ) ;
  }

  @Test
  public void test2132() {
    coral.tests.JPFBenchmark.benchmark02(-63.6351272348183,0.0 ) ;
  }

  @Test
  public void test2133() {
    coral.tests.JPFBenchmark.benchmark02(-63.647351331078994,-45.86547847579689 ) ;
  }

  @Test
  public void test2134() {
    coral.tests.JPFBenchmark.benchmark02(-63.913987094341174,120.82349317534201 ) ;
  }

  @Test
  public void test2135() {
    coral.tests.JPFBenchmark.benchmark02(-63.931606984302626,72.40470444267321 ) ;
  }

  @Test
  public void test2136() {
    coral.tests.JPFBenchmark.benchmark02(-63.993994275511156,70.35394119074911 ) ;
  }

  @Test
  public void test2137() {
    coral.tests.JPFBenchmark.benchmark02(64.0039400158768,26.967704967907054 ) ;
  }

  @Test
  public void test2138() {
    coral.tests.JPFBenchmark.benchmark02(64.07755086704577,-36.462658698828434 ) ;
  }

  @Test
  public void test2139() {
    coral.tests.JPFBenchmark.benchmark02(64.09417807737321,-1.5707963267949054 ) ;
  }

  @Test
  public void test2140() {
    coral.tests.JPFBenchmark.benchmark02(-64.27646036497903,-53.301463373465864 ) ;
  }

  @Test
  public void test2141() {
    coral.tests.JPFBenchmark.benchmark02(-64.29794882633925,-1.5707963267948972 ) ;
  }

  @Test
  public void test2142() {
    coral.tests.JPFBenchmark.benchmark02(64.29989210484709,2628.43385864549 ) ;
  }

  @Test
  public void test2143() {
    coral.tests.JPFBenchmark.benchmark02(-64.33673139321125,-99.9150057283626 ) ;
  }

  @Test
  public void test2144() {
    coral.tests.JPFBenchmark.benchmark02(-64.51377037679411,-15.477520457380336 ) ;
  }

  @Test
  public void test2145() {
    coral.tests.JPFBenchmark.benchmark02(-64.61496097833512,1.5707963267948966 ) ;
  }

  @Test
  public void test2146() {
    coral.tests.JPFBenchmark.benchmark02(6.461902263008527,11.465042198375613 ) ;
  }

  @Test
  public void test2147() {
    coral.tests.JPFBenchmark.benchmark02(-6.476545961842539,1.5707963267948961 ) ;
  }

  @Test
  public void test2148() {
    coral.tests.JPFBenchmark.benchmark02(6.479951972848787E-13,54.97787143772203 ) ;
  }

  @Test
  public void test2149() {
    coral.tests.JPFBenchmark.benchmark02(-64.88939768187643,76.24538576853385 ) ;
  }

  @Test
  public void test2150() {
    coral.tests.JPFBenchmark.benchmark02(-64.96469894400325,0.0 ) ;
  }

  @Test
  public void test2151() {
    coral.tests.JPFBenchmark.benchmark02(-65.02418822973738,-25.33143615932684 ) ;
  }

  @Test
  public void test2152() {
    coral.tests.JPFBenchmark.benchmark02(65.18581562505855,-1.2347126051073243 ) ;
  }

  @Test
  public void test2153() {
    coral.tests.JPFBenchmark.benchmark02(65.21336726468033,-44.713786286171576 ) ;
  }

  @Test
  public void test2154() {
    coral.tests.JPFBenchmark.benchmark02(6.525378465815493,79.83465355770417 ) ;
  }

  @Test
  public void test2155() {
    coral.tests.JPFBenchmark.benchmark02(65.28949754986729,54.97787144058142 ) ;
  }

  @Test
  public void test2156() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179587,39.09092239822918 ) ;
  }

  @Test
  public void test2157() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179588,20.171886852373778 ) ;
  }

  @Test
  public void test2158() {
    coral.tests.JPFBenchmark.benchmark02(-6.533185307179588,-73.57898831156658 ) ;
  }

  @Test
  public void test2159() {
    coral.tests.JPFBenchmark.benchmark02(6.533185307179715,-20.41053941689382 ) ;
  }

  @Test
  public void test2160() {
    coral.tests.JPFBenchmark.benchmark02(6.5331874841183595,29.93222731433028 ) ;
  }

  @Test
  public void test2161() {
    coral.tests.JPFBenchmark.benchmark02(-6.533427096020983,-86.39376001026034 ) ;
  }

  @Test
  public void test2162() {
    coral.tests.JPFBenchmark.benchmark02(-6.537122353845541,-26.957474172684098 ) ;
  }

  @Test
  public void test2163() {
    coral.tests.JPFBenchmark.benchmark02(-65.40532068136126,27.271662599656278 ) ;
  }

  @Test
  public void test2164() {
    coral.tests.JPFBenchmark.benchmark02(-65.51481790732316,-25.836614690070533 ) ;
  }

  @Test
  public void test2165() {
    coral.tests.JPFBenchmark.benchmark02(-65.59097588292335,45.01146015445644 ) ;
  }

  @Test
  public void test2166() {
    coral.tests.JPFBenchmark.benchmark02(-65.64550232823069,-100.83280638170459 ) ;
  }

  @Test
  public void test2167() {
    coral.tests.JPFBenchmark.benchmark02(6.5691639931187815,0.35480617268752834 ) ;
  }

  @Test
  public void test2168() {
    coral.tests.JPFBenchmark.benchmark02(65.81224548485622,-45.51898527340485 ) ;
  }

  @Test
  public void test2169() {
    coral.tests.JPFBenchmark.benchmark02(65.91370911502673,97.4740375353997 ) ;
  }

  @Test
  public void test2170() {
    coral.tests.JPFBenchmark.benchmark02(65.9313384532467,-6.474717059315965 ) ;
  }

  @Test
  public void test2171() {
    coral.tests.JPFBenchmark.benchmark02(65.97344161219162,4.71238898038467 ) ;
  }

  @Test
  public void test2172() {
    coral.tests.JPFBenchmark.benchmark02(65.9734424963233,89.53545166635956 ) ;
  }

  @Test
  public void test2173() {
    coral.tests.JPFBenchmark.benchmark02(65.97344570818217,-86.39379797337874 ) ;
  }

  @Test
  public void test2174() {
    coral.tests.JPFBenchmark.benchmark02(65.9734457252975,54.97787143780955 ) ;
  }

  @Test
  public void test2175() {
    coral.tests.JPFBenchmark.benchmark02(65.9734457254031,1.5707963267948966 ) ;
  }

  @Test
  public void test2176() {
    coral.tests.JPFBenchmark.benchmark02(65.97344578499599,-1.5707963267948966 ) ;
  }

  @Test
  public void test2177() {
    coral.tests.JPFBenchmark.benchmark02(65.97344596380424,-1.5707963267948966 ) ;
  }

  @Test
  public void test2178() {
    coral.tests.JPFBenchmark.benchmark02(65.97344607690259,-1.5707963201328214 ) ;
  }

  @Test
  public void test2179() {
    coral.tests.JPFBenchmark.benchmark02(-65.97344763273429,1.5707963267948977 ) ;
  }

  @Test
  public void test2180() {
    coral.tests.JPFBenchmark.benchmark02(65.97347729772014,25.22054539493486 ) ;
  }

  @Test
  public void test2181() {
    coral.tests.JPFBenchmark.benchmark02(65.97351222409729,64.40264615872285 ) ;
  }

  @Test
  public void test2182() {
    coral.tests.JPFBenchmark.benchmark02(65.97393400663617,-1.5707963267948966 ) ;
  }

  @Test
  public void test2183() {
    coral.tests.JPFBenchmark.benchmark02(-65.98125823011114,17.278759500057475 ) ;
  }

  @Test
  public void test2184() {
    coral.tests.JPFBenchmark.benchmark02(66.05412030865628,-26.78421213888419 ) ;
  }

  @Test
  public void test2185() {
    coral.tests.JPFBenchmark.benchmark02(66.06264353863817,0.0 ) ;
  }

  @Test
  public void test2186() {
    coral.tests.JPFBenchmark.benchmark02(66.16075827396568,-0.3814374303860909 ) ;
  }

  @Test
  public void test2187() {
    coral.tests.JPFBenchmark.benchmark02(-66.22344572466946,11.245574288831907 ) ;
  }

  @Test
  public void test2188() {
    coral.tests.JPFBenchmark.benchmark02(-66.32145929421225,-2640.916404351042 ) ;
  }

  @Test
  public void test2189() {
    coral.tests.JPFBenchmark.benchmark02(66.32786417562514,2623.65376833287 ) ;
  }

  @Test
  public void test2190() {
    coral.tests.JPFBenchmark.benchmark02(66.3644117763559,96.45066215699242 ) ;
  }

  @Test
  public void test2191() {
    coral.tests.JPFBenchmark.benchmark02(6.639070810526903,-80.14583691317081 ) ;
  }

  @Test
  public void test2192() {
    coral.tests.JPFBenchmark.benchmark02(66.63729439209007,68.73514291396532 ) ;
  }

  @Test
  public void test2193() {
    coral.tests.JPFBenchmark.benchmark02(66.67306670550812,-22.0826924549245 ) ;
  }

  @Test
  public void test2194() {
    coral.tests.JPFBenchmark.benchmark02(66.81141822800066,-31.91994328810661 ) ;
  }

  @Test
  public void test2195() {
    coral.tests.JPFBenchmark.benchmark02(-66.82052726728978,8.881991759006638 ) ;
  }

  @Test
  public void test2196() {
    coral.tests.JPFBenchmark.benchmark02(66.86005136039716,-146.363126976226 ) ;
  }

  @Test
  public void test2197() {
    coral.tests.JPFBenchmark.benchmark02(66.92896778992579,0.0 ) ;
  }

  @Test
  public void test2198() {
    coral.tests.JPFBenchmark.benchmark02(-6.698100123970087,-89.95030544420888 ) ;
  }

  @Test
  public void test2199() {
    coral.tests.JPFBenchmark.benchmark02(-66.9999150199502,88.14754149041465 ) ;
  }

  @Test
  public void test2200() {
    coral.tests.JPFBenchmark.benchmark02(-67.02782375841892,1.5707963267948983 ) ;
  }

  @Test
  public void test2201() {
    coral.tests.JPFBenchmark.benchmark02(67.17913334514976,41.20581320341803 ) ;
  }

  @Test
  public void test2202() {
    coral.tests.JPFBenchmark.benchmark02(-67.26223257840368,58.06715396874353 ) ;
  }

  @Test
  public void test2203() {
    coral.tests.JPFBenchmark.benchmark02(-67.29461189685298,0.5706136446554068 ) ;
  }

  @Test
  public void test2204() {
    coral.tests.JPFBenchmark.benchmark02(-67.49279025938057,-14.42920367427196 ) ;
  }

  @Test
  public void test2205() {
    coral.tests.JPFBenchmark.benchmark02(6.758006649133123,-80.21226999651721 ) ;
  }

  @Test
  public void test2206() {
    coral.tests.JPFBenchmark.benchmark02(-67.61214254841691,0.0 ) ;
  }

  @Test
  public void test2207() {
    coral.tests.JPFBenchmark.benchmark02(67.63037233074957,56.2390153812845 ) ;
  }

  @Test
  public void test2208() {
    coral.tests.JPFBenchmark.benchmark02(-67.63426154417743,-0.09001949310908106 ) ;
  }

  @Test
  public void test2209() {
    coral.tests.JPFBenchmark.benchmark02(67.67834629016275,-8.012551962586542 ) ;
  }

  @Test
  public void test2210() {
    coral.tests.JPFBenchmark.benchmark02(67.7270440894437,-56.24346484697411 ) ;
  }

  @Test
  public void test2211() {
    coral.tests.JPFBenchmark.benchmark02(67.85328607654075,-73.81563178283591 ) ;
  }

  @Test
  public void test2212() {
    coral.tests.JPFBenchmark.benchmark02(-67.90201590430922,1.5707963267948968 ) ;
  }

  @Test
  public void test2213() {
    coral.tests.JPFBenchmark.benchmark02(68.04417231984964,-1.5707963267948966 ) ;
  }

  @Test
  public void test2214() {
    coral.tests.JPFBenchmark.benchmark02(-68.0982948220378,-40.17575543879111 ) ;
  }

  @Test
  public void test2215() {
    coral.tests.JPFBenchmark.benchmark02(68.25719236443575,-8.347198588558048E-11 ) ;
  }

  @Test
  public void test2216() {
    coral.tests.JPFBenchmark.benchmark02(68.25950026077874,-1.5707963267948972 ) ;
  }

  @Test
  public void test2217() {
    coral.tests.JPFBenchmark.benchmark02(-68.26748736907484,32.62633851715898 ) ;
  }

  @Test
  public void test2218() {
    coral.tests.JPFBenchmark.benchmark02(-6.838280724307609,-3.3158315205426163 ) ;
  }

  @Test
  public void test2219() {
    coral.tests.JPFBenchmark.benchmark02(68.41166765587997,0.0 ) ;
  }

  @Test
  public void test2220() {
    coral.tests.JPFBenchmark.benchmark02(-68.43386270493579,2617.6510767237987 ) ;
  }

  @Test
  public void test2221() {
    coral.tests.JPFBenchmark.benchmark02(-68.84747236189325,3.2131921225994144 ) ;
  }

  @Test
  public void test2222() {
    coral.tests.JPFBenchmark.benchmark02(68.88818868387334,-83.34844475731046 ) ;
  }

  @Test
  public void test2223() {
    coral.tests.JPFBenchmark.benchmark02(-6.892528248626176,-10.863200058678824 ) ;
  }

  @Test
  public void test2224() {
    coral.tests.JPFBenchmark.benchmark02(-68.93189874074858,-40.16661680472004 ) ;
  }

  @Test
  public void test2225() {
    coral.tests.JPFBenchmark.benchmark02(68.93758866600203,9.970329312012032 ) ;
  }

  @Test
  public void test2226() {
    coral.tests.JPFBenchmark.benchmark02(-68.95849170726825,-1.5707963267949054 ) ;
  }

  @Test
  public void test2227() {
    coral.tests.JPFBenchmark.benchmark02(68.96774582475035,-54.63449780337095 ) ;
  }

  @Test
  public void test2228() {
    coral.tests.JPFBenchmark.benchmark02(-69.03605200996729,-45.80316437481493 ) ;
  }

  @Test
  public void test2229() {
    coral.tests.JPFBenchmark.benchmark02(-69.04920933084344,-45.445278930751606 ) ;
  }

  @Test
  public void test2230() {
    coral.tests.JPFBenchmark.benchmark02(69.0773199667849,-16.555376380026487 ) ;
  }

  @Test
  public void test2231() {
    coral.tests.JPFBenchmark.benchmark02(69.11098158365334,0.0 ) ;
  }

  @Test
  public void test2232() {
    coral.tests.JPFBenchmark.benchmark02(69.1142273875925,0.5705518395881249 ) ;
  }

  @Test
  public void test2233() {
    coral.tests.JPFBenchmark.benchmark02(-69.11503837747534,-17.278759403055506 ) ;
  }

  @Test
  public void test2234() {
    coral.tests.JPFBenchmark.benchmark02(69.11503837897543,0.0 ) ;
  }

  @Test
  public void test2235() {
    coral.tests.JPFBenchmark.benchmark02(69.11503885581261,-1.5707963267948977 ) ;
  }

  @Test
  public void test2236() {
    coral.tests.JPFBenchmark.benchmark02(-69.11504302366103,0 ) ;
  }

  @Test
  public void test2237() {
    coral.tests.JPFBenchmark.benchmark02(-69.14987218087653,-20.29319918148387 ) ;
  }

  @Test
  public void test2238() {
    coral.tests.JPFBenchmark.benchmark02(-69.20155559116844,-30.68926625967765 ) ;
  }

  @Test
  public void test2239() {
    coral.tests.JPFBenchmark.benchmark02(69.21712330391262,0.0 ) ;
  }

  @Test
  public void test2240() {
    coral.tests.JPFBenchmark.benchmark02(69.29745108319503,0.26444500657693937 ) ;
  }

  @Test
  public void test2241() {
    coral.tests.JPFBenchmark.benchmark02(6.937972310878639,-51.18149178065861 ) ;
  }

  @Test
  public void test2242() {
    coral.tests.JPFBenchmark.benchmark02(-6.938893903907228E-18,-1.5707952470296955 ) ;
  }

  @Test
  public void test2243() {
    coral.tests.JPFBenchmark.benchmark02(6.938893903907228E-18,1.5707963267948966 ) ;
  }

  @Test
  public void test2244() {
    coral.tests.JPFBenchmark.benchmark02(-69.38922730136107,-9.83216416523338 ) ;
  }

  @Test
  public void test2245() {
    coral.tests.JPFBenchmark.benchmark02(-69.4229405537473,0.0 ) ;
  }

  @Test
  public void test2246() {
    coral.tests.JPFBenchmark.benchmark02(69.42782137560381,-1.2580133302716345 ) ;
  }

  @Test
  public void test2247() {
    coral.tests.JPFBenchmark.benchmark02(-69.50296549327317,53.244799997081174 ) ;
  }

  @Test
  public void test2248() {
    coral.tests.JPFBenchmark.benchmark02(6.954487440902611,0 ) ;
  }

  @Test
  public void test2249() {
    coral.tests.JPFBenchmark.benchmark02(69.6798450294169,0.0 ) ;
  }

  @Test
  public void test2250() {
    coral.tests.JPFBenchmark.benchmark02(69.68006735027404,-74.10793451846658 ) ;
  }

  @Test
  public void test2251() {
    coral.tests.JPFBenchmark.benchmark02(69.7880056540589,-33.213134287035984 ) ;
  }

  @Test
  public void test2252() {
    coral.tests.JPFBenchmark.benchmark02(-69.79382984470656,0.0 ) ;
  }

  @Test
  public void test2253() {
    coral.tests.JPFBenchmark.benchmark02(69.88880804799803,0 ) ;
  }

  @Test
  public void test2254() {
    coral.tests.JPFBenchmark.benchmark02(-69.98870445308427,0.0 ) ;
  }

  @Test
  public void test2255() {
    coral.tests.JPFBenchmark.benchmark02(-70.07274268776831,1.5707963267948966 ) ;
  }

  @Test
  public void test2256() {
    coral.tests.JPFBenchmark.benchmark02(70.1010060175454,57.55411151078553 ) ;
  }

  @Test
  public void test2257() {
    coral.tests.JPFBenchmark.benchmark02(-70.13208867342352,-53.902009588093435 ) ;
  }

  @Test
  public void test2258() {
    coral.tests.JPFBenchmark.benchmark02(-70.13372059834808,-2.589478546358184 ) ;
  }

  @Test
  public void test2259() {
    coral.tests.JPFBenchmark.benchmark02(-70.15581219529169,38.772592539187116 ) ;
  }

  @Test
  public void test2260() {
    coral.tests.JPFBenchmark.benchmark02(7.0157815989523264,51.001719157488026 ) ;
  }

  @Test
  public void test2261() {
    coral.tests.JPFBenchmark.benchmark02(70.20164533934096,9.563256097978439 ) ;
  }

  @Test
  public void test2262() {
    coral.tests.JPFBenchmark.benchmark02(7.021469776313014,51.097994315233365 ) ;
  }

  @Test
  public void test2263() {
    coral.tests.JPFBenchmark.benchmark02(70.27904225693007,-163.65011123235627 ) ;
  }

  @Test
  public void test2264() {
    coral.tests.JPFBenchmark.benchmark02(-70.28086043450405,-14.429619820735176 ) ;
  }

  @Test
  public void test2265() {
    coral.tests.JPFBenchmark.benchmark02(70.30529029784964,-11.179201193088034 ) ;
  }

  @Test
  public void test2266() {
    coral.tests.JPFBenchmark.benchmark02(70.36534959945357,0 ) ;
  }

  @Test
  public void test2267() {
    coral.tests.JPFBenchmark.benchmark02(7.037158941826094E-15,-92.67698328079891 ) ;
  }

  @Test
  public void test2268() {
    coral.tests.JPFBenchmark.benchmark02(-70.3883079754259,0.2102511093630542 ) ;
  }

  @Test
  public void test2269() {
    coral.tests.JPFBenchmark.benchmark02(-7.039669746810096,-73.07094291959213 ) ;
  }

  @Test
  public void test2270() {
    coral.tests.JPFBenchmark.benchmark02(70.46851388852511,93.76642503270062 ) ;
  }

  @Test
  public void test2271() {
    coral.tests.JPFBenchmark.benchmark02(70.47668006580263,38.8338139699776 ) ;
  }

  @Test
  public void test2272() {
    coral.tests.JPFBenchmark.benchmark02(70.49701791691447,-31.76915552933312 ) ;
  }

  @Test
  public void test2273() {
    coral.tests.JPFBenchmark.benchmark02(70.5238696598939,-135.35283108728902 ) ;
  }

  @Test
  public void test2274() {
    coral.tests.JPFBenchmark.benchmark02(-70.57521022842221,70.95393010553386 ) ;
  }

  @Test
  public void test2275() {
    coral.tests.JPFBenchmark.benchmark02(-70.57603192037776,-182.6401566936611 ) ;
  }

  @Test
  public void test2276() {
    coral.tests.JPFBenchmark.benchmark02(70.60043098806707,0.0 ) ;
  }

  @Test
  public void test2277() {
    coral.tests.JPFBenchmark.benchmark02(70.6057172121927,-41.53895454440143 ) ;
  }

  @Test
  public void test2278() {
    coral.tests.JPFBenchmark.benchmark02(7.0614534107259495,-36.90658361968856 ) ;
  }

  @Test
  public void test2279() {
    coral.tests.JPFBenchmark.benchmark02(-70.62648976290565,0.0 ) ;
  }

  @Test
  public void test2280() {
    coral.tests.JPFBenchmark.benchmark02(70.66317256130458,12.159667805317609 ) ;
  }

  @Test
  public void test2281() {
    coral.tests.JPFBenchmark.benchmark02(-70.67312977682381,22.00385349621795 ) ;
  }

  @Test
  public void test2282() {
    coral.tests.JPFBenchmark.benchmark02(-70.72882505549939,0.0 ) ;
  }

  @Test
  public void test2283() {
    coral.tests.JPFBenchmark.benchmark02(70.74773915233844,1.678858351115366 ) ;
  }

  @Test
  public void test2284() {
    coral.tests.JPFBenchmark.benchmark02(70.76217790142792,0.520084781342277 ) ;
  }

  @Test
  public void test2285() {
    coral.tests.JPFBenchmark.benchmark02(70.82793002181768,-4.8367514328868844E-8 ) ;
  }

  @Test
  public void test2286() {
    coral.tests.JPFBenchmark.benchmark02(-7.0921670575412525,121.76029891371358 ) ;
  }

  @Test
  public void test2287() {
    coral.tests.JPFBenchmark.benchmark02(70.9369029601414,42.28141087672665 ) ;
  }

  @Test
  public void test2288() {
    coral.tests.JPFBenchmark.benchmark02(70.93733918515363,93.73713171587286 ) ;
  }

  @Test
  public void test2289() {
    coral.tests.JPFBenchmark.benchmark02(-70.94523016658054,47.43653611184092 ) ;
  }

  @Test
  public void test2290() {
    coral.tests.JPFBenchmark.benchmark02(-71.06129548331374,38.84481570971286 ) ;
  }

  @Test
  public void test2291() {
    coral.tests.JPFBenchmark.benchmark02(7.114747045441548,1.5707963267948966 ) ;
  }

  @Test
  public void test2292() {
    coral.tests.JPFBenchmark.benchmark02(-71.18204963769372,-66.99633294238996 ) ;
  }

  @Test
  public void test2293() {
    coral.tests.JPFBenchmark.benchmark02(71.21679962044625,100.0 ) ;
  }

  @Test
  public void test2294() {
    coral.tests.JPFBenchmark.benchmark02(71.30248070385878,-70.27267379799096 ) ;
  }

  @Test
  public void test2295() {
    coral.tests.JPFBenchmark.benchmark02(71.33453235421221,0.0 ) ;
  }

  @Test
  public void test2296() {
    coral.tests.JPFBenchmark.benchmark02(71.34765744580805,-1.570809585252164 ) ;
  }

  @Test
  public void test2297() {
    coral.tests.JPFBenchmark.benchmark02(71.35802242244108,-0.582879686807748 ) ;
  }

  @Test
  public void test2298() {
    coral.tests.JPFBenchmark.benchmark02(-71.36017368904518,-23.574567201891135 ) ;
  }

  @Test
  public void test2299() {
    coral.tests.JPFBenchmark.benchmark02(7.154195216967831E-19,1.5707963269113316 ) ;
  }

  @Test
  public void test2300() {
    coral.tests.JPFBenchmark.benchmark02(-7.167280768220172,-1.5707963267948966 ) ;
  }

  @Test
  public void test2301() {
    coral.tests.JPFBenchmark.benchmark02(-71.70135501090735,0.0 ) ;
  }

  @Test
  public void test2302() {
    coral.tests.JPFBenchmark.benchmark02(71.72448218689983,-13.605018095604706 ) ;
  }

  @Test
  public void test2303() {
    coral.tests.JPFBenchmark.benchmark02(71.75147563858718,-74.33258275322393 ) ;
  }

  @Test
  public void test2304() {
    coral.tests.JPFBenchmark.benchmark02(71.85116744714703,-5.212388980384691 ) ;
  }

  @Test
  public void test2305() {
    coral.tests.JPFBenchmark.benchmark02(-71.87375999972998,-11.14062277278913 ) ;
  }

  @Test
  public void test2306() {
    coral.tests.JPFBenchmark.benchmark02(71.89740995149066,106.93947690239918 ) ;
  }

  @Test
  public void test2307() {
    coral.tests.JPFBenchmark.benchmark02(-71.96575858291999,53.23937979863081 ) ;
  }

  @Test
  public void test2308() {
    coral.tests.JPFBenchmark.benchmark02(72.04364905226566,0.0 ) ;
  }

  @Test
  public void test2309() {
    coral.tests.JPFBenchmark.benchmark02(-7.218144277902951,4.49917381237297 ) ;
  }

  @Test
  public void test2310() {
    coral.tests.JPFBenchmark.benchmark02(72.2566309019561,45.553093961339684 ) ;
  }

  @Test
  public void test2311() {
    coral.tests.JPFBenchmark.benchmark02(-72.25663103256522,0.0 ) ;
  }

  @Test
  public void test2312() {
    coral.tests.JPFBenchmark.benchmark02(72.2566310327981,0.0 ) ;
  }

  @Test
  public void test2313() {
    coral.tests.JPFBenchmark.benchmark02(72.25663103376236,-1.5707963267948957 ) ;
  }

  @Test
  public void test2314() {
    coral.tests.JPFBenchmark.benchmark02(72.25663150940247,-1.5707963267948966 ) ;
  }

  @Test
  public void test2315() {
    coral.tests.JPFBenchmark.benchmark02(72.25669061024551,-10.995574296751986 ) ;
  }

  @Test
  public void test2316() {
    coral.tests.JPFBenchmark.benchmark02(-72.25760759541396,-42.41150082316608 ) ;
  }

  @Test
  public void test2317() {
    coral.tests.JPFBenchmark.benchmark02(7.228164809298162,80.00021427747913 ) ;
  }

  @Test
  public void test2318() {
    coral.tests.JPFBenchmark.benchmark02(72.30941384327252,-52.76986207832097 ) ;
  }

  @Test
  public void test2319() {
    coral.tests.JPFBenchmark.benchmark02(-72.3161930722927,45.03995994157276 ) ;
  }

  @Test
  public void test2320() {
    coral.tests.JPFBenchmark.benchmark02(72.33211209688062,-48.295228690199885 ) ;
  }

  @Test
  public void test2321() {
    coral.tests.JPFBenchmark.benchmark02(-72.37699568075817,10.767024761061077 ) ;
  }

  @Test
  public void test2322() {
    coral.tests.JPFBenchmark.benchmark02(-72.38360638080334,-26.133370410585243 ) ;
  }

  @Test
  public void test2323() {
    coral.tests.JPFBenchmark.benchmark02(-72.4169450740856,-2.5894962160312057E-6 ) ;
  }

  @Test
  public void test2324() {
    coral.tests.JPFBenchmark.benchmark02(-72.46146624744345,-103.09602839840613 ) ;
  }

  @Test
  public void test2325() {
    coral.tests.JPFBenchmark.benchmark02(-72.47380587207901,-39.872332088651 ) ;
  }

  @Test
  public void test2326() {
    coral.tests.JPFBenchmark.benchmark02(72.48491654354169,-57.743569063525335 ) ;
  }

  @Test
  public void test2327() {
    coral.tests.JPFBenchmark.benchmark02(72.48568553214899,0.0 ) ;
  }

  @Test
  public void test2328() {
    coral.tests.JPFBenchmark.benchmark02(72.49755662205001,14.810527681133221 ) ;
  }

  @Test
  public void test2329() {
    coral.tests.JPFBenchmark.benchmark02(-72.64058724945862,-5.096345197170212 ) ;
  }

  @Test
  public void test2330() {
    coral.tests.JPFBenchmark.benchmark02(72.65629021888435,-2618.328799659656 ) ;
  }

  @Test
  public void test2331() {
    coral.tests.JPFBenchmark.benchmark02(-72.71563531215325,68.00324633165702 ) ;
  }

  @Test
  public void test2332() {
    coral.tests.JPFBenchmark.benchmark02(72.72736639876872,1.5707963267948966 ) ;
  }

  @Test
  public void test2333() {
    coral.tests.JPFBenchmark.benchmark02(-72.74300700948993,95.64446022623821 ) ;
  }

  @Test
  public void test2334() {
    coral.tests.JPFBenchmark.benchmark02(-72.78641179830973,-74.3680251586021 ) ;
  }

  @Test
  public void test2335() {
    coral.tests.JPFBenchmark.benchmark02(-72.80109351639854,19.875889764617266 ) ;
  }

  @Test
  public void test2336() {
    coral.tests.JPFBenchmark.benchmark02(72.84865854227651,1.5707963267948966 ) ;
  }

  @Test
  public void test2337() {
    coral.tests.JPFBenchmark.benchmark02(-7.286041196041637,-32.986202587121085 ) ;
  }

  @Test
  public void test2338() {
    coral.tests.JPFBenchmark.benchmark02(-73.07317030649412,44.98262481653114 ) ;
  }

  @Test
  public void test2339() {
    coral.tests.JPFBenchmark.benchmark02(73.10104910264187,-1.5707963267948966 ) ;
  }

  @Test
  public void test2340() {
    coral.tests.JPFBenchmark.benchmark02(73.13345283730112,52.71310058912381 ) ;
  }

  @Test
  public void test2341() {
    coral.tests.JPFBenchmark.benchmark02(-73.16443815287171,88.28505506002264 ) ;
  }

  @Test
  public void test2342() {
    coral.tests.JPFBenchmark.benchmark02(-73.20732782773202,-1.5707963267948957 ) ;
  }

  @Test
  public void test2343() {
    coral.tests.JPFBenchmark.benchmark02(-73.21781787085445,-12.811435326714388 ) ;
  }

  @Test
  public void test2344() {
    coral.tests.JPFBenchmark.benchmark02(-73.22043080078227,29.216371379145613 ) ;
  }

  @Test
  public void test2345() {
    coral.tests.JPFBenchmark.benchmark02(73.24175560077524,5.551115123125783E-17 ) ;
  }

  @Test
  public void test2346() {
    coral.tests.JPFBenchmark.benchmark02(-73.27479081645698,-1.555545648729649 ) ;
  }

  @Test
  public void test2347() {
    coral.tests.JPFBenchmark.benchmark02(73.3220541695375,-51.155820325588785 ) ;
  }

  @Test
  public void test2348() {
    coral.tests.JPFBenchmark.benchmark02(73.34311226202735,-1.5707963267948966 ) ;
  }

  @Test
  public void test2349() {
    coral.tests.JPFBenchmark.benchmark02(73.37296367474579,-9.494107596574928E-16 ) ;
  }

  @Test
  public void test2350() {
    coral.tests.JPFBenchmark.benchmark02(73.47691613545433,1.5707963267948974 ) ;
  }

  @Test
  public void test2351() {
    coral.tests.JPFBenchmark.benchmark02(-73.58578603245786,0.0 ) ;
  }

  @Test
  public void test2352() {
    coral.tests.JPFBenchmark.benchmark02(73.58719475948351,-14.43129039117688 ) ;
  }

  @Test
  public void test2353() {
    coral.tests.JPFBenchmark.benchmark02(73.60427822504445,129.02844793104535 ) ;
  }

  @Test
  public void test2354() {
    coral.tests.JPFBenchmark.benchmark02(73.68547211218238,32.82175986552663 ) ;
  }

  @Test
  public void test2355() {
    coral.tests.JPFBenchmark.benchmark02(73.77216499300366,2580.916135174311 ) ;
  }

  @Test
  public void test2356() {
    coral.tests.JPFBenchmark.benchmark02(73.81957002807829,94.68568317539061 ) ;
  }

  @Test
  public void test2357() {
    coral.tests.JPFBenchmark.benchmark02(7.3933281469373355,-2.8886647155796936 ) ;
  }

  @Test
  public void test2358() {
    coral.tests.JPFBenchmark.benchmark02(73.9365080641515,1.2505716658958406 ) ;
  }

  @Test
  public void test2359() {
    coral.tests.JPFBenchmark.benchmark02(7.400967513625972,-29.665753878500396 ) ;
  }

  @Test
  public void test2360() {
    coral.tests.JPFBenchmark.benchmark02(-74.14162855126688,66.79725919806012 ) ;
  }

  @Test
  public void test2361() {
    coral.tests.JPFBenchmark.benchmark02(-74.14970235679937,88.28686929826361 ) ;
  }

  @Test
  public void test2362() {
    coral.tests.JPFBenchmark.benchmark02(74.40986017355885,16.963332075661814 ) ;
  }

  @Test
  public void test2363() {
    coral.tests.JPFBenchmark.benchmark02(-74.41006070270268,44.15572904981056 ) ;
  }

  @Test
  public void test2364() {
    coral.tests.JPFBenchmark.benchmark02(-74.46430669828739,-60.685637451267915 ) ;
  }

  @Test
  public void test2365() {
    coral.tests.JPFBenchmark.benchmark02(-74.58725100135901,-24.65981453769824 ) ;
  }

  @Test
  public void test2366() {
    coral.tests.JPFBenchmark.benchmark02(-7.464601085304872,-182.7235069022922 ) ;
  }

  @Test
  public void test2367() {
    coral.tests.JPFBenchmark.benchmark02(7.477449545320695,-0.3765320889257489 ) ;
  }

  @Test
  public void test2368() {
    coral.tests.JPFBenchmark.benchmark02(-74.79004554760951,0.03588158387877633 ) ;
  }

  @Test
  public void test2369() {
    coral.tests.JPFBenchmark.benchmark02(74.86086780682152,0 ) ;
  }

  @Test
  public void test2370() {
    coral.tests.JPFBenchmark.benchmark02(74.97807471162824,62.5567837285011 ) ;
  }

  @Test
  public void test2371() {
    coral.tests.JPFBenchmark.benchmark02(74.99086897046686,-56.67743900353148 ) ;
  }

  @Test
  public void test2372() {
    coral.tests.JPFBenchmark.benchmark02(75.04374219759532,0 ) ;
  }

  @Test
  public void test2373() {
    coral.tests.JPFBenchmark.benchmark02(-7.504801664523894,-79.39758957491749 ) ;
  }

  @Test
  public void test2374() {
    coral.tests.JPFBenchmark.benchmark02(-75.09989779834423,4.695581375752141 ) ;
  }

  @Test
  public void test2375() {
    coral.tests.JPFBenchmark.benchmark02(75.18565513287828,-69.97765074046697 ) ;
  }

  @Test
  public void test2376() {
    coral.tests.JPFBenchmark.benchmark02(75.18680545900912,42.607647632094825 ) ;
  }

  @Test
  public void test2377() {
    coral.tests.JPFBenchmark.benchmark02(-7.525383548622866E-19,-45.55309347676298 ) ;
  }

  @Test
  public void test2378() {
    coral.tests.JPFBenchmark.benchmark02(-75.26883097728614,69.52314132843586 ) ;
  }

  @Test
  public void test2379() {
    coral.tests.JPFBenchmark.benchmark02(75.29648202022857,1.672537992821894 ) ;
  }

  @Test
  public void test2380() {
    coral.tests.JPFBenchmark.benchmark02(-75.33812655204119,-131.7272590400854 ) ;
  }

  @Test
  public void test2381() {
    coral.tests.JPFBenchmark.benchmark02(75.3521013781841,31.85173308015382 ) ;
  }

  @Test
  public void test2382() {
    coral.tests.JPFBenchmark.benchmark02(-75.38970736512444,-4.962388980384691 ) ;
  }

  @Test
  public void test2383() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822367768494,-95.81858415169977 ) ;
  }

  @Test
  public void test2384() {
    coral.tests.JPFBenchmark.benchmark02(-75.39822368615145,-73.8274273592638 ) ;
  }

  @Test
  public void test2385() {
    coral.tests.JPFBenchmark.benchmark02(75.39822368615502,1.5707963267948963 ) ;
  }

  @Test
  public void test2386() {
    coral.tests.JPFBenchmark.benchmark02(75.39822368615502,1.5707963267948966 ) ;
  }

  @Test
  public void test2387() {
    coral.tests.JPFBenchmark.benchmark02(75.39822368625504,-1.5707963267948966 ) ;
  }

  @Test
  public void test2388() {
    coral.tests.JPFBenchmark.benchmark02(75.39825420373317,-61.261051237737114 ) ;
  }

  @Test
  public void test2389() {
    coral.tests.JPFBenchmark.benchmark02(-75.39931718875356,-45.55300118949572 ) ;
  }

  @Test
  public void test2390() {
    coral.tests.JPFBenchmark.benchmark02(75.42776698292,-1.5707963267948966 ) ;
  }

  @Test
  public void test2391() {
    coral.tests.JPFBenchmark.benchmark02(-75.44470880936315,0.0 ) ;
  }

  @Test
  public void test2392() {
    coral.tests.JPFBenchmark.benchmark02(75.463740117844,95.81857593448869 ) ;
  }

  @Test
  public void test2393() {
    coral.tests.JPFBenchmark.benchmark02(7.550896898009799,100.22788017857366 ) ;
  }

  @Test
  public void test2394() {
    coral.tests.JPFBenchmark.benchmark02(-75.52989456236428,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2395() {
    coral.tests.JPFBenchmark.benchmark02(75.55252752673321,92.35399632644322 ) ;
  }

  @Test
  public void test2396() {
    coral.tests.JPFBenchmark.benchmark02(75.56914162326302,-0.8561295431578315 ) ;
  }

  @Test
  public void test2397() {
    coral.tests.JPFBenchmark.benchmark02(-75.60848523324967,-48.6946861306418 ) ;
  }

  @Test
  public void test2398() {
    coral.tests.JPFBenchmark.benchmark02(-75.62297552715897,-51.89850105818981 ) ;
  }

  @Test
  public void test2399() {
    coral.tests.JPFBenchmark.benchmark02(75.71398018458936,0.0 ) ;
  }

  @Test
  public void test2400() {
    coral.tests.JPFBenchmark.benchmark02(75.71538471442247,74.9301335574272 ) ;
  }

  @Test
  public void test2401() {
    coral.tests.JPFBenchmark.benchmark02(-75.77256234960747,61.262178379672356 ) ;
  }

  @Test
  public void test2402() {
    coral.tests.JPFBenchmark.benchmark02(75.79880465509692,-36.17110599418047 ) ;
  }

  @Test
  public void test2403() {
    coral.tests.JPFBenchmark.benchmark02(-75.83932852507436,-41.17863588414974 ) ;
  }

  @Test
  public void test2404() {
    coral.tests.JPFBenchmark.benchmark02(75.84917935882754,-1.5707963267949054 ) ;
  }

  @Test
  public void test2405() {
    coral.tests.JPFBenchmark.benchmark02(-75.86711970177747,-29.65183517585659 ) ;
  }

  @Test
  public void test2406() {
    coral.tests.JPFBenchmark.benchmark02(-75.89651713526527,-11.718597552668898 ) ;
  }

  @Test
  public void test2407() {
    coral.tests.JPFBenchmark.benchmark02(-75.9036603101368,-29.327331267758126 ) ;
  }

  @Test
  public void test2408() {
    coral.tests.JPFBenchmark.benchmark02(-75.92764920710597,77.15969070558364 ) ;
  }

  @Test
  public void test2409() {
    coral.tests.JPFBenchmark.benchmark02(-7.595897316433593,-1.1340563725391644 ) ;
  }

  @Test
  public void test2410() {
    coral.tests.JPFBenchmark.benchmark02(-76.00532602328443,-1.5707963267948966 ) ;
  }

  @Test
  public void test2411() {
    coral.tests.JPFBenchmark.benchmark02(-76.1070448968388,-84.5990506236993 ) ;
  }

  @Test
  public void test2412() {
    coral.tests.JPFBenchmark.benchmark02(76.12109534553406,1.5707963267948968 ) ;
  }

  @Test
  public void test2413() {
    coral.tests.JPFBenchmark.benchmark02(76.12330885899273,44.78107423987984 ) ;
  }

  @Test
  public void test2414() {
    coral.tests.JPFBenchmark.benchmark02(76.18429015336369,45.36623879262122 ) ;
  }

  @Test
  public void test2415() {
    coral.tests.JPFBenchmark.benchmark02(-76.21589238002414,6.91452524165004 ) ;
  }

  @Test
  public void test2416() {
    coral.tests.JPFBenchmark.benchmark02(-76.32923556458093,66.40726618635057 ) ;
  }

  @Test
  public void test2417() {
    coral.tests.JPFBenchmark.benchmark02(76.34026812702061,-43.41127303159042 ) ;
  }

  @Test
  public void test2418() {
    coral.tests.JPFBenchmark.benchmark02(-76.38387880522775,-1.5707963267948966 ) ;
  }

  @Test
  public void test2419() {
    coral.tests.JPFBenchmark.benchmark02(-76.38610982501612,2609.87224052011 ) ;
  }

  @Test
  public void test2420() {
    coral.tests.JPFBenchmark.benchmark02(76.40145903462908,0 ) ;
  }

  @Test
  public void test2421() {
    coral.tests.JPFBenchmark.benchmark02(76.44210319045364,-0.004857037246812795 ) ;
  }

  @Test
  public void test2422() {
    coral.tests.JPFBenchmark.benchmark02(-76.46740099473752,1.5469750206559985 ) ;
  }

  @Test
  public void test2423() {
    coral.tests.JPFBenchmark.benchmark02(7.653589278135925,-1.5707963267949054 ) ;
  }

  @Test
  public void test2424() {
    coral.tests.JPFBenchmark.benchmark02(76.63821055940741,0.0 ) ;
  }

  @Test
  public void test2425() {
    coral.tests.JPFBenchmark.benchmark02(-7.664653413759595,-59.93389426912417 ) ;
  }

  @Test
  public void test2426() {
    coral.tests.JPFBenchmark.benchmark02(76.69622599269331,1.5707963267948983 ) ;
  }

  @Test
  public void test2427() {
    coral.tests.JPFBenchmark.benchmark02(-76.73668937631685,0.004913740747173384 ) ;
  }

  @Test
  public void test2428() {
    coral.tests.JPFBenchmark.benchmark02(-76.79487430901476,-94.02327688733669 ) ;
  }

  @Test
  public void test2429() {
    coral.tests.JPFBenchmark.benchmark02(-7.681640722341513,1.7018979462018642 ) ;
  }

  @Test
  public void test2430() {
    coral.tests.JPFBenchmark.benchmark02(-76.9021703656894,98.6275253153434 ) ;
  }

  @Test
  public void test2431() {
    coral.tests.JPFBenchmark.benchmark02(-7.690430531544026,-45.99506845913328 ) ;
  }

  @Test
  public void test2432() {
    coral.tests.JPFBenchmark.benchmark02(-76.97031206389147,1.1845404865920421 ) ;
  }

  @Test
  public void test2433() {
    coral.tests.JPFBenchmark.benchmark02(76.9861682259683,-14.429223951873475 ) ;
  }

  @Test
  public void test2434() {
    coral.tests.JPFBenchmark.benchmark02(-77.01576605847308,-25.301920683635842 ) ;
  }

  @Test
  public void test2435() {
    coral.tests.JPFBenchmark.benchmark02(77.01814666624747,1.570796326794897 ) ;
  }

  @Test
  public void test2436() {
    coral.tests.JPFBenchmark.benchmark02(-77.1278473856532,65.95796614295851 ) ;
  }

  @Test
  public void test2437() {
    coral.tests.JPFBenchmark.benchmark02(77.12922658512613,-0.5197346718533559 ) ;
  }

  @Test
  public void test2438() {
    coral.tests.JPFBenchmark.benchmark02(77.13577054065249,0 ) ;
  }

  @Test
  public void test2439() {
    coral.tests.JPFBenchmark.benchmark02(77.14922072943767,94.75867686817892 ) ;
  }

  @Test
  public void test2440() {
    coral.tests.JPFBenchmark.benchmark02(7.715536843016963,-96.93813707918551 ) ;
  }

  @Test
  public void test2441() {
    coral.tests.JPFBenchmark.benchmark02(77.25369971339266,0.24379800723994782 ) ;
  }

  @Test
  public void test2442() {
    coral.tests.JPFBenchmark.benchmark02(7.732814508136438E-8,-73.82742732497624 ) ;
  }

  @Test
  public void test2443() {
    coral.tests.JPFBenchmark.benchmark02(77.36908349422613,8.255735238603101 ) ;
  }

  @Test
  public void test2444() {
    coral.tests.JPFBenchmark.benchmark02(77.37564228068393,-29.332366611709688 ) ;
  }

  @Test
  public void test2445() {
    coral.tests.JPFBenchmark.benchmark02(-77.41045393098258,-71.18301381515316 ) ;
  }

  @Test
  public void test2446() {
    coral.tests.JPFBenchmark.benchmark02(-77.42241584311289,-8.070422760403389 ) ;
  }

  @Test
  public void test2447() {
    coral.tests.JPFBenchmark.benchmark02(77.43504568316354,-38.34320925757846 ) ;
  }

  @Test
  public void test2448() {
    coral.tests.JPFBenchmark.benchmark02(-77.43680123607824,75.20851947862032 ) ;
  }

  @Test
  public void test2449() {
    coral.tests.JPFBenchmark.benchmark02(77.4455271024301,-37.94447271143173 ) ;
  }

  @Test
  public void test2450() {
    coral.tests.JPFBenchmark.benchmark02(77.45128815657878,6.570062529927182 ) ;
  }

  @Test
  public void test2451() {
    coral.tests.JPFBenchmark.benchmark02(7.747144243897358,-94.140942216679 ) ;
  }

  @Test
  public void test2452() {
    coral.tests.JPFBenchmark.benchmark02(77.48943130899968,-0.30761736055201194 ) ;
  }

  @Test
  public void test2453() {
    coral.tests.JPFBenchmark.benchmark02(77.4959695636988,-64.6726532768524 ) ;
  }

  @Test
  public void test2454() {
    coral.tests.JPFBenchmark.benchmark02(-7.752339722090534,-0.1846149414831153 ) ;
  }

  @Test
  public void test2455() {
    coral.tests.JPFBenchmark.benchmark02(-77.53271127741988,-36.59463131438932 ) ;
  }

  @Test
  public void test2456() {
    coral.tests.JPFBenchmark.benchmark02(77.53370100511664,-5.718504314826016 ) ;
  }

  @Test
  public void test2457() {
    coral.tests.JPFBenchmark.benchmark02(-77.68705401036735,-7.386120461918466 ) ;
  }

  @Test
  public void test2458() {
    coral.tests.JPFBenchmark.benchmark02(77.7088662211394,-23.49185245441987 ) ;
  }

  @Test
  public void test2459() {
    coral.tests.JPFBenchmark.benchmark02(77.75861158808505,-86.88727379024957 ) ;
  }

  @Test
  public void test2460() {
    coral.tests.JPFBenchmark.benchmark02(77.76712516887036,100.0 ) ;
  }

  @Test
  public void test2461() {
    coral.tests.JPFBenchmark.benchmark02(77.80208750401349,27.2302940130935 ) ;
  }

  @Test
  public void test2462() {
    coral.tests.JPFBenchmark.benchmark02(7.786621415242195,1.5707963267948963 ) ;
  }

  @Test
  public void test2463() {
    coral.tests.JPFBenchmark.benchmark02(77.8818397692987,15.044737608948047 ) ;
  }

  @Test
  public void test2464() {
    coral.tests.JPFBenchmark.benchmark02(77.95457195955238,1.5707963267948966 ) ;
  }

  @Test
  public void test2465() {
    coral.tests.JPFBenchmark.benchmark02(77.9725027325874,-120.38400355616818 ) ;
  }

  @Test
  public void test2466() {
    coral.tests.JPFBenchmark.benchmark02(-77.97683514801483,-42.32594124897502 ) ;
  }

  @Test
  public void test2467() {
    coral.tests.JPFBenchmark.benchmark02(-77.98351540200407,116.06948571564277 ) ;
  }

  @Test
  public void test2468() {
    coral.tests.JPFBenchmark.benchmark02(77.98438562599439,-44.99766276341926 ) ;
  }

  @Test
  public void test2469() {
    coral.tests.JPFBenchmark.benchmark02(78.01993236893475,0.0 ) ;
  }

  @Test
  public void test2470() {
    coral.tests.JPFBenchmark.benchmark02(78.03336754506823,1.5707963267951224 ) ;
  }

  @Test
  public void test2471() {
    coral.tests.JPFBenchmark.benchmark02(78.03371636078784,-0.4307740296795841 ) ;
  }

  @Test
  public void test2472() {
    coral.tests.JPFBenchmark.benchmark02(-78.06229272917884,0.0 ) ;
  }

  @Test
  public void test2473() {
    coral.tests.JPFBenchmark.benchmark02(78.08471503203974,-1.5707963267948966 ) ;
  }

  @Test
  public void test2474() {
    coral.tests.JPFBenchmark.benchmark02(78.10295158162171,138.60427263440357 ) ;
  }

  @Test
  public void test2475() {
    coral.tests.JPFBenchmark.benchmark02(-78.10764537553803,1.5707963267948966 ) ;
  }

  @Test
  public void test2476() {
    coral.tests.JPFBenchmark.benchmark02(78.16983465222316,16.043525035197163 ) ;
  }

  @Test
  public void test2477() {
    coral.tests.JPFBenchmark.benchmark02(-78.2957426506408,-136.11786417961528 ) ;
  }

  @Test
  public void test2478() {
    coral.tests.JPFBenchmark.benchmark02(-78.29832499442388,-31.56922252427603 ) ;
  }

  @Test
  public void test2479() {
    coral.tests.JPFBenchmark.benchmark02(-78.30599461228223,1.364150023133685 ) ;
  }

  @Test
  public void test2480() {
    coral.tests.JPFBenchmark.benchmark02(-78.30858273341077,-17.278759594743864 ) ;
  }

  @Test
  public void test2481() {
    coral.tests.JPFBenchmark.benchmark02(78.33058267471736,77.1457130656425 ) ;
  }

  @Test
  public void test2482() {
    coral.tests.JPFBenchmark.benchmark02(-78.34137516761929,4.513947808157147 ) ;
  }

  @Test
  public void test2483() {
    coral.tests.JPFBenchmark.benchmark02(-78.36180178696532,-1.5707963267948968 ) ;
  }

  @Test
  public void test2484() {
    coral.tests.JPFBenchmark.benchmark02(-78.37592494580785,42.413584473795304 ) ;
  }

  @Test
  public void test2485() {
    coral.tests.JPFBenchmark.benchmark02(-78.37990249712726,4.347734465015947 ) ;
  }

  @Test
  public void test2486() {
    coral.tests.JPFBenchmark.benchmark02(-78.38167440023736,0.031300088675346574 ) ;
  }

  @Test
  public void test2487() {
    coral.tests.JPFBenchmark.benchmark02(78.39001362778279,0.0 ) ;
  }

  @Test
  public void test2488() {
    coral.tests.JPFBenchmark.benchmark02(78.44578381557889,62.79547874399998 ) ;
  }

  @Test
  public void test2489() {
    coral.tests.JPFBenchmark.benchmark02(78.44676155696908,-33.89181188313076 ) ;
  }

  @Test
  public void test2490() {
    coral.tests.JPFBenchmark.benchmark02(78.45249171297223,38.210860148393294 ) ;
  }

  @Test
  public void test2491() {
    coral.tests.JPFBenchmark.benchmark02(7.846258175935873,0.0 ) ;
  }

  @Test
  public void test2492() {
    coral.tests.JPFBenchmark.benchmark02(78.47970996757101,-29.845130296852354 ) ;
  }

  @Test
  public void test2493() {
    coral.tests.JPFBenchmark.benchmark02(-78.53663795323052,0.0 ) ;
  }

  @Test
  public void test2494() {
    coral.tests.JPFBenchmark.benchmark02(7.853981013076272,-4.312695170405035E-6 ) ;
  }

  @Test
  public void test2495() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981584462979,-161.8545217466512 ) ;
  }

  @Test
  public void test2496() {
    coral.tests.JPFBenchmark.benchmark02(78.5398163320762,-17.27875955657124 ) ;
  }

  @Test
  public void test2497() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974483,-100.0 ) ;
  }

  @Test
  public void test2498() {
    coral.tests.JPFBenchmark.benchmark02(7.853981633974484,-1.5707963267948966 ) ;
  }

  @Test
  public void test2499() {
    coral.tests.JPFBenchmark.benchmark02(-7.853981633974485,17.317858130254393 ) ;
  }

  @Test
  public void test2500() {
    coral.tests.JPFBenchmark.benchmark02(-78.53981633983834,-1.5707963267948966 ) ;
  }

  @Test
  public void test2501() {
    coral.tests.JPFBenchmark.benchmark02(7.853981634016188,0.5378644559142162 ) ;
  }

  @Test
  public void test2502() {
    coral.tests.JPFBenchmark.benchmark02(-7.854010171137711,34.17818400578136 ) ;
  }

  @Test
  public void test2503() {
    coral.tests.JPFBenchmark.benchmark02(7.858120117463159,48.98436715014674 ) ;
  }

  @Test
  public void test2504() {
    coral.tests.JPFBenchmark.benchmark02(-78.6393818896388,85.8431446385388 ) ;
  }

  @Test
  public void test2505() {
    coral.tests.JPFBenchmark.benchmark02(78.67947912569684,60.5047619244969 ) ;
  }

  @Test
  public void test2506() {
    coral.tests.JPFBenchmark.benchmark02(78.68779789347568,-23.53378876744398 ) ;
  }

  @Test
  public void test2507() {
    coral.tests.JPFBenchmark.benchmark02(78.69402124005256,0.39678735180888364 ) ;
  }

  @Test
  public void test2508() {
    coral.tests.JPFBenchmark.benchmark02(-78.70445319961286,1.1142953221191192 ) ;
  }

  @Test
  public void test2509() {
    coral.tests.JPFBenchmark.benchmark02(78.71050370547073,-13.076497869759194 ) ;
  }

  @Test
  public void test2510() {
    coral.tests.JPFBenchmark.benchmark02(78.96055911208303,0.0 ) ;
  }

  @Test
  public void test2511() {
    coral.tests.JPFBenchmark.benchmark02(-79.01957437820515,78.10141850623239 ) ;
  }

  @Test
  public void test2512() {
    coral.tests.JPFBenchmark.benchmark02(79.02143605590922,-44.13581382841267 ) ;
  }

  @Test
  public void test2513() {
    coral.tests.JPFBenchmark.benchmark02(-79.02148230519683,0.0 ) ;
  }

  @Test
  public void test2514() {
    coral.tests.JPFBenchmark.benchmark02(-79.11593683858857,-69.06089632235461 ) ;
  }

  @Test
  public void test2515() {
    coral.tests.JPFBenchmark.benchmark02(79.18050175544975,-4.724282842732716 ) ;
  }

  @Test
  public void test2516() {
    coral.tests.JPFBenchmark.benchmark02(-79.22549874538916,-72.37279056604177 ) ;
  }

  @Test
  public void test2517() {
    coral.tests.JPFBenchmark.benchmark02(-7.924049471225402,0.0 ) ;
  }

  @Test
  public void test2518() {
    coral.tests.JPFBenchmark.benchmark02(-7.924450550363106,1.5707963267948968 ) ;
  }

  @Test
  public void test2519() {
    coral.tests.JPFBenchmark.benchmark02(-79.4856291175,6.440706637942616 ) ;
  }

  @Test
  public void test2520() {
    coral.tests.JPFBenchmark.benchmark02(-79.62029225752114,-1.5707963267948966 ) ;
  }

  @Test
  public void test2521() {
    coral.tests.JPFBenchmark.benchmark02(-7.964886388991668,-3.0306878994760393 ) ;
  }

  @Test
  public void test2522() {
    coral.tests.JPFBenchmark.benchmark02(-7.966499864905834,1.5707963267948966 ) ;
  }

  @Test
  public void test2523() {
    coral.tests.JPFBenchmark.benchmark02(-79.7958807861687,-0.03190056325421014 ) ;
  }

  @Test
  public void test2524() {
    coral.tests.JPFBenchmark.benchmark02(-79.82722332274055,0.0 ) ;
  }

  @Test
  public void test2525() {
    coral.tests.JPFBenchmark.benchmark02(-79.83218438580826,-92.69456762942426 ) ;
  }

  @Test
  public void test2526() {
    coral.tests.JPFBenchmark.benchmark02(7.983388978297307,0.5668494561073688 ) ;
  }

  @Test
  public void test2527() {
    coral.tests.JPFBenchmark.benchmark02(-7.987409996533485,-54.11760187932801 ) ;
  }

  @Test
  public void test2528() {
    coral.tests.JPFBenchmark.benchmark02(-79.92348857632983,-0.36691283550846177 ) ;
  }

  @Test
  public void test2529() {
    coral.tests.JPFBenchmark.benchmark02(79.94097524460662,14.8732735023992 ) ;
  }

  @Test
  public void test2530() {
    coral.tests.JPFBenchmark.benchmark02(80.01491739156802,1.5707963267948968 ) ;
  }

  @Test
  public void test2531() {
    coral.tests.JPFBenchmark.benchmark02(80.09096067041855,135.4434309958843 ) ;
  }

  @Test
  public void test2532() {
    coral.tests.JPFBenchmark.benchmark02(-8.016905091572095,-55.290329795458184 ) ;
  }

  @Test
  public void test2533() {
    coral.tests.JPFBenchmark.benchmark02(80.1729066615111,100.0 ) ;
  }

  @Test
  public void test2534() {
    coral.tests.JPFBenchmark.benchmark02(-80.2022131293443,25.523219163964 ) ;
  }

  @Test
  public void test2535() {
    coral.tests.JPFBenchmark.benchmark02(-80.2267269455885,32.13417545691439 ) ;
  }

  @Test
  public void test2536() {
    coral.tests.JPFBenchmark.benchmark02(-80.28257871052978,68.94307233440104 ) ;
  }

  @Test
  public void test2537() {
    coral.tests.JPFBenchmark.benchmark02(8.031036274041668,12.844026875609245 ) ;
  }

  @Test
  public void test2538() {
    coral.tests.JPFBenchmark.benchmark02(8.038540881599287,0.009928515482786232 ) ;
  }

  @Test
  public void test2539() {
    coral.tests.JPFBenchmark.benchmark02(8.040358434395742,82.2753392676843 ) ;
  }

  @Test
  public void test2540() {
    coral.tests.JPFBenchmark.benchmark02(-8.041092868874046,-35.28088856048895 ) ;
  }

  @Test
  public void test2541() {
    coral.tests.JPFBenchmark.benchmark02(80.47887640093228,0.0 ) ;
  }

  @Test
  public void test2542() {
    coral.tests.JPFBenchmark.benchmark02(-80.51294945944407,73.81186023262315 ) ;
  }

  @Test
  public void test2543() {
    coral.tests.JPFBenchmark.benchmark02(80.64084941764142,52.53720549169543 ) ;
  }

  @Test
  public void test2544() {
    coral.tests.JPFBenchmark.benchmark02(-80.65325665731145,-5.879927821438148 ) ;
  }

  @Test
  public void test2545() {
    coral.tests.JPFBenchmark.benchmark02(8.067508469475769,0 ) ;
  }

  @Test
  public void test2546() {
    coral.tests.JPFBenchmark.benchmark02(80.73921929804396,1.570796326794948 ) ;
  }

  @Test
  public void test2547() {
    coral.tests.JPFBenchmark.benchmark02(-80.77088932626246,-39.15629872964475 ) ;
  }

  @Test
  public void test2548() {
    coral.tests.JPFBenchmark.benchmark02(-8.082958294777288,-90.87721029374175 ) ;
  }

  @Test
  public void test2549() {
    coral.tests.JPFBenchmark.benchmark02(80.87603334904466,-14.942542585588367 ) ;
  }

  @Test
  public void test2550() {
    coral.tests.JPFBenchmark.benchmark02(8.104001446484395,-0.25001981291406994 ) ;
  }

  @Test
  public void test2551() {
    coral.tests.JPFBenchmark.benchmark02(-8.111361021371114E-7,193.21576105350704 ) ;
  }

  @Test
  public void test2552() {
    coral.tests.JPFBenchmark.benchmark02(-81.1507754598559,-26.066602873471652 ) ;
  }

  @Test
  public void test2553() {
    coral.tests.JPFBenchmark.benchmark02(81.15196341843566,-0.009356908682575932 ) ;
  }

  @Test
  public void test2554() {
    coral.tests.JPFBenchmark.benchmark02(-8.123531364693207,-79.94630523796941 ) ;
  }

  @Test
  public void test2555() {
    coral.tests.JPFBenchmark.benchmark02(8.139927634223284,72.3399116478669 ) ;
  }

  @Test
  public void test2556() {
    coral.tests.JPFBenchmark.benchmark02(-81.40706356528216,15.206941518100578 ) ;
  }

  @Test
  public void test2557() {
    coral.tests.JPFBenchmark.benchmark02(8.147783358342934,0.0 ) ;
  }

  @Test
  public void test2558() {
    coral.tests.JPFBenchmark.benchmark02(8.149056354427307,-37.40403712228083 ) ;
  }

  @Test
  public void test2559() {
    coral.tests.JPFBenchmark.benchmark02(8.154604976553998,-70.69729504116187 ) ;
  }

  @Test
  public void test2560() {
    coral.tests.JPFBenchmark.benchmark02(81.64012094069602,10.954286234825588 ) ;
  }

  @Test
  public void test2561() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140899323463,-1.5707963267948966 ) ;
  }

  @Test
  public void test2562() {
    coral.tests.JPFBenchmark.benchmark02(-81.68140899327587,4.7123889803434915 ) ;
  }

  @Test
  public void test2563() {
    coral.tests.JPFBenchmark.benchmark02(-81.6814099470837,-0.5707385098753456 ) ;
  }

  @Test
  public void test2564() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143951091275,-98.96016858807849 ) ;
  }

  @Test
  public void test2565() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143951091284,1.5707963267948963 ) ;
  }

  @Test
  public void test2566() {
    coral.tests.JPFBenchmark.benchmark02(-81.6814395109128,-45.55308659466521 ) ;
  }

  @Test
  public void test2567() {
    coral.tests.JPFBenchmark.benchmark02(-81.68143951103983,32.986718699023456 ) ;
  }

  @Test
  public void test2568() {
    coral.tests.JPFBenchmark.benchmark02(-81.68922149397488,-1.5707962937111184 ) ;
  }

  @Test
  public void test2569() {
    coral.tests.JPFBenchmark.benchmark02(81.75857443035201,17.10969188104319 ) ;
  }

  @Test
  public void test2570() {
    coral.tests.JPFBenchmark.benchmark02(-8.176116431565987,-80.99402161531847 ) ;
  }

  @Test
  public void test2571() {
    coral.tests.JPFBenchmark.benchmark02(-81.78317093022689,152.46900563609776 ) ;
  }

  @Test
  public void test2572() {
    coral.tests.JPFBenchmark.benchmark02(81.80189135676054,5.7023755312171716 ) ;
  }

  @Test
  public void test2573() {
    coral.tests.JPFBenchmark.benchmark02(-81.88269349823936,1.5707963267948963 ) ;
  }

  @Test
  public void test2574() {
    coral.tests.JPFBenchmark.benchmark02(81.89981633627033,27.886085839522707 ) ;
  }

  @Test
  public void test2575() {
    coral.tests.JPFBenchmark.benchmark02(-81.92246302446767,-1.5707963267948968 ) ;
  }

  @Test
  public void test2576() {
    coral.tests.JPFBenchmark.benchmark02(-81.98895630644131,-1.5707963267948983 ) ;
  }

  @Test
  public void test2577() {
    coral.tests.JPFBenchmark.benchmark02(82.04830263663047,46.81037425718051 ) ;
  }

  @Test
  public void test2578() {
    coral.tests.JPFBenchmark.benchmark02(-82.20674003947501,45.52546521204832 ) ;
  }

  @Test
  public void test2579() {
    coral.tests.JPFBenchmark.benchmark02(-82.21762240673836,-52.60583638533953 ) ;
  }

  @Test
  public void test2580() {
    coral.tests.JPFBenchmark.benchmark02(82.23855590200823,1.5707963267948983 ) ;
  }

  @Test
  public void test2581() {
    coral.tests.JPFBenchmark.benchmark02(8.224006842107986,-9.939676896890731 ) ;
  }

  @Test
  public void test2582() {
    coral.tests.JPFBenchmark.benchmark02(-82.24272897498997,-94.93446206832834 ) ;
  }

  @Test
  public void test2583() {
    coral.tests.JPFBenchmark.benchmark02(-82.25160163407514,-1.1895768359187713 ) ;
  }

  @Test
  public void test2584() {
    coral.tests.JPFBenchmark.benchmark02(82.26011329275434,99.96147408531036 ) ;
  }

  @Test
  public void test2585() {
    coral.tests.JPFBenchmark.benchmark02(82.28981069253116,0.0 ) ;
  }

  @Test
  public void test2586() {
    coral.tests.JPFBenchmark.benchmark02(82.37375681575904,21.047034657418948 ) ;
  }

  @Test
  public void test2587() {
    coral.tests.JPFBenchmark.benchmark02(82.38861406044984,-1.229618125609369 ) ;
  }

  @Test
  public void test2588() {
    coral.tests.JPFBenchmark.benchmark02(82.405266428527,0.1495890411523893 ) ;
  }

  @Test
  public void test2589() {
    coral.tests.JPFBenchmark.benchmark02(82.42525908987918,0.0 ) ;
  }

  @Test
  public void test2590() {
    coral.tests.JPFBenchmark.benchmark02(-8.24290532034701,-46.73496611773809 ) ;
  }

  @Test
  public void test2591() {
    coral.tests.JPFBenchmark.benchmark02(-82.49612110615982,1.5707963267948966 ) ;
  }

  @Test
  public void test2592() {
    coral.tests.JPFBenchmark.benchmark02(-82.5112246398996,1.5707963267948968 ) ;
  }

  @Test
  public void test2593() {
    coral.tests.JPFBenchmark.benchmark02(82.53505962100402,14.872696906365928 ) ;
  }

  @Test
  public void test2594() {
    coral.tests.JPFBenchmark.benchmark02(-82.54995858609607,147.55824612685822 ) ;
  }

  @Test
  public void test2595() {
    coral.tests.JPFBenchmark.benchmark02(82.55569499738854,-92.92737781283643 ) ;
  }

  @Test
  public void test2596() {
    coral.tests.JPFBenchmark.benchmark02(82.58555884500926,17.05006117384673 ) ;
  }

  @Test
  public void test2597() {
    coral.tests.JPFBenchmark.benchmark02(-82.62967328521424,-67.09406461449188 ) ;
  }

  @Test
  public void test2598() {
    coral.tests.JPFBenchmark.benchmark02(-82.65356962332561,1.5707963267948966 ) ;
  }

  @Test
  public void test2599() {
    coral.tests.JPFBenchmark.benchmark02(8.266466732288364,7.5351584530432945 ) ;
  }

  @Test
  public void test2600() {
    coral.tests.JPFBenchmark.benchmark02(82.67973727249333,0.0 ) ;
  }

  @Test
  public void test2601() {
    coral.tests.JPFBenchmark.benchmark02(-82.70270033583512,0.0 ) ;
  }

  @Test
  public void test2602() {
    coral.tests.JPFBenchmark.benchmark02(8.270537321775144,-15.730916783592576 ) ;
  }

  @Test
  public void test2603() {
    coral.tests.JPFBenchmark.benchmark02(82.7404676365432,69.71561703355468 ) ;
  }

  @Test
  public void test2604() {
    coral.tests.JPFBenchmark.benchmark02(-82.78364698631306,62.58710825624622 ) ;
  }

  @Test
  public void test2605() {
    coral.tests.JPFBenchmark.benchmark02(-82.81520743718458,0 ) ;
  }

  @Test
  public void test2606() {
    coral.tests.JPFBenchmark.benchmark02(82.83530790058438,-54.95487300847509 ) ;
  }

  @Test
  public void test2607() {
    coral.tests.JPFBenchmark.benchmark02(-82.83558827921198,-84.30045235528303 ) ;
  }

  @Test
  public void test2608() {
    coral.tests.JPFBenchmark.benchmark02(-8.284776261703783,-27.922501592823807 ) ;
  }

  @Test
  public void test2609() {
    coral.tests.JPFBenchmark.benchmark02(82.87229128590121,42.235771270825865 ) ;
  }

  @Test
  public void test2610() {
    coral.tests.JPFBenchmark.benchmark02(-82.88358513418453,59.0806843820543 ) ;
  }

  @Test
  public void test2611() {
    coral.tests.JPFBenchmark.benchmark02(82.98138712839534,123.16163289714866 ) ;
  }

  @Test
  public void test2612() {
    coral.tests.JPFBenchmark.benchmark02(82.98375860207629,44.05130456498422 ) ;
  }

  @Test
  public void test2613() {
    coral.tests.JPFBenchmark.benchmark02(-8.299461835009481,-1.5707963267948948 ) ;
  }

  @Test
  public void test2614() {
    coral.tests.JPFBenchmark.benchmark02(-83.00568952891665,1.5707963267948966 ) ;
  }

  @Test
  public void test2615() {
    coral.tests.JPFBenchmark.benchmark02(-8.302383474942673,47.35477427360982 ) ;
  }

  @Test
  public void test2616() {
    coral.tests.JPFBenchmark.benchmark02(-83.03689833155474,2586.4050381271786 ) ;
  }

  @Test
  public void test2617() {
    coral.tests.JPFBenchmark.benchmark02(-8.311595705123892,37.03622205692367 ) ;
  }

  @Test
  public void test2618() {
    coral.tests.JPFBenchmark.benchmark02(83.18667771556967,0.0 ) ;
  }

  @Test
  public void test2619() {
    coral.tests.JPFBenchmark.benchmark02(83.25180613892819,81.8944062378638 ) ;
  }

  @Test
  public void test2620() {
    coral.tests.JPFBenchmark.benchmark02(83.25220532013161,0.0 ) ;
  }

  @Test
  public void test2621() {
    coral.tests.JPFBenchmark.benchmark02(-8.326103280380952,69.82625315112517 ) ;
  }

  @Test
  public void test2622() {
    coral.tests.JPFBenchmark.benchmark02(-83.34550726346181,0.0 ) ;
  }

  @Test
  public void test2623() {
    coral.tests.JPFBenchmark.benchmark02(83.35564138001122,-12.730747147994549 ) ;
  }

  @Test
  public void test2624() {
    coral.tests.JPFBenchmark.benchmark02(-83.37256813866247,47.0035269861467 ) ;
  }

  @Test
  public void test2625() {
    coral.tests.JPFBenchmark.benchmark02(-83.41808309666632,67.24124884538882 ) ;
  }

  @Test
  public void test2626() {
    coral.tests.JPFBenchmark.benchmark02(-83.45284947219155,-1.5707963267948966 ) ;
  }

  @Test
  public void test2627() {
    coral.tests.JPFBenchmark.benchmark02(-83.48358674685845,0.06335392578525052 ) ;
  }

  @Test
  public void test2628() {
    coral.tests.JPFBenchmark.benchmark02(8.350640797137338,-1.5707963267948966 ) ;
  }

  @Test
  public void test2629() {
    coral.tests.JPFBenchmark.benchmark02(83.54479003545154,0.0 ) ;
  }

  @Test
  public void test2630() {
    coral.tests.JPFBenchmark.benchmark02(83.68297154294723,9.699209439520203 ) ;
  }

  @Test
  public void test2631() {
    coral.tests.JPFBenchmark.benchmark02(8.369825874952129,23.08565237623685 ) ;
  }

  @Test
  public void test2632() {
    coral.tests.JPFBenchmark.benchmark02(8.37031372597453,-3.711082626069782 ) ;
  }

  @Test
  public void test2633() {
    coral.tests.JPFBenchmark.benchmark02(-8.374159750341812,61.26105676214892 ) ;
  }

  @Test
  public void test2634() {
    coral.tests.JPFBenchmark.benchmark02(-83.74476761832182,-104.37096713840579 ) ;
  }

  @Test
  public void test2635() {
    coral.tests.JPFBenchmark.benchmark02(-83.77497326732318,-47.40287400512815 ) ;
  }

  @Test
  public void test2636() {
    coral.tests.JPFBenchmark.benchmark02(83.80087763476735,63.596261461113876 ) ;
  }

  @Test
  public void test2637() {
    coral.tests.JPFBenchmark.benchmark02(83.86385441210624,-14.163425217876721 ) ;
  }

  @Test
  public void test2638() {
    coral.tests.JPFBenchmark.benchmark02(84.0194033015265,14.737022162912012 ) ;
  }

  @Test
  public void test2639() {
    coral.tests.JPFBenchmark.benchmark02(-8.40924059118832,-22.546407532152696 ) ;
  }

  @Test
  public void test2640() {
    coral.tests.JPFBenchmark.benchmark02(8.411518799678628,-96.96870793401212 ) ;
  }

  @Test
  public void test2641() {
    coral.tests.JPFBenchmark.benchmark02(8.415576432534763,0.0 ) ;
  }

  @Test
  public void test2642() {
    coral.tests.JPFBenchmark.benchmark02(-84.30647237936859,1.5707963267948966 ) ;
  }

  @Test
  public void test2643() {
    coral.tests.JPFBenchmark.benchmark02(-84.31995403064327,-28.210076941336197 ) ;
  }

  @Test
  public void test2644() {
    coral.tests.JPFBenchmark.benchmark02(-84.34610342241108,58.3440211452147 ) ;
  }

  @Test
  public void test2645() {
    coral.tests.JPFBenchmark.benchmark02(84.37026654982957,-2327.3626085629503 ) ;
  }

  @Test
  public void test2646() {
    coral.tests.JPFBenchmark.benchmark02(84.39442899567157,0.0 ) ;
  }

  @Test
  public void test2647() {
    coral.tests.JPFBenchmark.benchmark02(-84.40981199169696,-107.76791958422983 ) ;
  }

  @Test
  public void test2648() {
    coral.tests.JPFBenchmark.benchmark02(84.4165311957162,2597.0026663311505 ) ;
  }

  @Test
  public void test2649() {
    coral.tests.JPFBenchmark.benchmark02(84.41922275512192,-92.96770067040514 ) ;
  }

  @Test
  public void test2650() {
    coral.tests.JPFBenchmark.benchmark02(-84.50469920683916,1.88909876698544 ) ;
  }

  @Test
  public void test2651() {
    coral.tests.JPFBenchmark.benchmark02(84.56036576430822,-4.203994931981896 ) ;
  }

  @Test
  public void test2652() {
    coral.tests.JPFBenchmark.benchmark02(-84.57541505508688,1.5707963267948968 ) ;
  }

  @Test
  public void test2653() {
    coral.tests.JPFBenchmark.benchmark02(-84.65793496447094,95.39890133831796 ) ;
  }

  @Test
  public void test2654() {
    coral.tests.JPFBenchmark.benchmark02(84.66391735393915,-82.93502839060048 ) ;
  }

  @Test
  public void test2655() {
    coral.tests.JPFBenchmark.benchmark02(-84.69326232893053,-102.29046679352027 ) ;
  }

  @Test
  public void test2656() {
    coral.tests.JPFBenchmark.benchmark02(84.77011244675319,-81.6905038688686 ) ;
  }

  @Test
  public void test2657() {
    coral.tests.JPFBenchmark.benchmark02(84.80810340050675,-110.47119406508737 ) ;
  }

  @Test
  public void test2658() {
    coral.tests.JPFBenchmark.benchmark02(84.82056272308222,-1.5707963267948966 ) ;
  }

  @Test
  public void test2659() {
    coral.tests.JPFBenchmark.benchmark02(84.82298928691274,-130.37607912509344 ) ;
  }

  @Test
  public void test2660() {
    coral.tests.JPFBenchmark.benchmark02(-84.82299221213655,-58.119457107995714 ) ;
  }

  @Test
  public void test2661() {
    coral.tests.JPFBenchmark.benchmark02(-84.82299744864623,32.98668673578242 ) ;
  }

  @Test
  public void test2662() {
    coral.tests.JPFBenchmark.benchmark02(84.82300160685828,-127.23475718509097 ) ;
  }

  @Test
  public void test2663() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164162697,1.5707963267012486 ) ;
  }

  @Test
  public void test2664() {
    coral.tests.JPFBenchmark.benchmark02(84.82300164663603,-117.80829530325525 ) ;
  }

  @Test
  public void test2665() {
    coral.tests.JPFBenchmark.benchmark02(84.82300164684975,10.995574059890696 ) ;
  }

  @Test
  public void test2666() {
    coral.tests.JPFBenchmark.benchmark02(84.82300164691705,1.5707963267948966 ) ;
  }

  @Test
  public void test2667() {
    coral.tests.JPFBenchmark.benchmark02(-84.8230016469244,0.0 ) ;
  }

  @Test
  public void test2668() {
    coral.tests.JPFBenchmark.benchmark02(-84.82300164704084,1.5707963267948966 ) ;
  }

  @Test
  public void test2669() {
    coral.tests.JPFBenchmark.benchmark02(84.8234945227886,45.55309327785864 ) ;
  }

  @Test
  public void test2670() {
    coral.tests.JPFBenchmark.benchmark02(84.83673043083135,-1.5707963267948968 ) ;
  }

  @Test
  public void test2671() {
    coral.tests.JPFBenchmark.benchmark02(-84.86048202446888,0 ) ;
  }

  @Test
  public void test2672() {
    coral.tests.JPFBenchmark.benchmark02(-84.87963207807378,14.500661325619895 ) ;
  }

  @Test
  public void test2673() {
    coral.tests.JPFBenchmark.benchmark02(-84.89951228843806,6.113135917636114 ) ;
  }

  @Test
  public void test2674() {
    coral.tests.JPFBenchmark.benchmark02(-84.90544340188042,-45.14266891711968 ) ;
  }

  @Test
  public void test2675() {
    coral.tests.JPFBenchmark.benchmark02(-84.9778892247271,-1.2587551141436677 ) ;
  }

  @Test
  public void test2676() {
    coral.tests.JPFBenchmark.benchmark02(-84.99635987064491,0.0 ) ;
  }

  @Test
  public void test2677() {
    coral.tests.JPFBenchmark.benchmark02(-85.02239499596519,-194.67977186024453 ) ;
  }

  @Test
  public void test2678() {
    coral.tests.JPFBenchmark.benchmark02(85.02622170977338,34.627604517343435 ) ;
  }

  @Test
  public void test2679() {
    coral.tests.JPFBenchmark.benchmark02(8.51300104418975,-17.975314276137922 ) ;
  }

  @Test
  public void test2680() {
    coral.tests.JPFBenchmark.benchmark02(-85.14284600837091,-21.468053098520528 ) ;
  }

  @Test
  public void test2681() {
    coral.tests.JPFBenchmark.benchmark02(-85.14425055690107,1.5707963267948966 ) ;
  }

  @Test
  public void test2682() {
    coral.tests.JPFBenchmark.benchmark02(-85.19320162319607,0 ) ;
  }

  @Test
  public void test2683() {
    coral.tests.JPFBenchmark.benchmark02(85.31516478902876,1.5707963267948968 ) ;
  }

  @Test
  public void test2684() {
    coral.tests.JPFBenchmark.benchmark02(85.34455163204056,0.0 ) ;
  }

  @Test
  public void test2685() {
    coral.tests.JPFBenchmark.benchmark02(85.40822178883147,0.0 ) ;
  }

  @Test
  public void test2686() {
    coral.tests.JPFBenchmark.benchmark02(-85.48850243172623,-41.639664271606634 ) ;
  }

  @Test
  public void test2687() {
    coral.tests.JPFBenchmark.benchmark02(-85.51897675836989,-43.43755312015385 ) ;
  }

  @Test
  public void test2688() {
    coral.tests.JPFBenchmark.benchmark02(-8.555654232841576,-1.5707963267948966 ) ;
  }

  @Test
  public void test2689() {
    coral.tests.JPFBenchmark.benchmark02(85.55738385956741,266.61643588897743 ) ;
  }

  @Test
  public void test2690() {
    coral.tests.JPFBenchmark.benchmark02(85.55743576792122,-18.705843675476757 ) ;
  }

  @Test
  public void test2691() {
    coral.tests.JPFBenchmark.benchmark02(85.58678526886402,22.534496632654395 ) ;
  }

  @Test
  public void test2692() {
    coral.tests.JPFBenchmark.benchmark02(85.63373932028318,-2.381534000298808 ) ;
  }

  @Test
  public void test2693() {
    coral.tests.JPFBenchmark.benchmark02(85.66016314032356,-13.77097009672875 ) ;
  }

  @Test
  public void test2694() {
    coral.tests.JPFBenchmark.benchmark02(-85.79498333171165,87.33737579632071 ) ;
  }

  @Test
  public void test2695() {
    coral.tests.JPFBenchmark.benchmark02(85.85036345579566,44.98503481228305 ) ;
  }

  @Test
  public void test2696() {
    coral.tests.JPFBenchmark.benchmark02(-85.92755658642443,24.899777664523953 ) ;
  }

  @Test
  public void test2697() {
    coral.tests.JPFBenchmark.benchmark02(85.95388651146035,-2579.9834878264282 ) ;
  }

  @Test
  public void test2698() {
    coral.tests.JPFBenchmark.benchmark02(86.00508950176845,-1.5707963267948966 ) ;
  }

  @Test
  public void test2699() {
    coral.tests.JPFBenchmark.benchmark02(86.01449804519244,-33.685417535291506 ) ;
  }

  @Test
  public void test2700() {
    coral.tests.JPFBenchmark.benchmark02(-8.602214444419104,0.0 ) ;
  }

  @Test
  public void test2701() {
    coral.tests.JPFBenchmark.benchmark02(86.14956824974396,0.0 ) ;
  }

  @Test
  public void test2702() {
    coral.tests.JPFBenchmark.benchmark02(86.22255605996358,27.083180169760283 ) ;
  }

  @Test
  public void test2703() {
    coral.tests.JPFBenchmark.benchmark02(86.24502662723837,83.5033243328702 ) ;
  }

  @Test
  public void test2704() {
    coral.tests.JPFBenchmark.benchmark02(-86.24875485224061,0.0 ) ;
  }

  @Test
  public void test2705() {
    coral.tests.JPFBenchmark.benchmark02(-86.25550067729682,-0.37175238624585855 ) ;
  }

  @Test
  public void test2706() {
    coral.tests.JPFBenchmark.benchmark02(-86.28676313056972,-1.5707963267948948 ) ;
  }

  @Test
  public void test2707() {
    coral.tests.JPFBenchmark.benchmark02(-86.29060356649306,73.60743956121138 ) ;
  }

  @Test
  public void test2708() {
    coral.tests.JPFBenchmark.benchmark02(-86.3734484199735,-16.971860715849722 ) ;
  }

  @Test
  public void test2709() {
    coral.tests.JPFBenchmark.benchmark02(-86.38262774475366,-37.935531560442804 ) ;
  }

  @Test
  public void test2710() {
    coral.tests.JPFBenchmark.benchmark02(8.653908873164255,17.009054636758716 ) ;
  }

  @Test
  public void test2711() {
    coral.tests.JPFBenchmark.benchmark02(86.54943377365538,-15.828668139419392 ) ;
  }

  @Test
  public void test2712() {
    coral.tests.JPFBenchmark.benchmark02(8.668702779863935,-92.3925990872553 ) ;
  }

  @Test
  public void test2713() {
    coral.tests.JPFBenchmark.benchmark02(8.673617379884035E-19,-4.712388980287951 ) ;
  }

  @Test
  public void test2714() {
    coral.tests.JPFBenchmark.benchmark02(86.84262911123804,1.5707963267948966 ) ;
  }

  @Test
  public void test2715() {
    coral.tests.JPFBenchmark.benchmark02(86.92954757056845,-90.74588904277394 ) ;
  }

  @Test
  public void test2716() {
    coral.tests.JPFBenchmark.benchmark02(87.07202210100478,-3.8198167807158705 ) ;
  }

  @Test
  public void test2717() {
    coral.tests.JPFBenchmark.benchmark02(8.70800651893618,-49.41145757234236 ) ;
  }

  @Test
  public void test2718() {
    coral.tests.JPFBenchmark.benchmark02(-8.712872049385194,-31.91709119629975 ) ;
  }

  @Test
  public void test2719() {
    coral.tests.JPFBenchmark.benchmark02(87.61265947960553,-71.33267044329594 ) ;
  }

  @Test
  public void test2720() {
    coral.tests.JPFBenchmark.benchmark02(87.65990779737818,1.5707963267948966 ) ;
  }

  @Test
  public void test2721() {
    coral.tests.JPFBenchmark.benchmark02(-87.6750575330864,88.48116616883257 ) ;
  }

  @Test
  public void test2722() {
    coral.tests.JPFBenchmark.benchmark02(-8.772131178970326,93.45922739467429 ) ;
  }

  @Test
  public void test2723() {
    coral.tests.JPFBenchmark.benchmark02(87.73070204087664,-16.21069699211482 ) ;
  }

  @Test
  public void test2724() {
    coral.tests.JPFBenchmark.benchmark02(-8.780751048279622,0.0 ) ;
  }

  @Test
  public void test2725() {
    coral.tests.JPFBenchmark.benchmark02(-87.96459430041422,1.5707963267949057 ) ;
  }

  @Test
  public void test2726() {
    coral.tests.JPFBenchmark.benchmark02(-87.96459430049768,48.69463555811281 ) ;
  }

  @Test
  public void test2727() {
    coral.tests.JPFBenchmark.benchmark02(87.9645943005142,-1.5707963267948941 ) ;
  }

  @Test
  public void test2728() {
    coral.tests.JPFBenchmark.benchmark02(-87.96459626121614,-1.5707963267948966 ) ;
  }

  @Test
  public void test2729() {
    coral.tests.JPFBenchmark.benchmark02(87.9655708643355,102.10207112625356 ) ;
  }

  @Test
  public void test2730() {
    coral.tests.JPFBenchmark.benchmark02(87.9655708656725,67.54424205217974 ) ;
  }

  @Test
  public void test2731() {
    coral.tests.JPFBenchmark.benchmark02(8.7986805005402,-29.34274002615905 ) ;
  }

  @Test
  public void test2732() {
    coral.tests.JPFBenchmark.benchmark02(88.00741692832595,1.5279780031196246 ) ;
  }

  @Test
  public void test2733() {
    coral.tests.JPFBenchmark.benchmark02(8.803075852050142,-58.555919681544346 ) ;
  }

  @Test
  public void test2734() {
    coral.tests.JPFBenchmark.benchmark02(-88.04311649617293,5.613176711334347 ) ;
  }

  @Test
  public void test2735() {
    coral.tests.JPFBenchmark.benchmark02(-88.14329723162986,78.24108299679628 ) ;
  }

  @Test
  public void test2736() {
    coral.tests.JPFBenchmark.benchmark02(-88.1689637783816,-49.117069754349544 ) ;
  }

  @Test
  public void test2737() {
    coral.tests.JPFBenchmark.benchmark02(-88.20632775576635,1.5707963267948912 ) ;
  }

  @Test
  public void test2738() {
    coral.tests.JPFBenchmark.benchmark02(88.22207978000094,-1.5707963267948966 ) ;
  }

  @Test
  public void test2739() {
    coral.tests.JPFBenchmark.benchmark02(-88.2318858347954,-23.865452894517123 ) ;
  }

  @Test
  public void test2740() {
    coral.tests.JPFBenchmark.benchmark02(-88.24499145077829,71.60320363006923 ) ;
  }

  @Test
  public void test2741() {
    coral.tests.JPFBenchmark.benchmark02(-88.26742513202794,53.069352414355876 ) ;
  }

  @Test
  public void test2742() {
    coral.tests.JPFBenchmark.benchmark02(88.26781653797143,-1.5707963267948963 ) ;
  }

  @Test
  public void test2743() {
    coral.tests.JPFBenchmark.benchmark02(88.33292283016192,-22.867381547445902 ) ;
  }

  @Test
  public void test2744() {
    coral.tests.JPFBenchmark.benchmark02(88.34197906452326,0.07729815667520257 ) ;
  }

  @Test
  public void test2745() {
    coral.tests.JPFBenchmark.benchmark02(-88.35473891584837,-92.67698328089891 ) ;
  }

  @Test
  public void test2746() {
    coral.tests.JPFBenchmark.benchmark02(88.44451196752853,1.5707963267948966 ) ;
  }

  @Test
  public void test2747() {
    coral.tests.JPFBenchmark.benchmark02(-88.45283260984527,77.89093559877489 ) ;
  }

  @Test
  public void test2748() {
    coral.tests.JPFBenchmark.benchmark02(-88.46956692559822,70.49723202784642 ) ;
  }

  @Test
  public void test2749() {
    coral.tests.JPFBenchmark.benchmark02(88.4748233651287,45.042864412552106 ) ;
  }

  @Test
  public void test2750() {
    coral.tests.JPFBenchmark.benchmark02(-88.48377052354688,-2620.886789301435 ) ;
  }

  @Test
  public void test2751() {
    coral.tests.JPFBenchmark.benchmark02(88.55785579337748,30.4383917018457 ) ;
  }

  @Test
  public void test2752() {
    coral.tests.JPFBenchmark.benchmark02(88.57881577572624,98.96016858807849 ) ;
  }

  @Test
  public void test2753() {
    coral.tests.JPFBenchmark.benchmark02(88.61852797847696,-0.5047325350766073 ) ;
  }

  @Test
  public void test2754() {
    coral.tests.JPFBenchmark.benchmark02(-88.66499276713887,44.27096232881752 ) ;
  }

  @Test
  public void test2755() {
    coral.tests.JPFBenchmark.benchmark02(88.8046224408165,-28.274333882308138 ) ;
  }

  @Test
  public void test2756() {
    coral.tests.JPFBenchmark.benchmark02(88.80599140402387,-0.31745451808134206 ) ;
  }

  @Test
  public void test2757() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,0.0 ) ;
  }

  @Test
  public void test2758() {
    coral.tests.JPFBenchmark.benchmark02(-8.881784197001252E-16,-72.63811826248353 ) ;
  }

  @Test
  public void test2759() {
    coral.tests.JPFBenchmark.benchmark02(-88.82125364343571,86.58278157034465 ) ;
  }

  @Test
  public void test2760() {
    coral.tests.JPFBenchmark.benchmark02(88.86184044334661,0 ) ;
  }

  @Test
  public void test2761() {
    coral.tests.JPFBenchmark.benchmark02(-8.88680475417625,-2602.2106133625725 ) ;
  }

  @Test
  public void test2762() {
    coral.tests.JPFBenchmark.benchmark02(-88.95976649243912,-136.09511929127453 ) ;
  }

  @Test
  public void test2763() {
    coral.tests.JPFBenchmark.benchmark02(88.96028679009873,-79.07235662856216 ) ;
  }

  @Test
  public void test2764() {
    coral.tests.JPFBenchmark.benchmark02(88.96723036429174,-5.715025043976371 ) ;
  }

  @Test
  public void test2765() {
    coral.tests.JPFBenchmark.benchmark02(-89.08457412452063,-0.02295996967912305 ) ;
  }

  @Test
  public void test2766() {
    coral.tests.JPFBenchmark.benchmark02(89.12887166687364,0 ) ;
  }

  @Test
  public void test2767() {
    coral.tests.JPFBenchmark.benchmark02(-89.20381967177818,74.70126019860527 ) ;
  }

  @Test
  public void test2768() {
    coral.tests.JPFBenchmark.benchmark02(89.20918341673223,50.13434921415612 ) ;
  }

  @Test
  public void test2769() {
    coral.tests.JPFBenchmark.benchmark02(89.29197438669277,0 ) ;
  }

  @Test
  public void test2770() {
    coral.tests.JPFBenchmark.benchmark02(89.29551975363964,42.26499522534428 ) ;
  }

  @Test
  public void test2771() {
    coral.tests.JPFBenchmark.benchmark02(-8.932040820172332,-100.0 ) ;
  }

  @Test
  public void test2772() {
    coral.tests.JPFBenchmark.benchmark02(89.33954605268266,83.1921211607823 ) ;
  }

  @Test
  public void test2773() {
    coral.tests.JPFBenchmark.benchmark02(-89.34754347315965,1.5707963267948983 ) ;
  }

  @Test
  public void test2774() {
    coral.tests.JPFBenchmark.benchmark02(-89.3515716875991,0.0 ) ;
  }

  @Test
  public void test2775() {
    coral.tests.JPFBenchmark.benchmark02(89.43074855169118,-8.18419394507556 ) ;
  }

  @Test
  public void test2776() {
    coral.tests.JPFBenchmark.benchmark02(89.47866051491633,0.252929105199683 ) ;
  }

  @Test
  public void test2777() {
    coral.tests.JPFBenchmark.benchmark02(89.53539062731545,0.0 ) ;
  }

  @Test
  public void test2778() {
    coral.tests.JPFBenchmark.benchmark02(-89.55104129366093,53.934356118238725 ) ;
  }

  @Test
  public void test2779() {
    coral.tests.JPFBenchmark.benchmark02(-89.5656348661179,0 ) ;
  }

  @Test
  public void test2780() {
    coral.tests.JPFBenchmark.benchmark02(-89.57537633327114,-3.181578357051453 ) ;
  }

  @Test
  public void test2781() {
    coral.tests.JPFBenchmark.benchmark02(-89.63404636329744,92.10197382696471 ) ;
  }

  @Test
  public void test2782() {
    coral.tests.JPFBenchmark.benchmark02(-89.64291196956987,54.051123187653445 ) ;
  }

  @Test
  public void test2783() {
    coral.tests.JPFBenchmark.benchmark02(-89.67144002320639,0.033008386602180036 ) ;
  }

  @Test
  public void test2784() {
    coral.tests.JPFBenchmark.benchmark02(-89.70186092151833,0.0 ) ;
  }

  @Test
  public void test2785() {
    coral.tests.JPFBenchmark.benchmark02(-89.70766384477696,2597.227033419341 ) ;
  }

  @Test
  public void test2786() {
    coral.tests.JPFBenchmark.benchmark02(-89.75554057639768,0.0 ) ;
  }

  @Test
  public void test2787() {
    coral.tests.JPFBenchmark.benchmark02(-89.75649806865165,1.5707963267948912 ) ;
  }

  @Test
  public void test2788() {
    coral.tests.JPFBenchmark.benchmark02(-89.77722183467625,79.49045181877011 ) ;
  }

  @Test
  public void test2789() {
    coral.tests.JPFBenchmark.benchmark02(-89.78003409080104,82.0899976828955 ) ;
  }

  @Test
  public void test2790() {
    coral.tests.JPFBenchmark.benchmark02(-89.79864723854625,0 ) ;
  }

  @Test
  public void test2791() {
    coral.tests.JPFBenchmark.benchmark02(-89.81263275706256,-6.461279060435371 ) ;
  }

  @Test
  public void test2792() {
    coral.tests.JPFBenchmark.benchmark02(89.83697773764014,0.0 ) ;
  }

  @Test
  public void test2793() {
    coral.tests.JPFBenchmark.benchmark02(-89.87364603835513,-6.904772312841079 ) ;
  }

  @Test
  public void test2794() {
    coral.tests.JPFBenchmark.benchmark02(-89.88014188385766,-16.174164789727556 ) ;
  }

  @Test
  public void test2795() {
    coral.tests.JPFBenchmark.benchmark02(-89.90517209045628,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test2796() {
    coral.tests.JPFBenchmark.benchmark02(89.97853395950229,0.3004156544829578 ) ;
  }

  @Test
  public void test2797() {
    coral.tests.JPFBenchmark.benchmark02(-89.9872064218615,0.0 ) ;
  }

  @Test
  public void test2798() {
    coral.tests.JPFBenchmark.benchmark02(-90.00608670167303,1.5707963267948966 ) ;
  }

  @Test
  public void test2799() {
    coral.tests.JPFBenchmark.benchmark02(90.02837606068681,24.163230812739407 ) ;
  }

  @Test
  public void test2800() {
    coral.tests.JPFBenchmark.benchmark02(90.05956329207356,0.0 ) ;
  }

  @Test
  public void test2801() {
    coral.tests.JPFBenchmark.benchmark02(-90.06839521082578,-82.55189763441133 ) ;
  }

  @Test
  public void test2802() {
    coral.tests.JPFBenchmark.benchmark02(90.07498598328706,0.2605634111529822 ) ;
  }

  @Test
  public void test2803() {
    coral.tests.JPFBenchmark.benchmark02(-9.014961582040357,-65.66064504139014 ) ;
  }

  @Test
  public void test2804() {
    coral.tests.JPFBenchmark.benchmark02(90.19342112186123,22.629882804418884 ) ;
  }

  @Test
  public void test2805() {
    coral.tests.JPFBenchmark.benchmark02(90.25880458674519,-1.5707963267948966 ) ;
  }

  @Test
  public void test2806() {
    coral.tests.JPFBenchmark.benchmark02(90.29674071727607,0.05196905270739738 ) ;
  }

  @Test
  public void test2807() {
    coral.tests.JPFBenchmark.benchmark02(-90.44671342645248,1.4556323113593401 ) ;
  }

  @Test
  public void test2808() {
    coral.tests.JPFBenchmark.benchmark02(90.47437790522943,-9.65961043325487 ) ;
  }

  @Test
  public void test2809() {
    coral.tests.JPFBenchmark.benchmark02(-90.51723113208536,40.98745173096199 ) ;
  }

  @Test
  public void test2810() {
    coral.tests.JPFBenchmark.benchmark02(-90.56259117327345,0.0 ) ;
  }

  @Test
  public void test2811() {
    coral.tests.JPFBenchmark.benchmark02(90.57811795209139,-1.0427273248980522 ) ;
  }

  @Test
  public void test2812() {
    coral.tests.JPFBenchmark.benchmark02(-90.58651354423866,2.0904697367754546 ) ;
  }

  @Test
  public void test2813() {
    coral.tests.JPFBenchmark.benchmark02(90.59666530895194,-45.51331239401178 ) ;
  }

  @Test
  public void test2814() {
    coral.tests.JPFBenchmark.benchmark02(-90.60568617940928,-58.935344219919045 ) ;
  }

  @Test
  public void test2815() {
    coral.tests.JPFBenchmark.benchmark02(-90.61860918406296,-61.41119503923711 ) ;
  }

  @Test
  public void test2816() {
    coral.tests.JPFBenchmark.benchmark02(90.65962218855756,2604.4378992081224 ) ;
  }

  @Test
  public void test2817() {
    coral.tests.JPFBenchmark.benchmark02(90.68216312310912,13.114665655605336 ) ;
  }

  @Test
  public void test2818() {
    coral.tests.JPFBenchmark.benchmark02(-90.69251676898836,21.94209856755016 ) ;
  }

  @Test
  public void test2819() {
    coral.tests.JPFBenchmark.benchmark02(90.75149959241512,1.5707963267948966 ) ;
  }

  @Test
  public void test2820() {
    coral.tests.JPFBenchmark.benchmark02(90.77188163977817,92.12795968220169 ) ;
  }

  @Test
  public void test2821() {
    coral.tests.JPFBenchmark.benchmark02(90.77548651957636,0 ) ;
  }

  @Test
  public void test2822() {
    coral.tests.JPFBenchmark.benchmark02(90.78608902878642,0.0 ) ;
  }

  @Test
  public void test2823() {
    coral.tests.JPFBenchmark.benchmark02(90.83086394371189,1.5707963267948966 ) ;
  }

  @Test
  public void test2824() {
    coral.tests.JPFBenchmark.benchmark02(-90.84577467339545,-80.11066255566412 ) ;
  }

  @Test
  public void test2825() {
    coral.tests.JPFBenchmark.benchmark02(90.88605938502278,39.876967887815525 ) ;
  }

  @Test
  public void test2826() {
    coral.tests.JPFBenchmark.benchmark02(-90.90141288218257,0.0 ) ;
  }

  @Test
  public void test2827() {
    coral.tests.JPFBenchmark.benchmark02(90.90794064873229,10.995574288487585 ) ;
  }

  @Test
  public void test2828() {
    coral.tests.JPFBenchmark.benchmark02(-90.93196985820445,0.0 ) ;
  }

  @Test
  public void test2829() {
    coral.tests.JPFBenchmark.benchmark02(90.93956556761096,4.935281090465719 ) ;
  }

  @Test
  public void test2830() {
    coral.tests.JPFBenchmark.benchmark02(-90.94912051845843,-2.070796326802875 ) ;
  }

  @Test
  public void test2831() {
    coral.tests.JPFBenchmark.benchmark02(90.95156322159818,1.5707963267948912 ) ;
  }

  @Test
  public void test2832() {
    coral.tests.JPFBenchmark.benchmark02(-90.96775540143913,-28.77878409929255 ) ;
  }

  @Test
  public void test2833() {
    coral.tests.JPFBenchmark.benchmark02(-90.97064125329396,58.13288765909955 ) ;
  }

  @Test
  public void test2834() {
    coral.tests.JPFBenchmark.benchmark02(-90.97927319977555,-0.3973799422051956 ) ;
  }

  @Test
  public void test2835() {
    coral.tests.JPFBenchmark.benchmark02(90.99144102944979,1.456050402241343 ) ;
  }

  @Test
  public void test2836() {
    coral.tests.JPFBenchmark.benchmark02(-91.04042096849044,-98.47563749410016 ) ;
  }

  @Test
  public void test2837() {
    coral.tests.JPFBenchmark.benchmark02(-91.06569530964784,45.00722278440197 ) ;
  }

  @Test
  public void test2838() {
    coral.tests.JPFBenchmark.benchmark02(-91.09115547494011,64.76980119623148 ) ;
  }

  @Test
  public void test2839() {
    coral.tests.JPFBenchmark.benchmark02(-91.09545442913966,1.5707963267948968 ) ;
  }

  @Test
  public void test2840() {
    coral.tests.JPFBenchmark.benchmark02(91.0966319017399,1.5707963267948983 ) ;
  }

  @Test
  public void test2841() {
    coral.tests.JPFBenchmark.benchmark02(91.10618695119727,4.712377983936791 ) ;
  }

  @Test
  public void test2842() {
    coral.tests.JPFBenchmark.benchmark02(91.10618695385148,-10.995574287563922 ) ;
  }

  @Test
  public void test2843() {
    coral.tests.JPFBenchmark.benchmark02(91.106186954004,1.5707963267948966 ) ;
  }

  @Test
  public void test2844() {
    coral.tests.JPFBenchmark.benchmark02(91.106186954004,-1.5707963267948977 ) ;
  }

  @Test
  public void test2845() {
    coral.tests.JPFBenchmark.benchmark02(91.10618695406505,17.27875959468794 ) ;
  }

  @Test
  public void test2846() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695409835,-1.5707963267948966 ) ;
  }

  @Test
  public void test2847() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695410326,-1.5707963267948966 ) ;
  }

  @Test
  public void test2848() {
    coral.tests.JPFBenchmark.benchmark02(-91.10618695410399,-1.5707963267948957 ) ;
  }

  @Test
  public void test2849() {
    coral.tests.JPFBenchmark.benchmark02(-91.106186954204,-1.5707963267948966 ) ;
  }

  @Test
  public void test2850() {
    coral.tests.JPFBenchmark.benchmark02(-91.106186954204,1.5707963267948966 ) ;
  }

  @Test
  public void test2851() {
    coral.tests.JPFBenchmark.benchmark02(91.10618695503533,0.0 ) ;
  }

  @Test
  public void test2852() {
    coral.tests.JPFBenchmark.benchmark02(91.11009320443969,-1.5707878921911045 ) ;
  }

  @Test
  public void test2853() {
    coral.tests.JPFBenchmark.benchmark02(-91.12061180832112,-58.10503923729407 ) ;
  }

  @Test
  public void test2854() {
    coral.tests.JPFBenchmark.benchmark02(-91.12989020004339,-1.5470930809555374 ) ;
  }

  @Test
  public void test2855() {
    coral.tests.JPFBenchmark.benchmark02(-91.19980629845745,-100.0 ) ;
  }

  @Test
  public void test2856() {
    coral.tests.JPFBenchmark.benchmark02(91.24720085823691,-50.30478905303257 ) ;
  }

  @Test
  public void test2857() {
    coral.tests.JPFBenchmark.benchmark02(91.27794545069244,-60.73816981061905 ) ;
  }

  @Test
  public void test2858() {
    coral.tests.JPFBenchmark.benchmark02(91.34910746069356,-16.660610708808886 ) ;
  }

  @Test
  public void test2859() {
    coral.tests.JPFBenchmark.benchmark02(-91.35887711042456,-32.73403270647555 ) ;
  }

  @Test
  public void test2860() {
    coral.tests.JPFBenchmark.benchmark02(-91.43389789588477,-51.533002898648256 ) ;
  }

  @Test
  public void test2861() {
    coral.tests.JPFBenchmark.benchmark02(-91.52174174369314,30.50977670183638 ) ;
  }

  @Test
  public void test2862() {
    coral.tests.JPFBenchmark.benchmark02(-91.68551383239931,-91.59040062442784 ) ;
  }

  @Test
  public void test2863() {
    coral.tests.JPFBenchmark.benchmark02(9.169590656939363,89.27114016765313 ) ;
  }

  @Test
  public void test2864() {
    coral.tests.JPFBenchmark.benchmark02(-9.178242038473783,92.42751799576521 ) ;
  }

  @Test
  public void test2865() {
    coral.tests.JPFBenchmark.benchmark02(91.79801490822629,-7.8233236878457575 ) ;
  }

  @Test
  public void test2866() {
    coral.tests.JPFBenchmark.benchmark02(91.80611021123013,16.485625320004942 ) ;
  }

  @Test
  public void test2867() {
    coral.tests.JPFBenchmark.benchmark02(91.83491914533637,-78.49386169177845 ) ;
  }

  @Test
  public void test2868() {
    coral.tests.JPFBenchmark.benchmark02(91.88765026374105,9.696583828622522 ) ;
  }

  @Test
  public void test2869() {
    coral.tests.JPFBenchmark.benchmark02(-92.0649927007574,0.28294535289221995 ) ;
  }

  @Test
  public void test2870() {
    coral.tests.JPFBenchmark.benchmark02(92.08203098574512,0 ) ;
  }

  @Test
  public void test2871() {
    coral.tests.JPFBenchmark.benchmark02(92.09816757420967,0 ) ;
  }

  @Test
  public void test2872() {
    coral.tests.JPFBenchmark.benchmark02(-92.10012711078217,2623.8461893214967 ) ;
  }

  @Test
  public void test2873() {
    coral.tests.JPFBenchmark.benchmark02(-92.12392109185978,0.0 ) ;
  }

  @Test
  public void test2874() {
    coral.tests.JPFBenchmark.benchmark02(92.13348993701325,1.5707963267948966 ) ;
  }

  @Test
  public void test2875() {
    coral.tests.JPFBenchmark.benchmark02(-92.146018366223,-100.0 ) ;
  }

  @Test
  public void test2876() {
    coral.tests.JPFBenchmark.benchmark02(92.16146531352794,0.0 ) ;
  }

  @Test
  public void test2877() {
    coral.tests.JPFBenchmark.benchmark02(92.16645993008017,-1.224549650476889 ) ;
  }

  @Test
  public void test2878() {
    coral.tests.JPFBenchmark.benchmark02(-92.23753574027722,-38.42416314833987 ) ;
  }

  @Test
  public void test2879() {
    coral.tests.JPFBenchmark.benchmark02(-92.3316871754257,-48.75111331287783 ) ;
  }

  @Test
  public void test2880() {
    coral.tests.JPFBenchmark.benchmark02(-92.33561081549524,89.41070312362567 ) ;
  }

  @Test
  public void test2881() {
    coral.tests.JPFBenchmark.benchmark02(92.33643767503264,10.966841080259186 ) ;
  }

  @Test
  public void test2882() {
    coral.tests.JPFBenchmark.benchmark02(92.42563751368209,-54.16484417184017 ) ;
  }

  @Test
  public void test2883() {
    coral.tests.JPFBenchmark.benchmark02(92.57402497554668,-21.15736905345276 ) ;
  }

  @Test
  public void test2884() {
    coral.tests.JPFBenchmark.benchmark02(92.63410922620687,-32.606274905982715 ) ;
  }

  @Test
  public void test2885() {
    coral.tests.JPFBenchmark.benchmark02(-92.6552470286363,1.5707963267948966 ) ;
  }

  @Test
  public void test2886() {
    coral.tests.JPFBenchmark.benchmark02(-92.67698328089638,0.0 ) ;
  }

  @Test
  public void test2887() {
    coral.tests.JPFBenchmark.benchmark02(-92.67698328089914,0.0 ) ;
  }

  @Test
  public void test2888() {
    coral.tests.JPFBenchmark.benchmark02(-92.68637044379757,0.0 ) ;
  }

  @Test
  public void test2889() {
    coral.tests.JPFBenchmark.benchmark02(92.88123795954007,-56.29551850463128 ) ;
  }

  @Test
  public void test2890() {
    coral.tests.JPFBenchmark.benchmark02(92.90871904923773,89.1459073683827 ) ;
  }

  @Test
  public void test2891() {
    coral.tests.JPFBenchmark.benchmark02(9.292776534558527,1.4387949006849217 ) ;
  }

  @Test
  public void test2892() {
    coral.tests.JPFBenchmark.benchmark02(-9.295779353720783E-19,92.67698328097246 ) ;
  }

  @Test
  public void test2893() {
    coral.tests.JPFBenchmark.benchmark02(92.98920171507247,66.29045794293013 ) ;
  }

  @Test
  public void test2894() {
    coral.tests.JPFBenchmark.benchmark02(-9.300559449060849,1.5707963267948983 ) ;
  }

  @Test
  public void test2895() {
    coral.tests.JPFBenchmark.benchmark02(9.304001962925849,4.837712334728713 ) ;
  }

  @Test
  public void test2896() {
    coral.tests.JPFBenchmark.benchmark02(-9.326787068315024,42.411500823472664 ) ;
  }

  @Test
  public void test2897() {
    coral.tests.JPFBenchmark.benchmark02(9.329378347371062,-92.01507825084465 ) ;
  }

  @Test
  public void test2898() {
    coral.tests.JPFBenchmark.benchmark02(-93.43117600083606,0 ) ;
  }

  @Test
  public void test2899() {
    coral.tests.JPFBenchmark.benchmark02(93.64207833183346,0.0 ) ;
  }

  @Test
  public void test2900() {
    coral.tests.JPFBenchmark.benchmark02(-93.70206445709528,40.01105088666326 ) ;
  }

  @Test
  public void test2901() {
    coral.tests.JPFBenchmark.benchmark02(-93.7112677805829,49.66270798578057 ) ;
  }

  @Test
  public void test2902() {
    coral.tests.JPFBenchmark.benchmark02(-93.7823794197571,5.2123889803846915 ) ;
  }

  @Test
  public void test2903() {
    coral.tests.JPFBenchmark.benchmark02(-93.92949929728071,-1.5707963267948948 ) ;
  }

  @Test
  public void test2904() {
    coral.tests.JPFBenchmark.benchmark02(94.06718591920574,-2613.0323316636277 ) ;
  }

  @Test
  public void test2905() {
    coral.tests.JPFBenchmark.benchmark02(94.16576019710325,-70.72108868353537 ) ;
  }

  @Test
  public void test2906() {
    coral.tests.JPFBenchmark.benchmark02(-94.17345228908879,68.44234615190277 ) ;
  }

  @Test
  public void test2907() {
    coral.tests.JPFBenchmark.benchmark02(-94.2253636595247,-1.5707963267948966 ) ;
  }

  @Test
  public void test2908() {
    coral.tests.JPFBenchmark.benchmark02(-9.424776315684634,-0.5704046510147492 ) ;
  }

  @Test
  public void test2909() {
    coral.tests.JPFBenchmark.benchmark02(-9.424777960707432,1.5707963267948912 ) ;
  }

  @Test
  public void test2910() {
    coral.tests.JPFBenchmark.benchmark02(-94.2477796075938,1.5707963267948974 ) ;
  }

  @Test
  public void test2911() {
    coral.tests.JPFBenchmark.benchmark02(9.424777960768607,-83.25611157072201 ) ;
  }

  @Test
  public void test2912() {
    coral.tests.JPFBenchmark.benchmark02(94.24777960769377,1.5707963267948966 ) ;
  }

  @Test
  public void test2913() {
    coral.tests.JPFBenchmark.benchmark02(94.24777960815946,-1.5707963267948966 ) ;
  }

  @Test
  public void test2914() {
    coral.tests.JPFBenchmark.benchmark02(-9.42477796086346,-1.5707963268008158 ) ;
  }

  @Test
  public void test2915() {
    coral.tests.JPFBenchmark.benchmark02(-94.2493605730142,54.3460687560852 ) ;
  }

  @Test
  public void test2916() {
    coral.tests.JPFBenchmark.benchmark02(9.425266244099546,0.5546326246466055 ) ;
  }

  @Test
  public void test2917() {
    coral.tests.JPFBenchmark.benchmark02(94.25519070232,-135.54780544673815 ) ;
  }

  @Test
  public void test2918() {
    coral.tests.JPFBenchmark.benchmark02(9.426291380467491,1.5708084595478173 ) ;
  }

  @Test
  public void test2919() {
    coral.tests.JPFBenchmark.benchmark02(94.2790296076938,1.5707963267948966 ) ;
  }

  @Test
  public void test2920() {
    coral.tests.JPFBenchmark.benchmark02(9.428684210769381,1.5707963267948957 ) ;
  }

  @Test
  public void test2921() {
    coral.tests.JPFBenchmark.benchmark02(94.30727191491414,4.299329330379729E-16 ) ;
  }

  @Test
  public void test2922() {
    coral.tests.JPFBenchmark.benchmark02(-94.31063825376329,-1.5707963267948966 ) ;
  }

  @Test
  public void test2923() {
    coral.tests.JPFBenchmark.benchmark02(-94.40328112167276,-77.5008214180346 ) ;
  }

  @Test
  public void test2924() {
    coral.tests.JPFBenchmark.benchmark02(-94.43421818547753,82.95035248563985 ) ;
  }

  @Test
  public void test2925() {
    coral.tests.JPFBenchmark.benchmark02(-94.47725034251366,-0.4378264906539897 ) ;
  }

  @Test
  public void test2926() {
    coral.tests.JPFBenchmark.benchmark02(-94.48984569013832,1.2838317851146712 ) ;
  }

  @Test
  public void test2927() {
    coral.tests.JPFBenchmark.benchmark02(94.50393316198738,72.3122097468303 ) ;
  }

  @Test
  public void test2928() {
    coral.tests.JPFBenchmark.benchmark02(-94.63479729566292,1.5707963267948966 ) ;
  }

  @Test
  public void test2929() {
    coral.tests.JPFBenchmark.benchmark02(9.465865070893186,0.0 ) ;
  }

  @Test
  public void test2930() {
    coral.tests.JPFBenchmark.benchmark02(-94.67009164854102,0.0 ) ;
  }

  @Test
  public void test2931() {
    coral.tests.JPFBenchmark.benchmark02(9.476007096715502,-2.983908259523117 ) ;
  }

  @Test
  public void test2932() {
    coral.tests.JPFBenchmark.benchmark02(-94.79687931260666,-30.45680812006039 ) ;
  }

  @Test
  public void test2933() {
    coral.tests.JPFBenchmark.benchmark02(-94.81965987438936,-108.30384362219083 ) ;
  }

  @Test
  public void test2934() {
    coral.tests.JPFBenchmark.benchmark02(94.82848725665525,53.38295120667817 ) ;
  }

  @Test
  public void test2935() {
    coral.tests.JPFBenchmark.benchmark02(-94.85574574511809,-100.0 ) ;
  }

  @Test
  public void test2936() {
    coral.tests.JPFBenchmark.benchmark02(9.487277960769394,1.5707963267948966 ) ;
  }

  @Test
  public void test2937() {
    coral.tests.JPFBenchmark.benchmark02(94.875936748782,-46.580159332158885 ) ;
  }

  @Test
  public void test2938() {
    coral.tests.JPFBenchmark.benchmark02(-94.91996038778485,0.0 ) ;
  }

  @Test
  public void test2939() {
    coral.tests.JPFBenchmark.benchmark02(94.970359129695,0 ) ;
  }

  @Test
  public void test2940() {
    coral.tests.JPFBenchmark.benchmark02(94.99251246110745,-72.62552490280373 ) ;
  }

  @Test
  public void test2941() {
    coral.tests.JPFBenchmark.benchmark02(95.02850482540047,55.758596655387294 ) ;
  }

  @Test
  public void test2942() {
    coral.tests.JPFBenchmark.benchmark02(-95.05779786320765,-2.3808145824537887 ) ;
  }

  @Test
  public void test2943() {
    coral.tests.JPFBenchmark.benchmark02(95.13793359817394,1.5707963267948961 ) ;
  }

  @Test
  public void test2944() {
    coral.tests.JPFBenchmark.benchmark02(-95.22655350747897,-1.5707963267948966 ) ;
  }

  @Test
  public void test2945() {
    coral.tests.JPFBenchmark.benchmark02(-95.25011170033572,2.049921017856178 ) ;
  }

  @Test
  public void test2946() {
    coral.tests.JPFBenchmark.benchmark02(-95.37299523152231,45.19270103968313 ) ;
  }

  @Test
  public void test2947() {
    coral.tests.JPFBenchmark.benchmark02(-95.50456015564211,1.5707963267948966 ) ;
  }

  @Test
  public void test2948() {
    coral.tests.JPFBenchmark.benchmark02(95.5358726271004,-56.78648710961755 ) ;
  }

  @Test
  public void test2949() {
    coral.tests.JPFBenchmark.benchmark02(95.54993398165502,1.5707963267948966 ) ;
  }

  @Test
  public void test2950() {
    coral.tests.JPFBenchmark.benchmark02(-95.56437113551138,2607.46207768613 ) ;
  }

  @Test
  public void test2951() {
    coral.tests.JPFBenchmark.benchmark02(95.58030249535113,-8.65990205618617 ) ;
  }

  @Test
  public void test2952() {
    coral.tests.JPFBenchmark.benchmark02(-95.59078738910485,1.5707963267948966 ) ;
  }

  @Test
  public void test2953() {
    coral.tests.JPFBenchmark.benchmark02(95.61631538351966,-1.5707963267948963 ) ;
  }

  @Test
  public void test2954() {
    coral.tests.JPFBenchmark.benchmark02(-95.63561199944182,-15.707963267948966 ) ;
  }

  @Test
  public void test2955() {
    coral.tests.JPFBenchmark.benchmark02(-95.64578431707173,0.0 ) ;
  }

  @Test
  public void test2956() {
    coral.tests.JPFBenchmark.benchmark02(-95.67337482404548,4.971281248321006 ) ;
  }

  @Test
  public void test2957() {
    coral.tests.JPFBenchmark.benchmark02(-95.67856584000052,3.552713678800501E-15 ) ;
  }

  @Test
  public void test2958() {
    coral.tests.JPFBenchmark.benchmark02(-95.73346700937424,0 ) ;
  }

  @Test
  public void test2959() {
    coral.tests.JPFBenchmark.benchmark02(95.81857593402673,0.0 ) ;
  }

  @Test
  public void test2960() {
    coral.tests.JPFBenchmark.benchmark02(95.83464096363761,0.0 ) ;
  }

  @Test
  public void test2961() {
    coral.tests.JPFBenchmark.benchmark02(-95.90697589123727,-122.43371353438589 ) ;
  }

  @Test
  public void test2962() {
    coral.tests.JPFBenchmark.benchmark02(96.07429217253474,-1.5707963267948968 ) ;
  }

  @Test
  public void test2963() {
    coral.tests.JPFBenchmark.benchmark02(96.23831651569253,-31.89272410724851 ) ;
  }

  @Test
  public void test2964() {
    coral.tests.JPFBenchmark.benchmark02(96.31084953275482,-55.318405661195634 ) ;
  }

  @Test
  public void test2965() {
    coral.tests.JPFBenchmark.benchmark02(96.32005008671575,1.570796326794897 ) ;
  }

  @Test
  public void test2966() {
    coral.tests.JPFBenchmark.benchmark02(-96.32831835087626,-193.078950435555 ) ;
  }

  @Test
  public void test2967() {
    coral.tests.JPFBenchmark.benchmark02(96.43632965891294,0.0 ) ;
  }

  @Test
  public void test2968() {
    coral.tests.JPFBenchmark.benchmark02(96.45095704621284,-0.6110881372320307 ) ;
  }

  @Test
  public void test2969() {
    coral.tests.JPFBenchmark.benchmark02(9.647353983195899,-2523.7618461704033 ) ;
  }

  @Test
  public void test2970() {
    coral.tests.JPFBenchmark.benchmark02(-96.56176225898521,1.5707963267948966 ) ;
  }

  @Test
  public void test2971() {
    coral.tests.JPFBenchmark.benchmark02(-96.66893495094263,-1.1314228887242619 ) ;
  }

  @Test
  public void test2972() {
    coral.tests.JPFBenchmark.benchmark02(96.67758406691227,-32.97628230735386 ) ;
  }

  @Test
  public void test2973() {
    coral.tests.JPFBenchmark.benchmark02(-96.67952167953821,45.51493228659535 ) ;
  }

  @Test
  public void test2974() {
    coral.tests.JPFBenchmark.benchmark02(96.95110187751123,38.8316377862105 ) ;
  }

  @Test
  public void test2975() {
    coral.tests.JPFBenchmark.benchmark02(9.704885458982858,86.39379797385755 ) ;
  }

  @Test
  public void test2976() {
    coral.tests.JPFBenchmark.benchmark02(97.15337781348538,-1.5707963267948983 ) ;
  }

  @Test
  public void test2977() {
    coral.tests.JPFBenchmark.benchmark02(97.20368021731423,15.776813656113056 ) ;
  }

  @Test
  public void test2978() {
    coral.tests.JPFBenchmark.benchmark02(-97.24454523662224,-0.28208302190133594 ) ;
  }

  @Test
  public void test2979() {
    coral.tests.JPFBenchmark.benchmark02(-97.26414238382701,86.72523091968091 ) ;
  }

  @Test
  public void test2980() {
    coral.tests.JPFBenchmark.benchmark02(-97.38937226106025,-152.3672436748951 ) ;
  }

  @Test
  public void test2981() {
    coral.tests.JPFBenchmark.benchmark02(97.38937226118405,-92.67698328089888 ) ;
  }

  @Test
  public void test2982() {
    coral.tests.JPFBenchmark.benchmark02(97.3893984275765,-32.9867139472336 ) ;
  }

  @Test
  public void test2983() {
    coral.tests.JPFBenchmark.benchmark02(97.3971847612836,0.0 ) ;
  }

  @Test
  public void test2984() {
    coral.tests.JPFBenchmark.benchmark02(97.39718476146315,1.5707963239403917 ) ;
  }

  @Test
  public void test2985() {
    coral.tests.JPFBenchmark.benchmark02(-97.39718487200533,-51.836279022650174 ) ;
  }

  @Test
  public void test2986() {
    coral.tests.JPFBenchmark.benchmark02(-97.45939428707575,-97.24479862922082 ) ;
  }

  @Test
  public void test2987() {
    coral.tests.JPFBenchmark.benchmark02(-97.52980317855321,-2519.8189664395804 ) ;
  }

  @Test
  public void test2988() {
    coral.tests.JPFBenchmark.benchmark02(-97.6211105122453,-47.93922055278604 ) ;
  }

  @Test
  public void test2989() {
    coral.tests.JPFBenchmark.benchmark02(97.67024560866287,-88.26903299638487 ) ;
  }

  @Test
  public void test2990() {
    coral.tests.JPFBenchmark.benchmark02(-97.77001450488854,0.0 ) ;
  }

  @Test
  public void test2991() {
    coral.tests.JPFBenchmark.benchmark02(-97.88414107325198,52.82905101121344 ) ;
  }

  @Test
  public void test2992() {
    coral.tests.JPFBenchmark.benchmark02(-97.92755031475431,-13.36894946511606 ) ;
  }

  @Test
  public void test2993() {
    coral.tests.JPFBenchmark.benchmark02(-97.94600156127984,-0.4138762600146369 ) ;
  }

  @Test
  public void test2994() {
    coral.tests.JPFBenchmark.benchmark02(97.94950774413803,23.290011305173365 ) ;
  }

  @Test
  public void test2995() {
    coral.tests.JPFBenchmark.benchmark02(98.0127574853725,16.65537437053178 ) ;
  }

  @Test
  public void test2996() {
    coral.tests.JPFBenchmark.benchmark02(-98.01277214069256,44.747281468762 ) ;
  }

  @Test
  public void test2997() {
    coral.tests.JPFBenchmark.benchmark02(-98.04514795487096,1.5707963267948966 ) ;
  }

  @Test
  public void test2998() {
    coral.tests.JPFBenchmark.benchmark02(-98.0708034113301,18.525932886030418 ) ;
  }

  @Test
  public void test2999() {
    coral.tests.JPFBenchmark.benchmark02(-98.0768844364977,1.474440538339705 ) ;
  }

  @Test
  public void test3000() {
    coral.tests.JPFBenchmark.benchmark02(98.20819798993801,-1.3140160187767786 ) ;
  }

  @Test
  public void test3001() {
    coral.tests.JPFBenchmark.benchmark02(-98.27251485659693,-0.3004971906184375 ) ;
  }

  @Test
  public void test3002() {
    coral.tests.JPFBenchmark.benchmark02(-98.38145327730611,92.67698328090009 ) ;
  }

  @Test
  public void test3003() {
    coral.tests.JPFBenchmark.benchmark02(-98.41448990400113,-0.545678684270036 ) ;
  }

  @Test
  public void test3004() {
    coral.tests.JPFBenchmark.benchmark02(-9.842171479947808,0.37093830573397046 ) ;
  }

  @Test
  public void test3005() {
    coral.tests.JPFBenchmark.benchmark02(-98.42920367340258,-100.0 ) ;
  }

  @Test
  public void test3006() {
    coral.tests.JPFBenchmark.benchmark02(98.43138288450615,86.39379837937888 ) ;
  }

  @Test
  public void test3007() {
    coral.tests.JPFBenchmark.benchmark02(-98.43258890817567,0.5275796801014444 ) ;
  }

  @Test
  public void test3008() {
    coral.tests.JPFBenchmark.benchmark02(-98.55043289840005,2567.3386641892253 ) ;
  }

  @Test
  public void test3009() {
    coral.tests.JPFBenchmark.benchmark02(-9.857172935843185,1.1836624410331473 ) ;
  }

  @Test
  public void test3010() {
    coral.tests.JPFBenchmark.benchmark02(-98.58791290405124,-1.5707963267949054 ) ;
  }

  @Test
  public void test3011() {
    coral.tests.JPFBenchmark.benchmark02(98.58828453662825,-1.5707963267948966 ) ;
  }

  @Test
  public void test3012() {
    coral.tests.JPFBenchmark.benchmark02(-98.61803084893639,-1.5707963267948966 ) ;
  }

  @Test
  public void test3013() {
    coral.tests.JPFBenchmark.benchmark02(98.62933010686592,2621.4675848891434 ) ;
  }

  @Test
  public void test3014() {
    coral.tests.JPFBenchmark.benchmark02(98.65435023790535,0.0 ) ;
  }

  @Test
  public void test3015() {
    coral.tests.JPFBenchmark.benchmark02(9.8708242710706E-11,1.5707963267948983 ) ;
  }

  @Test
  public void test3016() {
    coral.tests.JPFBenchmark.benchmark02(98.84822615274904,-100.0 ) ;
  }

  @Test
  public void test3017() {
    coral.tests.JPFBenchmark.benchmark02(98.8683960845166,-31.872251392224477 ) ;
  }

  @Test
  public void test3018() {
    coral.tests.JPFBenchmark.benchmark02(-98.88744451919406,-1.5707963267948974 ) ;
  }

  @Test
  public void test3019() {
    coral.tests.JPFBenchmark.benchmark02(-98.9226653196553,39.81541431763384 ) ;
  }

  @Test
  public void test3020() {
    coral.tests.JPFBenchmark.benchmark02(-98.9601685880769,0.0 ) ;
  }

  @Test
  public void test3021() {
    coral.tests.JPFBenchmark.benchmark02(98.98807312223178,60.73560144952526 ) ;
  }

  @Test
  public void test3022() {
    coral.tests.JPFBenchmark.benchmark02(-98.98874349896876,28.63514034413791 ) ;
  }

  @Test
  public void test3023() {
    coral.tests.JPFBenchmark.benchmark02(98.99280683555622,44.263910684783205 ) ;
  }

  @Test
  public void test3024() {
    coral.tests.JPFBenchmark.benchmark02(-99.01395084380424,-107.45515166767694 ) ;
  }

  @Test
  public void test3025() {
    coral.tests.JPFBenchmark.benchmark02(99.4265766795736,-18.662610079133415 ) ;
  }

  @Test
  public void test3026() {
    coral.tests.JPFBenchmark.benchmark02(99.46909282340168,1.5707963267948963 ) ;
  }

  @Test
  public void test3027() {
    coral.tests.JPFBenchmark.benchmark02(-99.47116775575456,1.5707963267948974 ) ;
  }

  @Test
  public void test3028() {
    coral.tests.JPFBenchmark.benchmark02(-99.50242482340703,-1.5707963267948983 ) ;
  }

  @Test
  public void test3029() {
    coral.tests.JPFBenchmark.benchmark02(-99.50479197259678,-1.4667288280920654 ) ;
  }

  @Test
  public void test3030() {
    coral.tests.JPFBenchmark.benchmark02(99.50829223051124,1.5707963267948966 ) ;
  }

  @Test
  public void test3031() {
    coral.tests.JPFBenchmark.benchmark02(99.50914500543077,0.0 ) ;
  }

  @Test
  public void test3032() {
    coral.tests.JPFBenchmark.benchmark02(99.52103779518185,21.571842444691736 ) ;
  }

  @Test
  public void test3033() {
    coral.tests.JPFBenchmark.benchmark02(-99.52253337906514,76.20175099540296 ) ;
  }

  @Test
  public void test3034() {
    coral.tests.JPFBenchmark.benchmark02(-99.52480620627009,97.65627099628688 ) ;
  }

  @Test
  public void test3035() {
    coral.tests.JPFBenchmark.benchmark02(9.955884303179701,1.5707963267948966 ) ;
  }

  @Test
  public void test3036() {
    coral.tests.JPFBenchmark.benchmark02(99.57929868054151,-2596.761058004072 ) ;
  }

  @Test
  public void test3037() {
    coral.tests.JPFBenchmark.benchmark02(99.83202863102133,-10.980466611057523 ) ;
  }

  @Test
  public void test3038() {
    coral.tests.JPFBenchmark.benchmark02(-9.983890019098581,180.18686893548727 ) ;
  }

  @Test
  public void test3039() {
    coral.tests.JPFBenchmark.benchmark02(99.90059908972046,76.450902359016 ) ;
  }

  @Test
  public void test3040() {
    coral.tests.JPFBenchmark.benchmark02(-9.990104212751416E-10,-83.53883975790927 ) ;
  }

  @Test
  public void test3041() {
    coral.tests.JPFBenchmark.benchmark02(99.98517573264634,2.116585509138938 ) ;
  }

  @Test
  public void test3042() {
    coral.tests.JPFBenchmark.benchmark02(9.999414905732651,0.0 ) ;
  }

  @Test
  public void test3043() {
    coral.tests.JPFBenchmark.benchmark02(9.999828487550056E-11,-1.5707963267948983 ) ;
  }
}
