import org.junit.Test;

public class Sample80Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark80(31.9786188723495,0.9530936590480152 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark80(-36.15196251785713,73.25068407720309 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark80(-39.39652342934799,-75.91770348086635 ) ;
  }
}
