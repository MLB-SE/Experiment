import org.junit.Test;

public class Sample32Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark32(2.4544198296041486 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark32(24.999999999999996 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark32(28.59515912462942 ) ;
  }
}
