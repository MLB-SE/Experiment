import org.junit.Test;

public class Sample20Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark20(-0.0025718752223210907,610.7591508180864 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark20(-0.006091032878307732,30.483937161465175 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark20(0.006903766164992253,-227.52745229989395 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark20(-0.009675908637733547,162.34096306668255 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark20(0.0,14.14448930117473 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948932,-100.00000000000021 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark20(-0.015707963267948967,100.0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark20(0.015707963267948967,-99.99999999999999 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark20(0.01580948294785803,-99.35785578665734 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark20(-0.01714847444383949,91.59977069325654 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark20(0.019252663340502796,-81.58852097571007 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark20(-0.020329117516137793,77.26829881070621 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark20(0.023989771519160874,-65.47775269723955 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark20(-0.02409730922535691,65.18554881397266 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark20(-0.02443855499821183,64.27533571071731 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark20(0.025043143493024944,-62.72360844925068 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark20(0.02562858384997746,-61.29079686922608 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark20(-0.027634234013822735,56.84240518514749 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark20(0.02799924816903635,-56.10137519806393 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark20(0.03113246909230852,-50.45524407773272 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark20(-0.03141990339462372,49.993671433874454 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark20(-0.03632070118149788,43.247962613537744 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark20(-0.03868025367893039,40.60977313730827 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark20(-0.03893698091628638,40.342016505390404 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark20(-0.042706280292706,17.400365450167154 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark20(-0.04767551656616331,32.947651959155195 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark20(-0.08146356761881643,19.282194147756353 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark20(0.09220424705614505,-17.03605177577565 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark20(-0.09298054670986139,-67.57526741283965 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark20(0.09594149561390353,-16.372439440763273 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark20(0.0981367248667044,-64.02499172213024 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark20(0.11790839093974095,-55.607542687690234 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark20(-0.12197627407508296,12.877884151699755 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark20(0.12202786940120859,25.744878354474327 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark20(0.13624331361728537,-5.920417294427476 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark20(0.14270040891083838,-91.34385418690154 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark20(0.14389493247075064,-0.017084088314576473 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark20(-0.14736994394808683,10.65886492667889 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark20(-0.14972519996027972,10.491195384688815 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark20(-0.15729243351798894,-26.33052691066799 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark20(-0.1738567927428818,9.035001175467215 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark20(0.17922771903879192,-35.18770941958927 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark20(0.19147282941575397,-8.203755757868667 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark20(0.1937286332557473,-8.108230055601723 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark20(-0.19681159136781262,32.96477578868482 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark20(0.21275942160303885,-7.382969529432387 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark20(-0.21277772810530848,7.382334329735272 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark20(0.21758783818852123,-7.219136601868215 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark20(0.22617335867781657,13.890197642884132 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark20(0.22983701767295017,-6.834392225842762 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark20(-0.23215278195693428,6.446091834276174 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark20(-0.24048888507061134,2.3105092133742478 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark20(0.24227034641588802,-134.38636539083532 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark20(0.2578772619753716,-6.113778867541531 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark20(-0.2698973731750816,5.819976342548255 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark20(-0.27236323344474034,5.7672847650106736 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark20(-0.27747116259014254,26.762920197178673 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark20(-0.28105466676257423,2.879519493731171 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark20(0.28536768329709467,-3.573880236854106 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark20(0.2853930004515453,-8.882671253696617E-16 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark20(-0.28539678576669464,4.54033270066825 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark20(0.29318482918559063,-26.080553005782782 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark20(0.31116351328794645,-80.78327453334657 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark20(-0.3811600042669747,4.121094315275187 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark20(-0.38869938928744396,4.041159749889118 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark20(0.39998262227276227,-63.46337470826335 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark20(0.40436296837552743,-3.884619635436337 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark20(0.4061534690685457,-3.867494546820666 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark20(0.4234741138903537,-3.709308964282073 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark20(-0.4349198468899592,3.611691528973452 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark20(0.4625157678376439,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark20(-0.5346880644594978,36.728031037243795 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark20(-0.5548374233804045,2.831092966340765 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark20(0.6148777907785496,-20.6926539107472 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark20(-0.6588335632726132,78.21830473664522 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark20(-0.6590580358264118,0.7739402465211996 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark20(0.6590580358264118,-0.9444617816831896 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark20(0.6590580358264118,-40.28509024713282 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark20(0.6591326243534243,-86.91150928884201 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark20(0.6727261158411864,-1.6342482922482304E-13 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark20(-0.6854271590814749,64.39503669149474 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark20(0.6862539323227561,-18.837188217936543 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark20(-0.6955509755511361,100.0 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark20(0.7056691238477981,-2.2259672043319334 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark20(0.7194358691761269,-88.13466645627507 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark20(-0.7218068672354124,80.0156159897002 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark20(-0.7442041651899274,26.672191381765586 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark20(0.7490064412638338,-94.36401732628943 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark20(0.7596731680904014,-2.067726481301721 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark20(-0.7612271364971824,1.0326447018319402 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark20(-0.7643564034989362,99.28648086521608 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark20(0.7842989020374903,-90.12351124509625 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974456,-32.24802578441687 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974456,-65.0495937819073 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974456,96.1280490514209 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974474,-49.81377931007566 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark20(0.785398163397448,-2.000000000000001 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-0.043689343523389323 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-0.5897498440256861 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.2789769243681803E-13 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.3908533656177013 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,17.368926672020457 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.7621414021254829 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9808385459594389 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999503 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999716 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,1.9999999999999964 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-1.9999999999999996 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-2.0 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,2.0000000000000018 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,24.159081256370378 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-25.745796866813357 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,32.17487485379494 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-32.28843212553621 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-33.49831333114186 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-33.844104677830444 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,3.552713678800501E-15 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,41.80755993360742 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-48.979862237247204 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,49.5654395341047 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-56.54784139839284 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,57.1237409677672 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-57.93074030447085 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-65.24750106298812 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,7.079644938985774E-15 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,7.105427357601002E-15 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-72.03153799437804 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-73.79421708331759 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-73.92715605603846 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,80.53567376008954 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,8.656507079534638 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,88.5816627276843 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,9.119598311595613 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974483,9.528229334660725 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-96.417145418399 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-96.43250769683694 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974483,-97.21665812079652 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-0.13329563092852936 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,1.9999999999999005 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-1.9999999999999998 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974484,57.367403540164716 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974484,-88.52814662125635 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974485,-1.5566259575314234 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974485,1.9999999999999996 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974486,1.9999999999999298 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974487,-1.9999999999999707 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974487,33.57157256103302 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,1.9999999999999978 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,25.778073674585478 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,33.75272746507213 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-48.552186491051195 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974488,65.47649391353532 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-88.86417782924674 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974488,-96.31429139612389 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark20(0.785398163397449,-1.9999999999999982 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974492,-0.2335549953748878 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974492,-49.772664141953385 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633974527,1.9999999999997868 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974527,-1.9999999999999858 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark20(0.7853981633974598,-1.9999999999999707 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark20(-0.7853981633975096,1.9999999999992677 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark20(-0.794500411988795,1.9770868625012745 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark20(-0.8612827582854266,1.8237870335664041 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark20(0.8821390665163307,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark20(0.8910203948413624,-38.24068741858946 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark20(-0.9344502637022458,1.16369554128935 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark20(100.0,-13.646161328426402 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark20(-100.0,56.67502554265587 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark20(-100.0,77.25176335177302 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark20(-10.083835996595791,0.1557736884381284 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark20(10.083835996595791,-0.1557736884381284 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark20(10.093073919940199,-0.15563111290521525 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark20(-10.124761709237688,6.125590154201717 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark20(10.15172489842366,-0.1547319635344735 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark20(10.232824311591799,-0.15350564799744326 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark20(1.0279359249411435,-31.676547727538207 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark20(1.0420474841064267,-42.373951754896346 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark20(10.427945872756258,-72.43820685540331 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark20(10.431812141282045,-16.947541152412782 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark20(-10.46224481261953,55.70175881737897 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark20(-10.482125223198986,0.1498547568691908 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark20(-1067.1158570330458,104.88374505762894 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark20(-107.60152405194,0.014597522958866734 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark20(10.812883975570557,-0.145270801975105 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark20(108.7737299708707,-31.080994273171342 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark20(-110.61480091146917,37.88764309153219 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark20(1.1102230246251565E-16,-100.0 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark20(-1.1102230246251565E-16,60.300621727791764 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark20(-11.22693543831421,0.01703184400303462 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark20(114.09395834899088,-42.252666106891056 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark20(-116.24376479761746,-0.43241443876005836 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark20(-11.735995299697422,0.13384432139602126 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark20(11.764274868232121,-0.13352257953752655 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark20(-11.772178690139992,73.22700695309148 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark20(-11.781163905832008,0.13333116654266292 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark20(-11.842037185566424,0.12240864627809836 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark20(-118.60572553900386,0.0073379408696538344 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark20(12.010205395644265,-12.169391727094187 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark20(12.019241738416728,-83.26764791418113 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark20(12.052445099631013,-0.13033009599379852 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark20(120.5633819091888,-65.01371765375437 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark20(-12.097247584664046,0.12984741494306776 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark20(12.155204336740756,-5.708583780480822 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark20(-12.382020456162937,-0.1268610670089032 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark20(-12.526518615117041,73.24801270203903 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark20(-12.587636821805475,0.12478881850752233 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark20(1260.919208808618,-1374.4931476251322 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark20(12.668155997079495,-0.12399565707566486 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark20(12.799421505022892,-0.12272400953265272 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark20(-128.0218867478263,6.4819633216942245 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark20(-12.82962874117326,11.353875362699469 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark20(12.866399320492107,0.4883406111275019 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark20(13.040187713961892,-0.12045810698822024 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark20(1.305284123041584,-73.21358268111022 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark20(-1.3084691642187003,-52.82129703090459 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark20(13.106003410589366,-64.72840552660571 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark20(-13.190324858672241,1.4582244039112795E-303 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark20(-1.3217202999477504,29.690493192864707 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark20(-132.19309747118322,20.17742852315712 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark20(-13.23209254138135,8.184983280366524 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark20(-1.3322676295501878E-15,3.3260976983066115 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark20(13.338625314173825,-0.1177629845502703 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark20(13.465649856234705,-26.210323521334274 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark20(1353.3261601814004,-5.302704436293999E-4 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark20(-14.128963228611852,63.64262310426227 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark20(-141.42642452711243,70.602564242715 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark20(-1427.5792116386224,1309.8773872017277 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark20(14.416679803231562,0.43582748544995703 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark20(14.444779922414995,-0.10874491236501152 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark20(14.515401543668503,-52.46205702840765 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark20(1.465952996498563,-82.00551659295432 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark20(14.873421784056308,-33.889065455584976 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark20(-14.901149178007394,100.0 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark20(14.922565104893406,-0.10526315789232517 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark20(-14.94087558781257,63.16626381549092 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark20(-15.027852429004582,23.047272478616716 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark20(-15.148718352729492,-5.599351685856718 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark20(1.5429390903757938,-1.3706810832788977E-14 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark20(15.640147988785582,-1.7763568394002505E-15 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark20(158.72438802314417,-88.07806148784269 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark20(-16.065495126997646,0.09777453569764023 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark20(-16.0697921340996,83.21556224402497 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark20(16.34080807599064,-7.105427357601002E-15 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark20(16.367021303775378,-70.65132226421223 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark20(-16.459662902193255,0.09543308001682024 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark20(16.84886604942848,-0.09322860791858326 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark20(16.85072027688628,-33.59176003853139 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark20(16.957630591560346,-0.09263064897619996 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark20(-17.047507788612034,0.09214228532831115 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark20(-17.070683374427364,35.792909770565586 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark20(-17.152419467172827,4.797550629719048 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark20(17.2274888284721,-51.790038728391565 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark20(17.243179021313566,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark20(-1.729654970925452,0.6382132678467372 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark20(-17.455192301803198,67.40266329580632 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark20(-17.467693781018752,0.08992579939212127 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark20(175.2287970390665,-26.863444316555668 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark20(17.532021739983158,-96.4470989346403 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark20(-17.70955221273161,19.887659776322735 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark20(-17.72102321970713,92.2713186022346 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark20(-1.7750967334634058,-7.080359905139943 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark20(-1.7763568394002505E-14,62.90059316636116 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark20(1.7763568394002505E-15,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark20(-178.28442899397743,2.8421709430404007E-14 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark20(18.064157758141306,-0.08695652173913046 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark20(-1.8103273473402517,0.8676863491581912 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark20(-18.132941032001426,0.08662667153787784 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark20(-18.19231033258247,91.20672304703668 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark20(18.255272896667027,-15.881889404691421 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark20(1.8308496477099254,-0.8579603075324561 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark20(-18.309009388209162,19.834760564459607 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark20(18.35782526320539,-0.08556549069793107 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark20(-184.4209000436094,4.196504740717174 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark20(18.58094848229537,-8.844655878215065 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark20(18.61861566906731,-39.11177175326179 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark20(-18.708582614365895,110.40906774580156 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark20(18.84955592153876,-79.33898072878759 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark20(-18.905297134756438,29.924258408628305 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark20(-18.958497451218143,0.08285447361198806 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark20(-190.16204678725455,0.008260304518147507 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark20(19.31724422002719,-36.15298599264243 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark20(19.4205043177664,-39.98113215543037 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark20(19.50861395736517,-0.08051808961045472 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark20(1.9630417744761672,-0.8001848698375529 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark20(-19.72306621911118,17.52137259266631 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark20(-1.9774514476193288,-3.177415715942846 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark20(19.918016933113275,-0.07886308823161414 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark20(1.9931641072177229,81.84496104323003 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark20(2.0041683600089728E-292,-71.42591561618923 ) ;
  }

  @Test
  public void test292() {
    coral.tests.JPFBenchmark.benchmark20(20.151129034735078,-65.47865939587341 ) ;
  }

  @Test
  public void test293() {
    coral.tests.JPFBenchmark.benchmark20(20.272063259359555,-2.8253118391103684 ) ;
  }

  @Test
  public void test294() {
    coral.tests.JPFBenchmark.benchmark20(-20.36616670078122,0.07712773590990096 ) ;
  }

  @Test
  public void test295() {
    coral.tests.JPFBenchmark.benchmark20(-20.564270891664506,60.071240337384836 ) ;
  }

  @Test
  public void test296() {
    coral.tests.JPFBenchmark.benchmark20(20.573179205268236,0.30540662891667386 ) ;
  }

  @Test
  public void test297() {
    coral.tests.JPFBenchmark.benchmark20(-20.666034400010673,40.15337827280936 ) ;
  }

  @Test
  public void test298() {
    coral.tests.JPFBenchmark.benchmark20(20.78175739335518,-68.19090297201107 ) ;
  }

  @Test
  public void test299() {
    coral.tests.JPFBenchmark.benchmark20(208.11323618103194,-0.8526677307830691 ) ;
  }

  @Test
  public void test300() {
    coral.tests.JPFBenchmark.benchmark20(-20.923048448980264,-0.15014985322288965 ) ;
  }

  @Test
  public void test301() {
    coral.tests.JPFBenchmark.benchmark20(-21.19340524668923,71.16371177667142 ) ;
  }

  @Test
  public void test302() {
    coral.tests.JPFBenchmark.benchmark20(21.205750411731096,-0.04348591420671609 ) ;
  }

  @Test
  public void test303() {
    coral.tests.JPFBenchmark.benchmark20(-21.237906390790968,25.482356889774522 ) ;
  }

  @Test
  public void test304() {
    coral.tests.JPFBenchmark.benchmark20(21.33209053930214,-0.07363536751828749 ) ;
  }

  @Test
  public void test305() {
    coral.tests.JPFBenchmark.benchmark20(21.33209053930214,-84.57928328103702 ) ;
  }

  @Test
  public void test306() {
    coral.tests.JPFBenchmark.benchmark20(-21.419916725569422,0.0337215748080828 ) ;
  }

  @Test
  public void test307() {
    coral.tests.JPFBenchmark.benchmark20(21.46554827735632,-84.35129432627912 ) ;
  }

  @Test
  public void test308() {
    coral.tests.JPFBenchmark.benchmark20(21.60714250986335,-40.605132315066015 ) ;
  }

  @Test
  public void test309() {
    coral.tests.JPFBenchmark.benchmark20(-21.67915345171038,0.07245653435194299 ) ;
  }

  @Test
  public void test310() {
    coral.tests.JPFBenchmark.benchmark20(-22.08296307832615,24.81337987211034 ) ;
  }

  @Test
  public void test311() {
    coral.tests.JPFBenchmark.benchmark20(22.090637290182006,-5.0485888189620765 ) ;
  }

  @Test
  public void test312() {
    coral.tests.JPFBenchmark.benchmark20(-22.1070824528183,0.01782930567118246 ) ;
  }

  @Test
  public void test313() {
    coral.tests.JPFBenchmark.benchmark20(-2.220446049250313E-16,13.01910803790858 ) ;
  }

  @Test
  public void test314() {
    coral.tests.JPFBenchmark.benchmark20(-2.220446049250313E-16,15.46595740013639 ) ;
  }

  @Test
  public void test315() {
    coral.tests.JPFBenchmark.benchmark20(-2.231302425072623,93.49687445727326 ) ;
  }

  @Test
  public void test316() {
    coral.tests.JPFBenchmark.benchmark20(22.313187151415974,-3.107820639541832 ) ;
  }

  @Test
  public void test317() {
    coral.tests.JPFBenchmark.benchmark20(-22.49851603097347,0.06981777485379026 ) ;
  }

  @Test
  public void test318() {
    coral.tests.JPFBenchmark.benchmark20(22.532023320654588,-25.70738560260223 ) ;
  }

  @Test
  public void test319() {
    coral.tests.JPFBenchmark.benchmark20(22.650206610954964,-21.668434202595815 ) ;
  }

  @Test
  public void test320() {
    coral.tests.JPFBenchmark.benchmark20(-2.2680660392669165,5.9130664316016635 ) ;
  }

  @Test
  public void test321() {
    coral.tests.JPFBenchmark.benchmark20(-2.2737367544323206E-13,5.551115123125783E-17 ) ;
  }

  @Test
  public void test322() {
    coral.tests.JPFBenchmark.benchmark20(-2.275124091518445,19.66615314608607 ) ;
  }

  @Test
  public void test323() {
    coral.tests.JPFBenchmark.benchmark20(22.78773797066379,-62.88892268346213 ) ;
  }

  @Test
  public void test324() {
    coral.tests.JPFBenchmark.benchmark20(22.80108503317581,-70.59795345900302 ) ;
  }

  @Test
  public void test325() {
    coral.tests.JPFBenchmark.benchmark20(23.05413170361623,-0.068135132868548 ) ;
  }

  @Test
  public void test326() {
    coral.tests.JPFBenchmark.benchmark20(-23.13050113687771,98.37386075467734 ) ;
  }

  @Test
  public void test327() {
    coral.tests.JPFBenchmark.benchmark20(23.206618452779487,-17.32798169098742 ) ;
  }

  @Test
  public void test328() {
    coral.tests.JPFBenchmark.benchmark20(-23.425108257120257,72.03017967302131 ) ;
  }

  @Test
  public void test329() {
    coral.tests.JPFBenchmark.benchmark20(2.349719015454338,-29.790787349669486 ) ;
  }

  @Test
  public void test330() {
    coral.tests.JPFBenchmark.benchmark20(2.3561944878160572,-1.2998199451174672E-7 ) ;
  }

  @Test
  public void test331() {
    coral.tests.JPFBenchmark.benchmark20(-2.356194489544309,0.6666666668500233 ) ;
  }

  @Test
  public void test332() {
    coral.tests.JPFBenchmark.benchmark20(-2.365846041382543,0.10241921116690356 ) ;
  }

  @Test
  public void test333() {
    coral.tests.JPFBenchmark.benchmark20(2.3790554601228378,-0.6602604912429371 ) ;
  }

  @Test
  public void test334() {
    coral.tests.JPFBenchmark.benchmark20(-23.795837056967656,0.06601139195205974 ) ;
  }

  @Test
  public void test335() {
    coral.tests.JPFBenchmark.benchmark20(-23.886288881886884,51.58769547802186 ) ;
  }

  @Test
  public void test336() {
    coral.tests.JPFBenchmark.benchmark20(-24.137910581612783,99.24075184181858 ) ;
  }

  @Test
  public void test337() {
    coral.tests.JPFBenchmark.benchmark20(24.255946125437802,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test338() {
    coral.tests.JPFBenchmark.benchmark20(24.331635102057238,-95.04367866111069 ) ;
  }

  @Test
  public void test339() {
    coral.tests.JPFBenchmark.benchmark20(-24.388242845033403,68.01993813857726 ) ;
  }

  @Test
  public void test340() {
    coral.tests.JPFBenchmark.benchmark20(-2453.6942934155054,3.469446951953614E-18 ) ;
  }

  @Test
  public void test341() {
    coral.tests.JPFBenchmark.benchmark20(24.554901274253865,-99.75711394686577 ) ;
  }

  @Test
  public void test342() {
    coral.tests.JPFBenchmark.benchmark20(-24.712832195733455,2.5441381078844825 ) ;
  }

  @Test
  public void test343() {
    coral.tests.JPFBenchmark.benchmark20(-2.4789688097529665,0.38237454628011935 ) ;
  }

  @Test
  public void test344() {
    coral.tests.JPFBenchmark.benchmark20(-2.4811327776281,8.000186860723565 ) ;
  }

  @Test
  public void test345() {
    coral.tests.JPFBenchmark.benchmark20(2.4811944901193765,-0.28187539210850354 ) ;
  }

  @Test
  public void test346() {
    coral.tests.JPFBenchmark.benchmark20(2.481194490192345,-0.01439196695144842 ) ;
  }

  @Test
  public void test347() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.30724578518089607 ) ;
  }

  @Test
  public void test348() {
    coral.tests.JPFBenchmark.benchmark20(-2.4825346177633816,0.632738941707122 ) ;
  }

  @Test
  public void test349() {
    coral.tests.JPFBenchmark.benchmark20(2.482534714347827,-0.6327389170900484 ) ;
  }

  @Test
  public void test350() {
    coral.tests.JPFBenchmark.benchmark20(2.483116858660055,-0.1791976408531818 ) ;
  }

  @Test
  public void test351() {
    coral.tests.JPFBenchmark.benchmark20(-24.87292789074513,28.602041311383573 ) ;
  }

  @Test
  public void test352() {
    coral.tests.JPFBenchmark.benchmark20(25.096813006948366,-88.39260969081087 ) ;
  }

  @Test
  public void test353() {
    coral.tests.JPFBenchmark.benchmark20(25.306105940325807,-59.72131749225886 ) ;
  }

  @Test
  public void test354() {
    coral.tests.JPFBenchmark.benchmark20(25.365702259762713,49.37210661816107 ) ;
  }

  @Test
  public void test355() {
    coral.tests.JPFBenchmark.benchmark20(-25.441386928776026,68.56497452052037 ) ;
  }

  @Test
  public void test356() {
    coral.tests.JPFBenchmark.benchmark20(25.55822863970745,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test357() {
    coral.tests.JPFBenchmark.benchmark20(-25.575450673243026,39.60899850310915 ) ;
  }

  @Test
  public void test358() {
    coral.tests.JPFBenchmark.benchmark20(-25.87294013860877,6.336527544311281 ) ;
  }

  @Test
  public void test359() {
    coral.tests.JPFBenchmark.benchmark20(2.5887242778977924,-0.606783943815941 ) ;
  }

  @Test
  public void test360() {
    coral.tests.JPFBenchmark.benchmark20(-25.918139392115794,13.092015596785078 ) ;
  }

  @Test
  public void test361() {
    coral.tests.JPFBenchmark.benchmark20(2.6061944901923453,-0.6027163669975325 ) ;
  }

  @Test
  public void test362() {
    coral.tests.JPFBenchmark.benchmark20(-2.606194490192347,1.111763459071824E-12 ) ;
  }

  @Test
  public void test363() {
    coral.tests.JPFBenchmark.benchmark20(2.606194492303206,-0.6027164631925556 ) ;
  }

  @Test
  public void test364() {
    coral.tests.JPFBenchmark.benchmark20(-2.6061944935367967,0.6027164629080353 ) ;
  }

  @Test
  public void test365() {
    coral.tests.JPFBenchmark.benchmark20(2.606195265023993,-4.927530658903712 ) ;
  }

  @Test
  public void test366() {
    coral.tests.JPFBenchmark.benchmark20(-2.606999960996916,21.822714114208225 ) ;
  }

  @Test
  public void test367() {
    coral.tests.JPFBenchmark.benchmark20(2.631266631443026,-2.8421709430404007E-14 ) ;
  }

  @Test
  public void test368() {
    coral.tests.JPFBenchmark.benchmark20(26.44901813936997,-55.39402681840018 ) ;
  }

  @Test
  public void test369() {
    coral.tests.JPFBenchmark.benchmark20(-26.700393416085817,-46.24765283459862 ) ;
  }

  @Test
  public void test370() {
    coral.tests.JPFBenchmark.benchmark20(-26.778405942931442,7.33278240699191 ) ;
  }

  @Test
  public void test371() {
    coral.tests.JPFBenchmark.benchmark20(26.84577787801777,-0.026591881922305605 ) ;
  }

  @Test
  public void test372() {
    coral.tests.JPFBenchmark.benchmark20(26.898742139468695,-0.05839664615729585 ) ;
  }

  @Test
  public void test373() {
    coral.tests.JPFBenchmark.benchmark20(-26.915958157415247,4.006801005489336 ) ;
  }

  @Test
  public void test374() {
    coral.tests.JPFBenchmark.benchmark20(-2.7715751645990707,11.901796100331186 ) ;
  }

  @Test
  public void test375() {
    coral.tests.JPFBenchmark.benchmark20(27.81218271470842,-65.4686896124308 ) ;
  }

  @Test
  public void test376() {
    coral.tests.JPFBenchmark.benchmark20(2.7849257675497228,15.696586194365764 ) ;
  }

  @Test
  public void test377() {
    coral.tests.JPFBenchmark.benchmark20(27.91713624989224,-10.803145854395584 ) ;
  }

  @Test
  public void test378() {
    coral.tests.JPFBenchmark.benchmark20(-28.076338170181003,73.4555136900427 ) ;
  }

  @Test
  public void test379() {
    coral.tests.JPFBenchmark.benchmark20(-28.7111518843234,35.61641876520523 ) ;
  }

  @Test
  public void test380() {
    coral.tests.JPFBenchmark.benchmark20(2.87982932754646,-43.80340566868932 ) ;
  }

  @Test
  public void test381() {
    coral.tests.JPFBenchmark.benchmark20(28.86474512029664,-74.24580653322583 ) ;
  }

  @Test
  public void test382() {
    coral.tests.JPFBenchmark.benchmark20(28.9530087687113,-82.73368782115496 ) ;
  }

  @Test
  public void test383() {
    coral.tests.JPFBenchmark.benchmark20(-29.012706387142956,55.69997259733403 ) ;
  }

  @Test
  public void test384() {
    coral.tests.JPFBenchmark.benchmark20(29.042296940055564,-7.9160549107246965 ) ;
  }

  @Test
  public void test385() {
    coral.tests.JPFBenchmark.benchmark20(-29.07539430762984,121.44970197779602 ) ;
  }

  @Test
  public void test386() {
    coral.tests.JPFBenchmark.benchmark20(29.536211568639146,-95.72508190480508 ) ;
  }

  @Test
  public void test387() {
    coral.tests.JPFBenchmark.benchmark20(29.750614706013636,-0.05279878558197938 ) ;
  }

  @Test
  public void test388() {
    coral.tests.JPFBenchmark.benchmark20(2.9797628643929377,55.87840986607526 ) ;
  }

  @Test
  public void test389() {
    coral.tests.JPFBenchmark.benchmark20(-2.981577671132257,12.405772737852018 ) ;
  }

  @Test
  public void test390() {
    coral.tests.JPFBenchmark.benchmark20(-29.84061101328632,0.05263954970947179 ) ;
  }

  @Test
  public void test391() {
    coral.tests.JPFBenchmark.benchmark20(29.87822482084002,0.2102931263438741 ) ;
  }

  @Test
  public void test392() {
    coral.tests.JPFBenchmark.benchmark20(30.096637573254156,-0.05219175474242377 ) ;
  }

  @Test
  public void test393() {
    coral.tests.JPFBenchmark.benchmark20(-30.12100727780637,81.15380485530116 ) ;
  }

  @Test
  public void test394() {
    coral.tests.JPFBenchmark.benchmark20(30.12360625263466,-99.1238709148457 ) ;
  }

  @Test
  public void test395() {
    coral.tests.JPFBenchmark.benchmark20(3.0167005884700715,-31.626599389993707 ) ;
  }

  @Test
  public void test396() {
    coral.tests.JPFBenchmark.benchmark20(-3.0511187905915023,18.823276066289168 ) ;
  }

  @Test
  public void test397() {
    coral.tests.JPFBenchmark.benchmark20(30.62530808157527,-79.60740371495744 ) ;
  }

  @Test
  public void test398() {
    coral.tests.JPFBenchmark.benchmark20(30.63052837250048,-0.051282051282051294 ) ;
  }

  @Test
  public void test399() {
    coral.tests.JPFBenchmark.benchmark20(30.6925908857624,-98.49171255882707 ) ;
  }

  @Test
  public void test400() {
    coral.tests.JPFBenchmark.benchmark20(30.86405723690497,-73.09969420269127 ) ;
  }

  @Test
  public void test401() {
    coral.tests.JPFBenchmark.benchmark20(-30.93330815924743,0.05078009499366498 ) ;
  }

  @Test
  public void test402() {
    coral.tests.JPFBenchmark.benchmark20(31.07092023790267,-0.0505551916315099 ) ;
  }

  @Test
  public void test403() {
    coral.tests.JPFBenchmark.benchmark20(3.1415926535896714,-4.481335848690729 ) ;
  }

  @Test
  public void test404() {
    coral.tests.JPFBenchmark.benchmark20(-31.533168757296124,99.4747929970919 ) ;
  }

  @Test
  public void test405() {
    coral.tests.JPFBenchmark.benchmark20(-31.68507779650365,9.96289757511748 ) ;
  }

  @Test
  public void test406() {
    coral.tests.JPFBenchmark.benchmark20(32.09389625659645,-77.93417573711135 ) ;
  }

  @Test
  public void test407() {
    coral.tests.JPFBenchmark.benchmark20(-32.15517312493897,5.551115123125783E-17 ) ;
  }

  @Test
  public void test408() {
    coral.tests.JPFBenchmark.benchmark20(32.22115072205113,-183.903280831841 ) ;
  }

  @Test
  public void test409() {
    coral.tests.JPFBenchmark.benchmark20(-32.33306344210301,80.2684417753201 ) ;
  }

  @Test
  public void test410() {
    coral.tests.JPFBenchmark.benchmark20(-3.237972819403976,0.48511720585845997 ) ;
  }

  @Test
  public void test411() {
    coral.tests.JPFBenchmark.benchmark20(3.2407396902310044,-1.940144616273181 ) ;
  }

  @Test
  public void test412() {
    coral.tests.JPFBenchmark.benchmark20(-32.566395849243,38.20663269601735 ) ;
  }

  @Test
  public void test413() {
    coral.tests.JPFBenchmark.benchmark20(32.75924100684168,-61.03730536331456 ) ;
  }

  @Test
  public void test414() {
    coral.tests.JPFBenchmark.benchmark20(-33.00028531904633,88.54444777678316 ) ;
  }

  @Test
  public void test415() {
    coral.tests.JPFBenchmark.benchmark20(-33.06147795678203,-31.340711076503496 ) ;
  }

  @Test
  public void test416() {
    coral.tests.JPFBenchmark.benchmark20(33.1174097847186,0.09486226954378 ) ;
  }

  @Test
  public void test417() {
    coral.tests.JPFBenchmark.benchmark20(-33.21977306480865,44.87844179856327 ) ;
  }

  @Test
  public void test418() {
    coral.tests.JPFBenchmark.benchmark20(-3.3221778242802866,0.47282126661452617 ) ;
  }

  @Test
  public void test419() {
    coral.tests.JPFBenchmark.benchmark20(3.3300493395839297,-0.47170361955993073 ) ;
  }

  @Test
  public void test420() {
    coral.tests.JPFBenchmark.benchmark20(33.77210095110942,-73.5262777545902 ) ;
  }

  @Test
  public void test421() {
    coral.tests.JPFBenchmark.benchmark20(33.772120820617324,-0.041094840409711564 ) ;
  }

  @Test
  public void test422() {
    coral.tests.JPFBenchmark.benchmark20(-33.7721210260883,0.046511627906979464 ) ;
  }

  @Test
  public void test423() {
    coral.tests.JPFBenchmark.benchmark20(3.3778865421009607,0.9323596639955215 ) ;
  }

  @Test
  public void test424() {
    coral.tests.JPFBenchmark.benchmark20(33.79623577180069,-41.840403596548335 ) ;
  }

  @Test
  public void test425() {
    coral.tests.JPFBenchmark.benchmark20(-34.090281483872104,40.00247008362459 ) ;
  }

  @Test
  public void test426() {
    coral.tests.JPFBenchmark.benchmark20(34.4716271067396,-0.04556780339758859 ) ;
  }

  @Test
  public void test427() {
    coral.tests.JPFBenchmark.benchmark20(34.89698941599525,-67.16277650648263 ) ;
  }

  @Test
  public void test428() {
    coral.tests.JPFBenchmark.benchmark20(35.11895640142157,-0.044727875989256205 ) ;
  }

  @Test
  public void test429() {
    coral.tests.JPFBenchmark.benchmark20(-35.157354762933885,82.06862026269098 ) ;
  }

  @Test
  public void test430() {
    coral.tests.JPFBenchmark.benchmark20(35.178805672096445,-33.239028694024796 ) ;
  }

  @Test
  public void test431() {
    coral.tests.JPFBenchmark.benchmark20(3.5284529787076506,-0.44517989506274347 ) ;
  }

  @Test
  public void test432() {
    coral.tests.JPFBenchmark.benchmark20(-35.32169978877032,176.53923789788496 ) ;
  }

  @Test
  public void test433() {
    coral.tests.JPFBenchmark.benchmark20(-3.552713678800501E-15,1.7105694144590052E-49 ) ;
  }

  @Test
  public void test434() {
    coral.tests.JPFBenchmark.benchmark20(3.552713678800501E-15,-21.967245153767934 ) ;
  }

  @Test
  public void test435() {
    coral.tests.JPFBenchmark.benchmark20(35.56517494261632,-63.430547284489215 ) ;
  }

  @Test
  public void test436() {
    coral.tests.JPFBenchmark.benchmark20(35.59443958602989,-22.956578765917975 ) ;
  }

  @Test
  public void test437() {
    coral.tests.JPFBenchmark.benchmark20(-3.5805097093067113,0.43870746187671905 ) ;
  }

  @Test
  public void test438() {
    coral.tests.JPFBenchmark.benchmark20(36.143671372171895,-0.04345978886921387 ) ;
  }

  @Test
  public void test439() {
    coral.tests.JPFBenchmark.benchmark20(-36.28753496686227,0.043287490545424134 ) ;
  }

  @Test
  public void test440() {
    coral.tests.JPFBenchmark.benchmark20(-36.34964422796285,47.56371112626704 ) ;
  }

  @Test
  public void test441() {
    coral.tests.JPFBenchmark.benchmark20(-364.4107618310875,10.452987374292036 ) ;
  }

  @Test
  public void test442() {
    coral.tests.JPFBenchmark.benchmark20(36.48047053945186,-67.52221345147198 ) ;
  }

  @Test
  public void test443() {
    coral.tests.JPFBenchmark.benchmark20(36.508409752761935,-66.01743141789633 ) ;
  }

  @Test
  public void test444() {
    coral.tests.JPFBenchmark.benchmark20(-36.753287492577144,0.04273893395555817 ) ;
  }

  @Test
  public void test445() {
    coral.tests.JPFBenchmark.benchmark20(-3.6902371133313636,0.4256627090763976 ) ;
  }

  @Test
  public void test446() {
    coral.tests.JPFBenchmark.benchmark20(-37.040053807251105,0.00981229237113573 ) ;
  }

  @Test
  public void test447() {
    coral.tests.JPFBenchmark.benchmark20(-37.040053807251105,67.38205973528693 ) ;
  }

  @Test
  public void test448() {
    coral.tests.JPFBenchmark.benchmark20(-37.11500741052098,25.858988687980666 ) ;
  }

  @Test
  public void test449() {
    coral.tests.JPFBenchmark.benchmark20(37.244735519438876,-40.506908984003346 ) ;
  }

  @Test
  public void test450() {
    coral.tests.JPFBenchmark.benchmark20(3.775612518398802,-0.41603748243240146 ) ;
  }

  @Test
  public void test451() {
    coral.tests.JPFBenchmark.benchmark20(-37.89862947193179,44.888363517282784 ) ;
  }

  @Test
  public void test452() {
    coral.tests.JPFBenchmark.benchmark20(3.800650689416205,-0.2940641748491166 ) ;
  }

  @Test
  public void test453() {
    coral.tests.JPFBenchmark.benchmark20(-38.180856580081056,78.77991239776418 ) ;
  }

  @Test
  public void test454() {
    coral.tests.JPFBenchmark.benchmark20(-38.46982318133257,22.049230963994823 ) ;
  }

  @Test
  public void test455() {
    coral.tests.JPFBenchmark.benchmark20(-38.83301702109425,12.78728047888584 ) ;
  }

  @Test
  public void test456() {
    coral.tests.JPFBenchmark.benchmark20(-38.85945389932273,83.72516419542214 ) ;
  }

  @Test
  public void test457() {
    coral.tests.JPFBenchmark.benchmark20(-39.042066017504624,0.017953792995875517 ) ;
  }

  @Test
  public void test458() {
    coral.tests.JPFBenchmark.benchmark20(-39.109614524548356,-92.4674809128062 ) ;
  }

  @Test
  public void test459() {
    coral.tests.JPFBenchmark.benchmark20(-3.9193770974243143,0.40077703363301587 ) ;
  }

  @Test
  public void test460() {
    coral.tests.JPFBenchmark.benchmark20(-3.923342691696871,0.28484846503647243 ) ;
  }

  @Test
  public void test461() {
    coral.tests.JPFBenchmark.benchmark20(3.944304526105059E-31,-6.336535903271454 ) ;
  }

  @Test
  public void test462() {
    coral.tests.JPFBenchmark.benchmark20(-3.969168410049256,30.395581811137532 ) ;
  }

  @Test
  public void test463() {
    coral.tests.JPFBenchmark.benchmark20(39.83068957994916,-25.256769502736795 ) ;
  }

  @Test
  public void test464() {
    coral.tests.JPFBenchmark.benchmark20(39.83411842814558,-74.92352826241422 ) ;
  }

  @Test
  public void test465() {
    coral.tests.JPFBenchmark.benchmark20(-4.003024920753689,5.493632692895666 ) ;
  }

  @Test
  public void test466() {
    coral.tests.JPFBenchmark.benchmark20(-40.05530633326986,44.25330530129992 ) ;
  }

  @Test
  public void test467() {
    coral.tests.JPFBenchmark.benchmark20(40.13375987558882,-0.03913902738403352 ) ;
  }

  @Test
  public void test468() {
    coral.tests.JPFBenchmark.benchmark20(40.2761386379498,-0.03900066838370719 ) ;
  }

  @Test
  public void test469() {
    coral.tests.JPFBenchmark.benchmark20(-4.053375127033269,0.38752799273838434 ) ;
  }

  @Test
  public void test470() {
    coral.tests.JPFBenchmark.benchmark20(40.68672466768294,-12.933377532906503 ) ;
  }

  @Test
  public void test471() {
    coral.tests.JPFBenchmark.benchmark20(40.984191049984,-50.45815246603234 ) ;
  }

  @Test
  public void test472() {
    coral.tests.JPFBenchmark.benchmark20(4.107246967904743,-0.38244506334037354 ) ;
  }

  @Test
  public void test473() {
    coral.tests.JPFBenchmark.benchmark20(-41.48968251275916,0.03785992641211067 ) ;
  }

  @Test
  public void test474() {
    coral.tests.JPFBenchmark.benchmark20(-41.57617345563939,46.99977097742748 ) ;
  }

  @Test
  public void test475() {
    coral.tests.JPFBenchmark.benchmark20(-41.676976505969414,60.75768506393329 ) ;
  }

  @Test
  public void test476() {
    coral.tests.JPFBenchmark.benchmark20(419.0773592213958,-5.296242202081572 ) ;
  }

  @Test
  public void test477() {
    coral.tests.JPFBenchmark.benchmark20(-42.04827404663432,49.857465364927236 ) ;
  }

  @Test
  public void test478() {
    coral.tests.JPFBenchmark.benchmark20(-42.05201191177215,77.12009350915798 ) ;
  }

  @Test
  public void test479() {
    coral.tests.JPFBenchmark.benchmark20(42.16820875303645,-24.610045868867815 ) ;
  }

  @Test
  public void test480() {
    coral.tests.JPFBenchmark.benchmark20(42.40806024310933,-90.19791208494745 ) ;
  }

  @Test
  public void test481() {
    coral.tests.JPFBenchmark.benchmark20(-42.411120391591766,0.03703736926285766 ) ;
  }

  @Test
  public void test482() {
    coral.tests.JPFBenchmark.benchmark20(-42.55092911528871,0.0032030186688407625 ) ;
  }

  @Test
  public void test483() {
    coral.tests.JPFBenchmark.benchmark20(42.979934447706114,-63.66720630185403 ) ;
  }

  @Test
  public void test484() {
    coral.tests.JPFBenchmark.benchmark20(43.37017749834161,-18.115461225253256 ) ;
  }

  @Test
  public void test485() {
    coral.tests.JPFBenchmark.benchmark20(-43.37107293122311,5.53054124407204E-4 ) ;
  }

  @Test
  public void test486() {
    coral.tests.JPFBenchmark.benchmark20(43.72099462177068,-88.41815685312243 ) ;
  }

  @Test
  public void test487() {
    coral.tests.JPFBenchmark.benchmark20(43.77370606596213,-0.035884471934541716 ) ;
  }

  @Test
  public void test488() {
    coral.tests.JPFBenchmark.benchmark20(43.801777662558095,-62.65120959028179 ) ;
  }

  @Test
  public void test489() {
    coral.tests.JPFBenchmark.benchmark20(-44.198846950037066,37.97603468929396 ) ;
  }

  @Test
  public void test490() {
    coral.tests.JPFBenchmark.benchmark20(-4.440892098500626E-16,82.64029379181875 ) ;
  }

  @Test
  public void test491() {
    coral.tests.JPFBenchmark.benchmark20(4.464301128281135,-1.09E-321 ) ;
  }

  @Test
  public void test492() {
    coral.tests.JPFBenchmark.benchmark20(-44.70008164397373,62.411516844844385 ) ;
  }

  @Test
  public void test493() {
    coral.tests.JPFBenchmark.benchmark20(-44.789628951864835,39.664777029394465 ) ;
  }

  @Test
  public void test494() {
    coral.tests.JPFBenchmark.benchmark20(-44.81540595230699,0.025119170791767953 ) ;
  }

  @Test
  public void test495() {
    coral.tests.JPFBenchmark.benchmark20(-45.11201431405847,45.43998395186984 ) ;
  }

  @Test
  public void test496() {
    coral.tests.JPFBenchmark.benchmark20(45.83436472189152,-1.3916088766314516 ) ;
  }

  @Test
  public void test497() {
    coral.tests.JPFBenchmark.benchmark20(45.856561455611,-74.13082953184924 ) ;
  }

  @Test
  public void test498() {
    coral.tests.JPFBenchmark.benchmark20(-4.592743859993639,6.156305412239404 ) ;
  }

  @Test
  public void test499() {
    coral.tests.JPFBenchmark.benchmark20(-4.598538175318808,72.51632252660458 ) ;
  }

  @Test
  public void test500() {
    coral.tests.JPFBenchmark.benchmark20(46.03446341659887,-12.591085060379237 ) ;
  }

  @Test
  public void test501() {
    coral.tests.JPFBenchmark.benchmark20(-46.33849163764929,3.469446951953614E-18 ) ;
  }

  @Test
  public void test502() {
    coral.tests.JPFBenchmark.benchmark20(-46.355441054557645,2.3822038913217183E-20 ) ;
  }

  @Test
  public void test503() {
    coral.tests.JPFBenchmark.benchmark20(4.646910451957689,1.3521210215128106 ) ;
  }

  @Test
  public void test504() {
    coral.tests.JPFBenchmark.benchmark20(4.676747439895607,-3.552713678800501E-15 ) ;
  }

  @Test
  public void test505() {
    coral.tests.JPFBenchmark.benchmark20(-47.11558936207405,1.651328441127859 ) ;
  }

  @Test
  public void test506() {
    coral.tests.JPFBenchmark.benchmark20(47.133662026784485,-0.03332642233277494 ) ;
  }

  @Test
  public void test507() {
    coral.tests.JPFBenchmark.benchmark20(47.23982622696814,-57.09287061849773 ) ;
  }

  @Test
  public void test508() {
    coral.tests.JPFBenchmark.benchmark20(-47.332422867590346,0.033186476238267086 ) ;
  }

  @Test
  public void test509() {
    coral.tests.JPFBenchmark.benchmark20(4.742161309563727,-84.97169342636954 ) ;
  }

  @Test
  public void test510() {
    coral.tests.JPFBenchmark.benchmark20(47.48880200076695,-30.565886310953346 ) ;
  }

  @Test
  public void test511() {
    coral.tests.JPFBenchmark.benchmark20(475.4826258062522,-92.95169753488183 ) ;
  }

  @Test
  public void test512() {
    coral.tests.JPFBenchmark.benchmark20(47.812254380070065,-0.03285342528106483 ) ;
  }

  @Test
  public void test513() {
    coral.tests.JPFBenchmark.benchmark20(-4.787673088783156,100.0 ) ;
  }

  @Test
  public void test514() {
    coral.tests.JPFBenchmark.benchmark20(47.90218652356782,-15.911533909787522 ) ;
  }

  @Test
  public void test515() {
    coral.tests.JPFBenchmark.benchmark20(-4.791568408218282,99.19671468077436 ) ;
  }

  @Test
  public void test516() {
    coral.tests.JPFBenchmark.benchmark20(48.214604218771655,-15.010121405479211 ) ;
  }

  @Test
  public void test517() {
    coral.tests.JPFBenchmark.benchmark20(48.335479676408575,-95.80348850145984 ) ;
  }

  @Test
  public void test518() {
    coral.tests.JPFBenchmark.benchmark20(-48.52871187265018,-68.94913976667468 ) ;
  }

  @Test
  public void test519() {
    coral.tests.JPFBenchmark.benchmark20(49.28722279095186,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test520() {
    coral.tests.JPFBenchmark.benchmark20(49.45241881703563,-100.0 ) ;
  }

  @Test
  public void test521() {
    coral.tests.JPFBenchmark.benchmark20(-49.48008429396593,0.0317460317460818 ) ;
  }

  @Test
  public void test522() {
    coral.tests.JPFBenchmark.benchmark20(-49.57160664467009,0.031687420140613654 ) ;
  }

  @Test
  public void test523() {
    coral.tests.JPFBenchmark.benchmark20(-49.60642442161028,0.03165187810376883 ) ;
  }

  @Test
  public void test524() {
    coral.tests.JPFBenchmark.benchmark20(49.62745235253024,-13.85895158759709 ) ;
  }

  @Test
  public void test525() {
    coral.tests.JPFBenchmark.benchmark20(49.76710003353202,-31.716410265140695 ) ;
  }

  @Test
  public void test526() {
    coral.tests.JPFBenchmark.benchmark20(-50.10931076525326,75.74316160820322 ) ;
  }

  @Test
  public void test527() {
    coral.tests.JPFBenchmark.benchmark20(-50.350994608321926,17.98031011928842 ) ;
  }

  @Test
  public void test528() {
    coral.tests.JPFBenchmark.benchmark20(5.047597471508498,-33.29806004375055 ) ;
  }

  @Test
  public void test529() {
    coral.tests.JPFBenchmark.benchmark20(51.018948703860445,-19.428146978877535 ) ;
  }

  @Test
  public void test530() {
    coral.tests.JPFBenchmark.benchmark20(-51.17588062083414,41.387420308441854 ) ;
  }

  @Test
  public void test531() {
    coral.tests.JPFBenchmark.benchmark20(-51.26720182901532,44.92235974508543 ) ;
  }

  @Test
  public void test532() {
    coral.tests.JPFBenchmark.benchmark20(51.84585725436557,-15.284514542404864 ) ;
  }

  @Test
  public void test533() {
    coral.tests.JPFBenchmark.benchmark20(-52.15139889209042,39.77616873891563 ) ;
  }

  @Test
  public void test534() {
    coral.tests.JPFBenchmark.benchmark20(-5.220561008086207,9.592326932761353E-13 ) ;
  }

  @Test
  public void test535() {
    coral.tests.JPFBenchmark.benchmark20(52.35140537663031,-60.93469839828409 ) ;
  }

  @Test
  public void test536() {
    coral.tests.JPFBenchmark.benchmark20(-52.36778741291464,65.1548135749569 ) ;
  }

  @Test
  public void test537() {
    coral.tests.JPFBenchmark.benchmark20(-52.418206145250345,8.825348615558283 ) ;
  }

  @Test
  public void test538() {
    coral.tests.JPFBenchmark.benchmark20(5.243998469775816,2.3967062351221076 ) ;
  }

  @Test
  public void test539() {
    coral.tests.JPFBenchmark.benchmark20(5.268703101786315,-19.080780027401637 ) ;
  }

  @Test
  public void test540() {
    coral.tests.JPFBenchmark.benchmark20(52.77436798694217,-54.10683067612476 ) ;
  }

  @Test
  public void test541() {
    coral.tests.JPFBenchmark.benchmark20(5.289827785241101,-0.29694659080915664 ) ;
  }

  @Test
  public void test542() {
    coral.tests.JPFBenchmark.benchmark20(53.12486637190341,-11.235791298823727 ) ;
  }

  @Test
  public void test543() {
    coral.tests.JPFBenchmark.benchmark20(53.365617668001136,-46.13455956889412 ) ;
  }

  @Test
  public void test544() {
    coral.tests.JPFBenchmark.benchmark20(-53.93420836850987,0.02912430485791694 ) ;
  }

  @Test
  public void test545() {
    coral.tests.JPFBenchmark.benchmark20(54.06228413132497,-0.029055308188222478 ) ;
  }

  @Test
  public void test546() {
    coral.tests.JPFBenchmark.benchmark20(54.068639955895755,-0.02905189270668096 ) ;
  }

  @Test
  public void test547() {
    coral.tests.JPFBenchmark.benchmark20(54.1548710329061,-2.3292779433190987 ) ;
  }

  @Test
  public void test548() {
    coral.tests.JPFBenchmark.benchmark20(-54.191222461710595,27.597527297780147 ) ;
  }

  @Test
  public void test549() {
    coral.tests.JPFBenchmark.benchmark20(-54.232598623296056,89.96237530335094 ) ;
  }

  @Test
  public void test550() {
    coral.tests.JPFBenchmark.benchmark20(-54.32300388445306,50.554701329385296 ) ;
  }

  @Test
  public void test551() {
    coral.tests.JPFBenchmark.benchmark20(54.395489384784895,-87.16266194320221 ) ;
  }

  @Test
  public void test552() {
    coral.tests.JPFBenchmark.benchmark20(54.47405634926892,-99.39943152460573 ) ;
  }

  @Test
  public void test553() {
    coral.tests.JPFBenchmark.benchmark20(54.63614968725804,-94.53211166502746 ) ;
  }

  @Test
  public void test554() {
    coral.tests.JPFBenchmark.benchmark20(-5.464842739493108,-6.540091845628552 ) ;
  }

  @Test
  public void test555() {
    coral.tests.JPFBenchmark.benchmark20(546.7539027215348,-153.99032906062908 ) ;
  }

  @Test
  public void test556() {
    coral.tests.JPFBenchmark.benchmark20(5.512104660876261,43.33933381744055 ) ;
  }

  @Test
  public void test557() {
    coral.tests.JPFBenchmark.benchmark20(55.281404690948364,-0.02841455161236328 ) ;
  }

  @Test
  public void test558() {
    coral.tests.JPFBenchmark.benchmark20(5.52982473965986,1.1362358850392915 ) ;
  }

  @Test
  public void test559() {
    coral.tests.JPFBenchmark.benchmark20(-55.36247550000601,38.60771591115616 ) ;
  }

  @Test
  public void test560() {
    coral.tests.JPFBenchmark.benchmark20(5.551115123125783E-17,-100.0 ) ;
  }

  @Test
  public void test561() {
    coral.tests.JPFBenchmark.benchmark20(5.551115123125783E-17,-59.449372313680385 ) ;
  }

  @Test
  public void test562() {
    coral.tests.JPFBenchmark.benchmark20(55.57777397001507,-75.53007496635831 ) ;
  }

  @Test
  public void test563() {
    coral.tests.JPFBenchmark.benchmark20(55.834123783365435,-0.028133267263036752 ) ;
  }

  @Test
  public void test564() {
    coral.tests.JPFBenchmark.benchmark20(55.95932697211198,-36.176868253422654 ) ;
  }

  @Test
  public void test565() {
    coral.tests.JPFBenchmark.benchmark20(56.06280194731337,-77.80719439412347 ) ;
  }

  @Test
  public void test566() {
    coral.tests.JPFBenchmark.benchmark20(5.61380206469583,-48.20550785798268 ) ;
  }

  @Test
  public void test567() {
    coral.tests.JPFBenchmark.benchmark20(5.622786769189652,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test568() {
    coral.tests.JPFBenchmark.benchmark20(-5.624127271353175,0.279296013587004 ) ;
  }

  @Test
  public void test569() {
    coral.tests.JPFBenchmark.benchmark20(-56.85820618118437,46.09504777542889 ) ;
  }

  @Test
  public void test570() {
    coral.tests.JPFBenchmark.benchmark20(57.07779179330021,-0.027520271500399505 ) ;
  }

  @Test
  public void test571() {
    coral.tests.JPFBenchmark.benchmark20(-571.6588975780144,132.64318845298956 ) ;
  }

  @Test
  public void test572() {
    coral.tests.JPFBenchmark.benchmark20(57.46933973466537,-0.02733277142294008 ) ;
  }

  @Test
  public void test573() {
    coral.tests.JPFBenchmark.benchmark20(-57.58008329912868,100.0 ) ;
  }

  @Test
  public void test574() {
    coral.tests.JPFBenchmark.benchmark20(-57.98684111548147,0.027088841133226026 ) ;
  }

  @Test
  public void test575() {
    coral.tests.JPFBenchmark.benchmark20(58.06938647463963,-47.51754251901781 ) ;
  }

  @Test
  public void test576() {
    coral.tests.JPFBenchmark.benchmark20(59.14998872607393,-53.87462368560858 ) ;
  }

  @Test
  public void test577() {
    coral.tests.JPFBenchmark.benchmark20(-59.24377713179251,28.955860406314684 ) ;
  }

  @Test
  public void test578() {
    coral.tests.JPFBenchmark.benchmark20(-60.522685438126445,57.52714044281913 ) ;
  }

  @Test
  public void test579() {
    coral.tests.JPFBenchmark.benchmark20(-60.686224846621116,0.02588390249624073 ) ;
  }

  @Test
  public void test580() {
    coral.tests.JPFBenchmark.benchmark20(-60.87530917928259,32.435411526615695 ) ;
  }

  @Test
  public void test581() {
    coral.tests.JPFBenchmark.benchmark20(60.91273752441592,-83.26292868260211 ) ;
  }

  @Test
  public void test582() {
    coral.tests.JPFBenchmark.benchmark20(-61.05255959025329,17.289964366096168 ) ;
  }

  @Test
  public void test583() {
    coral.tests.JPFBenchmark.benchmark20(-61.29882516408338,77.36638197945959 ) ;
  }

  @Test
  public void test584() {
    coral.tests.JPFBenchmark.benchmark20(61.326620612739646,-18.037139094920672 ) ;
  }

  @Test
  public void test585() {
    coral.tests.JPFBenchmark.benchmark20(61.42081167198825,-24.747961445861748 ) ;
  }

  @Test
  public void test586() {
    coral.tests.JPFBenchmark.benchmark20(61.50471599165639,-52.427835805500614 ) ;
  }

  @Test
  public void test587() {
    coral.tests.JPFBenchmark.benchmark20(-62.024808714032,47.43426051816673 ) ;
  }

  @Test
  public void test588() {
    coral.tests.JPFBenchmark.benchmark20(62.046454908398395,-0.21814150307462646 ) ;
  }

  @Test
  public void test589() {
    coral.tests.JPFBenchmark.benchmark20(-62.0464549083984,0.025316455696202535 ) ;
  }

  @Test
  public void test590() {
    coral.tests.JPFBenchmark.benchmark20(-62.30560658734407,14.121748260423345 ) ;
  }

  @Test
  public void test591() {
    coral.tests.JPFBenchmark.benchmark20(6.251443403479854,-77.98478466708568 ) ;
  }

  @Test
  public void test592() {
    coral.tests.JPFBenchmark.benchmark20(-62.529581012766954,8.449304479836083 ) ;
  }

  @Test
  public void test593() {
    coral.tests.JPFBenchmark.benchmark20(62.84647704041757,-25.660563462406728 ) ;
  }

  @Test
  public void test594() {
    coral.tests.JPFBenchmark.benchmark20(-63.48845823399016,10.094510390696552 ) ;
  }

  @Test
  public void test595() {
    coral.tests.JPFBenchmark.benchmark20(63.61822779769343,-0.024690979003534078 ) ;
  }

  @Test
  public void test596() {
    coral.tests.JPFBenchmark.benchmark20(-6.3886802245716865,42.44473399934936 ) ;
  }

  @Test
  public void test597() {
    coral.tests.JPFBenchmark.benchmark20(-63.89981696533383,74.1152502495571 ) ;
  }

  @Test
  public void test598() {
    coral.tests.JPFBenchmark.benchmark20(-64.06153691016792,121.42917117083411 ) ;
  }

  @Test
  public void test599() {
    coral.tests.JPFBenchmark.benchmark20(-64.44472292557926,0.024374320432859205 ) ;
  }

  @Test
  public void test600() {
    coral.tests.JPFBenchmark.benchmark20(-6.490067412223993,7.105427357601002E-15 ) ;
  }

  @Test
  public void test601() {
    coral.tests.JPFBenchmark.benchmark20(-65.28438601928244,85.02981202630079 ) ;
  }

  @Test
  public void test602() {
    coral.tests.JPFBenchmark.benchmark20(-65.31438768955924,0.024049774978538066 ) ;
  }

  @Test
  public void test603() {
    coral.tests.JPFBenchmark.benchmark20(-65.47181705193834,0.02399194642098834 ) ;
  }

  @Test
  public void test604() {
    coral.tests.JPFBenchmark.benchmark20(65.51726526115894,-66.36932947593466 ) ;
  }

  @Test
  public void test605() {
    coral.tests.JPFBenchmark.benchmark20(65.81460161301521,-7.7041955220324745 ) ;
  }

  @Test
  public void test606() {
    coral.tests.JPFBenchmark.benchmark20(-66.02335037283768,3.24950078147144 ) ;
  }

  @Test
  public void test607() {
    coral.tests.JPFBenchmark.benchmark20(6.623434437512628,-0.23715737531853343 ) ;
  }

  @Test
  public void test608() {
    coral.tests.JPFBenchmark.benchmark20(66.37680935246328,-50.7010090832329 ) ;
  }

  @Test
  public void test609() {
    coral.tests.JPFBenchmark.benchmark20(66.58766268920499,-22.375201420266237 ) ;
  }

  @Test
  public void test610() {
    coral.tests.JPFBenchmark.benchmark20(-66.73752287827345,42.76659969822609 ) ;
  }

  @Test
  public void test611() {
    coral.tests.JPFBenchmark.benchmark20(67.14428919194404,-97.04281049583308 ) ;
  }

  @Test
  public void test612() {
    coral.tests.JPFBenchmark.benchmark20(-67.39920608876143,45.97364678621173 ) ;
  }

  @Test
  public void test613() {
    coral.tests.JPFBenchmark.benchmark20(67.60713907185925,-0.023234178348018924 ) ;
  }

  @Test
  public void test614() {
    coral.tests.JPFBenchmark.benchmark20(67.72775811885526,-0.023192799679539227 ) ;
  }

  @Test
  public void test615() {
    coral.tests.JPFBenchmark.benchmark20(67.73116947169396,-11.688543222184723 ) ;
  }

  @Test
  public void test616() {
    coral.tests.JPFBenchmark.benchmark20(67.73473436031746,-0.023190410970521956 ) ;
  }

  @Test
  public void test617() {
    coral.tests.JPFBenchmark.benchmark20(678.3119908220206,-0.0012990183655337915 ) ;
  }

  @Test
  public void test618() {
    coral.tests.JPFBenchmark.benchmark20(67.96757612563857,-53.03966643675424 ) ;
  }

  @Test
  public void test619() {
    coral.tests.JPFBenchmark.benchmark20(-68.04788089047491,100.0 ) ;
  }

  @Test
  public void test620() {
    coral.tests.JPFBenchmark.benchmark20(6.806704450697861,-0.2307719305535365 ) ;
  }

  @Test
  public void test621() {
    coral.tests.JPFBenchmark.benchmark20(-68.32335392946469,14.991200622703303 ) ;
  }

  @Test
  public void test622() {
    coral.tests.JPFBenchmark.benchmark20(68.329640214141,-0.02298850654153311 ) ;
  }

  @Test
  public void test623() {
    coral.tests.JPFBenchmark.benchmark20(-68.32964021557798,0.01932303292571417 ) ;
  }

  @Test
  public void test624() {
    coral.tests.JPFBenchmark.benchmark20(-68.45598034314904,60.218046318043854 ) ;
  }

  @Test
  public void test625() {
    coral.tests.JPFBenchmark.benchmark20(68.49641399358211,-42.465825514986435 ) ;
  }

  @Test
  public void test626() {
    coral.tests.JPFBenchmark.benchmark20(-6.865181718581031,0.228806227014128 ) ;
  }

  @Test
  public void test627() {
    coral.tests.JPFBenchmark.benchmark20(68.77209475760998,50.7718968883276 ) ;
  }

  @Test
  public void test628() {
    coral.tests.JPFBenchmark.benchmark20(-68.91602169853759,56.16811711739271 ) ;
  }

  @Test
  public void test629() {
    coral.tests.JPFBenchmark.benchmark20(68.97225372710483,-75.5330308560237 ) ;
  }

  @Test
  public void test630() {
    coral.tests.JPFBenchmark.benchmark20(7.003370092818677,-0.2242914919497978 ) ;
  }

  @Test
  public void test631() {
    coral.tests.JPFBenchmark.benchmark20(-70.07544236955795,67.87797080411002 ) ;
  }

  @Test
  public void test632() {
    coral.tests.JPFBenchmark.benchmark20(-70.26728243766358,53.33696808656765 ) ;
  }

  @Test
  public void test633() {
    coral.tests.JPFBenchmark.benchmark20(70.70901242069664,-23.834658525860462 ) ;
  }

  @Test
  public void test634() {
    coral.tests.JPFBenchmark.benchmark20(70.77098576488942,-0.022195484629985884 ) ;
  }

  @Test
  public void test635() {
    coral.tests.JPFBenchmark.benchmark20(71.1045365672327,-26.686369877033627 ) ;
  }

  @Test
  public void test636() {
    coral.tests.JPFBenchmark.benchmark20(-71.47123286916711,2.0303519614918897 ) ;
  }

  @Test
  public void test637() {
    coral.tests.JPFBenchmark.benchmark20(-71.58601919546267,0.021942780789443006 ) ;
  }

  @Test
  public void test638() {
    coral.tests.JPFBenchmark.benchmark20(-71.81946298527663,60.21200319528234 ) ;
  }

  @Test
  public void test639() {
    coral.tests.JPFBenchmark.benchmark20(71.99669370817784,-29.18730120456155 ) ;
  }

  @Test
  public void test640() {
    coral.tests.JPFBenchmark.benchmark20(72.29621321672633,-33.691946919242355 ) ;
  }

  @Test
  public void test641() {
    coral.tests.JPFBenchmark.benchmark20(-72.61274977565398,11.313804827002649 ) ;
  }

  @Test
  public void test642() {
    coral.tests.JPFBenchmark.benchmark20(-72.67790828531639,22.05048056633385 ) ;
  }

  @Test
  public void test643() {
    coral.tests.JPFBenchmark.benchmark20(73.01462382128781,-120.83575316120071 ) ;
  }

  @Test
  public void test644() {
    coral.tests.JPFBenchmark.benchmark20(7.306363903689995,-6.169436240004954 ) ;
  }

  @Test
  public void test645() {
    coral.tests.JPFBenchmark.benchmark20(73.19826220713901,-8.881784197001252E-16 ) ;
  }

  @Test
  public void test646() {
    coral.tests.JPFBenchmark.benchmark20(73.2836635438247,-26.152572093977295 ) ;
  }

  @Test
  public void test647() {
    coral.tests.JPFBenchmark.benchmark20(-73.80495347859696,45.72957318105928 ) ;
  }

  @Test
  public void test648() {
    coral.tests.JPFBenchmark.benchmark20(7.41927157481102,-48.33920651423155 ) ;
  }

  @Test
  public void test649() {
    coral.tests.JPFBenchmark.benchmark20(-74.45263542196221,88.59098444346867 ) ;
  }

  @Test
  public void test650() {
    coral.tests.JPFBenchmark.benchmark20(-74.61282551670988,31.678909885078603 ) ;
  }

  @Test
  public void test651() {
    coral.tests.JPFBenchmark.benchmark20(-74.864762381822,0.020981784711792573 ) ;
  }

  @Test
  public void test652() {
    coral.tests.JPFBenchmark.benchmark20(-75.05153969122722,72.1806008590406 ) ;
  }

  @Test
  public void test653() {
    coral.tests.JPFBenchmark.benchmark20(-7.522910854988723,15.099787583048325 ) ;
  }

  @Test
  public void test654() {
    coral.tests.JPFBenchmark.benchmark20(-75.34625614103305,0.02084770242405517 ) ;
  }

  @Test
  public void test655() {
    coral.tests.JPFBenchmark.benchmark20(75.82456888439663,-74.4125616388221 ) ;
  }

  @Test
  public void test656() {
    coral.tests.JPFBenchmark.benchmark20(-7.69480352686702,15.544079471166537 ) ;
  }

  @Test
  public void test657() {
    coral.tests.JPFBenchmark.benchmark20(77.26243565961983,-4.859027726586464 ) ;
  }

  @Test
  public void test658() {
    coral.tests.JPFBenchmark.benchmark20(77.31666506792766,-0.020316400421757082 ) ;
  }

  @Test
  public void test659() {
    coral.tests.JPFBenchmark.benchmark20(7.779009632197962,-65.4370830642345 ) ;
  }

  @Test
  public void test660() {
    coral.tests.JPFBenchmark.benchmark20(-77.88075830391841,18.735903656836108 ) ;
  }

  @Test
  public void test661() {
    coral.tests.JPFBenchmark.benchmark20(77.9539218526956,-44.59265400844386 ) ;
  }

  @Test
  public void test662() {
    coral.tests.JPFBenchmark.benchmark20(77.98003016170486,-59.375882347696994 ) ;
  }

  @Test
  public void test663() {
    coral.tests.JPFBenchmark.benchmark20(7.810785246068374,-50.77215138094832 ) ;
  }

  @Test
  public void test664() {
    coral.tests.JPFBenchmark.benchmark20(-78.64402554894521,139.1004730206016 ) ;
  }

  @Test
  public void test665() {
    coral.tests.JPFBenchmark.benchmark20(78.80052002386655,-100.0 ) ;
  }

  @Test
  public void test666() {
    coral.tests.JPFBenchmark.benchmark20(-78.90905666761046,3.1086244689504383E-15 ) ;
  }

  @Test
  public void test667() {
    coral.tests.JPFBenchmark.benchmark20(79.13677808547433,-0.019849131652773442 ) ;
  }

  @Test
  public void test668() {
    coral.tests.JPFBenchmark.benchmark20(-79.19887437557124,73.47968980929791 ) ;
  }

  @Test
  public void test669() {
    coral.tests.JPFBenchmark.benchmark20(79.23684845353698,-5.551115123125783E-17 ) ;
  }

  @Test
  public void test670() {
    coral.tests.JPFBenchmark.benchmark20(-79.3528472915179,0.01979508461774881 ) ;
  }

  @Test
  public void test671() {
    coral.tests.JPFBenchmark.benchmark20(-80.20102626805627,44.796628118133356 ) ;
  }

  @Test
  public void test672() {
    coral.tests.JPFBenchmark.benchmark20(80.20379241158588,-44.79292017449643 ) ;
  }

  @Test
  public void test673() {
    coral.tests.JPFBenchmark.benchmark20(80.34097861020348,-82.66553164816204 ) ;
  }

  @Test
  public void test674() {
    coral.tests.JPFBenchmark.benchmark20(-80.70055579611527,12.048528249824614 ) ;
  }

  @Test
  public void test675() {
    coral.tests.JPFBenchmark.benchmark20(80.8402370161557,-76.74777713637945 ) ;
  }

  @Test
  public void test676() {
    coral.tests.JPFBenchmark.benchmark20(-81.00096346870168,48.446617576473386 ) ;
  }

  @Test
  public void test677() {
    coral.tests.JPFBenchmark.benchmark20(81.53500821757362,-1.7818759504918156 ) ;
  }

  @Test
  public void test678() {
    coral.tests.JPFBenchmark.benchmark20(-8.154468670428228,-1.1557807555197144 ) ;
  }

  @Test
  public void test679() {
    coral.tests.JPFBenchmark.benchmark20(81.86228826847838,-0.01918827777747012 ) ;
  }

  @Test
  public void test680() {
    coral.tests.JPFBenchmark.benchmark20(-8.200532357869981E-143,5.6902623986817984E-160 ) ;
  }

  @Test
  public void test681() {
    coral.tests.JPFBenchmark.benchmark20(8.221329528245505,16.826905712747703 ) ;
  }

  @Test
  public void test682() {
    coral.tests.JPFBenchmark.benchmark20(-82.25194362755421,146.9138248065796 ) ;
  }

  @Test
  public void test683() {
    coral.tests.JPFBenchmark.benchmark20(82.28516780121717,-13.982586630422462 ) ;
  }

  @Test
  public void test684() {
    coral.tests.JPFBenchmark.benchmark20(82.34046702916103,-0.018609962608260276 ) ;
  }

  @Test
  public void test685() {
    coral.tests.JPFBenchmark.benchmark20(-82.34046702916103,0.019076845000631296 ) ;
  }

  @Test
  public void test686() {
    coral.tests.JPFBenchmark.benchmark20(82.35033595408865,-17.09941212959312 ) ;
  }

  @Test
  public void test687() {
    coral.tests.JPFBenchmark.benchmark20(-82.38111747305801,32.73094900018797 ) ;
  }

  @Test
  public void test688() {
    coral.tests.JPFBenchmark.benchmark20(-82.51362864550755,13.606538656554818 ) ;
  }

  @Test
  public void test689() {
    coral.tests.JPFBenchmark.benchmark20(83.08717949734228,-0.018905399561013336 ) ;
  }

  @Test
  public void test690() {
    coral.tests.JPFBenchmark.benchmark20(-83.1711078332855,92.85050143457596 ) ;
  }

  @Test
  public void test691() {
    coral.tests.JPFBenchmark.benchmark20(-83.37543945464964,27.374573108840224 ) ;
  }

  @Test
  public void test692() {
    coral.tests.JPFBenchmark.benchmark20(-83.41218293624607,61.22197835672699 ) ;
  }

  @Test
  public void test693() {
    coral.tests.JPFBenchmark.benchmark20(83.5980576738196,-10.198127614764417 ) ;
  }

  @Test
  public void test694() {
    coral.tests.JPFBenchmark.benchmark20(83.61987780791031,-67.00035359891514 ) ;
  }

  @Test
  public void test695() {
    coral.tests.JPFBenchmark.benchmark20(83.8171561659955,83.44749147572631 ) ;
  }

  @Test
  public void test696() {
    coral.tests.JPFBenchmark.benchmark20(84.03760348894596,-0.0013535259560225868 ) ;
  }

  @Test
  public void test697() {
    coral.tests.JPFBenchmark.benchmark20(84.15461521241795,-192.19967597796838 ) ;
  }

  @Test
  public void test698() {
    coral.tests.JPFBenchmark.benchmark20(-84.42915878396131,61.30315612959749 ) ;
  }

  @Test
  public void test699() {
    coral.tests.JPFBenchmark.benchmark20(84.70057281454251,-0.01854528575897897 ) ;
  }

  @Test
  public void test700() {
    coral.tests.JPFBenchmark.benchmark20(-85.42826599219464,97.76442950726653 ) ;
  }

  @Test
  public void test701() {
    coral.tests.JPFBenchmark.benchmark20(-85.48205968275083,68.21299994880889 ) ;
  }

  @Test
  public void test702() {
    coral.tests.JPFBenchmark.benchmark20(-86.11993255347441,0.01823963721545574 ) ;
  }

  @Test
  public void test703() {
    coral.tests.JPFBenchmark.benchmark20(-8.637837248247237,4.433956774281982 ) ;
  }

  @Test
  public void test704() {
    coral.tests.JPFBenchmark.benchmark20(-8.639046049018097,0.011832659853943994 ) ;
  }

  @Test
  public void test705() {
    coral.tests.JPFBenchmark.benchmark20(8.639379790209215,-0.006435199726073089 ) ;
  }

  @Test
  public void test706() {
    coral.tests.JPFBenchmark.benchmark20(8.694907741530537,-0.1806570435810506 ) ;
  }

  @Test
  public void test707() {
    coral.tests.JPFBenchmark.benchmark20(8.717393351214252,-34.59668304431978 ) ;
  }

  @Test
  public void test708() {
    coral.tests.JPFBenchmark.benchmark20(-87.1791958890896,0.018018018069279766 ) ;
  }

  @Test
  public void test709() {
    coral.tests.JPFBenchmark.benchmark20(87.2069406272226,-0.018012285667544203 ) ;
  }

  @Test
  public void test710() {
    coral.tests.JPFBenchmark.benchmark20(-87.263584669151,99.80952842304225 ) ;
  }

  @Test
  public void test711() {
    coral.tests.JPFBenchmark.benchmark20(-87.28584829571126,50.981571692923694 ) ;
  }

  @Test
  public void test712() {
    coral.tests.JPFBenchmark.benchmark20(8.743538264023783,-3.3168436080676145 ) ;
  }

  @Test
  public void test713() {
    coral.tests.JPFBenchmark.benchmark20(87.57930937057236,-2.5954504953451645 ) ;
  }

  @Test
  public void test714() {
    coral.tests.JPFBenchmark.benchmark20(-8.765719924942967,0.179197640381502 ) ;
  }

  @Test
  public void test715() {
    coral.tests.JPFBenchmark.benchmark20(-8.76571992494297,0.15506237435272702 ) ;
  }

  @Test
  public void test716() {
    coral.tests.JPFBenchmark.benchmark20(8.76571992494297,-13.694785006682025 ) ;
  }

  @Test
  public void test717() {
    coral.tests.JPFBenchmark.benchmark20(87.76080142223731,-25.058053503094275 ) ;
  }

  @Test
  public void test718() {
    coral.tests.JPFBenchmark.benchmark20(-8.77949369875132,60.83205657249217 ) ;
  }

  @Test
  public void test719() {
    coral.tests.JPFBenchmark.benchmark20(-88.13839423664722,96.88001360166318 ) ;
  }

  @Test
  public void test720() {
    coral.tests.JPFBenchmark.benchmark20(-881.9762402345281,143.66243181358243 ) ;
  }

  @Test
  public void test721() {
    coral.tests.JPFBenchmark.benchmark20(-88.36341581760661,5.853050065407388 ) ;
  }

  @Test
  public void test722() {
    coral.tests.JPFBenchmark.benchmark20(-8.850773361597883,6.389125344449907 ) ;
  }

  @Test
  public void test723() {
    coral.tests.JPFBenchmark.benchmark20(-88.78650836319962,29.809995100005096 ) ;
  }

  @Test
  public void test724() {
    coral.tests.JPFBenchmark.benchmark20(8.881784197001252E-16,-100.0 ) ;
  }

  @Test
  public void test725() {
    coral.tests.JPFBenchmark.benchmark20(8.881784197001252E-16,-18.848056952698172 ) ;
  }

  @Test
  public void test726() {
    coral.tests.JPFBenchmark.benchmark20(-8.918651588782067,0.1761248672131842 ) ;
  }

  @Test
  public void test727() {
    coral.tests.JPFBenchmark.benchmark20(-89.2678874115338,156.78422167406094 ) ;
  }

  @Test
  public void test728() {
    coral.tests.JPFBenchmark.benchmark20(90.01316894459458,-21.429507614507422 ) ;
  }

  @Test
  public void test729() {
    coral.tests.JPFBenchmark.benchmark20(-90.08818915293057,-45.66700166694333 ) ;
  }

  @Test
  public void test730() {
    coral.tests.JPFBenchmark.benchmark20(90.3071527136542,37.36409508060933 ) ;
  }

  @Test
  public void test731() {
    coral.tests.JPFBenchmark.benchmark20(90.35758230643621,-0.01738422262636179 ) ;
  }

  @Test
  public void test732() {
    coral.tests.JPFBenchmark.benchmark20(-90.38182476511227,64.32448131527129 ) ;
  }

  @Test
  public void test733() {
    coral.tests.JPFBenchmark.benchmark20(90.38328879070654,-0.6361552832677779 ) ;
  }

  @Test
  public void test734() {
    coral.tests.JPFBenchmark.benchmark20(90.42727279783514,-22.308114461145024 ) ;
  }

  @Test
  public void test735() {
    coral.tests.JPFBenchmark.benchmark20(90.45528876611719,-66.96186361969444 ) ;
  }

  @Test
  public void test736() {
    coral.tests.JPFBenchmark.benchmark20(-9.04840622161287,29.335471572618438 ) ;
  }

  @Test
  public void test737() {
    coral.tests.JPFBenchmark.benchmark20(-90.51020803633386,97.88555988983398 ) ;
  }

  @Test
  public void test738() {
    coral.tests.JPFBenchmark.benchmark20(-90.71834452801096,34.91582010582212 ) ;
  }

  @Test
  public void test739() {
    coral.tests.JPFBenchmark.benchmark20(-909.879354908679,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test740() {
    coral.tests.JPFBenchmark.benchmark20(-9.132984337538241,0.17199157129161335 ) ;
  }

  @Test
  public void test741() {
    coral.tests.JPFBenchmark.benchmark20(91.76524498993041,-0.08019694060332938 ) ;
  }

  @Test
  public void test742() {
    coral.tests.JPFBenchmark.benchmark20(-91.92291403895037,99.55962162849994 ) ;
  }

  @Test
  public void test743() {
    coral.tests.JPFBenchmark.benchmark20(92.658669062027,-80.30099358760694 ) ;
  }

  @Test
  public void test744() {
    coral.tests.JPFBenchmark.benchmark20(92.80974053001941,-0.016924908073488454 ) ;
  }

  @Test
  public void test745() {
    coral.tests.JPFBenchmark.benchmark20(-92.96665399434518,52.54762182394275 ) ;
  }

  @Test
  public void test746() {
    coral.tests.JPFBenchmark.benchmark20(-93.12699674969322,0.01686724990194716 ) ;
  }

  @Test
  public void test747() {
    coral.tests.JPFBenchmark.benchmark20(-93.32294424681419,0.016831834223324127 ) ;
  }

  @Test
  public void test748() {
    coral.tests.JPFBenchmark.benchmark20(-93.45586303120814,18.433063536444504 ) ;
  }

  @Test
  public void test749() {
    coral.tests.JPFBenchmark.benchmark20(93.4637920821655,-21.76556451294023 ) ;
  }

  @Test
  public void test750() {
    coral.tests.JPFBenchmark.benchmark20(93.58872157186738,-0.016153250690756186 ) ;
  }

  @Test
  public void test751() {
    coral.tests.JPFBenchmark.benchmark20(-94.1077644174055,10.562403206560347 ) ;
  }

  @Test
  public void test752() {
    coral.tests.JPFBenchmark.benchmark20(94.23841594478353,-36.938824911741094 ) ;
  }

  @Test
  public void test753() {
    coral.tests.JPFBenchmark.benchmark20(-9.451053594293526,19.292146466588548 ) ;
  }

  @Test
  public void test754() {
    coral.tests.JPFBenchmark.benchmark20(-94.57657512895055,2.4477825539995735 ) ;
  }

  @Test
  public void test755() {
    coral.tests.JPFBenchmark.benchmark20(-9.48686064615076,0.16557598824139674 ) ;
  }

  @Test
  public void test756() {
    coral.tests.JPFBenchmark.benchmark20(94.93662566113986,95.45074079827492 ) ;
  }

  @Test
  public void test757() {
    coral.tests.JPFBenchmark.benchmark20(95.13625568917872,-100.0 ) ;
  }

  @Test
  public void test758() {
    coral.tests.JPFBenchmark.benchmark20(95.37252919419694,-52.63284686279943 ) ;
  }

  @Test
  public void test759() {
    coral.tests.JPFBenchmark.benchmark20(-9.544066274092087,73.86931086574462 ) ;
  }

  @Test
  public void test760() {
    coral.tests.JPFBenchmark.benchmark20(-95.60511373133227,-11.018918694669438 ) ;
  }

  @Test
  public void test761() {
    coral.tests.JPFBenchmark.benchmark20(96.26157530224097,-24.907309968356458 ) ;
  }

  @Test
  public void test762() {
    coral.tests.JPFBenchmark.benchmark20(-9.626359443877956,0.16317657115887885 ) ;
  }

  @Test
  public void test763() {
    coral.tests.JPFBenchmark.benchmark20(-96.31622173932936,78.62223522158743 ) ;
  }

  @Test
  public void test764() {
    coral.tests.JPFBenchmark.benchmark20(96.60397388632282,-0.012833123801775823 ) ;
  }

  @Test
  public void test765() {
    coral.tests.JPFBenchmark.benchmark20(-96.69034205674365,0.016245638327280505 ) ;
  }

  @Test
  public void test766() {
    coral.tests.JPFBenchmark.benchmark20(-96.71542519779668,44.40254668904916 ) ;
  }

  @Test
  public void test767() {
    coral.tests.JPFBenchmark.benchmark20(97.67422520817411,-53.69777875370518 ) ;
  }

  @Test
  public void test768() {
    coral.tests.JPFBenchmark.benchmark20(98.25345327766627,-83.7107555081422 ) ;
  }

  @Test
  public void test769() {
    coral.tests.JPFBenchmark.benchmark20(-98.73462815960616,50.54109439028838 ) ;
  }

  @Test
  public void test770() {
    coral.tests.JPFBenchmark.benchmark20(9.891661316528145,-0.1588000515313061 ) ;
  }

  @Test
  public void test771() {
    coral.tests.JPFBenchmark.benchmark20(990.4203318478889,-48.10777227221536 ) ;
  }

  @Test
  public void test772() {
    coral.tests.JPFBenchmark.benchmark20(-9.923572046194522,24.129852378512574 ) ;
  }

  @Test
  public void test773() {
    coral.tests.JPFBenchmark.benchmark20(-99.77260835971289,85.33527949817099 ) ;
  }

  @Test
  public void test774() {
    coral.tests.JPFBenchmark.benchmark20(99.95784525945476,-0.015714587709666716 ) ;
  }

  @Test
  public void test775() {
    coral.tests.JPFBenchmark.benchmark20(-99.99999351107415,137.36614769784865 ) ;
  }
}
