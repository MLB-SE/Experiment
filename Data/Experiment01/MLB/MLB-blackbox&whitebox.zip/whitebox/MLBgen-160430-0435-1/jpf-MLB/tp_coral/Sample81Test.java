import org.junit.Test;

public class Sample81Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark81(-10.806863553372793,-84.74786935329385 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark81(-64.44128414769852,-4.167412600356989 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark81(-93.4280890761651,-1.132833265373037 ) ;
  }
}
