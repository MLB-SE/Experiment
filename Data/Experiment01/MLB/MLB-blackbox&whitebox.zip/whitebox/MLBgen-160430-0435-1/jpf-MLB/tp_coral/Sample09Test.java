import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(-0.0011087506619608541,-6.990876565973144 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(0.0017684945857838364,-322.75314170119697 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(-0.002167484346218137,263.2789704568438 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark09(-0.0032976576768176634,28.67932920441288 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark09(0.005707962001598223,-100.0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark09(0.005942556872574424,-5.188841933319519 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark09(-0.016984770397577585,33.60526975505045 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark09(0.017900947184572955,-14.898166525899105 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark09(0.018601965099083025,-84.44249402835015 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark09(-0.019573214422305696,80.25234347838197 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark09(-0.021376166911402487,26.70186643484619 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark09(0.021947558108513565,-71.57043708591786 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark09(0.02564661300689895,-61.24771042368642 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark09(-0.027510692296555044,6.246853653062263 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark09(-0.028176358670452917,55.74873407762618 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark09(0.030237311431477173,-18.877205968512367 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark09(-0.03198630386013601,22.635400741927498 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark09(-0.03246165892536019,48.389280732899806 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark09(-0.03462974601416491,45.35974148214601 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark09(0.03894141746210089,-40.33742039112074 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark09(0.03990239013495345,-39.36597084741849 ) ;
  }

  @Test
  public void test21() {
    coral.tests.JPFBenchmark.benchmark09(-0.04170390421236414,37.66545018893444 ) ;
  }

  @Test
  public void test22() {
    coral.tests.JPFBenchmark.benchmark09(-0.04712337930941418,4.880520641939214 ) ;
  }

  @Test
  public void test23() {
    coral.tests.JPFBenchmark.benchmark09(-0.047332132638684854,33.186679729513 ) ;
  }

  @Test
  public void test24() {
    coral.tests.JPFBenchmark.benchmark09(-0.0539758750968733,29.10182232294904 ) ;
  }

  @Test
  public void test25() {
    coral.tests.JPFBenchmark.benchmark09(-0.06322285332623652,9.02832256753928 ) ;
  }

  @Test
  public void test26() {
    coral.tests.JPFBenchmark.benchmark09(0.08220872687361803,-19.107415800389774 ) ;
  }

  @Test
  public void test27() {
    coral.tests.JPFBenchmark.benchmark09(0.0834148094338895,-6.842864754013629 ) ;
  }

  @Test
  public void test28() {
    coral.tests.JPFBenchmark.benchmark09(-0.10996074052347378,5.190900804357739 ) ;
  }

  @Test
  public void test29() {
    coral.tests.JPFBenchmark.benchmark09(0.11077262547448619,-14.180365591828405 ) ;
  }

  @Test
  public void test30() {
    coral.tests.JPFBenchmark.benchmark09(0.14260017293231841,-11.01538865272229 ) ;
  }

  @Test
  public void test31() {
    coral.tests.JPFBenchmark.benchmark09(0.1459471965156789,-10.762771497472016 ) ;
  }

  @Test
  public void test32() {
    coral.tests.JPFBenchmark.benchmark09(0.15350975953530455,-1.540527561068462 ) ;
  }

  @Test
  public void test33() {
    coral.tests.JPFBenchmark.benchmark09(-0.18100719078912775,8.678087980630906 ) ;
  }

  @Test
  public void test34() {
    coral.tests.JPFBenchmark.benchmark09(0.18383297178029126,-8.544693106915773 ) ;
  }

  @Test
  public void test35() {
    coral.tests.JPFBenchmark.benchmark09(-0.18679969699402976,8.40898755229298 ) ;
  }

  @Test
  public void test36() {
    coral.tests.JPFBenchmark.benchmark09(0.18944946324347728,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test37() {
    coral.tests.JPFBenchmark.benchmark09(-0.21962224575110323,7.152264204488064 ) ;
  }

  @Test
  public void test38() {
    coral.tests.JPFBenchmark.benchmark09(-0.23029665553255468,6.820751795819497 ) ;
  }

  @Test
  public void test39() {
    coral.tests.JPFBenchmark.benchmark09(-0.24249693237629522,-15.330131577376692 ) ;
  }

  @Test
  public void test40() {
    coral.tests.JPFBenchmark.benchmark09(0.24478642482527846,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test41() {
    coral.tests.JPFBenchmark.benchmark09(-0.2502610970686142,2.280800851811453 ) ;
  }

  @Test
  public void test42() {
    coral.tests.JPFBenchmark.benchmark09(0.26980924843775256,-5.821877255468792 ) ;
  }

  @Test
  public void test43() {
    coral.tests.JPFBenchmark.benchmark09(-0.31720400362924295,4.952006622939365 ) ;
  }

  @Test
  public void test44() {
    coral.tests.JPFBenchmark.benchmark09(0.31943679376226225,-1.7868826170167191 ) ;
  }

  @Test
  public void test45() {
    coral.tests.JPFBenchmark.benchmark09(0.3971940826903777,-80.19896784620711 ) ;
  }

  @Test
  public void test46() {
    coral.tests.JPFBenchmark.benchmark09(-0.4227202381712516,8.526512829121202E-14 ) ;
  }

  @Test
  public void test47() {
    coral.tests.JPFBenchmark.benchmark09(-0.44307456425457736,0.40543441585125584 ) ;
  }

  @Test
  public void test48() {
    coral.tests.JPFBenchmark.benchmark09(-0.44838086995051407,1.1275776313984522 ) ;
  }

  @Test
  public void test49() {
    coral.tests.JPFBenchmark.benchmark09(-0.514602565293834,1.189895738712544E-16 ) ;
  }

  @Test
  public void test50() {
    coral.tests.JPFBenchmark.benchmark09(0.5171073422420562,-1.0614712011265015 ) ;
  }

  @Test
  public void test51() {
    coral.tests.JPFBenchmark.benchmark09(-0.5321362880097444,0.5019441684588628 ) ;
  }

  @Test
  public void test52() {
    coral.tests.JPFBenchmark.benchmark09(-0.546327738949896,2.875190503440564 ) ;
  }

  @Test
  public void test53() {
    coral.tests.JPFBenchmark.benchmark09(-0.6177666268218539,2.5427018207117698 ) ;
  }

  @Test
  public void test54() {
    coral.tests.JPFBenchmark.benchmark09(0.634960957110934,-0.020596319768417748 ) ;
  }

  @Test
  public void test55() {
    coral.tests.JPFBenchmark.benchmark09(0.6559345445658283,-0.9260644187519957 ) ;
  }

  @Test
  public void test56() {
    coral.tests.JPFBenchmark.benchmark09(0.6609854132324512,-2.3764462805815185 ) ;
  }

  @Test
  public void test57() {
    coral.tests.JPFBenchmark.benchmark09(0.6835429110229896,-2.2980215308561163 ) ;
  }

  @Test
  public void test58() {
    coral.tests.JPFBenchmark.benchmark09(0.6846839067386834,8.087038738542905 ) ;
  }

  @Test
  public void test59() {
    coral.tests.JPFBenchmark.benchmark09(0.6848661841416395,-2.2365642892219704 ) ;
  }

  @Test
  public void test60() {
    coral.tests.JPFBenchmark.benchmark09(0.7643252795168536,-2.0551411406761133 ) ;
  }

  @Test
  public void test61() {
    coral.tests.JPFBenchmark.benchmark09(-0.8401715735661313,1.8696137505909434 ) ;
  }

  @Test
  public void test62() {
    coral.tests.JPFBenchmark.benchmark09(0.8962534183109412,-0.1563256006242426 ) ;
  }

  @Test
  public void test63() {
    coral.tests.JPFBenchmark.benchmark09(-1.0032239457213121,1.5657484388149214 ) ;
  }

  @Test
  public void test64() {
    coral.tests.JPFBenchmark.benchmark09(-10.490350309165134,-19.91503781345506 ) ;
  }

  @Test
  public void test65() {
    coral.tests.JPFBenchmark.benchmark09(1.0658141036401503E-14,-3.2496301548317774 ) ;
  }

  @Test
  public void test66() {
    coral.tests.JPFBenchmark.benchmark09(1.0812328810061445E-9,-83.74338594905491 ) ;
  }

  @Test
  public void test67() {
    coral.tests.JPFBenchmark.benchmark09(-108.44762271569958,0.005263013739260966 ) ;
  }

  @Test
  public void test68() {
    coral.tests.JPFBenchmark.benchmark09(10.867862032351923,-0.14453590983386447 ) ;
  }

  @Test
  public void test69() {
    coral.tests.JPFBenchmark.benchmark09(-1.102344595001243,1.4249594309419418 ) ;
  }

  @Test
  public void test70() {
    coral.tests.JPFBenchmark.benchmark09(1.1070953923362237E-16,-0.5530900081532584 ) ;
  }

  @Test
  public void test71() {
    coral.tests.JPFBenchmark.benchmark09(-1.1102230246251565E-16,29.137236485154773 ) ;
  }

  @Test
  public void test72() {
    coral.tests.JPFBenchmark.benchmark09(-11.176078060827123,82.63604722016049 ) ;
  }

  @Test
  public void test73() {
    coral.tests.JPFBenchmark.benchmark09(-1.1193982374058749,28.253745198713233 ) ;
  }

  @Test
  public void test74() {
    coral.tests.JPFBenchmark.benchmark09(-1.1363397377525928,0.2135805679971554 ) ;
  }

  @Test
  public void test75() {
    coral.tests.JPFBenchmark.benchmark09(-115.14563389155046,0.004952112700791099 ) ;
  }

  @Test
  public void test76() {
    coral.tests.JPFBenchmark.benchmark09(-12.03638516430674,-0.45995225360006486 ) ;
  }

  @Test
  public void test77() {
    coral.tests.JPFBenchmark.benchmark09(-1.2137370054864107,1.2941817870712384 ) ;
  }

  @Test
  public void test78() {
    coral.tests.JPFBenchmark.benchmark09(1.2434497875801753E-14,-8.15037467969799 ) ;
  }

  @Test
  public void test79() {
    coral.tests.JPFBenchmark.benchmark09(12.473373339838377,-0.12593195793939493 ) ;
  }

  @Test
  public void test80() {
    coral.tests.JPFBenchmark.benchmark09(12.496572814096613,-0.0456761177735371 ) ;
  }

  @Test
  public void test81() {
    coral.tests.JPFBenchmark.benchmark09(1.2581175384237199E-17,-8.118321439070417 ) ;
  }

  @Test
  public void test82() {
    coral.tests.JPFBenchmark.benchmark09(-1266.4139174846916,1363.5602576912404 ) ;
  }

  @Test
  public void test83() {
    coral.tests.JPFBenchmark.benchmark09(-1.2792686058698308,1.2278862465532352 ) ;
  }

  @Test
  public void test84() {
    coral.tests.JPFBenchmark.benchmark09(1.3074866348621412,-1.2013861441578086 ) ;
  }

  @Test
  public void test85() {
    coral.tests.JPFBenchmark.benchmark09(1.3283327657475041,-1.1825322444040962 ) ;
  }

  @Test
  public void test86() {
    coral.tests.JPFBenchmark.benchmark09(-1.3322676295501878E-15,18.164567430826523 ) ;
  }

  @Test
  public void test87() {
    coral.tests.JPFBenchmark.benchmark09(-1.3448150451127274,1.1680389303372394 ) ;
  }

  @Test
  public void test88() {
    coral.tests.JPFBenchmark.benchmark09(-13.549592783555767,92.81837204538479 ) ;
  }

  @Test
  public void test89() {
    coral.tests.JPFBenchmark.benchmark09(-13.722645576977811,1.3322676295501878E-14 ) ;
  }

  @Test
  public void test90() {
    coral.tests.JPFBenchmark.benchmark09(13.815590276046906,-15.576540160140967 ) ;
  }

  @Test
  public void test91() {
    coral.tests.JPFBenchmark.benchmark09(-1.3825555648079302,2.220446049250313E-16 ) ;
  }

  @Test
  public void test92() {
    coral.tests.JPFBenchmark.benchmark09(1.3923169966059532,-1.1281887175291416 ) ;
  }

  @Test
  public void test93() {
    coral.tests.JPFBenchmark.benchmark09(-1.4210854715202004E-14,0.7687612465322644 ) ;
  }

  @Test
  public void test94() {
    coral.tests.JPFBenchmark.benchmark09(1.427462930262081,-1.1004112915956767 ) ;
  }

  @Test
  public void test95() {
    coral.tests.JPFBenchmark.benchmark09(-14.59833214242245,62.90342785949122 ) ;
  }

  @Test
  public void test96() {
    coral.tests.JPFBenchmark.benchmark09(1.4921397450962104E-13,-1.066061085983776 ) ;
  }

  @Test
  public void test97() {
    coral.tests.JPFBenchmark.benchmark09(-1497.7999867707067,1206.7087926090117 ) ;
  }

  @Test
  public void test98() {
    coral.tests.JPFBenchmark.benchmark09(-15.75832878717209,71.39196976908593 ) ;
  }

  @Test
  public void test99() {
    coral.tests.JPFBenchmark.benchmark09(-15.863148899027578,-22.765809774962293 ) ;
  }

  @Test
  public void test100() {
    coral.tests.JPFBenchmark.benchmark09(-15.905693079302253,69.65686815648624 ) ;
  }

  @Test
  public void test101() {
    coral.tests.JPFBenchmark.benchmark09(-1.6057143973293653,0.9782538721751859 ) ;
  }

  @Test
  public void test102() {
    coral.tests.JPFBenchmark.benchmark09(1.6344805553626323,-54.0448575304612 ) ;
  }

  @Test
  public void test103() {
    coral.tests.JPFBenchmark.benchmark09(1.6418147205193505E-288,-1.2502613099265576E-13 ) ;
  }

  @Test
  public void test104() {
    coral.tests.JPFBenchmark.benchmark09(-16.526732051728317,0.3199848739098617 ) ;
  }

  @Test
  public void test105() {
    coral.tests.JPFBenchmark.benchmark09(-1.724072513767563E-16,0.6256849910382859 ) ;
  }

  @Test
  public void test106() {
    coral.tests.JPFBenchmark.benchmark09(-1.7599433274391474,-2.1122884396105626 ) ;
  }

  @Test
  public void test107() {
    coral.tests.JPFBenchmark.benchmark09(17.644007619184066,-19.244851235011698 ) ;
  }

  @Test
  public void test108() {
    coral.tests.JPFBenchmark.benchmark09(-1.7763568394002505E-15,21.91071706132402 ) ;
  }

  @Test
  public void test109() {
    coral.tests.JPFBenchmark.benchmark09(17.778445592397322,-0.08835397440294912 ) ;
  }

  @Test
  public void test110() {
    coral.tests.JPFBenchmark.benchmark09(18.039181483646786,-0.08707691799757565 ) ;
  }

  @Test
  public void test111() {
    coral.tests.JPFBenchmark.benchmark09(183.23686385735292,-39.12515513770152 ) ;
  }

  @Test
  public void test112() {
    coral.tests.JPFBenchmark.benchmark09(-1.840136402463017,0.37645503548513937 ) ;
  }

  @Test
  public void test113() {
    coral.tests.JPFBenchmark.benchmark09(1.865174681370263E-14,-18.178170021394763 ) ;
  }

  @Test
  public void test114() {
    coral.tests.JPFBenchmark.benchmark09(1.9721522630525295E-31,41.501378276816524 ) ;
  }

  @Test
  public void test115() {
    coral.tests.JPFBenchmark.benchmark09(1.9721522630525295E-31,4.178141929035959 ) ;
  }

  @Test
  public void test116() {
    coral.tests.JPFBenchmark.benchmark09(-2.0534915457080487,0.7649392713973384 ) ;
  }

  @Test
  public void test117() {
    coral.tests.JPFBenchmark.benchmark09(-2.093258899549255E-11,5.727749741917137 ) ;
  }

  @Test
  public void test118() {
    coral.tests.JPFBenchmark.benchmark09(-21.47080121677702,0.07315965114368872 ) ;
  }

  @Test
  public void test119() {
    coral.tests.JPFBenchmark.benchmark09(-21.609453507474992,0.01865240542685707 ) ;
  }

  @Test
  public void test120() {
    coral.tests.JPFBenchmark.benchmark09(-21.822841475852357,7.551168639920675 ) ;
  }

  @Test
  public void test121() {
    coral.tests.JPFBenchmark.benchmark09(-2.184833047257513,4.440892098500626E-16 ) ;
  }

  @Test
  public void test122() {
    coral.tests.JPFBenchmark.benchmark09(2.2044893717153538,-2.5E-323 ) ;
  }

  @Test
  public void test123() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-16,20.275765943415024 ) ;
  }

  @Test
  public void test124() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-29.49109135268735 ) ;
  }

  @Test
  public void test125() {
    coral.tests.JPFBenchmark.benchmark09(-2.220446049250313E-16,39.203894974293064 ) ;
  }

  @Test
  public void test126() {
    coral.tests.JPFBenchmark.benchmark09(2.220446049250313E-16,-71.22015765607014 ) ;
  }

  @Test
  public void test127() {
    coral.tests.JPFBenchmark.benchmark09(-22.222094873040913,0.8738607355602063 ) ;
  }

  @Test
  public void test128() {
    coral.tests.JPFBenchmark.benchmark09(23.161023703651363,2.192929519474104 ) ;
  }

  @Test
  public void test129() {
    coral.tests.JPFBenchmark.benchmark09(-23.259367367539244,-1.080542769352944 ) ;
  }

  @Test
  public void test130() {
    coral.tests.JPFBenchmark.benchmark09(23.300560831857297,-25.894329585930052 ) ;
  }

  @Test
  public void test131() {
    coral.tests.JPFBenchmark.benchmark09(-2.344440365859896,5.3290705182007514E-14 ) ;
  }

  @Test
  public void test132() {
    coral.tests.JPFBenchmark.benchmark09(-23.92067765419101,0.06566688241458268 ) ;
  }

  @Test
  public void test133() {
    coral.tests.JPFBenchmark.benchmark09(24.349640818299264,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test134() {
    coral.tests.JPFBenchmark.benchmark09(-24.67887600333063,-56.47414360208893 ) ;
  }

  @Test
  public void test135() {
    coral.tests.JPFBenchmark.benchmark09(-2.476507709554383,-43.064234554420324 ) ;
  }

  @Test
  public void test136() {
    coral.tests.JPFBenchmark.benchmark09(-2.4998081326858768,0.6283667559346569 ) ;
  }

  @Test
  public void test137() {
    coral.tests.JPFBenchmark.benchmark09(-25.098464176683038,47.34971321433045 ) ;
  }

  @Test
  public void test138() {
    coral.tests.JPFBenchmark.benchmark09(2.5514438532505136E-5,-1.4210854715202004E-14 ) ;
  }

  @Test
  public void test139() {
    coral.tests.JPFBenchmark.benchmark09(-25.590234542032704,77.85344945014643 ) ;
  }

  @Test
  public void test140() {
    coral.tests.JPFBenchmark.benchmark09(-25.926526465314865,45.8470290196415 ) ;
  }

  @Test
  public void test141() {
    coral.tests.JPFBenchmark.benchmark09(-26.089729001775066,0.021877164543516757 ) ;
  }

  @Test
  public void test142() {
    coral.tests.JPFBenchmark.benchmark09(-26.352800993771353,0.059606427687370456 ) ;
  }

  @Test
  public void test143() {
    coral.tests.JPFBenchmark.benchmark09(26.50584195714157,46.239619019297265 ) ;
  }

  @Test
  public void test144() {
    coral.tests.JPFBenchmark.benchmark09(26.88489472336417,-62.18322569095469 ) ;
  }

  @Test
  public void test145() {
    coral.tests.JPFBenchmark.benchmark09(27.263884537804362,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test146() {
    coral.tests.JPFBenchmark.benchmark09(27.8720179561232,-99.86682643123999 ) ;
  }

  @Test
  public void test147() {
    coral.tests.JPFBenchmark.benchmark09(-27.891300548233986,0.05631850419016615 ) ;
  }

  @Test
  public void test148() {
    coral.tests.JPFBenchmark.benchmark09(-29.121840341339293,-30.70546713216298 ) ;
  }

  @Test
  public void test149() {
    coral.tests.JPFBenchmark.benchmark09(-2.9317296525549352,13.379509001859812 ) ;
  }

  @Test
  public void test150() {
    coral.tests.JPFBenchmark.benchmark09(-2.9348567073834735,0.5352207904539625 ) ;
  }

  @Test
  public void test151() {
    coral.tests.JPFBenchmark.benchmark09(29.48197899905145,-71.21294417218908 ) ;
  }

  @Test
  public void test152() {
    coral.tests.JPFBenchmark.benchmark09(-2.964232186207905,0.39265189611339224 ) ;
  }

  @Test
  public void test153() {
    coral.tests.JPFBenchmark.benchmark09(2.9942017537844556,-0.5246127201714188 ) ;
  }

  @Test
  public void test154() {
    coral.tests.JPFBenchmark.benchmark09(30.747211571948696,-14.868512570263377 ) ;
  }

  @Test
  public void test155() {
    coral.tests.JPFBenchmark.benchmark09(-31.155389038867128,-36.44710288116628 ) ;
  }

  @Test
  public void test156() {
    coral.tests.JPFBenchmark.benchmark09(31.37369949521664,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test157() {
    coral.tests.JPFBenchmark.benchmark09(32.125489745638134,-0.04889563829943394 ) ;
  }

  @Test
  public void test158() {
    coral.tests.JPFBenchmark.benchmark09(-32.67767722674695,0.01746545234130555 ) ;
  }

  @Test
  public void test159() {
    coral.tests.JPFBenchmark.benchmark09(32.70305406436549,-4.440892098500626E-16 ) ;
  }

  @Test
  public void test160() {
    coral.tests.JPFBenchmark.benchmark09(-3.310681122541194,9.524236223584676 ) ;
  }

  @Test
  public void test161() {
    coral.tests.JPFBenchmark.benchmark09(33.51503602732462,-0.01701264230793929 ) ;
  }

  @Test
  public void test162() {
    coral.tests.JPFBenchmark.benchmark09(33.92996131642458,-1.3425623155083537 ) ;
  }

  @Test
  public void test163() {
    coral.tests.JPFBenchmark.benchmark09(-33.96535379372499,99.70857474449801 ) ;
  }

  @Test
  public void test164() {
    coral.tests.JPFBenchmark.benchmark09(-34.169236080388885,-4.755735741307674 ) ;
  }

  @Test
  public void test165() {
    coral.tests.JPFBenchmark.benchmark09(-34.29093588163994,79.35503020625666 ) ;
  }

  @Test
  public void test166() {
    coral.tests.JPFBenchmark.benchmark09(-3.552713678800501E-15,0.745282574000683 ) ;
  }

  @Test
  public void test167() {
    coral.tests.JPFBenchmark.benchmark09(-3.552713678800501E-15,71.20566353697382 ) ;
  }

  @Test
  public void test168() {
    coral.tests.JPFBenchmark.benchmark09(-3.552713678800501E-15,7.138632826460238 ) ;
  }

  @Test
  public void test169() {
    coral.tests.JPFBenchmark.benchmark09(-35.72916720600925,0.04396397816210218 ) ;
  }

  @Test
  public void test170() {
    coral.tests.JPFBenchmark.benchmark09(-36.336870803031566,0.015708429820385568 ) ;
  }

  @Test
  public void test171() {
    coral.tests.JPFBenchmark.benchmark09(36.82440840344004,-0.042656390011364224 ) ;
  }

  @Test
  public void test172() {
    coral.tests.JPFBenchmark.benchmark09(36.915334744448984,47.94115463634952 ) ;
  }

  @Test
  public void test173() {
    coral.tests.JPFBenchmark.benchmark09(-36.94876046743873,0.04251282876401641 ) ;
  }

  @Test
  public void test174() {
    coral.tests.JPFBenchmark.benchmark09(36.965342696663114,-78.52846490049521 ) ;
  }

  @Test
  public void test175() {
    coral.tests.JPFBenchmark.benchmark09(-3.7066138297822455,0.4237820282689597 ) ;
  }

  @Test
  public void test176() {
    coral.tests.JPFBenchmark.benchmark09(3.730349362740526E-14,-1.1466529053187884 ) ;
  }

  @Test
  public void test177() {
    coral.tests.JPFBenchmark.benchmark09(-37.459029536073764,118.2674945156661 ) ;
  }

  @Test
  public void test178() {
    coral.tests.JPFBenchmark.benchmark09(-37.55748090516795,0.0418237935276089 ) ;
  }

  @Test
  public void test179() {
    coral.tests.JPFBenchmark.benchmark09(-37.621115012080566,61.45908406810858 ) ;
  }

  @Test
  public void test180() {
    coral.tests.JPFBenchmark.benchmark09(3.7734706078355,-26.792778253392118 ) ;
  }

  @Test
  public void test181() {
    coral.tests.JPFBenchmark.benchmark09(-38.23627451687093,22.56962068220352 ) ;
  }

  @Test
  public void test182() {
    coral.tests.JPFBenchmark.benchmark09(-38.902391996170856,16.646818571097754 ) ;
  }

  @Test
  public void test183() {
    coral.tests.JPFBenchmark.benchmark09(3.9023149739287526E-17,-1.5691285907585386 ) ;
  }

  @Test
  public void test184() {
    coral.tests.JPFBenchmark.benchmark09(3.944304526105059E-31,1.5972474494914763 ) ;
  }

  @Test
  public void test185() {
    coral.tests.JPFBenchmark.benchmark09(40.23370653930621,-0.03904180007030452 ) ;
  }

  @Test
  public void test186() {
    coral.tests.JPFBenchmark.benchmark09(4.0E-323,-0.6405053374693921 ) ;
  }

  @Test
  public void test187() {
    coral.tests.JPFBenchmark.benchmark09(-4.1245003294089063E-16,-0.31731181052682406 ) ;
  }

  @Test
  public void test188() {
    coral.tests.JPFBenchmark.benchmark09(41.96250360039707,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test189() {
    coral.tests.JPFBenchmark.benchmark09(-42.347489575269584,34.13905833564153 ) ;
  }

  @Test
  public void test190() {
    coral.tests.JPFBenchmark.benchmark09(-42.38882717906396,41.21045507457128 ) ;
  }

  @Test
  public void test191() {
    coral.tests.JPFBenchmark.benchmark09(-42.686531170863525,0.0367984065162707 ) ;
  }

  @Test
  public void test192() {
    coral.tests.JPFBenchmark.benchmark09(-4.440892098500626E-16,58.38042144481267 ) ;
  }

  @Test
  public void test193() {
    coral.tests.JPFBenchmark.benchmark09(-44.554827338336736,63.893656665830406 ) ;
  }

  @Test
  public void test194() {
    coral.tests.JPFBenchmark.benchmark09(-44.70524124587374,37.55340807482918 ) ;
  }

  @Test
  public void test195() {
    coral.tests.JPFBenchmark.benchmark09(-4.476790902490691,0.05087705669270856 ) ;
  }

  @Test
  public void test196() {
    coral.tests.JPFBenchmark.benchmark09(44.9436522819658,-14.399543797318827 ) ;
  }

  @Test
  public void test197() {
    coral.tests.JPFBenchmark.benchmark09(45.14504733783784,-37.19293784613656 ) ;
  }

  @Test
  public void test198() {
    coral.tests.JPFBenchmark.benchmark09(-45.24418592294095,40.40830072552879 ) ;
  }

  @Test
  public void test199() {
    coral.tests.JPFBenchmark.benchmark09(45.66080450731525,-63.60821802380756 ) ;
  }

  @Test
  public void test200() {
    coral.tests.JPFBenchmark.benchmark09(-4.6056226567324785,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test201() {
    coral.tests.JPFBenchmark.benchmark09(46.073865968639936,-114.42573228525028 ) ;
  }

  @Test
  public void test202() {
    coral.tests.JPFBenchmark.benchmark09(-4.623324623016481,-11.022007918327612 ) ;
  }

  @Test
  public void test203() {
    coral.tests.JPFBenchmark.benchmark09(-4.648023050087985E-16,0.13173846019590751 ) ;
  }

  @Test
  public void test204() {
    coral.tests.JPFBenchmark.benchmark09(46.8496107692593,-0.03352848190204272 ) ;
  }

  @Test
  public void test205() {
    coral.tests.JPFBenchmark.benchmark09(-46.860488705625336,0.03352069878448218 ) ;
  }

  @Test
  public void test206() {
    coral.tests.JPFBenchmark.benchmark09(-48.05214491435676,37.52792598559968 ) ;
  }

  @Test
  public void test207() {
    coral.tests.JPFBenchmark.benchmark09(4.8263727010594835,-0.32546104996202985 ) ;
  }

  @Test
  public void test208() {
    coral.tests.JPFBenchmark.benchmark09(49.12040180331812,-94.46887676061722 ) ;
  }

  @Test
  public void test209() {
    coral.tests.JPFBenchmark.benchmark09(49.22490081104826,-49.16868181030401 ) ;
  }

  @Test
  public void test210() {
    coral.tests.JPFBenchmark.benchmark09(-492.8613888796687,410.8681269763784 ) ;
  }

  @Test
  public void test211() {
    coral.tests.JPFBenchmark.benchmark09(-4.960082020794029E-14,0.19377890422671018 ) ;
  }

  @Test
  public void test212() {
    coral.tests.JPFBenchmark.benchmark09(4.971280667039466,88.03333120002114 ) ;
  }

  @Test
  public void test213() {
    coral.tests.JPFBenchmark.benchmark09(50.57135948571816,-3.197442310920451E-14 ) ;
  }

  @Test
  public void test214() {
    coral.tests.JPFBenchmark.benchmark09(5.07793160572308,5.085788448219516 ) ;
  }

  @Test
  public void test215() {
    coral.tests.JPFBenchmark.benchmark09(50.99950739988833,-0.030800225470379416 ) ;
  }

  @Test
  public void test216() {
    coral.tests.JPFBenchmark.benchmark09(-51.121758217916025,85.32471454480569 ) ;
  }

  @Test
  public void test217() {
    coral.tests.JPFBenchmark.benchmark09(-51.82365710358381,63.074882147173525 ) ;
  }

  @Test
  public void test218() {
    coral.tests.JPFBenchmark.benchmark09(5.272450653478899,-0.29792527802198476 ) ;
  }

  @Test
  public void test219() {
    coral.tests.JPFBenchmark.benchmark09(-5.329070518200751E-15,25.562219985484063 ) ;
  }

  @Test
  public void test220() {
    coral.tests.JPFBenchmark.benchmark09(-5.417591373302205,-1.2389987575407093 ) ;
  }

  @Test
  public void test221() {
    coral.tests.JPFBenchmark.benchmark09(-543.4461464528107,534.0601590796832 ) ;
  }

  @Test
  public void test222() {
    coral.tests.JPFBenchmark.benchmark09(-56.6092925349731,28.77273284936831 ) ;
  }

  @Test
  public void test223() {
    coral.tests.JPFBenchmark.benchmark09(-57.217549666210886,66.66590079005309 ) ;
  }

  @Test
  public void test224() {
    coral.tests.JPFBenchmark.benchmark09(60.735063467702844,74.78212115782591 ) ;
  }

  @Test
  public void test225() {
    coral.tests.JPFBenchmark.benchmark09(-62.33242051428076,3.436382031302521 ) ;
  }

  @Test
  public void test226() {
    coral.tests.JPFBenchmark.benchmark09(-6.249220614680823,0.0 ) ;
  }

  @Test
  public void test227() {
    coral.tests.JPFBenchmark.benchmark09(62.507166151129894,-67.95801471739975 ) ;
  }

  @Test
  public void test228() {
    coral.tests.JPFBenchmark.benchmark09(62.56413282844547,-0.025106978324179963 ) ;
  }

  @Test
  public void test229() {
    coral.tests.JPFBenchmark.benchmark09(62.73608026170544,-0.025038164964120688 ) ;
  }

  @Test
  public void test230() {
    coral.tests.JPFBenchmark.benchmark09(62.82414216072735,31.85882331705585 ) ;
  }

  @Test
  public void test231() {
    coral.tests.JPFBenchmark.benchmark09(-62.855160180801384,0.009664248233036675 ) ;
  }

  @Test
  public void test232() {
    coral.tests.JPFBenchmark.benchmark09(-64.33981754551903,100.0 ) ;
  }

  @Test
  public void test233() {
    coral.tests.JPFBenchmark.benchmark09(6.455831999512563,-52.59590616409684 ) ;
  }

  @Test
  public void test234() {
    coral.tests.JPFBenchmark.benchmark09(-65.81832580925317,-84.12801509238813 ) ;
  }

  @Test
  public void test235() {
    coral.tests.JPFBenchmark.benchmark09(-65.99107218324573,36.657423847608165 ) ;
  }

  @Test
  public void test236() {
    coral.tests.JPFBenchmark.benchmark09(-66.19530491651622,42.3273599576805 ) ;
  }

  @Test
  public void test237() {
    coral.tests.JPFBenchmark.benchmark09(-6.717731398151969,0.23382839141603945 ) ;
  }

  @Test
  public void test238() {
    coral.tests.JPFBenchmark.benchmark09(-68.82464182435069,99.78831105999706 ) ;
  }

  @Test
  public void test239() {
    coral.tests.JPFBenchmark.benchmark09(-70.45980556231441,3.944922581910717 ) ;
  }

  @Test
  public void test240() {
    coral.tests.JPFBenchmark.benchmark09(70.87697874747695,-0.02216229239103701 ) ;
  }

  @Test
  public void test241() {
    coral.tests.JPFBenchmark.benchmark09(-71.14920901982237,8.229846656061632 ) ;
  }

  @Test
  public void test242() {
    coral.tests.JPFBenchmark.benchmark09(-72.32229948760661,0.021719391362329032 ) ;
  }

  @Test
  public void test243() {
    coral.tests.JPFBenchmark.benchmark09(7.254849876371509,-10.715761147424871 ) ;
  }

  @Test
  public void test244() {
    coral.tests.JPFBenchmark.benchmark09(72.90895124774252,-0.021544629293286266 ) ;
  }

  @Test
  public void test245() {
    coral.tests.JPFBenchmark.benchmark09(-74.12628331059076,49.92781855423263 ) ;
  }

  @Test
  public void test246() {
    coral.tests.JPFBenchmark.benchmark09(-74.14650592756517,65.4270864524414 ) ;
  }

  @Test
  public void test247() {
    coral.tests.JPFBenchmark.benchmark09(75.29144963310044,-67.76302361597178 ) ;
  }

  @Test
  public void test248() {
    coral.tests.JPFBenchmark.benchmark09(75.33430481611296,-7.549516567451064E-15 ) ;
  }

  @Test
  public void test249() {
    coral.tests.JPFBenchmark.benchmark09(76.12290892858243,-33.348816814078866 ) ;
  }

  @Test
  public void test250() {
    coral.tests.JPFBenchmark.benchmark09(76.76846179082351,-52.061439795198524 ) ;
  }

  @Test
  public void test251() {
    coral.tests.JPFBenchmark.benchmark09(-77.0541339733191,45.67756781371119 ) ;
  }

  @Test
  public void test252() {
    coral.tests.JPFBenchmark.benchmark09(7.753228590405851E-7,-195.21931849688684 ) ;
  }

  @Test
  public void test253() {
    coral.tests.JPFBenchmark.benchmark09(-7.760635923636558,0.20240562013877295 ) ;
  }

  @Test
  public void test254() {
    coral.tests.JPFBenchmark.benchmark09(7.771561172376096E-16,-41.777792902317756 ) ;
  }

  @Test
  public void test255() {
    coral.tests.JPFBenchmark.benchmark09(79.51918339933054,3.259356834936142 ) ;
  }

  @Test
  public void test256() {
    coral.tests.JPFBenchmark.benchmark09(-7.993605777301127E-15,12.519900792451821 ) ;
  }

  @Test
  public void test257() {
    coral.tests.JPFBenchmark.benchmark09(8.01581023779363E-14,-1.8927935162839895 ) ;
  }

  @Test
  public void test258() {
    coral.tests.JPFBenchmark.benchmark09(80.30199000957825,-100.0 ) ;
  }

  @Test
  public void test259() {
    coral.tests.JPFBenchmark.benchmark09(-81.24386229302712,81.51831809133697 ) ;
  }

  @Test
  public void test260() {
    coral.tests.JPFBenchmark.benchmark09(-81.26704108481628,-52.2797762473773 ) ;
  }

  @Test
  public void test261() {
    coral.tests.JPFBenchmark.benchmark09(81.31659913764365,-42.49749688989407 ) ;
  }

  @Test
  public void test262() {
    coral.tests.JPFBenchmark.benchmark09(-81.45193424042257,25.847872364783214 ) ;
  }

  @Test
  public void test263() {
    coral.tests.JPFBenchmark.benchmark09(-8.253963007695686,19.221121885131126 ) ;
  }

  @Test
  public void test264() {
    coral.tests.JPFBenchmark.benchmark09(-83.17853648467361,9.231094898961175 ) ;
  }

  @Test
  public void test265() {
    coral.tests.JPFBenchmark.benchmark09(83.70820839690614,-0.018765140920790957 ) ;
  }

  @Test
  public void test266() {
    coral.tests.JPFBenchmark.benchmark09(86.16210275476547,-84.26950203146558 ) ;
  }

  @Test
  public void test267() {
    coral.tests.JPFBenchmark.benchmark09(87.18464404735758,-66.29742661130184 ) ;
  }

  @Test
  public void test268() {
    coral.tests.JPFBenchmark.benchmark09(-87.65338775190385,91.46710001649097 ) ;
  }

  @Test
  public void test269() {
    coral.tests.JPFBenchmark.benchmark09(-87.73152319633036,61.17957876300687 ) ;
  }

  @Test
  public void test270() {
    coral.tests.JPFBenchmark.benchmark09(8.881784197001252E-16,-23.116709045896158 ) ;
  }

  @Test
  public void test271() {
    coral.tests.JPFBenchmark.benchmark09(-8.881784197001252E-16,33.068941485853756 ) ;
  }

  @Test
  public void test272() {
    coral.tests.JPFBenchmark.benchmark09(-8.881784197001252E-16,3.3456795199079927 ) ;
  }

  @Test
  public void test273() {
    coral.tests.JPFBenchmark.benchmark09(88.82817482631393,-0.017683537119458775 ) ;
  }

  @Test
  public void test274() {
    coral.tests.JPFBenchmark.benchmark09(-89.36564249802007,12.595930864916838 ) ;
  }

  @Test
  public void test275() {
    coral.tests.JPFBenchmark.benchmark09(90.86032320813024,-27.330867909059677 ) ;
  }

  @Test
  public void test276() {
    coral.tests.JPFBenchmark.benchmark09(-9.159036216761809,0.06232054656407508 ) ;
  }

  @Test
  public void test277() {
    coral.tests.JPFBenchmark.benchmark09(-91.95901530036787,36.15765706115761 ) ;
  }

  @Test
  public void test278() {
    coral.tests.JPFBenchmark.benchmark09(-9.270174190178572,0.06157330426167864 ) ;
  }

  @Test
  public void test279() {
    coral.tests.JPFBenchmark.benchmark09(93.07553629596958,-0.0168765756213313 ) ;
  }

  @Test
  public void test280() {
    coral.tests.JPFBenchmark.benchmark09(93.12286156139623,-145.82385047675785 ) ;
  }

  @Test
  public void test281() {
    coral.tests.JPFBenchmark.benchmark09(93.66486654555291,-22.800277387674342 ) ;
  }

  @Test
  public void test282() {
    coral.tests.JPFBenchmark.benchmark09(93.7174226593304,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test283() {
    coral.tests.JPFBenchmark.benchmark09(-94.58772172455478,4.5365082549002835 ) ;
  }

  @Test
  public void test284() {
    coral.tests.JPFBenchmark.benchmark09(94.94922617454651,-24.818069678241102 ) ;
  }

  @Test
  public void test285() {
    coral.tests.JPFBenchmark.benchmark09(9.66077324684666,-43.976786070449194 ) ;
  }

  @Test
  public void test286() {
    coral.tests.JPFBenchmark.benchmark09(97.3177186347929,-31.071247567668017 ) ;
  }

  @Test
  public void test287() {
    coral.tests.JPFBenchmark.benchmark09(-97.98660460999416,-45.93969756797895 ) ;
  }

  @Test
  public void test288() {
    coral.tests.JPFBenchmark.benchmark09(-98.08144201818214,-79.9669209087356 ) ;
  }

  @Test
  public void test289() {
    coral.tests.JPFBenchmark.benchmark09(98.91896226016931,-16.202922918966394 ) ;
  }

  @Test
  public void test290() {
    coral.tests.JPFBenchmark.benchmark09(99.99897301708681,-2.764629927470562 ) ;
  }

  @Test
  public void test291() {
    coral.tests.JPFBenchmark.benchmark09(99.99999999999999,-6.665396182979548E-14 ) ;
  }
}
