import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(138,-78.63779066454828 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(-257,69.64862491375848 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(428,0.0 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(526,8.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(-711,8.616248188761944 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-757,8.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(835,22.784100364739984 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(-918,-11.67417104016073 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(927,0 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(964,-35.31110390298204 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(-987,0 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-987,0.0 ) ;
  }
}
