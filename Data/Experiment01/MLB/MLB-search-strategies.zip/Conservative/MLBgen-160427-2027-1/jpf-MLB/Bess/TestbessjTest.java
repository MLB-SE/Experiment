import org.junit.Test;

public class TestbessjTest {

  @Test
  public void test0() {
    bess.bessj(0,-6.228596200165158E-159 ) ;
  }

  @Test
  public void test1() {
    bess.bessj(0,6.555224289595561E-162 ) ;
  }

  @Test
  public void test2() {
    bess.bessj(1,0.5689044894225205 ) ;
  }

  @Test
  public void test3() {
    bess.bessj(107,0.0 ) ;
  }

  @Test
  public void test4() {
    bess.bessj(-107,-52.03649195802183 ) ;
  }

  @Test
  public void test5() {
    bess.bessj(1,-0.8903939763531942 ) ;
  }

  @Test
  public void test6() {
    bess.bessj(1,1.0 ) ;
  }

  @Test
  public void test7() {
    bess.bessj(112,-121.05669857655025 ) ;
  }

  @Test
  public void test8() {
    bess.bessj(-113,1.539088486545154 ) ;
  }

  @Test
  public void test9() {
    bess.bessj(124,-124.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessj(-124,-36.47984225952061 ) ;
  }

  @Test
  public void test11() {
    bess.bessj(139,15.09031911528291 ) ;
  }

  @Test
  public void test12() {
    bess.bessj(147,-93.04537626369076 ) ;
  }

  @Test
  public void test13() {
    bess.bessj(1644,1.3622042159542408E-161 ) ;
  }

  @Test
  public void test14() {
    bess.bessj(1,6.480584995488954E-162 ) ;
  }

  @Test
  public void test15() {
    bess.bessj(-1742,0.0 ) ;
  }

  @Test
  public void test16() {
    bess.bessj(-177,77.46137262562448 ) ;
  }

  @Test
  public void test17() {
    bess.bessj(-18,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test18() {
    bess.bessj(-192,-1.3892242184281734E-163 ) ;
  }

  @Test
  public void test19() {
    bess.bessj(2,3.469446951953614E-18 ) ;
  }

  @Test
  public void test20() {
    bess.bessj(-241,0.0 ) ;
  }

  @Test
  public void test21() {
    bess.bessj(-248,0.0 ) ;
  }

  @Test
  public void test22() {
    bess.bessj(2,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test23() {
    bess.bessj(-302,63.12679743557058 ) ;
  }

  @Test
  public void test24() {
    bess.bessj(-325,-69.70376607486892 ) ;
  }

  @Test
  public void test25() {
    bess.bessj(352,-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test26() {
    bess.bessj(-379,6.606496248439763E-162 ) ;
  }

  @Test
  public void test27() {
    bess.bessj(388,0.0 ) ;
  }

  @Test
  public void test28() {
    bess.bessj(401,-64.57997798721307 ) ;
  }

  @Test
  public void test29() {
    bess.bessj(40,62.28312352729361 ) ;
  }

  @Test
  public void test30() {
    bess.bessj(439,0 ) ;
  }

  @Test
  public void test31() {
    bess.bessj(461,58.17332811454264 ) ;
  }

  @Test
  public void test32() {
    bess.bessj(546,4.446676975557074E-150 ) ;
  }

  @Test
  public void test33() {
    bess.bessj(-560,5.556896873712694E-163 ) ;
  }

  @Test
  public void test34() {
    bess.bessj(629,0.0 ) ;
  }

  @Test
  public void test35() {
    bess.bessj(762,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test36() {
    bess.bessj(-775,-7.112827998352248E-161 ) ;
  }

  @Test
  public void test37() {
    bess.bessj(806,2.5269841324701218E-175 ) ;
  }

  @Test
  public void test38() {
    bess.bessj(-886,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test39() {
    bess.bessj(889,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test40() {
    bess.bessj(929,88.7628728698206 ) ;
  }

  @Test
  public void test41() {
    bess.bessj(-942,0 ) ;
  }

  @Test
  public void test42() {
    bess.bessj(95,95.0 ) ;
  }

  @Test
  public void test43() {
    bess.bessj(978,-74.70361073378264 ) ;
  }
}
