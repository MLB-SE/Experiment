import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(-0.23001052974669278 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(-10.173218914970647 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(-10.56434210695349 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(-10.671398964496603 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(11.299722613481407 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(12.498808512102386 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(12.525605995068801 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(-14.072531824395426 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(-15.248505526790936 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(-15.361742812493674 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(-15.854331918939153 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(-15.984706755581442 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(16.823248417297634 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(-16.913359945665547 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(17.30722757296313 ) ;
  }

  @Test
  public void test15() {
    dawson.probks(-18.367065103983265 ) ;
  }

  @Test
  public void test16() {
    dawson.probks(19.158802085770347 ) ;
  }

  @Test
  public void test17() {
    dawson.probks(19.288403990778423 ) ;
  }

  @Test
  public void test18() {
    dawson.probks(19.28938914462776 ) ;
  }

  @Test
  public void test19() {
    dawson.probks(19.2896393996883 ) ;
  }

  @Test
  public void test20() {
    dawson.probks(-19.290544332425142 ) ;
  }

  @Test
  public void test21() {
    dawson.probks(19.291518281829926 ) ;
  }

  @Test
  public void test22() {
    dawson.probks(-19.291530477104512 ) ;
  }

  @Test
  public void test23() {
    dawson.probks(19.291695476497104 ) ;
  }

  @Test
  public void test24() {
    dawson.probks(-19.292008875912305 ) ;
  }

  @Test
  public void test25() {
    dawson.probks(19.293686122667612 ) ;
  }

  @Test
  public void test26() {
    dawson.probks(19.295559504303466 ) ;
  }

  @Test
  public void test27() {
    dawson.probks(-19.296000652725695 ) ;
  }

  @Test
  public void test28() {
    dawson.probks(-19.2960147644607 ) ;
  }

  @Test
  public void test29() {
    dawson.probks(-2.1568906526365055 ) ;
  }

  @Test
  public void test30() {
    dawson.probks(29.442759788004537 ) ;
  }

  @Test
  public void test31() {
    dawson.probks(32.10749200414568 ) ;
  }

  @Test
  public void test32() {
    dawson.probks(-38.852750823660486 ) ;
  }

  @Test
  public void test33() {
    dawson.probks(-5.037790095207214 ) ;
  }

  @Test
  public void test34() {
    dawson.probks(52.024935125284685 ) ;
  }

  @Test
  public void test35() {
    dawson.probks(5.90893418359579 ) ;
  }

  @Test
  public void test36() {
    dawson.probks(6.030036788850055 ) ;
  }

  @Test
  public void test37() {
    dawson.probks(-61.38595424492757 ) ;
  }

  @Test
  public void test38() {
    dawson.probks(62.64643086764511 ) ;
  }

  @Test
  public void test39() {
    dawson.probks(65.7110705627729 ) ;
  }

  @Test
  public void test40() {
    dawson.probks(-7.671748177478648 ) ;
  }

  @Test
  public void test41() {
    dawson.probks(7.737291043510993 ) ;
  }

  @Test
  public void test42() {
    dawson.probks(-82.81935112492991 ) ;
  }

  @Test
  public void test43() {
    dawson.probks(85.1090467409557 ) ;
  }

  @Test
  public void test44() {
    dawson.probks(90.76546591452944 ) ;
  }

  @Test
  public void test45() {
    dawson.probks(-9.245747224171353 ) ;
  }

  @Test
  public void test46() {
    dawson.probks(96.29607447361633 ) ;
  }

  @Test
  public void test47() {
    dawson.probks(9.94269089181239 ) ;
  }
}
