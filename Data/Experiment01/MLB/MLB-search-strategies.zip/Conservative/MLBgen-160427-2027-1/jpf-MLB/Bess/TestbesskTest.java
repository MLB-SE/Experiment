import org.junit.Test;

public class TestbesskTest {

  @Test
  public void test0() {
    bess.bessk(134,-18.83555040014106 ) ;
  }

  @Test
  public void test1() {
    bess.bessk(183,2.0 ) ;
  }

  @Test
  public void test2() {
    bess.bessk(196,80.39712327737902 ) ;
  }

  @Test
  public void test3() {
    bess.bessk(206,1.0E-323 ) ;
  }

  @Test
  public void test4() {
    bess.bessk(-208,0 ) ;
  }

  @Test
  public void test5() {
    bess.bessk(-252,-92.31249480838824 ) ;
  }

  @Test
  public void test6() {
    bess.bessk(342,1.2752561769343012E-16 ) ;
  }

  @Test
  public void test7() {
    bess.bessk(-346,56.12856697506291 ) ;
  }

  @Test
  public void test8() {
    bess.bessk(387,2.0 ) ;
  }

  @Test
  public void test9() {
    bess.bessk(-401,2.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessk(-402,0.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessk(-443,2.0 ) ;
  }

  @Test
  public void test12() {
    bess.bessk(-483,-1.734723475976807E-18 ) ;
  }

  @Test
  public void test13() {
    bess.bessk(657,-73.538050491297 ) ;
  }

  @Test
  public void test14() {
    bess.bessk(-669,-51.31322130670573 ) ;
  }

  @Test
  public void test15() {
    bess.bessk(-70,8.129872718476162E-261 ) ;
  }

  @Test
  public void test16() {
    bess.bessk(716,0.0 ) ;
  }

  @Test
  public void test17() {
    bess.bessk(-736,-74.2479917411598 ) ;
  }

  @Test
  public void test18() {
    bess.bessk(770,0 ) ;
  }

  @Test
  public void test19() {
    bess.bessk(785,1.798607931085792 ) ;
  }

  @Test
  public void test20() {
    bess.bessk(-836,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test21() {
    bess.bessk(854,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test22() {
    bess.bessk(874,70.68251143546408 ) ;
  }

  @Test
  public void test23() {
    bess.bessk(-877,0.03749170456467432 ) ;
  }
}
