import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.0,0.0 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(-0.007222786558981064,-0.0072229375016903815 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(0.008247215380085292,-0.008247216322345253 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(0.0,100.0 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-0.011813776921852218,1.3877787807814457E-17 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(0.0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(0.0,-1.4E-322 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(0.0,-1.5E-323 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(0.0,1.73E-322 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(0.0,-1.7800590868057611E-307 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(0.0,1.9113238906945923E-298 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(0.0,1.9E-322 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(0.0,2.0E-323 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(0.0,-2.2081878100212577 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(0.0,-22.449738459719118 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(0.0,-2.446494580089078E-296 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(0.0,2.465190328815662E-32 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(0.0,-2.716154612436E-312 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(0.0,3.16E-322 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(0.0,3.5E-323 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(0.0,4.0E-323 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(0.0,45.69376088082062 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(0.0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(0.0,4.930380657631324E-32 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(0.0,-4.9E-323 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(0.0,5.43230922487E-312 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(0.0,5.9E-323 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(0.0,-61.50569892634155 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(0.0,6.4E-323 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(0.0,-7.4E-323 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(0.0,-7.9E-323 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(0.0,-87.57191663770466 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(0.0,8.977651093538419E-190 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(-0.09098382196354184,0.09098382196354189 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(0.0,9.4E-323 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(0.0,97.95448363085788 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(0.0,-9.860761315262648E-32 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(0.32558500916751265,-0.32558500916906447 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(0.5094092652421481,0.5094090218196787 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(0.9317332760260655,-14.80063997222419 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(1.0118E-320,0.0 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(1.0581867713474008E-31,1.0581867722131348E-31 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(1.0587911840678754E-22,-1.9721522630525295E-31 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(1.0691058840368783E-50,1.6314249621331407E-35 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(-1.0842021724855044E-19,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(1.0E-323,-2.0E-323 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-11.974430798860652,-19.190276607017438 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(1.2338789709326767E-178,1.2338789709326767E-178 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(-1.2416008742147837E-63,-1.241544376853084E-63 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(1.282729156652829E-7,1.2827291566528293E-7 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(13.206278019124358,13.206278019124358 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-1.3713661391599488E-33,1.7715909482375635E-33 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(13.760205212824388,0 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-13.780397954462124,0.0 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(-1.3877787807814457E-17,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(1.402757983365378E-191,-1.557374211108995E-207 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-1.5291218216687929E-33,1.529121821668793E-33 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(15.356709927073851,18.686077608703215 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(1.5407439555097887E-33,-1.234098667461054E-17 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(-1.5641274181117976E-148,1.7365302730352168E-164 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(1.5793650827938261E-176,1.5793650827938261E-176 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(1.58E-322,0.0 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(1.615482347173307E-18,-1.6103086405154868E-18 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(1.7105694144590052E-49,1.0005024255865276E-33 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(1.734723475976807E-18,-1.734829355095214E-18 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(1.7406242255195668E-65,1.7406242255195666E-65 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(-17.611297920017748,-78.13090524653651 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(-1.8465957235571472E-127,-5.1253327236687384E-144 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(19.112658973178284,19.112658973178284 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(-1.9742063534922827E-177,1.9742063534922827E-177 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(2.0143007725689407E-31,2.0143007725690042E-31 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-2.08E-322,-2.5E-323 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(2.0E-323,0.0 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-2.1175823681357508E-22,5.293955920339377E-23 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(2.2227587494850775E-162,-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(2.2859400988619277E-66,2.285940098861928E-66 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(2.317726184556591,-28.63098122427212 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-2.410251283121667,44.81874146336878 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-2.4308653429145085E-63,2.4688476138975477E-63 ) ;
  }

  @Test
  public void test79() {
    dawson.pythag(-24.803928959192877,24.803928959192877 ) ;
  }

  @Test
  public void test80() {
    dawson.pythag(2.5802712304394434E-16,-2.5802712304394434E-16 ) ;
  }

  @Test
  public void test81() {
    dawson.pythag(-2.590327E-318,0.0 ) ;
  }

  @Test
  public void test82() {
    dawson.pythag(-26.370765395219877,69.12158160304423 ) ;
  }

  @Test
  public void test83() {
    dawson.pythag(-2.6469779601696886E-23,2.6469779601696886E-23 ) ;
  }

  @Test
  public void test84() {
    dawson.pythag(-2.676729946523375E-82,-3.248565551764031E-114 ) ;
  }

  @Test
  public void test85() {
    dawson.pythag(2.710505431213761E-20,2.710505431213761E-20 ) ;
  }

  @Test
  public void test86() {
    dawson.pythag(-27.704393340373883,43.19652588321816 ) ;
  }

  @Test
  public void test87() {
    dawson.pythag(2.778448436856347E-163,-1.9742063534922827E-177 ) ;
  }

  @Test
  public void test88() {
    dawson.pythag(3.0814879110195774E-33,-1.682848586667401E-33 ) ;
  }

  @Test
  public void test89() {
    dawson.pythag(3.0814879110195774E-33,-4.622231866529366E-33 ) ;
  }

  @Test
  public void test90() {
    dawson.pythag(3.1587301655876523E-176,3.506894958413445E-192 ) ;
  }

  @Test
  public void test91() {
    dawson.pythag(-3.247731073528402E-19,-3.247731073528397E-19 ) ;
  }

  @Test
  public void test92() {
    dawson.pythag(-3.31561842E-316,0.0 ) ;
  }

  @Test
  public void test93() {
    dawson.pythag(-3.469446951953614E-18,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test94() {
    dawson.pythag(-3.488120700934677E-105,-9.363352709384397E-97 ) ;
  }

  @Test
  public void test95() {
    dawson.pythag(-3.506894958413445E-192,-3.8934355277724873E-208 ) ;
  }

  @Test
  public void test96() {
    dawson.pythag(3.6171204779179415E-12,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test97() {
    dawson.pythag(-36.64937391498589,32.92813792538453 ) ;
  }

  @Test
  public void test98() {
    dawson.pythag(-3.7192263233644383,3.7192263233644383 ) ;
  }

  @Test
  public void test99() {
    dawson.pythag(3.7303958963440262,0.0 ) ;
  }

  @Test
  public void test100() {
    dawson.pythag(37.54906683019606,-37.54906683019606 ) ;
  }

  @Test
  public void test101() {
    dawson.pythag(-37.56640036151215,-37.56640036151215 ) ;
  }

  @Test
  public void test102() {
    dawson.pythag(-3.8960068637056082,-56.82704189314365 ) ;
  }

  @Test
  public void test103() {
    dawson.pythag(3.944304526105059E-31,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test104() {
    dawson.pythag(3.9484127069845653E-177,-4.383618698016806E-193 ) ;
  }

  @Test
  public void test105() {
    dawson.pythag(4.0E-323,0.0 ) ;
  }

  @Test
  public void test106() {
    dawson.pythag(-4.209384110788221,0 ) ;
  }

  @Test
  public void test107() {
    dawson.pythag(-4.2351647362715017E-22,4.764560328305439E-22 ) ;
  }

  @Test
  public void test108() {
    dawson.pythag(-4.251915904029492E-33,4.2519159040294914E-33 ) ;
  }

  @Test
  public void test109() {
    dawson.pythag(4.276806969653545E-50,4.276423536147513E-50 ) ;
  }

  @Test
  public void test110() {
    dawson.pythag(-4.383618698016806E-193,4.383618698016806E-193 ) ;
  }

  @Test
  public void test111() {
    dawson.pythag(4.383618698016806E-193,4.383618698016806E-193 ) ;
  }

  @Test
  public void test112() {
    dawson.pythag(44.363655376159095,-44.363655376159095 ) ;
  }

  @Test
  public void test113() {
    dawson.pythag(-45.03317027895002,45.03317027895002 ) ;
  }

  @Test
  public void test114() {
    dawson.pythag(47.875184822073535,-47.875184822073535 ) ;
  }

  @Test
  public void test115() {
    dawson.pythag(48.43986486573283,85.88988969182367 ) ;
  }

  @Test
  public void test116() {
    dawson.pythag(-4.930380657631324E-32,-3.6634926249971666E-17 ) ;
  }

  @Test
  public void test117() {
    dawson.pythag(4.930380657631324E-32,4.930380657631324E-32 ) ;
  }

  @Test
  public void test118() {
    dawson.pythag(4.9355158837307067E-178,-2.805515966730756E-191 ) ;
  }

  @Test
  public void test119() {
    dawson.pythag(-4.9E-324,0.0 ) ;
  }

  @Test
  public void test120() {
    dawson.pythag(-5.0052077379577523E-147,-3.910318545279494E-149 ) ;
  }

  @Test
  public void test121() {
    dawson.pythag(-53.87992906008918,-53.87992906008918 ) ;
  }

  @Test
  public void test122() {
    dawson.pythag(-5.421010862427522E-20,6.776263578034403E-20 ) ;
  }

  @Test
  public void test123() {
    dawson.pythag(5.4738221262688167E-48,5.482600639610295E-48 ) ;
  }

  @Test
  public void test124() {
    dawson.pythag(-5.4738221262688167E-48,-5.49139631702887E-48 ) ;
  }

  @Test
  public void test125() {
    dawson.pythag(-5.4E-323,0.0 ) ;
  }

  @Test
  public void test126() {
    dawson.pythag(-55.04780578920836,0.0 ) ;
  }

  @Test
  public void test127() {
    dawson.pythag(-5.551115123125783E-17,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test128() {
    dawson.pythag(-55.845650666725135,-19.430508749821016 ) ;
  }

  @Test
  public void test129() {
    dawson.pythag(5.6902623986817984E-160,6.3174603311753045E-176 ) ;
  }

  @Test
  public void test130() {
    dawson.pythag(59.59532404440432,-64.68234884261246 ) ;
  }

  @Test
  public void test131() {
    dawson.pythag(5.9E-323,0.0 ) ;
  }

  @Test
  public void test132() {
    dawson.pythag(-5.9E-323,1.5E-323 ) ;
  }

  @Test
  public void test133() {
    dawson.pythag(-6.075264485444922E-17,-3.944304526105059E-31 ) ;
  }

  @Test
  public void test134() {
    dawson.pythag(-6.162975822039155E-33,-3.3087224502121107E-24 ) ;
  }

  @Test
  public void test135() {
    dawson.pythag(-6.22949684443598E-207,-6.916130828522582E-223 ) ;
  }

  @Test
  public void test136() {
    dawson.pythag(-6.267074712201467E-64,-7.490682167507517E-96 ) ;
  }

  @Test
  public void test137() {
    dawson.pythag(-6.3174603311753045E-176,7.01378991682689E-192 ) ;
  }

  @Test
  public void test138() {
    dawson.pythag(66.54538712506317,7.813899841779886 ) ;
  }

  @Test
  public void test139() {
    dawson.pythag(-6.776263578034403E-21,-6.776263578034403E-21 ) ;
  }

  @Test
  public void test140() {
    dawson.pythag(-6.842277657836021E-49,1.5745872982730385E-33 ) ;
  }

  @Test
  public void test141() {
    dawson.pythag(68.72889526342819,68.72889526342819 ) ;
  }

  @Test
  public void test142() {
    dawson.pythag(6.938893903907228E-18,6.952446431063297E-18 ) ;
  }

  @Test
  public void test143() {
    dawson.pythag(70.06549081891399,0.0 ) ;
  }

  @Test
  public void test144() {
    dawson.pythag(71.02997712745457,-8.886862001353151 ) ;
  }

  @Test
  public void test145() {
    dawson.pythag(72.97039332333742,-48.826719843882586 ) ;
  }

  @Test
  public void test146() {
    dawson.pythag(7.345100375743868,10.596852669120736 ) ;
  }

  @Test
  public void test147() {
    dawson.pythag(74.1932022298532,-41.22348472007054 ) ;
  }

  @Test
  public void test148() {
    dawson.pythag(7.449999352361772E-20,-7.449999352361901E-20 ) ;
  }

  @Test
  public void test149() {
    dawson.pythag(7.45745104881521E-18,-7.457461644234975E-18 ) ;
  }

  @Test
  public void test150() {
    dawson.pythag(74.74904734895114,69.75684431520409 ) ;
  }

  @Test
  public void test151() {
    dawson.pythag(74.86223938611093,97.09117395219161 ) ;
  }

  @Test
  public void test152() {
    dawson.pythag(7.4E-323,0.0 ) ;
  }

  @Test
  public void test153() {
    dawson.pythag(-75.56205962025588,-75.56205962025588 ) ;
  }

  @Test
  public void test154() {
    dawson.pythag(-7.610241384540206E-48,-7.610241384540207E-48 ) ;
  }

  @Test
  public void test155() {
    dawson.pythag(-7.703719777548943E-34,-4.287836514002247E-17 ) ;
  }

  @Test
  public void test156() {
    dawson.pythag(-7.823586285246663E-34,7.823623677324908E-34 ) ;
  }

  @Test
  public void test157() {
    dawson.pythag(7.85805665085787E-65,-3.3735033418337674E-80 ) ;
  }

  @Test
  public void test158() {
    dawson.pythag(7.888609052210118E-31,-7.888609052210118E-31 ) ;
  }

  @Test
  public void test159() {
    dawson.pythag(82.49948715590793,0.0 ) ;
  }

  @Test
  public void test160() {
    dawson.pythag(-82.54812047689346,-44.20331469149674 ) ;
  }

  @Test
  public void test161() {
    dawson.pythag(-82.64244922330212,8.218491009565952 ) ;
  }

  @Test
  public void test162() {
    dawson.pythag(8.266752465878689E-48,8.17147262781313E-48 ) ;
  }

  @Test
  public void test163() {
    dawson.pythag(-8.470329472543003E-22,8.470329472543003E-22 ) ;
  }

  @Test
  public void test164() {
    dawson.pythag(-8.580610804868188E-16,8.580614488756831E-16 ) ;
  }

  @Test
  public void test165() {
    dawson.pythag(8.673617379884035E-19,2.9725349706387725E-6 ) ;
  }

  @Test
  public void test166() {
    dawson.pythag(8.673617379884035E-19,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test167() {
    dawson.pythag(8.673617379884035E-19,-6.938893903907228E-18 ) ;
  }

  @Test
  public void test168() {
    dawson.pythag(-8.682651365176084E-165,-1.5793650827938261E-176 ) ;
  }

  @Test
  public void test169() {
    dawson.pythag(-91.8118613610236,-23.3362068270893 ) ;
  }

  @Test
  public void test170() {
    dawson.pythag(-9.202632046025604E-23,-9.202632046019696E-23 ) ;
  }

  @Test
  public void test171() {
    dawson.pythag(-92.46857622181079,0 ) ;
  }

  @Test
  public void test172() {
    dawson.pythag(-9.639679460411536E-181,9.639679460411536E-181 ) ;
  }

  @Test
  public void test173() {
    dawson.pythag(-97.08364956667901,51.36590872317515 ) ;
  }

  @Test
  public void test174() {
    dawson.pythag(-98.41222453977913,0.0 ) ;
  }

  @Test
  public void test175() {
    dawson.pythag(-9.860761315262648E-32,7.92539179419726E-17 ) ;
  }

  @Test
  public void test176() {
    dawson.pythag(9.860761315262648E-32,9.611507132620847E-17 ) ;
  }
}
