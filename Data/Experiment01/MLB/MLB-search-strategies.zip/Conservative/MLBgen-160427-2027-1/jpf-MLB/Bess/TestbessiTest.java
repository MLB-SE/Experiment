import org.junit.Test;

public class TestbessiTest {

  @Test
  public void test0() {
    bess.bessi(1030,-4.0597434319433E-33 ) ;
  }

  @Test
  public void test1() {
    bess.bessi(-121,57.749188545430655 ) ;
  }

  @Test
  public void test2() {
    bess.bessi(-310,7.483537220011778E-9 ) ;
  }

  @Test
  public void test3() {
    bess.bessi(347,7.903873254508392E-9 ) ;
  }

  @Test
  public void test4() {
    bess.bessi(-367,0 ) ;
  }

  @Test
  public void test5() {
    bess.bessi(37,0 ) ;
  }

  @Test
  public void test6() {
    bess.bessi(-38,-2.8451311993408992E-160 ) ;
  }

  @Test
  public void test7() {
    bess.bessi(4223,8.748962050525804E-162 ) ;
  }

  @Test
  public void test8() {
    bess.bessi(-448,-54.129641211660726 ) ;
  }

  @Test
  public void test9() {
    bess.bessi(-824,64.71362725189104 ) ;
  }

  @Test
  public void test10() {
    bess.bessi(-861,-4.057443566494958E-34 ) ;
  }

  @Test
  public void test11() {
    bess.bessi(914,-38.17318541644439 ) ;
  }

  @Test
  public void test12() {
    bess.bessi(936,94.37120382151451 ) ;
  }

  @Test
  public void test13() {
    bess.bessi(952,86.49155616832999 ) ;
  }
}
