import org.junit.Test;

public class Sample01Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark01(12.955842321455386,-51.167153331182234 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark01(56.9590806047363,-96.94773934668284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark01(96.18128925717104,48.8753903542935 ) ;
  }
}
