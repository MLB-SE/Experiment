import org.junit.Test;

public class Sample12Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark12(0.012066293217245061,0.4388636832310766,-66.59360914319498,0.6588027962641907 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark12(-0.6014943979837994,-0.15184279964269365,27.58816645116636,-20.8099158151267 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark12(-0.734982791639041,-0.9865593863341786,-29.642589534609826,-65.11348490181616 ) ;
  }
}
