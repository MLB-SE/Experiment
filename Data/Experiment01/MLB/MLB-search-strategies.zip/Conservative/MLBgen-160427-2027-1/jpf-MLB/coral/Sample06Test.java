import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-10.833775874765792,9.072707739586932,4.561874028941219 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-36.77262274432436,-7.494726594337791,-34.2882663215738 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(-46.690021947050745,-17.37598632393213,-81.54391837962507 ) ;
  }
}
