import org.junit.Test;

public class Sample15Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark15(0.1479312455243189,-66.00201524876495,99.05245128215486,-19.010419699373983 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark15(0.6406624388436626,29.204221690173938,-41.90256632739893,-63.83418738108093 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark15(-0.8734196995090291,-34.43923619626625,92.2570788966211,45.70773158729771 ) ;
  }
}
