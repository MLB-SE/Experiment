import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-51.427194923679934,0,-25.16605560081304 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,57.59586531887375,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,64.78137625411149,0,9.235414535355796 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-67.6452634708333,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(-84.88789195491239,-61.531093402055426,63.91594256323694,-89.49113832862956 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(93.7039286428415,47.579649644769034,24.078581212690267,62.67981020655469 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(-97.16023770244276,-90.39519066073743,58.88067543553344,-66.2777394575894 ) ;
  }
}
