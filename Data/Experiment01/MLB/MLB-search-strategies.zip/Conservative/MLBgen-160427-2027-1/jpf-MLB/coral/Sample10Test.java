import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(6.674763979442446,22.731571053717687,2.0498557132695936 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(-80.13300097076454,-65.30911278009042,13.58172389968884 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(98.066775253408,-27.992717968562502,78.86655073974359 ) ;
  }
}
