import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(2.413094121448788,-76.2269961158463,-98.53159798283288 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(71.4507785442502,-29.653429936509795,75.34303950870682 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-99.91592997499454,-31.84434317115476,0.890589850517955 ) ;
  }
}
