import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.018460517930378728,78.53474876629352,31.230497780628752,62.57042714750747 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-0.375811474606877,5.586111861232084,-40.77320389939347,173.7365550604859 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.4548854256420469,68.75028663249981,88.07320798092525,-77.73625731215856 ) ;
  }
}
