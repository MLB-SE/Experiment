import org.junit.Test;

public class Sample13Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark13(0.27540357050372677,42.10277695737605,-84.68556982265926,-9.765119827046604 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark13(0.3187929349046641,-57.88824710453686,-6.519483439191333,51.90169278267604 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark13(0.9141875241660813,-77.34333023817007,-8.849678180118744,5.189840780337877 ) ;
  }
}
