import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.6790804466469353,51.95889598448329,21.750496041424498,47.39106047562527 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.778764964024603,30.04082329845542,38.38277565328909,-51.95594033424919 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.8511292696565391,34.81320589923239,-11.520345767239467,-14.696989627781745 ) ;
  }
}
