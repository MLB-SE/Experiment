import org.junit.Test;

public class Sample09Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark09(19.165864178823583,75.26168527241202 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark09(-56.74337102067631,-36.63937426890295 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark09(70.9964270311402,15.566246524028287 ) ;
  }
}
