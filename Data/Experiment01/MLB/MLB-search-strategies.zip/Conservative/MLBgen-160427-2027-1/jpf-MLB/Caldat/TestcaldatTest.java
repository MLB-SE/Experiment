import org.junit.Test;

public class TestcaldatTest {

  @Test
  public void test0() {
    caldat.caldat(0 ) ;
  }

  @Test
  public void test1() {
    caldat.caldat(-1 ) ;
  }

  @Test
  public void test2() {
    caldat.caldat(11056 ) ;
  }

  @Test
  public void test3() {
    caldat.caldat(12913 ) ;
  }

  @Test
  public void test4() {
    caldat.caldat(-1365 ) ;
  }

  @Test
  public void test5() {
    caldat.caldat(-137 ) ;
  }

  @Test
  public void test6() {
    caldat.caldat(14280 ) ;
  }

  @Test
  public void test7() {
    caldat.caldat(-171 ) ;
  }

  @Test
  public void test8() {
    caldat.caldat(18459 ) ;
  }

  @Test
  public void test9() {
    caldat.caldat(19155 ) ;
  }

  @Test
  public void test10() {
    caldat.caldat(20119 ) ;
  }

  @Test
  public void test11() {
    caldat.caldat(207 ) ;
  }

  @Test
  public void test12() {
    caldat.caldat(21311 ) ;
  }

  @Test
  public void test13() {
    caldat.caldat(22166 ) ;
  }

  @Test
  public void test14() {
    caldat.caldat(-222 ) ;
  }

  @Test
  public void test15() {
    caldat.caldat(2610 ) ;
  }

  @Test
  public void test16() {
    caldat.caldat(-270 ) ;
  }

  @Test
  public void test17() {
    caldat.caldat(27177 ) ;
  }

  @Test
  public void test18() {
    caldat.caldat(-285 ) ;
  }

  @Test
  public void test19() {
    caldat.caldat(-290 ) ;
  }

  @Test
  public void test20() {
    caldat.caldat(-295 ) ;
  }

  @Test
  public void test21() {
    caldat.caldat(3050 ) ;
  }

  @Test
  public void test22() {
    caldat.caldat(-307 ) ;
  }

  @Test
  public void test23() {
    caldat.caldat(-309 ) ;
  }

  @Test
  public void test24() {
    caldat.caldat(31 ) ;
  }

  @Test
  public void test25() {
    caldat.caldat(-316 ) ;
  }

  @Test
  public void test26() {
    caldat.caldat(-320 ) ;
  }

  @Test
  public void test27() {
    caldat.caldat(-324 ) ;
  }

  @Test
  public void test28() {
    caldat.caldat(3311 ) ;
  }

  @Test
  public void test29() {
    caldat.caldat(3382 ) ;
  }

  @Test
  public void test30() {
    caldat.caldat(3384 ) ;
  }

  @Test
  public void test31() {
    caldat.caldat(-360 ) ;
  }

  @Test
  public void test32() {
    caldat.caldat(390 ) ;
  }

  @Test
  public void test33() {
    caldat.caldat(4076 ) ;
  }

  @Test
  public void test34() {
    caldat.caldat(41 ) ;
  }

  @Test
  public void test35() {
    caldat.caldat(4114 ) ;
  }

  @Test
  public void test36() {
    caldat.caldat(421 ) ;
  }

  @Test
  public void test37() {
    caldat.caldat(423 ) ;
  }

  @Test
  public void test38() {
    caldat.caldat(441 ) ;
  }

  @Test
  public void test39() {
    caldat.caldat(4455 ) ;
  }

  @Test
  public void test40() {
    caldat.caldat(4462 ) ;
  }

  @Test
  public void test41() {
    caldat.caldat(4469 ) ;
  }

  @Test
  public void test42() {
    caldat.caldat(4479 ) ;
  }

  @Test
  public void test43() {
    caldat.caldat(482 ) ;
  }

  @Test
  public void test44() {
    caldat.caldat(4875 ) ;
  }

  @Test
  public void test45() {
    caldat.caldat(5160 ) ;
  }

  @Test
  public void test46() {
    caldat.caldat(534 ) ;
  }

  @Test
  public void test47() {
    caldat.caldat(-545 ) ;
  }

  @Test
  public void test48() {
    caldat.caldat(556 ) ;
  }

  @Test
  public void test49() {
    caldat.caldat(-57 ) ;
  }

  @Test
  public void test50() {
    caldat.caldat(60 ) ;
  }

  @Test
  public void test51() {
    caldat.caldat(6299 ) ;
  }

  @Test
  public void test52() {
    caldat.caldat(-648 ) ;
  }

  @Test
  public void test53() {
    caldat.caldat(6670 ) ;
  }

  @Test
  public void test54() {
    caldat.caldat(-669 ) ;
  }

  @Test
  public void test55() {
    caldat.caldat(6700 ) ;
  }

  @Test
  public void test56() {
    caldat.caldat(-677 ) ;
  }

  @Test
  public void test57() {
    caldat.caldat(-678 ) ;
  }

  @Test
  public void test58() {
    caldat.caldat(-693 ) ;
  }

  @Test
  public void test59() {
    caldat.caldat(-727 ) ;
  }

  @Test
  public void test60() {
    caldat.caldat(-728 ) ;
  }

  @Test
  public void test61() {
    caldat.caldat(76 ) ;
  }

  @Test
  public void test62() {
    caldat.caldat(763 ) ;
  }

  @Test
  public void test63() {
    caldat.caldat(773 ) ;
  }

  @Test
  public void test64() {
    caldat.caldat(777 ) ;
  }

  @Test
  public void test65() {
    caldat.caldat(780 ) ;
  }

  @Test
  public void test66() {
    caldat.caldat(786 ) ;
  }

  @Test
  public void test67() {
    caldat.caldat(790 ) ;
  }

  @Test
  public void test68() {
    caldat.caldat(827 ) ;
  }

  @Test
  public void test69() {
    caldat.caldat(858 ) ;
  }

  @Test
  public void test70() {
    caldat.caldat(-889 ) ;
  }

  @Test
  public void test71() {
    caldat.caldat(-90 ) ;
  }

  @Test
  public void test72() {
    caldat.caldat(90 ) ;
  }
}
