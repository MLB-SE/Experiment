import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,-1 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-304 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,571 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(0,0,67 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(1,0,0 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(-1000,-381,2513 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-1,0,-1 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-1,0,1 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(104,-498,-8 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(1,0,525 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-1054,865,1 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-1,1667,2195 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-11,692,822 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-117,0,0 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(1,17985,0 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-11,912,1 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-119,974,47 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-12,16695,1 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-12,19094,2 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(1,22047,2 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-1,22106,13 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-124,0,-13 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-12,523,1 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-129,0,12 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(-12,970,0 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-13,0,-1 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(-13,0,1 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-13,0,-1405 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-13,0,2 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-13,0,269 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(-13,0,774 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-13,0,-968 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(-13,1011,453 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(-13,-1081,556 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-13,1281,-1 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(-13,132,0 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-13,13,-945 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-13,14347,7 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-13,15452,2 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(-13,175,1 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(1318,-43,-1 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(-13,20162,-6 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(-13,20335,-1 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-13,2183,1889 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-13,-2329,1 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(-13,324,2 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(-13,-914,-512 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(14,0,1 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(-14,19422,0 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(14,20600,-1 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(14,22498,-9 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(1480,0,0 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(-15,18906,-2 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(-1,560,-1 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(-16,17811,6 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(-17,20975,3 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(176,-233,1 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(-18,20763,-36 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-184,0,0 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(185,854,780 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(190,0,0 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(19086,1973,-2 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(19139,1922,-4 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(19,16962,1 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(19172,1058,4 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(19205,611,-1 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(19381,352,-1 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(19412,118,-3 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(19466,-508,3 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(194,-868,1682 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(19,-513,0 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(19537,1351,0 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(19591,786,-6 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(195,983,-1 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(19683,1122,-21 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(2,0,0 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(-2,0,-1 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(-2,0,1 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(2,0,-1 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(-2,0,-1625 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(-2016,-396,1 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(-2,0,1744 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-2,0,-2 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-2,0,247 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(2,0,-252 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(-2,0,-614 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-2,0,67 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-2,1072,-1 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(211,0,-157 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-2,114,1860 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(-2,12,0 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(2,-1222,2 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(-2,12230,12 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-2,15611,-2 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(-2,-1603,0 ) ;
  }

  @Test
  public void test98() {
    caldat.julday(2,16410,0 ) ;
  }

  @Test
  public void test99() {
    caldat.julday(-2,16824,-3 ) ;
  }

  @Test
  public void test100() {
    caldat.julday(-2,17203,-1 ) ;
  }

  @Test
  public void test101() {
    caldat.julday(-2,18303,-2 ) ;
  }

  @Test
  public void test102() {
    caldat.julday(218,360,-2 ) ;
  }

  @Test
  public void test103() {
    caldat.julday(-222,0,-1 ) ;
  }

  @Test
  public void test104() {
    caldat.julday(-2,222,-891 ) ;
  }

  @Test
  public void test105() {
    caldat.julday(-2,2265,662 ) ;
  }

  @Test
  public void test106() {
    caldat.julday(-2,2282,-1 ) ;
  }

  @Test
  public void test107() {
    caldat.julday(-2,281,336 ) ;
  }

  @Test
  public void test108() {
    caldat.julday(-232,87,-739 ) ;
  }

  @Test
  public void test109() {
    caldat.julday(-2,398,2173 ) ;
  }

  @Test
  public void test110() {
    caldat.julday(-245,0,-998 ) ;
  }

  @Test
  public void test111() {
    caldat.julday(24,578,824 ) ;
  }

  @Test
  public void test112() {
    caldat.julday(-2,536,1 ) ;
  }

  @Test
  public void test113() {
    caldat.julday(-2,-575,-2 ) ;
  }

  @Test
  public void test114() {
    caldat.julday(-2,596,-1 ) ;
  }

  @Test
  public void test115() {
    caldat.julday(-2,-630,-321 ) ;
  }

  @Test
  public void test116() {
    caldat.julday(-27,19787,-8 ) ;
  }

  @Test
  public void test117() {
    caldat.julday(272,0,-1 ) ;
  }

  @Test
  public void test118() {
    caldat.julday(2,-731,1 ) ;
  }

  @Test
  public void test119() {
    caldat.julday(2,8469,10 ) ;
  }

  @Test
  public void test120() {
    caldat.julday(-284,877,-220 ) ;
  }

  @Test
  public void test121() {
    caldat.julday(285,0,-1 ) ;
  }

  @Test
  public void test122() {
    caldat.julday(-28,-864,0 ) ;
  }

  @Test
  public void test123() {
    caldat.julday(29,14126,0 ) ;
  }

  @Test
  public void test124() {
    caldat.julday(293,574,-18 ) ;
  }

  @Test
  public void test125() {
    caldat.julday(-2,-961,1 ) ;
  }

  @Test
  public void test126() {
    caldat.julday(-2,976,1749 ) ;
  }

  @Test
  public void test127() {
    caldat.julday(299,0,-856 ) ;
  }

  @Test
  public void test128() {
    caldat.julday(308,-397,0 ) ;
  }

  @Test
  public void test129() {
    caldat.julday(-3,0,-990 ) ;
  }

  @Test
  public void test130() {
    caldat.julday(-31,21979,17 ) ;
  }

  @Test
  public void test131() {
    caldat.julday(-3,16596,2 ) ;
  }

  @Test
  public void test132() {
    caldat.julday(-3,17061,1 ) ;
  }

  @Test
  public void test133() {
    caldat.julday(-3,17144,2 ) ;
  }

  @Test
  public void test134() {
    caldat.julday(-3,17791,0 ) ;
  }

  @Test
  public void test135() {
    caldat.julday(-3,18172,4 ) ;
  }

  @Test
  public void test136() {
    caldat.julday(-319,0,2 ) ;
  }

  @Test
  public void test137() {
    caldat.julday(-3,19279,7 ) ;
  }

  @Test
  public void test138() {
    caldat.julday(320,0,-844 ) ;
  }

  @Test
  public void test139() {
    caldat.julday(-3,20108,-1 ) ;
  }

  @Test
  public void test140() {
    caldat.julday(-3,20914,-1 ) ;
  }

  @Test
  public void test141() {
    caldat.julday(34,18835,4 ) ;
  }

  @Test
  public void test142() {
    caldat.julday(363,0,0 ) ;
  }

  @Test
  public void test143() {
    caldat.julday(365,0,1 ) ;
  }

  @Test
  public void test144() {
    caldat.julday(-368,-785,-1 ) ;
  }

  @Test
  public void test145() {
    caldat.julday(-3,835,-416 ) ;
  }

  @Test
  public void test146() {
    caldat.julday(389,0,0 ) ;
  }

  @Test
  public void test147() {
    caldat.julday(-393,0,-368 ) ;
  }

  @Test
  public void test148() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test149() {
    caldat.julday(4,0,-1 ) ;
  }

  @Test
  public void test150() {
    caldat.julday(4,0,1 ) ;
  }

  @Test
  public void test151() {
    caldat.julday(4,0,-1286 ) ;
  }

  @Test
  public void test152() {
    caldat.julday(4,0,-2 ) ;
  }

  @Test
  public void test153() {
    caldat.julday(4,0,212 ) ;
  }

  @Test
  public void test154() {
    caldat.julday(-40,21536,2 ) ;
  }

  @Test
  public void test155() {
    caldat.julday(4,0,2722 ) ;
  }

  @Test
  public void test156() {
    caldat.julday(4,0,-317 ) ;
  }

  @Test
  public void test157() {
    caldat.julday(4,-110,579 ) ;
  }

  @Test
  public void test158() {
    caldat.julday(4,1294,-828 ) ;
  }

  @Test
  public void test159() {
    caldat.julday(-415,0,2 ) ;
  }

  @Test
  public void test160() {
    caldat.julday(4,-1583,-1 ) ;
  }

  @Test
  public void test161() {
    caldat.julday(4,16604,-2 ) ;
  }

  @Test
  public void test162() {
    caldat.julday(4,-1720,1 ) ;
  }

  @Test
  public void test163() {
    caldat.julday(4,179,-1 ) ;
  }

  @Test
  public void test164() {
    caldat.julday(4,18085,2 ) ;
  }

  @Test
  public void test165() {
    caldat.julday(-420,0,0 ) ;
  }

  @Test
  public void test166() {
    caldat.julday(4,20371,-11 ) ;
  }

  @Test
  public void test167() {
    caldat.julday(-42,17981,-8 ) ;
  }

  @Test
  public void test168() {
    caldat.julday(4,-283,-2 ) ;
  }

  @Test
  public void test169() {
    caldat.julday(4,-297,2303 ) ;
  }

  @Test
  public void test170() {
    caldat.julday(-43,15849,-2 ) ;
  }

  @Test
  public void test171() {
    caldat.julday(431,610,1556 ) ;
  }

  @Test
  public void test172() {
    caldat.julday(-435,-605,1664 ) ;
  }

  @Test
  public void test173() {
    caldat.julday(4,356,-221 ) ;
  }

  @Test
  public void test174() {
    caldat.julday(-438,0,1 ) ;
  }

  @Test
  public void test175() {
    caldat.julday(44,0,1 ) ;
  }

  @Test
  public void test176() {
    caldat.julday(4,402,0 ) ;
  }

  @Test
  public void test177() {
    caldat.julday(4,428,1 ) ;
  }

  @Test
  public void test178() {
    caldat.julday(4,460,-1 ) ;
  }

  @Test
  public void test179() {
    caldat.julday(-48,0,-1 ) ;
  }

  @Test
  public void test180() {
    caldat.julday(4,844,2984 ) ;
  }

  @Test
  public void test181() {
    caldat.julday(496,0,-1 ) ;
  }

  @Test
  public void test182() {
    caldat.julday(-5,0,1 ) ;
  }

  @Test
  public void test183() {
    caldat.julday(508,0,-1 ) ;
  }

  @Test
  public void test184() {
    caldat.julday(-518,0,-277 ) ;
  }

  @Test
  public void test185() {
    caldat.julday(-520,0,0 ) ;
  }

  @Test
  public void test186() {
    caldat.julday(-5,21692,-12 ) ;
  }

  @Test
  public void test187() {
    caldat.julday(-524,-109,-1 ) ;
  }

  @Test
  public void test188() {
    caldat.julday(-53,17758,-5 ) ;
  }

  @Test
  public void test189() {
    caldat.julday(539,0,793 ) ;
  }

  @Test
  public void test190() {
    caldat.julday(543,532,1 ) ;
  }

  @Test
  public void test191() {
    caldat.julday(-568,587,609 ) ;
  }

  @Test
  public void test192() {
    caldat.julday(-58,577,1656 ) ;
  }

  @Test
  public void test193() {
    caldat.julday(588,-737,-261 ) ;
  }

  @Test
  public void test194() {
    caldat.julday(-589,265,0 ) ;
  }

  @Test
  public void test195() {
    caldat.julday(-60,0,-1 ) ;
  }

  @Test
  public void test196() {
    caldat.julday(60,0,852 ) ;
  }

  @Test
  public void test197() {
    caldat.julday(601,0,380 ) ;
  }

  @Test
  public void test198() {
    caldat.julday(-6,0,2 ) ;
  }

  @Test
  public void test199() {
    caldat.julday(-618,0,805 ) ;
  }

  @Test
  public void test200() {
    caldat.julday(-6,19883,-2 ) ;
  }

  @Test
  public void test201() {
    caldat.julday(-6,21630,-1 ) ;
  }

  @Test
  public void test202() {
    caldat.julday(622,0,0 ) ;
  }

  @Test
  public void test203() {
    caldat.julday(-627,0,-164 ) ;
  }

  @Test
  public void test204() {
    caldat.julday(655,0,-2 ) ;
  }

  @Test
  public void test205() {
    caldat.julday(-656,0,1 ) ;
  }

  @Test
  public void test206() {
    caldat.julday(-6,630,85 ) ;
  }

  @Test
  public void test207() {
    caldat.julday(681,-139,-5 ) ;
  }

  @Test
  public void test208() {
    caldat.julday(-699,0,1 ) ;
  }

  @Test
  public void test209() {
    caldat.julday(-710,0,1 ) ;
  }

  @Test
  public void test210() {
    caldat.julday(718,0,1 ) ;
  }

  @Test
  public void test211() {
    caldat.julday(-725,0,0 ) ;
  }

  @Test
  public void test212() {
    caldat.julday(-735,11,1 ) ;
  }

  @Test
  public void test213() {
    caldat.julday(-745,0,1 ) ;
  }

  @Test
  public void test214() {
    caldat.julday(-748,-300,1789 ) ;
  }

  @Test
  public void test215() {
    caldat.julday(-753,109,0 ) ;
  }

  @Test
  public void test216() {
    caldat.julday(-7,-675,-1 ) ;
  }

  @Test
  public void test217() {
    caldat.julday(-786,-632,2 ) ;
  }

  @Test
  public void test218() {
    caldat.julday(-793,0,-1 ) ;
  }

  @Test
  public void test219() {
    caldat.julday(-8,0,1 ) ;
  }

  @Test
  public void test220() {
    caldat.julday(-807,0,0 ) ;
  }

  @Test
  public void test221() {
    caldat.julday(-8,-1017,0 ) ;
  }

  @Test
  public void test222() {
    caldat.julday(-8,18936,0 ) ;
  }

  @Test
  public void test223() {
    caldat.julday(833,0,-429 ) ;
  }

  @Test
  public void test224() {
    caldat.julday(837,0,907 ) ;
  }

  @Test
  public void test225() {
    caldat.julday(838,-934,714 ) ;
  }

  @Test
  public void test226() {
    caldat.julday(-8,-624,-1 ) ;
  }

  @Test
  public void test227() {
    caldat.julday(-873,0,325 ) ;
  }

  @Test
  public void test228() {
    caldat.julday(884,0,-1 ) ;
  }

  @Test
  public void test229() {
    caldat.julday(897,0,-2 ) ;
  }

  @Test
  public void test230() {
    caldat.julday(898,0,-1 ) ;
  }

  @Test
  public void test231() {
    caldat.julday(9,15385,-1 ) ;
  }

  @Test
  public void test232() {
    caldat.julday(9,16342,-7 ) ;
  }

  @Test
  public void test233() {
    caldat.julday(-92,-841,1 ) ;
  }

  @Test
  public void test234() {
    caldat.julday(-94,0,912 ) ;
  }

  @Test
  public void test235() {
    caldat.julday(944,0,0 ) ;
  }

  @Test
  public void test236() {
    caldat.julday(968,0,-361 ) ;
  }

  @Test
  public void test237() {
    caldat.julday(-9,-75,-661 ) ;
  }

  @Test
  public void test238() {
    caldat.julday(977,0,711 ) ;
  }

  @Test
  public void test239() {
    caldat.julday(988,0,1 ) ;
  }

  @Test
  public void test240() {
    caldat.julday(-990,0,1 ) ;
  }

  @Test
  public void test241() {
    caldat.julday(-993,0,51 ) ;
  }
}
