import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,1.232595164407831E-32 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,1.5407439555097887E-33 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(0,2.0 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(0,2.000000000065598 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(0,2.220446049250313E-16 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(0,48.00296415491104 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(0,49.43545223907785 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(0,-5.421010862427522E-20 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(0,63.818369159450924 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(0,6.688128923900166 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(-1,0.0 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(108,4.930380657631324E-32 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(-1,1.7870385667227282 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(-1,2.0 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(-1,2.0000000000000004 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(-1,2.000000000018096 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(1226,2.0000000000000004 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(-1,33.72357880980593 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-1,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(141,2.0000000000000004 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-15,0.0 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(-1,80.50173619104322 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(-208,0.0 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(-2,1.329225760356406E-16 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-2,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-2,-2.6469779601696886E-23 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(229,-84.57678751821484 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(252,1.7763568394002505E-15 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(253,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(-3072,2.0000000000000004 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(318,6.755501617372739E-16 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(321,-87.36552391289854 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(328,-3.0E-323 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(-373,-2.220446049250313E-16 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(396,3.469446951953614E-18 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(413,0 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(418,0.0 ) ;
  }

  @Test
  public void test38() {
    airy.sphbes(457,55.23133796438714 ) ;
  }

  @Test
  public void test39() {
    airy.sphbes(-458,2.0000000000000004 ) ;
  }

  @Test
  public void test40() {
    airy.sphbes(460,4.0E-323 ) ;
  }

  @Test
  public void test41() {
    airy.sphbes(469,2.0000000000000386 ) ;
  }

  @Test
  public void test42() {
    airy.sphbes(47,9.860761315262648E-32 ) ;
  }

  @Test
  public void test43() {
    airy.sphbes(-484,-1.1102230246251565E-16 ) ;
  }

  @Test
  public void test44() {
    airy.sphbes(-493,15.789045300954399 ) ;
  }

  @Test
  public void test45() {
    airy.sphbes(-4933,2.000000000000057 ) ;
  }

  @Test
  public void test46() {
    airy.sphbes(-496,0.4780941347102754 ) ;
  }

  @Test
  public void test47() {
    airy.sphbes(501,-84.1977028712488 ) ;
  }

  @Test
  public void test48() {
    airy.sphbes(509,-6.9E-323 ) ;
  }

  @Test
  public void test49() {
    airy.sphbes(-529,-36.952646079526154 ) ;
  }

  @Test
  public void test50() {
    airy.sphbes(-536,3.4765393723108673 ) ;
  }

  @Test
  public void test51() {
    airy.sphbes(575,4.4E-323 ) ;
  }

  @Test
  public void test52() {
    airy.sphbes(58,-4.9E-324 ) ;
  }

  @Test
  public void test53() {
    airy.sphbes(-606,2.0 ) ;
  }

  @Test
  public void test54() {
    airy.sphbes(609,-8.673617379884035E-19 ) ;
  }

  @Test
  public void test55() {
    airy.sphbes(-616,53.275538444889094 ) ;
  }

  @Test
  public void test56() {
    airy.sphbes(-646,0.0 ) ;
  }

  @Test
  public void test57() {
    airy.sphbes(672,79.09571138010008 ) ;
  }

  @Test
  public void test58() {
    airy.sphbes(-730,-2.7755575615628914E-17 ) ;
  }

  @Test
  public void test59() {
    airy.sphbes(739,9.4E-323 ) ;
  }

  @Test
  public void test60() {
    airy.sphbes(-744,0.0 ) ;
  }

  @Test
  public void test61() {
    airy.sphbes(763,1.43E-322 ) ;
  }

  @Test
  public void test62() {
    airy.sphbes(-769,-87.0976429829717 ) ;
  }

  @Test
  public void test63() {
    airy.sphbes(818,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test64() {
    airy.sphbes(862,2.0000000000000004 ) ;
  }

  @Test
  public void test65() {
    airy.sphbes(864,-1.0842021724855044E-19 ) ;
  }

  @Test
  public void test66() {
    airy.sphbes(916,-3.2379E-319 ) ;
  }

  @Test
  public void test67() {
    airy.sphbes(-938,0 ) ;
  }

  @Test
  public void test68() {
    airy.sphbes(944,0.0 ) ;
  }

  @Test
  public void test69() {
    airy.sphbes(952,-2.1684043449710089E-19 ) ;
  }

  @Test
  public void test70() {
    airy.sphbes(954,1.5648446121212286E-16 ) ;
  }

  @Test
  public void test71() {
    airy.sphbes(962,0.0 ) ;
  }

  @Test
  public void test72() {
    airy.sphbes(98,-3.469446951953614E-18 ) ;
  }

  @Test
  public void test73() {
    airy.sphbes(984,29.93109580394696 ) ;
  }
}
