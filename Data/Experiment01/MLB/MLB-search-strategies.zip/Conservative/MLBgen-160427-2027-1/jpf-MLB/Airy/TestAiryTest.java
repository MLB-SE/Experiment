import org.junit.Test;

public class TestAiryTest {

  @Test
  public void test0() {
    airy.main_airy(0.0 ) ;
  }

  @Test
  public void test1() {
    airy.main_airy(0.001555732230052351 ) ;
  }

  @Test
  public void test2() {
    airy.main_airy(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3() {
    airy.main_airy(11.585722235194055 ) ;
  }

  @Test
  public void test4() {
    airy.main_airy(-1.2179414521290823 ) ;
  }

  @Test
  public void test5() {
    airy.main_airy(-1.232595164407831E-32 ) ;
  }

  @Test
  public void test6() {
    airy.main_airy(1.232595164407831E-32 ) ;
  }

  @Test
  public void test7() {
    airy.main_airy(-12.616966033201862 ) ;
  }

  @Test
  public void test8() {
    airy.main_airy(1.5573742111089916E-207 ) ;
  }

  @Test
  public void test9() {
    airy.main_airy(16.19252429041289 ) ;
  }

  @Test
  public void test10() {
    airy.main_airy(2.172649641381682 ) ;
  }

  @Test
  public void test11() {
    airy.main_airy(23.342605193374837 ) ;
  }

  @Test
  public void test12() {
    airy.main_airy(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test13() {
    airy.main_airy(2.465190328815662E-32 ) ;
  }

  @Test
  public void test14() {
    airy.main_airy(-25.509918810233543 ) ;
  }

  @Test
  public void test15() {
    airy.main_airy(-2.7016136048916335E-225 ) ;
  }

  @Test
  public void test16() {
    airy.main_airy(3.0814879110195774E-33 ) ;
  }

  @Test
  public void test17() {
    airy.main_airy(-3.4352615445959E-208 ) ;
  }

  @Test
  public void test18() {
    airy.main_airy(3.469446951953614E-18 ) ;
  }

  @Test
  public void test19() {
    airy.main_airy(3.506894958413445E-192 ) ;
  }

  @Test
  public void test20() {
    airy.main_airy(-4.2873840888449735 ) ;
  }

  @Test
  public void test21() {
    airy.main_airy(4.3225817678266135E-224 ) ;
  }

  @Test
  public void test22() {
    airy.main_airy(4.4296242762058995 ) ;
  }

  @Test
  public void test23() {
    airy.main_airy(4.49529065857115 ) ;
  }

  @Test
  public void test24() {
    airy.main_airy(4.7580600594348255 ) ;
  }

  @Test
  public void test25() {
    airy.main_airy(-4.930380657631324E-32 ) ;
  }

  @Test
  public void test26() {
    airy.main_airy(4.930380657631324E-32 ) ;
  }

  @Test
  public void test27() {
    airy.main_airy(-5.551115123125783E-17 ) ;
  }

  @Test
  public void test28() {
    airy.main_airy(5.551115123125783E-17 ) ;
  }

  @Test
  public void test29() {
    airy.main_airy(6.162975822039155E-33 ) ;
  }

  @Test
  public void test30() {
    airy.main_airy(-6.307387246171231 ) ;
  }

  @Test
  public void test31() {
    airy.main_airy(-72.99950087448299 ) ;
  }

  @Test
  public void test32() {
    airy.main_airy(-7.309317055614343 ) ;
  }

  @Test
  public void test33() {
    airy.main_airy(-76.93955146460769 ) ;
  }

  @Test
  public void test34() {
    airy.main_airy(-82.82980692659547 ) ;
  }

  @Test
  public void test35() {
    airy.main_airy(-82.9013821041636 ) ;
  }

  @Test
  public void test36() {
    airy.main_airy(-8.767237396033612E-193 ) ;
  }

  @Test
  public void test37() {
    airy.main_airy(-8.881784197001252E-16 ) ;
  }

  @Test
  public void test38() {
    airy.main_airy(8.881784197001252E-16 ) ;
  }

  @Test
  public void test39() {
    airy.main_airy(92.42342307402157 ) ;
  }

  @Test
  public void test40() {
    airy.main_airy(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test41() {
    airy.main_airy(9.860761315262648E-32 ) ;
  }
}
