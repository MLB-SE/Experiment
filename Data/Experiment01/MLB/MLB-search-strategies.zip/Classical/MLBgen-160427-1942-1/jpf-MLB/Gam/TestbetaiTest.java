import org.junit.Test;

public class TestbetaiTest {

  @Test
  public void test0() {
    beta.betai(0,0,0.2781522368634337 ) ;
  }

  @Test
  public void test1() {
    beta.betai(0,0,0.3357487455468515 ) ;
  }

  @Test
  public void test2() {
    beta.betai(0,0,0.4643366227775203 ) ;
  }

  @Test
  public void test3() {
    beta.betai(0,0,0.6922384854532737 ) ;
  }

  @Test
  public void test4() {
    beta.betai(0,0,0.998612579195111 ) ;
  }

  @Test
  public void test5() {
    beta.betai(0,0,0.9999999999999996 ) ;
  }

  @Test
  public void test6() {
    beta.betai(0,0,0.9999999999999998 ) ;
  }

  @Test
  public void test7() {
    beta.betai(0,0,1.0 ) ;
  }

  @Test
  public void test8() {
    beta.betai(0,0,1.0000000000000002 ) ;
  }

  @Test
  public void test9() {
    beta.betai(0,0,1.0000000000000009 ) ;
  }

  @Test
  public void test10() {
    beta.betai(0,0,1.0000000000000018 ) ;
  }

  @Test
  public void test11() {
    beta.betai(0,0,1.0000291500356095 ) ;
  }

  @Test
  public void test12() {
    beta.betai(0,0,-10.468025609526464 ) ;
  }

  @Test
  public void test13() {
    beta.betai(0,0,1.1102230246251565E-16 ) ;
  }

  @Test
  public void test14() {
    beta.betai(0,0,11.788413981293928 ) ;
  }

  @Test
  public void test15() {
    beta.betai(0,0,-14.163997703121026 ) ;
  }

  @Test
  public void test16() {
    beta.betai(0,0,-20.763565795760357 ) ;
  }

  @Test
  public void test17() {
    beta.betai(0,0,-3.0814879110195774E-33 ) ;
  }

  @Test
  public void test18() {
    beta.betai(0,0,-3.419713561852973 ) ;
  }

  @Test
  public void test19() {
    beta.betai(0,0,4.440892098500626E-16 ) ;
  }

  @Test
  public void test20() {
    beta.betai(0,0,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test21() {
    beta.betai(0,0,-5.980274549627708 ) ;
  }

  @Test
  public void test22() {
    beta.betai(0,0,6.3895115089040075 ) ;
  }

  @Test
  public void test23() {
    beta.betai(0,0,74.00128646561271 ) ;
  }

  @Test
  public void test24() {
    beta.betai(0,0,9.308078298292344 ) ;
  }

  @Test
  public void test25() {
    beta.betai(0,0,97.51208757929072 ) ;
  }

  @Test
  public void test26() {
    beta.betai(0,0,9.860761315262648E-32 ) ;
  }
}
