import org.junit.Test;

public class TestbicoTest {

  @Test
  public void test0() {
    gam.bico(0,-1 ) ;
  }

  @Test
  public void test1() {
    gam.bico(0,1 ) ;
  }

  @Test
  public void test2() {
    gam.bico(0,-569 ) ;
  }

  @Test
  public void test3() {
    gam.bico(0,58 ) ;
  }

  @Test
  public void test4() {
    gam.bico(0,-984 ) ;
  }

  @Test
  public void test5() {
    gam.bico(1,0 ) ;
  }

  @Test
  public void test6() {
    gam.bico(1000,0 ) ;
  }

  @Test
  public void test7() {
    gam.bico(-127,0 ) ;
  }

  @Test
  public void test8() {
    gam.bico(1,570 ) ;
  }

  @Test
  public void test9() {
    gam.bico(-19,-511 ) ;
  }

  @Test
  public void test10() {
    gam.bico(-197,236 ) ;
  }

  @Test
  public void test11() {
    gam.bico(2,0 ) ;
  }

  @Test
  public void test12() {
    gam.bico(-320,2 ) ;
  }

  @Test
  public void test13() {
    gam.bico(367,0 ) ;
  }

  @Test
  public void test14() {
    gam.bico(474,0 ) ;
  }

  @Test
  public void test15() {
    gam.bico(-508,0 ) ;
  }

  @Test
  public void test16() {
    gam.bico(55,0 ) ;
  }

  @Test
  public void test17() {
    gam.bico(-819,-771 ) ;
  }

  @Test
  public void test18() {
    gam.bico(-85,0 ) ;
  }

  @Test
  public void test19() {
    gam.bico(-998,904 ) ;
  }
}
