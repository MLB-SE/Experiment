import org.junit.Test;

public class TesterffcTest {

  @Test
  public void test0() {
    gam.erffc(0.48032565803988947 ) ;
  }

  @Test
  public void test1() {
    gam.erffc(0.9315055488519937 ) ;
  }

  @Test
  public void test2() {
    gam.erffc(-1.069301462436958 ) ;
  }

  @Test
  public void test3() {
    gam.erffc(-1.224073252428644 ) ;
  }

  @Test
  public void test4() {
    gam.erffc(-1.2247448713915892 ) ;
  }

  @Test
  public void test5() {
    gam.erffc(1.2247448713915892 ) ;
  }

  @Test
  public void test6() {
    gam.erffc(1.2634920662350609E-175 ) ;
  }

  @Test
  public void test7() {
    gam.erffc(-1.3877787807814457E-17 ) ;
  }

  @Test
  public void test8() {
    gam.erffc(-1.422808795731072 ) ;
  }

  @Test
  public void test9() {
    gam.erffc(14.319424104324014 ) ;
  }

  @Test
  public void test10() {
    gam.erffc(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test11() {
    gam.erffc(2.220446049250313E-16 ) ;
  }

  @Test
  public void test12() {
    gam.erffc(2.4384198533773542 ) ;
  }

  @Test
  public void test13() {
    gam.erffc(-4.440892098500626E-16 ) ;
  }

  @Test
  public void test14() {
    gam.erffc(4.440892098500626E-16 ) ;
  }

  @Test
  public void test15() {
    gam.erffc(49.73175012391789 ) ;
  }

  @Test
  public void test16() {
    gam.erffc(-5.0539682649402436E-175 ) ;
  }

  @Test
  public void test17() {
    gam.erffc(-93.02975174337473 ) ;
  }

  @Test
  public void test18() {
    gam.erffc(97.79587258920023 ) ;
  }

  @Test
  public void test19() {
    gam.erffc(-9.860761315262648E-32 ) ;
  }

  @Test
  public void test20() {
    gam.erffc(-99.7519529805298 ) ;
  }
}
