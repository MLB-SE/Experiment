import org.junit.Test;

public class TestexpintTest {

  @Test
  public void test0() {
    expint.expint(0,0.0 ) ;
  }

  @Test
  public void test1() {
    expint.expint(0,74.91051876327137 ) ;
  }

  @Test
  public void test2() {
    expint.expint(-102,0 ) ;
  }

  @Test
  public void test3() {
    expint.expint(1171,0.0 ) ;
  }

  @Test
  public void test4() {
    expint.expint(1196,-3.5E-323 ) ;
  }

  @Test
  public void test5() {
    expint.expint(211,6.9E-323 ) ;
  }

  @Test
  public void test6() {
    expint.expint(278,4.930380657631324E-32 ) ;
  }

  @Test
  public void test7() {
    expint.expint(292,0.0 ) ;
  }

  @Test
  public void test8() {
    expint.expint(533,0.0 ) ;
  }

  @Test
  public void test9() {
    expint.expint(6,36.08826569769306 ) ;
  }

  @Test
  public void test10() {
    expint.expint(663,88.65794312865856 ) ;
  }

  @Test
  public void test11() {
    expint.expint(777,1.24E-322 ) ;
  }

  @Test
  public void test12() {
    expint.expint(862,0 ) ;
  }

  @Test
  public void test13() {
    expint.expint(900,5.249112522673855 ) ;
  }

  @Test
  public void test14() {
    expint.expint(961,-89.71837890766756 ) ;
  }
}
