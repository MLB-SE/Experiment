import org.junit.Test;

public class TestfactrlTest {

  @Test
  public void test0() {
    gam.factrl(0 ) ;
  }

  @Test
  public void test1() {
    gam.factrl(-1 ) ;
  }

  @Test
  public void test2() {
    gam.factrl(11 ) ;
  }

  @Test
  public void test3() {
    gam.factrl(-129 ) ;
  }

  @Test
  public void test4() {
    gam.factrl(23 ) ;
  }

  @Test
  public void test5() {
    gam.factrl(409 ) ;
  }

  @Test
  public void test6() {
    gam.factrl(-61 ) ;
  }

  @Test
  public void test7() {
    gam.factrl(-678 ) ;
  }

  @Test
  public void test8() {
    gam.factrl(725 ) ;
  }

  @Test
  public void test9() {
    gam.factrl(769 ) ;
  }
}
