import org.junit.Test;

public class TestbessyTest {

  @Test
  public void test0() {
    bess.bessy(368,79.0137766258012 ) ;
  }

  @Test
  public void test1() {
    bess.bessy(-456,0 ) ;
  }

  @Test
  public void test2() {
    bess.bessy(-543,96.78335164466395 ) ;
  }

  @Test
  public void test3() {
    bess.bessy(630,4.078420016190279 ) ;
  }

  @Test
  public void test4() {
    bess.bessy(676,-23.357131344206735 ) ;
  }

  @Test
  public void test5() {
    bess.bessy(-712,0.0 ) ;
  }

  @Test
  public void test6() {
    bess.bessy(734,0 ) ;
  }

  @Test
  public void test7() {
    bess.bessy(776,0.0 ) ;
  }

  @Test
  public void test8() {
    bess.bessy(-791,-53.5256099905816 ) ;
  }

  @Test
  public void test9() {
    bess.bessy(-848,8.0 ) ;
  }

  @Test
  public void test10() {
    bess.bessy(900,8.0 ) ;
  }

  @Test
  public void test11() {
    bess.bessy(-95,-27.596866488962206 ) ;
  }
}
