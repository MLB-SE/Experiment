import org.junit.Test;

public class TestdawsonTest {

  @Test
  public void test0() {
    dawson.dawson(0.10103644384389937 ) ;
  }

  @Test
  public void test1() {
    dawson.dawson(-0.19999999999999996 ) ;
  }

  @Test
  public void test2() {
    dawson.dawson(-0.20000000000000018 ) ;
  }

  @Test
  public void test3() {
    dawson.dawson(0.20000000000000018 ) ;
  }

  @Test
  public void test4() {
    dawson.dawson(-0.39999999999999997 ) ;
  }

  @Test
  public void test5() {
    dawson.dawson(0.39999999999999997 ) ;
  }

  @Test
  public void test6() {
    dawson.dawson(-0.4 ) ;
  }

  @Test
  public void test7() {
    dawson.dawson(0.4000000000000155 ) ;
  }

  @Test
  public void test8() {
    dawson.dawson(-0.42988975502960614 ) ;
  }

  @Test
  public void test9() {
    dawson.dawson(-0.45189331132663746 ) ;
  }

  @Test
  public void test10() {
    dawson.dawson(0.45513825123574314 ) ;
  }

  @Test
  public void test11() {
    dawson.dawson(-0.46152987845562343 ) ;
  }

  @Test
  public void test12() {
    dawson.dawson(-0.468318586506113 ) ;
  }

  @Test
  public void test13() {
    dawson.dawson(0.48803935570665935 ) ;
  }

  @Test
  public void test14() {
    dawson.dawson(0.5308692120389813 ) ;
  }

  @Test
  public void test15() {
    dawson.dawson(0.6391574588126936 ) ;
  }

  @Test
  public void test16() {
    dawson.dawson(0.6938701315730063 ) ;
  }

  @Test
  public void test17() {
    dawson.dawson(-0.7581530230350841 ) ;
  }

  @Test
  public void test18() {
    dawson.dawson(0.7999999999999996 ) ;
  }

  @Test
  public void test19() {
    dawson.dawson(-0.7999999999999998 ) ;
  }

  @Test
  public void test20() {
    dawson.dawson(0.7999999999999999 ) ;
  }

  @Test
  public void test21() {
    dawson.dawson(0.8465285592605838 ) ;
  }

  @Test
  public void test22() {
    dawson.dawson(-0.9839394812502702 ) ;
  }

  @Test
  public void test23() {
    dawson.dawson(-11.91032604465667 ) ;
  }

  @Test
  public void test24() {
    dawson.dawson(13.867970361680278 ) ;
  }

  @Test
  public void test25() {
    dawson.dawson(-1.5999999999999999 ) ;
  }

  @Test
  public void test26() {
    dawson.dawson(1.7326140668367822 ) ;
  }

  @Test
  public void test27() {
    dawson.dawson(-1.7990441556183476 ) ;
  }

  @Test
  public void test28() {
    dawson.dawson(-18.72251963099845 ) ;
  }

  @Test
  public void test29() {
    dawson.dawson(-20.225860585026552 ) ;
  }

  @Test
  public void test30() {
    dawson.dawson(-21.373358311150923 ) ;
  }

  @Test
  public void test31() {
    dawson.dawson(-2.554644194086047 ) ;
  }

  @Test
  public void test32() {
    dawson.dawson(2.612245674686136 ) ;
  }

  @Test
  public void test33() {
    dawson.dawson(2.652902615778004 ) ;
  }

  @Test
  public void test34() {
    dawson.dawson(27.07803364983114 ) ;
  }

  @Test
  public void test35() {
    dawson.dawson(-27.487998944150107 ) ;
  }

  @Test
  public void test36() {
    dawson.dawson(2.768492991237782 ) ;
  }

  @Test
  public void test37() {
    dawson.dawson(-3.285403586617334 ) ;
  }

  @Test
  public void test38() {
    dawson.dawson(35.931323728791085 ) ;
  }

  @Test
  public void test39() {
    dawson.dawson(3.596568481308141 ) ;
  }

  @Test
  public void test40() {
    dawson.dawson(3.6050666479668507 ) ;
  }

  @Test
  public void test41() {
    dawson.dawson(36.79131228919661 ) ;
  }

  @Test
  public void test42() {
    dawson.dawson(-40.76198348370417 ) ;
  }

  @Test
  public void test43() {
    dawson.dawson(4.115726730145763 ) ;
  }

  @Test
  public void test44() {
    dawson.dawson(-4.147239574265096 ) ;
  }

  @Test
  public void test45() {
    dawson.dawson(-41.851218732572406 ) ;
  }

  @Test
  public void test46() {
    dawson.dawson(44.307962293179 ) ;
  }

  @Test
  public void test47() {
    dawson.dawson(4.4448313023504085 ) ;
  }

  @Test
  public void test48() {
    dawson.dawson(-49.052551724187744 ) ;
  }

  @Test
  public void test49() {
    dawson.dawson(49.27854092836441 ) ;
  }

  @Test
  public void test50() {
    dawson.dawson(-52.27729155526579 ) ;
  }

  @Test
  public void test51() {
    dawson.dawson(53.19477308097487 ) ;
  }

  @Test
  public void test52() {
    dawson.dawson(-55.241056716760475 ) ;
  }

  @Test
  public void test53() {
    dawson.dawson(56.527748321639706 ) ;
  }

  @Test
  public void test54() {
    dawson.dawson(57.34017186015126 ) ;
  }

  @Test
  public void test55() {
    dawson.dawson(-59.52335437778791 ) ;
  }

  @Test
  public void test56() {
    dawson.dawson(-6.03548334994673 ) ;
  }

  @Test
  public void test57() {
    dawson.dawson(-6.053550773446716 ) ;
  }

  @Test
  public void test58() {
    dawson.dawson(65.26748526120784 ) ;
  }

  @Test
  public void test59() {
    dawson.dawson(66.34047699359601 ) ;
  }

  @Test
  public void test60() {
    dawson.dawson(67.46739788094223 ) ;
  }

  @Test
  public void test61() {
    dawson.dawson(76.2153886141341 ) ;
  }

  @Test
  public void test62() {
    dawson.dawson(-77.4938524272522 ) ;
  }

  @Test
  public void test63() {
    dawson.dawson(-81.67180736042683 ) ;
  }

  @Test
  public void test64() {
    dawson.dawson(82.92596943565579 ) ;
  }

  @Test
  public void test65() {
    dawson.dawson(-84.03603421206486 ) ;
  }

  @Test
  public void test66() {
    dawson.dawson(-84.7175886646154 ) ;
  }

  @Test
  public void test67() {
    dawson.dawson(85.24216908167529 ) ;
  }

  @Test
  public void test68() {
    dawson.dawson(86.43228084639017 ) ;
  }

  @Test
  public void test69() {
    dawson.dawson(-90.0787907874494 ) ;
  }
}
