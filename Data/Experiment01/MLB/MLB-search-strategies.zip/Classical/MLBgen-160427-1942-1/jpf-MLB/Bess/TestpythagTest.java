import org.junit.Test;

public class TestpythagTest {

  @Test
  public void test0() {
    dawson.pythag(0.02138975042571925,0.021390110699635194 ) ;
  }

  @Test
  public void test1() {
    dawson.pythag(0.060915950949566915,0.06091877176229944 ) ;
  }

  @Test
  public void test2() {
    dawson.pythag(-0.7423103913613289,0.7423103913613289 ) ;
  }

  @Test
  public void test3() {
    dawson.pythag(1.0891064199586964,23.646695325085872 ) ;
  }

  @Test
  public void test4() {
    dawson.pythag(-1.0E-323,0.0 ) ;
  }

  @Test
  public void test5() {
    dawson.pythag(11.661677848878767,77.68623698530547 ) ;
  }

  @Test
  public void test6() {
    dawson.pythag(-12.307040709361033,0 ) ;
  }

  @Test
  public void test7() {
    dawson.pythag(1.3552527156068805E-20,-8.470329472543003E-22 ) ;
  }

  @Test
  public void test8() {
    dawson.pythag(-1.3877787807814457E-17,-0.01109623117300726 ) ;
  }

  @Test
  public void test9() {
    dawson.pythag(-1.3877787807814457E-17,2.0816681711721685E-17 ) ;
  }

  @Test
  public void test10() {
    dawson.pythag(-15.58542627554094,-15.58542627554094 ) ;
  }

  @Test
  public void test11() {
    dawson.pythag(1.5793650827938261E-176,-1.5793650827938261E-176 ) ;
  }

  @Test
  public void test12() {
    dawson.pythag(1.5793650827938261E-176,1.5793650827938261E-176 ) ;
  }

  @Test
  public void test13() {
    dawson.pythag(1.6370404527291505E-33,1.5407439555097887E-33 ) ;
  }

  @Test
  public void test14() {
    dawson.pythag(1.6543612251060553E-24,-1.6543643805496762E-24 ) ;
  }

  @Test
  public void test15() {
    dawson.pythag(1.7534474792067224E-192,-1.7534474792067224E-192 ) ;
  }

  @Test
  public void test16() {
    dawson.pythag(-1.7534474792067224E-192,1.9467177638862437E-208 ) ;
  }

  @Test
  public void test17() {
    dawson.pythag(17.67207448190471,-17.67207448190471 ) ;
  }

  @Test
  public void test18() {
    dawson.pythag(-1.9259299443872359E-34,1.9259301739759762E-34 ) ;
  }

  @Test
  public void test19() {
    dawson.pythag(-2.0E-323,0.0 ) ;
  }

  @Test
  public void test20() {
    dawson.pythag(-2.1084395886461046E-81,1.5623219933292265E-66 ) ;
  }

  @Test
  public void test21() {
    dawson.pythag(2.1175823681357508E-22,4.930380657631324E-32 ) ;
  }

  @Test
  public void test22() {
    dawson.pythag(21.21539099253569,21.21539099253569 ) ;
  }

  @Test
  public void test23() {
    dawson.pythag(2.1382117650983773E-50,-2.1382117650965955E-50 ) ;
  }

  @Test
  public void test24() {
    dawson.pythag(-2.1684043449710089E-19,1.6940658945086007E-21 ) ;
  }

  @Test
  public void test25() {
    dawson.pythag(-23.114255864254503,-0.6913212842675875 ) ;
  }

  @Test
  public void test26() {
    dawson.pythag(24.18012250326204,0.0 ) ;
  }

  @Test
  public void test27() {
    dawson.pythag(24.851410386231805,-73.39248093485394 ) ;
  }

  @Test
  public void test28() {
    dawson.pythag(2.5E-323,0.0 ) ;
  }

  @Test
  public void test29() {
    dawson.pythag(-2.805515966730756E-191,3.11474842221799E-207 ) ;
  }

  @Test
  public void test30() {
    dawson.pythag(-28.566213872079786,65.74450741623119 ) ;
  }

  @Test
  public void test31() {
    dawson.pythag(-3.691037826509492E-5,3.6910183640092645E-5 ) ;
  }

  @Test
  public void test32() {
    dawson.pythag(-38.22670293051469,-78.32447734816839 ) ;
  }

  @Test
  public void test33() {
    dawson.pythag(39.54029451438279,0 ) ;
  }

  @Test
  public void test34() {
    dawson.pythag(41.364035504163965,-41.364035504163965 ) ;
  }

  @Test
  public void test35() {
    dawson.pythag(-4.498227489835819E-191,-6.22949684443598E-207 ) ;
  }

  @Test
  public void test36() {
    dawson.pythag(4.5569512622227484E-305,0.0 ) ;
  }

  @Test
  public void test37() {
    dawson.pythag(-46.31195471782688,78.62386692963591 ) ;
  }

  @Test
  public void test38() {
    dawson.pythag(-4.712128221451531E-17,-4.7104331916799693E-17 ) ;
  }

  @Test
  public void test39() {
    dawson.pythag(4.737101034043988,-36.8646364153955 ) ;
  }

  @Test
  public void test40() {
    dawson.pythag(48.47144167296238,48.47144167296238 ) ;
  }

  @Test
  public void test41() {
    dawson.pythag(5.345529420184391E-51,-5.471944492805538E-51 ) ;
  }

  @Test
  public void test42() {
    dawson.pythag(-5.41761432454426,-48.57935527401458 ) ;
  }

  @Test
  public void test43() {
    dawson.pythag(5.484458581292045,0.0 ) ;
  }

  @Test
  public void test44() {
    dawson.pythag(5.616426750121252E-32,5.616659214480001E-32 ) ;
  }

  @Test
  public void test45() {
    dawson.pythag(-58.9696872099974,-58.97716340108248 ) ;
  }

  @Test
  public void test46() {
    dawson.pythag(-59.782009029770755,-73.99696793882562 ) ;
  }

  @Test
  public void test47() {
    dawson.pythag(-5.986374760315219E-19,5.98637476031522E-19 ) ;
  }

  @Test
  public void test48() {
    dawson.pythag(6.034870943341545,87.01117866323736 ) ;
  }

  @Test
  public void test49() {
    dawson.pythag(-6.084404423641242E-5,-6.237308702771872E-5 ) ;
  }

  @Test
  public void test50() {
    dawson.pythag(-6.2565096724471904E-148,-6.2565096724471904E-148 ) ;
  }

  @Test
  public void test51() {
    dawson.pythag(-64.65889925468946,0.0 ) ;
  }

  @Test
  public void test52() {
    dawson.pythag(64.90022278739865,0.0 ) ;
  }

  @Test
  public void test53() {
    dawson.pythag(-67.04096774006771,-67.04096774006771 ) ;
  }

  @Test
  public void test54() {
    dawson.pythag(6.938893903907228E-18,-0.00539321297044917 ) ;
  }

  @Test
  public void test55() {
    dawson.pythag(-6.938893903907228E-18,6.938893903907228E-18 ) ;
  }

  @Test
  public void test56() {
    dawson.pythag(-70.43612073019284,0.0 ) ;
  }

  @Test
  public void test57() {
    dawson.pythag(71.21486249113693,76.95912765297223 ) ;
  }

  @Test
  public void test58() {
    dawson.pythag(73.06733787174932,-11.572287876761095 ) ;
  }

  @Test
  public void test59() {
    dawson.pythag(7.375410521037635E-177,1.7534474792067224E-192 ) ;
  }

  @Test
  public void test60() {
    dawson.pythag(7.812871321366302,0 ) ;
  }

  @Test
  public void test61() {
    dawson.pythag(80.9544261917014,-38.05242623578191 ) ;
  }

  @Test
  public void test62() {
    dawson.pythag(-81.62902238420047,0.0 ) ;
  }

  @Test
  public void test63() {
    dawson.pythag(84.81264527131255,-84.81264527131255 ) ;
  }

  @Test
  public void test64() {
    dawson.pythag(85.38973104225377,-20.208517549144275 ) ;
  }

  @Test
  public void test65() {
    dawson.pythag(-8.552847072295026E-50,-8.619666190047331E-50 ) ;
  }

  @Test
  public void test66() {
    dawson.pythag(86.91000399553053,86.91000399553053 ) ;
  }

  @Test
  public void test67() {
    dawson.pythag(-87.03224309515316,89.49232707043734 ) ;
  }

  @Test
  public void test68() {
    dawson.pythag(-87.79624478172514,20.758255346156005 ) ;
  }

  @Test
  public void test69() {
    dawson.pythag(87.88556285307959,-96.89538639162339 ) ;
  }

  @Test
  public void test70() {
    dawson.pythag(-91.41648974814929,-91.41648974814929 ) ;
  }

  @Test
  public void test71() {
    dawson.pythag(-93.45831670677256,-78.99972210245714 ) ;
  }

  @Test
  public void test72() {
    dawson.pythag(-93.46677384069828,54.845455896421214 ) ;
  }

  @Test
  public void test73() {
    dawson.pythag(-95.52693671076398,28.187562135664876 ) ;
  }

  @Test
  public void test74() {
    dawson.pythag(9.617999988706471E-35,9.618108312001765E-35 ) ;
  }

  @Test
  public void test75() {
    dawson.pythag(96.32802302622326,64.68234670593301 ) ;
  }

  @Test
  public void test76() {
    dawson.pythag(96.57012685622163,29.878853848189237 ) ;
  }

  @Test
  public void test77() {
    dawson.pythag(-97.7584151615216,97.7584151615216 ) ;
  }

  @Test
  public void test78() {
    dawson.pythag(-97.98996027925065,97.98996027925065 ) ;
  }
}
