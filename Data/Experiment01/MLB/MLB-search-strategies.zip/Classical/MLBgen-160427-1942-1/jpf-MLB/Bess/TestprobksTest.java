import org.junit.Test;

public class TestprobksTest {

  @Test
  public void test0() {
    dawson.probks(11.300387713154663 ) ;
  }

  @Test
  public void test1() {
    dawson.probks(13.38873246982655 ) ;
  }

  @Test
  public void test2() {
    dawson.probks(13.48291717349295 ) ;
  }

  @Test
  public void test3() {
    dawson.probks(15.158175219314487 ) ;
  }

  @Test
  public void test4() {
    dawson.probks(1.5768544561060196 ) ;
  }

  @Test
  public void test5() {
    dawson.probks(16.020792306649483 ) ;
  }

  @Test
  public void test6() {
    dawson.probks(19.28851857809561 ) ;
  }

  @Test
  public void test7() {
    dawson.probks(19.289029094577483 ) ;
  }

  @Test
  public void test8() {
    dawson.probks(19.292303400092916 ) ;
  }

  @Test
  public void test9() {
    dawson.probks(19.29378386394221 ) ;
  }

  @Test
  public void test10() {
    dawson.probks(-3.1373448243204365 ) ;
  }

  @Test
  public void test11() {
    dawson.probks(-40.84208014397846 ) ;
  }

  @Test
  public void test12() {
    dawson.probks(-58.43214595633186 ) ;
  }

  @Test
  public void test13() {
    dawson.probks(-61.08472194915271 ) ;
  }

  @Test
  public void test14() {
    dawson.probks(62.83843578797706 ) ;
  }
}
