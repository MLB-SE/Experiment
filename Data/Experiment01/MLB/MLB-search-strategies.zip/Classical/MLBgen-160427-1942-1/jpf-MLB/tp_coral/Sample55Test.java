import org.junit.Test;

public class Sample55Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark55(11.735640686716762,100.0,15.980833947059278 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark55(15.319445106371205,80.53329342995886,67.35051453443447 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark55(17.114787481118398,-68.32439625089987,14.69005004877636 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark55(17.930348034630697,18.71888711197289,16.852375299138885 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark55(18.389354741480133,-68.50287064787801,66.1900667509559 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark55(20.072204288141776,51.977880728971655,-63.82274802348569 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark55(2.434698774304095,-96.15431351083382,0.8425778639072655 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark55(34.27227886982555,-100.0,36.057949260958054 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark55(4.480258420268882,0.7890201223061779,4.529374407506335 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark55(-57.49031452534441,20.64471474808802,-31.106509278658436 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark55(67.56457654786826,-75.03367577913383,90.27651961929294 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark55(67.76451419329017,-100.0,80.5061523614641 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark55(-70.69880280097382,-2.782426012217502,-60.561987032095196 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark55(-89.43177855297013,74.43119224747588,-87.0647547774229 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark55(97.92258476905008,37.6970661220804,96.92667830495768 ) ;
  }
}
