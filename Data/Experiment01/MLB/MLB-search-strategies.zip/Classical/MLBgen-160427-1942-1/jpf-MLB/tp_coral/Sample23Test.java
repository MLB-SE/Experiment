import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,-65.61428528619615,0,71.29165264592633 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,-93.12490091919432,96.02214993913739,45.02188873814814 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(100.0,-99.99999999999991,75.34925020416445,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-19.07886586886842,46.6081308165401,67.42110329669214,-39.137920811660805 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(22.681457649730486,-45.931306488352206,88.49845971594627,15.824573241358204 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(23.734559696376365,3.2244931723325694,-64.33367771891312,86.04934142952575 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(-23.74445739623485,4.018247067836744,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark23(32.019520836304565,-35.17767681998936,73.33074952568549,46.18677044077229 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark23(-50.184620907928434,43.862982107675776,0,-2.535829834640623 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark23(-5.4339542367748805,-80.61422354948166,-85.21482850005304,-37.96034094235954 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark23(68.55529543669367,-2.4349398685921684,61.44335885744309,-97.36859249264845 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark23(85.2066228153677,18.60029569187438,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark23(87.66610743989581,-30.660465071486033,-66.00608315313897,51.60726034112733 ) ;
  }
}
