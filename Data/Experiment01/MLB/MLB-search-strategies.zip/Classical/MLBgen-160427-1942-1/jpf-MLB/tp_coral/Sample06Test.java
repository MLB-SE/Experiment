import org.junit.Test;

public class Sample06Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark06(-27.56244323248825,-43.784570993833526,33.98630753660282 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark06(-29.18160662816086,-61.240991453806124,-6.024778697810072 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark06(40.30945746242028,78.66812338649018,-90.45434756542268 ) ;
  }
}
