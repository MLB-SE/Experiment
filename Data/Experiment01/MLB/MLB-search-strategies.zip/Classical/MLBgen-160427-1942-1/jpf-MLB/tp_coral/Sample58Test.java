import org.junit.Test;

public class Sample58Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark58(0,49.20527349946724,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark58(0,-9.157009549528496,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark58(11.409031816700633,58.16186799667037,-100.0,82.80191029244742,92.93469757468216 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark58(-20.33596261301011,-3.505308104155816,24.091492938192545,2.364757248042366,97.11625631482914 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark58(21.71496955853492,10.425059625915111,-31.465888089314387,25.453394594243605,52.74577671471087 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark58(-31.188783659685825,-30.218765009345063,-49.27090430126615,40.6599852350341,7.779109128719469 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark58(-3.6972800690880234,-99.48894918309314,-76.54989264362513,-16.722848771825326,-19.389883334697515 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark58(46.93735666648837,5.327188833051551,8.683523808902418,71.72429382260702,66.45231992430342 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark58(47.90973463238009,80.15278351952034,92.21219282839505,95.55186099886359,76.3544170119925 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark58(-52.303912564633805,53.47400906798049,-0.3072749918445794,-1.8990382547153875,94.57628587797706 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark58(7.077283064536916,3.813398819656257,25.474607421429628,-66.14338546884076,63.70656971829746 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark58(72.82529969249008,14.86902660897403,-86.90051506439995,175.27228796787517,37.01763705834867 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark58(90.67238154453003,19.973686448748637,14.006408220419047,12.444533269583943,1.2757581031860497 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark58(-98.42950428956362,60.16514098711818,12.445978003771344,55.0662441670284,50.570765689767796 ) ;
  }
}
