import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(22.990485773396557,34.50349648328591 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(-26.82987768308428,-54.91957214836402 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(-29.74250043200604,-60.07692328008023 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(35.397703469109956,70.41273995374888 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(50.24090565045455,31.658168729653823 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(69.03188334425732,-42.09541419656166 ) ;
  }
}
