import org.junit.Test;

public class Sample35Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark35(-16.67752076231912,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark35(50.265489485743295,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark35(-54.299953839114636,43.1363916737555 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark35(70.68583471090862,-75.09184124683841 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark35(-79.4022529340266,30.609787760296427 ) ;
  }
}
