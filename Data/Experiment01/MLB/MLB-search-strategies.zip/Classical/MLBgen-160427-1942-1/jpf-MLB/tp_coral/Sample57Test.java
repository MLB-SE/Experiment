import org.junit.Test;

public class Sample57Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark57(0,0.7303031161672919,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark57(0,29.326574128064777,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark57(10.318503988219646,41.26694203796063,-53.49240258123245,76.43073374670416,24.40016602341848 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark57(28.223659838237978,-96.8645339686799,-73.56845540850658,49.592232763121956,82.1253784181961 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark57(35.40201728657212,91.4835186742815,-29.377595652090307,28.956586187020548,7.488333635322846 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark57(50.70254449269848,67.08094975814379,-10.327319259418857,-2.1604829202216678,44.36722904491472 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark57(5.998677265412731,34.156276305351724,6.14554733466943,21.951395687219957,57.36536082987111 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark57(87.704344638923,-0.6622047475513345,65.91290762992762,-99.1054433024399,-53.38119752867145 ) ;
  }
}
