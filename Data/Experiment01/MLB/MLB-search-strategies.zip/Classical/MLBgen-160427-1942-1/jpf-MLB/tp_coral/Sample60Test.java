import org.junit.Test;

public class Sample60Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark60(0,1.6934215614231647,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark60(0,86.74626411962319,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark60(13.05477027906177,66.45884753622008,84.25134859820773,20.461145637165075,-66.58388684921732 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark60(25.416672065896392,83.65011122266142,-109.94437916302732,-52.70450587038983,91.00439371995287 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark60(2.9310414220292955,95.84178887021119,-96.63453276955912,74.00657860837606,68.23396773907169 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark60(3.4804402687667277,73.0778534970496,-25.477467124384475,43.2836778272663,82.70963981462515 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark60(37.48953648088943,70.60853609149963,100.0,-90.0976493846658,70.94776185519359 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark60(47.489303073462565,-24.247119556244584,-48.385379015675724,-36.99109005719732,22.002574527866585 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark60(50.64687633155773,-2.1945201629179394,-89.0637620605877,-84.89383714468974,0.9240282969767293 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark60(62.17037642746686,35.49300387710224,-16.68555833799128,81.55730305910822,88.84045008686351 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark60(63.97454218047572,-0.7665627517193769,-63.144634886457496,87.84710167014134,-92.91115099922492 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark60(67.11215663660647,9.793391912272895,-76.55906633567493,35.66508779049809,82.82945237730698 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark60(-68.69505155882362,-41.52302569278778,109.73488197598854,73.21590832753003,71.07598332277917 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark60(75.49097048318026,4.276919056524348,96.21275096980361,-26.44064010823446,20.059771229245072 ) ;
  }
}
