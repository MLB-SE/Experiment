import org.junit.Test;

public class Sample33Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark33(-42.46051902690824 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark33(63.617251235193315 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark33(-75.16217265240414 ) ;
  }
}
