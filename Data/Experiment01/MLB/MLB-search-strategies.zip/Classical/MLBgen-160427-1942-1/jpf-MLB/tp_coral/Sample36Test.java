import org.junit.Test;

public class Sample36Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark36(28.274333744846558,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark36(-56.033020134387336,-58.261060249422435,58.65203934003188 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark36(58.633526466296246,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark36(-67.56660625056075,-76.70686470915776,9.997121217182546 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark36(-68.86679321954307,90.7940669067819,0.21570937245225252 ) ;
  }
}
