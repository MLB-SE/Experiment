import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-100.0,100.0,100.0,0,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(14.469515526286585,20.75270083346617,0,0,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(1.5148605263968875,70.8620660385759,-3.6378857126228183,82.14990189280381,87.44932617337759,47.847440813781816,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(1.6876279759242232,-23.866450772716185,-91.06848799460255,-97.07131410109041,-59.10464419073342,81.09579276586197,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(20.540554816072003,-43.56395858097546,0,0,0,0,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-43.05600218819019,-78.37555390655906,-45.949649581689165,-39.10049387315928,-14.115418466176305,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(43.833879943581536,144.00655823230352,162.77379080638968,-132.66482429099565,-127.96826452011439,36.839559227754734,-77.65909760952582 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(43.84343430965981,28.730521185791204,5.40685058640446,49.339343890725736,-58.640756619980586,-25.4367256604747,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(50.75087315378431,62.91443508321498,29.18655280616531,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(58.45351408875274,-60.493747703718206,61.309051951983406,17.324618248328676,73.45724897039426,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(69.01546629903797,-57.013088851283065,-35.51401223873498,0,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(77.68090571543608,-62.15561512291102,-37.459184511090896,12.68257452960188,-18.798754349626805,34.602537352465376,4.618076961062927 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(7.849098705876685,-73.6729509089329,-43.19250657414737,100.0,100.0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(-86.74149867685506,-72.40760964606264,18.365274723793874,-8.952024052626072,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(94.93840901489125,-78.36395856757471,-58.0241345399525,42.331445019517474,0,0,0 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-9.692162014209089,78.382892649855,50.08754047291549,62.39359376957455,-15.067155618028536,-51.108336395610586,-79.61626541760862 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(99.16903536315738,-95.53009691143744,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(99.99781278124246,98.07916138202405,93.33583778665182,-32.32786835693991,0,0,0 ) ;
  }
}
