import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,100.0,99.99999999840725,-41.15446441323011,14.764686976759583 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(16.768159471808517,-2.4210848684815858,69.90876792808686,0,-33.585746698748295 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(19.32502294722009,-45.10347279075182,82.16346531116537,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(27.136583428921313,-1.474781358769936,100.0,0,81.48937913498375 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-29.155026100840004,-48.647348228618206,-0.047664721238476204,-4.958406986993722,-37.378893532840806 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-35.13295894679452,72.99312633144106,13.759432144969125,28.28889564204232,-80.42702820771433 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(4.290125180908831,-45.58056594031294,-1.9594981622082888,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(-63.36102786754152,44.12318924905142,-72.16854743686537,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(65.91584410508605,-52.833682430791875,26.16221034865076,-74.14510698195241,21.20465091368824 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(99.97124048512114,-94.39016964074037,-71.67044115624196,86.9031465927589,24.74402148899683 ) ;
  }
}
