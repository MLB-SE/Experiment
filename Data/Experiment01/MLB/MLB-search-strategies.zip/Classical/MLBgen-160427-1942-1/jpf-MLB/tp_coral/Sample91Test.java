import org.junit.Test;

public class Sample91Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark91(-64.19027543301426,64.61502336416726 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark91(78.53849307570772,-6.986357954107021 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark91(-84.06984758164522,-23.46177524268809 ) ;
  }
}
