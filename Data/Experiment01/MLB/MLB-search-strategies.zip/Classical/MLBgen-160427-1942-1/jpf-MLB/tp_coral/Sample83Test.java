import org.junit.Test;

public class Sample83Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark83(-1.9179525095561587,-33.245055562353755 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark83(7.553569243528611,57.057303178605075 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark83(-8.258920447953049,68.21392089366068 ) ;
  }
}
