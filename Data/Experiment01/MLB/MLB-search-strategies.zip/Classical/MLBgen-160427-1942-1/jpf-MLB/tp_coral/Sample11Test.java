import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(-0.6860941228363941,-32.759754004660735,19.72915744465942,-100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.9189568630564366,-7.525461867080367,-54.728874487939066,57.046733932329516 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(63.386300701619376,-46.439460722560064,-52.23907152792013,-54.52961630164861 ) ;
  }
}
