import org.junit.Test;

public class JpfTargetRayTraceTest {

  @Test
  public void test0() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.13556655f,-0.39393783f,-0.062322035f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,0.3778357f,-0.9025717f,0.20640874f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.6922201f,-0.59790444f,-0.05018419f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-0.8296079f,-0.032881368f,0.5573774f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-1.0552187E-5f,-2.7405785E-4f,6.534749E-5f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,41.946667f,40.31723f,3.246892f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,63.897137f,-79.633224f,-2.2647853f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,8.198214E-5f,-2.3309912E-7f,-5.5527173E-5f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,-9.0280736E-8f,8.491472E-8f,-2.0917963E-7f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.rayTrace(0f,0f,0f,0f,0f,0f,0f,96.021996f,47.2902f,-41.07666f ) ;
  }

  @Test
  public void test10() {
    TestDrivers.rayTrace(100.0f,-100.0f,-100.0f,-99.56522f,86.567856f,100.0f,-100.0f,-0.9394803f,0.1651817f,0.30015296f ) ;
  }

  @Test
  public void test11() {
    TestDrivers.rayTrace(-100.0f,-100.0f,100.0f,9.981789f,100.0f,-30.095293f,100.0f,-0.39233127f,-0.1449456f,0.90833193f ) ;
  }

  @Test
  public void test12() {
    TestDrivers.rayTrace(-100.0f,-15.834541f,-100.0f,-85.99091f,-100.0f,-52.4168f,-100.0f,0.75157964f,-0.53301656f,-0.38861474f ) ;
  }

  @Test
  public void test13() {
    TestDrivers.rayTrace(-100.0f,29.192715f,-94.44506f,41.51884f,-71.7302f,-3.7251782f,-100.0f,-0.10894625f,0.7230259f,0.52331406f ) ;
  }

  @Test
  public void test14() {
    TestDrivers.rayTrace(100.0f,35.10225f,100.0f,-100.0f,100.0f,100.0f,-100.0f,-0.10961675f,0.58932817f,-0.80042267f ) ;
  }

  @Test
  public void test15() {
    TestDrivers.rayTrace(100.0f,-97.15661f,-100.0f,-100.0f,-100.0f,-98.43703f,-100.0f,-0.99666744f,0.041232277f,-0.070383556f ) ;
  }

  @Test
  public void test16() {
    TestDrivers.rayTrace(-10.891585f,98.756584f,-46.22396f,-100.0f,38.650055f,18.006903f,0.7560122f,-0.0010189832f,-0.99968183f,-0.025202503f ) ;
  }

  @Test
  public void test17() {
    TestDrivers.rayTrace(-147.58784f,-49.086475f,137.49611f,60.814995f,-100.0f,-44.89812f,100.0f,-0.13639283f,0.39760658f,0.9073859f ) ;
  }

  @Test
  public void test18() {
    TestDrivers.rayTrace(-15.266041f,32.444977f,65.951256f,95.55905f,78.06442f,-9.55776f,76.84638f,78.72369f,10.150883f,-37.6255f ) ;
  }

  @Test
  public void test19() {
    TestDrivers.rayTrace(-17.096258f,-87.95542f,2.4155748f,-66.327675f,38.837517f,17.955313f,-54.816315f,-0.7144647f,0.5433833f,0.1950698f ) ;
  }

  @Test
  public void test20() {
    TestDrivers.rayTrace(18.99796f,-2.3288076f,-8.530791f,60.312977f,63.43318f,-87.86278f,-90.511635f,55.73189f,-84.22396f,-62.32143f ) ;
  }

  @Test
  public void test21() {
    TestDrivers.rayTrace(-19.150965f,-35.96138f,59.444386f,-66.7164f,-88.00578f,-24.45118f,72.68397f,-24.064466f,-35.251717f,90.856384f ) ;
  }

  @Test
  public void test22() {
    TestDrivers.rayTrace(19.204102f,12.038653f,6.585586f,-23.737371f,0.3010536f,-66.14585f,77.4987f,-0.33252588f,0.33476663f,-0.7005027f ) ;
  }

  @Test
  public void test23() {
    TestDrivers.rayTrace(20.8236f,-98.269066f,52.27018f,72.05954f,-19.986414f,-91.91018f,-7.1680875f,4.475817f,-1.1856985f,-3.8917682f ) ;
  }

  @Test
  public void test24() {
    TestDrivers.rayTrace(22.038828f,88.25581f,38.660088f,80.037254f,10.410866f,42.01283f,7.8788686f,0.09742833f,-0.17138521f,0.95008683f ) ;
  }

  @Test
  public void test25() {
    TestDrivers.rayTrace(2.301011f,-28.167553f,-38.654957f,-55.522f,-34.35006f,-62.149334f,-62.83408f,60.451344f,43.396614f,11.757136f ) ;
  }

  @Test
  public void test26() {
    TestDrivers.rayTrace(25.388903f,49.831547f,44.864544f,74.14345f,81.7709f,-89.47346f,46.242302f,-15.088032f,61.37949f,33.554276f ) ;
  }

  @Test
  public void test27() {
    TestDrivers.rayTrace(30.202106f,-35.998028f,-37.010998f,43.38307f,65.97045f,-25.755922f,-14.699217f,-0.13825108f,-0.4933377f,-0.043905158f ) ;
  }

  @Test
  public void test28() {
    TestDrivers.rayTrace(33.254704f,-42.37359f,72.779396f,62.419884f,51.13237f,14.357344f,48.41212f,0.07241178f,-0.17757882f,0.4414148f ) ;
  }

  @Test
  public void test29() {
    TestDrivers.rayTrace(3.6716f,39.99975f,-76.36303f,59.9279f,32.382446f,-13.47365f,-69.55585f,0.8755983f,0.2754112f,0.18701616f ) ;
  }

  @Test
  public void test30() {
    TestDrivers.rayTrace(4.1183286f,51.35507f,83.8427f,53.258198f,28.90203f,14.62141f,37.588455f,7.1218348f,88.11845f,75.8564f ) ;
  }

  @Test
  public void test31() {
    TestDrivers.rayTrace(43.685093f,90.22029f,-81.099846f,59.88111f,78.692955f,-37.79515f,-66.91866f,-67.055725f,57.825184f,41.949017f ) ;
  }

  @Test
  public void test32() {
    TestDrivers.rayTrace(50.822117f,-5.9938626f,53.826656f,-75.630424f,100.0f,100.0f,17.413086f,0.1551593f,0.36062104f,-0.77241117f ) ;
  }

  @Test
  public void test33() {
    TestDrivers.rayTrace(-5.4354963f,33.41182f,59.259785f,17.799913f,-98.86973f,7.801346f,-34.089283f,9.181605f,-32.524193f,-52.592625f ) ;
  }

  @Test
  public void test34() {
    TestDrivers.rayTrace(58.226933f,-100.0f,94.03585f,100.0f,100.0f,-52.545357f,78.12544f,-0.087465145f,0.24499938f,0.3593058f ) ;
  }

  @Test
  public void test35() {
    TestDrivers.rayTrace(-66.287125f,47.806858f,48.45802f,-65.0285f,-70.662766f,13.007752f,26.022345f,-44.92419f,5.0559926f,42.625126f ) ;
  }

  @Test
  public void test36() {
    TestDrivers.rayTrace(7.2409406f,20.128084f,-55.217182f,-37.14865f,-11.315547f,59.135895f,-44.849094f,65.05501f,97.50435f,68.09078f ) ;
  }

  @Test
  public void test37() {
    TestDrivers.rayTrace(73.22363f,-100.0f,66.542786f,-100.0f,-67.846176f,-71.41504f,81.078545f,-0.3449269f,0.21192794f,-0.9143916f ) ;
  }

  @Test
  public void test38() {
    TestDrivers.rayTrace(-75.92482f,-100.0f,42.661175f,-44.43512f,15.987025f,-77.05546f,-6.350893f,0.71275336f,0.60207087f,-0.35985187f ) ;
  }

  @Test
  public void test39() {
    TestDrivers.rayTrace(7.7712455f,64.73026f,-61.50598f,80.67082f,80.27812f,62.42589f,-5.8857646f,-85.01393f,26.91834f,-1.7078892f ) ;
  }

  @Test
  public void test40() {
    TestDrivers.rayTrace(79.65772f,-100.0f,-100.0f,-99.877625f,-100.0f,100.0f,99.21869f,0.7384698f,-0.43444893f,-0.5156709f ) ;
  }

  @Test
  public void test41() {
    TestDrivers.rayTrace(-81.192024f,-4.8896074f,100.0f,-11.133187f,-100.0f,-64.42635f,100.0f,-0.4150626f,0.03483139f,0.90912586f ) ;
  }

  @Test
  public void test42() {
    TestDrivers.rayTrace(-84.30839f,-47.64327f,-63.020298f,10.33801f,-16.558458f,-66.9811f,-68.92437f,-99.88006f,43.06395f,17.018482f ) ;
  }

  @Test
  public void test43() {
    TestDrivers.rayTrace(88.58641f,-75.63654f,-52.054955f,76.852455f,96.147675f,-60.77701f,61.397095f,77.62606f,52.884407f,-34.46911f ) ;
  }

  @Test
  public void test44() {
    TestDrivers.rayTrace(88.778076f,-37.366016f,-0.97463435f,-88.58292f,-72.10268f,89.754814f,52.532272f,93.67141f,-75.23403f,2.8523283f ) ;
  }

  @Test
  public void test45() {
    TestDrivers.rayTrace(96.08604f,100.0f,100.0f,100.0f,47.729973f,100.0f,78.560646f,-0.30308485f,-0.2067325f,-0.2514085f ) ;
  }

  @Test
  public void test46() {
    TestDrivers.rayTrace(-96.7f,57.821552f,-53.136543f,42.55501f,84.422905f,35.510616f,12.846331f,-12.203863f,-91.520584f,-31.352943f ) ;
  }

  @Test
  public void test47() {
    TestDrivers.rayTrace(97.330475f,62.645924f,100.0f,13.441438f,25.386082f,41.198097f,-100.0f,0.23319212f,-0.78833336f,-0.26280653f ) ;
  }

  @Test
  public void test48() {
    TestDrivers.rayTrace(99.99997f,-99.99999f,99.999985f,99.9909f,-100.0f,-87.070404f,-41.882423f,0.5697914f,-0.25891373f,0.77993685f ) ;
  }
}
