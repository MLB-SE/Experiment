import org.junit.Test;

public class JpfTargetVector3DNormalizeTest {

  @Test
  public void test0() {
    TestDrivers.vector3DNormalize(-0.04678988f,0.21482582f,-0.44403568f ) ;
  }

  @Test
  public void test1() {
    TestDrivers.vector3DNormalize(0.1548451f,-0.27794158f,-0.9480356f ) ;
  }

  @Test
  public void test2() {
    TestDrivers.vector3DNormalize(-0.31682348f,0.55840003f,0.7666892f ) ;
  }

  @Test
  public void test3() {
    TestDrivers.vector3DNormalize(-0.32738066f,5.3835346E-4f,-0.7852747f ) ;
  }

  @Test
  public void test4() {
    TestDrivers.vector3DNormalize(-1.06134125E-4f,1.7860837E-4f,4.3675708E-4f ) ;
  }

  @Test
  public void test5() {
    TestDrivers.vector3DNormalize(-1.0935143E-8f,-2.5770426E-8f,-3.086727E-8f ) ;
  }

  @Test
  public void test6() {
    TestDrivers.vector3DNormalize(-1.1877315E-4f,6.7564047E-6f,-2.2901509E-4f ) ;
  }

  @Test
  public void test7() {
    TestDrivers.vector3DNormalize(-2.8735838f,6.4585457f,54.5687f ) ;
  }

  @Test
  public void test8() {
    TestDrivers.vector3DNormalize(35.607704f,-89.95673f,-90.39923f ) ;
  }

  @Test
  public void test9() {
    TestDrivers.vector3DNormalize(-68.190994f,-28.923716f,-96.3074f ) ;
  }
}
