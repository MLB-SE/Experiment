import org.junit.Test;

public class JpfTargetWoodTest {

  @Test
  public void test0() {
    Optimization.wood(-4.36050878880836,19.01403689727495,0,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.wood(43.78491706884617,-51.484565072521015,0,0 ) ;
  }

  @Test
  public void test2() {
    Optimization.wood(5.313405308123279,59.98264636756909,0,0 ) ;
  }
}
