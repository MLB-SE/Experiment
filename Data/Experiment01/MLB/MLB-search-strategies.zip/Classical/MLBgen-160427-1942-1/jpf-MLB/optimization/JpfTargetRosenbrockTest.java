import org.junit.Test;

public class JpfTargetRosenbrockTest {

  @Test
  public void test0() {
    Optimization.rosenbrock(-6.083537767020521,37.0094369791922 ) ;
  }

  @Test
  public void test1() {
    Optimization.rosenbrock(81.61888319629588,-69.79691053785166 ) ;
  }

  @Test
  public void test2() {
    Optimization.rosenbrock(-8.331243991682058,69.40832991808169 ) ;
  }
}
