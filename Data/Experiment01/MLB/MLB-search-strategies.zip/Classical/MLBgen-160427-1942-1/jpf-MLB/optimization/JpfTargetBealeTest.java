import org.junit.Test;

public class JpfTargetBealeTest {

  @Test
  public void test0() {
    Optimization.beale(-0.01615532827405575,93.8486239681609 ) ;
  }

  @Test
  public void test1() {
    Optimization.beale(34.06514488757202,19.97706639133881 ) ;
  }

  @Test
  public void test2() {
    Optimization.beale(65.03509416855584,-65.27129179724649 ) ;
  }
}
