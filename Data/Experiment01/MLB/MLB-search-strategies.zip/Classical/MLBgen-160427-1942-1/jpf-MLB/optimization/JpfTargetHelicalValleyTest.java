import org.junit.Test;

public class JpfTargetHelicalValleyTest {

  @Test
  public void test0() {
    Optimization.theta(-0.003431738671751179,0 ) ;
  }

  @Test
  public void test1() {
    Optimization.theta(-0.9268553141291989,-71.31662194766267 ) ;
  }

  @Test
  public void test2() {
    Optimization.theta(100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    Optimization.theta(10.766091118677409,-41.76025200720843 ) ;
  }

  @Test
  public void test4() {
    Optimization.theta(-1.2495459271171946E-22,100.0 ) ;
  }

  @Test
  public void test5() {
    Optimization.theta(1.6868838650850014E-8,-874.6448196581831 ) ;
  }

  @Test
  public void test6() {
    Optimization.theta(-2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test7() {
    Optimization.theta(2.465190328815662E-32,0 ) ;
  }

  @Test
  public void test8() {
    Optimization.theta(30.53119359450874,-0.16750356070663486 ) ;
  }

  @Test
  public void test9() {
    Optimization.theta(31.087397586534905,0 ) ;
  }

  @Test
  public void test10() {
    Optimization.theta(-36.79613151215067,46.16298147446258 ) ;
  }

  @Test
  public void test11() {
    Optimization.theta(3.91233247973193,0 ) ;
  }

  @Test
  public void test12() {
    Optimization.theta(39.38900252888155,21.663030342131478 ) ;
  }

  @Test
  public void test13() {
    Optimization.theta(-41.97845754782388,38.091714719900324 ) ;
  }

  @Test
  public void test14() {
    Optimization.theta(-4.860126944801223,0 ) ;
  }

  @Test
  public void test15() {
    Optimization.theta(-4.930380657631324E-32,0 ) ;
  }

  @Test
  public void test16() {
    Optimization.theta(-49.495209530186585,69.97331123288507 ) ;
  }

  @Test
  public void test17() {
    Optimization.theta(-51.07117453757635,0 ) ;
  }

  @Test
  public void test18() {
    Optimization.theta(53.30189160592377,0 ) ;
  }

  @Test
  public void test19() {
    Optimization.theta(-56.87677663508446,81.75471285557313 ) ;
  }

  @Test
  public void test20() {
    Optimization.theta(60.85414600556871,50.95614602467174 ) ;
  }

  @Test
  public void test21() {
    Optimization.theta(62.39761610928041,-63.67627643394604 ) ;
  }

  @Test
  public void test22() {
    Optimization.theta(-73.8197513549498,58.1576187056757 ) ;
  }

  @Test
  public void test23() {
    Optimization.theta(80.31479681066992,0.0 ) ;
  }

  @Test
  public void test24() {
    Optimization.theta(-86.9182395413686,-8.502752817789464 ) ;
  }

  @Test
  public void test25() {
    Optimization.theta(93.00453063246206,-46.841769257948606 ) ;
  }

  @Test
  public void test26() {
    Optimization.theta(93.14679038259698,57.272512456734425 ) ;
  }

  @Test
  public void test27() {
    Optimization.theta(-99.04953212761392,0 ) ;
  }
}
