import org.junit.Test;

public class JpfTargetFreudensteinRothTest {

  @Test
  public void test0() {
    Optimization.freudensteinRoth(-16.18315669472463,16.50349377063489 ) ;
  }

  @Test
  public void test1() {
    Optimization.freudensteinRoth(-63.693781889121695,-2.000652643768248 ) ;
  }

  @Test
  public void test2() {
    Optimization.freudensteinRoth(6.5626575593358485,-1.2338100709195654 ) ;
  }
}
