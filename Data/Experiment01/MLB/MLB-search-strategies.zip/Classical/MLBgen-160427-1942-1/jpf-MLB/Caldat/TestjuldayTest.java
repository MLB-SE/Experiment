import org.junit.Test;

public class TestjuldayTest {

  @Test
  public void test0() {
    caldat.julday(0,0,0 ) ;
  }

  @Test
  public void test1() {
    caldat.julday(0,0,471 ) ;
  }

  @Test
  public void test2() {
    caldat.julday(0,0,-735 ) ;
  }

  @Test
  public void test3() {
    caldat.julday(0,0,-86 ) ;
  }

  @Test
  public void test4() {
    caldat.julday(-1,0,-272 ) ;
  }

  @Test
  public void test5() {
    caldat.julday(-1,0,364 ) ;
  }

  @Test
  public void test6() {
    caldat.julday(-107,0,0 ) ;
  }

  @Test
  public void test7() {
    caldat.julday(-110,0,-48 ) ;
  }

  @Test
  public void test8() {
    caldat.julday(-1,163,-728 ) ;
  }

  @Test
  public void test9() {
    caldat.julday(-1,1663,0 ) ;
  }

  @Test
  public void test10() {
    caldat.julday(-13,0,0 ) ;
  }

  @Test
  public void test11() {
    caldat.julday(-13,0,245 ) ;
  }

  @Test
  public void test12() {
    caldat.julday(-13,0,400 ) ;
  }

  @Test
  public void test13() {
    caldat.julday(-13,0,-560 ) ;
  }

  @Test
  public void test14() {
    caldat.julday(-13,0,-74 ) ;
  }

  @Test
  public void test15() {
    caldat.julday(-13,-1014,-500 ) ;
  }

  @Test
  public void test16() {
    caldat.julday(-13,15205,-1 ) ;
  }

  @Test
  public void test17() {
    caldat.julday(-13,20898,0 ) ;
  }

  @Test
  public void test18() {
    caldat.julday(-13,236,-186 ) ;
  }

  @Test
  public void test19() {
    caldat.julday(-13,-406,0 ) ;
  }

  @Test
  public void test20() {
    caldat.julday(135,0,-113 ) ;
  }

  @Test
  public void test21() {
    caldat.julday(-13,510,217 ) ;
  }

  @Test
  public void test22() {
    caldat.julday(-13,-575,1260 ) ;
  }

  @Test
  public void test23() {
    caldat.julday(-13,725,2245 ) ;
  }

  @Test
  public void test24() {
    caldat.julday(-14,18141,4 ) ;
  }

  @Test
  public void test25() {
    caldat.julday(1420,760,1685 ) ;
  }

  @Test
  public void test26() {
    caldat.julday(-14,-335,0 ) ;
  }

  @Test
  public void test27() {
    caldat.julday(-1475,0,1 ) ;
  }

  @Test
  public void test28() {
    caldat.julday(1,-480,1661 ) ;
  }

  @Test
  public void test29() {
    caldat.julday(-165,0,0 ) ;
  }

  @Test
  public void test30() {
    caldat.julday(-17,19627,-3 ) ;
  }

  @Test
  public void test31() {
    caldat.julday(-190,0,-216 ) ;
  }

  @Test
  public void test32() {
    caldat.julday(19171,-842,0 ) ;
  }

  @Test
  public void test33() {
    caldat.julday(-19,21320,-4 ) ;
  }

  @Test
  public void test34() {
    caldat.julday(19486,862,-1 ) ;
  }

  @Test
  public void test35() {
    caldat.julday(19613,736,-48 ) ;
  }

  @Test
  public void test36() {
    caldat.julday(-2,0,0 ) ;
  }

  @Test
  public void test37() {
    caldat.julday(2,0,0 ) ;
  }

  @Test
  public void test38() {
    caldat.julday(-2,0,-18 ) ;
  }

  @Test
  public void test39() {
    caldat.julday(-2,0,476 ) ;
  }

  @Test
  public void test40() {
    caldat.julday(-2,0,517 ) ;
  }

  @Test
  public void test41() {
    caldat.julday(-2,0,-749 ) ;
  }

  @Test
  public void test42() {
    caldat.julday(-211,0,359 ) ;
  }

  @Test
  public void test43() {
    caldat.julday(2,112,769 ) ;
  }

  @Test
  public void test44() {
    caldat.julday(225,0,-155 ) ;
  }

  @Test
  public void test45() {
    caldat.julday(-226,867,865 ) ;
  }

  @Test
  public void test46() {
    caldat.julday(-22,935,1629 ) ;
  }

  @Test
  public void test47() {
    caldat.julday(-23,448,1648 ) ;
  }

  @Test
  public void test48() {
    caldat.julday(2,-358,-957 ) ;
  }

  @Test
  public void test49() {
    caldat.julday(-241,0,409 ) ;
  }

  @Test
  public void test50() {
    caldat.julday(248,0,1 ) ;
  }

  @Test
  public void test51() {
    caldat.julday(2,8,19 ) ;
  }

  @Test
  public void test52() {
    caldat.julday(305,0,-1 ) ;
  }

  @Test
  public void test53() {
    caldat.julday(-313,0,-727 ) ;
  }

  @Test
  public void test54() {
    caldat.julday(382,0,525 ) ;
  }

  @Test
  public void test55() {
    caldat.julday(4,0,0 ) ;
  }

  @Test
  public void test56() {
    caldat.julday(4,0,1505 ) ;
  }

  @Test
  public void test57() {
    caldat.julday(4,0,2140 ) ;
  }

  @Test
  public void test58() {
    caldat.julday(4,0,-630 ) ;
  }

  @Test
  public void test59() {
    caldat.julday(4,0,-89 ) ;
  }

  @Test
  public void test60() {
    caldat.julday(-4,1621,1716 ) ;
  }

  @Test
  public void test61() {
    caldat.julday(-452,0,373 ) ;
  }

  @Test
  public void test62() {
    caldat.julday(-484,0,-539 ) ;
  }

  @Test
  public void test63() {
    caldat.julday(-488,-139,1962 ) ;
  }

  @Test
  public void test64() {
    caldat.julday(513,0,1 ) ;
  }

  @Test
  public void test65() {
    caldat.julday(5164,1578,1204 ) ;
  }

  @Test
  public void test66() {
    caldat.julday(-5,21511,0 ) ;
  }

  @Test
  public void test67() {
    caldat.julday(-529,0,1 ) ;
  }

  @Test
  public void test68() {
    caldat.julday(576,0,0 ) ;
  }

  @Test
  public void test69() {
    caldat.julday(576,0,276 ) ;
  }

  @Test
  public void test70() {
    caldat.julday(602,0,-1 ) ;
  }

  @Test
  public void test71() {
    caldat.julday(619,511,0 ) ;
  }

  @Test
  public void test72() {
    caldat.julday(-623,0,382 ) ;
  }

  @Test
  public void test73() {
    caldat.julday(660,0,-711 ) ;
  }

  @Test
  public void test74() {
    caldat.julday(680,0,0 ) ;
  }

  @Test
  public void test75() {
    caldat.julday(-681,-91,-84 ) ;
  }

  @Test
  public void test76() {
    caldat.julday(685,264,-327 ) ;
  }

  @Test
  public void test77() {
    caldat.julday(-704,-259,-697 ) ;
  }

  @Test
  public void test78() {
    caldat.julday(705,-865,-545 ) ;
  }

  @Test
  public void test79() {
    caldat.julday(-7,20131,-7 ) ;
  }

  @Test
  public void test80() {
    caldat.julday(-722,0,485 ) ;
  }

  @Test
  public void test81() {
    caldat.julday(731,0,-413 ) ;
  }

  @Test
  public void test82() {
    caldat.julday(747,0,-452 ) ;
  }

  @Test
  public void test83() {
    caldat.julday(75,0,351 ) ;
  }

  @Test
  public void test84() {
    caldat.julday(-8,0,-262 ) ;
  }

  @Test
  public void test85() {
    caldat.julday(-8,14899,-8 ) ;
  }

  @Test
  public void test86() {
    caldat.julday(-8,21262,-20 ) ;
  }

  @Test
  public void test87() {
    caldat.julday(885,233,832 ) ;
  }

  @Test
  public void test88() {
    caldat.julday(9,0,0 ) ;
  }

  @Test
  public void test89() {
    caldat.julday(-9,0,469 ) ;
  }

  @Test
  public void test90() {
    caldat.julday(-908,-14,367 ) ;
  }

  @Test
  public void test91() {
    caldat.julday(912,0,329 ) ;
  }

  @Test
  public void test92() {
    caldat.julday(-920,0,2 ) ;
  }

  @Test
  public void test93() {
    caldat.julday(-930,0,-1 ) ;
  }

  @Test
  public void test94() {
    caldat.julday(-937,0,0 ) ;
  }

  @Test
  public void test95() {
    caldat.julday(97,0,888 ) ;
  }

  @Test
  public void test96() {
    caldat.julday(-992,0,-256 ) ;
  }

  @Test
  public void test97() {
    caldat.julday(993,917,14 ) ;
  }
}
