import org.junit.Test;

public class TestsphbesTest {

  @Test
  public void test0() {
    airy.sphbes(0,2.3047621954340807 ) ;
  }

  @Test
  public void test1() {
    airy.sphbes(0,43.229296552689135 ) ;
  }

  @Test
  public void test2() {
    airy.sphbes(0,71.24002701144073 ) ;
  }

  @Test
  public void test3() {
    airy.sphbes(1020,-1.3552527156068805E-20 ) ;
  }

  @Test
  public void test4() {
    airy.sphbes(-1038,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test5() {
    airy.sphbes(-134,0.0 ) ;
  }

  @Test
  public void test6() {
    airy.sphbes(-139,34.40256534866552 ) ;
  }

  @Test
  public void test7() {
    airy.sphbes(1726,2.0000000000000564 ) ;
  }

  @Test
  public void test8() {
    airy.sphbes(-1,75.253467088419 ) ;
  }

  @Test
  public void test9() {
    airy.sphbes(178,0 ) ;
  }

  @Test
  public void test10() {
    airy.sphbes(187,11.135628336770665 ) ;
  }

  @Test
  public void test11() {
    airy.sphbes(1969,-6.4E-323 ) ;
  }

  @Test
  public void test12() {
    airy.sphbes(285,-1.504715399527967E-16 ) ;
  }

  @Test
  public void test13() {
    airy.sphbes(-326,52.477166707879576 ) ;
  }

  @Test
  public void test14() {
    airy.sphbes(367,1.24E-322 ) ;
  }

  @Test
  public void test15() {
    airy.sphbes(-380,-30.95843310750226 ) ;
  }

  @Test
  public void test16() {
    airy.sphbes(395,-97.70596984361009 ) ;
  }

  @Test
  public void test17() {
    airy.sphbes(460,-47.60977964883861 ) ;
  }

  @Test
  public void test18() {
    airy.sphbes(485,1.1169381466976227E-16 ) ;
  }

  @Test
  public void test19() {
    airy.sphbes(-501,89.72869829650705 ) ;
  }

  @Test
  public void test20() {
    airy.sphbes(510,58.044798032271274 ) ;
  }

  @Test
  public void test21() {
    airy.sphbes(-511,0.4627079421066327 ) ;
  }

  @Test
  public void test22() {
    airy.sphbes(53,0.0 ) ;
  }

  @Test
  public void test23() {
    airy.sphbes(541,0.0 ) ;
  }

  @Test
  public void test24() {
    airy.sphbes(610,-77.39344824631297 ) ;
  }

  @Test
  public void test25() {
    airy.sphbes(-63,0.0 ) ;
  }

  @Test
  public void test26() {
    airy.sphbes(-640,0.0 ) ;
  }

  @Test
  public void test27() {
    airy.sphbes(684,1.5E-323 ) ;
  }

  @Test
  public void test28() {
    airy.sphbes(686,1.9721522630525295E-31 ) ;
  }

  @Test
  public void test29() {
    airy.sphbes(713,-2.0E-322 ) ;
  }

  @Test
  public void test30() {
    airy.sphbes(741,0.0 ) ;
  }

  @Test
  public void test31() {
    airy.sphbes(-763,2.0 ) ;
  }

  @Test
  public void test32() {
    airy.sphbes(-784,0 ) ;
  }

  @Test
  public void test33() {
    airy.sphbes(817,-4.930380657631324E-32 ) ;
  }

  @Test
  public void test34() {
    airy.sphbes(820,54.842813327316776 ) ;
  }

  @Test
  public void test35() {
    airy.sphbes(-821,2.0000000000000004 ) ;
  }

  @Test
  public void test36() {
    airy.sphbes(-845,-18.882011327572684 ) ;
  }

  @Test
  public void test37() {
    airy.sphbes(-908,2.0000000000000004 ) ;
  }
}
