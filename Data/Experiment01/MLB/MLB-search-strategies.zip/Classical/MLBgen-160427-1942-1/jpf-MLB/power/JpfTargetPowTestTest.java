import org.junit.Test;

public class JpfTargetPowTestTest {

  @Test
  public void test0() {
    concolic.PowExample.test(209,0 ) ;
  }

  @Test
  public void test1() {
    concolic.PowExample.test(21,-399 ) ;
  }

  @Test
  public void test2() {
    concolic.PowExample.test(21,441 ) ;
  }

  @Test
  public void test3() {
    concolic.PowExample.test(2,4 ) ;
  }

  @Test
  public void test4() {
    concolic.PowExample.test(42,1764 ) ;
  }

  @Test
  public void test5() {
    concolic.PowExample.test(-567,0 ) ;
  }

  @Test
  public void test6() {
    concolic.PowExample.test(589,-338 ) ;
  }

  @Test
  public void test7() {
    concolic.PowExample.test(859,62 ) ;
  }
}
