import org.junit.Test;

public class TestStatCalcTest {

  @Test
  public void test0() {
    concolic.TestStatCalc.run(-189 ) ;
  }

  @Test
  public void test1() {
    concolic.TestStatCalc.run(-23 ) ;
  }

  @Test
  public void test2() {
    concolic.TestStatCalc.run(-277 ) ;
  }

  @Test
  public void test3() {
    concolic.TestStatCalc.run(3 ) ;
  }

  @Test
  public void test4() {
    concolic.TestStatCalc.run(326 ) ;
  }

  @Test
  public void test5() {
    concolic.TestStatCalc.run(-433 ) ;
  }

  @Test
  public void test6() {
    concolic.TestStatCalc.run(-459 ) ;
  }

  @Test
  public void test7() {
    concolic.TestStatCalc.run(523 ) ;
  }

  @Test
  public void test8() {
    concolic.TestStatCalc.run(-581 ) ;
  }

  @Test
  public void test9() {
    concolic.TestStatCalc.run(-674 ) ;
  }

  @Test
  public void test10() {
    concolic.TestStatCalc.run(694 ) ;
  }

  @Test
  public void test11() {
    concolic.TestStatCalc.run(-793 ) ;
  }

  @Test
  public void test12() {
    concolic.TestStatCalc.run(-800 ) ;
  }

  @Test
  public void test13() {
    concolic.TestStatCalc.run(821 ) ;
  }

  @Test
  public void test14() {
    concolic.TestStatCalc.run(-893 ) ;
  }

  @Test
  public void test15() {
    concolic.TestStatCalc.run(961 ) ;
  }

  @Test
  public void test16() {
    concolic.TestStatCalc.run(97 ) ;
  }
}
