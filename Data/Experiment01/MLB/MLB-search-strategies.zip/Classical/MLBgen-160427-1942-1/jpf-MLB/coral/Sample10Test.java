import org.junit.Test;

public class Sample10Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark10(35.463158867589414,-25.206800030260453,-52.50803160550805 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark10(40.05649317317349,98.74773104148312,43.3041694201448 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark10(99.86701309567674,21.401622076989046,-81.71376703940851 ) ;
  }
}
