import org.junit.Test;

public class Sample27Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark27(35.67413587232383,73.14047376536621,29.84716454278731 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark27(-36.009873799065026,15.16096380097828,15.793095673671306 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark27(-37.70767061389016,-77.46403826333076,52.99966244736282 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark27(5.568910902543509,-60.547665516007655,-22.44900793263605 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark27(95.40888014148749,-48.30084334970823,96.68879501871416 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark27(-97.0306285947778,58.703357018535144,24.574493097578113 ) ;
  }
}
