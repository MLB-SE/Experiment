import org.junit.Test;

public class Sample82Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark82(-1.3575779380324235E-6,-73.660595976488 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark82(-1.611823555870551E-5,-6.204153031253454 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark82(37.03262776341097,-31.07632476872655 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark82(-6.02104093715073,-58.729924763181884 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark82(-60.6316069634292,-1.6493047934605525E-6 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark82(-6.78340282273509E-6,-14.741863724330566 ) ;
  }
}
