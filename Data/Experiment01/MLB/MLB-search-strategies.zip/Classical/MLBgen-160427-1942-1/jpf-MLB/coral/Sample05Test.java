import org.junit.Test;

public class Sample05Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark05(16.632080063643418,92.10724377242619,84.17492381461054 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark05(24.29813380206231,87.13408586924564,3.585858335485554 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark05(-48.69725532583309,4.501872455912732,-10.37673785391236 ) ;
  }
}
