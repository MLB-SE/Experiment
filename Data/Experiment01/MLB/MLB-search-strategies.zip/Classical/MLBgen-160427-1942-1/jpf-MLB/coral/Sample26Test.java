import org.junit.Test;

public class Sample26Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark26(-100.0,-97.85543089887956,100.0,-71.19629704158102,-75.94809532610844 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark26(-13.164819113392996,1.6417859759653777,7.12867898571137,13.186238236501907,-65.2212968294791 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark26(14.803865378939534,83.7980283171753,-48.701442062127185,85.42604814270666,-75.46304699018387 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark26(22.93861683562794,66.41287471610923,52.44874915198804,-50.61424421666565,46.2671154246718 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark26(-36.35417349769088,-96.65277906069359,-51.63698796144318,0,44.91178792189041 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark26(-39.41604408945414,-90.72635479215705,76.39092246390835,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark26(-77.6045640045879,-23.35485532542336,100.0,0,56.13448878555229 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark26(8.0466977123872,27.49205689673306,-82.9892387507332,-2.8552799374128313,-16.265079393865406 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark26(87.98918102355614,-45.62592805216718,-86.78041842630135,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark26(-93.50683417670449,84.14749495887733,33.75458262065999,0,0 ) ;
  }
}
