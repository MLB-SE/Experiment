import org.junit.Test;

public class Sample11Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark11(0.23773732652232127,54.46795658983078,-40.0604239270135,-49.456342111110494 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark11(0.4399164351803506,35.382207578979916,-55.118446730202294,73.8324934646487 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark11(0.822930573150984,-3.849723332244409,-25.845562476419012,-33.762956846672324 ) ;
  }
}
