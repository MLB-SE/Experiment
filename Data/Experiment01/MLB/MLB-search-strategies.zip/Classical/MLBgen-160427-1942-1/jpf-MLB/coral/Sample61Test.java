import org.junit.Test;

public class Sample61Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,-32.69156212135749 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark61(0,0,0,5.3356242295947 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark61(100.0,0.0,100.0,100.0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark61(100.0,-3.333275172962725,185.79925644674023,100.0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark61(14.798221900543965,-17.013510314130656,99.66658609742703,-11.404758276779518 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark61(16.289133937031735,-9.067799140166642,-9.4962810841551,35.7052755750434 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark61(2.850489947808738,41.22080001799219,69.59470099227333,-4.831977331629472 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark61(31.568458768686686,-30.798989841534357,-36.13440233858165,-46.96018391841871 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark61(3.411092755546998,-1.154122327223217E-128,100.0,-89.01230806260396 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark61(37.88678313805357,-2.8614199224852968,73.5075035690804,34.83636361480356 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark61(40.54109711418692,-8.881784197001252E-16,66.19959051889353,37.643704808977034 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark61(54.931534749309066,-56.311559065053316,-2.8770603520537747,1.4970360363095239 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark61(-62.06914706006255,92.93411388180155,-13.633794535449724,-48.52381803550592 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark61(-62.59897298053596,-61.3158567025881,-93.69192145736929,-49.40885980612062 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark61(64.92417888628822,97.26769791770047,47.7404251665769,92.19025532173342 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark61(7.073197387270696,75.65594254850524,-37.36756122819334,-25.300803892220202 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark61(87.54981703196358,-29.281218323966556,92.76970925792943,-0.3980824097395299 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark61(9.342506448822157,-79.03588989967332,100.0,-0.11820587407418781 ) ;
  }

  @Test
  public void test18() {
    coral.tests.JPFBenchmark.benchmark61(95.49100771104884,-17.844275675364997,-193.2723313960955,-45.794279427646025 ) ;
  }

  @Test
  public void test19() {
    coral.tests.JPFBenchmark.benchmark61(95.56069621884618,-97.51986401576909,-86.9281307753365,19.57889523041827 ) ;
  }

  @Test
  public void test20() {
    coral.tests.JPFBenchmark.benchmark61(-9.812580723159627,80.21247973383757,-5.045516970989098,-9.044799888712191 ) ;
  }
}
