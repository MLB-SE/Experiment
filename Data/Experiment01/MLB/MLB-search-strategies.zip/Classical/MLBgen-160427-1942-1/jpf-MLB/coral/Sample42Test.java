import org.junit.Test;

public class Sample42Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark42(0.8655836033729244,0.596287195674293 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark42(100.0,-0.9539123828297378 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark42(1.0,-35.62980223445993 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark42(14.3385458090018,70.35430841352405 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark42(38.17646870775269,0.11191044346743695 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark42(49.423858404581864,69.8209590782817 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark42(56.83308602554138,67.56767256486995 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark42(6.539800518891084,10.0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark42(74.13502282385662,17.98215495845541 ) ;
  }
}
