import org.junit.Test;

public class Sample54Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark54(17.423315261705213,-58.77101119712653,-25.93861993789737 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark54(21.22722059964623,-46.14182803353912,97.09272391133761 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark54(24.95136963548694,75.8141221210972,23.190941999044085 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark54(33.505128016402665,36.80264662337157,24.474853028264704 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark54(3.4135906833305754,-54.506344267760575,4.530469194710449 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark54(42.15646994062493,3.0021755695319996,49.89164187925991 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark54(46.034900341969895,0.778357488977569,43.63470496778739 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark54(46.298742296617405,-28.799840101896805,47.242057753991936 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark54(58.13663598266825,-37.50690754453421,88.42736328966694 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark54(58.18686875788469,-16.063196407976104,59.147595558687016 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark54(72.13237910502764,2.7827433676812,98.19217943126804 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark54(76.29629740421808,97.66153910203693,45.778334166794764 ) ;
  }
}
