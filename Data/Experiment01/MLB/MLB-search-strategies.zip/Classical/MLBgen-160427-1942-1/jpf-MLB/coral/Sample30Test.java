import org.junit.Test;

public class Sample30Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark30(100.0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark30(175.5312607500481 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark30(47.33531531479073 ) ;
  }
}
