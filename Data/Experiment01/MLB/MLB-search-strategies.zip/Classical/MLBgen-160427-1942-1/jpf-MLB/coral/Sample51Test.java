import org.junit.Test;

public class Sample51Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark51(0.9236698561774546,15.471029097335489 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark51(1.4354889913870026,47.889577685442816 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark51(18.847683527915194,27.734645734427858 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark51(2.04415477600417E-15,4.521232073581002E-8 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark51(21.102542250309302,28.897457749690698 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark51(2.168404344971009E-18,5.814734214658796E-10 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark51(-41.204492585869666,36.41965101507202 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark51(4.829366775894158,14.983024311133576 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark51(48.42317153114945,74.14913748238027 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark51(5.367988287783247,6.828376898528627 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark51(74.57399437961755,94.04148290697853 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark51(7.793813627678347,84.761636275987 ) ;
  }
}
