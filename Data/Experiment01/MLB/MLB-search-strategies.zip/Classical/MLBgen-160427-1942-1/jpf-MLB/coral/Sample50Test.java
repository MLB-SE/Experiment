import org.junit.Test;

public class Sample50Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark50(0.47263768718799415,49.52736231281201 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark50(0.8025090650917859,15.538274680892338 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark50(1.0175265539689374E-11,3.189869203880955E-6 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark50(14.852587761894057,27.852587761894057 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark50(2.3782738956500893,47.170679404332645 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark50(36.22471888548492,87.18115151812819 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark50(44.354187008323805,74.25014812115788 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark50(5.034657574256315,9.86497153618366 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark50(5.5888140252854934E-12,2.3640666843982366E-6 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark50(73.1360381377705,71.51619332168454 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark50(8.087679576963048,12.279478852356561 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark50(80.89457610151572,94.01852443960931 ) ;
  }
}
