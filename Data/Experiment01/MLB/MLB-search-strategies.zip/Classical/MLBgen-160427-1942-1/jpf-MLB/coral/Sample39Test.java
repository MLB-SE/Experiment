import org.junit.Test;

public class Sample39Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark39(1.3140102622304966,5.3716439596207606E-17 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark39(30.866222617011402,-66.19336822913861 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark39(49.644015325854554,31.951079242403893 ) ;
  }
}
