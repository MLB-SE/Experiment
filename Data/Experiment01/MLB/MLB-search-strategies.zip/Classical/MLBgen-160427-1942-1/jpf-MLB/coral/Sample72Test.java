import org.junit.Test;

public class Sample72Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark72(-10.963982635396365,57.443958468504704,65.45541947369054,84.62880501489857,-84.93032828652557,22.354417880428425,-84.45973234162454 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark72(-11.232276391197615,-42.730438847013176,-55.938240519259196,-83.52107580783546,-26.695462151831407,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark72(11.829210339084618,-65.18704899057477,-33.771122454676835,0,0,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark72(-12.128491299536549,-57.24896575771912,29.1675259631881,30.483486825353566,-65.03172782062657,42.93972345057858,-15.443957472321259 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark72(-148.59846593541664,-11.933681329119269,69.7364618503299,-90.29536841343486,-89.86636354786384,34.24353484406524,0 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark72(-18.05676546395769,-100.0,-46.440274950762685,35.241134042571936,0,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark72(33.87215532443767,46.715660727437744,34.15812652181802,-96.96286241054389,3.967144377936081,-27.44878215796185,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark72(-37.12942408008575,27.920393402133698,-78.04537854901005,-95.84509735408308,0,0,0 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark72(48.393178927758115,-96.12008313737238,0,0,0,0,0 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark72(52.34848005164389,83.90723415676112,44.49524270099747,21.75664830282344,-28.508834154613254,0,0 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark72(-60.40706581836226,41.10980686701092,-96.86710632386092,45.40609608018289,0,0,0 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark72(-60.68888756738771,55.13516751107795,0,0,0,0,0 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark72(-67.71302156881225,-47.94088764612341,40.97415947443914,100.0,-100.0,0,0 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark72(7.289846608167579,-72.15571132742195,-57.87546487082429,0,0,0,0 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark72(8.800487606437656,-0.6392653671820554,55.84794815445079,79.28221813755562,-84.04058112992143,5.2060191624562435,67.07475680955557 ) ;
  }

  @Test
  public void test15() {
    coral.tests.JPFBenchmark.benchmark72(-93.02628907566165,-80.70714672404229,-19.109843358876958,-77.97186233135022,41.42209900549889,93.22800639892128,0 ) ;
  }

  @Test
  public void test16() {
    coral.tests.JPFBenchmark.benchmark72(94.50032437317583,-93.52408198288124,0,0,0,0,0 ) ;
  }

  @Test
  public void test17() {
    coral.tests.JPFBenchmark.benchmark72(97.57716630336492,47.81303531766312,-92.98126356332203,0,0,0,0 ) ;
  }
}
