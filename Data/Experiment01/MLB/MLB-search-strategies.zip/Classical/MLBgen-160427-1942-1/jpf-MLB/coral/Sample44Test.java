import org.junit.Test;

public class Sample44Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark44(1.470803201396085,1.470803201396085 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark44(1.5786209249232002,1.5786209249232002 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark44(3.190720792110623,2.3453015942358717 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark44(44.850800883241135,95.99099181795182 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark44(45.00651687434717,17.946789364614048 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark44(7.636367378130629,81.19196504987536 ) ;
  }
}
