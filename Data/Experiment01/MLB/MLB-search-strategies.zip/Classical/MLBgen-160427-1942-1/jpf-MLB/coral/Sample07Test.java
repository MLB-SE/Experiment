import org.junit.Test;

public class Sample07Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark07(0,-0.058467908778922606,0,91.10198649327731 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark07(0,-13.613568168839567,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark07(0,76.38271675768401,0,63.125004698213075 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark07(0,-88.0469420668583,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark07(10.723349117017808,-89.78598091117837,48.01002877793584,22.4748460709633 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark07(-68.50410724776555,55.95160839804839,1.8159627189347987,26.745629504384922 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark07(86.20479208681786,-13.24986642721555,79.35140753238446,21.571263202164005 ) ;
  }
}
