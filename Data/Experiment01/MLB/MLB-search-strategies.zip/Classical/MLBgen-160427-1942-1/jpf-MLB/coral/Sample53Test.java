import org.junit.Test;

public class Sample53Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark53(12.745180958104251,2.7097599749411687,17.454686557389522 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark53(13.007302213978988,74.43654487811384,-73.08711365337355 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark53(18.163529905292776,-28.95188142161613,19.120371395070205 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark53(25.90953159547074,-14.737083728891577,30.112921932402827 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark53(26.051213606530794,94.25674908523308,27.263717498874527 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark53(3.913206777741337,-8.250393321166811,-38.21117864831041 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark53(48.119224426332494,74.01288687227822,68.89190690095799 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark53(53.452547418051836,55.680895760735666,10.209072668755397 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark53(92.03236291272577,4.898232738071201,-4.128163231802986 ) ;
  }
}
