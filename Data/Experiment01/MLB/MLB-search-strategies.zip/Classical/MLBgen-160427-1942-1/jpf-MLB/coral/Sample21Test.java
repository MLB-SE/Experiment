import org.junit.Test;

public class Sample21Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark21(23.35063715611967,-84.6928742120633 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark21(40.967044624238355,25.391811948344543 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark21(44.107184880390065,-21.83157358037664 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark21(56.82920998820296,-22.03284625009121 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark21(-6.475541333932881,-81.59276408105151 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark21(-70.4320496287362,-53.049117787486196 ) ;
  }
}
