import org.junit.Test;

public class Sample49Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark49(0.05898933673892762,0.1980360511127204 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark49(1.3421784792213539E-8,3.2650853245465304E-5 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark49(18.39440442848499,34.64987078475903 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark49(-22.004136335014593,96.52269095810797 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark49(23.92193917462798,26.07806082537202 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark49(2.7867401029772423,5.2544077940689204 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark49(5.035569856491918,56.06972026039395 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark49(62.13119516352586,72.25384815045484 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark49(6.726154669061373,8.501680079797907 ) ;
  }
}
