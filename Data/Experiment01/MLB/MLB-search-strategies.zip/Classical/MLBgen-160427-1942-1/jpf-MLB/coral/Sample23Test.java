import org.junit.Test;

public class Sample23Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark23(-100.0,-13.709460440149243,0,-20.634205501774264 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark23(10.656360544687258,-35.17331047720825,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark23(42.272296337450456,-28.833236296917747,0,0 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark23(-54.58514531609473,-61.81240809547519,-64.09013822079177,0.1147779678676244 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark23(66.10486615682629,86.05272032291234,24.387571834148503,76.82398481657734 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark23(92.08301921371717,-74.00382486537629,0,-94.45303755322203 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark23(99.39530968280138,-5.142381980592404,-69.41207873074902,-8.506565538735384 ) ;
  }
}
