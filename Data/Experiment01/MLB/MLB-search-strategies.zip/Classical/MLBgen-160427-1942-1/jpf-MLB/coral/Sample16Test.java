import org.junit.Test;

public class Sample16Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-0.6789561138275815 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark16(0,0,0,0,-16.111625394029232 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark16(59.25247058807062,15.140889154381014,43.80126228106943,-24.903430086183434,-36.75139945046957 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark16(68.30779418588503,14.521188143349747,-130.27321785115922,35.638684292960306,-33.42518382634701 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark16(-76.49325119447363,15.544571177908011,36.24242041956674,-21.999539212800755,87.97517476971419 ) ;
  }
}
