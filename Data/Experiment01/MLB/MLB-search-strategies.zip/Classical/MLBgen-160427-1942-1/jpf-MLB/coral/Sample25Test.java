import org.junit.Test;

public class Sample25Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark25(100.0,19.947761254427505,100.0,0,26.077923342966297 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark25(18.022562928321605,-24.461587928755762,-11.488373683520535,0,4.267433204616822 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark25(-22.106708553069325,41.84245249421622,-71.63922948262227,25.974819620484624,18.480277734942007 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark25(-3.32141875280567,92.71550801791966,-95.72476113374645,0,0 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark25(33.26154237243196,-16.389886086485433,-74.12457211318326,94.60421610205736,-39.20784848504177 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark25(82.90560641451134,42.453606090415775,-77.79796331146731,0,0 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark25(-87.83408085491658,19.737146792063694,30.392997136319686,0,0 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark25(8.885313280028925,-62.03032051534385,-57.99886960697525,-5.6488297698279695,-13.886945666285968 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark25(-93.1174782913249,100.0,50.70743041375185,-7.097681129511008,-15.649767957610011 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark25(99.90517547200962,99.99999999999999,-100.0,62.01536776929841,-100.0 ) ;
  }
}
