import org.junit.Test;

public class Sample31Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark31(-0.3219034136478811 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark31(1.0221232891358483 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark31(-14.194756085968336 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark31(4.792537434773591 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark31(5.135256966468631 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark31(-72.45168655062764 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark31(77.42653188729702 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark31(88.46645224701572 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark31(-8.881784197001252E-16 ) ;
  }
}
