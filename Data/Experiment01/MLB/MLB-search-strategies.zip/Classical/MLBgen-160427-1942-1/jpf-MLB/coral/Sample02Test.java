import org.junit.Test;

public class Sample02Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark02(-26.403030439427994,73.79628530066108 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark02(-5.015323531385292,-77.90363688381284 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark02(70.58929131710643,-50.16893906773536 ) ;
  }
}
