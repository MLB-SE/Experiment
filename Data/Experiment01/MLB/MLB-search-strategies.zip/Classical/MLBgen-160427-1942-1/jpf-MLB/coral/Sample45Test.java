import org.junit.Test;

public class Sample45Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark45(0.0,-20.20066841876718,75.78345248245864 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark45(127.44369542104485,76.77436662326024,2.3375590414151293 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark45(2.710505431213761E-20,1.0000000000000002,0.22378801140821902 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark45(-274.0184154112575,-345.79346682365826,36.96886390771712 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark45(34.40147002161953,78.1174290119965,46.45146335350475 ) ;
  }

  @Test
  public void test5() {
    coral.tests.JPFBenchmark.benchmark45(-5.757410386630184,-37.067433064992315,12.154301428196135 ) ;
  }

  @Test
  public void test6() {
    coral.tests.JPFBenchmark.benchmark45(62.33130039461281,72.96963677678485,22.672665629347975 ) ;
  }

  @Test
  public void test7() {
    coral.tests.JPFBenchmark.benchmark45(66.72361125180834,12.813996524270806,91.44636364120927 ) ;
  }

  @Test
  public void test8() {
    coral.tests.JPFBenchmark.benchmark45(68.1710476532655,1.0,12.291896197864176 ) ;
  }

  @Test
  public void test9() {
    coral.tests.JPFBenchmark.benchmark45(70.31824573329303,72.31824573329303,20.845553495472476 ) ;
  }

  @Test
  public void test10() {
    coral.tests.JPFBenchmark.benchmark45(78.24039196288174,83.37665356911293,39.747015949450315 ) ;
  }

  @Test
  public void test11() {
    coral.tests.JPFBenchmark.benchmark45(-89.86330605604704,-41.63141969374635,51.949011302349135 ) ;
  }

  @Test
  public void test12() {
    coral.tests.JPFBenchmark.benchmark45(90.31234444891453,-97.84564654413623,87.51608084745112 ) ;
  }

  @Test
  public void test13() {
    coral.tests.JPFBenchmark.benchmark45(95.95373658984852,-7.454918410138305,56.78400053925091 ) ;
  }

  @Test
  public void test14() {
    coral.tests.JPFBenchmark.benchmark45(98.82313694441987,-87.80081890809875,39.903376549629286 ) ;
  }
}
