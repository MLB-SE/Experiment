import org.junit.Test;

public class Sample56Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark56(0,1.833526924681479,0,0,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark56(0,-9.963764804280473,0,0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark56(-26.969730759386977,-29.61732854639716,-65.90625246777842,80.05485181612383,-71.5370793300122 ) ;
  }

  @Test
  public void test3() {
    coral.tests.JPFBenchmark.benchmark56(52.19607464654542,1.0905635974034311,10.790106476285223,-8.265681302494372,98.73183317925722 ) ;
  }

  @Test
  public void test4() {
    coral.tests.JPFBenchmark.benchmark56(-68.17575444828705,49.49137509178695,-76.57910779136094,-78.32068443933757,0.22597755081912396 ) ;
  }
}
