import org.junit.Test;

public class Sample41Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark41(-0.2015399950763756,0.2421583646917611 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark41(0.8816697773042677,-0.10432818109251052 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark41(49.87220321644813,1.9353530003389352 ) ;
  }
}
