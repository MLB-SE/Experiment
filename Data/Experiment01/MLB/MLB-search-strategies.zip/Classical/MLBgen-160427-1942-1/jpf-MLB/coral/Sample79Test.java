import org.junit.Test;

public class Sample79Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark79(-47.47390158320377,28.20777778453555,90.10469053028083,65.37230481446426,0 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark79(-4.921751735950199E-10,100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark79(-4.975503597604317E-7,100.0,100.0,100.0,0 ) ;
  }
}
