import org.junit.Test;

public class Sample08Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark08(-1.311810462583125,-98.83893799742212,98.86289772313472 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark08(-40.49471229283734,69.98872905888217,-45.53939944253995 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark08(64.20461892535094,34.0374221506421,-83.96274092963725 ) ;
  }
}
