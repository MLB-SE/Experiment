import org.junit.Test;

public class Sample14Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark14(0.5582578353206173,65.32922809214806,-88.13051885620955,93.3310318301397 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark14(-0.750407145375604,79.22755839337657,30.958220459103956,70.53618678259949 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark14(-0.9370737757319318,2.326391307851054,40.54196632395073,-71.10659224536158 ) ;
  }
}
