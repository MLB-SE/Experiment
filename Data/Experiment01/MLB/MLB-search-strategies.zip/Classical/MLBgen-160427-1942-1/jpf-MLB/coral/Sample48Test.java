import org.junit.Test;

public class Sample48Test {

  @Test
  public void test0() {
    coral.tests.JPFBenchmark.benchmark48(22.394798401177795,24.639541408842163,-87.04994204778511 ) ;
  }

  @Test
  public void test1() {
    coral.tests.JPFBenchmark.benchmark48(-63.13680983832951,55.591431521385815,-7.545378316943697 ) ;
  }

  @Test
  public void test2() {
    coral.tests.JPFBenchmark.benchmark48(-68.39502931020016,-32.43016409682322,-17.191068407861266 ) ;
  }
}
