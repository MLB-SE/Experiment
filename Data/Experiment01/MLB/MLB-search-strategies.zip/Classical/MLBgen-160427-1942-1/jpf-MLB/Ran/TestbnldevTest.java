import org.junit.Test;

public class TestbnldevTest {

  @Test
  public void test0() {
    dev.bnldev(0.0,25,0 ) ;
  }

  @Test
  public void test1() {
    dev.bnldev(0.0,99,0 ) ;
  }

  @Test
  public void test2() {
    dev.bnldev(0.6021064425740406,0,0 ) ;
  }

  @Test
  public void test3() {
    dev.bnldev(1.0,25,0 ) ;
  }

  @Test
  public void test4() {
    dev.bnldev(1.0,-250,0 ) ;
  }

  @Test
  public void test5() {
    dev.bnldev(1.0,43,0 ) ;
  }

  @Test
  public void test6() {
    dev.bnldev(1.0,-495,0 ) ;
  }

  @Test
  public void test7() {
    dev.bnldev(-166.0,442,0 ) ;
  }

  @Test
  public void test8() {
    dev.bnldev(186.0,86,0 ) ;
  }

  @Test
  public void test9() {
    dev.bnldev(-238.0,17,-31 ) ;
  }

  @Test
  public void test10() {
    dev.bnldev(245.0,397,0 ) ;
  }

  @Test
  public void test11() {
    dev.bnldev(30.0,1,-797 ) ;
  }

  @Test
  public void test12() {
    dev.bnldev(31.644737540499364,0,0 ) ;
  }

  @Test
  public void test13() {
    dev.bnldev(-32.0,25,0 ) ;
  }

  @Test
  public void test14() {
    dev.bnldev(-350.0,21,0 ) ;
  }

  @Test
  public void test15() {
    dev.bnldev(-357.0,747,0 ) ;
  }

  @Test
  public void test16() {
    dev.bnldev(-37.18465315135986,0,0 ) ;
  }

  @Test
  public void test17() {
    dev.bnldev(41.0,25,0 ) ;
  }

  @Test
  public void test18() {
    dev.bnldev(429.0,-908,0 ) ;
  }

  @Test
  public void test19() {
    dev.bnldev(-47.0,-65,0 ) ;
  }

  @Test
  public void test20() {
    dev.bnldev(-549.0,-373,0 ) ;
  }

  @Test
  public void test21() {
    dev.bnldev(560.0,698,0 ) ;
  }

  @Test
  public void test22() {
    dev.bnldev(-638.0,-309,0 ) ;
  }

  @Test
  public void test23() {
    dev.bnldev(-647.0,8,822 ) ;
  }

  @Test
  public void test24() {
    dev.bnldev(665.0,22,143 ) ;
  }

  @Test
  public void test25() {
    dev.bnldev(666.0,-334,0 ) ;
  }

  @Test
  public void test26() {
    dev.bnldev(811.0,-797,0 ) ;
  }

  @Test
  public void test27() {
    dev.bnldev(-841.0,873,0 ) ;
  }

  @Test
  public void test28() {
    dev.bnldev(-893.0,-488,0 ) ;
  }

  @Test
  public void test29() {
    dev.bnldev(937.0,19,0 ) ;
  }

  @Test
  public void test30() {
    dev.bnldev(-990.0,-106,0 ) ;
  }
}
