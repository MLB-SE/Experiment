import org.junit.Test;

public class TestellfTest {

  @Test
  public void test0() {
    ell.ellf(22.72194859743226,0.6865849121978584 ) ;
  }

  @Test
  public void test1() {
    ell.ellf(-25.132741222050832,1.8651480909594964 ) ;
  }

  @Test
  public void test2() {
    ell.ellf(-26.833467192968953,-41.97186293453954 ) ;
  }

  @Test
  public void test3() {
    ell.ellf(-28.241513948039938,-6.730525543127513 ) ;
  }

  @Test
  public void test4() {
    ell.ellf(28.274333880543995,-6.855441259331384 ) ;
  }

  @Test
  public void test5() {
    ell.ellf(-28.274333895326297,1.2176180587251526 ) ;
  }

  @Test
  public void test6() {
    ell.ellf(3.1415926369496243,-1.0487749522172893 ) ;
  }

  @Test
  public void test7() {
    ell.ellf(34.55751919113894,9.045711301095407 ) ;
  }

  @Test
  public void test8() {
    ell.ellf(34.557519224406434,0.6840005408236727 ) ;
  }

  @Test
  public void test9() {
    ell.ellf(34.55752127187662,-0.9999972671920849 ) ;
  }

  @Test
  public void test10() {
    ell.ellf(-40.84070457382462,-4.601413389969169 ) ;
  }

  @Test
  public void test11() {
    ell.ellf(-4.525952924465827,61.72901435952568 ) ;
  }

  @Test
  public void test12() {
    ell.ellf(-47.12388979706262,2.4006871928977938 ) ;
  }

  @Test
  public void test13() {
    ell.ellf(51.83627878423159,1.0 ) ;
  }

  @Test
  public void test14() {
    ell.ellf(-52.61912959170463,-0.6602414200169875 ) ;
  }

  @Test
  public void test15() {
    ell.ellf(56.548667763996626,-8.359833938766513 ) ;
  }

  @Test
  public void test16() {
    ell.ellf(56.54866777134025,0.24596466254337201 ) ;
  }

  @Test
  public void test17() {
    ell.ellf(59.68927888538097,1.0000000000438396 ) ;
  }

  @Test
  public void test18() {
    ell.ellf(-61.26105673624344,-1.0 ) ;
  }

  @Test
  public void test19() {
    ell.ellf(62.831814652062484,-1.00000000325738 ) ;
  }

  @Test
  public void test20() {
    ell.ellf(62.831853088792414,-0.0915239519504496 ) ;
  }

  @Test
  public void test21() {
    ell.ellf(-65.96155289595262,83.29351866539832 ) ;
  }

  @Test
  public void test22() {
    ell.ellf(66.80063552569567,-64.9419835374143 ) ;
  }

  @Test
  public void test23() {
    ell.ellf(-6.764304302040775,2.160893990776136 ) ;
  }

  @Test
  public void test24() {
    ell.ellf(70.68583470263327,-0.7998579518809908 ) ;
  }

  @Test
  public void test25() {
    ell.ellf(-72.25456123395074,0.9999999999923052 ) ;
  }

  @Test
  public void test26() {
    ell.ellf(72.25663104045121,2.0015614439920633 ) ;
  }

  @Test
  public void test27() {
    ell.ellf(75.58741608470532,5.317288862826453 ) ;
  }

  @Test
  public void test28() {
    ell.ellf(78.53981633651378,-0.31201525985854417 ) ;
  }

  @Test
  public void test29() {
    ell.ellf(-79.4357765791099,0.761581963595944 ) ;
  }

  @Test
  public void test30() {
    ell.ellf(83.25220532012952,0.17863383297981272 ) ;
  }

  @Test
  public void test31() {
    ell.ellf(-84.82946876167858,1.327582463877046E-6 ) ;
  }

  @Test
  public void test32() {
    ell.ellf(-85.59553344577768,-1.4327661359788506 ) ;
  }

  @Test
  public void test33() {
    ell.ellf(-91.10618693867863,0.8574929883497342 ) ;
  }

  @Test
  public void test34() {
    ell.ellf(-91.95621362689876,0.47699247832677827 ) ;
  }

  @Test
  public void test35() {
    ell.ellf(-94.19498407281912,-18.949797836286365 ) ;
  }

  @Test
  public void test36() {
    ell.ellf(-94.24618747108256,7.913406562114287E-6 ) ;
  }

  @Test
  public void test37() {
    ell.ellf(-97.38937201596616,1.2457287110904587 ) ;
  }

  @Test
  public void test38() {
    ell.ellf(97.38937226180441,-6.342170701744391 ) ;
  }
}
