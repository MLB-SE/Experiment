import org.junit.Test;

public class TestellpiTest {

  @Test
  public void test0() {
    ell.ellpi(-100.0,0,-0.709558767171262 ) ;
  }

  @Test
  public void test1() {
    ell.ellpi(-1.57079631946044,0,-0.9999999999997509 ) ;
  }

  @Test
  public void test2() {
    ell.ellpi(15.744798149021989,0,-27.15432061697258 ) ;
  }

  @Test
  public void test3() {
    ell.ellpi(21.99114858877954,0,1.4262235095519042 ) ;
  }

  @Test
  public void test4() {
    ell.ellpi(-25.13274123358335,0,-60.91243479171888 ) ;
  }

  @Test
  public void test5() {
    ell.ellpi(28.274333882125116,0,-19.423178025170962 ) ;
  }

  @Test
  public void test6() {
    ell.ellpi(3.1415926458043506,0,-1.4538494630490018 ) ;
  }

  @Test
  public void test7() {
    ell.ellpi(-31.41592653283199,0,1.7869160430066198 ) ;
  }

  @Test
  public void test8() {
    ell.ellpi(31.415935873568532,0,-0.0012265541451952746 ) ;
  }

  @Test
  public void test9() {
    ell.ellpi(-34.5575192034093,0,0.9987994222256367 ) ;
  }

  @Test
  public void test10() {
    ell.ellpi(-34.55751920674828,0,3.141171059217271 ) ;
  }

  @Test
  public void test11() {
    ell.ellpi(37.69911184016294,0,-1.248448890912079 ) ;
  }

  @Test
  public void test12() {
    ell.ellpi(41.04201514341682,0,0.658096129091918 ) ;
  }

  @Test
  public void test13() {
    ell.ellpi(-43.982297151115894,0,0.38236121118299593 ) ;
  }

  @Test
  public void test14() {
    ell.ellpi(47.12411767471307,0,0.5367929888700473 ) ;
  }

  @Test
  public void test15() {
    ell.ellpi(47.23402331465613,0,-9.09827010908995 ) ;
  }

  @Test
  public void test16() {
    ell.ellpi(-5.276496401300832,0,-83.16482143103411 ) ;
  }

  @Test
  public void test17() {
    ell.ellpi(-53.40723068220863,0,0.7562276213928967 ) ;
  }

  @Test
  public void test18() {
    ell.ellpi(54.97787143567456,0,-0.9910964937072521 ) ;
  }

  @Test
  public void test19() {
    ell.ellpi(61.26105699268416,0,0.9999999999999988 ) ;
  }

  @Test
  public void test20() {
    ell.ellpi(63.23889435557956,0,-15.607206130182249 ) ;
  }

  @Test
  public void test21() {
    ell.ellpi(-65.97344572332733,0,-3.7157986929833444 ) ;
  }

  @Test
  public void test22() {
    ell.ellpi(69.11503843421688,0,-1.009532999349555 ) ;
  }

  @Test
  public void test23() {
    ell.ellpi(72.27435911403205,0,2.59748624345211 ) ;
  }

  @Test
  public void test24() {
    ell.ellpi(-78.53981633851836,0,-1.7826981216898532 ) ;
  }

  @Test
  public void test25() {
    ell.ellpi(81.68140900888045,0,-0.84703518977059 ) ;
  }

  @Test
  public void test26() {
    ell.ellpi(-83.25220532012952,0,0.5340856143967185 ) ;
  }

  @Test
  public void test27() {
    ell.ellpi(-83.67761018801644,0,-19.068160859513 ) ;
  }

  @Test
  public void test28() {
    ell.ellpi(-87.96459430024699,0,-27.6493215594287 ) ;
  }

  @Test
  public void test29() {
    ell.ellpi(87.96459431223951,0,0.5569050334556256 ) ;
  }

  @Test
  public void test30() {
    ell.ellpi(9.087937503472128,0,3.0256567316883807 ) ;
  }

  @Test
  public void test31() {
    ell.ellpi(-91.10641021603881,0,-2.0270685746770018E-5 ) ;
  }

  @Test
  public void test32() {
    ell.ellpi(91.43599302798609,0,-1.0000000000000004 ) ;
  }

  @Test
  public void test33() {
    ell.ellpi(9.418778816006565,0,-92.08005592506588 ) ;
  }

  @Test
  public void test34() {
    ell.ellpi(-94.24777959204627,0,-0.2289759397293576 ) ;
  }

  @Test
  public void test35() {
    ell.ellpi(94.24777960788151,0,15.223630463896995 ) ;
  }

  @Test
  public void test36() {
    ell.ellpi(-95.81857593448869,0,-1.0 ) ;
  }

  @Test
  public void test37() {
    ell.ellpi(97.31412634643723,0,13.302307290828777 ) ;
  }

  @Test
  public void test38() {
    ell.ellpi(97.38937225561102,0,-0.7447516266313414 ) ;
  }
}
