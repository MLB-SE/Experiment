import org.junit.Test;

public class TestcisiTest {

  @Test
  public void test0() {
    frenel.cisi(0.13108914585928844 ) ;
  }

  @Test
  public void test1() {
    frenel.cisi(1.0542197943230523E-81 ) ;
  }

  @Test
  public void test2() {
    frenel.cisi(1.1102230246251565E-16 ) ;
  }

  @Test
  public void test3() {
    frenel.cisi(-12.252729645219503 ) ;
  }

  @Test
  public void test4() {
    frenel.cisi(1.237344495547461 ) ;
  }

  @Test
  public void test5() {
    frenel.cisi(-17.541302820622448 ) ;
  }

  @Test
  public void test6() {
    frenel.cisi(1.9721522630525295E-31 ) ;
  }

  @Test
  public void test7() {
    frenel.cisi(1.9999999999999938 ) ;
  }

  @Test
  public void test8() {
    frenel.cisi(-2.0 ) ;
  }

  @Test
  public void test9() {
    frenel.cisi(2.0 ) ;
  }

  @Test
  public void test10() {
    frenel.cisi(-24.523253618326038 ) ;
  }

  @Test
  public void test11() {
    frenel.cisi(-2.465190328815662E-32 ) ;
  }

  @Test
  public void test12() {
    frenel.cisi(2.465190328815662E-32 ) ;
  }

  @Test
  public void test13() {
    frenel.cisi(30.06685453444996 ) ;
  }

  @Test
  public void test14() {
    frenel.cisi(-4.4455174989701545E-162 ) ;
  }

  @Test
  public void test15() {
    frenel.cisi(-44.87089963545679 ) ;
  }

  @Test
  public void test16() {
    frenel.cisi(57.9374320153795 ) ;
  }

  @Test
  public void test17() {
    frenel.cisi(-58.65992361323664 ) ;
  }

  @Test
  public void test18() {
    frenel.cisi(75.25036139601221 ) ;
  }

  @Test
  public void test19() {
    frenel.cisi(-8.33355581928808 ) ;
  }

  @Test
  public void test20() {
    frenel.cisi(-8.673617379884035E-19 ) ;
  }
}
