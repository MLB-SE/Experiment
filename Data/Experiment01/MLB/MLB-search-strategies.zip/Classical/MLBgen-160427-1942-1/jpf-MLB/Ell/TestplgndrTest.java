import org.junit.Test;

public class TestplgndrTest {

  @Test
  public void test0() {
    plgndr.plgndr(0,-1,0 ) ;
  }

  @Test
  public void test1() {
    plgndr.plgndr(0,-104,0 ) ;
  }

  @Test
  public void test2() {
    plgndr.plgndr(0,398,0 ) ;
  }

  @Test
  public void test3() {
    plgndr.plgndr(0,-905,0 ) ;
  }

  @Test
  public void test4() {
    plgndr.plgndr(-1,0,0 ) ;
  }

  @Test
  public void test5() {
    plgndr.plgndr(-177,-178,0 ) ;
  }

  @Test
  public void test6() {
    plgndr.plgndr(-206,-681,0 ) ;
  }

  @Test
  public void test7() {
    plgndr.plgndr(209,109,82.03901436699596 ) ;
  }

  @Test
  public void test8() {
    plgndr.plgndr(-232,197,0 ) ;
  }

  @Test
  public void test9() {
    plgndr.plgndr(-251,-251,0 ) ;
  }

  @Test
  public void test10() {
    plgndr.plgndr(-265,1,0 ) ;
  }

  @Test
  public void test11() {
    plgndr.plgndr(-325,914,0 ) ;
  }

  @Test
  public void test12() {
    plgndr.plgndr(4185,2153,1.0000000004642715 ) ;
  }

  @Test
  public void test13() {
    plgndr.plgndr(-476,0,0 ) ;
  }

  @Test
  public void test14() {
    plgndr.plgndr(-535,588,0 ) ;
  }

  @Test
  public void test15() {
    plgndr.plgndr(587,264,1.0 ) ;
  }

  @Test
  public void test16() {
    plgndr.plgndr(618,172,0 ) ;
  }

  @Test
  public void test17() {
    plgndr.plgndr(627,232,0.0 ) ;
  }

  @Test
  public void test18() {
    plgndr.plgndr(713,366,-84.61428527630387 ) ;
  }

  @Test
  public void test19() {
    plgndr.plgndr(807,663,-32.106652893462666 ) ;
  }

  @Test
  public void test20() {
    plgndr.plgndr(934,741,-0.9999999999999982 ) ;
  }

  @Test
  public void test21() {
    plgndr.plgndr(-935,0,0 ) ;
  }

  @Test
  public void test22() {
    plgndr.plgndr(938,662,0.9999999999999996 ) ;
  }

  @Test
  public void test23() {
    plgndr.plgndr(946,622,-1.0 ) ;
  }

  @Test
  public void test24() {
    plgndr.plgndr(-957,-523,0 ) ;
  }

  @Test
  public void test25() {
    plgndr.plgndr(968,269,0.0 ) ;
  }

  @Test
  public void test26() {
    plgndr.plgndr(986,228,0.0 ) ;
  }

  @Test
  public void test27() {
    plgndr.plgndr(993,588,92.46105169087062 ) ;
  }
}
