import org.junit.Test;

public class TestdbrentTest {

  @Test
  public void test0() {
    ell.dbrent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.dbrent(0.9186737614159881,64.1146430726028,-95.81173503438312,0 ) ;
  }

  @Test
  public void test2() {
    ell.dbrent(-100.0,0.0,-100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.dbrent(100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.dbrent(-100.0,0,-100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.dbrent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test6() {
    ell.dbrent(12.85513396246705,0,-90.84959260442156,0 ) ;
  }

  @Test
  public void test7() {
    ell.dbrent(-13.962102529265463,-8.107251891057647,-2.252401252849829,0 ) ;
  }

  @Test
  public void test8() {
    ell.dbrent(-14.01201695326975,-95.03754497354639,1.3759082355796437,0 ) ;
  }

  @Test
  public void test9() {
    ell.dbrent(1.485753769739782,4.485741456516754,7.485729143293726,0 ) ;
  }

  @Test
  public void test10() {
    ell.dbrent(15.046160332413429,0.0,-15.046160332413429,0 ) ;
  }

  @Test
  public void test11() {
    ell.dbrent(18.295043980355643,38.59683201410081,95.68799290270792,0 ) ;
  }

  @Test
  public void test12() {
    ell.dbrent(18.54992608299915,-8.55415445284078,-37.04230152017429,0 ) ;
  }

  @Test
  public void test13() {
    ell.dbrent(22.344808647943584,0,22.34480864794358,0 ) ;
  }

  @Test
  public void test14() {
    ell.dbrent(-22.46812572480698,37.543032634735226,-22.46812572480698,0 ) ;
  }

  @Test
  public void test15() {
    ell.dbrent(22.47199152919383,0.0,15.672870678016046,0 ) ;
  }

  @Test
  public void test16() {
    ell.dbrent(23.601872304323777,-16.124754003477932,8.256703853761167,0 ) ;
  }

  @Test
  public void test17() {
    ell.dbrent(-27.707286484246367,-27.707286484246367,-27.707286484246367,0 ) ;
  }

  @Test
  public void test18() {
    ell.dbrent(28.96185580497823,0,28.961855804978228,0 ) ;
  }

  @Test
  public void test19() {
    ell.dbrent(32.98495657189422,18.62665133875747,32.98495657189422,0 ) ;
  }

  @Test
  public void test20() {
    ell.dbrent(34.46621000462585,26.52391660734682,34.46621000462585,0 ) ;
  }

  @Test
  public void test21() {
    ell.dbrent(-36.72262845044602,-70.0560559379792,-36.72262845044602,0 ) ;
  }

  @Test
  public void test22() {
    ell.dbrent(38.214624107839455,-18.212410160674068,38.214624107839455,0 ) ;
  }

  @Test
  public void test23() {
    ell.dbrent(-38.58033188784629,0.0,-38.58033188784629,0 ) ;
  }

  @Test
  public void test24() {
    ell.dbrent(41.634049042052425,0,-8.51984763609424,0 ) ;
  }

  @Test
  public void test25() {
    ell.dbrent(41.74491631860897,0.0,-53.74945743831239,0 ) ;
  }

  @Test
  public void test26() {
    ell.dbrent(-4.2044933900489845,0,-4.204493390048984,0 ) ;
  }

  @Test
  public void test27() {
    ell.dbrent(-44.12049492219909,0.0,-28.774861774370365,0 ) ;
  }

  @Test
  public void test28() {
    ell.dbrent(-45.56716949644104,0.0,-69.5793812265776,0 ) ;
  }

  @Test
  public void test29() {
    ell.dbrent(-48.07761348626772,-59.12717573702216,-70.17673798777659,0 ) ;
  }

  @Test
  public void test30() {
    ell.dbrent(51.68512292451,0,51.68512292450999,0 ) ;
  }

  @Test
  public void test31() {
    ell.dbrent(56.613570083453794,0,68.20372661029558,0 ) ;
  }

  @Test
  public void test32() {
    ell.dbrent(57.884052241452224,0,57.884052241452224,0 ) ;
  }

  @Test
  public void test33() {
    ell.dbrent(59.599776145593886,0,59.59977614559389,0 ) ;
  }

  @Test
  public void test34() {
    ell.dbrent(60.978186721644114,0.0,71.87629237680832,0 ) ;
  }

  @Test
  public void test35() {
    ell.dbrent(-62.83397925921953,0.0,62.83397925921953,0 ) ;
  }

  @Test
  public void test36() {
    ell.dbrent(63.71572630526762,33.39233913013166,11.927319235172959,0 ) ;
  }

  @Test
  public void test37() {
    ell.dbrent(-67.96970306898875,0.0,-16.12016444930153,0 ) ;
  }

  @Test
  public void test38() {
    ell.dbrent(75.3028968775888,67.51043049643512,59.71796411528145,0 ) ;
  }

  @Test
  public void test39() {
    ell.dbrent(-7.554375880175911,58.38083755246103,-18.35367265901793,0 ) ;
  }

  @Test
  public void test40() {
    ell.dbrent(-76.41648545533295,39.6715852960466,72.66739684217725,0 ) ;
  }

  @Test
  public void test41() {
    ell.dbrent(-7.945374476639017,-2.3080667637936187,-7.945374476639017,0 ) ;
  }

  @Test
  public void test42() {
    ell.dbrent(84.4041620073697,-17.63740340284545,-19.012757974091215,0 ) ;
  }

  @Test
  public void test43() {
    ell.dbrent(-91.49080413272543,0,-29.354455108503117,0 ) ;
  }

  @Test
  public void test44() {
    ell.dbrent(94.36493456596818,-29.358113501427894,96.29455157705274,0 ) ;
  }

  @Test
  public void test45() {
    ell.dbrent(-94.70357964291726,90.96758354720674,-87.92497106237278,0 ) ;
  }

  @Test
  public void test46() {
    ell.dbrent(-96.80886201099568,-27.932948750381897,36.75886888471666,0 ) ;
  }

  @Test
  public void test47() {
    ell.dbrent(99.63517368790001,0,99.6351736879,0 ) ;
  }
}
