import org.junit.Test;

public class TestbrentTest {

  @Test
  public void test0() {
    ell.brent(0.0,0.0,0.0,0 ) ;
  }

  @Test
  public void test1() {
    ell.brent(100.0,0.0,100.0,0 ) ;
  }

  @Test
  public void test2() {
    ell.brent(100.0,0,100.0,0 ) ;
  }

  @Test
  public void test3() {
    ell.brent(-100.0,-100.0,-100.0,0 ) ;
  }

  @Test
  public void test4() {
    ell.brent(100.0,100.0,100.0,0 ) ;
  }

  @Test
  public void test5() {
    ell.brent(-100.0,-99.99870137826706,-99.99740275653411,0 ) ;
  }

  @Test
  public void test6() {
    ell.brent(-1.1102230246251565E-16,0.0,-1.1102230246251565E-16,0 ) ;
  }

  @Test
  public void test7() {
    ell.brent(-11.369143508684743,26.97812322971926,65.32538996812326,0 ) ;
  }

  @Test
  public void test8() {
    ell.brent(-11.571774574061788,-0.45702245039746714,-11.571774574061788,0 ) ;
  }

  @Test
  public void test9() {
    ell.brent(1.1996456745887605,0,1.1996456745887603,0 ) ;
  }

  @Test
  public void test10() {
    ell.brent(-12.671951075078795,58.73392843315281,13.946681311993416,0 ) ;
  }

  @Test
  public void test11() {
    ell.brent(12.805485722683159,0.0,12.805485722683159,0 ) ;
  }

  @Test
  public void test12() {
    ell.brent(-1.290338128461996,0,-1.2903381284619961,0 ) ;
  }

  @Test
  public void test13() {
    ell.brent(13.468411051586543,-5.39840298942562,-12.292433908730445,0 ) ;
  }

  @Test
  public void test14() {
    ell.brent(-17.494287573790018,0.0,-70.85936300824787,0 ) ;
  }

  @Test
  public void test15() {
    ell.brent(21.540337076021828,15.526082725392726,21.540337076021828,0 ) ;
  }

  @Test
  public void test16() {
    ell.brent(-2.4377530625028,0.0,-100.0,0 ) ;
  }

  @Test
  public void test17() {
    ell.brent(24.95923714192121,-98.50445774259606,24.95923714192121,0 ) ;
  }

  @Test
  public void test18() {
    ell.brent(-28.71950341000901,0,-70.7940361428236,0 ) ;
  }

  @Test
  public void test19() {
    ell.brent(-29.44324607787368,-14.035221089274245,-19.954462740239507,0 ) ;
  }

  @Test
  public void test20() {
    ell.brent(29.63570913561734,0,29.635709135617343,0 ) ;
  }

  @Test
  public void test21() {
    ell.brent(3.0270622627578803,-46.09196291199855,33.114407184159944,0 ) ;
  }

  @Test
  public void test22() {
    ell.brent(31.876494989770748,0,31.87649498977075,0 ) ;
  }

  @Test
  public void test23() {
    ell.brent(32.72796398112722,13.62359931496481,4.461728630845677,0 ) ;
  }

  @Test
  public void test24() {
    ell.brent(33.32597531032272,0,33.32597531032272,0 ) ;
  }

  @Test
  public void test25() {
    ell.brent(34.41627398434817,-25.774304761742943,-85.96488350783406,0 ) ;
  }

  @Test
  public void test26() {
    ell.brent(-35.939768146483814,3.6225611155484785,-92.75444367291269,0 ) ;
  }

  @Test
  public void test27() {
    ell.brent(37.38095258140393,81.91026747206146,59.8487962674611,0 ) ;
  }

  @Test
  public void test28() {
    ell.brent(41.85919900624618,0.0,-41.85919900624618,0 ) ;
  }

  @Test
  public void test29() {
    ell.brent(43.025437813018236,73.69639165397821,43.025437813018236,0 ) ;
  }

  @Test
  public void test30() {
    ell.brent(44.28150844964349,0,44.281508449643496,0 ) ;
  }

  @Test
  public void test31() {
    ell.brent(45.09317710086265,25.100213810221845,82.07978139522311,0 ) ;
  }

  @Test
  public void test32() {
    ell.brent(46.92328236766581,0,46.92328236766582,0 ) ;
  }

  @Test
  public void test33() {
    ell.brent(-5.006089874233405,0.0,5.006089874233405,0 ) ;
  }

  @Test
  public void test34() {
    ell.brent(51.169217425802316,0.0,82.36988481439577,0 ) ;
  }

  @Test
  public void test35() {
    ell.brent(-51.26040079249862,-23.44886280834445,-51.26040079249862,0 ) ;
  }

  @Test
  public void test36() {
    ell.brent(51.817332011634676,-7.372417926893064,39.39715585172323,0 ) ;
  }

  @Test
  public void test37() {
    ell.brent(-52.879983758578916,85.32759212973457,-52.879983758578916,0 ) ;
  }

  @Test
  public void test38() {
    ell.brent(-59.296571024559206,52.804263742079485,-92.49618427343486,0 ) ;
  }

  @Test
  public void test39() {
    ell.brent(-63.01075110794838,0,-61.726615887989226,0 ) ;
  }

  @Test
  public void test40() {
    ell.brent(-63.999739361172445,-12.641701401050526,77.77371509031255,0 ) ;
  }

  @Test
  public void test41() {
    ell.brent(-68.76390704677115,-30.84017490810811,-163.95506612149086,0 ) ;
  }

  @Test
  public void test42() {
    ell.brent(73.41517434910898,0.0,-31.99654526213014,0 ) ;
  }

  @Test
  public void test43() {
    ell.brent(-83.01290492002384,0,-8.81768441476261,0 ) ;
  }

  @Test
  public void test44() {
    ell.brent(-86.29174508711122,0.0,-28.03124403075968,0 ) ;
  }

  @Test
  public void test45() {
    ell.brent(-87.84846136301503,0.0,-74.18714005264921,0 ) ;
  }

  @Test
  public void test46() {
    ell.brent(88.28981884248188,0,15.803417214785867,0 ) ;
  }

  @Test
  public void test47() {
    ell.brent(96.87201904541477,1.8595781144319545,-93.15286281655086,0 ) ;
  }
}
