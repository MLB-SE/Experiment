import org.junit.Test;

public class TestelleTest {

  @Test
  public void test0() {
    ell.elle(100.0,-0.4411254843339254 ) ;
  }

  @Test
  public void test1() {
    ell.elle(-1.0079272671416206E-8,1.1717891889598568 ) ;
  }

  @Test
  public void test2() {
    ell.elle(-10.903526695161887,-37.158870476318896 ) ;
  }

  @Test
  public void test3() {
    ell.elle(-15.653193447723737,18.267361960373027 ) ;
  }

  @Test
  public void test4() {
    ell.elle(-21.991006700029327,-1.3727311693873104E-4 ) ;
  }

  @Test
  public void test5() {
    ell.elle(28.274333881737117,-19.581965687888292 ) ;
  }

  @Test
  public void test6() {
    ell.elle(-29.973525885824245,4.9543953103447365 ) ;
  }

  @Test
  public void test7() {
    ell.elle(31.410448454867037,0.8051918432841205 ) ;
  }

  @Test
  public void test8() {
    ell.elle(-31.415926534486882,1.0601855566105327 ) ;
  }

  @Test
  public void test9() {
    ell.elle(-3.1415927013118425,-0.9704100814578425 ) ;
  }

  @Test
  public void test10() {
    ell.elle(34.557519166752705,0.8134838266322555 ) ;
  }

  @Test
  public void test11() {
    ell.elle(34.55751917507004,1.1299841489116893 ) ;
  }

  @Test
  public void test12() {
    ell.elle(-3.5021370603669473,2.8345981671562797 ) ;
  }

  @Test
  public void test13() {
    ell.elle(-37.64294148511566,-2.1073799522429964E-7 ) ;
  }

  @Test
  public void test14() {
    ell.elle(-37.69911187751109,1.0781733908967652 ) ;
  }

  @Test
  public void test15() {
    ell.elle(38.17781297933237,-1.479571142854144 ) ;
  }

  @Test
  public void test16() {
    ell.elle(45.79830587764869,-58.42024481426829 ) ;
  }

  @Test
  public void test17() {
    ell.elle(54.977871436532986,0.02740795037272487 ) ;
  }

  @Test
  public void test18() {
    ell.elle(5.836839148606776,-2.3165707593977656 ) ;
  }

  @Test
  public void test19() {
    ell.elle(59.69026036109342,-0.996688039215656 ) ;
  }

  @Test
  public void test20() {
    ell.elle(62.387683015338155,-0.996420444270238 ) ;
  }

  @Test
  public void test21() {
    ell.elle(63.459817144850604,1.084123267097354 ) ;
  }

  @Test
  public void test22() {
    ell.elle(75.3982236721793,-0.9065938093413135 ) ;
  }

  @Test
  public void test23() {
    ell.elle(-76.24192114212781,-1.338498261375416 ) ;
  }

  @Test
  public void test24() {
    ell.elle(76.96902001294994,-1.0 ) ;
  }

  @Test
  public void test25() {
    ell.elle(-7.853981627708899,1.0000000000000004 ) ;
  }

  @Test
  public void test26() {
    ell.elle(78.53981634369238,1.0631785419960944 ) ;
  }

  @Test
  public void test27() {
    ell.elle(-81.6814089904051,-1.0139876827697467 ) ;
  }

  @Test
  public void test28() {
    ell.elle(84.8228411995257,-1.000000000649377 ) ;
  }

  @Test
  public void test29() {
    ell.elle(-9.04637801390665,0.300878762028681 ) ;
  }

  @Test
  public void test30() {
    ell.elle(91.10618696325959,-1.03563285566611 ) ;
  }

  @Test
  public void test31() {
    ell.elle(-95.81857593448869,-0.1644047119212928 ) ;
  }

  @Test
  public void test32() {
    ell.elle(97.38937225244145,-10.148685861247635 ) ;
  }
}
