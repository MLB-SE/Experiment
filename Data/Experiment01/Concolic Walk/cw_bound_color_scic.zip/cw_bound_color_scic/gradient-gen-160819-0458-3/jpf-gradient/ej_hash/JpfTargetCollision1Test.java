import org.junit.Test;

public class JpfTargetCollision1Test {

  @Test
  public void test0() {
    EffectiveJavaHashCode.testCollision1(0,0l,0,0,0l,0);
  }

  @Test
  public void test1() {
    EffectiveJavaHashCode.testCollision1(1,0l,0,0,0l,0);
  }
}
