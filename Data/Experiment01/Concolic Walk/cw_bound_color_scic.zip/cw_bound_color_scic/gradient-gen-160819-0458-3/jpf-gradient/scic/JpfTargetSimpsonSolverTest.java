import org.junit.Test;

public class JpfTargetSimpsonSolverTest {

  @Test
  public void test0() {
    scic.SimpsonSolver.simpson(0.0,0.0);
  }

  @Test
  public void test1() {
    scic.SimpsonSolver.simpson(-129.98577295565795,0.0);
  }

  @Test
  public void test2() {
    scic.SimpsonSolver.simpson(-75.19884823877193,0.0);
  }
}
